# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""
    Kadr+ 2.0 — Telegram source for the new FanFilm engine.

    Etap 4:
    - logowanie do konta Telegram przez MTProto/Telethon;
    - pobieranie listy grup/kanałów/dialogów z konta użytkownika;
    - wyszukiwanie plików wideo w tych dialogach;
    - odtwarzanie przez lokalny proxy HTTP z obsługą Range;
    - szybkie wyszukiwanie po koncie z twardym filtrem do własnych dialogów użytkownika;
    - skan plików wideo pod postem-plakatem/opisem dla filmów i seriali.

    Prywatność:
    - kod logowania i 2FA są wpisywane wyłącznie w Kodi;
    - sesja Telegrama jest zapisywana lokalnie w profilu dodatku.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import os
import re
import sys
import time
import uuid
import shutil
import threading
import queue
import struct
import unicodedata
import zlib
from html import unescape
from urllib.parse import quote, quote_plus, urlencode, urlparse

import requests

from ptw.debug import fflog, fflog_exc
from ptw.libraries import control, title_matcher


# Vendored Telethon dependencies. Telethon is pure Python, but Kodi/Android
# usually does not provide it as script.module.telethon.
def _telegram_vendor_path():
    try:
        return os.path.join(control.addonPath, 'resources', 'lib', 'vendor', 'telegram')
    except Exception:
        return ''


_vp = _telegram_vendor_path()
if _vp and _vp not in sys.path:
    sys.path.insert(0, _vp)

# Telethon reports a routine idle-socket reconnect as a warning on stderr.
# Kodi classifies stderr as an add-on error even though Telethon reconnects and
# the search continues.  Actual login/search/stream failures are logged by the
# guarded Kadr+ calls below, so keep the transport's internal logger quiet.
_TG_TELETHON_LOGGER = logging.getLogger('kadrplus.telegram.telethon')
_TG_TELETHON_LOGGER.setLevel(logging.CRITICAL)

_TG_PROXY_SERVER = None
_TG_PROXY_PORT = None
_TG_PROXY_THREAD = None
_TG_PROXY_MAP = {}
_TG_RANGE_WORKERS = {}
_TG_LOOP_BY_THREAD = {}
_TG_SEARCH_LOCK = threading.Lock()
_TG_SEARCH_STATE_LOCK = threading.Lock()
_TG_ACTIVE_SEARCH = None


def _token_tag(token):
    """Return a non-reversible correlation id instead of logging a stream token."""
    return hashlib.sha256(str(token).encode('utf-8')).hexdigest()[:8]


def _tg_cache_dir():
    try:
        folder = os.path.join(control.dataPath, 'telegram', 'stream_cache')
        try:
            control.makeDirs(folder)
        except Exception:
            if not os.path.exists(folder):
                os.makedirs(folder, exist_ok=True)
        return folder
    except Exception:
        try:
            folder = os.path.join(control.dataPath, 'telegram_stream_cache')
            os.makedirs(folder, exist_ok=True)
            return folder
        except Exception:
            return control.dataPath


def _tg_cache_size(spec):
    try:
        path = (spec or {}).get('cache_path') or ''
        if path and os.path.exists(path):
            return int(os.path.getsize(path) or 0)
    except Exception:
        pass
    try:
        return int((spec or {}).get('cache_pos') or 0)
    except Exception:
        return 0



def _tg_clear_stream_cache(max_age=0):
    """Remove old 2.41.24 progressive Telegram cache files.

    2.41.24 could start downloading multi-GB files in the background.  The new
    proxy no longer uses this cache, so it is safe to clean the addon-owned
    telegram/stream_cache folder.
    """
    try:
        cdir = _tg_cache_dir()
        if not cdir or not os.path.isdir(cdir):
            return 0
        now = time.time()
        removed = 0
        for name in os.listdir(cdir):
            path = os.path.join(cdir, name)
            try:
                if os.path.isfile(path) and (not max_age or now - os.path.getmtime(path) >= max_age):
                    os.remove(path)
                    removed += 1
            except Exception:
                pass
        if removed:
            fflog('[telegram-proxy] cleaned old stream_cache files=%s' % removed, 1)
        return removed
    except Exception:
        return 0



def _tg_temp_session_base(original_base):
    """Create a per-request copy of Telethon SQLite session.

    Kodi does HEAD/GET/range probes in parallel. Reusing the main .session
    file in every proxy request locks SQLite and playback ends with HTTP 503.
    A short-lived copy keeps the authorised auth key but avoids writing to the
    same database from multiple proxy threads.
    """
    try:
        folder = os.path.join(os.path.dirname(original_base), "proxy_sessions")
        if not os.path.exists(folder):
            os.makedirs(folder, exist_ok=True)
        tmp_base = os.path.join(folder, "tg_proxy_%s" % uuid.uuid4().hex)
        src = original_base + ".session"
        dst = tmp_base + ".session"
        if os.path.exists(src):
            shutil.copy2(src, dst)
            return tmp_base
    except Exception:
        fflog_exc(1)
    return original_base


def _tg_delete_session_copy(base):
    try:
        if not base:
            return
        folder = os.path.basename(os.path.dirname(base))
        if folder != "proxy_sessions":
            return
        for suffix in (".session", ".session-journal", ".session-wal", ".session-shm"):
            path = base + suffix
            try:
                if os.path.exists(path):
                    os.remove(path)
            except Exception:
                pass
    except Exception:
        pass


def _tg_safe_disconnect(client):
    """Disconnect Telethon without leaking CancelledError into Kodi threads."""
    loop = None
    try:
        if client:
            loop = getattr(client, 'loop', None)
            result = client.disconnect()
            # Telethon's sync facade normally waits itself. In a Kodi worker it
            # can occasionally return an awaitable instead, leaving receive and
            # Queue.get tasks alive until Python destroys the interpreter.
            if (asyncio.iscoroutine(result) or asyncio.isfuture(result)) and loop and not loop.is_running():
                loop.run_until_complete(result)
    except BaseException:
        # On Kodi/Android Telethon may raise asyncio.CancelledError during
        # disconnect. It is BaseException on Python 3.11, so except Exception
        # does not catch it and the HTTP request thread explodes in the log.
        pass
    try:
        # Give Telethon's cancellation callbacks one event-loop turn and drain
        # anything it left behind. Every Kadr+ worker owns its loop, so this does
        # not cancel tasks belonging to another source search.
        if loop and not loop.is_closed() and not loop.is_running():
            pending = [task for task in asyncio.all_tasks(loop) if not task.done()]
            for task in pending:
                task.cancel()
            if pending:
                loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
    except BaseException:
        pass
    try:
        if client:
            _tg_delete_session_copy(getattr(client, '_kadrplus_temp_session_base', ''))
    except Exception:
        pass


def _tg_close_current_loop():
    """Close the search worker's private loop after Telethon disconnects.

    Kodi can keep provider threads alive between plugin invocations.  Leaving a
    stopped Telethon loop in that thread produced ``Task was destroyed but it
    is pending`` during the next scan and made the number of Telegram results
    depend on timing.  Stream proxy workers own separate loops and do not call
    this helper.
    """
    loop = _TG_LOOP_BY_THREAD.pop(threading.get_ident(), None)
    try:
        if not loop or loop.is_closed() or loop.is_running():
            return
        pending = [task for task in asyncio.all_tasks(loop) if not task.done()]
        for task in pending:
            task.cancel()
        if pending:
            loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
        loop.run_until_complete(asyncio.sleep(0))
        loop.close()
    except BaseException:
        pass


def _tg_claim_search(owner):
    """Serialize account searches and cooperatively replace an older scan."""
    global _TG_ACTIVE_SEARCH
    current = threading.current_thread()
    try:
        with _TG_SEARCH_STATE_LOCK:
            previous = _TG_ACTIVE_SEARCH
            if previous is not None:
                try:
                    _previous_owner, previous_thread = previous
                    if previous_thread is not current:
                        stop_event = getattr(previous_thread, 'stop_event', None)
                        if stop_event is not None:
                            stop_event.set()
                except Exception:
                    pass

        while True:
            try:
                if owner._cancelled():
                    return False
            except Exception:
                pass
            if _TG_SEARCH_LOCK.acquire(timeout=0.2):
                with _TG_SEARCH_STATE_LOCK:
                    _TG_ACTIVE_SEARCH = (owner, current)
                return True
    except BaseException:
        return False


def _tg_release_search(owner):
    global _TG_ACTIVE_SEARCH
    try:
        current = threading.current_thread()
        with _TG_SEARCH_STATE_LOCK:
            if _TG_ACTIVE_SEARCH == (owner, current):
                _TG_ACTIVE_SEARCH = None
    except Exception:
        pass
    try:
        _TG_SEARCH_LOCK.release()
    except RuntimeError:
        pass



def _tg_export_session_string(session_base):
    """Export authorised Telethon SQLite session to an in-memory StringSession.

    Proxy playback must not keep opening/copying the same .session database.
    Kodi fires HEAD/GET/Range requests in parallel and SQLite sessions were
    causing locks or broken reconnects on Android.  A StringSession contains
    the auth key/DC only and is safe to instantiate per proxy request.
    """
    try:
        if not session_base:
            return ''
        from telethon.sessions import SQLiteSession, StringSession
        sess = SQLiteSession(session_base)
        try:
            value = StringSession.save(sess)
        finally:
            try:
                sess.close()
            except Exception:
                pass
        return value or ''
    except Exception:
        fflog_exc(1)
        return ''


def _tg_proxy_cleanup(max_age=7200):
    try:
        now = time.time()
        for key, value in list(_TG_PROXY_MAP.items()):
            if now - float(value.get('created') or 0) > max_age:
                try:
                    value['cache_stop'] = True
                    ev = value.get('_cache_event')
                    if ev:
                        ev.set()
                    worker = value.get('_range_worker')
                    if worker:
                        worker.stop()
                except Exception:
                    pass
                _TG_RANGE_WORKERS.pop(key, None)
                _TG_PROXY_MAP.pop(key, None)
        # Clean orphaned per-request Telethon session copies.
        try:
            base_dir = ''
            for value in list(_TG_PROXY_MAP.values()):
                sp = value.get('session_path') or ''
                if sp:
                    base_dir = os.path.join(os.path.dirname(sp), 'proxy_sessions')
                    break
            if base_dir and os.path.isdir(base_dir):
                for name in os.listdir(base_dir):
                    path = os.path.join(base_dir, name)
                    try:
                        if os.path.isfile(path) and now - os.path.getmtime(path) > max_age:
                            os.remove(path)
                    except Exception:
                        pass
        except Exception:
            pass
        # Clean old progressive playback cache files.
        try:
            cdir = _tg_cache_dir()
            if cdir and os.path.isdir(cdir):
                files = []
                for name in os.listdir(cdir):
                    path = os.path.join(cdir, name)
                    try:
                        if os.path.isfile(path):
                            age = now - os.path.getmtime(path)
                            size = os.path.getsize(path)
                            if age > 24 * 3600:
                                os.remove(path)
                            else:
                                files.append((os.path.getmtime(path), size, path))
                    except Exception:
                        pass
                # Keep cache under ~8 GB when possible.
                total = sum(x[1] for x in files)
                for _mtime, size, path in sorted(files):
                    if total <= 8 * 1024 ** 3:
                        break
                    try:
                        os.remove(path)
                        total -= size
                    except Exception:
                        pass
        except Exception:
            pass
    except Exception:
        pass



def _tg_proxy_prefetch_start(spec, wait_seconds=8.0, min_ready=1536 * 1024, max_bytes=0):
    """Start progressive Telegram->disk cache before Kodi opens the URL.

    Kodi probes local HTTP URLs aggressively and times out when the proxy has to
    connect to Telegram, resolve the entity and fetch the first MTProto chunks
    inside the first GET.  This prefetch starts at resolve() time, so the proxy
    can feed Kodi from a growing local file immediately.
    """
    try:
        if not spec or spec.get('_cache_started'):
            return bool(spec and spec.get('cache_path'))
        total = int(spec.get('size') or 0)
        try:
            max_bytes = int(max_bytes or spec.get('progressive_cache_max') or 0)
            if max_bytes and total:
                max_bytes = max(1024 * 1024, min(max_bytes, total))
        except Exception:
            max_bytes = 0
        if total <= 0:
            return False
        folder = _tg_cache_dir()
        token = spec.get('token') or uuid.uuid4().hex
        name = _tg_ascii_filename(spec.get('filename') or 'video.mp4')
        path = os.path.join(folder, '%s_%s' % (token[:16], name))
        spec['cache_path'] = path
        spec['cache_pos'] = 0
        spec['cache_done'] = False
        spec['cache_error'] = ''
        spec['cache_stop'] = False
        spec['cache_last_read'] = time.time()
        spec['_cache_event'] = threading.Event()
        spec['_cache_lock'] = threading.RLock()
        spec['_cache_started'] = True

        def _worker():
            client = None
            try:
                # Fresh cache for this playback token.
                try:
                    if os.path.exists(path):
                        os.remove(path)
                except Exception:
                    pass
                client = _tg_proxy_client(spec)
                if not client:
                    spec['cache_error'] = 'client unavailable'
                    return
                entity = _tg_find_entity(client, int(spec.get('chat_id') or 0), spec.get('chat_ref') or '', spec)
                if not entity:
                    spec['cache_error'] = 'entity unavailable'
                    return
                msg = client.get_messages(entity, ids=int(spec.get('message_id') or 0))
                if not msg or not getattr(msg, 'media', None):
                    spec['cache_error'] = 'media unavailable'
                    return
                fflog('[telegram-proxy] prefetch start size=%s file=%r' % (total, os.path.basename(path)), 1)
                written = 0
                with open(path, 'ab') as fh:
                    for chunk in client.iter_download(msg.media, offset=0, request_size=1024 * 1024, chunk_size=256 * 1024, file_size=total or None):
                        if spec.get('cache_stop'):
                            break
                        if not chunk:
                            continue
                        with spec.get('_cache_lock') or threading.RLock():
                            fh.write(chunk)
                            written += len(chunk)
                            spec['cache_pos'] = written
                        try:
                            spec['_cache_event'].set()
                        except Exception:
                            pass
                        # Do not keep downloading a multi-GB file forever when
                        # Kodi failed to open or the user backed out. While Kodi
                        # is reading, _tg_proxy_send_from_cache refreshes this
                        # timestamp on every served chunk.
                        try:
                            last_read = float(spec.get('cache_last_read') or spec.get('created') or time.time())
                            if written >= 4 * 1024 * 1024 and time.time() - last_read > 75:
                                spec['cache_stop'] = True
                                fflog('[telegram-proxy] prefetch idle stop bytes=%s' % written, 1)
                                break
                        except Exception:
                            pass
                        if max_bytes and written >= max_bytes:
                            try:
                                fflog('[telegram-proxy] prefetch reached soft cap bytes=%s' % written, 1)
                            except Exception:
                                pass
                            break
                        if total and written >= total:
                            break
                spec['cache_done'] = True
                fflog('[telegram-proxy] prefetch done bytes=%s' % written, 1)
            except Exception as exc:
                spec['cache_error'] = repr(exc)
                fflog_exc(1)
            finally:
                try:
                    spec['cache_done'] = bool(spec.get('cache_done')) or bool(spec.get('cache_error'))
                    ev = spec.get('_cache_event')
                    if ev:
                        ev.set()
                except Exception:
                    pass
                _tg_safe_disconnect(client)

        t = threading.Thread(target=_worker, name='KadrPlusTGPrefetch', daemon=True)
        spec['_cache_thread'] = t
        t.start()

        # Give the worker a small head start, but do not block Kodi forever.
        started = time.time()
        while time.time() - started < float(wait_seconds or 0):
            if _tg_cache_size(spec) >= int(min_ready or 0):
                return True
            if spec.get('cache_error'):
                return False
            ev = spec.get('_cache_event')
            if ev:
                ev.wait(0.25)
                try:
                    ev.clear()
                except Exception:
                    pass
            else:
                time.sleep(0.25)
        return bool(_tg_cache_size(spec) > 0)
    except Exception:
        fflog_exc(1)
        return False


def _tg_proxy_send_from_cache(handler, spec, start, end, total, wait_for_more=False):
    """Serve bytes that are already present in the growing progressive cache.

    2.41.34: never send HTTP headers and then wait for the cache to catch up for
    many seconds. Kodi/libcurl treats that as a dead stream.  The caller should
    shrink Content-Range to the currently cached bytes, call this function, flush
    them, close the response and let Kodi request the next range.

    Returns the number of bytes actually written.
    """
    sent = 0
    try:
        path = (spec or {}).get('cache_path') or ''
        if not path:
            return 0
        pos = int(start or 0)
        end = int(end if end is not None else (total - 1))
        try:
            spec['cache_last_read'] = time.time()
        except Exception:
            pass
        last_progress = time.time()
        last_cached_seen = _tg_cache_size(spec)
        while pos <= end:
            cached = _tg_cache_size(spec)
            if cached > last_cached_seen:
                last_cached_seen = cached
                last_progress = time.time()
            if cached <= pos:
                if wait_for_more and not spec.get('cache_done') and not spec.get('cache_error'):
                    # Avoid orphaned HTTP threads when Telegram stalls. Kodi may
                    # reconnect/request again, but a stuck Python thread blocks
                    # shutdown and log upload on Android.
                    if time.time() - last_progress > 35:
                        try:
                            fflog('[telegram-proxy] cache wait timeout pos=%s cached=%s sent=%s' % (pos, cached, sent), 1)
                        except Exception:
                            pass
                        break
                    ev = spec.get('_cache_event')
                    if ev:
                        ev.wait(0.25)
                        try:
                            ev.clear()
                        except Exception:
                            pass
                    else:
                        time.sleep(0.1)
                    continue
                break
            to_read = min(256 * 1024, end - pos + 1, cached - pos)
            if to_read <= 0:
                break
            try:
                with open(path, 'rb') as fh:
                    fh.seek(pos)
                    data = fh.read(to_read)
            except Exception:
                data = b''
            if not data:
                break
            try:
                handler.wfile.write(data)
                try:
                    handler.wfile.flush()
                except Exception:
                    pass
                try:
                    spec['cache_last_read'] = time.time()
                except Exception:
                    pass
            except (BrokenPipeError, ConnectionResetError):
                return sent
            n = len(data)
            pos += n
            sent += n
        return sent
    except (BrokenPipeError, ConnectionResetError):
        return sent
    except Exception:
        fflog_exc(1)
        return sent

def _tg_ascii_filename(value, default='video.mp4'):
    """Return a latin-1/HTTP-header safe filename fallback.

    BaseHTTPRequestHandler encodes headers as latin-1. Telegram filenames often
    contain Polish/German characters; sending them raw breaks playback before
    Kodi can even read the first byte. Keep the real UTF-8 filename in
    filename*=..., but use a plain ASCII fallback in filename="...".
    """
    try:
        name = os.path.basename(str(value or default).replace('\\', '/')) or default
        name = unicodedata.normalize('NFKD', name).encode('ascii', 'ignore').decode('ascii')
        name = re.sub(r'[^A-Za-z0-9._ -]+', '_', name)
        name = re.sub(r'\s+', ' ', name).strip(' ._-') or default
        if '.' not in os.path.basename(name):
            name += '.mp4'
        return name[:160]
    except Exception:
        return default


def _tg_content_disposition(filename):
    try:
        original = os.path.basename(str(filename or 'video.mp4').replace('\\', '/')) or 'video.mp4'
        fallback = _tg_ascii_filename(original)
        # RFC 5987 keeps UTF-8 name available while the whole header stays ASCII.
        return "inline; filename=\"%s\"; filename*=UTF-8''%s" % (
            fallback.replace('"', ''), quote(original.encode('utf-8'))
        )
    except Exception:
        return 'inline; filename="video.mp4"'



def _tg_document_location_from_spec(spec):
    """Build a direct Telegram file location from metadata saved with source.

    This avoids get_messages()/get_entity() on every Kodi Range request.  Kodi
    opens several ranges in parallel during demuxing, and every extra MTProto
    lookup makes the first body bytes arrive too late on Android.
    """
    try:
        spec = spec or {}
        doc_id = int(spec.get('doc_id') or 0)
        doc_hash = int(spec.get('doc_access_hash') or 0)
        ref = spec.get('doc_file_reference') or ''
        if not (doc_id and doc_hash and ref):
            return None
        try:
            ref_bytes = base64.urlsafe_b64decode((str(ref) + '=' * (-len(str(ref)) % 4)).encode('ascii'))
        except Exception:
            ref_bytes = base64.b64decode(str(ref).encode('ascii'))
        from telethon.tl.types import InputDocumentFileLocation
        return InputDocumentFileLocation(doc_id, doc_hash, ref_bytes, '')
    except Exception:
        return None


def _tg_get_message_for_download(client, spec):
    """Fallback resolver used only when direct document location is missing/expired."""
    try:
        entity = _tg_find_entity(client, int((spec or {}).get('chat_id') or 0), (spec or {}).get('chat_ref') or '', spec)
        if not entity:
            return None
        msg = client.get_messages(entity, ids=int((spec or {}).get('message_id') or 0))
        if not msg or not getattr(msg, 'media', None):
            return None
        return msg
    except Exception:
        fflog_exc(1)
        return None


def _tg_download_target(client, spec, force_message=False):
    """Return (file_like, dc_id, msg) for Telethon.iter_download."""
    try:
        if not force_message:
            loc = _tg_document_location_from_spec(spec)
            if loc:
                try:
                    dc_id = int((spec or {}).get('doc_dc_id') or 0) or None
                except Exception:
                    dc_id = None
                return loc, dc_id, None
        msg = _tg_get_message_for_download(client, spec)
        if not msg:
            return None, None, None
        return getattr(msg, 'media', None), None, msg
    except Exception:
        fflog_exc(1)
        return None, None, None


def _tg_iter_download(client, spec, offset, total, request_size=256 * 1024, force_message=False):
    """Create a Telethon download iterator for an exact byte offset."""
    file_like, dc_id, _msg = _tg_download_target(client, spec, force_message=force_message)
    if not file_like:
        return None
    kwargs = {
        'offset': int(offset or 0),
        'request_size': int(request_size or 256 * 1024),
        'chunk_size': int(request_size or 256 * 1024),
    }
    try:
        if total:
            kwargs['file_size'] = int(total)
    except Exception:
        pass
    try:
        if dc_id:
            kwargs['dc_id'] = int(dc_id)
    except Exception:
        pass
    return client.iter_download(file_like, **kwargs)



def _tg_round_1024(value, up=False):
    try:
        value = int(value or 0)
        if up:
            return ((value + 1023) // 1024) * 1024
        return (value // 1024) * 1024
    except Exception:
        return 0


def _tg_file_part_sync(client, spec, offset, want, total=0, force_message=False, timeout=9.0):
    """Fetch one small Telegram byte part through raw upload.getFile.

    This deliberately avoids Telethon.iter_download for Kodi's first bytes.
    Telegram's file API is chunked: with the precise flag offset and limit must
    be 1 KiB aligned, limit <= 1 MiB and a request may not cross a 1 MiB block.
    We align down, fetch a legal part, then slice back to the exact HTTP range.
    """
    try:
        if not client:
            return b''
        total = int(total or (spec or {}).get('size') or 0)
        offset = int(max(0, offset or 0))
        want = int(max(1, want or 0))
        if total and offset >= total:
            return b''
        if total:
            want = min(want, max(0, total - offset))
        if want <= 0:
            return b''

        file_like, dc_id, _msg = _tg_download_target(client, spec, force_message=force_message)
        if not file_like:
            return b''

        from telethon import functions, types, utils, errors
        info = utils._get_file_info(file_like)
        location = info.location
        try:
            if getattr(info, 'dc_id', None):
                dc_id = int(info.dc_id)
        except Exception:
            pass

        aligned = _tg_round_1024(offset, up=False)
        skip = offset - aligned
        # Telegram requires a single upload.getFile request to stay inside a
        # 1 MiB block. Keep the first request small so Kodi receives body bytes
        # before libcurl's open timeout.
        block_end = ((aligned // (1024 * 1024)) + 1) * (1024 * 1024)
        max_limit = max(1024, block_end - aligned)
        if total:
            max_limit = min(max_limit, max(0, total - aligned))
        limit = min(256 * 1024, max_limit)
        limit = max(1024, min(limit, _tg_round_1024(skip + want, up=True)))
        limit = min(limit, max_limit)
        limit = _tg_round_1024(limit, up=False)
        if limit <= skip:
            return b''

        async def _call_one(use_dc):
            sender = client._sender
            exported = False
            try:
                if use_dc and int(getattr(client.session, 'dc_id', 0) or 0) != int(use_dc):
                    sender = await client._borrow_exported_sender(int(use_dc))
                    exported = True
                req = functions.upload.GetFileRequest(
                    location=location,
                    offset=int(aligned),
                    limit=int(limit),
                    precise=True,
                    cdn_supported=False,
                )
                result = await asyncio.wait_for(client._call(sender, req), timeout=float(timeout or 9.0))
                if isinstance(result, types.upload.FileCdnRedirect):
                    raise RuntimeError('unexpected CDN redirect')
                return bytes(getattr(result, 'bytes', b'') or b'')
            finally:
                try:
                    if exported and sender:
                        await client._return_exported_sender(sender)
                except Exception:
                    pass

        async def _work():
            try:
                return await _call_one(dc_id)
            except errors.FileMigrateError as exc:
                return await _call_one(int(getattr(exc, 'new_dc', 0) or 0))

        loop = _tg_ensure_event_loop()
        try:
            asyncio.set_event_loop(loop)
        except Exception:
            pass
        raw = loop.run_until_complete(_work())
        if not raw:
            return b''
        return raw[skip:skip + want]
    except Exception as exc:
        try:
            fflog('[telegram-proxy] raw getFile failed offset=%s want=%s force_msg=%s err=%r' % (offset, want, force_message, exc), 1)
        except Exception:
            pass
        return b''


def _tg_fetch_part_retry(client, spec, offset, want, total=0, timeout=9.0):
    """Fetch a byte part, refreshing message/file_reference if direct document fails."""
    last = b''
    for force_message in (False, True):
        try:
            data = _tg_file_part_sync(client, spec, offset, want, total=total, force_message=force_message, timeout=timeout)
            if data:
                if force_message:
                    try:
                        fflog('[telegram-proxy] raw getFile OK via refreshed message offset=%s bytes=%s' % (offset, len(data)), 1)
                    except Exception:
                        pass
                return data
            last = data
        except Exception:
            fflog_exc(1)
    return last or b''


def _tg_fetch_range_retry(client, spec, offset, want, total=0, timeout=7.0, max_parts=16):
    """Fetch up to ``want`` bytes using Telegram upload.getFile chunks.

    upload.getFile may not cross a 1 MiB Telegram block. The older one-part
    code returned only the first legal slice, so requests such as bytes=1966080-
    yielded about 128 KiB and Kodi treated the stream as too short. This helper
    loops across Telegram block boundaries and returns one contiguous buffer.
    It is still bounded: no full-file download is attempted here.
    """
    out = []
    got = 0
    try:
        total = int(total or (spec or {}).get('size') or 0)
        pos = int(max(0, offset or 0))
        want = int(max(1, want or 0))
        if total:
            want = min(want, max(0, total - pos))
        if want <= 0:
            return b''
        parts = 0
        while got < want and parts < int(max_parts or 1):
            need = want - got
            # Ask for at most 1 MiB, but _tg_file_part_sync will shrink further
            # if the current offset is near a 1 MiB block boundary.
            ask = min(1024 * 1024, need)
            data = _tg_fetch_part_retry(client, spec, pos, ask, total=total, timeout=timeout)
            if not data:
                break
            out.append(data)
            n = len(data)
            got += n
            pos += n
            parts += 1
            if total and pos >= total:
                break
            if n <= 0:
                break
        return b''.join(out)
    except Exception:
        fflog_exc(1)
        try:
            return b''.join(out)
        except Exception:
            return b''


def _tg_parallel_prefix_to_cache(spec, path, total, prefix_bytes=2 * 1024 * 1024, chunk_size=512 * 1024, workers=2, deadline_seconds=18.0):
    """Download the first few MiB through a tiny FastTelethon-style fan-out.

    Telethon's own FAQ says file transfer is single-connection and not parallel.
    Kodi, however, needs the startup bytes quickly.  This helper uses 2-3 short
    lived MTProto clients from the exported StringSession to fetch consecutive
    upload.getFile blocks in parallel, then writes only contiguous bytes to the
    cache file.  It stops at a small prefix; the normal worker continues
    progressively afterwards.
    """
    try:
        spec = spec or {}
        total = int(total or spec.get('size') or 0)
        if total <= 0 or not path:
            return 0
        prefix_bytes = int(max(256 * 1024, min(prefix_bytes or 0, total, 8 * 1024 * 1024)))
        chunk_size = int(max(128 * 1024, min(chunk_size or 0, 1024 * 1024)))
        workers = int(max(1, min(workers or 1, 3)))
        offsets = list(range(0, prefix_bytes, chunk_size))
        if not offsets:
            return 0
        q = queue.Queue()
        for off in offsets:
            q.put(off)
        results = {}
        errors = []
        lock = threading.RLock()
        stop = threading.Event()
        deadline = time.time() + float(deadline_seconds or 0)

        def _fetcher(idx):
            client = None
            try:
                client = _tg_proxy_client(spec)
                if not client:
                    with lock:
                        errors.append('client unavailable')
                    return
                while not stop.is_set() and time.time() < deadline:
                    try:
                        off = q.get_nowait()
                    except queue.Empty:
                        return
                    want = min(chunk_size, max(0, total - off), max(0, prefix_bytes - off))
                    data = _tg_fetch_range_retry(client, spec, off, want, total=total, timeout=7.0, max_parts=8)
                    with lock:
                        results[off] = data or b''
                    ev = spec.get('_cache_event')
                    if ev:
                        ev.set()
            except Exception as exc:
                with lock:
                    errors.append(repr(exc))
                fflog_exc(1)
            finally:
                _tg_safe_disconnect(client)

        threads = [threading.Thread(target=_fetcher, args=(i,), name='KadrPlusTGPrefix%d' % i, daemon=True) for i in range(workers)]
        for t in threads:
            t.start()

        written = 0
        next_off = 0
        last_report = 0
        with open(path, 'ab') as fh:
            while next_off < prefix_bytes and time.time() < deadline and not stop.is_set():
                with lock:
                    have = results.pop(next_off, None) if next_off in results else None
                if have is None:
                    ev = spec.get('_cache_event')
                    if ev:
                        ev.wait(0.15)
                        try:
                            ev.clear()
                        except Exception:
                            pass
                    else:
                        time.sleep(0.05)
                    continue
                if not have:
                    # Cannot build a contiguous prefix past this point.
                    break
                fh.write(have)
                written += len(have)
                next_off += len(have)
                spec['cache_pos'] = written
                try:
                    fh.flush()
                except Exception:
                    pass
                ev = spec.get('_cache_event')
                if ev:
                    ev.set()
                if written - last_report >= 512 * 1024:
                    last_report = written
                    try:
                        fflog('[telegram-proxy] parallel prefix cached=%s/%s' % (written, prefix_bytes), 1)
                    except Exception:
                        pass
                if len(have) < chunk_size:
                    break
        stop.set()
        for t in threads:
            try:
                t.join(0.2)
            except Exception:
                pass
        if written:
            try:
                fflog('[telegram-proxy] parallel prefix done bytes=%s target=%s workers=%s errors=%s' % (written, prefix_bytes, workers, len(errors)), 1)
            except Exception:
                pass
        return written
    except Exception:
        fflog_exc(1)
        return 0






def _tg_proxy_raw_cache_start(spec, wait_seconds=64.0, min_ready=6 * 1024 * 1024, max_bytes=0):
    """Start one fast Telegram->disk progressive cache.

    2.41.37 architecture:
    - one Telethon client owns the download for this playback token;
    - it uses Telethon's direct downloader/iter_download so an exported DC sender
      is borrowed once and reused for all chunks;
    - no fsync on every 256 KiB chunk. On Android that made the buffer grow at
      only a few KB/s and Kodi timed out while waiting for the 0-4 MiB probe;
    - Kodi receives the URL only after enough startup bytes are ready for its
      first demuxer probes. This is buffering, not full pre-download.
    """
    try:
        if not spec or spec.get('_raw_cache_started'):
            return bool(spec and spec.get('cache_path'))
        total = int(spec.get('size') or 0)
        if total <= 0:
            return False
        try:
            max_bytes = int(max_bytes or spec.get('progressive_cache_max') or 0)
            if max_bytes and total:
                max_bytes = max(8 * 1024 * 1024, min(max_bytes, total))
        except Exception:
            max_bytes = 0
        folder = _tg_cache_dir()
        token = spec.get('token') or uuid.uuid4().hex
        name = _tg_ascii_filename(spec.get('filename') or 'video.mp4')
        path = os.path.join(folder, '%s_stream_%s' % (token[:16], name))
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass
        spec['cache_path'] = path
        spec['cache_pos'] = 0
        spec['cache_done'] = False
        spec['cache_error'] = ''
        spec['cache_stop'] = False
        spec['cache_last_read'] = time.time()
        spec['_cache_event'] = threading.Event()
        spec['_cache_lock'] = threading.RLock()
        spec['_raw_cache_started'] = True

        def _worker():
            client = None
            written = 0
            try:
                client = _tg_proxy_client(spec)
                if not client:
                    spec['cache_error'] = 'client unavailable'
                    return
                fflog('[telegram-proxy] fast cache start size=%s max=%s file=%r' % (total, max_bytes or 0, os.path.basename(path)), 1)

                # First build a small contiguous prefix using 2-3 bounded
                # getFile workers. This avoids the 70 s wait seen in the log
                # where a single iterator produced only ~1 MiB too late.
                try:
                    written = _tg_parallel_prefix_to_cache(spec, path, total, prefix_bytes=2 * 1024 * 1024, chunk_size=512 * 1024, workers=2, deadline_seconds=16.0)
                except Exception:
                    fflog_exc(1)
                    written = int(spec.get('cache_pos') or 0)

                # 2.41.38: do not use a long Telethon.iter_download iterator for
                # the startup cache. On Android/Kodi it could sit for tens of
                # seconds before giving enough data. Use bounded upload.getFile
                # calls instead: every request has its own short timeout, and the
                # worker can reconnect/resume at the exact written offset.
                last_flush = 0
                empty_rounds = 0
                with open(path, 'ab') as fh:
                    while not spec.get('cache_stop'):
                        if max_bytes and written >= max_bytes:
                            fflog('[telegram-proxy] fast cache soft cap bytes=%s' % written, 1)
                            break
                        if total and written >= total:
                            break
                        want = 512 * 1024
                        if max_bytes:
                            want = min(want, max(0, max_bytes - written))
                        if total:
                            want = min(want, max(0, total - written))
                        if want <= 0:
                            break
                        data = _tg_fetch_range_retry(client, spec, written, want, total=total, timeout=7.0, max_parts=4)
                        if not data:
                            empty_rounds += 1
                            if empty_rounds == 1:
                                # Recreate the MTProto connection once, but do
                                # not keep a dead downloader alive forever.
                                _tg_safe_disconnect(client)
                                client = _tg_proxy_client(spec)
                                if not client:
                                    spec['cache_error'] = 'client unavailable after reconnect'
                                    break
                                continue
                            if empty_rounds >= 3:
                                spec['cache_error'] = 'raw getFile returned no bytes at %s' % written
                                break
                            time.sleep(0.25)
                            continue
                        empty_rounds = 0
                        with spec.get('_cache_lock') or threading.RLock():
                            fh.write(data)
                            written += len(data)
                            spec['cache_pos'] = written
                            if written - last_flush >= 128 * 1024:
                                try:
                                    fh.flush()
                                except Exception:
                                    pass
                                last_flush = written
                        ev = spec.get('_cache_event')
                        if ev:
                            ev.set()
                        try:
                            last_read = float(spec.get('cache_last_read') or spec.get('created') or time.time())
                            # Stop quickly after failed opens, but keep going
                            # during playback where cache_last_read is refreshed.
                            if written >= max(2 * 1024 * 1024, int(min_ready or 0)) and time.time() - last_read > 45:
                                spec['cache_stop'] = True
                                fflog('[telegram-proxy] fast cache idle stop bytes=%s' % written, 1)
                                break
                        except Exception:
                            pass
                    try:
                        fh.flush()
                    except Exception:
                        pass
                spec['cache_done'] = bool(total and written >= total) or bool(max_bytes and written >= max_bytes) or bool(spec.get('cache_stop'))
                fflog('[telegram-proxy] fast cache done bytes=%s done=%s err=%r' % (written, spec.get('cache_done'), spec.get('cache_error') or ''), 1)
            except Exception as exc:
                spec['cache_error'] = repr(exc)
                fflog('[telegram-proxy] fast cache failed bytes=%s err=%r' % (written, exc), 1)
                fflog_exc(1)
            finally:
                try:
                    ev = spec.get('_cache_event')
                    if ev:
                        ev.set()
                except Exception:
                    pass
                _tg_safe_disconnect(client)

        t = threading.Thread(target=_worker, name='KadrPlusTGFastCache', daemon=True)
        spec['_cache_thread'] = t
        t.start()

        started = time.time()
        # Wait for a real demuxer startup buffer. Kodi's first opening pattern
        # in the failing logs was bytes=0-2097151 and bytes=1966080-4063231,
        # so 6 MiB is a practical minimum that avoids immediate live fallback.
        while time.time() - started < float(wait_seconds or 0):
            cached = _tg_cache_size(spec)
            if cached >= int(min_ready or 0):
                fflog('[telegram-proxy] fast cache ready cached=%s wait=%.2fs' % (cached, time.time() - started), 1)
                return True
            if spec.get('cache_error') and cached <= 0:
                fflog('[telegram-proxy] fast cache startup error=%r' % (spec.get('cache_error'),), 1)
                return False
            ev = spec.get('_cache_event')
            if ev:
                ev.wait(0.25)
                try:
                    ev.clear()
                except Exception:
                    pass
            else:
                time.sleep(0.25)
        cached = _tg_cache_size(spec)
        fflog('[telegram-proxy] fast cache wait timeout cached=%s min=%s' % (cached, int(min_ready or 0)), 1)
        # Do not block playItem for a minute. If we have at least a small
        # contiguous head, hand Kodi the URL and let the growing cache feed it.
        return bool(cached >= 256 * 1024)
    except Exception:
        fflog_exc(1)
        return False


def _tg_proxy_wait_cache(spec, pos, timeout=12.0):
    """Wait until the progressive cache contains byte position pos."""
    try:
        deadline = time.time() + float(timeout or 0)
        while time.time() < deadline:
            if _tg_cache_size(spec) > int(pos or 0):
                return True
            if spec.get('cache_done') or spec.get('cache_error'):
                return False
            ev = spec.get('_cache_event')
            if ev:
                ev.wait(0.25)
                try:
                    ev.clear()
                except Exception:
                    pass
            else:
                time.sleep(0.1)
        return _tg_cache_size(spec) > int(pos or 0)
    except Exception:
        return False

def _tg_proxy_stream_one_part_response(handler, spec, start, end, total, mime, filename, partial):
    """Serve one truthful Telegram byte part and close the HTTP response.

    Kodi/libcurl times out when we declare a multi-MB Content-Length and MTProto
    stalls before that whole window is delivered.  For Telegram playback we must
    be conservative: fetch one small getFile part first, then return a 206 whose
    Content-Range/Content-Length exactly match the bytes we actually have.  Kodi
    can then ask for the next byte range, while no proxy thread remains stuck
    waiting for the rest of a large declared response.
    """
    client = None
    try:
        total = int(total or (spec or {}).get('size') or 0)
        start = int(max(0, start or 0))
        end = int(end if end is not None else (total - 1 if total else start))
        if total and start >= total:
            handler.send_error(416, 'Requested Range Not Satisfiable')
            return False
        if end < start:
            end = start
        # Keep the first response deliberately small.  The previous 2 MB window
        # caused Kodi to wait for bytes that Telegram had not delivered yet.
        max_chunk = 1024 * 1024
        try:
            if total and start >= max(0, total - 16 * 1024 * 1024):
                # Tail probes are sparse but important for MP4/MKV indexes.
                max_chunk = 1024 * 1024
        except Exception:
            pass
        want = min(max_chunk, max(1, end - start + 1))
        client = _tg_proxy_client(spec)
        if not client:
            handler.send_error(502, 'Telegram client unavailable')
            return False
        data = _tg_fetch_range_retry(client, spec, start, want, total=total, timeout=7.0, max_parts=8)
        if not data:
            try:
                fflog('[telegram-proxy] one-part empty start=%s want=%s total=%s' % (start, want, total), 1)
            except Exception:
                pass
            handler.send_error(504, 'Telegram did not return bytes')
            return False
        real_end = start + len(data) - 1
        # Always be truthful and partial for Telegram.  Even for a non-Range GET,
        # returning the whole file size would make Kodi wait for a long MTProto
        # stream inside one HTTP response and block the UI on failure.
        _tg_proxy_write_headers(handler, 206, mime, filename, total, start, real_end, True)
        handler.wfile.write(data)
        try:
            handler.wfile.flush()
        except Exception:
            pass
        try:
            fflog('[telegram-proxy] one-part sent start=%s end=%s bytes=%s requested_end=%s' % (start, real_end, len(data), end), 1)
        except Exception:
            pass
        return True
    except (BrokenPipeError, ConnectionResetError):
        return True
    except Exception:
        fflog_exc(1)
        try:
            handler.send_error(502, 'Telegram one-part stream error')
        except Exception:
            pass
        return False
    finally:
        _tg_safe_disconnect(client)

def _tg_probe_edges(spec, head_bytes=256 * 1024, tail_bytes=0, timeout_each=10.0):
    """Warm tiny edge chunks only; this is not full-file downloading.

    Kodi's first HTTP open fails if the local proxy accepts the connection but
    waits too long before body bytes. A 256 KiB head probe lets the first
    response start immediately, while the rest keeps streaming on demand.
    """
    client = None
    try:
        total = int((spec or {}).get('size') or 0)
        if total <= 0:
            return False
        client = _tg_proxy_client(spec)
        if not client:
            return False
        head_target = int(max(64 * 1024, min(int(head_bytes or 0), 512 * 1024, total)))
        started = time.time()
        head = _tg_fetch_part_retry(client, spec, 0, head_target, total=total, timeout=timeout_each)
        if head:
            spec['edge_head'] = head
            spec['edge_head_len'] = len(head)
            fflog('[telegram-proxy] edge head ready bytes=%s dt=%.2fs' % (len(head), time.time() - started), 1)
        else:
            spec['edge_head_error'] = 'no bytes'
            fflog('[telegram-proxy] edge head failed dt=%.2fs' % (time.time() - started), 1)

        # Keep tail probing disabled by default. It can be enabled later if logs
        # show MP4 moov-tail is the only remaining issue. The worker can fetch
        # arbitrary tail ranges on demand with the same raw getFile primitive.
        if tail_bytes and total > 2 * 1024 * 1024:
            tail_start = max(0, total - int(tail_bytes))
            tail = _tg_fetch_part_retry(client, spec, tail_start, min(int(tail_bytes), total - tail_start), total=total, timeout=timeout_each)
            if tail:
                spec['edge_tail_start'] = tail_start
                spec['edge_tail'] = tail
                spec['edge_tail_len'] = len(tail)
                fflog('[telegram-proxy] edge tail ready start=%s bytes=%s' % (tail_start, len(tail)), 1)
        return bool(spec.get('edge_head'))
    except Exception:
        fflog_exc(1)
        return False
    finally:
        _tg_safe_disconnect(client)


def _tg_edge_slice(spec, start, end):
    try:
        start = int(start or 0)
        end = int(end if end is not None else start)
        if end < start:
            return b''
        head = (spec or {}).get('edge_head') or b''
        if head and start < len(head):
            return bytes(head[start:min(end + 1, len(head))])
        tail = (spec or {}).get('edge_tail') or b''
        tail_start = int((spec or {}).get('edge_tail_start') or 0)
        if tail and start >= tail_start and start < tail_start + len(tail):
            off = start - tail_start
            return bytes(tail[off:min(len(tail), off + (end - start + 1))])
    except Exception:
        pass
    return b''

def _tg_head_prefetch_start(spec, wait_seconds=7.0, min_ready=192 * 1024, max_bytes=3 * 1024 * 1024):
    """Warm only the beginning of the Telegram file for Kodi.

    Kodi's curl input times out if the first GET to 127.0.0.1 does not receive
    bytes quickly. 2.41.24 tried a full progressive cache and could download
    multi-GB files in the background. This function deliberately caches only a
    tiny head segment, then the proxy continues normal Range streaming.
    """
    try:
        if not spec or spec.get('_head_started'):
            return bool(spec and int(spec.get('head_cache_pos') or 0) > 0)
        total = int(spec.get('size') or 0)
        if total <= 0:
            return False
        token = spec.get('token') or uuid.uuid4().hex
        folder = _tg_cache_dir()
        path = os.path.join(folder, '%s.head' % token[:24])
        spec['head_cache_path'] = path
        spec['head_cache_pos'] = 0
        spec['head_cache_done'] = False
        spec['head_cache_error'] = ''
        spec['_head_event'] = threading.Event()
        spec['_head_lock'] = threading.RLock()
        spec['_head_started'] = True
        max_bytes = int(max(256 * 1024, min(int(max_bytes or 0), total, 8 * 1024 * 1024)))
        spec['head_cache_max'] = max_bytes

        def _worker():
            client = None
            written = 0
            try:
                try:
                    if os.path.exists(path):
                        os.remove(path)
                except Exception:
                    pass
                client = _tg_proxy_client(spec)
                if not client:
                    spec['head_cache_error'] = 'client unavailable'
                    return
                entity = _tg_find_entity(client, int(spec.get('chat_id') or 0), spec.get('chat_ref') or '', spec)
                if not entity:
                    spec['head_cache_error'] = 'entity unavailable'
                    return
                msg = client.get_messages(entity, ids=int(spec.get('message_id') or 0))
                if not msg or not getattr(msg, 'media', None):
                    spec['head_cache_error'] = 'media unavailable'
                    return
                fflog('[telegram-proxy] head prefetch start max=%s file=%r' % (max_bytes, spec.get('filename') or ''), 1)
                remaining = max_bytes
                with open(path, 'wb') as fh:
                    for chunk in client.iter_download(msg.media, offset=0, request_size=64 * 1024, chunk_size=64 * 1024, file_size=total or None):
                        if not chunk or remaining <= 0:
                            break
                        if len(chunk) > remaining:
                            chunk = chunk[:remaining]
                        fh.write(chunk)
                        written += len(chunk)
                        remaining -= len(chunk)
                        with spec.get('_head_lock') or threading.RLock():
                            spec['head_cache_pos'] = written
                        try:
                            spec['_head_event'].set()
                        except Exception:
                            pass
                        if written >= max_bytes:
                            break
                spec['head_cache_done'] = True
                fflog('[telegram-proxy] head prefetch done bytes=%s' % written, 1)
            except Exception as exc:
                spec['head_cache_error'] = repr(exc)
                fflog_exc(1)
            finally:
                try:
                    spec['head_cache_done'] = True
                    ev = spec.get('_head_event')
                    if ev:
                        ev.set()
                except Exception:
                    pass
                _tg_safe_disconnect(client)

        t = threading.Thread(target=_worker, name='KadrPlusTGHeadPrefetch', daemon=True)
        spec['_head_thread'] = t
        t.start()

        started = time.time()
        while time.time() - started < float(wait_seconds or 0):
            if int(spec.get('head_cache_pos') or 0) >= int(min_ready or 0):
                return True
            if spec.get('head_cache_error'):
                return False
            ev = spec.get('_head_event')
            if ev:
                ev.wait(0.20)
                try:
                    ev.clear()
                except Exception:
                    pass
            else:
                time.sleep(0.20)
        return int(spec.get('head_cache_pos') or 0) > 0
    except Exception:
        fflog_exc(1)
        return False


def _tg_proxy_write_headers(handler, status, mime, filename, total, start, end, partial):
    length = (int(end) - int(start) + 1) if total else 0
    handler.send_response(status)
    handler.send_header('Content-Type', mime or 'video/mp4')
    handler.send_header('Accept-Ranges', 'bytes')
    handler.send_header('Content-Disposition', _tg_content_disposition(filename or 'video.mp4'))
    # Help Kodi/libcurl keep a local HTTP stream open long enough for MTProto.
    handler.send_header('Cache-Control', 'no-cache')
    if total:
        if partial:
            handler.send_header('Content-Range', 'bytes %d-%d/%d' % (int(start), int(end), int(total)))
        handler.send_header('Content-Length', str(length))
    handler.send_header('Connection', 'close')
    handler.end_headers()
    try:
        handler.wfile.flush()
    except Exception:
        pass


def _tg_proxy_send_head_cache(handler, spec, start, end):
    """Write available cached head bytes for a requested range and return bytes sent."""
    try:
        path = (spec or {}).get('head_cache_path') or ''
        cached = int((spec or {}).get('head_cache_pos') or 0)
        if not path or not os.path.exists(path) or cached <= int(start or 0):
            return 0
        pos = int(start or 0)
        limit = min(int(end) + 1, cached)
        sent = 0
        with open(path, 'rb') as fh:
            fh.seek(pos)
            while pos < limit:
                data = fh.read(min(128 * 1024, limit - pos))
                if not data:
                    break
                handler.wfile.write(data)
                try:
                    handler.wfile.flush()
                except Exception:
                    pass
                pos += len(data)
                sent += len(data)
        return sent
    except (BrokenPipeError, ConnectionResetError):
        return max(1, int(locals().get('sent', 0)))
    except Exception:
        fflog_exc(1)
        return 0



def _tg_tail_prefetch_start(spec, wait_seconds=0.0, min_ready=0, max_bytes=8 * 1024 * 1024):
    """Warm the last bytes of the Telegram file for Kodi's MP4/MKV tail probe.

    Kodi/libcurl often opens a local HTTP file, reads the head, and then asks for
    a Range close to EOF to inspect the container index.  Telegram MTProto may
    take longer than Kodi's ~20 s read timeout to connect and seek to that
    position, so playback dies although the source is valid.  Keep only a small
    tail cache, not the whole movie.
    """
    try:
        if not spec or spec.get('_tail_started'):
            return bool(spec and spec.get('tail_cache_path'))
        total = int(spec.get('size') or 0)
        if total <= 0:
            return False
        max_bytes = int(max(256 * 1024, min(int(max_bytes or 0), total, 16 * 1024 * 1024)))
        # Telegram's getFile offsets are happiest on 4 KiB boundaries.
        tail_start = max(0, total - max_bytes)
        tail_start -= tail_start % 4096
        folder = _tg_cache_dir()
        token = spec.get('token') or uuid.uuid4().hex
        name = _tg_ascii_filename(spec.get('filename') or 'video.mp4')
        path = os.path.join(folder, '%s_tail_%s' % (token[:16], name))
        spec['tail_cache_path'] = path
        spec['tail_cache_start'] = tail_start
        spec['tail_cache_pos'] = 0
        spec['tail_cache_done'] = False
        spec['tail_cache_error'] = ''
        spec['_tail_event'] = threading.Event()
        spec['_tail_lock'] = threading.RLock()
        spec['_tail_started'] = True

        def _worker():
            client = None
            written = 0
            try:
                try:
                    if os.path.exists(path):
                        os.remove(path)
                except Exception:
                    pass
                client = _tg_proxy_client(spec)
                if not client:
                    spec['tail_cache_error'] = 'client unavailable'
                    return
                entity = _tg_find_entity(client, int(spec.get('chat_id') or 0), spec.get('chat_ref') or '', spec)
                if not entity:
                    spec['tail_cache_error'] = 'entity unavailable'
                    return
                msg = client.get_messages(entity, ids=int(spec.get('message_id') or 0))
                if not msg or not getattr(msg, 'media', None):
                    spec['tail_cache_error'] = 'media unavailable'
                    return
                fflog('[telegram-proxy] tail prefetch start offset=%s max=%s file=%r' % (tail_start, max_bytes, spec.get('filename') or ''), 1)
                remaining = total - tail_start
                with open(path, 'wb') as fh:
                    for chunk in client.iter_download(msg.media, offset=tail_start, request_size=512 * 1024, chunk_size=256 * 1024, file_size=total or None):
                        if not chunk or remaining <= 0:
                            break
                        if len(chunk) > remaining:
                            chunk = chunk[:remaining]
                        fh.write(chunk)
                        written += len(chunk)
                        remaining -= len(chunk)
                        with spec.get('_tail_lock') or threading.RLock():
                            spec['tail_cache_pos'] = written
                        ev = spec.get('_tail_event')
                        if ev:
                            ev.set()
                        if remaining <= 0:
                            break
                spec['tail_cache_done'] = True
                fflog('[telegram-proxy] tail prefetch done bytes=%s' % written, 1)
            except Exception as exc:
                spec['tail_cache_error'] = repr(exc)
                fflog_exc(1)
            finally:
                try:
                    spec['tail_cache_done'] = True
                    ev = spec.get('_tail_event')
                    if ev:
                        ev.set()
                except Exception:
                    pass
                _tg_safe_disconnect(client)

        t = threading.Thread(target=_worker, name='KadrPlusTGTailPrefetch', daemon=True)
        spec['_tail_thread'] = t
        t.start()

        started = time.time()
        while time.time() - started < float(wait_seconds or 0):
            if int(spec.get('tail_cache_pos') or 0) >= int(min_ready or 0):
                return True
            if spec.get('tail_cache_error'):
                return False
            ev = spec.get('_tail_event')
            if ev:
                ev.wait(0.20)
                try:
                    ev.clear()
                except Exception:
                    pass
            else:
                time.sleep(0.20)
        return int(spec.get('tail_cache_pos') or 0) > 0
    except Exception:
        fflog_exc(1)
        return False



def _tg_tail_cache_ready(spec, start, end, wait_seconds=0.0):
    """Return True only when the requested tail range is fully cached.

    This deliberately checks *before* sending HTTP headers.  If Kodi receives a
    206 response with a large Content-Length and the proxy then waits on MTProto,
    libcurl times out and Kodi can keep Python request threads alive.  For MP4
    open probes the tail range must be served immediately from disk or fail
    quickly and cleanly.
    """
    try:
        spec = spec or {}
        path = spec.get('tail_cache_path') or ''
        tail_start = int(spec.get('tail_cache_start') or 0)
        if not path or int(start or 0) < tail_start:
            return False
        need_until = int(end) - tail_start + 1
        deadline = time.time() + float(wait_seconds or 0)
        while int(spec.get('tail_cache_pos') or 0) < need_until and not spec.get('tail_cache_done'):
            if time.time() >= deadline:
                break
            ev = spec.get('_tail_event')
            if ev:
                ev.wait(0.10)
                try:
                    ev.clear()
                except Exception:
                    pass
            else:
                time.sleep(0.10)
        cached = int(spec.get('tail_cache_pos') or 0)
        return bool(path and os.path.exists(path) and cached >= need_until)
    except Exception:
        return False

def _tg_proxy_send_tail_cache(handler, spec, start, end, wait_seconds=10.0):
    """Write cached tail bytes for a requested range and return bytes sent."""
    try:
        path = (spec or {}).get('tail_cache_path') or ''
        tail_start = int((spec or {}).get('tail_cache_start') or 0)
        if not path or int(start or 0) < tail_start:
            return 0
        need_until = int(end) - tail_start + 1
        deadline = time.time() + float(wait_seconds or 0)
        while int((spec or {}).get('tail_cache_pos') or 0) < need_until and not (spec or {}).get('tail_cache_done'):
            if time.time() >= deadline:
                break
            ev = (spec or {}).get('_tail_event')
            if ev:
                ev.wait(0.20)
                try:
                    ev.clear()
                except Exception:
                    pass
            else:
                time.sleep(0.20)
        cached = int((spec or {}).get('tail_cache_pos') or 0)
        if not os.path.exists(path) or cached <= int(start or 0) - tail_start:
            return 0
        pos = int(start or 0)
        limit = min(int(end) + 1, tail_start + cached)
        sent = 0
        with open(path, 'rb') as fh:
            fh.seek(pos - tail_start)
            while pos < limit:
                data = fh.read(min(128 * 1024, limit - pos))
                if not data:
                    break
                handler.wfile.write(data)
                pos += len(data)
                sent += len(data)
        return sent
    except (BrokenPipeError, ConnectionResetError):
        return max(1, int(locals().get('sent', 0)))
    except Exception:
        fflog_exc(1)
        return 0



def _tg_edge_prefetch_sync(spec, head_bytes=512 * 1024, tail_bytes=8 * 1024 * 1024, timeout=16.0):
    """Synchronously warm head and tail caches before Kodi opens the URL.

    Previous builds started background Telethon threads. On Kodi/Android those
    threads can outlive the plugin invocation and block GUI operations when
    MTProto stalls.  This version uses one temporary Telethon client, downloads
    a small head segment and a tail segment that reaches EOF, then disconnects.
    The local HTTP proxy can then answer Kodi's startup range probes without
    opening extra Telegram connections.
    """
    client = None
    try:
        spec = spec or {}
        total = int(spec.get('size') or 0)
        if total <= 0:
            return False
        deadline = time.time() + float(timeout or 0)
        folder = _tg_cache_dir()
        token = spec.get('token') or uuid.uuid4().hex
        safe_name = _tg_ascii_filename(spec.get('filename') or 'video.mp4')

        head_bytes = int(max(128 * 1024, min(int(head_bytes or 0), total, 2 * 1024 * 1024)))
        tail_bytes = int(max(1024 * 1024, min(int(tail_bytes or 0), total, 16 * 1024 * 1024)))
        tail_start = max(0, total - tail_bytes)
        # Align down for Telegram getFile, but extend target length to EOF.
        tail_start -= tail_start % 4096
        tail_target = total - tail_start

        head_path = os.path.join(folder, '%s.head' % token[:24])
        tail_path = os.path.join(folder, '%s_tail_%s' % (token[:16], safe_name))
        for path in (head_path, tail_path):
            try:
                if os.path.exists(path):
                    os.remove(path)
            except Exception:
                pass

        spec['head_cache_path'] = head_path
        spec['head_cache_pos'] = 0
        spec['head_cache_done'] = False
        spec['head_cache_error'] = ''
        spec['_head_event'] = threading.Event()
        spec['_head_lock'] = threading.RLock()
        spec['_head_started'] = True
        spec['head_cache_max'] = head_bytes

        spec['tail_cache_path'] = tail_path
        spec['tail_cache_start'] = tail_start
        spec['tail_cache_pos'] = 0
        spec['tail_cache_done'] = False
        spec['tail_cache_error'] = ''
        spec['_tail_event'] = threading.Event()
        spec['_tail_lock'] = threading.RLock()
        spec['_tail_started'] = True

        client = _tg_proxy_client(spec)
        if not client:
            spec['head_cache_error'] = 'client unavailable'
            spec['tail_cache_error'] = 'client unavailable'
            return False
        entity = _tg_find_entity(client, int(spec.get('chat_id') or 0), spec.get('chat_ref') or '', spec)
        if not entity:
            spec['head_cache_error'] = 'entity unavailable'
            spec['tail_cache_error'] = 'entity unavailable'
            return False
        msg = client.get_messages(entity, ids=int(spec.get('message_id') or 0))
        if not msg or not getattr(msg, 'media', None):
            spec['head_cache_error'] = 'media unavailable'
            spec['tail_cache_error'] = 'media unavailable'
            return False

        def fetch_segment(label, path, offset, target, pos_key, done_key, event_key, error_key):
            written = 0
            try:
                fflog('[telegram-proxy] edge %s prefetch start offset=%s bytes=%s file=%r' % (label, offset, target, spec.get('filename') or ''), 1)
                with open(path, 'wb') as fh:
                    for chunk in client.iter_download(msg.media, offset=int(offset or 0), request_size=128 * 1024, chunk_size=64 * 1024, file_size=total or None):
                        if time.time() >= deadline:
                            spec[error_key] = 'timeout after %s bytes' % written
                            break
                        if not chunk:
                            continue
                        if written + len(chunk) > target:
                            chunk = chunk[:max(0, target - written)]
                        if not chunk:
                            break
                        fh.write(chunk)
                        written += len(chunk)
                        spec[pos_key] = written
                        ev = spec.get(event_key)
                        if ev:
                            ev.set()
                        if written >= target:
                            break
                spec[done_key] = True
                fflog('[telegram-proxy] edge %s prefetch done bytes=%s target=%s' % (label, written, target), 1)
            except Exception as exc:
                spec[error_key] = repr(exc)
                spec[done_key] = True
                fflog('[telegram-proxy] edge %s prefetch failed bytes=%s err=%r' % (label, written, exc), 1)
                fflog_exc(1)
            finally:
                ev = spec.get(event_key)
                if ev:
                    ev.set()
            return written

        head_written = fetch_segment('head', head_path, 0, head_bytes, 'head_cache_pos', 'head_cache_done', '_head_event', 'head_cache_error')
        tail_written = 0
        if time.time() < deadline:
            tail_written = fetch_segment('tail', tail_path, tail_start, tail_target, 'tail_cache_pos', 'tail_cache_done', '_tail_event', 'tail_cache_error')
        else:
            spec['tail_cache_error'] = 'timeout before tail'
            spec['tail_cache_done'] = True
        ok = bool(head_written > 0 and tail_written >= tail_target)
        fflog('[telegram-proxy] edge prefetch summary head=%s/%s tail=%s/%s ok=%s' % (head_written, head_bytes, tail_written, tail_target, ok), 1)
        return ok
    except Exception:
        fflog_exc(1)
        return False
    finally:
        try:
            spec['head_cache_done'] = True
            spec['tail_cache_done'] = True
            ev = spec.get('_head_event') if spec else None
            if ev:
                ev.set()
            ev = spec.get('_tail_event') if spec else None
            if ev:
                ev.set()
        except Exception:
            pass
        _tg_safe_disconnect(client)

def _tg_proxy_stream_direct_body(handler, spec, start, end, total):
    """Continue an already-open HTTP response with Telegram bytes.

    The source token stores the document file location, so this function can
    stream a requested range without resolving the chat/message for every Kodi
    read.  If Telegram says the file_reference is stale, we retry once through
    get_messages() and then continue streaming.
    """
    try:
        start = int(start or 0)
        end = int(end if end is not None else (int(total or 0) - 1))
        if total and start > end:
            return True
        pos = start
        remaining = (end - start + 1) if total else None
        sent_total = 0
        # First use direct InputDocumentFileLocation; fallback to message refresh.
        for attempt, force_message in enumerate((False, True, True), start=1):
            client = None
            try:
                client = _tg_proxy_client(spec)
                if not client:
                    return sent_total > 0
                iterator = _tg_iter_download(client, spec, pos, total, request_size=256 * 1024, force_message=force_message)
                if iterator is None:
                    return sent_total > 0
                fflog('[telegram-proxy] body stream range=%s-%s/%s attempt=%s mode=%s' % (
                    pos, end, total, attempt, 'msg' if force_message else 'doc'), 1)
                for chunk in iterator:
                    if not chunk:
                        continue
                    if remaining is not None:
                        if remaining <= 0:
                            break
                        if len(chunk) > remaining:
                            chunk = chunk[:remaining]
                    handler.wfile.write(chunk)
                    try:
                        handler.wfile.flush()
                    except Exception:
                        pass
                    n = len(chunk)
                    pos += n
                    sent_total += n
                    if remaining is not None:
                        remaining -= n
                        if remaining <= 0:
                            return True
                return True
            except (BrokenPipeError, ConnectionResetError):
                return True
            except Exception as exc:
                fflog('[telegram-proxy] body stream failed attempt=%s sent=%s err=%r' % (attempt, sent_total, exc), 1)
                if sent_total > 0:
                    fflog_exc(1)
                    return True
                time.sleep(0.25)
            finally:
                _tg_safe_disconnect(client)
        return sent_total > 0
    except Exception:
        fflog_exc(1)
        return False


def _tg_proxy_stream_range_response(handler, spec, start, end, total, mime, filename, partial):
    """Open Telegram first, get the first chunk, then send HTTP headers.

    Kodi/libcurl is much happier when a 206 response is followed immediately by
    body bytes.  Older builds sent headers first and then waited on MTProto; the
    result was timeout(28), failed demuxing, or a deliberate 503 for tail probes.
    """
    start = int(start or 0)
    end = int(end if end is not None else (int(total or 0) - 1))
    length = (end - start + 1) if total else 0
    remaining = length if total else None
    pos = start
    sent_total = 0
    last_exc = None
    for attempt, force_message in enumerate((False, True, True), start=1):
        client = None
        try:
            client = _tg_proxy_client(spec)
            if not client:
                last_exc = 'client unavailable'
                continue
            iterator = _tg_iter_download(client, spec, pos, total, request_size=256 * 1024, force_message=force_message)
            if iterator is None:
                last_exc = 'download target unavailable'
                continue
            fflog('[telegram-proxy] live response range=%s-%s/%s attempt=%s mode=%s file=%r' % (
                pos, end, total, attempt, 'msg' if force_message else 'doc', filename), 1)
            first = None
            for chunk in iterator:
                if chunk:
                    first = bytes(chunk)
                    break
            if not first:
                last_exc = 'empty first chunk'
                continue
            if remaining is not None and len(first) > remaining:
                first = first[:remaining]
            _tg_proxy_write_headers(handler, 206 if partial else 200, mime, filename, total, start, end, partial)
            handler.wfile.write(first)
            try:
                handler.wfile.flush()
            except Exception:
                pass
            n = len(first)
            pos += n
            sent_total += n
            if remaining is not None:
                remaining -= n
                if remaining <= 0:
                    return True
            for chunk in iterator:
                if not chunk:
                    continue
                data = bytes(chunk)
                if remaining is not None:
                    if remaining <= 0:
                        break
                    if len(data) > remaining:
                        data = data[:remaining]
                handler.wfile.write(data)
                try:
                    handler.wfile.flush()
                except Exception:
                    pass
                n = len(data)
                pos += n
                sent_total += n
                if remaining is not None:
                    remaining -= n
                    if remaining <= 0:
                        return True
            return True
        except (BrokenPipeError, ConnectionResetError):
            return True
        except Exception as exc:
            last_exc = exc
            fflog('[telegram-proxy] live response failed attempt=%s sent=%s err=%r' % (attempt, sent_total, exc), 1)
            if sent_total > 0:
                fflog_exc(1)
                return True
            time.sleep(0.25)
        finally:
            _tg_safe_disconnect(client)
    try:
        fflog('[telegram-proxy] live response cannot start range=%s-%s err=%r' % (start, end, last_exc), 1)
        handler.send_error(502, 'Telegram stream did not start')
    except Exception:
        pass
    return False


class _TGRangeWorker:
    """Persistent per-playback Telegram byte-window worker.

    Important: do not open a new Telethon client for every HTTP Range. Kodi may
    fire 2-4 requests while opening a single MP4. On Android this caused broken
    reconnects and long-lived Python threads. This worker owns one Telethon
    client and serves bounded Range jobs through small queues.
    """

    def __init__(self, spec):
        self.spec = spec or {}
        self.token = self.spec.get('token') or uuid.uuid4().hex
        self.jobs = queue.PriorityQueue()
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, name='KadrPlusTGRangeWorker', daemon=True)
        self.client = None
        self.started = False

    def start(self):
        if not self.started:
            self.started = True
            self.thread.start()
        return self

    def is_alive(self):
        try:
            return bool(self.thread and self.thread.is_alive() and not self.stop_event.is_set())
        except Exception:
            return False

    def stop(self):
        try:
            self.stop_event.set()
            self.jobs.put_nowait((999, time.time(), {'stop': True}))
        except Exception:
            pass

    def _priority(self, start, total):
        try:
            start = int(start or 0)
            total = int(total or 0)
            if total and start >= max(0, total - 32 * 1024 * 1024):
                return 0  # MP4/MKV tail probe
            if start < 4 * 1024 * 1024:
                return 1  # startup head probe
        except Exception:
            pass
        return 2

    def submit(self, start, end, total):
        job = {
            'id': uuid.uuid4().hex,
            'start': int(start or 0),
            'end': int(end if end is not None else max(0, int(total or 0) - 1)),
            'total': int(total or 0),
            'q': queue.Queue(maxsize=64),
            'cancel': threading.Event(),
        }
        self.jobs.put((self._priority(job['start'], job['total']), time.time(), job))
        return job

    def _put(self, job, item):
        try:
            q = job.get('q')
            cancel = job.get('cancel')
            while q and not (cancel and cancel.is_set()) and not self.stop_event.is_set():
                try:
                    q.put(item, timeout=0.5)
                    return True
                except queue.Full:
                    continue
        except Exception:
            pass
        return False

    def _ensure_client(self):
        try:
            if self.client:
                return self.client
            self.client = _tg_proxy_client(self.spec)
            return self.client
        except Exception:
            fflog_exc(1)
            self.client = None
            return None

    def _drop_client(self):
        try:
            _tg_safe_disconnect(self.client)
        except Exception:
            pass
        self.client = None

    def _run(self):
        try:
            fflog('[telegram-proxy] range worker start token=%s' % _token_tag(self.token), 1)
            while not self.stop_event.is_set():
                try:
                    _prio, _ts, job = self.jobs.get(timeout=90)
                except queue.Empty:
                    # Keep no idle MTProto connection forever.
                    self._drop_client()
                    continue
                if job.get('stop'):
                    break
                if job.get('cancel') and job['cancel'].is_set():
                    continue
                self._process(job)
        except Exception:
            fflog_exc(1)
        finally:
            self._drop_client()
            fflog('[telegram-proxy] range worker stop token=%s' % _token_tag(self.token), 1)

    def _process(self, job):
        start = int(job.get('start') or 0)
        end = int(job.get('end') or 0)
        total = int(job.get('total') or 0)
        pos = start
        sent = 0
        last_err = None
        try:
            fflog('[telegram-proxy] worker raw job start range=%s-%s/%s' % (start, end, total), 1)
            client = self._ensure_client()
            if not client:
                self._put(job, ('error', 'client unavailable'))
                return
            while pos <= end and not job['cancel'].is_set() and not self.stop_event.is_set():
                remaining = end - pos + 1
                # First byte should be small and fast. Later chunks can be larger,
                # but still bounded so a cancelled Kodi request does not pin a
                # Telethon download for minutes.
                want = 64 * 1024 if sent == 0 else min(256 * 1024, remaining)
                try:
                    data = _tg_fetch_part_retry(client, self.spec, pos, want, total=total, timeout=(8.0 if sent == 0 else 12.0))
                except Exception as exc:
                    last_err = exc
                    data = b''
                if not data:
                    if sent == 0:
                        # Reconnect once for the first chunk. Do not leave the
                        # worker blocked forever; Kodi must get either bytes or a
                        # quick HTTP error.
                        self._drop_client()
                        client = self._ensure_client()
                        if client:
                            try:
                                data = _tg_fetch_part_retry(client, self.spec, pos, want, total=total, timeout=8.0)
                            except Exception as exc:
                                last_err = exc
                                data = b''
                    if not data:
                        break
                if remaining and len(data) > remaining:
                    data = data[:remaining]
                if not self._put(job, ('data', data)):
                    break
                n = len(data)
                pos += n
                sent += n
            if sent > 0:
                self._put(job, ('done', sent))
                fflog('[telegram-proxy] worker raw job done range=%s-%s sent=%s' % (start, end, sent), 1)
            else:
                self._put(job, ('error', repr(last_err or 'empty first chunk')))
                fflog('[telegram-proxy] worker raw job empty range=%s-%s err=%r' % (start, end, last_err), 1)
        except Exception as exc:
            try:
                self._put(job, ('error', repr(exc)))
            except Exception:
                pass
            fflog_exc(1)

    def stream_response(self, handler, start, end, total, mime, filename, partial):
        job = self.submit(start, end, total)
        q = job.get('q')
        sent = 0
        try:
            first = None
            first_deadline = time.time() + 22.0
            while time.time() < first_deadline:
                try:
                    kind, payload = q.get(timeout=0.25)
                except queue.Empty:
                    continue
                if kind == 'data' and payload:
                    first = payload
                    break
                if kind == 'error':
                    raise RuntimeError(payload)
                if kind == 'done':
                    break
            if not first:
                job['cancel'].set()
                fflog('[telegram-proxy] worker no first byte range=%s-%s/%s' % (start, end, total), 1)
                try:
                    handler.send_error(502, 'Telegram stream did not start')
                except Exception:
                    pass
                return False
            _tg_proxy_write_headers(handler, 206 if partial else 200, mime, filename, total, start, end, partial)
            handler.wfile.write(first)
            sent += len(first)
            while True:
                try:
                    kind, payload = q.get(timeout=28.0)
                except queue.Empty:
                    fflog('[telegram-proxy] worker read timeout after sent=%s range=%s-%s' % (sent, start, end), 1)
                    return sent > 0
                if kind == 'data' and payload:
                    handler.wfile.write(payload)
                    sent += len(payload)
                    continue
                if kind == 'done':
                    return True
                if kind == 'error':
                    fflog('[telegram-proxy] worker stream error after sent=%s err=%r' % (sent, payload), 1)
                    return sent > 0
        except (BrokenPipeError, ConnectionResetError):
            try:
                job['cancel'].set()
            except Exception:
                pass
            return True
        except Exception as exc:
            try:
                job['cancel'].set()
            except Exception:
                pass
            fflog('[telegram-proxy] worker response failed range=%s-%s err=%r' % (start, end, exc), 1)
            try:
                handler.send_error(502, 'Telegram proxy worker error')
            except Exception:
                pass
            return False


def _tg_get_range_worker(spec):
    try:
        if not spec:
            return None
        token = spec.get('token') or ''
        worker = spec.get('_range_worker') or (_TG_RANGE_WORKERS.get(token) if token else None)
        if worker and worker.is_alive():
            return worker
        worker = _TGRangeWorker(spec).start()
        spec['_range_worker'] = worker
        if token:
            _TG_RANGE_WORKERS[token] = worker
        return worker
    except Exception:
        fflog_exc(1)
        return None

def _tg_proxy_start(preferred_port=0):
    global _TG_PROXY_SERVER, _TG_PROXY_PORT, _TG_PROXY_THREAD
    try:
        if _TG_PROXY_SERVER and _TG_PROXY_PORT:
            return _TG_PROXY_PORT

        import http.server
        import socketserver
        import threading

        class _TGThreadingServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
            daemon_threads = True
            allow_reuse_address = True

        class _TGProxyHandler(http.server.BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'
            server_version = 'KadrPlusTGProxy/1.0'

            def log_message(self, fmt, *args):
                try:
                    fflog('[telegram-proxy] ' + (fmt % args), 0)
                except Exception:
                    pass

            def do_HEAD(self):
                self._handle(head_only=True)

            def do_GET(self):
                self._handle(head_only=False)

            def _token_from_path(self):
                m = re.match(r'^/telegram/([A-Za-z0-9_-]{16,64})(?:/.*)?$', urlparse(self.path).path or '')
                return m.group(1) if m else ''

            def _range(self, total):
                try:
                    rng = self.headers.get('Range') or ''
                    m = re.match(r'bytes=(\d*)-(\d*)', rng)
                    if not m or not total:
                        return 0, max(0, int(total or 0) - 1), False
                    if m.group(1) == '' and m.group(2):
                        # suffix range: last N bytes
                        n = int(m.group(2))
                        start = max(0, total - n)
                        end = total - 1
                    else:
                        start = int(m.group(1) or 0)
                        end = int(m.group(2) or (total - 1))
                    start = max(0, min(start, total - 1))
                    end = max(start, min(end, total - 1))
                    return start, end, True
                except Exception:
                    return 0, max(0, int(total or 0) - 1), False

            def _bounded_range(self, total, start, end, partial):
                """Limit Kodi's open-ended byte ranges to streaming windows.

                Kodi commonly asks for ``Range: bytes=N-``. If the proxy answers
                with Content-Length from N to EOF, one HTTP request may try to
                stream 1.5 GB through one Telethon iterator and block the demuxer
                from issuing/finishing other important probes.  A real HTTP server
                can satisfy the request with a smaller 206 range; Kodi/libcurl will
                request the next window when it needs more.  This is buffering on
                demand, not full-file predownload.
                """
                try:
                    total = int(total or 0)
                    start = int(start or 0)
                    end = int(end if end is not None else max(0, total - 1))
                    if total <= 0:
                        return start, end, partial
                    raw = self.headers.get('Range') or ''
                    requested_start, requested_end = start, end
                    remaining_to_eof = max(0, total - start)
                    if start < 2 * 1024 * 1024:
                        window = 2 * 1024 * 1024
                    elif remaining_to_eof <= 24 * 1024 * 1024:
                        window = 8 * 1024 * 1024
                    else:
                        window = 4 * 1024 * 1024
                    if not partial:
                        partial = True
                    if end >= total - 1 and (end - start + 1) > window:
                        end = min(total - 1, start + window - 1)
                    if end != requested_end or partial != bool(raw):
                        try:
                            fflog('[telegram-proxy] bounded range raw=%r %s-%s -> %s-%s/%s' % (raw, requested_start, requested_end, start, end, total), 1)
                        except Exception:
                            pass
                    else:
                        try:
                            fflog('[telegram-proxy] range raw=%r %s-%s/%s' % (raw, start, end, total), 1)
                        except Exception:
                            pass
                    return start, end, partial
                except Exception:
                    return start, end, partial

            def _handle(self, head_only=False):
                token = self._token_from_path()
                spec = _TG_PROXY_MAP.get(token)
                if not spec:
                    self.send_error(404, 'Telegram proxy token not found')
                    return
                try:
                    self.connection.settimeout(24)
                except Exception:
                    pass

                if head_only:
                    try:
                        total = int(spec.get('size') or 0)
                        mime = spec.get('mime') or 'video/mp4'
                        filename = spec.get('filename') or 'video.mp4'
                        start, end, partial = self._range(total)
                        length = (end - start + 1) if total else 0
                        self.send_response(206 if partial else 200)
                        self.send_header('Content-Type', mime)
                        self.send_header('Accept-Ranges', 'bytes')
                        self.send_header('Content-Disposition', _tg_content_disposition(filename))
                        if total:
                            if partial:
                                self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, total))
                            self.send_header('Content-Length', str(length))
                        self.send_header('Connection', 'close')
                        self.end_headers()
                    except Exception:
                        fflog_exc(1)
                        try:
                            self.send_error(502, 'Telegram proxy head error')
                        except Exception:
                            pass
                    return

                # 2.41.26: warm only the first few MB and immediately feed Kodi.
                # The previous full-cache idea could download multi-GB files. Here
                # Content-Length still describes the requested range, but cached
                # head bytes are sent first, then the same HTTP response continues
                # with live MTProto Range streaming.
                try:
                    total0 = int(spec.get('size') or 0)
                    mime0 = spec.get('mime') or 'video/mp4'
                    filename0 = spec.get('filename') or 'video.mp4'
                    start0, end0, partial0 = self._range(total0)
                    start0, end0, partial0 = self._bounded_range(total0, start0, end0, partial0)
                    # Main path: all Kodi startup ranges read from the same growing
                    # progressive cache.  Kodi opens duplicate bytes=0- requests and
                    # another request around ~2 MB; serving all of them from one
                    # file avoids serial Telegram jobs and libcurl read timeouts.
                    cached_now = _tg_cache_size(spec)
                    if spec.get('cache_path'):
                        # 2.41.37: cache-only HTTP path. Do not spawn a new
                        # Telethon live stream from request threads. The previous
                        # live fallback was what kept Kodi busy after failed opens.
                        if cached_now <= start0:
                            _tg_proxy_wait_cache(spec, start0, timeout=24.0)
                            cached_now = _tg_cache_size(spec)
                        if cached_now > start0:
                            try:
                                fflog('[telegram-proxy] cache-only response range=%s-%s cached=%s' % (start0, end0, cached_now), 1)
                            except Exception:
                                pass
                            _tg_proxy_write_headers(self, 206, mime0, filename0, total0, start0, end0, True)
                            sent_cache = _tg_proxy_send_from_cache(self, spec, start0, end0, total0, wait_for_more=True)
                            try:
                                fflog('[telegram-proxy] cache-only sent=%s range=%s-%s cached=%s done=%s err=%r' % (sent_cache, start0, end0, _tg_cache_size(spec), spec.get('cache_done'), spec.get('cache_error') or ''))
                            except Exception:
                                pass
                            return
                        try:
                            fflog('[telegram-proxy] cache-only miss range=%s-%s cached=%s err=%r; using bounded raw response' % (start0, end0, cached_now, spec.get('cache_error') or ''), 1)
                        except Exception:
                            pass
                        _tg_proxy_stream_one_part_response(self, spec, start0, end0, total0, mime0, filename0, True)
                        return
                    cached0 = int(spec.get('head_cache_pos') or 0)
                    if spec.get('head_cache_path') and cached0 > start0:
                        _tg_proxy_write_headers(self, 206 if partial0 else 200, mime0, filename0, total0, start0, end0, partial0)
                        sent0 = _tg_proxy_send_head_cache(self, spec, start0, end0)
                        next_pos = start0 + int(sent0 or 0)
                        if total0 and next_pos <= end0:
                            _tg_proxy_stream_direct_body(self, spec, next_pos, end0, total0)
                        return

                    # Kodi often asks for a tail Range while opening MP4/MKV.
                    # Serve it from the small tail cache when possible; otherwise
                    # the first byte can arrive after Kodi's libcurl timeout.
                    tail_start0 = int(spec.get('tail_cache_start') or 0)
                    if spec.get('tail_cache_path') and total0 and start0 >= tail_start0:
                        if _tg_tail_cache_ready(spec, start0, end0, wait_seconds=0.05):
                            _tg_proxy_write_headers(self, 206 if partial0 else 200, mime0, filename0, total0, start0, end0, partial0)
                            _tg_proxy_send_tail_cache(self, spec, start0, end0, wait_seconds=0.0)
                            return
                        try:
                            fflog('[telegram-proxy] tail cache miss; streaming live range=%s-%s cached=%s start=%s err=%r' % (
                                start0, end0, int(spec.get('tail_cache_pos') or 0), tail_start0, spec.get('tail_cache_error') or ''), 1)
                        except Exception:
                            pass
                        # Nie zwracaj 503. To zabija demuxer Kodi. Przejdź do
                        # live Range i wyślij nagłówki dopiero po pierwszym chunku.
                except (BrokenPipeError, ConnectionResetError):
                    return
                except Exception:
                    fflog_exc(1)

                try:
                    total = int(spec.get('size') or 0)
                    mime = spec.get('mime') or 'video/mp4'
                    filename = spec.get('filename') or 'video.mp4'
                    start, end, partial = self._range(total)
                    start, end, partial = self._bounded_range(total, start, end, partial)
                    if head_only:
                        _tg_proxy_write_headers(self, 206 if partial else 200, mime, filename, total, start, end, partial)
                        return
                    edge = _tg_edge_slice(spec, start, end)
                    if edge:
                        try:
                            fflog('[telegram-proxy] edge cache hit start=%s bytes=%s' % (start, len(edge)), 1)
                        except Exception:
                            pass
                        _tg_proxy_write_headers(self, 206 if partial else 200, mime, filename, total, start, end, partial)
                        self.wfile.write(edge)
                        try:
                            self.wfile.flush()
                        except Exception:
                            pass
                        next_start = start + len(edge)
                        if next_start > end:
                            return
                        start = next_start
                    # 2.41.35: return only a truthful small 206 range.
                    # Do not keep a long response open waiting for Telegram to
                    # fill a 2 MB window; that is what froze Kodi/libcurl.
                    _tg_proxy_stream_one_part_response(self, spec, start, end, total, mime, filename, partial)
                except Exception:
                    fflog_exc(1)
                    try:
                        self.send_error(502, 'Telegram proxy upstream error')
                    except Exception:
                        pass

        preferred_port = int(preferred_port or 0)
        if preferred_port and not (1024 < preferred_port < 65536):
            preferred_port = 0
        try_ports = [preferred_port] if preferred_port else []
        try_ports += [0]
        last_exc = None
        for port in try_ports:
            try:
                srv = _TGThreadingServer(('127.0.0.1', port), _TGProxyHandler)
                _TG_PROXY_SERVER = srv
                _TG_PROXY_PORT = int(srv.server_address[1])
                _TG_PROXY_THREAD = threading.Thread(target=srv.serve_forever, name='KadrPlusTelegramProxy', daemon=True)
                _TG_PROXY_THREAD.start()
                fflog(f'[telegram-proxy] started on 127.0.0.1:{_TG_PROXY_PORT}', 1)
                return _TG_PROXY_PORT
            except Exception as exc:
                last_exc = exc
        if last_exc:
            fflog(f'[telegram-proxy] cannot start: {last_exc!r}', 1)
        return 0
    except Exception:
        fflog_exc(1)
        return 0


def _tg_ensure_event_loop():
    """Return a Telethon-safe asyncio loop in Kodi worker threads.

    Kodi/Android Python 3.11 can have a broken/cleared default event-loop
    policy in plugin callback threads. In the log this showed as:
    TypeError: 'NoneType' object is not callable inside asyncio.events.

    Therefore do not trust asyncio.get_event_loop() only. Keep a per-thread
    loop and fall back to SelectorEventLoop without touching the global policy
    if Python's policy object is broken.
    """
    try:
        import threading
        tid = threading.get_ident()
    except Exception:
        tid = 0

    try:
        loop = _TG_LOOP_BY_THREAD.get(tid)
        if loop and not loop.is_closed():
            return loop
    except Exception:
        pass

    try:
        loop = asyncio.get_running_loop()
        if loop and not loop.is_closed():
            _TG_LOOP_BY_THREAD[tid] = loop
            return loop
    except Exception:
        pass

    # Try normal APIs, but catch *all* exceptions, not only RuntimeError.
    try:
        loop = asyncio.get_event_loop()
        if loop and not loop.is_closed():
            _TG_LOOP_BY_THREAD[tid] = loop
            return loop
    except Exception as exc:
        try:
            fflog(f'[telegram] asyncio.get_event_loop failed, creating local loop: {exc!r}', 1)
        except Exception:
            pass

    try:
        loop = asyncio.new_event_loop()
    except Exception as exc:
        try:
            fflog(f'[telegram] asyncio.new_event_loop failed, using SelectorEventLoop: {exc!r}', 1)
        except Exception:
            pass
        try:
            loop = asyncio.SelectorEventLoop()
        except Exception:
            # Last resort: reset policy if available and retry once.
            try:
                policy_cls = getattr(asyncio, 'DefaultEventLoopPolicy', None)
                if policy_cls:
                    asyncio.set_event_loop_policy(policy_cls())
                    loop = asyncio.new_event_loop()
                else:
                    raise
            except Exception:
                raise

    try:
        asyncio.set_event_loop(loop)
    except Exception:
        pass
    _TG_LOOP_BY_THREAD[tid] = loop
    return loop


def _tg_running_loop_for_telethon():
    """Small wrapper used to patch Telethon's helpers.get_running_loop.

    Telethon 1.x exposes client.loop as helpers.get_running_loop() and in Kodi
    request/proxy threads that function may ask Python's default policy for a
    loop before Kodi has registered one.  The symptom is playback ending with:
    "There is no current event loop in thread process_request_thread".
    Always return our per-thread loop instead.
    """
    return _tg_ensure_event_loop()


def _tg_patch_telethon_helpers():
    try:
        import telethon.helpers as helpers
        if not getattr(helpers.get_running_loop, '_kadrplus_patched', False):
            def _patched_get_running_loop():
                return _tg_running_loop_for_telethon()
            _patched_get_running_loop._kadrplus_patched = True
            helpers.get_running_loop = _patched_get_running_loop

        # Kodi/Android TV potrafi wyrzucić asyncio.CancelledError podczas
        # telethonowego przełączania DC (_switch_dc -> _disconnect). W normalnym
        # Pythonie Telethon to wycisza, ale na niektórych buildach Androida błąd
        # potrafi wyjść wyżej i przerwać login. Patch ograniczamy do helpera
        # cancelującego wewnętrzne taski Telethona.
        if not getattr(getattr(helpers, '_cancel', None), '_kadrplus_patched', False):
            _orig_cancel = helpers._cancel
            async def _patched_cancel(log, **tasks):
                try:
                    return await _orig_cancel(log, **tasks)
                except BaseException:
                    return None
            _patched_cancel._kadrplus_patched = True
            helpers._cancel = _patched_cancel
    except Exception:
        pass


def _tg_telethon_imports():
    try:
        from telethon.sync import TelegramClient
        from telethon import errors
        from telethon.tl.types import PeerChannel, PeerChat, PeerUser
        _tg_patch_telethon_helpers()
        return TelegramClient, errors, PeerChannel, PeerChat, PeerUser
    except Exception:
        return None, None, None, None, None


def _tg_proxy_client(spec):
    try:
        TelegramClient, _, _, _, _ = _tg_telethon_imports()
        if not TelegramClient:
            return None
        api_id = int(spec.get('api_id') or 0)
        api_hash = spec.get('api_hash') or ''
        if not (api_id and api_hash):
            return None
        loop = _tg_ensure_event_loop()
        _tg_patch_telethon_helpers()
        try:
            asyncio.set_event_loop(loop)
        except Exception:
            pass

        session_string = spec.get('session_string') or ''
        if not session_string:
            session_path = spec.get('session_path') or ''
            session_string = _tg_export_session_string(session_path)
            if session_string:
                spec['session_string'] = session_string
        if session_string:
            from telethon.sessions import StringSession
            client = TelegramClient(StringSession(session_string), api_id, api_hash, loop=loop,
                                    timeout=10, request_retries=0, connection_retries=2,
                                    retry_delay=0.5, auto_reconnect=True, receive_updates=False,
                                    flood_sleep_threshold=0, entity_cache_limit=128,
                                    base_logger=_TG_TELETHON_LOGGER)
            try:
                setattr(client, '_kadrplus_temp_session_base', '')
            except Exception:
                pass
        else:
            # Awaryjny fallback tylko gdy nie da się wyeksportować sesji.
            session_path = spec.get('session_path') or ''
            if not session_path:
                return None
            client_session_path = _tg_temp_session_base(session_path)
            client = TelegramClient(client_session_path, api_id, api_hash, loop=loop,
                                    timeout=10, request_retries=0, connection_retries=2,
                                    retry_delay=0.5, auto_reconnect=True, receive_updates=False,
                                    flood_sleep_threshold=0, entity_cache_limit=128,
                                    base_logger=_TG_TELETHON_LOGGER)
            try:
                setattr(client, '_kadrplus_temp_session_base', client_session_path if client_session_path != session_path else '')
            except Exception:
                pass
        client.connect()
        if not client.is_user_authorized():
            _tg_safe_disconnect(client)
            return None
        return client
    except Exception:
        fflog_exc(1)
        return None


def _tg_find_entity(client, chat_id, chat_ref='', spec=None):
    try:
        # Fast path for playback: store peer type/access_hash in the source token,
        # so the proxy does not have to iterate hundreds of dialogs before every
        # Kodi Range/GET request.  That dialog scan was the main reason local TG
        # playback timed out before the first bytes arrived.
        try:
            spec = spec or {}
            peer_type = (spec.get('peer_type') or '').lower()
            access_hash = int(spec.get('access_hash') or 0)
            cid = int(chat_id or spec.get('chat_id') or 0)
            if cid:
                from telethon.tl.types import InputPeerChannel, InputPeerChat, PeerChannel, PeerChat
                if peer_type in ('channel', 'megagroup', 'broadcast') and access_hash:
                    return InputPeerChannel(cid, access_hash)
                if peer_type in ('chat', 'group'):
                    return InputPeerChat(cid)
                # If we do not know the peer type but have an access_hash, this
                # is almost always a channel/megagroup.
                if access_hash:
                    return InputPeerChannel(cid, access_hash)
        except Exception:
            pass
        if chat_ref:
            try:
                return client.get_entity(chat_ref)
            except Exception:
                pass
        # Slow fallback: search known dialogs.
        for d in client.iter_dialogs(limit=500):
            ent = getattr(d, 'entity', None)
            if ent and int(getattr(ent, 'id', 0) or 0) == int(chat_id or 0):
                return ent
    except Exception:
        fflog_exc(1)
    return None


class source:
    has_sort_order = True
    has_color_identify2 = True
    use_premium_color = False

    def __init__(self):
        # Startuj wcześnie: Telegram potrafi skanować wiele dialogów, więc
        # przy niskim priorytecie wyniki wracały dopiero po timeoutcie i były odrzucane.
        self.priority = 0
        # Osobna grupa źródeł [TG]; sources.py dołącza ją tylko gdy provider.telegram=true.
        self.language = ['pl', 'de', 'en']
        self.api_id = (control.setting('telegram.api_id') or '').strip()
        self.api_hash = (control.setting('telegram.api_hash') or '').strip()
        self.phone = self._normalize_phone(control.setting('telegram.phone') or '')
        # Production defaults: Telegram only searches the user's logged-in
        # account dialogs. Old public t.me/s and local proxy switches were
        # experimental and are intentionally hidden/disabled now.
        self.chats = []
        self.session_name = 'kadrplus_telegram'
        self.only_account = True
        self.public_web = False
        self.use_dialogs = True
        self.login_on_search = False
        self.qr_login = True
        self.proxy_stream = self._setting_bool(control.setting('telegram.proxy_stream'), default=True)
        try:
            self.proxy_port = int(control.setting('telegram.proxy_port') or 0)
        except Exception:
            self.proxy_port = 0
        self.diagnostics_enabled = self._setting_bool(
            control.setting('diagnostics.enabled'),
            default=False,
        )
        try:
            self.chat_filter_mode = int(control.setting('telegram.chat_filter_mode') or 0)
        except Exception:
            self.chat_filter_mode = 0
        self.chat_filter_mode = max(0, min(int(self.chat_filter_mode or 0), 2))
        def _int_setting(setting_id, default, low, high):
            try:
                value = int(control.setting(setting_id) or default)
            except Exception:
                value = int(default)
            return max(int(low), min(int(value), int(high)))

        self.search_limit = _int_setting('telegram.search_limit', 100, 5, 500)
        self.dialog_limit = _int_setting('telegram.dialog_limit', 500, 5, 1000)
        self.search_timeout = _int_setting('telegram.search_timeout', 65, 8, 120)
        self.min_size_mb = _int_setting('telegram.min_size_mb', 0, 0, 3000)
        self.min_size_series_mb = _int_setting('telegram.min_size_series_mb', 0, 0, 1500)
        self.min_file_size = int(self.min_size_mb) * 1024 * 1024
        self.min_series_file_size = int(self.min_size_series_mb) * 1024 * 1024

        # Ustawialne limity Telegrama. Domyślne wartości są kompromisem:
        # szybkie wyszukiwanie po koncie + mały fallback na grupy/tematy + skan plakatów.
        self.max_results = _int_setting('telegram.max_results', 200, 20, 500)
        self.max_per_chat = _int_setting('telegram.max_per_chat', 20, 5, 100)
        self.quick_budget_pct = _int_setting('telegram.quick_budget_pct', 50, 15, 80)
        self.topic_budget = _int_setting('telegram.topic_budget', 12, 0, 40)
        # Ile wiadomości sprawdzać wewnątrz tematu/forum oraz jak szeroko
        # sprawdzać posty-plakaty dla filmów. Więcej = dokładniej, ale wolniej.
        self.topic_scan_limit = _int_setting('telegram.topic_scan_limit', 80, 40, 160)
        self.dialog_fallback_budget = _int_setting('telegram.dialog_fallback_budget', 10, 0, 40)
        self.max_context_headers = _int_setting('telegram.context_headers', 32, 0, 100)
        self.context_budget = _int_setting('telegram.context_budget', 18, 0, 60)
        self.movie_context_files = _int_setting('telegram.movie_context_files', 3, 0, 10)
        self.series_context_files = _int_setting('telegram.series_context_files', 30, 0, 100)
        self.startup_buffer_mb = _int_setting('telegram.startup_buffer_mb', 4, 1, 16)
        self.strict_episode_match = self._setting_bool(control.setting('telegram.strict_episode_match'), default=False)
        # True only when the user backed out of the nested Telegram result list.
        # The source engine uses it to distinguish Cancel from a broken stream.
        self.selection_cancelled = False
        self.session = None
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'pl-PL,pl;q=0.9,de-DE;q=0.8,en-US;q=0.7,en;q=0.6',
        }

    def _diag(self, message):
        if not self.diagnostics_enabled:
            return
        try:
            # One master switch controls all Kadr+ diagnostics.  The helper
            # writes to kodi.log and strips queries, chat names, identifiers,
            # URLs and credentials before anything leaves this module.
            from lib.ff.diagnostics import log_event
            log_event('telegram', message)
        except Exception:
            pass

    def _cancelled(self):
        """Return True when the FanFilm source window requested cancellation."""
        try:
            thread = threading.current_thread()
            stop_event = getattr(thread, 'stop_event', None)
            thread_stopped = bool(stop_event and stop_event.is_set())
            return bool(getattr(self, 'canceled', False) or thread_stopped)
        except Exception:
            return False

    def _is_api_id_invalid(self, exc, errors=None):
        try:
            api_err = getattr(errors, 'ApiIdInvalidError', None) if errors else None
            if api_err and isinstance(exc, api_err):
                return True
        except Exception:
            pass
        name = exc.__class__.__name__
        text = str(exc)
        return name == 'ApiIdInvalidError' or 'API_ID_INVALID' in text or 'api_id/api_hash combination is invalid' in text

    def _show_api_id_invalid(self):
        try:
            control.infoDialog('Telegram: nieprawidłowe api_id/api_hash. Wklej ponownie parę z my.telegram.org.', heading='Telegram', icon='WARNING', time=9000, sound=False)
        except Exception:
            pass

    def _client_dc_id(self, client):
        try:
            return int(getattr(getattr(client, 'session', None), 'dc_id', 0) or 0)
        except Exception:
            return 0

    def _is_dc_migration_error(self, exc):
        try:
            name = exc.__class__.__name__
            text = str(exc)
        except Exception:
            name, text = '', ''
        markers = (
            'PhoneMigrateError', 'NetworkMigrateError', 'UserMigrateError', 'FileMigrateError',
            'PHONE_MIGRATE', 'NETWORK_MIGRATE', 'USER_MIGRATE', 'FILE_MIGRATE',
            'associated with DC', '_switch_dc', 'new data center'
        )
        return any(m in name or m in text for m in markers)

    def _is_dc_switch_interrupt(self, exc):
        try:
            if isinstance(exc, asyncio.CancelledError):
                return True
        except Exception:
            pass
        return self._is_dc_migration_error(exc)

    def _new_login_client(self, session_path, api_id, api_hash, loop):
        try:
            TelegramClient, _, _, _, _ = _tg_telethon_imports()
            if not TelegramClient:
                return None
            _tg_patch_telethon_helpers()
            try:
                asyncio.set_event_loop(loop)
            except Exception:
                pass
            client = TelegramClient(
                session_path, int(api_id), api_hash, loop=loop,
                base_logger=_TG_TELETHON_LOGGER,
            )
            client.connect()
            return client
        except BaseException:
            fflog_exc(1)
            return None

    def _recover_client_after_dc_switch(self, client, session_path, api_id, api_hash, loop, before_dc=0, reason='login'):
        try:
            after_dc = self._client_dc_id(client)
            if not after_dc or (before_dc and after_dc == before_dc):
                return None
            try:
                fflog('[telegram] %s: DC migration detected %s -> %s, recreating client' % (reason, before_dc or '?', after_dc), 1)
            except Exception:
                pass
            try:
                control.infoDialog('Telegram: przełączam logowanie na DC %s i ponawiam próbę' % after_dc, heading='Telegram', time=4500, sound=False)
            except Exception:
                pass
            _tg_safe_disconnect(client)
            try:
                time.sleep(0.35)
            except Exception:
                pass
            return self._new_login_client(session_path, api_id, api_hash, loop)
        except BaseException:
            fflog_exc(1)
            return None

    def _send_login_code_with_dc_retry(self, client, phone, session_path, api_id, api_hash, loop, errors=None):
        before_dc = self._client_dc_id(client)
        try:
            sent = self._send_login_code(client, phone, force_sms=False)
            return client, sent
        except BaseException as exc:
            if self._is_api_id_invalid(exc, errors):
                self._show_api_id_invalid()
                return client, None
            if not self._is_dc_switch_interrupt(exc):
                fflog_exc(1)
                return client, None
            new_client = self._recover_client_after_dc_switch(client, session_path, api_id, api_hash, loop, before_dc, 'send_code_request')
            if not new_client:
                try:
                    control.infoDialog('Telegram: nie udało się przełączyć centrum danych. Uruchom Kodi ponownie i spróbuj jeszcze raz.', heading='Telegram', icon='WARNING', time=8000, sound=False)
                except Exception:
                    pass
                return client, None
            try:
                sent = self._send_login_code(new_client, phone, force_sms=False)
                return new_client, sent
            except BaseException as exc2:
                if self._is_api_id_invalid(exc2, errors):
                    self._show_api_id_invalid()
                else:
                    fflog_exc(1)
                    try:
                        control.infoDialog('Telegram: ponowne wysłanie kodu po przełączeniu DC nie powiodło się.', heading='Telegram', icon='WARNING', time=7000, sound=False)
                    except Exception:
                        pass
                return new_client, None

    def _qr_login_with_dc_retry(self, client, session_path, api_id, api_hash, loop, errors=None):
        before_dc = self._client_dc_id(client)
        try:
            self._last_qr_dc_migrated = False
            ok = self._qr_login(client, errors)
            if ok:
                return client, True
            if not getattr(self, '_last_qr_dc_migrated', False):
                return client, False
            new_client = self._recover_client_after_dc_switch(client, session_path, api_id, api_hash, loop, before_dc, 'qr_login')
            if not new_client:
                return client, False
            self._last_qr_dc_migrated = False
            ok = self._qr_login(new_client, errors)
            return new_client, bool(ok)
        except BaseException as exc:
            if self._is_api_id_invalid(exc, errors):
                self._show_api_id_invalid()
                return client, False
            if self._is_dc_switch_interrupt(exc):
                new_client = self._recover_client_after_dc_switch(client, session_path, api_id, api_hash, loop, before_dc, 'qr_login')
                if new_client:
                    try:
                        ok = self._qr_login(new_client, errors)
                        return new_client, bool(ok)
                    except BaseException:
                        fflog_exc(1)
                        return new_client, False
            fflog_exc(1)
            return client, False

    # ------------------------------------------------------------------ #
    # Kadr+/FanFilm interface                                             #
    # ------------------------------------------------------------------ #

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        if not self._configured():
            return None
        return self._pack({
            'kind': 'movie',
            'imdb': imdb or '',
            'title': title or localtitle,
            'localtitle': localtitle,
            'aliases': aliases or [],
            'year': year,
        })

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        if not self._configured():
            return None
        return self._pack({
            'kind': 'series',
            'imdb': imdb or '',
            'tvdb': tvdb or '',
            'title': tvshowtitle or localtvshowtitle,
            'localtitle': localtvshowtitle,
            'aliases': aliases or [],
            'year': year,
        })

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        if not url:
            return None
        try:
            data = self._unpack(url)
            data['season'] = int(season or 1)
            data['episode'] = int(float(episode or 1))
            data['episode_title'] = title or ''
            return self._pack(data)
        except Exception:
            fflog_exc(1)
            return None

    def sources(self, url, hostDict, hostprDict, from_cache=False):
        try:
            if not url or not self._configured():
                return []
            data = self._unpack(url)
            fflog(f'[telegram] Stage 5 search for {data.get("title")!r}', 1)
            results = []
            if self._cancelled():
                return []

            # Stage 3: logged account dialogs first. This is what private groups/channels need.
            if self.use_dialogs and self._mtproto_ready():
                results.extend(self._sources_mtproto(data))

            # Manual public web fallback is still useful for public channels.
            if self.public_web and not self.only_account and (not results or self.chats):
                results.extend(self._sources_public_web(data))

            if self._cancelled():
                fflog('[telegram] search cancelled before building result list', 1)
                return []
            if not results:
                self._log_telethon_status()

            dedup = []
            seen = set()
            for item in results:
                u = (item.get('url') or '').split('|', 1)[0]
                if not u or u in seen:
                    continue
                seen.add(u)
                dedup.append(item)
            if dedup:
                items = []
                for item in dedup[:self.max_results]:
                    item = dict(item or {})
                    item['language'] = item.get('language') if item.get('language') in ('pl', 'de', 'en', 'multi') else 'pl'
                    item['direct'] = True
                    item['debridonly'] = False
                    item['color_identify'] = control.setting('telegram.color.identify2') or 'FF2196F3'
                    items.append(item)
                fresh_count = len(items)
                items, restored_count = self._merge_recent_search_results(items, data)
                aggregate = self._aggregate_source(items, data)
                if aggregate:
                    aggregate['color_identify'] = control.setting('telegram.color.identify2') or 'FF2196F3'
                    aggregate['filename'] = f'Telegram — {len(items)} wyników'
                    fflog(
                        f'[telegram] Kadr+ 2.0 returned aggregate with {len(items)} results '
                        f'(fresh={fresh_count}, restored={restored_count})',
                        1,
                    )
                    return [aggregate]
            fflog('[telegram] Kadr+ 2.0 returned 0 sources', 1)
            return []
        except Exception:
            fflog_exc(1)
            return []

    def _aggregate_source(self, items, data=None):
        try:
            count = len(items or [])
            cache_id = self._save_selection_cache(items or [], data or {})
            if cache_id:
                token = self._pack({
                    'mode': 'select_cache',
                    'cache_id': cache_id,
                    'title': (data or {}).get('title') or (data or {}).get('localtitle') or '',
                })
            else:
                token = self._pack({
                    'mode': 'select',
                    'items': items or [],
                    'title': (data or {}).get('title') or (data or {}).get('localtitle') or '',
                })
            return {
                'provider': 'telegram',
                'source': 'Telegram',
                # Nie używamy quality=0, bo część filtrów traktuje to jak
                # źródło techniczne/niepełne. To tylko agregat do otwarcia listy.
                'quality': 'HD',
                'language': 'multi',
                'url': token,
                'info': '%d znalezionych wyników' % count,
                'direct': True,
                'debridonly': False,
                'filename': '',
                'premium': False,
                'telegram_aggregate': True,
                'telegram_count': count,
                'size': '',
            }
        except Exception:
            fflog_exc(1)
            return {}

    def _selection_cache_dir(self):
        try:
            path = os.path.join(control.dataPath, 'telegram', 'search_results')
            try:
                control.makeDirs(path)
            except Exception:
                os.makedirs(path, exist_ok=True)
            return path
        except Exception:
            return ''

    @staticmethod
    def _normalized_cache_title(value):
        try:
            value = unicodedata.normalize('NFKD', str(value or ''))
            value = ''.join(ch for ch in value if not unicodedata.combining(ch))
            return re.sub(r'[^a-z0-9]+', ' ', value.lower()).strip()
        except Exception:
            return ''

    def _search_history_identity(self, data):
        """Return a stable, non-readable key for one movie/episode query."""
        try:
            aliases = data.get('aliases') or []
            identity = {
                'kind': data.get('kind') or '',
                'title': self._normalized_cache_title(data.get('title')),
                'localtitle': self._normalized_cache_title(data.get('localtitle')),
                'aliases': sorted(
                    self._normalized_cache_title(alias.get('title') if isinstance(alias, dict) else alias)
                    for alias in aliases
                    if alias
                ),
                'year': str(data.get('year') or ''),
                'season': str(data.get('season') or ''),
                'episode': str(data.get('episode') or ''),
                'imdb': str(data.get('imdb') or ''),
                'tvdb': str(data.get('tvdb') or ''),
            }
            raw = json.dumps(identity, ensure_ascii=True, sort_keys=True, separators=(',', ':'))
            return hashlib.sha256(raw.encode('utf-8')).hexdigest()[:32]
        except Exception:
            return ''

    def _recent_search_items(self, data):
        """Load recent results for this exact query (plus legacy picker cache).

        Telegram's server ranking and a strict time budget can make two scans
        return slightly different subsets.  Reusing only recent local metadata
        prevents a rescan from losing a valid file that was found moments ago.
        """
        folder = self._selection_cache_dir()
        if not folder:
            return []
        now = time.time()
        max_age = 6 * 3600
        identity = self._search_history_identity(data or {})
        requested_titles = {
            self._normalized_cache_title((data or {}).get('title')),
            self._normalized_cache_title((data or {}).get('localtitle')),
        }
        requested_titles.discard('')

        paths = []
        if identity:
            paths.append(os.path.join(folder, f'recent_{identity}.json'))
        try:
            legacy = [
                os.path.join(folder, name)
                for name in os.listdir(folder)
                if name.endswith('.json') and not name.startswith('recent_')
            ]
            legacy.sort(key=lambda path: os.path.getmtime(path), reverse=True)
            paths.extend(legacy[:24])
        except Exception:
            pass

        cached = []
        for path in paths:
            try:
                if not os.path.isfile(path) or now - os.path.getmtime(path) > max_age:
                    continue
                with open(path, 'r', encoding='utf-8') as fh:
                    payload = json.load(fh) or {}
                # Stable history is already keyed by the complete query.  Old
                # picker files only had a title, so accept those conservatively.
                if not os.path.basename(path).startswith('recent_'):
                    cached_title = self._normalized_cache_title(payload.get('title'))
                    if requested_titles and cached_title not in requested_titles:
                        continue
                values = payload.get('items') or []
                if isinstance(values, list):
                    cached.extend(item for item in values if isinstance(item, dict))
            except Exception:
                continue
        return cached

    @staticmethod
    def _search_result_key(item):
        try:
            url = str((item or {}).get('url') or '').split('|', 1)[0].strip()
            if url:
                return 'url:' + url
            raw = json.dumps(item or {}, ensure_ascii=True, sort_keys=True, default=str, separators=(',', ':'))
            return 'meta:' + hashlib.sha256(raw.encode('utf-8')).hexdigest()
        except Exception:
            return ''

    def _merge_recent_search_results(self, fresh, data):
        """Merge fresh Telegram hits with a short-lived, query-specific history."""
        fresh = [dict(item or {}) for item in fresh if isinstance(item, dict)]
        previous = self._recent_search_items(data or {})
        fresh_unique = []
        restored_unique = []
        seen = set()
        for item in fresh:
            key = self._search_result_key(item)
            if not key or key in seen:
                continue
            seen.add(key)
            fresh_unique.append(item)
            if len(fresh_unique) >= self.max_results:
                break

        # Never let history displace a result found by the current scan.
        remaining = max(0, self.max_results - len(fresh_unique))
        for item in previous:
            if len(restored_unique) >= remaining:
                break
            key = self._search_result_key(item)
            if not key or key in seen:
                continue
            seen.add(key)
            restored_unique.append(item)

        # Keep files belonging to a Telegram post together.  Appending all
        # restored files at the very end could split one group into two visual
        # blocks; inserting them after the last fresh member preserves both the
        # provider's current ranking and clean group separators.
        restored_by_group = {}
        for item in restored_unique:
            group_id = str((item or {}).get('telegram_parent_header_id') or '')
            if group_id:
                restored_by_group.setdefault(group_id, []).append(item)
        last_fresh_group_index = {}
        for index, item in enumerate(fresh_unique):
            group_id = str((item or {}).get('telegram_parent_header_id') or '')
            if group_id:
                last_fresh_group_index[group_id] = index

        merged = []
        placed_groups = set()
        for index, item in enumerate(fresh_unique):
            merged.append(item)
            group_id = str((item or {}).get('telegram_parent_header_id') or '')
            if group_id and last_fresh_group_index.get(group_id) == index:
                merged.extend(restored_by_group.get(group_id, ()))
                placed_groups.add(group_id)
        for item in restored_unique:
            group_id = str((item or {}).get('telegram_parent_header_id') or '')
            if not group_id:
                merged.append(item)
            elif group_id not in placed_groups:
                merged.extend(restored_by_group.get(group_id, ()))
                placed_groups.add(group_id)

        identity = self._search_history_identity(data or {})
        folder = self._selection_cache_dir()
        if identity and folder:
            path = os.path.join(folder, f'recent_{identity}.json')
            temp_path = path + '.tmp'
            try:
                with open(temp_path, 'w', encoding='utf-8') as fh:
                    json.dump(
                        {
                            'items': merged,
                            'title': (data or {}).get('title') or (data or {}).get('localtitle') or '',
                            'saved_at': int(time.time()),
                        },
                        fh,
                        ensure_ascii=False,
                        separators=(',', ':'),
                    )
                os.replace(temp_path, path)
            except Exception:
                try:
                    if os.path.exists(temp_path):
                        os.unlink(temp_path)
                except Exception:
                    pass

        fresh_keys = {self._search_result_key(item) for item in fresh}
        restored = sum(1 for item in merged if self._search_result_key(item) not in fresh_keys)
        return merged, restored

    def _save_selection_cache(self, items, data):
        try:
            folder = self._selection_cache_dir()
            if not folder:
                return ''
            now = time.time()
            # Sprzątnij stare wyniki, żeby cache nie rósł bez końca.
            try:
                for name in os.listdir(folder):
                    if not name.endswith('.json'):
                        continue
                    path = os.path.join(folder, name)
                    if now - os.path.getmtime(path) > 6 * 3600:
                        os.remove(path)
            except Exception:
                pass
            cache_id = uuid.uuid4().hex
            path = os.path.join(folder, cache_id + '.json')
            with open(path, 'w', encoding='utf-8') as fh:
                json.dump({'items': items or [], 'title': (data or {}).get('title') or (data or {}).get('localtitle') or ''}, fh, ensure_ascii=False, separators=(',', ':'))
            return cache_id
        except Exception:
            fflog_exc(1)
            return ''

    def _load_selection_cache(self, cache_id):
        try:
            cache_id = re.sub(r'[^A-Fa-f0-9]+', '', str(cache_id or ''))
            if not cache_id:
                return {}
            path = os.path.join(self._selection_cache_dir(), cache_id + '.json')
            with open(path, 'r', encoding='utf-8') as fh:
                return json.load(fh) or {}
        except Exception:
            fflog_exc(1)
            return {}

    def _selection_label(self, item):
        try:
            fname = self._clean_filename_label(item.get('filename') or item.get('info2') or '', limit=220)
            if not fname:
                # Last fallback: filename is also embedded in info as the final segment.
                parts = [p.strip() for p in str(item.get('info') or '').split('•') if p.strip()]
                fname = parts[-1] if parts else 'Plik Telegram'
            quality = str(item.get('quality') or '').strip() or self._quality_from_text(fname)
            size = str(item.get('size') or '').strip()
            chat = self._display_chat_title(item.get('source') or 'Telegram')
            language = str(item.get('language') or '').strip().upper()
            date = str(item.get('telegram_date') or '').strip()
            pieces = [fname]
            if language:
                pieces.append(language)
            if quality and quality != '0':
                pieces.append(quality)
            if size:
                pieces.append(size)
            if date:
                pieces.append(date)
            if chat:
                pieces.append(chat)
            return ' • '.join([p for p in pieces if p])
        except Exception:
            return 'Plik Telegram'

    def directory_from_source(self, source, meta=None, title=''):
        """Legacy renderer kept for old Kadr+ routes; unused by the new engine.

        Kadr+ 2.0 opens a nested picker inside the source window instead. Running
        a second plugin directory from an unresolved /play invocation would leave
        two Kodi handles alive and recreate the false playback error on Back.
        """
        fflog('[TELEGRAM] ignored obsolete directory_from_source route', 1)
        return False

    def _resolve_selected_result(self, data):
        try:
            self.selection_cancelled = False
            items = data.get('items') or []
            if not items:
                return None

            def _header_label(txt):
                txt = re.sub(r'\s+', ' ', str(txt or '')).strip()
                if not txt:
                    txt = 'Pliki z posta/opisu Telegrama'
                if len(txt) > 220:
                    txt = txt[:217].rstrip() + '...'
                return txt

            def _separator_label():
                return 'KONIEC GRUPY'

            rows = []
            open_header = None
            for item in items:
                hid = str(item.get('telegram_parent_header_id') or '')
                if hid:
                    if open_header != hid:
                        if open_header is not None:
                            rows.append((_separator_label(), None))
                        rows.append((_header_label(item.get('telegram_parent_header_text') or ''), None))
                        open_header = hid
                else:
                    if open_header is not None:
                        rows.append((_separator_label(), None))
                        open_header = None
                rows.append((self._selection_label(item), item))
            if open_header is not None:
                rows.append((_separator_label(), None))

            while True:
                try:
                    from lib.windows.telegram import TelegramResultsDialog
                    idx = TelegramResultsDialog(rows=rows).doModal()
                except Exception:
                    # Awaryjny fallback dla nietypowych skórek/instalacji, w
                    # których Kodi odmówi załadowania naszego XML-a.  Także tu
                    # pokazuj wyłącznie wybieralne pliki, bez nagłówków.
                    fflog_exc(1)
                    selectable = [
                        (pos, label)
                        for pos, (label, payload) in enumerate(rows)
                        if payload is not None
                    ]
                    selected = control.selectDialog(
                        [label for _pos, label in selectable],
                        heading='Telegram • wyniki wyszukiwania',
                    )
                    idx = selectable[selected][0] if selected is not None and selected >= 0 else -1
                if idx is None or idx < 0 or idx >= len(rows):
                    self.selection_cancelled = True
                    fflog('[TELEGRAM] result list closed without playback', 1)
                    return False
                selected = rows[idx][1]
                # Zielone opisy i czerwone kreski są tylko nagłówkami wizualnymi.
                if not selected:
                    continue
                # Rejestracja strumienia i pobranie pierwszych bajtów potrafią
                # zająć kilka–kilkanaście sekund. Pokaż użytkownikowi, że klik
                # został przyjęty, zanim zaczniemy kontakt z usługą proxy.
                try:
                    control.busy_dialog(True)
                except Exception:
                    pass
                return self.resolve(selected.get('url') or '')
        except Exception:
            fflog_exc(1)
            return None

    def resolve(self, url, **kwargs):
        try:
            self.selection_cancelled = False
            data = self._unpack(url)
            mode = data.get('mode') or ''
            if mode == 'select_cache':
                cached = self._load_selection_cache(data.get('cache_id') or '')
                if cached:
                    data.update(cached)
                return self._resolve_selected_result(data)
            if mode == 'select':
                return self._resolve_selected_result(data)
            if mode == 'mtproto':
                return self._resolve_mtproto(data)
            src = data.get('url') or ''
            if not src:
                return None
            headers = urlencode({
                'User-Agent': self.headers['User-Agent'],
                'Referer': data.get('referer') or 'https://t.me/',
                'Accept': '*/*',
                'Accept-Language': self.headers.get('Accept-Language', 'pl-PL,pl;q=0.9,en;q=0.7'),
                'Connection': 'keep-alive',
            })
            if '|' not in src:
                src = src + '|' + headers
            return src
        except Exception:
            fflog_exc(1)
            return None

    def _chat_filter_path(self):
        try:
            return os.path.join(self._session_dir(), 'chat_filter.json')
        except Exception:
            return os.path.join(control.dataPath, 'telegram_chat_filter.json')

    def _load_chat_filter(self):
        try:
            path = self._chat_filter_path()
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as fh:
                    data = json.load(fh) or {}
            else:
                data = {}
        except Exception:
            data = {}
        try:
            if not isinstance(data.get('chats'), list):
                data['chats'] = []
            ids = data.get('selected_ids') or []
            data['selected_ids'] = [str(x) for x in ids if str(x).strip()]
        except Exception:
            data = {'chats': [], 'selected_ids': []}
        return data

    def _save_chat_filter(self, data):
        try:
            if not isinstance(data, dict):
                data = {}
            data.setdefault('chats', [])
            data.setdefault('selected_ids', [])
            data['saved'] = int(time.time())
            path = self._chat_filter_path()
            folder = os.path.dirname(path)
            if folder and not os.path.exists(folder):
                try:
                    control.makeDirs(folder)
                except Exception:
                    os.makedirs(folder, exist_ok=True)
            with open(path, 'w', encoding='utf-8') as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2, sort_keys=True)
            return True
        except Exception:
            fflog_exc(1)
            return False

    def _chat_filter_mode_name(self):
        try:
            return ['all', 'selected', 'excluded'][int(self.chat_filter_mode or 0)]
        except Exception:
            return 'all'

    def _selected_chat_ids(self):
        try:
            data = self._load_chat_filter()
            return set([str(x) for x in (data.get('selected_ids') or []) if str(x).strip()])
        except Exception:
            return set()

    def _clean_chat_filter_text(self, value, max_len=90):
        """Minimal cleanup for Telegram chat/channel names in Kodi UI.

        Keep the name as close as possible to Telegram.  Only remove Kodi markup
        and control/newline characters that can break settings lists.
        """
        try:
            text = str(value or '')
            text = unescape(text)
            text = text.replace('[CR]', ' ').replace('\r', ' ').replace('\n', ' ').replace('\t', ' ')
            text = re.sub(r'\[(?:/?(?:COLOR|B|I|LIGHT|UPPERCASE)|COLOR\s+[^\]]+)\]', '', text, flags=re.I)
            cleaned = []
            for ch in text:
                cat = unicodedata.category(ch)
                if cat in ('Cc', 'Cf', 'Cs', 'Cn'):
                    continue
                cleaned.append(ch)
            text = ''.join(cleaned)
            text = text.replace('＠', '@').replace('﹫', '@')
            text = re.sub(r'\s+', ' ', text).strip()
            if max_len and text and len(text) > int(max_len):
                text = text[:int(max_len) - 1].rstrip() + '…'
            return text
        except Exception:
            try:
                return re.sub(r'\s+', ' ', str(value or '')).strip()
            except Exception:
                return ''

    def _chat_filter_display_label(self, ch):
        try:
            cid = self._clean_chat_filter_text(ch.get('id') or '', 40)
            username = self._clean_chat_filter_text(ch.get('username') or '', 50).lstrip('@')
            title = self._clean_chat_filter_text(ch.get('title') or '', 70)
            kind = self._clean_chat_filter_text(ch.get('kind') or 'grupa/kanał', 18) or 'grupa/kanał'

            # Normal, predictable format requested by user:
            # "Nazwa (@username) (kanał/grupa/tematy)".
            # Do not try to outsmart decorative Telegram titles here; display them
            # as Telegram reports them.  If there is no readable title, fall back
            # to @username or ID.
            if title and username and username.lower() not in title.lower().replace('@', ''):
                label = '%s (@%s) (%s)' % (title, username, kind)
            elif title:
                label = '%s (%s)' % (title, kind)
            elif username:
                label = '@%s (%s)' % (username, kind)
            else:
                label = 'ID %s (%s)' % (cid or '?', kind)
            return re.sub(r'\s+', ' ', label).strip()
        except Exception:
            return str(ch.get('title') or ch.get('username') or ch.get('id') or '')

    def _chat_filter_item_from_dialog(self, d):
        try:
            ent = getattr(d, 'entity', None)
            if not ent:
                return None
            eid = int(getattr(ent, 'id', 0) or 0)
            if not eid:
                return None
            if not (getattr(d, 'is_channel', False) or getattr(d, 'is_group', False) or self._is_group_channel(ent)):
                return None
            username = ''
            try:
                username = getattr(ent, 'username', None) or ''
            except Exception:
                username = ''
            username = self._clean_chat_filter_text(username, 60).lstrip('@')
            raw_title = getattr(d, 'name', None) or getattr(ent, 'title', None) or ''
            title = self._clean_chat_filter_text(raw_title, 90)
            if not title:
                title = ('@%s' % username) if username else str(eid)
            kind = 'kanał' if getattr(d, 'is_channel', False) and not getattr(d, 'is_group', False) else 'grupa'
            try:
                if getattr(ent, 'forum', False):
                    kind += ' / tematy'
            except Exception:
                pass
            return {
                'id': str(eid),
                'title': str(title or '').strip() or str(eid),
                'username': str(username or '').strip(),
                'kind': kind,
                'score': int(self._chat_scan_score(title) or 0),
            }
        except Exception:
            return None

    def _collect_chat_filter_dialogs(self, client, limit=1000, progress=None):
        chats = []
        seen = set()
        scanned = 0
        try:
            for d in client.iter_dialogs(limit=int(limit or 1000)):
                scanned += 1
                if progress and scanned % 5 == 0:
                    try:
                        if hasattr(progress, 'iscanceled') and progress.iscanceled():
                            break
                        pct = min(90, 10 + int(scanned * 80 / max(80, int(limit or 1000))))
                        progress.update(pct, 'Sprawdzam grupy/kanały Telegram…\nZnaleziono: %s' % len(chats))
                    except Exception:
                        pass
                item = self._chat_filter_item_from_dialog(d)
                if not item:
                    continue
                eid = item.get('id') or ''
                if not eid or eid in seen:
                    continue
                seen.add(eid)
                chats.append(item)
        except Exception:
            fflog_exc(1)
        try:
            chats = sorted(chats, key=lambda x: (str(x.get('title') or '').lower(), str(x.get('id') or '')))
        except Exception:
            pass
        return chats

    def refresh_chat_filter_list_from_settings(self):
        progress = None
        try:
            try:
                progress = control.progressDialog
                progress.create('Telegram', 'Łączę z kontem Telegram…')
                progress.update(0, 'Pobieram listę grup/kanałów…')
            except Exception:
                progress = None
            client = self._get_client(interactive=False)
            if not (client and client.is_user_authorized()):
                try:
                    if progress:
                        progress.close()
                except Exception:
                    pass
                control.infoDialog('Telegram: najpierw zaloguj konto', heading='Telegram', icon='WARNING', time=5000, sound=False)
                try:
                    _tg_safe_disconnect(client)
                except Exception:
                    pass
                return False
            try:
                if progress:
                    progress.update(10, 'Odświeżam listę grup/kanałów…')
            except Exception:
                pass
            chats = self._collect_chat_filter_dialogs(client, limit=1000, progress=progress)
            try:
                if progress:
                    progress.update(92, 'Zapisuję listę grup/kanałów…')
            except Exception:
                pass
            _tg_safe_disconnect(client)
            data = self._load_chat_filter()
            old_selected = set([str(x) for x in data.get('selected_ids') or []])
            available = set([str(x.get('id')) for x in chats])
            data['chats'] = chats
            data['selected_ids'] = sorted([x for x in old_selected if x in available])
            self._save_chat_filter(data)
            try:
                if progress:
                    progress.update(100, 'Odświeżono: %s grup/kanałów' % len(chats))
                    control.sleep(250)
                    progress.close()
            except Exception:
                pass
            control.infoDialog('Telegram: odświeżono listę grup/kanałów (%s)' % len(chats), heading='Telegram', time=4500, sound=False)
            return True
        except Exception:
            fflog_exc(1)
            try:
                if progress:
                    progress.close()
            except Exception:
                pass
            control.infoDialog('Telegram: nie udało się odświeżyć listy grup/kanałów', heading='Telegram', icon='WARNING', time=5500, sound=False)
            return False

    def choose_chat_filter_from_settings(self):
        try:
            data = self._load_chat_filter()
            chats = data.get('chats') or []
            if not chats:
                if not self.refresh_chat_filter_list_from_settings():
                    return False
                data = self._load_chat_filter()
                chats = data.get('chats') or []
            if not chats:
                control.infoDialog('Telegram: brak grup/kanałów do wyboru', heading='Telegram', icon='WARNING', time=4500, sound=False)
                return False
            selected = set([str(x) for x in data.get('selected_ids') or []])
            labels = []
            preselect = []
            for idx, ch in enumerate(chats):
                labels.append(self._chat_filter_display_label(ch))
                if str(ch.get('id') or '') in selected:
                    preselect.append(idx)
            mode = self._chat_filter_mode_name()
            if mode == 'selected':
                heading = 'Telegram: zaznacz grupy/kanały do przeszukiwania'
            elif mode == 'excluded':
                heading = 'Telegram: zaznacz grupy/kanały do wykluczenia'
            else:
                heading = 'Telegram: wybór zapisany, aktywny po zmianie trybu'
            try:
                picked = control.dialog.multiselect(heading, labels, preselect=preselect)
            except TypeError:
                picked = control.dialog.multiselect(heading, labels)
            if picked is None:
                return False
            new_ids = []
            for idx in picked:
                try:
                    new_ids.append(str(chats[int(idx)].get('id') or ''))
                except Exception:
                    pass
            data['selected_ids'] = sorted([x for x in new_ids if x])
            self._save_chat_filter(data)
            if mode == 'selected':
                msg = 'Telegram: wybrano %s grup/kanałów do przeszukiwania' % len(data['selected_ids'])
            elif mode == 'excluded':
                msg = 'Telegram: wykluczono %s grup/kanałów z przeszukiwania' % len(data['selected_ids'])
            else:
                msg = 'Telegram: zapisano wybór (%s). Zmień tryb na wybrane/wykluczone, żeby go użyć.' % len(data['selected_ids'])
            control.infoDialog(msg, heading='Telegram', time=5500, sound=False)
            return True
        except Exception:
            fflog_exc(1)
            control.infoDialog('Telegram: nie udało się zapisać wyboru grup/kanałów', heading='Telegram', icon='WARNING', time=5500, sound=False)
            return False

    def clear_chat_filter_from_settings(self):
        try:
            data = self._load_chat_filter()
            data['selected_ids'] = []
            self._save_chat_filter(data)
            control.infoDialog('Telegram: wyczyszczono wybór grup/kanałów', heading='Telegram', time=4000, sound=False)
            return True
        except Exception:
            fflog_exc(1)
            control.infoDialog('Telegram: nie udało się wyczyścić wyboru grup/kanałów', heading='Telegram', icon='WARNING', time=5000, sound=False)
            return False

    def login_from_settings(self):
        """Manual Telegram login launched from addon settings action button."""
        try:
            if not self._api_credentials_ready():
                control.infoDialog('Uzupełnij API ID i API HASH Telegram', heading='Telegram', icon='WARNING', time=6000, sound=False)
                return False
            choice = control.selectDialog([
                'Wyślij kod do czatu Telegram i zaloguj',
                'Zaloguj kodem QR',
                'Sprawdź aktualną sesję',
                'Wyczyść zapisaną sesję',
            ], heading='Telegram')
            if choice < 0:
                return False
            if choice == 3:
                return self.clear_session_from_settings()
            if choice == 2:
                client = self._get_client(interactive=False)
                ok = bool(client and client.is_user_authorized())
                _tg_safe_disconnect(client)
                control.infoDialog('Telegram: zalogowany' if ok else 'Telegram: nie zalogowano', heading='Telegram', icon=('INFO' if ok else 'WARNING'), time=5000, sound=False)
                return ok
            if choice == 1:
                return self._login_qr_from_settings()

            old_qr = self.qr_login
            old_login = self.login_on_search
            try:
                self.qr_login = False
                self.login_on_search = True
                client = self._get_client(interactive=True)
                ok = bool(client and client.is_user_authorized())
                if ok:
                    control.infoDialog('Telegram zalogowany', heading='Telegram', time=3500, sound=False)
                _tg_safe_disconnect(client)
                return ok
            finally:
                self.qr_login = old_qr
                self.login_on_search = old_login
        except BaseException:
            fflog_exc(1)
            control.infoDialog('Telegram login nieudany - sprawdź log', heading='Telegram', icon='WARNING', time=6000, sound=False)
            return False

    def login_code_from_settings(self):
        """Interactive login using API ID, API HASH, phone and Telegram code."""
        try:
            if not (self._api_credentials_ready() and self.phone):
                control.infoDialog(
                    'Uzupełnij API ID, API HASH i numer telefonu Telegram (z kodem kraju, np. +48).',
                    heading='Telegram', icon='WARNING', time=6500, sound=False
                )
                return False
            old_qr = self.qr_login
            old_login = self.login_on_search
            try:
                self.qr_login = False
                self.login_on_search = True
                client = self._get_client(interactive=True)
                ok = bool(client and client.is_user_authorized())
                if ok:
                    control.infoDialog('Telegram zalogowany', heading='Telegram', time=3500, sound=False)
                _tg_safe_disconnect(client)
                return ok
            finally:
                self.qr_login = old_qr
                self.login_on_search = old_login
        except BaseException:
            fflog_exc(1)
            control.infoDialog('Telegram: logowanie kodem nieudane — sprawdź log', heading='Telegram', icon='WARNING', time=6500, sound=False)
            return False

    def login_qr_from_settings(self):
        """Public settings action for QR login."""
        try:
            if not (int(self.api_id or 0) and self.api_hash):
                control.infoDialog('Uzupełnij API ID i API HASH Telegram', heading='Telegram', icon='WARNING', time=5500, sound=False)
                return False
        except Exception:
            control.infoDialog('API ID Telegram musi być liczbą', heading='Telegram', icon='WARNING', time=5500, sound=False)
            return False
        return self._login_qr_from_settings()

    def check_session_from_settings(self):
        """Check saved Telegram session without starting a new login."""
        client = None
        try:
            if not (int(self.api_id or 0) and self.api_hash):
                control.infoDialog('Uzupełnij API ID i API HASH Telegram', heading='Telegram', icon='WARNING', time=5500, sound=False)
                return False
            TelegramClient, errors, _, _, _ = _tg_telethon_imports()
            if not TelegramClient:
                control.infoDialog('Brak biblioteki Telethon w dodatku', heading='Telegram', icon='WARNING', time=5000, sound=False)
                return False
            loop = _tg_ensure_event_loop()
            _tg_patch_telethon_helpers()
            try:
                asyncio.set_event_loop(loop)
            except Exception:
                pass
            client = TelegramClient(
                self._session_path(), int(self.api_id), self.api_hash, loop=loop,
                base_logger=_TG_TELETHON_LOGGER,
            )
            client.connect()
            ok = bool(client.is_user_authorized())
            control.infoDialog(
                'Telegram: sesja jest zalogowana' if ok else 'Telegram: brak aktywnej sesji',
                heading='Telegram', icon=('INFO' if ok else 'WARNING'), time=5000, sound=False
            )
            return ok
        except BaseException:
            fflog_exc(1)
            control.infoDialog('Telegram: nie udało się sprawdzić sesji', heading='Telegram', icon='WARNING', time=6000, sound=False)
            return False
        finally:
            _tg_safe_disconnect(client)

    def clear_session_from_settings(self):
        try:
            self._delete_session_files()
            self._forget_session_phone()
            control.infoDialog('Sesja Telegram wyczyszczona', heading='Telegram', time=4000, sound=False)
            return True
        except Exception:
            fflog_exc(1)
            control.infoDialog('Nie udało się wyczyścić sesji Telegram', heading='Telegram', icon='WARNING', time=5000, sound=False)
            return False

    def _login_qr_from_settings(self):
        client = None
        try:
            TelegramClient, errors, _, _, _ = _tg_telethon_imports()
            if not TelegramClient:
                control.infoDialog('Brak Telethon w dodatku', heading='Telegram', icon='WARNING', time=3500, sound=False)
                return False
            api_id = int(self.api_id or 0)
            api_hash = self.api_hash
            if not (api_id and api_hash):
                control.infoDialog('Uzupełnij api_id i api_hash Telegram', heading='Telegram', icon='WARNING', time=5500, sound=False)
                return False
            self._delete_session_files()
            loop = _tg_ensure_event_loop()
            _tg_patch_telethon_helpers()
            try:
                asyncio.set_event_loop(loop)
            except Exception:
                pass
            session_path = self._session_path()
            client = TelegramClient(
                session_path, api_id, api_hash, loop=loop,
                base_logger=_TG_TELETHON_LOGGER,
            )
            client.connect()
            if client.is_user_authorized():
                control.infoDialog('Telegram już jest zalogowany', heading='Telegram', time=3500, sound=False)
                return True
            client, ok = self._qr_login_with_dc_retry(client, session_path, api_id, api_hash, loop, errors)
            if ok:
                if self.phone:
                    self._save_session_phone(self.phone)
                else:
                    self._forget_session_phone()
                control.infoDialog('Telegram zalogowany przez QR', heading='Telegram', time=3500, sound=False)
            return bool(ok)
        except BaseException as exc:
            if self._is_api_id_invalid(exc, errors if 'errors' in locals() else None):
                self._show_api_id_invalid()
                return False
            fflog_exc(1)
            control.infoDialog('Telegram QR login nieudany - sprawdź log', heading='Telegram', icon='WARNING', time=6000, sound=False)
            return False
        finally:
            _tg_safe_disconnect(client)

    # ------------------------------------------------------------------ #
    # MTProto / account dialogs                                           #
    # ------------------------------------------------------------------ #

    def _api_credentials_ready(self):
        try:
            return bool(int(self.api_id or 0) and self.api_hash)
        except Exception:
            return False

    def _has_saved_session(self):
        """Return True when a reusable Telethon SQLite session exists."""
        try:
            path = self._session_base() + '.session'
            return os.path.isfile(path) and os.path.getsize(path) > 0
        except Exception:
            return False

    def _mtproto_ready(self):
        # QR login is deliberately phone-less. Authorization is verified by
        # _get_client(), so an existing session is sufficient for searching.
        return bool(self._api_credentials_ready() and (self.phone or self._has_saved_session()))

    def _extract_channel_hint(self, text):
        try:
            text = str(text or '')
            # Często nazwa grupy jest dopisana w podpisie/pliku jako @KANAL.
            handles = re.findall(r'(?<![A-Za-z0-9_])@([A-Za-z0-9_]{3,64})', text)
            if handles:
                return '@' + handles[0]
        except Exception:
            pass
        return ''

    def _clean_filename_label(self, value, limit=96):
        try:
            value = os.path.basename(str(value or '').replace('\\', '/'))
            value = unescape(value)
            value = re.sub(r'[\r\n\t]+', ' ', value)
            value = re.sub(r'\s+', ' ', value).strip(' ._-')
            return value[:limit]
        except Exception:
            return ''

    def _best_filename_label(self, msg_dict):
        try:
            fn = self._clean_filename_label((msg_dict or {}).get('filename') or '')
            if fn:
                return fn
            text = str((msg_dict or {}).get('text') or '')
            text = re.sub(r'(?<![A-Za-z0-9_])@[A-Za-z0-9_]{3,64}', ' ', text)
            text = re.sub(r'https?://\S+', ' ', text, flags=re.I)
            text = re.sub(r'[\r\n\t]+', ' ', text)
            text = re.sub(r'\s+', ' ', text).strip(' ._-')
            return self._clean_filename_label(text, limit=140)
        except Exception:
            return ''

    def _tg_chat_label(self, title, text=''):
        chat = self._display_chat_title(title)
        if not chat or chat.lower() == 'telegram':
            hint = self._extract_channel_hint(text)
            if hint:
                chat = hint
        return chat or 'Telegram'

    def _message_text_blob(self, msg):
        try:
            m = self._message_dict_from_mtproto(msg, '', '')
            return ' '.join([m.get('filename') or '', m.get('text') or ''])
        except Exception:
            try:
                return ' '.join([
                    str(getattr(getattr(msg, 'file', None), 'name', '') or ''),
                    str(getattr(msg, 'message', '') or ''),
                ])
            except Exception:
                return ''

    def _message_contains_query(self, msg, query):
        """Require the searched title word/phrase to be present in the result.

        Telegram's account-wide search can return fuzzy/broad hits, so a hit must
        contain the query we actually sent.  Do not apply a separate stop-word or
        case rule here: if a word is the selected PL/DE title word (even From/Ted),
        it is allowed.  For combined series queries every token must be present,
        e.g. "Stamtąd S04E10".
        """
        try:
            q = re.sub(r'\s+', ' ', str(query or '')).strip()
            if not q:
                return True
            blob = self._message_text_blob(msg)
            if not blob:
                return False

            tokens = re.findall(r'[0-9A-Za-ząćęłńóśżźĄĆĘŁŃÓŚŻŹÄÖÜäöüß]{2,}', q, flags=re.I)
            if not tokens:
                return True
            raw_blob = str(blob or '')
            folded_blob = self._ascii_fold(raw_blob).lower()
            norm_blob = title_matcher.normalize(raw_blob)

            for tok in tokens:
                t = str(tok or '').strip()
                if not t:
                    continue
                # Whole-token match first. This keeps short real titles valid
                # (Ted, From, It) while still rejecting random fuzzy results that
                # do not contain the searched word at all.
                pat = r'(?<![0-9A-Za-z])%s(?![0-9A-Za-z])' % re.escape(t)
                if re.search(pat, raw_blob, re.I):
                    continue
                tf = self._ascii_fold(t).lower()
                if tf:
                    pat_f = r'(?<![0-9A-Za-z])%s(?![0-9A-Za-z])' % re.escape(tf)
                    if re.search(pat_f, folded_blob, re.I):
                        continue
                nt = title_matcher.normalize(t)
                if nt and nt in norm_blob:
                    continue
                return False
            return True
        except Exception:
            return False

    def _header_text_from_message(self, msg, chat_title='', ref=''):
        try:
            m = self._message_dict_from_mtproto(msg, chat_title, ref)
            txt = m.get('text') or m.get('filename') or ''
            txt = re.sub(r'(?<![A-Za-z0-9_])@[A-Za-z0-9_]{3,64}', ' ', txt)
            txt = re.sub(r'https?://\S+', ' ', txt, flags=re.I)
            txt = re.sub(r'[\r\n\t]+', ' ', txt)
            txt = re.sub(r'\s+', ' ', txt).strip(' ._-')
            return txt[:260]
        except Exception:
            return ''

    def _series_episode_conflict(self, blob, data):
        """Return True when a Telegram hit is clearly another episode.

        We still allow unnamed/garbled files, but if the file/message contains
        an explicit SxxEyy / 1x13 / E13 token that does not match the requested
        episode, it must not be shown as a source for the current episode.
        """
        try:
            if (data or {}).get('kind') != 'series':
                return False
            s = int((data or {}).get('season') or 0)
            e = int((data or {}).get('episode') or 0)
            if s <= 0 or e <= 0:
                return False
            txt = self._ascii_fold(str(blob or ''))
            if not txt:
                return False

            pairs = []
            for a, b in re.findall(r'(?i)\bS\s*0?(\d{1,3})\s*[\._\-\s]*E\s*0?(\d{1,3})\b', txt):
                try:
                    pairs.append((int(a), int(b)))
                except Exception:
                    pass
            for a, b in re.findall(r'(?i)\b0?(\d{1,3})\s*x\s*0?(\d{1,3})\b', txt):
                try:
                    pairs.append((int(a), int(b)))
                except Exception:
                    pass

            if pairs:
                return not any((ps == s and pe == e) for ps, pe in pairs)

            # Plain E-number without season is weaker, but if it is explicit and
            # different, it is almost certainly another episode.
            eps = []
            for b in re.findall(r'(?i)(?:^|[^\w])E\s*0?(\d{1,3})(?:[^\w]|$)', txt):
                try:
                    eps.append(int(b))
                except Exception:
                    pass
            if eps and not any(pe == e for pe in eps):
                return True
            return False
        except Exception:
            return False

    def _series_episode_match_level(self, blob, data):
        """Return 3 for SxxEyy/1x02, 2 for Exx, 0 unknown, -1 conflict."""
        try:
            if (data or {}).get('kind') != 'series':
                return 0
            s = int((data or {}).get('season') or 0)
            e = int((data or {}).get('episode') or 0)
            if s <= 0 or e <= 0:
                return 0
            text = self._ascii_fold(str(blob or ''))
            pairs = []
            for a, b in re.findall(r'(?i)\bS\s*0?(\d{1,3})\s*[\._\-\s]*E\s*0?(\d{1,3})\b', text):
                pairs.append((int(a), int(b)))
            for a, b in re.findall(r'(?i)\b0?(\d{1,3})\s*x\s*0?(\d{1,3})\b', text):
                pairs.append((int(a), int(b)))
            if pairs:
                return 3 if (s, e) in pairs else -1
            episodes = [int(v) for v in re.findall(r'(?i)(?:^|[^\w])E\s*0?(\d{1,3})(?:[^\w]|$)', text)]
            if episodes:
                return 2 if e in episodes else -1
            return 0
        except Exception:
            return 0

    def _movie_year_conflict(self, blob, data):
        """Reject only a clearly different release year, not a numeric title."""
        try:
            if (data or {}).get('kind') != 'movie':
                return False
            wanted = str((data or {}).get('year') or '').strip()
            if not re.fullmatch(r'(?:19|20)\d{2}', wanted):
                return False
            years = set(re.findall(r'(?<!\d)((?:19|20)\d{2})(?!\d)', str(blob or '')))
            if not years or wanted in years:
                return False
            title_years = set()
            for variant in self._wanted_variants(data, max_items=18):
                title_years.update(re.findall(r'(?<!\d)((?:19|20)\d{2})(?!\d)', str(variant or '')))
            release_years = years - title_years
            return bool(release_years and wanted not in release_years)
        except Exception:
            return False

    def _telegram_result_score(self, blob, data, query='', query_rank=99, parent_header=None):
        """Rank broad Telegram hits without hiding uncertain filenames."""
        try:
            header_text = ''
            if isinstance(parent_header, dict):
                header_text = str(parent_header.get('text') or '')
            lookup = ' '.join([str(blob or ''), header_text]).strip()
            variants = self._wanted_variants(data, max_items=18)
            title_score = max([title_matcher.score(lookup, v) for v in variants if v] or [0])
            score = int(round(title_score))
            compact_lookup = title_matcher.compact(lookup)
            if any(
                (cv := title_matcher.compact(v)) and len(cv) >= 4 and cv in compact_lookup
                for v in variants
            ):
                score += 30
            if query:
                query_tokens = [self._ascii_fold(x).lower() for x in re.findall(r'[\wÄÖÜäöüß]+', str(query), re.UNICODE)]
                folded = self._ascii_fold(lookup).lower()
                if query_tokens and all(token in folded for token in query_tokens):
                    score += 15
            try:
                score += max(0, 8 - min(8, int(query_rank or 0)))
            except Exception:
                pass
            if (data or {}).get('kind') == 'movie':
                wanted_year = str((data or {}).get('year') or '').strip()
                if wanted_year and re.search(r'(?<!\d)%s(?!\d)' % re.escape(wanted_year), lookup):
                    score += 25
            elif (data or {}).get('kind') == 'series':
                level = self._series_episode_match_level(lookup, data)
                if level == 3:
                    score += 70
                elif level == 2:
                    score += 45
                if parent_header:
                    score += 20
            return score
        except Exception:
            return 0

    def _effective_min_file_size(self, data):
        try:
            # 300 MB is good for movies, but sitcom/animation episodes often sit
            # around 150-300 MB.  Keeping 300 for every episode hid e.g. Ted.
            # Still blocks thumbnails/samples/2-3 MB junk.
            if (data or {}).get('kind') == 'series':
                return int(getattr(self, 'min_series_file_size', 0) or 0)
            return int(getattr(self, 'min_file_size', 0) or 0)
        except Exception:
            return int(getattr(self, 'min_file_size', 0) or 0)

    def _append_mtproto_source(self, out, msg, ent, title, ref, data, seen=None, force_match=False,
                               parent_header=None, match_query='', query_rank=99):
        try:
            if not self._message_has_video_file(msg):
                return False
            size_bytes = self._message_file_size(msg)
            _min_file_size = self._effective_min_file_size(data)
            if _min_file_size and size_bytes and size_bytes < _min_file_size:
                return False
            m = self._message_dict_from_mtproto(msg, title, ref)
            try:
                _blob_for_ep = ' '.join([m.get('filename') or '', m.get('text') or '', m.get('message_url') or ''])
                # Always reject a clearly different episode/year. Unnamed files
                # remain allowed, especially when attached to a matched poster.
                episode_level = self._series_episode_match_level(_blob_for_ep, data)
                if episode_level < 0 or self._movie_year_conflict(_blob_for_ep, data):
                    return False
                # Optional strict mode additionally requires an explicit episode
                # token for direct hits. Poster/album children remain contextual.
                if self.strict_episode_match and (data or {}).get('kind') == 'series' and not parent_header and episode_level <= 0:
                    return False
            except Exception:
                pass
            if not force_match and not self._message_matches(m, data):
                return False
            message_id = int(getattr(msg, 'id', 0) or 0)
            chat_id = int(getattr(ent, 'id', 0) or getattr(msg, 'chat_id', 0) or 0)
            key = (chat_id, message_id)
            if seen is not None:
                if key in seen:
                    return False
                seen.add(key)
            chat_label = self._tg_chat_label(title, ' '.join([m.get('filename') or '', m.get('text') or '']))
            file_name = self._best_filename_label(m)
            peer_type = 'channel'
            try:
                cls_name = ent.__class__.__name__.lower()
                if 'chat' in cls_name and not getattr(ent, 'access_hash', None):
                    peer_type = 'chat'
                elif getattr(ent, 'broadcast', False):
                    peer_type = 'broadcast'
                elif getattr(ent, 'megagroup', False):
                    peer_type = 'megagroup'
            except Exception:
                pass
            doc_id = ''
            doc_access_hash = ''
            doc_file_reference = ''
            doc_dc_id = ''
            try:
                doc = getattr(getattr(msg, 'media', None), 'document', None)
                if doc:
                    doc_id = str(getattr(doc, 'id', '') or '')
                    doc_access_hash = str(getattr(doc, 'access_hash', '') or '')
                    ref_bytes = getattr(doc, 'file_reference', b'') or b''
                    if ref_bytes:
                        doc_file_reference = base64.urlsafe_b64encode(ref_bytes).decode('ascii').rstrip('=')
                    doc_dc_id = str(getattr(doc, 'dc_id', '') or '')
            except Exception:
                pass
            token = self._pack({
                'mode': 'mtproto',
                'chat_id': chat_id,
                'chat_ref': ref or '',
                'chat_title': chat_label,
                'message_id': message_id,
                'peer_type': peer_type,
                'access_hash': str(getattr(ent, 'access_hash', '') or ''),
                'api_id': int(self.api_id or 0),
                # api_hash itself is not stored in the token; resolve reads settings.
                'size': int(size_bytes or 0),
                'mime': getattr(getattr(msg, 'file', None), 'mime_type', None) or 'video/mp4',
                'filename': file_name or getattr(getattr(msg, 'file', None), 'name', None) or '',
                # Direct document location for fast Range playback; fallback still
                # uses chat_id/message_id when the file_reference expires.
                'doc_id': doc_id,
                'doc_access_hash': doc_access_hash,
                'doc_file_reference': doc_file_reference,
                'doc_dc_id': doc_dc_id,
            })
            _blob = ' '.join([m.get('filename') or '', m.get('text') or ''])
            _match_score = self._telegram_result_score(
                _blob, data, query=match_query, query_rank=query_rank, parent_header=parent_header
            )
            _src = {
                'provider': 'telegram',
                'source': chat_label,
                'quality': self._quality_from_text(_blob),
                'language': self._language_from_text(_blob),
                'url': token,
                'info': self._info_from_message(m, chat_label),
                'direct': True,
                'debridonly': False,
                'debrid': '',
                'filename': file_name,
                'premium': False,
                'size': m.get('size') or self._fmt_size(size_bytes),
                'telegram_date': m.get('date') or '',
                'telegram_message_id': str(message_id or ''),
                'telegram_match_score': int(_match_score or 0),
            }
            if parent_header:
                try:
                    _src['telegram_parent_header_id'] = str(parent_header.get('id') or '')
                    _src['telegram_parent_header_text'] = parent_header.get('text') or ''
                    _src['telegram_context_child'] = True
                except Exception:
                    pass
            out.append(_src)
            return True
        except Exception:
            fflog_exc(1)
            return False

    def _message_title_header_matches(self, msg, data, chat_title='', ref='', require_season=False):
        """Detect title/description posts that can act as a Telegram header.

        Channels often publish a poster/caption first and then put unnamed video
        files underneath it.  The search hits the caption, not the file, so the
        source has to scan the small block below that caption.
        """
        try:
            m = self._message_dict_from_mtproto(msg, chat_title, ref)
            blob = ' '.join([m.get('filename') or '', m.get('text') or ''])
            if not blob:
                return False

            raw_variants = self._wanted_variants(data, max_items=16)
            variants = []
            for v in raw_variants:
                for vv in ([v] + self._search_phrase_variants(v)):
                    vv = re.sub(r'\s+', ' ', str(vv or '')).strip(' ._-')
                    if vv and vv not in variants:
                        variants.append(vv)
            variants = variants[:36] or raw_variants

            score = max([title_matcher.score(blob, v) for v in variants if v] or [0])
            compact_blob = title_matcher.compact(blob)
            compact_hit = False
            for v in variants:
                cv = title_matcher.compact(v)
                if cv and len(cv) >= 8 and cv in compact_blob:
                    compact_hit = True
                    break
            if score < 55 and not compact_hit:
                return False

            nb = title_matcher.normalize(blob)
            if require_season:
                try:
                    s = int(data.get('season') or 1)
                    season_ok = bool(re.search(r'\b(?:s|season|sezon)\s*0?%d\b' % s, nb, re.I))
                except Exception:
                    season_ok = False
                return season_ok or ((score >= 84 or compact_hit) and not self._message_has_video_file(msg))

            # For movies the year is helpful, but not mandatory: many TG posts
            # have just a poster + Polish/German/English title and the file below.
            year = str((data or {}).get('year') or '').strip()
            year_ok = bool(year and re.search(r'(?<!\d)%s(?!\d)' % re.escape(year), blob))
            return year_ok or score >= 70 or compact_hit
        except Exception:
            return False

    def _series_header_matches(self, msg, data, chat_title='', ref=''):
        """Detect Telegram posts like "Szpital św. Anny sezon 1"."""
        try:
            if (data or {}).get('kind') != 'series':
                return False
            return self._message_title_header_matches(msg, data, chat_title, ref, require_season=True)
        except Exception:
            return False

    def _movie_header_matches(self, msg, data, chat_title='', ref=''):
        """Detect movie poster/caption posts with video files directly below."""
        try:
            if (data or {}).get('kind') != 'movie':
                return False
            if self._message_has_video_file(msg):
                return False
            return self._message_title_header_matches(msg, data, chat_title, ref, require_season=False)
        except Exception:
            return False

    def _context_child_allowed(self, msg, data):
        """Allow unnamed/garbled files under a matched poster, reject clear other titles.

        Poster-context scan exists for this pattern:
            poster/caption with the real title -> video messages below with no useful name.
        It must *not* attach a clearly named different movie/series, e.g. a
        "Zwierzogród 2" header followed by a file named "Troll 2 2025".
        """
        try:
            blob = self._message_text_blob(msg)
            blob = re.sub(r'\s+', ' ', str(blob or '')).strip()
            if not blob:
                return True

            # Series: explicit other SxxEyy/Eyy is always a conflict.
            if self._series_episode_conflict(blob, data):
                return False

            variants = []
            wanted_words = set()
            for v in self._wanted_variants(data, max_items=12):
                for vv in ([v] + self._search_phrase_variants(v)):
                    vv = re.sub(r'\s+', ' ', str(vv or '')).strip(' ._-')
                    if vv and vv not in variants:
                        variants.append(vv)
                    for w in re.findall(r'[A-Za-zĄĆĘŁŃÓŚŻŹąćęłńóśżźÄÖÜäöüß0-9]{3,}', vv, flags=re.I):
                        wanted_words.add(self._ascii_fold(w).lower())

            folded_blob = self._ascii_fold(blob).lower()
            norm_blob = title_matcher.normalize(blob)
            for v in variants:
                vf = self._ascii_fold(v).lower()
                vn = title_matcher.normalize(v)
                if (vf and len(vf) >= 4 and vf in folded_blob) or (vn and len(vn) >= 4 and vn in norm_blob):
                    return True

            kind = (data or {}).get('kind') or ''
            season = int((data or {}).get('season') or 0)
            episode = int((data or {}).get('episode') or 0)

            # For series, SxxEyy / Eyy / Odcinek yy under the correct header is expected.
            if kind == 'series':
                if season and episode:
                    if re.search(r'(?i)\bS0?%d\s*E0?%d\b' % (season, episode), blob):
                        return True
                    if re.search(r'(?i)\bE0?%d\b' % episode, blob):
                        return True
                    if re.search(r'(?i)\b(?:odcinek|odc|episode|ep)\.?\s*0?%d\b' % episode, blob):
                        return True
                if season and re.search(r'(?i)\bS0?%d\b' % season, blob):
                    return True

            clean = re.sub(r'\.[A-Za-z0-9]{2,5}$', '', blob)
            clean = re.sub(r'[_\\./\\[\\]\\(\\)\-]+', ' ', clean)
            words = re.findall(r'[A-Za-zĄĆĘŁŃÓŚŻŹąćęłńóśżźÄÖÜäöüß0-9]{2,}', clean, flags=re.I)
            lower_words = [self._ascii_fold(w).lower() for w in words]
            generic = set([
                'video','vid','movie','film','plik','file','document','telegram','odcinek','odc','episode','ep',
                'part','part1','part2','part3','cd1','cd2','cd3','disc1','disc2',
                'mkv','mp4','avi','xvid','x264','x265','h264','h265','hevc',
                '720p','1080p','2160p','4k','uhd','hdr','web','webrip','webdl',
                'bluray','brrip','dvdrip','proper','repack','aac','ac3','dts',
                'lektor','dubbing','napisy','pl','de','german','english','eng',
                'www','com','net','org','tv','dl','hd','sd','filmostrada','filmostradatv',
                'kino','vod','online','release','releases','rips','rip','p2p'
            ])
            content_words = [w for w in lower_words if w not in generic and not re.match(r'^\d+$', w)]

            # If there are no meaningful title-like words, this is exactly the
            # unnamed/technical child we want to keep.
            if not content_words:
                return True

            # Movie poster blocks should be strict. A named child that does not
            # contain the requested movie title is probably another movie.
            if kind == 'movie':
                if len(content_words) == 1:
                    w = content_words[0]
                    if w in wanted_words:
                        return True
                    # Allow a single long hash/random string, reject normal title
                    # words like "troll".
                    if len(w) >= 12:
                        vowels = len(re.findall(r'[aeiouyąęó]', w))
                        if float(vowels) / float(max(len(w), 1)) < 0.20:
                            return True
                    return False
                # Multiple meaningful words under a movie header look like a real
                # different filename/title, so reject.
                return False

            # Series may have odd package names; allow long random strings, but
            # reject normal named children not matching the title/episode.
            if len(content_words) <= 1:
                w = content_words[0] if content_words else ''
                if not w:
                    return True
                if len(w) >= 10:
                    vowels = len(re.findall(r'[aeiouyąęó]', w))
                    return float(vowels) / float(max(len(w), 1)) < 0.22
                return False

            joined = ''.join(content_words)
            if joined and len(joined) >= 14:
                vowels = len(re.findall(r'[aeiouyąęó]', joined))
                if float(vowels) / float(max(len(joined), 1)) < 0.20:
                    return True

            return False
        except Exception:
            # Safer default for context scan: if we cannot understand a named
            # child, do not attach it to the poster. Direct search can still find it.
            return False

    def _message_grouped_id(self, msg):
        try:
            gid = getattr(msg, 'grouped_id', None)
            if gid:
                return str(gid)
        except Exception:
            pass
        return ''

    def _reply_topic_id_from_message(self, msg):
        """Return a numeric Telegram forum-topic id, never the boolean forum flag.

        Telethon exposes reply_to.forum_topic as a bool in some cases. Older code
        treated True as topic id 1, which could incorrectly reject nearby files in
        real topic groups.  When the numeric top id is missing, be permissive and
        return 0 instead of inventing a topic.
        """
        try:
            rr = getattr(msg, 'reply_to', None)
            if not rr:
                return 0
            for attr in ('reply_to_top_id', 'top_msg_id'):
                val = getattr(rr, attr, None)
                if val and not isinstance(val, bool):
                    try:
                        return int(val)
                    except Exception:
                        pass
            return 0
        except Exception:
            return 0

    def _append_album_video_group(self, client, out, ent, title, ref, data, header_msg, seen=None, max_add=10, deadline=None):
        """Add video siblings from the same Telegram media album/group.

        Telegram often stores one visual post as a media album: poster/photo with
        caption + video tile in the same grouped_id. In the app it looks like one
        post, not "messages below". The older context scan only checked messages
        after/before the header, so album video siblings could be missed.
        """
        try:
            header_id = int(getattr(header_msg, 'id', 0) or 0)
            gid = self._message_grouped_id(header_msg)
            if not header_id or not gid or max_add <= 0:
                return 0
            if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                return 0
            # Album siblings are usually adjacent, but channels can insert several
            # media entries around the caption.  Use a wider radius; grouped_id
            # still keeps this safe.
            lo = max(1, header_id - 48)
            hi = header_id + 49
            msg_by_id = {}
            # Fetch album neighbours in small chunks. A single get_messages() over
            # 100+ ids was the reason 2.42.00 still showed scanned=1 for Szpital:
            # the first slow header could burn the entire poster budget.
            ids_all = list(range(lo, hi))
            chunk_size = 8
            for off in range(0, len(ids_all), chunk_size):
                if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                    break
                try:
                    chunk = ids_all[off:off + chunk_size]
                    msgs_chunk = client.get_messages(ent, ids=chunk) or []
                except Exception:
                    msgs_chunk = []
                try:
                    msgs_chunk = list(msgs_chunk)
                except Exception:
                    msgs_chunk = [msgs_chunk]
                for m in msgs_chunk:
                    if not m:
                        continue
                    try:
                        msg_by_id[int(getattr(m, 'id', 0) or 0)] = m
                    except Exception:
                        pass

            added = 0
            for near in [msg_by_id.get(i) for i in ids_all]:
                if not near:
                    continue
                try:
                    if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                        break
                    if added >= max_add:
                        break
                    if int(getattr(near, 'id', 0) or 0) == header_id:
                        continue
                    if self._message_grouped_id(near) != gid:
                        continue
                    if not self._message_has_video_file(near):
                        continue
                    if not self._context_child_allowed(near, data):
                        continue
                    parent_header = {
                        'id': header_id,
                        'text': self._header_text_from_message(header_msg, title, ref),
                    }
                    if self._append_mtproto_source(out, near, ent, title, ref, data, seen, force_match=True, parent_header=parent_header):
                        try:
                            self._diag('[telegram] album group match kind=%s header_id=%s video_msg=%s gid=%s' % ((data or {}).get('kind') or '', header_id, getattr(near, 'id', ''), gid))
                        except Exception:
                            pass
                        added += 1
                except Exception:
                    continue
            return added
        except Exception:
            fflog_exc(1)
            return 0

    def _append_nearby_video_block(self, client, out, ent, title, ref, data, header_msg, seen=None, max_scan=40, max_add=10, stop_on_new_header=True, allow_reverse_fallback=False, deadline=None):
        try:
            header_id = int(getattr(header_msg, 'id', 0) or 0)
            if not header_id or max_add <= 0:
                return 0
            header_topic = self._reply_topic_id_from_message(header_msg)

            def same_topic(m):
                # Be strict only when both sides expose a numeric topic id. If one
                # message only has forum_topic=True, do not treat True as id=1.
                try:
                    if not header_topic:
                        return True
                    top = self._reply_topic_id_from_message(m)
                    if not top:
                        return True
                    return int(top or 0) == int(header_topic or 0)
                except Exception:
                    return True

            def is_new_header(m):
                try:
                    if self._message_has_video_file(m):
                        return False
                    txt = (getattr(m, 'message', None) or '').strip()
                    if len(txt) < 20:
                        return False
                    if (data or {}).get('kind') == 'series':
                        return self._series_header_matches(m, data, title, ref)
                    return self._movie_header_matches(m, data, title, ref)
                except Exception:
                    return False

            if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                return 0

            def append_near(near, parent_header, added):
                try:
                    if added >= max_add:
                        return added
                    if int(getattr(near, 'id', 0) or 0) == header_id:
                        return added
                    if not same_topic(near):
                        return added
                    if not self._message_has_video_file(near):
                        return added
                    if not self._context_child_allowed(near, data):
                        return added
                    if self._append_mtproto_source(out, near, ent, title, ref, data, seen, force_match=True, parent_header=parent_header):
                        try:
                            self._diag('[telegram] context block match kind=%s header_id=%s video_msg=%s' % ((data or {}).get('kind') or '', header_id, getattr(near, 'id', '')))
                        except Exception:
                            pass
                        return added + 1
                except Exception:
                    pass
                return added

            parent_header = {
                'id': header_id,
                'text': self._header_text_from_message(header_msg, title, ref),
            }

            # Album/grouped_id first: required for posts like poster + video tile
            # (e.g. Krzyk 7). Keep it before the generic neighbour scan.
            album_added = self._append_album_video_group(client, out, ent, title, ref, data, header_msg, seen, max_add=max_add, deadline=deadline)
            added_total = int(album_added or 0)
            if added_total >= max_add:
                return added_total

            # 2.42.00: do not let one slow header consume the entire poster budget.
            # Telethon iter_messages(min_id=..., reverse=True) can block for many seconds
            # in large/closed topic groups.  For header/context posts the video files are
            # normally adjacent by message id, so fetch a bounded id window in chunks.
            # This restores the .88 behaviour for "Szpital św. Anny": several header
            # candidates are actually checked, instead of scanned=1 added=0.
            def scan_id_window(direction=1):
                added = 0
                try:
                    # Series blocks can contain a whole season, films usually only 1-3 files.
                    span = int(max_scan or 1)
                    if (data or {}).get('kind') == 'series':
                        span = max(span, 100)
                    else:
                        span = min(max(span, 16), 60)
                    span = min(span, 180)
                    ids = []
                    if direction >= 0:
                        ids = list(range(header_id + 1, header_id + span + 1))
                    else:
                        lo = max(1, header_id - span)
                        ids = list(range(header_id - 1, lo - 1, -1))
                    # Smaller chunks keep UI responsive and reduce the chance that a single
                    # RPC call burns all remaining context time.
                    chunk_size = 8
                    passed = 0
                    for off in range(0, len(ids), chunk_size):
                        if added_total + added >= max_add:
                            break
                        if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                            break
                        chunk = ids[off:off + chunk_size]
                        try:
                            msgs = client.get_messages(ent, ids=chunk) or []
                        except Exception:
                            msgs = []
                        try:
                            msgs = list(msgs)
                        except Exception:
                            msgs = [msgs]
                        # Preserve physical order under/above the header.
                        msg_by_id = {}
                        for m in msgs:
                            if m:
                                try:
                                    msg_by_id[int(getattr(m, 'id', 0) or 0)] = m
                                except Exception:
                                    pass
                        for mid in chunk:
                            if added_total + added >= max_add:
                                break
                            if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                                break
                            near = msg_by_id.get(int(mid))
                            if not near:
                                continue
                            if not same_topic(near):
                                continue
                            # Stop only after seeing actual non-video content past the header.
                            # Do not stop on the first unrelated poster if no video was seen yet;
                            # some Telegram posts insert images/text between caption and files.
                            if stop_on_new_header and passed and is_new_header(near):
                                break
                            passed += 1
                            before = added
                            added = append_near(near, parent_header, added)
                            # For movies, after one matching file, avoid accidentally pulling
                            # the next unrelated movie block. Series may continue collecting.
                            if (data or {}).get('kind') == 'movie' and added > before:
                                if added_total + added >= max_add:
                                    break
                    return added
                except Exception:
                    return added

            remaining_add = max(0, int(max_add or 0) - int(added_total or 0))
            if remaining_add > 0:
                old_max_add = max_add
                try:
                    max_add = remaining_add
                    # First scan messages after the header; then, if needed, the older side.
                    added_total += scan_id_window(direction=1)
                    if added_total < old_max_add and allow_reverse_fallback:
                        max_add = old_max_add - added_total
                        added_total += scan_id_window(direction=-1)
                finally:
                    max_add = old_max_add

            if added_total:
                return added_total

            # Do not use the old unbounded iter_messages fallback for series
            # headers. On large topic groups it can block inside Telethon longer than
            # our deadline can be checked, which is exactly what caused scanned=1.
            # Movies are protected by album + small id-window; keep a tiny fallback only
            # if there is still enough per-header time left.
            if (data or {}).get('kind') == 'series':
                return added_total

            def scan(reverse=True):
                added = 0
                passed = 0
                kwargs = {'limit': 8}
                if reverse:
                    kwargs.update({'min_id': header_id, 'reverse': True})
                else:
                    kwargs.update({'max_id': header_id})
                for near in client.iter_messages(ent, **kwargs):
                    try:
                        if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                            break
                        if added >= max_add:
                            break
                        if int(getattr(near, 'id', 0) or 0) == header_id:
                            continue
                        if not same_topic(near):
                            continue
                        if stop_on_new_header and passed and is_new_header(near):
                            break
                        passed += 1
                        added = append_near(near, parent_header, added)
                    except Exception:
                        continue
                return added

            remaining_add = max(0, int(max_add or 0) - int(added_total or 0))
            if remaining_add > 0 and (deadline is None or time.time() + 1.5 < float(deadline)):
                old_max_add = max_add
                try:
                    max_add = remaining_add
                    added_total += scan(reverse=True)
                    if added_total < old_max_add and allow_reverse_fallback and (deadline is None or time.time() + 1.5 < float(deadline)):
                        max_add = old_max_add - added_total
                        added_total += scan(reverse=False)
                finally:
                    max_add = old_max_add
            return added_total
        except Exception:
            fflog_exc(1)
            return 0

    def _append_series_nearby_videos(self, client, out, ent, title, ref, data, header_msg, seen=None, max_scan=80, max_add=30, deadline=None):
        try:
            if (data or {}).get('kind') != 'series' or not header_msg:
                return 0
            # Show a block of episodes below the matched header instead of only
            # guessing the requested episode number. The user wants broad raw TG
            # results and will choose manually.
            return self._append_nearby_video_block(client, out, ent, title, ref, data, header_msg, seen, max_scan=max_scan, max_add=max_add, stop_on_new_header=True, allow_reverse_fallback=True, deadline=deadline)
        except Exception:
            fflog_exc(1)
            return 0

    def _append_movie_nearby_videos(self, client, out, ent, title, ref, data, header_msg, seen=None, max_scan=40, max_add=3, deadline=None):
        try:
            if (data or {}).get('kind') != 'movie' or not header_msg:
                return 0
            # Movie posts are usually one file, sometimes CD1/CD2/CD3. Keep this
            # small so a poster hit does not pull an unrelated channel block.
            return self._append_nearby_video_block(client, out, ent, title, ref, data, header_msg, seen, max_scan=max_scan, max_add=max_add, stop_on_new_header=True, allow_reverse_fallback=True, deadline=deadline)
        except Exception:
            fflog_exc(1)
            return 0

    def _query_looks_german(self, value):
        try:
            v = str(value or '').lower()
            if re.search(r'[äöüß]', v):
                return True
            if self._looks_german_title(v):
                return True
            return bool(re.search(r'\b(?:drachen|zahmen|zaehmen|deutsch|german|filme|kino)\b', v, re.I))
        except Exception:
            return False

    def _sources_mtproto(self, data):
        out = []
        if self._cancelled():
            return out
        if not _tg_claim_search(self):
            return out
        client = self._get_client(interactive=self.login_on_search)
        if not client:
            if not self.login_on_search:
                fflog('[telegram] nie zalogowano - użyj przycisku w ustawieniach Telegram', 1)
            _tg_close_current_loop()
            _tg_release_search(self)
            return out
        try:
            # Szybka ścieżka: używamy serwerowego wyszukiwania Telegrama po koncie
            # (jak w aplikacji), ale KAŻDY wynik przepuszczamy przez mapę własnych
            # dialogów. Nie pokazujemy wyników spoza konta użytkownika.
            # Od 2.41.73 nie skanujemy od razu plików spod plakatów, bo to zjadało
            # cały timeout na pierwszym wariancie tytułu i blokowało np. DE wyniki.
            started = time.time()
            total_deadline = started + max(8.0, float(self.search_timeout or 65))

            def _remaining_total(reserve=0.0):
                try:
                    return max(0.0, float(total_deadline) - time.time() - float(reserve or 0.0))
                except Exception:
                    return 0.0

            queries = self._build_queries(data)
            targets = self._get_mtproto_targets(client)
            if not targets:
                fflog('[telegram] konto zalogowane, ale brak dialogów/kanałów do skanowania', 1)
                return out

            target_map = self._build_target_map(client, targets)
            seen = set()
            seen_headers = set()
            header_buckets = {}
            found_by_chat = {}

            max_queries = 10 if data.get('kind') == 'series' else 12
            # Kolejność jest istotna: seriale zaczynają od dokładnych kombinacji
            # PL/DE/EN + SxxEyy, potem przechodzą do szerokich słów tytułowych.
            # Filmy zachowują słowa PL/DE/EN jako główną metodę, a pełne frazy
            # są tylko krótkim pomocniczym ogonem. Bez losowych aliasów.
            queries_used = queries[:max_queries]
            # Niższy limit na pojedyncze zapytanie daje większą szerokość i zostawia czas
            # na pliki pod plakatami. Surowych wyników nadal nie filtrujemy po tytule.
            # Account-wide search is closest to the Telegram app search.  The old
            # per-query limit (~33) could miss valid hits that are slightly lower
            # in Telegram's ranking, e.g. a channel post with a poster/caption.
            # Keep it bounded, but let it use the configured search limit.
            # 2.42.21: nie pozwól, żeby pierwsze szerokie słowo (np. "Siedem")
            # zjadło cały szybki etap i zablokowało kolejne poprawne warianty
            # (np. "Pounds"). Każde zapytanie dostaje własny mały wycinek czasu.
            per_query_limit = min(max(40, int(self.search_limit or 100)), 150)
            # Account-wide search can block for a long time on broad words like
            # "Siedem".  Reserve real time for own-dialog/forum-topic fallback,
            # because the valid files are often inside topic groups.
            quick_budget = max(5.0, min(float(self.search_timeout) * (float(self.quick_budget_pct or 35) / 100.0), max(5.0, float(self.search_timeout) - 2.0)))
            quick_budget = min(quick_budget, _remaining_total(reserve=2.0))
            quick_deadline = time.time() + quick_budget
            quick_per_query_budget = max(4.0, min(12.0, (quick_budget / float(max(1, len(queries_used)))) + 1.0))
            _eff_min_mb = int(self._effective_min_file_size(data) / (1024 * 1024)) if self._effective_min_file_size(data) else 0
            self._diag('[telegram] szybkie wyszukiwanie po koncie, filtrowane do własnych dialogów; queries=%s targets=%s limit=%s min_size=%sMB quick_budget=%.1fs per_q=%.1fs max_results=%s max_per_chat=%s topic_budget=%ss topic_scan_limit=%s fallback_budget=%ss headers=%s context_budget=%ss' % (len(queries_used), len(targets), per_query_limit, _eff_min_mb, quick_budget, quick_per_query_budget, self.max_results, self.max_per_chat, self.topic_budget, self.topic_scan_limit, self.dialog_fallback_budget, self.max_context_headers, getattr(self, 'context_budget', 14)))
            try:
                self._diag('[telegram] zapytania: %s' % ', '.join([repr(q) for q in queries_used]))
            except Exception:
                pass

            def chat_key_for(ent, title):
                return str(getattr(ent, 'id', '') or title)

            def remember_header(q_idx, msg, ent, title, ref):
                try:
                    message_id = int(getattr(msg, 'id', 0) or 0)
                    chat_id = int(getattr(ent, 'id', 0) or getattr(msg, 'chat_id', 0) or 0)
                    if not message_id or not chat_id:
                        return False
                    key = (chat_id, message_id)
                    if key in seen_headers:
                        return False
                    if self._series_header_matches(msg, data, title, ref) or self._movie_header_matches(msg, data, title, ref):
                        seen_headers.add(key)
                        header_buckets.setdefault(int(q_idx or 0), []).append((msg, ent, title, ref))
                        return True
                except Exception:
                    pass
                return False

            def process_msg(q_idx, msg, ent, title, ref, collect_header=True, query=''):
                try:
                    # Nie ufaj ślepo serwerowemu searchowi Telegrama: wynik musi naprawdę
                    # zawierać aktualnie szukane słowo/frazę.  Dzięki temu nie wpadają
                    # losowe pliki z kanału, które nie mają nic wspólnego ze Stamtąd/FROM.
                    if query and not self._message_contains_query(msg, query):
                        if collect_header:
                            return 0
                        return 0
                    chat_key = chat_key_for(ent, title)
                    if found_by_chat.get(chat_key, 0) >= self.max_per_chat:
                        return 0
                    if self._append_mtproto_source(
                        out, msg, ent, title, ref, data, seen, force_match=True,
                        match_query=query, query_rank=q_idx,
                    ):
                        found_by_chat[chat_key] = found_by_chat.get(chat_key, 0) + 1
                        return 1
                    if collect_header:
                        remember_header(q_idx, msg, ent, title, ref)
                except Exception:
                    pass
                return 0

            # 1) Szybkie wyszukiwanie po koncie: najpierw zbieramy bezpośrednie
            # pliki i same nagłówki/plakaty. Kontekst spod plakatów skanujemy dopiero
            # po przejściu wszystkich wariantów PL/DE/EN.
            for q_idx, q in enumerate(queries_used):
                if self._cancelled() or len(out) >= self.max_results:
                    break
                if time.time() >= quick_deadline or _remaining_total(reserve=1.0) <= 0:
                    self._diag('[telegram] kończę szybki skan po %.1fs, zostawiam czas na plakaty/fallback' % (time.time() - started))
                    break
                query_deadline = min(quick_deadline, time.time() + quick_per_query_budget)
                q_added_before = len(out)
                q_headers_before = sum(len(v) for v in header_buckets.values())
                try:
                    for msg in client.iter_messages(None, search=q, limit=per_query_limit):
                        if self._cancelled() or len(out) >= self.max_results or time.time() >= query_deadline or time.time() >= quick_deadline:
                            break
                        target = self._target_for_message(msg, target_map)
                        if not target:
                            # Twardy filtr: żadnych wyników spoza dialogów konta.
                            continue
                        ent, title, ref = target
                        process_msg(q_idx, msg, ent, title, ref, collect_header=True, query=q)
                except Exception:
                    fflog_exc(1)
                    continue
                try:
                    q_headers_after = sum(len(v) for v in header_buckets.values())
                    self._diag('[telegram] quick query %r end; added=%s headers=%s elapsed=%.1fs' % (q, len(out)-q_added_before, q_headers_after-q_headers_before, time.time()-started))
                except Exception:
                    pass

            # 2) Krótki fallback po własnych dialogach. To przywraca zachowanie ze
            # starszych wersji dla kanałów/grup, których serwerowe account-search nie
            # zwraca wysoko. Priorytet mają niemieckie słowa, bo tam było widać regres.
            try:
                if len(out) < self.max_results and _remaining_total(reserve=1.0) > 0:
                    de_idxs = [i for i, q in enumerate(queries_used) if self._query_looks_german(q)]
                    first_idxs = list(range(min(5, len(queries_used))))
                    ordered_idxs = []
                    for i in first_idxs + de_idxs:
                        if i not in ordered_idxs:
                            ordered_idxs.append(i)
                    if ordered_idxs:
                        fallback_started = time.time()
                        fallback_budget = float(getattr(self, 'dialog_fallback_budget', 10) or 0)
                        if fallback_budget > 0:
                            fallback_budget = min(max(8.0, fallback_budget), _remaining_total(reserve=1.0))
                        if fallback_budget <= 0:
                            ordered_idxs = []
                        self._diag('[telegram] krótki fallback po własnych dialogach; query_idx=%s budget=%.1fs' % (ordered_idxs, fallback_budget))
                        # Fair fallback: dla każdego wysoko ocenionego dialogu spróbuj
                        # wszystkich zapytań krótko, zamiast mielić najpierw samo PL.
                        for ent, title, ref in targets:
                            if self._cancelled() or len(out) >= self.max_results or time.time() - fallback_started > fallback_budget or _remaining_total(reserve=0.5) <= 0:
                                break
                            chat_key = chat_key_for(ent, title)
                            if found_by_chat.get(chat_key, 0) >= self.max_per_chat:
                                continue
                            for q_idx in ordered_idxs:
                                if self._cancelled() or len(out) >= self.max_results or time.time() - fallback_started > fallback_budget or _remaining_total(reserve=0.5) <= 0:
                                    break
                                q = queries_used[q_idx]
                                try:
                                    for msg in client.iter_messages(ent, search=q, limit=min(max(6, int(self.search_limit or 100) // 12), 12)):
                                        if self._cancelled() or len(out) >= self.max_results or time.time() - fallback_started > fallback_budget or _remaining_total(reserve=0.5) <= 0:
                                            break
                                        process_msg(q_idx, msg, ent, title, ref, collect_header=True, query=q)
                                except Exception:
                                    continue
            except Exception:
                pass

            # 3) Teraz dopiero skanujemy pliki pod plakatami/nagłówkami. Kolejność
            # round-robin po zapytaniach chroni DE/EN przed zalaniem wynikami z PL.
            try:
                header_total = sum(len(v) for v in header_buckets.values())
                if header_total:
                    self._diag('[telegram] kandydaci nagłówków/plakatów=%s' % header_total)
                ordered_headers = []
                max_depth = max([len(v) for v in header_buckets.values()] or [0])
                for pos in range(max_depth):
                    for q_idx in range(len(queries_used)):
                        bucket = header_buckets.get(q_idx) or []
                        if pos < len(bucket):
                            ordered_headers.append(bucket[pos])
                scanned_headers = 0
                context_added = 0
                header_cap = int(self.max_context_headers or 32)
                if data.get('kind') == 'movie':
                    # 2.42.18: przywracamy zachowanie 2.42.16. Suwak głębokości
                    # dotyczy teraz wyłącznie skanu wiadomości w tematach/forum.
                    # Liczba skanowanych plakatów/nagłówków dla filmów zostaje
                    # na znanym, działającym kompromisie, żeby nie rozpraszać
                    # budżetu czasu na zbyt wiele kandydatów.
                    header_cap = min(header_cap, 24)
                context_started = time.time()
                remaining_for_context = _remaining_total(reserve=1.0)
                context_setting = float(getattr(self, 'context_budget', 18) or 0)
                if data.get('kind') == 'series' and context_setting > 0:
                    context_setting = max(18.0, context_setting)
                context_budget = min(context_setting, remaining_for_context)
                context_deadline = context_started + max(0.0, context_budget)
                if header_total:
                    self._diag('[telegram] budżet skanu plakatów/opisów: %.1fs cap=%s' % (context_budget, header_cap))
                for msg, ent, title, ref in ordered_headers:
                    if self._cancelled() or len(out) >= self.max_results or _remaining_total(reserve=0.2) <= 0 or time.time() >= context_deadline:
                        break
                    if scanned_headers >= header_cap:
                        break
                    chat_key = chat_key_for(ent, title)
                    remaining = max(0, self.max_per_chat - int(found_by_chat.get(chat_key, 0) or 0))
                    if remaining <= 0:
                        continue
                    added = 0
                    # Per-header guard: check more candidates shallowly instead of
                    # allowing the first slow poster to consume the whole context budget.
                    per_header = 3.2 if data.get('kind') == 'series' else 2.4
                    header_deadline = min(float(context_deadline), time.time() + per_header)
                    header_id_dbg = int(getattr(msg, 'id', 0) or 0)
                    try:
                        self._diag('[telegram] header scan start %s/%s id=%s chat=%s per=%.1fs' % (scanned_headers + 1, header_total, header_id_dbg, title, max(0.0, header_deadline - time.time())))
                    except Exception:
                        pass
                    h_started = time.time()
                    if self._series_header_matches(msg, data, title, ref):
                        added = self._append_series_nearby_videos(client, out, ent, title, ref, data, msg, seen, max_add=min(int(getattr(self, 'series_context_files', 30) or 0), remaining), deadline=header_deadline)
                    elif self._movie_header_matches(msg, data, title, ref):
                        added = self._append_movie_nearby_videos(client, out, ent, title, ref, data, msg, seen, max_add=min(int(getattr(self, 'movie_context_files', 3) or 0), remaining), deadline=header_deadline)
                    scanned_headers += 1
                    try:
                        self._diag('[telegram] header scan end id=%s added=%s elapsed=%.1fs' % (header_id_dbg, added, time.time() - h_started))
                    except Exception:
                        pass
                    if added:
                        context_added += int(added or 0)
                        found_by_chat[chat_key] = found_by_chat.get(chat_key, 0) + added
                if header_total:
                    self._diag('[telegram] skan plakatów/nagłówków: scanned=%s added=%s' % (scanned_headers, context_added))
            except Exception:
                pass

            # 4) Fallback dla tematów/forum. Część supergrup nie oddaje
            # wyników z topiców w zwykłym account-search.  Sprawdzamy wszystkie
            # własne dialogi-fora, nie tylko pierwszych kilkadziesiąt, ale pilnujemy
            # limitu czasu.
            if len(out) < self.max_results and _remaining_total(reserve=1.0) > 0:
                try:
                    topic_started = time.time()
                    topic_setting = float(getattr(self, 'topic_budget', 12) or 0)
                    topic_budget = min(max(10.0, topic_setting) if topic_setting > 0 else 0.0, _remaining_total(reserve=1.0))
                    topic_queries = queries_used[:min(5, len(queries_used))]
                    self._diag('[telegram] fallback topiców/forum; queries=%s targets=%s budget=%.1fs' % (len(topic_queries), len(targets), topic_budget))
                    # Fair topic fallback: nie mielimy wszystkich forów dla jednego
                    # szerokiego słowa. W każdym forum próbujemy kolejno PL/DE/EN.
                    for ent, title, ref in targets:
                        if self._cancelled() or len(out) >= self.max_results or _remaining_total(reserve=0.2) <= 0 or time.time() - topic_started > topic_budget:
                            break
                        if not getattr(ent, 'forum', False):
                            continue
                        chat_key = chat_key_for(ent, title)
                        if found_by_chat.get(chat_key, 0) >= self.max_per_chat:
                            continue
                        for q_idx, q in enumerate(topic_queries):
                            if self._cancelled() or len(out) >= self.max_results or _remaining_total(reserve=0.2) <= 0 or time.time() - topic_started > topic_budget:
                                break
                            added_topic = self._search_forum_topics(client, out, ent, title, ref, q, data, seen, found_by_chat.get(chat_key, 0), self.max_per_chat, deadline=min(topic_started + topic_budget, total_deadline))
                            if added_topic:
                                found_by_chat[chat_key] = found_by_chat.get(chat_key, 0) + added_topic
                except Exception:
                    pass

            # 3b) Krótki fallback po własnych dialogach, ale dopiero PO plakatach.
            # Używamy go głównie dla niemieckich zapytań i kanałów, których account-search
            # nie zwrócił wysoko.
            try:
                if len(out) < self.max_results and _remaining_total(reserve=1.0) > 0:
                    de_idxs = [i for i, q in enumerate(queries_used) if self._query_looks_german(q)]
                    first_idxs = list(range(min(5, len(queries_used))))
                    ordered_idxs = []
                    for i in first_idxs + de_idxs:
                        if i not in ordered_idxs:
                            ordered_idxs.append(i)
                    if ordered_idxs:
                        fallback_started = time.time()
                        remaining_total = _remaining_total(reserve=1.0)
                        fallback_budget = min(max(8.0, float(getattr(self, 'dialog_fallback_budget', 10) or 0)) if float(getattr(self, 'dialog_fallback_budget', 10) or 0) > 0 else 0.0, remaining_total)
                        if fallback_budget <= 0:
                            ordered_idxs = []
                        self._diag('[telegram] krótki fallback po własnych dialogach po plakatach; query_idx=%s budget=%.1fs' % (ordered_idxs, fallback_budget))
                        for ent, title, ref in targets:
                            if self._cancelled() or len(out) >= self.max_results or _remaining_total(reserve=0.2) <= 0 or time.time() - fallback_started > fallback_budget:
                                break
                            chat_key = chat_key_for(ent, title)
                            if found_by_chat.get(chat_key, 0) >= self.max_per_chat:
                                continue
                            for q_idx in ordered_idxs:
                                if self._cancelled() or len(out) >= self.max_results or _remaining_total(reserve=0.2) <= 0 or time.time() - fallback_started > fallback_budget:
                                    break
                                q = queries_used[q_idx]
                                try:
                                    for msg in client.iter_messages(ent, search=q, limit=min(max(5, int(self.search_limit or 100) // 15), 10)):
                                        if self._cancelled() or len(out) >= self.max_results or _remaining_total(reserve=0.2) <= 0 or time.time() - fallback_started > fallback_budget:
                                            break
                                        process_msg(q_idx, msg, ent, title, ref, collect_header=True, query=q)
                                except Exception:
                                    continue
            except Exception:
                pass

            # 5) Głębszy fallback po własnych grupach/tematach.
            # To nadal NIE zmienia koncepcji zapytań: używamy tych samych
            # najdłuższych słów z zaakceptowanych tytułów PL/DE/EN/original, bez
            # pełnych fraz. Różnica: nie uznajemy kilku znalezionych wyników za
            # powód do przerwania. Szukamy głębiej zawsze, dopóki jest budżet czasu
            # i miejsce na kolejne surowe wyniki.
            try:
                if queries_used and len(out) < self.max_results:
                    rescue_started = time.time()
                    # Kontrolowany budżet dodatkowego skanu. Ogranicznikiem jest czas,
                    # max_results i max_per_chat, a nie liczba już znalezionych wyników.
                    rescue_budget = min(24.0, max(8.0, _remaining_total(reserve=0.5)))
                    rescue_deadline = min(rescue_started + rescue_budget, total_deadline)
                    if rescue_budget <= 1.0:
                        raise RuntimeError('no time left for deep fallback')
                    rescue_queries = queries_used[:min(3, len(queries_used))]
                    self._diag('[telegram] deep fallback always; have=%s max=%s queries=%s budget=%.1fs' % (len(out), self.max_results, rescue_queries, rescue_budget))

                    def rescue_process(q_idx, q, msg, ent, title, ref):
                        try:
                            if q and not self._message_contains_query(msg, q):
                                return 0
                            chat_key = chat_key_for(ent, title)
                            if found_by_chat.get(chat_key, 0) >= self.max_per_chat:
                                return 0
                            if self._append_mtproto_source(
                                out, msg, ent, title, ref, data, seen, force_match=True,
                                match_query=q, query_rank=q_idx,
                            ):
                                found_by_chat[chat_key] = found_by_chat.get(chat_key, 0) + 1
                                return 1
                            remaining = max(0, self.max_per_chat - int(found_by_chat.get(chat_key, 0) or 0))
                            if remaining <= 0:
                                return 0
                            added = 0
                            if self._movie_header_matches(msg, data, title, ref):
                                added = self._append_movie_nearby_videos(client, out, ent, title, ref, data, msg, seen, max_add=min(int(getattr(self, 'movie_context_files', 3) or 0), remaining), deadline=rescue_deadline)
                            elif self._series_header_matches(msg, data, title, ref):
                                added = self._append_series_nearby_videos(client, out, ent, title, ref, data, msg, seen, max_add=min(int(getattr(self, 'series_context_files', 30) or 0), remaining), deadline=rescue_deadline)
                            if added:
                                found_by_chat[chat_key] = found_by_chat.get(chat_key, 0) + int(added or 0)
                                self._diag('[telegram] deep fallback context added=%s chat=%s msg=%s' % (added, title, getattr(msg, 'id', '')))
                                return int(added or 0)
                        except Exception:
                            pass
                        return 0

                    # Najpierw tematy/forum, bo tam najczęściej giną posty publikowane
                    # w grupach podzielonych na tematy.
                    try:
                        for ent, title, ref in targets:
                            if self._cancelled() or len(out) >= self.max_results or time.time() >= rescue_deadline:
                                break
                            if not getattr(ent, 'forum', False):
                                continue
                            chat_key = chat_key_for(ent, title)
                            if found_by_chat.get(chat_key, 0) >= self.max_per_chat:
                                continue
                            for q_idx, q in enumerate(rescue_queries):
                                if self._cancelled() or len(out) >= self.max_results or time.time() >= rescue_deadline:
                                    break
                                added_topic = self._search_forum_topics(client, out, ent, title, ref, q, data, seen, found_by_chat.get(chat_key, 0), self.max_per_chat, deadline=rescue_deadline)
                                if added_topic:
                                    found_by_chat[chat_key] = found_by_chat.get(chat_key, 0) + added_topic
                    except Exception:
                        pass

                    # Potem własne dialogi bez warunku "out musi być puste".
                    try:
                        for ent, title, ref in targets:
                            if self._cancelled() or len(out) >= self.max_results or time.time() >= rescue_deadline:
                                break
                            chat_key = chat_key_for(ent, title)
                            if found_by_chat.get(chat_key, 0) >= self.max_per_chat:
                                continue
                            for q_idx, q in enumerate(rescue_queries):
                                if self._cancelled() or len(out) >= self.max_results or time.time() >= rescue_deadline:
                                    break
                                try:
                                    rescue_limit = min(max(12, int(self.search_limit or 100) // 6), 30)
                                    for msg in client.iter_messages(ent, search=q, limit=rescue_limit):
                                        if self._cancelled() or len(out) >= self.max_results or time.time() >= rescue_deadline:
                                            break
                                        rescue_process(q_idx, q, msg, ent, title, ref)
                                except Exception:
                                    continue
                    except Exception:
                        pass
                    self._diag('[telegram] deep fallback end; results=%s elapsed=%.1fs' % (len(out), time.time() - rescue_started))
            except Exception:
                pass

            # Keep all broad/uncertain hits, but place exact title/year/episode
            # matches first. Python's stable sort preserves PL/DE/EN query order
            # for equal scores.
            out.sort(key=lambda item: int((item or {}).get('telegram_match_score') or 0), reverse=True)
            self._diag('[telegram] szybki skan zakończony: results=%s elapsed=%.1fs' % (len(out), time.time() - started))
        finally:
            _tg_safe_disconnect(client)
            _tg_close_current_loop()
            _tg_release_search(self)
        return out

    def _peer_keys_for_entity(self, ent):
        keys = set()
        try:
            eid = int(getattr(ent, 'id', 0) or 0)
            if eid:
                keys.add(eid)
                keys.add(-eid)
                try:
                    keys.add(int('-100%s' % abs(eid)))
                except Exception:
                    pass
        except Exception:
            pass
        try:
            from telethon import utils
            pid = int(utils.get_peer_id(ent) or 0)
            if pid:
                keys.add(pid)
        except Exception:
            pass
        return keys

    def _peer_keys_for_message(self, msg):
        keys = set()
        try:
            cid = int(getattr(msg, 'chat_id', 0) or 0)
            if cid:
                keys.add(cid)
                keys.add(-cid)
                scid = str(abs(cid))
                if scid.startswith('100') and len(scid) > 4:
                    try:
                        keys.add(int(scid[3:]))
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            peer = getattr(msg, 'peer_id', None)
            for attr in ('channel_id', 'chat_id', 'user_id'):
                val = int(getattr(peer, attr, 0) or 0)
                if val:
                    keys.add(val)
                    keys.add(-val)
                    try:
                        keys.add(int('-100%s' % abs(val)))
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            chat = getattr(msg, 'chat', None)
            if chat:
                keys.update(self._peer_keys_for_entity(chat))
        except Exception:
            pass
        return keys

    def _build_target_map(self, client, targets):
        target_map = {}
        try:
            for ent, title, ref in targets:
                for key in self._peer_keys_for_entity(ent):
                    target_map[int(key)] = (ent, title, ref)
        except Exception:
            pass
        return target_map

    def _target_for_message(self, msg, target_map):
        try:
            for key in self._peer_keys_for_message(msg):
                if int(key) in target_map:
                    return target_map[int(key)]
        except Exception:
            pass
        return None

    def _get_client(self, interactive=False):
        try:
            TelegramClient, errors, _, _, _ = _tg_telethon_imports()
            if not TelegramClient:
                control.infoDialog('Brak Telethon w dodatku', heading='Telegram', icon='WARNING', time=3500, sound=False)
                return None
            api_id = int(self.api_id or 0)
            api_hash = self.api_hash
            phone = self._normalize_phone(self.phone)
            if not (api_id and api_hash):
                fflog('[telegram] brak api_id/api_hash - pomijam MTProto', 1)
                return None

            # Jeżeli wcześniej wpisano błędny numer, Telethon mógł utworzyć pustą
            # sesję z poprzednim stanem logowania. To blokowało ponowne wysłanie kodu.
            if phone:
                self._prepare_session_for_phone(phone)

            session_path = self._session_path()
            loop = _tg_ensure_event_loop()
            _tg_patch_telethon_helpers()
            try:
                asyncio.set_event_loop(loop)
            except Exception:
                pass
            client = TelegramClient(
                session_path, api_id, api_hash, loop=loop,
                base_logger=_TG_TELETHON_LOGGER,
            )
            client.connect()
            if client.is_user_authorized():
                if phone:
                    self._save_session_phone(phone)
                return client
            if not interactive:
                _tg_safe_disconnect(client)
                return None

            if not phone:
                _tg_safe_disconnect(client)
                control.infoDialog(
                    'Numer telefonu jest wymagany do logowania kodem. Użyj logowania QR albo wpisz numer z kodem kraju.',
                    heading='Telegram', icon='WARNING', time=7000, sound=False
                )
                return None

            # Czysty start dla niezalogowanej sesji. Szczególnie ważne po zmianie numeru.
            _tg_safe_disconnect(client)
            self._delete_session_files()
            client = TelegramClient(
                session_path, api_id, api_hash, loop=loop,
                base_logger=_TG_TELETHON_LOGGER,
            )
            client.connect()

            # Login jest lokalnie w Kodi. Kod/2FA nigdy nie trafia do logu.
            # Telegram zwykle wysyła kod do aplikacji Telegram jako wiadomość od
            # oficjalnego konta Telegram; QR jest fallbackiem, jeśli kod z czatu nie przyjdzie.
            client, sent = self._send_login_code_with_dc_retry(client, phone, session_path, api_id, api_hash, loop, errors)
            if not sent:
                if self.qr_login:
                    client, qr_ok = self._qr_login_with_dc_retry(client, session_path, api_id, api_hash, loop, errors)
                    if qr_ok:
                        self._save_session_phone(phone)
                        control.infoDialog('Telegram zalogowany przez QR', heading='Telegram', time=3500, sound=False)
                        return client
                _tg_safe_disconnect(client)
                return None

            code = self._ask_text('Telegram: wpisz kod z czatu Telegram', hidden=False)
            if not code:
                # Nie wymuszamy SMS ani połączenia. Telethon/Telegram oznacza force_sms
                # jako deprecated, a użytkownik chce tylko kod w aplikacji Telegram.
                # Gdy kod z czatu nie przychodzi, najlepszy fallback to QR login.
                if self.qr_login:
                    try:
                        use_qr = control.yesnoDialog(
                            'Kod z czatu Telegram nie przyszedł albo został anulowany.',
                            'Zalogować przez kod QR zamiast SMS/połączenia?',
                            'W Telegramie: Ustawienia > Urządzenia > Połącz urządzenie.',
                            heading='Telegram', nolabel='Anuluj', yeslabel='Pokaż QR'
                        )
                    except Exception:
                        use_qr = False
                    if use_qr:
                        client, qr_ok = self._qr_login_with_dc_retry(client, session_path, api_id, api_hash, loop, errors)
                        if qr_ok:
                            self._save_session_phone(phone)
                            control.infoDialog('Telegram zalogowany przez QR', heading='Telegram', time=3500, sound=False)
                            return client
                _tg_safe_disconnect(client)
                return None

            try:
                client.sign_in(phone=phone, code=code.strip())
            except asyncio.CancelledError:
                try:
                    control.infoDialog('Telegram: logowanie przerwane podczas przełączania połączenia. Spróbuj ponownie.', heading='Telegram', icon='WARNING', time=6000, sound=False)
                except Exception:
                    pass
                return None
            except BaseException as exc:
                if errors and isinstance(exc, getattr(errors, 'SessionPasswordNeededError', ())):
                    password = self._ask_text('Telegram: hasło 2FA', hidden=True)
                    if not password:
                        _tg_safe_disconnect(client)
                        return None
                    client.sign_in(password=password)
                else:
                    # Nie próbuj dalej po błędnym kodzie - następne wyszukiwanie wyśle nowy kod.
                    fflog_exc(1)
                    try:
                        control.infoDialog('Telegram: błędny albo wygasły kod logowania', heading='Telegram', icon='WARNING', time=5500, sound=False)
                    except Exception:
                        pass
                    _tg_safe_disconnect(client)
                    return None

            if client.is_user_authorized():
                self._save_session_phone(phone)
                control.infoDialog('Telegram zalogowany', heading='Telegram', time=3000, sound=False)
                return client
            _tg_safe_disconnect(client)
            return None
        except BaseException as exc:
            if self._is_api_id_invalid(exc, errors if 'errors' in locals() else None):
                self._show_api_id_invalid()
                return None
            fflog_exc(1)
            try:
                control.infoDialog('Telegram login nieudany - sprawdź api_id/api_hash/telefon', heading='Telegram', icon='WARNING', time=5500, sound=False)
            except Exception:
                pass
            return None

    def _qr_login(self, client, errors=None):
        try:
            start_dc = self._client_dc_id(client)
            self._last_qr_dc_migrated = False
            control.infoDialog('Telegram: przygotowuję kod QR do logowania', heading='Telegram', time=3500, sound=False)
            qr = client.qr_login()
            path = self._qr_image_path()
            if self._write_qr_png(qr.url, path):
                try:
                    control.execute('ShowPicture("%s")' % path.replace('"', '').replace('\\', '/'))
                except Exception:
                    pass
                try:
                    control.infoDialog('Zeskanuj QR w Telegram: Ustawienia > Urządzenia > Połącz urządzenie', heading='Telegram', time=9000, sound=False)
                except Exception:
                    pass
            else:
                # Awaryjnie pokaż tg:// URL w oknie tekstowym. Na TV jest mniej wygodne,
                # ale logika QR dalej czeka na potwierdzenie.
                try:
                    control.dialog.textviewer('Telegram QR URL', qr.url)
                except Exception:
                    pass

            try:
                wait_result = qr.wait(timeout=120)
                if asyncio.iscoroutine(wait_result):
                    loop = _tg_ensure_event_loop()
                    _tg_patch_telethon_helpers()
                    try:
                        asyncio.set_event_loop(loop)
                    except Exception:
                        pass
                    user = loop.run_until_complete(wait_result)
                else:
                    user = wait_result
                fflog('[telegram] QR login OK user=%s' % (getattr(user, 'id', '') or ''), 1)
                try:
                    control.execute('Action(PreviousMenu)')
                except Exception:
                    pass
                return bool(client.is_user_authorized())
            except asyncio.CancelledError:
                try:
                    end_dc = self._client_dc_id(client)
                    if end_dc and start_dc and end_dc != start_dc:
                        self._last_qr_dc_migrated = True
                        try:
                            fflog('[telegram] QR login interrupted during DC migration %s -> %s' % (start_dc, end_dc), 1)
                        except Exception:
                            pass
                        control.infoDialog('Telegram QR: przełączam centrum danych i pokażę nowy QR.', heading='Telegram', time=6500, sound=False)
                    else:
                        control.infoDialog('Telegram QR: oczekiwanie anulowane albo wygasło', heading='Telegram', icon='WARNING', time=6000, sound=False)
                except Exception:
                    pass
                return False
            except BaseException as exc:
                if errors and isinstance(exc, getattr(errors, 'SessionPasswordNeededError', ())):
                    password = self._ask_text('Telegram: hasło 2FA po QR', hidden=True)
                    if not password:
                        return False
                    client.sign_in(password=password)
                    return bool(client.is_user_authorized())
                if self._is_dc_migration_error(exc):
                    try:
                        end_dc = self._client_dc_id(client)
                        if end_dc and start_dc and end_dc != start_dc:
                            self._last_qr_dc_migrated = True
                            fflog('[telegram] QR login interrupted by migration exception %s -> %s' % (start_dc, end_dc), 1)
                            control.infoDialog('Telegram QR: przełączam centrum danych i pokażę nowy QR.', heading='Telegram', time=6500, sound=False)
                            return False
                    except Exception:
                        pass
                    raise
                fflog_exc(1)
                try:
                    control.infoDialog('Telegram QR: nie zalogowano w czasie 120 sekund', heading='Telegram', icon='WARNING', time=6000, sound=False)
                except Exception:
                    pass
                return False
        except Exception as exc:
            if self._is_api_id_invalid(exc, errors):
                self._show_api_id_invalid()
                return False
            fflog_exc(1)
            return False

    def _qr_image_path(self):
        try:
            folder = os.path.join(control.dataPath, 'telegram')
            try:
                control.makeDirs(folder)
            except Exception:
                if not os.path.exists(folder):
                    os.makedirs(folder)
            return os.path.join(folder, 'telegram_login_qr.png')
        except Exception:
            return os.path.join(control.dataPath, 'telegram_login_qr.png')

    def _write_qr_png(self, data, path, scale=8, border=4):
        try:
            matrix = None
            # Na części Android TV brakuje script.module.pyqrcode. Najpierw próbujemy
            # starej metody, a potem vendored qrcode z paczki dodatku. Dzięki temu
            # QR działa bez instalowania dodatkowych bibliotek z repozytorium Kodi.
            try:
                import pyqrcode
                qr = pyqrcode.create(data, error='M')
                matrix = qr.code
            except Exception as exc:
                try:
                    fflog('[telegram] pyqrcode unavailable, using bundled qrcode fallback: %r' % exc, 1)
                except Exception:
                    pass
                import qrcode
                qr = qrcode.QRCode(
                    version=None,
                    error_correction=qrcode.constants.ERROR_CORRECT_M,
                    box_size=1,
                    border=0,
                )
                qr.add_data(data)
                qr.make(fit=True)
                matrix = qr.get_matrix()

            if not matrix:
                return False
            size = len(matrix)
            width = (size + border * 2) * scale
            height = width

            def png_chunk(tag, payload):
                raw = tag + payload
                return struct.pack('>I', len(payload)) + raw + struct.pack('>I', zlib.crc32(raw) & 0xffffffff)

            rows = []
            white = 255
            black = 0
            for y in range(size + border * 2):
                if y < border or y >= size + border:
                    row = bytes([white]) * width
                else:
                    src = matrix[y - border]
                    pixels = []
                    pixels.extend([white] * (border * scale))
                    for cell in src:
                        v = black if cell else white
                        pixels.extend([v] * scale)
                    pixels.extend([white] * (border * scale))
                    row = bytes(pixels)
                for _ in range(scale):
                    rows.append(b'\x00' + row)
            raw = b''.join(rows)
            png = b'\x89PNG\r\n\x1a\n'
            png += png_chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 0, 0, 0, 0))
            png += png_chunk(b'IDAT', zlib.compress(raw, 9))
            png += png_chunk(b'IEND', b'')
            with open(path, 'wb') as f:
                f.write(png)
            return True
        except Exception:
            fflog_exc(1)
            return False

    def _send_login_code(self, client, phone, force_sms=False):
        try:
            masked = self._mask_phone(phone)
            control.infoDialog('Telegram: wysyłam kod do czatu Telegram (%s)' % masked, heading='Telegram', time=4000, sound=False)
            # Nie przekazujemy force_sms. W Telethon 1.38/Telegram jest to deprecated
            # i potrafi zwracać SendCodeUnavailableError. Telegram sam decyduje,
            # ale pierwszą metodą dla aktywnego konta jest zwykle aplikacja/czat Telegram.
            sent = client.send_code_request(phone)
            desc = self._sent_code_description(sent)
            try:
                fflog('[telegram] send_code_request OK phone=%s app_only=True %s' % (masked, desc), 1)
            except Exception:
                pass
            try:
                control.infoDialog('Kod wysłany: %s' % desc, heading='Telegram', time=6500, sound=False)
            except Exception:
                pass
            return sent
        except BaseException as exc:
            if self._is_api_id_invalid(exc):
                self._show_api_id_invalid()
                return None
            if self._is_dc_switch_interrupt(exc):
                raise
            fflog_exc(1)
            try:
                if self.qr_login:
                    control.infoDialog('Telegram nie wysłał kodu. Spróbuj logowania QR.', heading='Telegram', icon='WARNING', time=6500, sound=False)
                else:
                    control.infoDialog('Telegram NIE wysłał kodu. Sprawdź numer/api_id/api_hash albo limit prób.', heading='Telegram', icon='WARNING', time=7500, sound=False)
            except Exception:
                pass
            return None

    def _sent_code_description(self, sent):
        try:
            t = getattr(sent, 'type', None)
            tname = type(t).__name__ if t is not None else type(sent).__name__
            next_type = getattr(sent, 'next_type', None)
            nname = type(next_type).__name__ if next_type is not None else ''
            timeout = getattr(sent, 'timeout', None)
            length = getattr(t, 'length', None) if t is not None else None
            if 'App' in tname:
                where = 'aplikacja Telegram / czat Telegram'
            elif 'Sms' in tname or 'SMS' in tname:
                where = 'SMS'
            elif 'Call' in tname:
                where = 'połączenie telefoniczne'
            elif 'FlashCall' in tname:
                where = 'flash-call'
            elif 'MissedCall' in tname:
                where = 'nieodebrane połączenie'
            elif 'Email' in tname:
                where = 'e-mail'
            else:
                where = tname
            extra = []
            if length:
                extra.append('długość: %s' % length)
            if timeout:
                extra.append('ponów za: %ss' % timeout)
            if nname:
                extra.append('następna metoda: %s' % nname.replace('SentCodeType', ''))
            return where + ((' (' + ', '.join(extra) + ')') if extra else '')
        except Exception:
            return type(sent).__name__

    def _mask_phone(self, phone):
        try:
            p = str(phone or '').strip()
            if len(p) <= 5:
                return p
            return p[:3] + '***' + p[-3:]
        except Exception:
            return '***'

    def _chat_scan_score(self, title):
        try:
            t = title_matcher.normalize(title or '')
            score = 0
            keywords = [
                'film', 'filmy', 'movie', 'movies', 'kino', 'cinema', 'serial', 'seriale',
                'serien', 'serie', 'deutsch', 'german', 'lektor', 'dubbing', 'napisy',
                'bajki', 'cartoon', 'anime', 'ghibli', 'stream', 'vod', 'hd', '4k'
            ]
            for kw in keywords:
                if kw in t:
                    score += 10
            negative = ['apk', 'iptv', 'programy', 'konto', 'konta', 'czat', 'gadu', 'bot']
            for kw in negative:
                if kw in t:
                    score -= 8
            return score
        except Exception:
            return 0

    def _is_group_channel(self, ent):
        try:
            if not ent:
                return False
            if getattr(ent, 'bot', False) or getattr(ent, 'first_name', None) or getattr(ent, 'phone', None):
                return False
            if getattr(ent, 'megagroup', False) or getattr(ent, 'broadcast', False):
                return True
            return bool(getattr(ent, 'title', None))
        except Exception:
            return False

    def _forum_topics_for_query(self, client, ent, q):
        try:
            if not getattr(ent, 'forum', False):
                return []
            from telethon.tl.functions.channels import GetForumTopicsRequest
            topics = []
            seen = set()
            for query in (q, None):
                try:
                    # Some groups have many topics; the relevant one (e.g. Wrzutki)
                    # may not be in the first dozen returned without a query.
                    res = client(GetForumTopicsRequest(channel=ent, offset_date=None, offset_id=0, offset_topic=0, limit=50, q=query))
                    for topic in getattr(res, 'topics', []) or []:
                        top = int(getattr(topic, 'top_message', 0) or 0)
                        if top and top not in seen:
                            seen.add(top)
                            topics.append(topic)
                except Exception:
                    continue
                if len(topics) >= 50:
                    break
            return topics[:50]
        except Exception:
            return []

    def _search_forum_topics(self, client, out, ent, title, ref, q, data, seen, current_count=0, max_per_chat=5, deadline=None):
        added = 0
        try:
            if current_count >= max_per_chat:
                return 0
            for topic in self._forum_topics_for_query(client, ent, q):
                if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                    break
                if current_count + added >= max_per_chat or len(out) >= self.max_results:
                    break
                top = int(getattr(topic, 'top_message', 0) or 0)
                if not top:
                    continue
                topic_title = getattr(topic, 'title', '') or ''
                chat_title = '%s / %s' % (title, topic_title) if topic_title else title
                try:
                    for msg in client.iter_messages(ent, search=q, reply_to=top, limit=min(max(8, int(self.search_limit or 100)), int(getattr(self, 'topic_scan_limit', 80) or 80))):
                        if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                            break
                        if current_count + added >= max_per_chat or len(out) >= self.max_results:
                            break
                        if self._message_contains_query(msg, q) and self._append_mtproto_source(
                            out, msg, ent, chat_title, ref, data, seen, force_match=True,
                            match_query=q, query_rank=6,
                        ):
                            added += 1
                        else:
                            remaining = max(0, int(max_per_chat or 0) - int(current_count or 0) - int(added or 0))
                            ctx_added = 0
                            if self._series_header_matches(msg, data, chat_title, ref):
                                ctx_added = self._append_series_nearby_videos(client, out, ent, chat_title, ref, data, msg, seen, max_add=min(int(getattr(self, 'series_context_files', 30) or 0), remaining), deadline=deadline)
                            elif self._movie_header_matches(msg, data, chat_title, ref):
                                ctx_added = self._append_movie_nearby_videos(client, out, ent, chat_title, ref, data, msg, seen, max_add=min(int(getattr(self, 'movie_context_files', 3) or 0), remaining), deadline=deadline)
                            if ctx_added:
                                added += ctx_added
                except Exception:
                    continue
        except Exception:
            pass
        return added

    def _get_mtproto_targets(self, client):
        targets = []
        seen = set()
        manual = [self._public_chat_name(c) for c in self.chats]
        manual = [x for x in manual if x]
        if manual:
            for ref in manual:
                try:
                    ent = client.get_entity(ref)
                    eid = int(getattr(ent, 'id', 0) or 0)
                    if eid in seen:
                        continue
                    seen.add(eid)
                    title = getattr(ent, 'title', None) or getattr(ent, 'username', None) or ref
                    targets.append((ent, title, ref, 9999))
                except Exception:
                    fflog_exc(1)

        if self.use_dialogs:
            try:
                for d in client.iter_dialogs(limit=self.dialog_limit):
                    ent = getattr(d, 'entity', None)
                    if not ent:
                        continue
                    eid = int(getattr(ent, 'id', 0) or 0)
                    if not eid or eid in seen:
                        continue
                    # channels/groups/supergroups only; skip private users/bots by default.
                    if not (getattr(d, 'is_channel', False) or getattr(d, 'is_group', False) or self._is_group_channel(ent)):
                        continue
                    seen.add(eid)
                    ref = ''
                    try:
                        username = getattr(ent, 'username', None)
                        if username:
                            ref = username
                    except Exception:
                        pass
                    title = getattr(d, 'name', None) or getattr(ent, 'title', None) or ref or str(eid)
                    targets.append((ent, title, ref, self._chat_scan_score(title)))
            except Exception:
                fflog_exc(1)

        try:
            mode = self._chat_filter_mode_name()
            selected = self._selected_chat_ids()
            if mode == 'selected':
                if selected:
                    targets = [x for x in targets if str(int(getattr(x[0], 'id', 0) or 0)) in selected]
                else:
                    # Tryb tylko wybrane bez wyboru ma nie skanować wszystkiego przez pomyłkę.
                    fflog('[telegram] chat filter selected_only, ale lista wybranych jest pusta', 1)
                    targets = []
            elif mode == 'excluded' and selected:
                targets = [x for x in targets if str(int(getattr(x[0], 'id', 0) or 0)) not in selected]
        except Exception:
            fflog_exc(1)

        try:
            targets = sorted(targets, key=lambda x: x[3], reverse=True)
        except Exception:
            pass
        # Nie skanuj setek dialogów w jednym wyszukiwaniu, ale po odwróceniu pętli
        # zapytań możemy bezpiecznie sprawdzić więcej własnych grup/kanałów.
        limit = min(max(5, int(self.dialog_limit or 1000)), 1000)
        targets = targets[:limit]
        try:
            fflog('[telegram] MTProto account targets=%s filter=%s selected=%s' % (len(targets), self._chat_filter_mode_name(), len(self._selected_chat_ids())), 1)
        except Exception:
            fflog(f'[telegram] MTProto account targets={len(targets)} own_dialogs_filter', 1)
        return [(ent, title, ref) for ent, title, ref, _score in targets]

    def _document_from_message(self, msg):
        try:
            doc = getattr(msg, 'document', None)
            if doc:
                return doc
        except Exception:
            pass
        try:
            doc = getattr(getattr(msg, 'media', None), 'document', None)
            if doc:
                return doc
        except Exception:
            pass
        return None

    def _filename_from_document(self, doc):
        try:
            for a in getattr(doc, 'attributes', []) or []:
                name = getattr(a, 'file_name', None)
                if name:
                    return str(name)
        except Exception:
            pass
        return ''

    def _message_file_size(self, msg):
        try:
            size = int(getattr(getattr(msg, 'file', None), 'size', 0) or 0)
            if size:
                return size
        except Exception:
            pass
        try:
            doc = self._document_from_message(msg)
            return int(getattr(doc, 'size', 0) or 0) if doc else 0
        except Exception:
            return 0

    def _message_has_video_file(self, msg):
        try:
            # Telethon exposes some videos as msg.video/msg.document even when
            # msg.file.mime_type/name is empty.  The previous check missed such
            # album video tiles under poster/caption posts.
            if getattr(msg, 'video', None):
                return True
            file_obj = getattr(msg, 'file', None)
            name = (getattr(file_obj, 'name', None) or '').lower() if file_obj else ''
            mime = (getattr(file_obj, 'mime_type', None) or '').lower() if file_obj else ''
            if mime.startswith('video/'):
                return True
            if re.search(r'\.(mp4|mkv|avi|mov|webm|m4v)$', name, re.I):
                return True
            doc = self._document_from_message(msg)
            if doc:
                dmime = (getattr(doc, 'mime_type', None) or '').lower()
                if dmime.startswith('video/'):
                    return True
                dname = self._filename_from_document(doc).lower()
                if re.search(r'\.(mp4|mkv|avi|mov|webm|m4v)$', dname, re.I):
                    return True
                for a in getattr(doc, 'attributes', []) or []:
                    cls = a.__class__.__name__.lower()
                    if 'video' in cls:
                        return True
        except Exception:
            pass
        return False

    def _message_dict_from_mtproto(self, msg, chat_title, ref=''):
        file_obj = getattr(msg, 'file', None)
        doc = self._document_from_message(msg)
        filename = (getattr(file_obj, 'name', None) or self._filename_from_document(doc) or '')
        size = self._fmt_size(int(self._message_file_size(msg) or 0))
        text = ' '.join(x for x in (filename, getattr(msg, 'message', None) or '') if x).strip()
        try:
            msg_date = getattr(msg, 'date', None)
            date_label = msg_date.strftime('%Y-%m-%d') if msg_date else ''
        except Exception:
            date_label = ''
        return {
            'chat': chat_title,
            'message_id': str(getattr(msg, 'id', '') or ''),
            'date': date_label,
            'message_url': ('https://t.me/%s/%s' % (ref, getattr(msg, 'id', ''))) if ref else '',
            'text': text,
            'filename': filename,
            'size': size,
            'video_url': 'mtproto',
        }

    def _resolve_mtproto(self, data):
        try:
            if not self.proxy_stream:
                control.infoDialog('Telegram wymaga lokalnego serwisu proxy do odtwarzania MTProto', heading='Telegram', icon='WARNING', time=4000, sound=False)
                return None

            spec = dict(data or {})
            spec['api_hash'] = self.api_hash
            spec['session_path'] = self._session_path()
            spec['session_string'] = _tg_export_session_string(spec['session_path'])
            spec['created'] = time.time()
            spec['startup_buffer_mb'] = int(self.startup_buffer_mb or 4)
            if not spec.get('session_string'):
                control.infoDialog('Telegram: nie udało się odczytać aktywnej sesji.', heading='Telegram', icon='WARNING', time=5000, sound=False)
                return None

            # 2.41.39: playback is registered in the persistent service.py
            # Telegram stream service. The old in-resolver proxy is intentionally
            # not used here: it created Telethon clients in Kodi HTTP/request
            # threads and repeatedly blocked Android/Kodi after failed opens.
            try:
                from resources.lib import tg_stream_service
                # Metadane + bufor są przygotowywane w usłudze. Daj im czas
                # zależny od wybranego bufora, ale nie blokuj bez końca.
                register_timeout = max(24.0, min(48.0, 20.0 + float(self.startup_buffer_mb)))
                result = tg_stream_service.register_with_service(spec, preferred_port=self.proxy_port, timeout=register_timeout)
            except Exception:
                fflog_exc(1)
                result = {'ok': False, 'error': 'stream_service import/register failed'}

            if result.get('ok') and result.get('url'):
                fflog('[tg-service] resolved service url token=%s file=%r size=%s cached=%s' % (
                    _token_tag(result.get('token') or ''), data.get('filename') or '', int(spec.get('size') or 0), int(result.get('cached') or 0)), 1)
                # 2.41.45 native-crypto branch: when Telethon has a native
                # crypto backend, use normal seekable HTTP Range again. MP4/MKV
                # players need truthful seek support for tail metadata. If we fell
                # back to pure Python pyaes, refuse instead of clogging Kodi.
                _backend = str(result.get('crypto_backend') or '').lower()
                if _backend in ('pyaes', 'unknown', ''):
                    try:
                        control.infoDialog('Telegram: brak szybkiej kryptografii. Streaming wymaga tgcrypto_ctypes albo libssl.', heading='Telegram', icon='WARNING', time=7000, sound=False)
                    except Exception:
                        pass
                    return None
                _u = result.get('url')
                return _u

            err = result.get('error') or 'nieznany błąd serwisu Telegram'
            try:
                fflog('[tg-service] register failed err=%r cached=%s' % (err, result.get('cached')), 1)
                control.infoDialog('Telegram: serwis nie oddał pierwszych bajtów albo backend streamingu odmówił startu. Sprawdź log.', heading='Telegram', icon='WARNING', time=6000, sound=False)
            except Exception:
                pass
            return None
        except Exception:
            fflog_exc(1)
            return None

    # ------------------------------------------------------------------ #
    # Public t.me/s search                                                 #
    # ------------------------------------------------------------------ #

    def _sources_public_web(self, data):
        out = []
        queries = self._build_queries(data)
        chats = self._public_chats()
        if not chats:
            fflog('[telegram] no public @channels for t.me/s fallback', 1)
            return out

        for chat in chats:
            found_for_chat = 0
            for q in queries:
                if found_for_chat >= 5:
                    break
                html, page_url = self._fetch_public_page(chat, q)
                if not html:
                    continue
                messages = self._parse_public_messages(html, chat, page_url)
                for msg in messages:
                    if found_for_chat >= 5:
                        break
                    if not self._message_matches(msg, data):
                        continue
                    src = msg.get('video_url') or ''
                    if not src:
                        continue
                    token = self._pack({
                        'mode': 'public_web',
                        'url': src,
                        'referer': msg.get('message_url') or page_url,
                        'chat': chat,
                        'message_id': msg.get('message_id'),
                        'title': msg.get('text') or data.get('title'),
                    })
                    quality = self._quality_from_text(' '.join([msg.get('text') or '', src]))
                    info = self._info_from_message(msg, chat)
                    out.append({
                        'provider': 'telegram',
                        'source': self._display_chat_title(msg.get('chat') or chat),
                        'quality': quality,
                        'language': 'pl',
                        'url': token,
                        'info': info,
                        'direct': True,
                        'debridonly': False,
                        'filename': msg.get('filename') or '',
                        'premium': False,
                    })
                    found_for_chat += 1
        return out

    def _fetch_public_page(self, chat, query=''):
        try:
            base = f'https://t.me/s/{chat}'
            if query:
                url = base + '?q=' + quote(query)
            else:
                url = base
            fflog(f'[telegram] GET {url}', 1)
            r = self._get_session().get(url, headers=self.headers, timeout=18)
            if r.status_code >= 400:
                fflog(f'[telegram] public page status={r.status_code} chat={chat}', 1)
                return '', url
            text = r.text or ''
            if 'tgme_channel_history' not in text and 'tgme_widget_message' not in text:
                fflog(f'[telegram] no public messages in {chat}', 1)
            return text, url
        except Exception:
            fflog_exc(1)
            return '', ''

    def _parse_public_messages(self, html, chat, page_url):
        messages = []
        try:
            blocks = re.split(r'(?=<div class="tgme_widget_message[^>]*\bdata-post=)', html or '')
            for block in blocks:
                if 'tgme_widget_message' not in block:
                    continue
                post = self._first_match(block, r'data-post="([^"]+)"')
                msg_id = ''
                if post and '/' in post:
                    try:
                        msg_id = post.rsplit('/', 1)[1]
                    except Exception:
                        pass
                message_url = f'https://t.me/{post}' if post else page_url
                text = self._clean_html(self._first_match(block, r'<div class="tgme_widget_message_text[^>]*>(.*?)</div>'))
                if not text:
                    text = self._clean_html(self._first_match(block, r'<div class="tgme_widget_message_caption[^>]*>(.*?)</div>'))
                filename = self._clean_html(self._first_match(block, r'<div class="tgme_widget_message_document_title[^>]*>(.*?)</div>'))
                size = self._clean_html(self._first_match(block, r'<div class="tgme_widget_message_document_extra[^>]*>(.*?)</div>'))
                video_url = self._extract_media_url(block)
                messages.append({
                    'chat': chat,
                    'message_id': msg_id,
                    'message_url': message_url,
                    'text': ' '.join(x for x in (filename, text) if x).strip(),
                    'filename': filename,
                    'size': size,
                    'video_url': video_url,
                })
        except Exception:
            fflog_exc(1)
        return messages

    def _extract_media_url(self, block):
        try:
            candidates = []
            for attr in ('data-src', 'src', 'href', 'data-video'):
                for val in re.findall(attr + r'="([^"]+)"', block or '', re.I):
                    val = unescape(val).replace('\\/', '/').strip()
                    if val.startswith('//'):
                        val = 'https:' + val
                    if not val.startswith('http'):
                        continue
                    if self._looks_like_media_url(val):
                        candidates.append(val)
            for val in re.findall(r'https?://[^\s"\']+', block or '', re.I):
                val = unescape(val).replace('\\/', '/').strip().rstrip('),;')
                if self._looks_like_media_url(val):
                    candidates.append(val)
            for u in candidates:
                if re.search(r'\.(?:mp4|mkv|avi|mov)(?:\?|$)', u, re.I):
                    return u
            for u in candidates:
                if 'cdn-telegram' in u or '/file/' in u:
                    return u
        except Exception:
            fflog_exc(1)
        return ''

    def _looks_like_media_url(self, url):
        u = (url or '').lower()
        if not u.startswith('http'):
            return False
        if re.search(r'\.(?:jpg|jpeg|png|webp|gif)(?:\?|$)', u):
            return False
        return bool(re.search(r'\.(?:mp4|mkv|avi|mov|m3u8)(?:\?|$)|cdn-telegram|/file/', u))

    # ------------------------------------------------------------------ #
    # Matching                                                            #
    # ------------------------------------------------------------------ #

    def _known_polish_title_variants(self, data):
        """Small local override list for titles whose PL name is often missing
        from the metadata passed to source scrapers.

        This is intentionally narrow: it only injects Polish titles that the user
        explicitly needs or that are very common in PL catalogues.  The normal
        metadata/aliases still drive the rest of the search.
        """
        out = []
        try:
            title = str((data or {}).get('title') or '').strip()
            local = str((data or {}).get('localtitle') or '').strip()
            aliases = []
            for item in ((data or {}).get('aliases') or []):
                if isinstance(item, dict):
                    value = (
                        item.get('title') or item.get('name') or item.get('value')
                        or item.get('originalname') or item.get('original_name') or ''
                    )
                else:
                    value = item
                value = str(value or '').strip()
                if value:
                    aliases.append(value)
            blob = ' '.join([title, local] + aliases).lower()
            imdb = str((data or {}).get('imdb') or '').strip().lower()

            def add(x):
                x = re.sub(r'\s+', ' ', str(x or '')).strip()
                if x and x not in out:
                    out.append(x)

            # FROM (tt9813792) is often passed to scrapers only as "FROM" plus
            # non-PL aliases, while Polish uploads use "Stamtąd".
            if imdb == 'tt9813792' or re.search(r'(^|\s)from($|\s)', blob):
                add('Stamtąd')
                add('Stamtad')

            # A few PL catalogue names that are also commonly missing/ambiguous
            # in upstream aliases.  Kept after metadata variants, not instead of them.
            if re.search(r'married\s+with\s+children|bundy|bundych', blob):
                add('Świat według Bundych')
                add('Swiat wedlug Bundych')
            if re.search(r'kiepskich|kiepscy|swiat\s+wedlug\s+kiepskich|świat\s+według\s+kiepskich', blob):
                add('Świat według Kiepskich')
                add('Swiat wedlug Kiepskich')

            # Szpital św. Anny bywa przekazywany przez metadata jako angielski
            # tytuł/original albo zwykły alias bez kodu języka.  Nie dodajemy
            # osobnych zapytań Anny/św/sw; pełny tytuł daje dalej główne słowo
            # wyszukiwania: "Szpital".
            if re.search(r'szpital\s+(?:św|sw|święt|swiet).*anny|(?:saint|st\.?)\s+anne', blob, re.I):
                add('Szpital św. Anny')
                add('Szpital sw Anny')
        except Exception:
            pass
        return out

    def _has_strong_polish_marks(self, value):
        """True only for diacritics that are a strong PL signal.

        The letter 'ó' is intentionally excluded here: it is common in
        Portuguese/Spanish/Hungarian/etc. aliases, so it must not by itself
        promote an unknown bare alias to Polish.  Once a title is accepted
        as PL by metadata/localtitle, 'ó' is still preserved and normalized
        by the query builder, e.g. Zwierzogród -> Zwierzogrod.
        """
        try:
            return bool(re.search(r'[ąćęłńśżźĄĆĘŁŃŚŻŹ]', str(value or '')))
        except Exception:
            return False

    def _variant_lang_group(self, value, data=None):
        """Priority bucket for Telegram title variants.

        0 = Polish/local, 2 = German-looking, 1 = English/original fallback.
        Bare/unknown aliases are not used by _wanted_variants anymore, because
        they can be Portuguese/Turkish/Czech/etc. (Susto, Korkun, Mrak...).
        """
        try:
            v = str(value or '')
            vc = title_matcher.compact(v)
            local = str((data or {}).get('localtitle') or '') if data else ''
            title = str((data or {}).get('title') or '') if data else ''
            if local and vc == title_matcher.compact(local):
                return 0
            # Preserve explicit language/country metadata. Re-classifying an
            # accepted alias only by how its words "look" made names such as
            # German "Zoomania" fall into the EN bucket.
            for alias in ((data or {}).get('aliases') or []) if data else []:
                if not isinstance(alias, dict):
                    continue
                av = (
                    alias.get('title') or alias.get('name') or alias.get('value')
                    or alias.get('originalname') or alias.get('original_name')
                    or alias.get('originaltitle') or alias.get('original_title') or ''
                )
                if not av or vc != title_matcher.compact(av):
                    continue
                codes = ' '.join(
                    str(alias.get(key) or '').lower()
                    for key in ('lang', 'language', 'iso_639_1', 'country', 'region', 'iso_3166_1', 'locale')
                )
                if re.search(r'(^|[^a-z])(pl|pol|polish|polska|polski)([^a-z]|$)', codes):
                    return 0
                if re.search(r'(^|[^a-z])(de|deu|ger|german|deutsch)([^a-z]|$)', codes):
                    return 2
                if re.search(r'(^|[^a-z])(en|eng|english|us|usa|gb|uk|original|orig)([^a-z]|$)', codes):
                    return 1
            if self._has_strong_polish_marks(v):
                return 0
            if vc in ('stamtad', 'swiatwedlugbundych', 'swiatwedlugkiepskich'):
                return 0
            if self._looks_german_title(v):
                return 2
            if title and vc == title_matcher.compact(title):
                return 1
            if not local and title and vc == title_matcher.compact(title):
                return 1
            return 1
        except Exception:
            return 1

    def _wanted_variants(self, data, max_items=24):
        """Return only PL/DE/EN title variants used for Telegram.

        Current rule agreed with the user:
          Polish title -> Polish title without diacritics (added by query builder)
          -> German title -> German without diacritics -> English/original title.

        Important: do NOT use generic unknown aliases.  Metadata providers can
        pass aliases from many countries as plain strings (for example Susto,
        Korkun, Mrak, Origem).  Those are now ignored unless the alias metadata
        explicitly marks the title as PL/DE/EN.  A word is never rejected just
        because it looks short or generic if it belongs to an accepted title
        variant; Ted, From, Film, He, etc. remain valid when they are really in
        the PL/DE/EN title.
        """
        try:
            data = data or {}
            title = data.get('title') or data.get('localtitle') or ''
            local = data.get('localtitle') or ''
            aliases = data.get('aliases') or []
            known_pl = self._known_polish_title_variants(data)

            buckets = {0: [], 2: [], 1: []}  # PL/local, DE, EN/original

            def add_bucket(group, v):
                v = re.sub(r'\s+', ' ', str(v or '')).strip()
                if not v:
                    return
                if v not in buckets.setdefault(group, []):
                    buckets[group].append(v)

            def alias_text_and_codes(a):
                av = a
                codes = []
                try:
                    if isinstance(a, dict):
                        av = (
                            a.get('title') or a.get('name') or a.get('value')
                            or a.get('originalname') or a.get('original_name')
                            or a.get('originaltitle') or a.get('original_title') or ''
                        )
                        for k in ('lang', 'language', 'iso_639_1', 'country', 'region', 'iso_3166_1', 'locale'):
                            val = a.get(k)
                            if val:
                                codes.append(str(val).lower())
                    else:
                        # Plain string aliases have no language metadata.  Keep
                        # the text only for obvious PL/DE detection below.  This
                        # restores cases like "Szpital św. Anny" passed as a
                        # bare alias, without re-enabling random EN/foreign aliases
                        # such as Susto/Korkun/Mrak.
                        av = a
                except Exception:
                    av = a
                return re.sub(r'\s+', ' ', str(av or '')).strip(), codes

            def code_group(codes):
                joined = ' '.join(codes).lower()
                # language/country can arrive as pl, pl-PL, polish, DE, us, gb, etc.
                if re.search(r'(^|[^a-z])(pl|pol|polish|polska|polski)([^a-z]|$)', joined):
                    return 0
                if re.search(r'(^|[^a-z])(de|deu|ger|german|deutsch|niemcy|niemiecki)([^a-z]|$)', joined):
                    return 2
                if re.search(r'(^|[^a-z])(en|eng|english|us|usa|gb|uk|original|orig)([^a-z]|$)', joined):
                    return 1
                return None

            # Polish/local title first.  Known local fixes are only PL titles.
            for v in known_pl:
                add_bucket(0, v)
            add_bucket(0, local)

            # The title field is usually the original/English title, but in some
            # Kodi paths it can already be the localized PL display title.  If it
            # equals local or contains Polish letters, keep it in PL; if it looks
            # German, keep it as DE; otherwise treat it as English/original.
            if title:
                if local and title_matcher.compact(title) == title_matcher.compact(local):
                    add_bucket(0, title)
                elif self._has_strong_polish_marks(title):
                    add_bucket(0, title)
                elif self._looks_german_title(title):
                    add_bucket(2, title)
                else:
                    add_bucket(1, title)

            # Aliases: use explicit PL/DE/EN metadata.  For bare string aliases
            # keep only obvious Polish/German text, matching 2.41.88 behaviour.
            # Do not accept bare English/unknown aliases, because that was causing
            # Susto/Korkun/Mrak/Origem-style noise.
            for a in aliases:
                av, codes = alias_text_and_codes(a)
                group = code_group(codes)
                if av and group is None:
                    if self._has_strong_polish_marks(av):
                        group = 0
                    elif self._looks_german_title(av):
                        group = 2
                if av and group is not None:
                    add_bucket(group, av)

            ordered = []
            seen = set()
            for group in (0, 2, 1):
                for idx, v in enumerate(buckets.get(group, [])):
                    key = title_matcher.compact(v)
                    if not key or key in seen:
                        continue
                    seen.add(key)
                    ordered.append((group, idx, v))
            return [v for _, __, v in ordered[:max_items]] or [local or title]
        except Exception:
            return [data.get('localtitle') or data.get('title') or '']

    def _rank_title_variant(self, value, title, local, idx=0, data=None):
        # Kept for compatibility with older calls.  _wanted_variants now returns
        # already ordered PL -> DE -> EN variants.
        v = str(value or '').strip()
        group = self._variant_lang_group(v, data)
        base = {0: 0, 2: 1, 1: 2}.get(group, 3)
        return base + min(int(idx or 0), 50) / 100.0

    def _looks_german_title(self, value):
        v = (' ' + str(value or '').lower() + ' ')
        if re.search(r'[äöüß]', v):
            return True
        # Heuristic for title/localtitle only, not for generic aliases.  It helps
        # with German titles without diacritics, while aliases without language
        # metadata are ignored before this function is involved.
        return bool(re.search(r'\b(?:der|die|das|und|ein|eine|einer|eines|mit|nicht|deutsch|drachen|zaehmen|zähmen|koenig|könig|krieg|liebe|welt|herr|herren|dunkel|nacht|wunder|leben|tod|zeit|haus|mann|frau|kind|kinder)\b', v))

    def _looks_iberian_title(self, value):
        # Kept only for compatibility with older calls; no longer used to drop
        # title variants.
        return False

    def _looks_non_pl_en_de_title(self, value):
        # Do not drop real title variants by language.  A word is allowed if it
        # comes from a title/alias and is the longest word of that variant.
        return False

    def _ascii_fold(self, value):
        try:
            return unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode('ascii')
        except Exception:
            return str(value or '')

    def _search_phrase_variants(self, value):
        out = []
        try:
            base = re.sub(r'\s+', ' ', str(value or '')).strip()
            if not base:
                return out

            def add(x):
                x = str(x or '').strip(' ._-')
                x = re.sub(r'\s+', ' ', x)
                if x and x not in out:
                    out.append(x)

            def add_release_forms(x):
                x = re.sub(r'\s+', ' ', str(x or '')).strip()
                if not x:
                    return
                clean = re.sub(r'[^\wąćęłńóśżźÄÖÜäöüß]+', ' ', x, flags=re.I).strip()
                if clean:
                    add(clean)
                    # Telegram release names are commonly separated by dots or underscores.
                    add(re.sub(r'\s+', '.', clean).strip('.'))
                    add(re.sub(r'\s+', '_', clean).strip('_'))
                    add(re.sub(r'\s+', '-', clean).strip('-'))

            add(base)
            add(base.replace(':', ' '))
            add_release_forms(base)
            folded = self._ascii_fold(base)
            if folded and folded != base:
                add(folded)
                add_release_forms(folded)
            # Polish titles often alternate between pełna forma and abbreviation:
            # "świętej Anny" / "św. Anny" / "sw Anny".
            sw_forms = set()
            for x in (base, folded):
                if not x:
                    continue
                sw_forms.add(re.sub(r'(?i)\bśw\.?\b', 'św', x))
                sw_forms.add(re.sub(r'(?i)\bsw\.?\b', 'sw', x))
                sw_forms.add(re.sub(r'(?i)\bświęt(?:a|y|e|ej|ego|emu|ą)\b', 'św', x))
                sw_forms.add(re.sub(r'(?i)\bswiet(?:a|y|e|ej|ego|emu|a)\b', 'sw', x))
            for x in sw_forms:
                add(x)
                add_release_forms(x)
            # Shorter token query: do not remove stopwords.  If a word is
            # actually in the title, it may be the only/longest searchable token.
            toks = [t for t in re.split(r'\W+', folded or base, flags=re.I) if len(t) > 1]
            if len(toks) >= 2:
                short = ' '.join(toks[:5])
                add(short)
                add_release_forms(short)
        except Exception:
            pass
        return out

    def _build_queries(self, data):
        """Build a hybrid Telegram query plan from approved title variants.

        The longest real word remains the main recall strategy. For episodes we
        interleave exact title-word + SxxEyy/Exx queries before broad title-only
        searches so unrelated episodes cannot consume the per-chat limit first.
        Movies receive at most a few full-title helper queries after all broad
        PL/DE/EN words; full phrases never replace the proven word strategy.

        For every accepted title variant we still take the longest word actually
        present in that title. We do not use unknown/random foreign aliases.
        """
        variants = self._wanted_variants(data, max_items=18)
        queries = []

        def add(q):
            q = re.sub(r'[^0-9A-Za-ząćęłńóśżźĄĆĘŁŃÓŚŻŹÄÖÜäöüß]+', ' ', str(q or ''), flags=re.I)
            q = re.sub(r'\s+', ' ', q).strip()
            if q and q not in queries:
                queries.append(q)

        def best_word(value):
            raw = str(value or '')

            def _pick(text):
                words = re.findall(r'[0-9A-Za-ząćęłńóśżźĄĆĘŁŃÓŚŻŹÄÖÜäöüß]+', text, flags=re.I)
                # Do not remove stopwords.  If the word is in the title, it can be used.
                # Prefer non-year / non-pure-number words when possible, but allow
                # numeric titles like "1917" when there is nothing else.
                non_numeric = [w for w in words if not re.match(r'^\d+$', w)]
                long_enough = [w for w in non_numeric if len(self._ascii_fold(w)) >= 3]
                candidates = long_enough or non_numeric or words
                return candidates, words

            # Main title first: "Ne Zha 2: W krainie potworów" -> search "Zha"
            # before considering words from the subtitle.
            head = re.split(r'[:\-–—]', raw, 1)[0]
            candidates, words = _pick(head)
            # For titles like He-Man, the part before hyphen is only "He";
            # use the whole title so "Man" can win.
            if not candidates or max([len(self._ascii_fold(x)) for x in candidates] or [0]) < 3:
                candidates, words = _pick(raw)
            if not candidates:
                return ''
            candidates = sorted(candidates, key=lambda x: (len(self._ascii_fold(x)), len(x)), reverse=True)
            return candidates[0]

        grouped = {0: [], 1: [], 2: [], 3: []}
        for v in variants:
            try:
                group = self._variant_lang_group(v, data)
            except Exception:
                group = 1
            grouped.setdefault(group, []).append(v)

        base_by_group = {0: [], 2: [], 1: []}

        def add_base(group, q):
            q = re.sub(r'[^0-9A-Za-ząćęłńóśżźĄĆĘŁŃÓŚŻŹÄÖÜäöüß]+', ' ', str(q or ''), flags=re.I)
            q = re.sub(r'\s+', ' ', q).strip()
            if q and q not in base_by_group.setdefault(group, []):
                base_by_group[group].append(q)

        # PL first, then DE, then EN/original. No generic/unknown aliases.
        for group in (0, 2, 1):
            for v in grouped.get(group, []):
                word = best_word(v)
                if not word:
                    continue
                add_base(group, word)
                folded = self._ascii_fold(word)
                if folded and folded.lower() != word.lower():
                    add_base(group, folded)

        base_queries = []
        for group in (0, 2, 1):
            for q in base_by_group.get(group, []):
                if q not in base_queries:
                    base_queries.append(q)

        if data.get('kind') == 'series':
            try:
                s = int(data.get('season') or 1)
                e = int(data.get('episode') or 1)
                # Reserve at least one exact query for PL, DE and EN/original,
                # then fill one extra slot (often the no-diacritics PL form).
                exact_words = []
                for group in (0, 2, 1):
                    if base_by_group.get(group):
                        q = base_by_group[group][0]
                        if q not in exact_words:
                            exact_words.append(q)
                for q in base_queries:
                    if q not in exact_words:
                        exact_words.append(q)
                    if len(exact_words) >= 4:
                        break
                for q in exact_words:
                    add('%s S%02dE%02d' % (q, s, e))
                for q in exact_words[:2]:
                    add('%s E%02d' % (q, e))
            except Exception:
                pass
            for q in base_queries:
                add(q)
        else:
            # Longest-word queries stay first and therefore receive most of the
            # search budget. Add only a small full-title precision tail.
            for q in base_queries:
                add(q)
            phrase_count = 0
            for group in (0, 2, 1):
                for value in grouped.get(group, []):
                    phrase = re.sub(
                        r'[^0-9A-Za-ząćęłńóśżźĄĆĘŁŃÓŚŻŹÄÖÜäöüß]+',
                        ' ', str(value or ''), flags=re.I,
                    )
                    phrase = re.sub(r'\s+', ' ', phrase).strip()
                    if len(phrase.split()) < 2 or phrase in queries:
                        continue
                    add(phrase)
                    phrase_count += 1
                    if phrase_count >= 3:
                        break
                if phrase_count >= 3:
                    break

        return queries[:14]

    def _message_matches(self, msg, data):
        blob = ' '.join([msg.get('filename') or '', msg.get('text') or '', msg.get('message_url') or ''])
        try:
            if self._series_episode_conflict(blob, data):
                return False
        except Exception:
            pass
        norm_blob = title_matcher.normalize(blob)
        variants = self._wanted_variants(data, max_items=10)
        try:
            score = max(title_matcher.score(blob, v) for v in variants if v)
        except Exception:
            score = 0
        compact_blob = title_matcher.compact(blob)
        compact_hit = False
        for v in variants:
            cv = title_matcher.compact(v)
            if cv and len(cv) >= 3 and cv in compact_blob:
                compact_hit = True
                break
        # Do not require a perfect title-score match. If the real PL/DE title
        # word is present, allow it; the query builder and direct search already
        # chose that word intentionally.
        if score < 55 and not compact_hit:
            return False
        if data.get('kind') == 'movie':
            year = str(data.get('year') or '').strip()
            # Year is helpful, but not mandatory. Many valid Telegram filenames
            # and poster-context children do not include the year.  Reject only
            # when the message contains a different explicit 19xx/20xx year and
            # does not contain the requested year.
            if year:
                years_in_blob = re.findall(r'(?<!\d)(?:19|20)\d{2}(?!\d)', blob)
                if years_in_blob and year not in years_in_blob:
                    return False
        if data.get('kind') == 'series':
            s = int(data.get('season') or 1)
            e = int(data.get('episode') or 1)
            patterns = [
                rf'\bs0?{s}\s*e0?{e}\b',
                rf'\b0?{s}x0?{e}\b',
                rf'\b(?:ep|episode|odc(?:inek)?\.?)\s*0?{e}\b',
            ]
            if not any(re.search(p, norm_blob, re.I) for p in patterns):
                if score < 82:
                    return False
        return True

    def _language_from_text(self, text):
        """Best-effort PL/DE/EN tag for the Telegram picker.

        Unknown files keep the historical PL fallback so they are not hidden by
        language filters.  This affects presentation only; Telegram results remain
        deliberately broad and are never rejected by this guess.
        """
        value = re.sub(r'[_\.\-]+', ' ', str(text or '')).lower()
        if re.search(r'\b(?:multi|dual audio|multiaudio)\b', value):
            return 'multi'
        found = []
        patterns = (
            ('pl', r'\b(?:polish|polski|lektor(?: pl)?|dubbing(?: pl)?|napisy pl|plsub|pldub)\b'),
            ('de', r'\b(?:deutsch|german|gerdub|de dub|de sub|german dub|german sub)\b'),
            ('en', r'\b(?:english|eng dub|eng sub|en dub|en sub|original audio)\b'),
        )
        for code, pattern in patterns:
            if re.search(pattern, value, re.I):
                found.append(code)
        if len(set(found)) > 1:
            return 'multi'
        return found[0] if found else 'pl'

    def _quality_from_text(self, text):
        m = re.search(r'(?<!\d)(2160|1080|720|540|480|360)p?(?!\d)', text or '', re.I)
        if m:
            return m.group(1) + 'p'
        if re.search(r'\b(?:4k|uhd)\b', text or '', re.I):
            return '4K'
        return 'HD'

    def _display_chat_title(self, title):
        title = re.sub(r'\s+', ' ', str(title or '')).strip(' @|-')
        if not title:
            return 'Telegram'
        title = re.sub(r'(?i)^telegram\s*[-•|]*\s*', '', title).strip() or title
        return title[:42]

    def _media_info_from_text(self, text):
        text = re.sub(r'[_\.]+', ' ', str(text or ' '))
        up = text.upper()
        tags = []
        checks = [
            ('HDCAM', r'\bHD\s*CAM\b|\bHDCAM\b'),
            ('CAM', r'\bCAM\b'),
            ('WEB-DL', r'\bWEB[- ]?DL\b'),
            ('WEBRip', r'\bWEB[- ]?RIP\b'),
            ('BluRay', r'\bBLU[- ]?RAY\b|\bBDRIP\b|\bBRRIP\b'),
            ('HDTV', r'\bHDTV\b'),
            ('DVDRip', r'\bDVD[- ]?RIP\b'),
            ('HEVC', r'\b(?:HEVC|H\.?265|X\.?265)\b'),
            ('AVC', r'\b(?:AVC|H\.?264|X\.?264)\b'),
            ('EAC3', r'\bE[- ]?AC3\b|\bDDP?5\.?1\b'),
            ('AC3', r'\bAC3\b'),
            ('MD', r'\bMD\b'),
            ('LD', r'\bLD\b'),
            ('Lektor', r'\bLEKTOR\b'),
            ('Dubbing', r'\bDUBBING\b|\bDUB\b'),
            ('Napisy', r'\bNAPISY\b|\bSUB(?:S|TITLES)?\b|\bPLSUB\b|\bDESUB\b'),
        ]
        for label, pattern in checks:
            if re.search(pattern, up, re.I) and label.upper() not in [x.upper() for x in tags]:
                tags.append(label)
        return tags[:7]

    def _info_from_message(self, msg, chat):
        parts = []
        txt = ' '.join([msg.get('filename') or '', msg.get('text') or ''])
        # Usuń @kanał z info, bo kanał/grupa jest osobnym segmentem labela.
        txt_for_tags = re.sub(r'(?<![A-Za-z0-9_])@[A-Za-z0-9_]{3,64}', ' ', txt)
        tags = self._media_info_from_text(txt_for_tags)
        if tags:
            parts.append(' '.join(tags))
        if msg.get('size'):
            parts.append(msg.get('size'))
        fname = self._best_filename_label(msg)
        if fname:
            parts.append(fname)
        # Kadr+ składa listę jako: TG • source • quality • info, więc info
        # trzymamy w stałym układzie: jakość/kodek/audio • rozmiar • nazwa_pliku.
        return ' • '.join([p for p in parts if p])[:180]

    def _fmt_size(self, size):
        try:
            size = int(size or 0)
            if size >= 1024 ** 3:
                return '%.2f GB' % (size / float(1024 ** 3))
            if size >= 1024 ** 2:
                return '%.0f MB' % (size / float(1024 ** 2))
        except Exception:
            pass
        return ''

    # ------------------------------------------------------------------ #
    # Config/helpers                                                       #
    # ------------------------------------------------------------------ #

    def _configured(self):
        try:
            if self.use_dialogs and self._mtproto_ready():
                return True
            if self.chats:
                return True
            fflog('[telegram] provider włączony, ale brak loginu albo listy grup/kanałów', 1)
            return False
        except Exception:
            return False

    def _normalize_phone(self, value):
        value = str(value or '').strip()
        value = re.sub(r'[\s\-().]+', '', value)
        if value and not value.startswith('+'):
            # Telegram najlepiej przyjmuje format międzynarodowy. Dla Polski
            # typowy błąd to wpisanie 48... bez plusa.
            if value.startswith('00'):
                value = '+' + value[2:]
            else:
                value = '+' + value
        return value

    def _session_dir(self):
        path = os.path.join(control.dataPath, 'telegram')
        if not os.path.exists(path):
            try:
                control.makeDirs(path)
            except Exception:
                os.makedirs(path, exist_ok=True)
        return path

    def _session_base(self):
        return os.path.join(self._session_dir(), re.sub(r'[^A-Za-z0-9._-]+', '_', self.session_name or 'kadrplus_telegram'))

    def _session_path(self):
        try:
            return self._session_base()
        except Exception:
            return self.session_name or 'kadrplus_telegram'

    def _session_meta_path(self):
        return self._session_base() + '.kadrmeta.json'

    def _session_files(self):
        base = self._session_base()
        names = [base, base + '.session', base + '.session-journal', self._session_meta_path()]
        # SQLite can create extra temporary files.
        try:
            folder = os.path.dirname(base)
            prefix = os.path.basename(base)
            for name in os.listdir(folder):
                if name.startswith(prefix + '.session'):
                    names.append(os.path.join(folder, name))
        except Exception:
            pass
        out = []
        for n in names:
            if n and n not in out:
                out.append(n)
        return out

    def _delete_session_files(self):
        try:
            for path in self._session_files():
                try:
                    if os.path.exists(path):
                        os.remove(path)
                        fflog(f'[telegram] usunięto starą sesję: {os.path.basename(path)}', 1)
                except Exception:
                    pass
        except Exception:
            fflog_exc(1)

    def _load_session_phone(self):
        try:
            path = self._session_meta_path()
            if not os.path.exists(path):
                return ''
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return self._normalize_phone(data.get('phone') or '')
        except Exception:
            return ''

    def _save_session_phone(self, phone):
        try:
            path = self._session_meta_path()
            with open(path, 'w', encoding='utf-8') as f:
                json.dump({'phone': self._normalize_phone(phone), 'saved': int(time.time())}, f)
        except Exception:
            pass

    def _forget_session_phone(self):
        try:
            path = self._session_meta_path()
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass

    def _prepare_session_for_phone(self, phone):
        try:
            saved = self._load_session_phone()
            if saved and saved != self._normalize_phone(phone):
                fflog(f'[telegram] numer zmieniony: {saved!r} -> {phone!r}; czyszczę sesję', 1)
                self._delete_session_files()
        except Exception:
            fflog_exc(1)

    def _ask_text(self, heading, hidden=False):
        try:
            kb = control.keyboard('', heading, hidden)
            kb.doModal()
            if kb.isConfirmed():
                return kb.getText()
        except Exception:
            fflog_exc(1)
        return ''

    def _public_chats(self):
        out = []
        for c in self.chats:
            ch = self._public_chat_name(c)
            if ch and ch not in out:
                out.append(ch)
        return out

    def _public_chat_name(self, value):
        value = (value or '').strip()
        if not value:
            return ''
        if value.startswith('-') or value.startswith('+') or 'joinchat' in value or '/+' in value:
            return ''
        value = value.replace('https://t.me/s/', '').replace('http://t.me/s/', '')
        value = value.replace('https://t.me/', '').replace('http://t.me/', '')
        value = value.lstrip('@').split('/', 1)[0].split('?', 1)[0].strip()
        if not re.match(r'^[A-Za-z0-9_]{3,64}$', value):
            return ''
        return value

    def _log_telethon_status(self):
        try:
            TelegramClient, _, _, _, _ = _tg_telethon_imports()
            if TelegramClient:
                if self._mtproto_ready():
                    fflog('[telegram] Telethon dostępny; sprawdź login / uprawnienia / wyniki w grupach', 1)
                else:
                    fflog('[telegram] Telethon dostępny, ale brak api_id/api_hash/phone w ustawieniach', 1)
            else:
                fflog('[telegram] Telethon niedostępny mimo vendora', 1)
        except Exception:
            pass

    def _get_session(self):
        if not self.session:
            self.session = requests.Session()
            self.session.headers.update(self.headers)
        return self.session

    def _first_match(self, text, pattern):
        m = re.search(pattern, text or '', re.I | re.S)
        return m.group(1) if m else ''

    def _clean_html(self, text):
        text = text or ''
        text = re.sub(r'<br\s*/?>', ' ', text, flags=re.I)
        text = re.sub(r'<[^>]+>', ' ', text)
        text = unescape(text)
        return re.sub(r'\s+', ' ', text).strip()

    def _setting_bool(self, value, default=False):
        if value is None or value == '':
            return bool(default)
        return str(value).strip().lower() in ('true', '1', 'yes', 'on')

    def _pack(self, data):
        raw = json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        return 'telegram:' + base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')

    def _unpack(self, token):
        token = str(token or '')
        if token.startswith('telegram:'):
            token = token.split(':', 1)[1]
        pad = '=' * (-len(token) % 4)
        return json.loads(base64.urlsafe_b64decode((token + pad).encode('ascii')).decode('utf-8'))
