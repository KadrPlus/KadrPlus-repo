# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""
    Kadr+ 2.0 — scraper KissKH (MULTI + napisy)

    Uwaga techniczna:
    KissKH używa API Angular oraz tokenów `kkey` dla endpointów stream/subtitle.
    Kodi nie ma Playwright/Chromium. 2.41.03 dodaje lekki fallback:
    automatyczne generowanie kkey przez enc-dec.app API.
    Nadal można wpisać ręcznie gotowe klucze:
      kisskh.stream_key
      kisskh.sub_key

    Flow:
      1. Search:      /api/DramaList/Search?q=...
      2. Details:     /api/DramaList/Drama/{id}?isq=false
      3. Stream:      /api/DramaList/Episode/{episode_id}.png?...&kkey=...
      4. Subtitles:   /api/Sub/{episode_id}?kkey=...
"""
from __future__ import annotations

import base64
import json
import os
import re
import struct
import time
import uuid
from html import unescape
from urllib.parse import quote, urlencode, urljoin, urlparse

from lib.ff import requests

# Lekki lokalny proxy dla KissKH. Kodi/libcurl na Androidzie potrafi zrywać
# bezpośrednie MP4 z videodelivery2.site błędem HTTP/2 framing layer.
# Python requests używa stabilnego HTTP/1.1, więc podajemy Kodi lokalny URL
# i strumieniujemy z CDN przez proxy tylko dla KissKH.
_KISSKH_PROXY_SERVER = None
_KISSKH_PROXY_PORT = None
_KISSKH_PROXY_THREAD = None
_KISSKH_PROXY_MAP = {}

from lib.ff.log_utils import fflog, fflog_exc
from lib.ff import control, source_utils, title_matcher



def _kisskh_proxy_cleanup(max_age=7200):
    try:
        now = time.time()
        for key, value in list(_KISSKH_PROXY_MAP.items()):
            if now - float(value.get('created') or 0) > max_age:
                _KISSKH_PROXY_MAP.pop(key, None)
    except Exception:
        pass


def _kisskh_proxy_start(preferred_port=0):
    global _KISSKH_PROXY_SERVER, _KISSKH_PROXY_PORT, _KISSKH_PROXY_THREAD
    try:
        if _KISSKH_PROXY_SERVER and _KISSKH_PROXY_PORT:
            return _KISSKH_PROXY_PORT

        import http.server
        import socketserver
        import threading

        class _KissKHThreadingServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
            daemon_threads = True
            allow_reuse_address = True

        class _KissKHProxyHandler(http.server.BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'
            server_version = 'KadrPlusKissKHProxy/1.0'

            def log_message(self, fmt, *args):
                try:
                    fflog('[kisskh-proxy] ' + (fmt % args), 0)
                except Exception:
                    pass

            def do_HEAD(self):
                self._handle(proxy_head=True)

            def do_GET(self):
                self._handle(proxy_head=False)

            def _token_from_path(self):
                m = re.match(r'^/kisskh/([A-Za-z0-9_-]{16,64})(?:/.*)?$', urlparse(self.path).path or '')
                return m.group(1) if m else ''

            def _handle(self, proxy_head=False):
                token = self._token_from_path()
                spec = _KISSKH_PROXY_MAP.get(token)
                if not spec:
                    self.send_error(404, 'KissKH proxy token not found')
                    return

                remote_url = spec.get('url') or ''
                headers = dict(spec.get('headers') or {})
                # Przekaż Range z Kodi, bo MP4 wymaga przewijania i buforowania po zakresach.
                if self.headers.get('Range'):
                    headers['Range'] = self.headers.get('Range')
                headers['Accept-Encoding'] = 'identity'
                headers['Connection'] = 'close'
                headers.pop('Host', None)

                try:
                    sess = requests.Session()
                    if proxy_head:
                        resp = sess.head(remote_url, headers=headers, allow_redirects=True, timeout=(10, 35))
                        # Niektóre CDN-y nie lubią HEAD — pobierz minimalny zakres.
                        if resp.status_code >= 400 or not resp.headers:
                            h2 = dict(headers)
                            h2['Range'] = h2.get('Range') or 'bytes=0-0'
                            resp = sess.get(remote_url, headers=h2, stream=True, allow_redirects=True, timeout=(10, 35))
                    else:
                        resp = sess.get(remote_url, headers=headers, stream=True, allow_redirects=True, timeout=(10, 90))

                    status = resp.status_code or 200
                    if status >= 400:
                        fflog(f'[kisskh-proxy] remote status={status} url={remote_url}', 1)
                    self.send_response(status)

                    pass_headers = ('Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges', 'Last-Modified', 'ETag')
                    sent_len = False
                    for name in pass_headers:
                        val = resp.headers.get(name)
                        if val:
                            self.send_header(name, val)
                            if name.lower() == 'content-length':
                                sent_len = True
                    if not resp.headers.get('Accept-Ranges'):
                        self.send_header('Accept-Ranges', 'bytes')
                    self.send_header('Connection', 'close')
                    self.end_headers()

                    if proxy_head:
                        try:
                            resp.close()
                        except Exception:
                            pass
                        return

                    try:
                        for chunk in resp.iter_content(chunk_size=256 * 1024):
                            if not chunk:
                                continue
                            self.wfile.write(chunk)
                    except (BrokenPipeError, ConnectionResetError):
                        pass
                    except Exception:
                        fflog_exc()
                    finally:
                        try:
                            resp.close()
                        except Exception:
                            pass
                except Exception:
                    fflog_exc()
                    try:
                        self.send_error(502, 'KissKH proxy upstream error')
                    except Exception:
                        pass

        preferred_port = int(preferred_port or 0)
        if preferred_port and not (1024 < preferred_port < 65536):
            preferred_port = 0
        try_ports = [preferred_port] if preferred_port else []
        try_ports += [0]
        last_exc = None
        for port in try_ports:
            try:
                srv = _KissKHThreadingServer(('127.0.0.1', port), _KissKHProxyHandler)
                _KISSKH_PROXY_SERVER = srv
                _KISSKH_PROXY_PORT = int(srv.server_address[1])
                _KISSKH_PROXY_THREAD = threading.Thread(target=srv.serve_forever, name='KissKHProxy', daemon=True)
                _KISSKH_PROXY_THREAD.start()
                fflog(f'[kisskh-proxy] started on 127.0.0.1:{_KISSKH_PROXY_PORT}', 1)
                return _KISSKH_PROXY_PORT
            except Exception as exc:
                last_exc = exc
                continue
        if last_exc:
            fflog(f'[kisskh-proxy] cannot start: {last_exc!r}', 1)
        return 0
    except Exception:
        fflog_exc()
        return 0


class source:
    has_sort_order = True
    priority = 2
    language = ['de']

    def __init__(self):
        self.priority = 2
        # Loader zostaje w grupie DE, żeby nie zmienić zakresu wyszukiwania użytkownika,
        # ale zwracane źródła oznaczamy jako MULTI: oryginalny dźwięk + wybór napisów.
        self.language = ['de']

        preferred_base = (control.setting('kisskh.base') or 'https://kisskh.nl').strip().rstrip('/')
        if not preferred_base.startswith('http'):
            preferred_base = 'https://' + preferred_base

        # KissKH UI działa pod .xyz, ale API z logów odpowiada pod .nl.
        # Nie zaczynamy już od .xyz, bo dawało dwa 404 i wydłużało każde wyszukiwanie.
        self.base_candidates = self._make_base_candidates(preferred_base)
        self.base_link = self.base_candidates[0] if self.base_candidates else preferred_base
        self.api_link = self.base_link.rstrip('/') + '/api/'
        self._rate_limited_until = 0

        self.stream_key = (control.setting('kisskh.stream_key') or '').strip()
        self.sub_key = (control.setting('kisskh.sub_key') or '').strip()
        self.auto_key = self._setting_bool(control.setting('kisskh.auto_key'), default=True)
        self.key_api = (control.setting('kisskh.key_api') or 'https://enc-dec.app/api').strip().rstrip('/')
        # 2.41.07: stabilizacja odtwarzania. Domyślnie nie obniżamy jakości,
        # tylko przepuszczamy bezpośredni MP4 przez lokalny proxy HTTP/1.1.
        self.proxy_stream = self._setting_bool(control.setting('kisskh.proxy_stream'), default=True)
        try:
            self.proxy_port = int(control.setting('kisskh.proxy_port') or 0)
        except Exception:
            self.proxy_port = 0
        self._kkey_cache = {}
        self._stream_quality_cache = {}

        self.headers = {
            'User-Agent': (
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                'AppleWebKit/537.36 (KHTML, like Gecko) '
                'Chrome/147.0.0.0 Safari/537.36'
            ),
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
            'Referer': self.base_link + '/',
        }
        self.session = None
        self._search_cache = {}
        self._detail_cache = {}

    # ------------------------------------------------------------------ #
    #  Metody wymagane przez Kadr+/FanFilm                                #
    # ------------------------------------------------------------------ #

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        fflog(f'[kisskh] movie {title=} {localtitle=} {year=}', 1)
        year_alt = kwargs.get('year_alt')
        if year_alt:
            year = (year, year_alt)
        item = self._search_best(title, localtitle, aliases, year, content_type='movie')
        if not item:
            return None
        return self._pack({
            'kind': 'movie',
            'drama_id': item.get('id'),
            'title': item.get('title') or item.get('name') or item.get('dramaName') or title,
            'episode_number': 1,
        })

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        fflog(f'[kisskh] tvshow {tvshowtitle=} {localtvshowtitle=} {year=}', 1)
        year_alt = kwargs.get('year_alt')
        if year_alt:
            year = (year, year_alt)
        item = self._search_best(tvshowtitle, localtvshowtitle, aliases, year, content_type='tvshow')
        if not item:
            return None
        return self._pack({
            'kind': 'series',
            'drama_id': item.get('id'),
            'title': item.get('title') or item.get('name') or item.get('dramaName') or tvshowtitle,
        })

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        fflog(f'[kisskh] episode {url=} {season=} {episode=}', 1)
        if not url:
            return None
        try:
            data = self._unpack(url)
            data['season'] = int(season or 1)
            data['episode_number'] = float(episode or 1)
            # Dla azjatyckich dram KissKH zwykle numeruje odcinki płasko.
            # Jeśli Kodi poda sezon > 1, dodajemy tę informację do tokena i próbujemy
            # dobrać serię typu "Title Season 2" już na etapie wyszukiwania/tvshow.
            detail = self._get_detail(data.get('drama_id'))
            ep = self._find_episode(detail, data['episode_number'])
            if not ep:
                fflog(f'[kisskh] brak episode_id dla EP {data["episode_number"]}', 1)
                return None
            data['episode_id'] = ep.get('id')
            data['episode_number'] = ep.get('number', data['episode_number'])
            data['sub_count'] = ep.get('sub', 0)
            return self._pack(data)
        except Exception:
            fflog_exc()
            return None

    def sources(self, url, hostDict, hostprDict):
        result = []
        fflog(f'[kisskh] sources {url=}', 1)
        if not url:
            return result
        try:
            data = self._unpack(url)
            if not data.get('episode_id'):
                data = self._ensure_movie_episode(data)
            if not data.get('episode_id'):
                return result

            # Lista źródeł ma być krótka i czytelna. Numer odcinka oraz informacja
            # o auto-kkey nie są potrzebne w labelu - Kodi i tak wie, który odcinek
            # jest odtwarzany, a kkey to detal techniczny. Słowo "Napisy" zostawiamy,
            # żeby formatter Kadr+ pokazał ładne "NAPISY DE".
            info = 'Napisy'

            result.append({
                'source': 'KissKH',
                'quality': self._source_quality(data),
                'language': 'multi',
                'url': self._pack(data),
                'info': info,
                'direct': True,
                'debridonly': False,
            })
        except Exception:
            fflog_exc()
        fflog(f'[kisskh] zwracam {len(result)} zrodel', 1)
        return result

    def resolve(self, url):
        fflog(f'[kisskh] resolve {url=}', 1)
        try:
            data = self._unpack(url)
            if not data.get('episode_id'):
                data = self._ensure_movie_episode(data)
            episode_id = data.get('episode_id')
            if not episode_id:
                return None

            referer = self._episode_referer(data)
            stream_key = self.stream_key or self._get_auto_kkey(int(episode_id), 'vid')
            if not stream_key:
                control.infoDialog(
                    'Brak kkey KissKH. Włącz auto kkey albo wpisz kisskh.stream_key.',
                    heading='KissKH', icon='WARNING', time=4500, sound=False
                )
                return None

            stream_url = self._get_stream_url(int(episode_id), stream_key, referer)
            if not stream_url:
                return None

            stream_url = self._normalize_stream_url(stream_url, referer)
            subs = self._prepare_subtitles(data, referer)
            if subs:
                # Wspólny resolver FanFilm przyjmuje URL jako tekst. Zwracanie
                # krotki (URL, napisy) kończyło się wyjątkiem przy sprawdzaniu
                # ``startswith`` i źródło wyglądało na martwe. Player Kadr+
                # ma już bezpieczny kanał przekazywania lokalnych napisów.
                try:
                    control.window().setProperty(
                        'source.subtitles',
                        json.dumps(list(subs.values()), ensure_ascii=False),
                    )
                except Exception:
                    fflog_exc(1)
            return stream_url
        except Exception:
            fflog_exc()
            return None

    # ------------------------------------------------------------------ #
    #  Search/detail                                                       #
    # ------------------------------------------------------------------ #

    def _search_best(self, title, localtitle, aliases, year, content_type='tvshow'):
        try:
            self._init_session()
            year_int, year_alt = self._year_pair(year)
            variants = title_matcher.title_variants(title, localtitle, aliases, max_items=6)
            if not variants:
                variants = [title or localtitle]

            # 2.41.02: NIE odpytujemy już automatycznie "Season 2/3/4".
            # W logu powodowało to 7 + 50 + 50 + 50 wyników, a potem dziesiątki
            # requestów /Drama/<id>, kończąc się 429 Too Many Requests i timeoutem.
            all_results = []
            seen_ids = set()
            for q in variants[:4]:
                for item in self._search(q):
                    item_id = item.get('id') or item.get('dramaId') or item.get('drama_id')
                    if not item_id or item_id in seen_ids:
                        continue
                    item['id'] = item_id
                    seen_ids.add(item_id)
                    all_results.append(item)
                    if len(all_results) >= 12:
                        break
                if len(all_results) >= 12:
                    break

            if not all_results:
                fflog(f'[kisskh] brak wyników dla {title!r}', 1)
                return None

            ranked = []
            for item in all_results:
                cand_title = item.get('title') or item.get('name') or item.get('dramaName') or item.get('label') or ''
                try:
                    score = max(title_matcher.score(cand_title, v) for v in variants if v)
                except Exception:
                    score = 0
                item_year = self._extract_year(
                    ' '.join(str(item.get(k) or '') for k in ('title', 'name', 'dramaName', 'label', 'releaseDate', 'year'))
                )
                if year_int and item_year and abs(int(item_year) - int(year_int)) <= 1:
                    score += 7
                elif year_alt and item_year and abs(int(item_year) - int(year_alt)) <= 1:
                    score += 5
                ranked.append((score, item))

            ranked.sort(key=lambda x: x[0], reverse=True)

            # Dla bardzo dobrego dopasowania nie pobieramy detail tylko po to, żeby sprawdzić typ.
            # Detail pobierze się dopiero w episode(), jeden raz, dla wybranego tytułu.
            best_score, best = ranked[0]
            if best and best_score >= 78:
                fflog(f'[kisskh] match {best.get("title") or best.get("name") or best.get("dramaName")} score={best_score}', 1)
                return best

            # Przy słabszych wynikach sprawdzamy najwyżej 2 kandydatów, nie wszystkie.
            for score, item in ranked[:2]:
                try:
                    detail = self._get_detail(item.get('id'))
                    if not detail:
                        continue
                    typ = (detail.get('type') or '').lower()
                    boosted = score
                    if content_type == 'movie' and 'movie' in typ:
                        boosted += 8
                    if content_type != 'movie' and any(x in typ for x in ('drama', 'series', 'tv', 'show')):
                        boosted += 5
                    if boosted >= 78:
                        fflog(f'[kisskh] match po detail {detail.get("title") or item.get("title")} score={boosted}', 1)
                        return item
                except Exception:
                    fflog_exc()

            fflog(f'[kisskh] brak pewnego matcha score={best_score}', 1)
            return None
        except Exception:
            fflog_exc()
            return None

    def _search(self, query):
        query = (query or '').strip()
        if not query:
            return []
        if query in self._search_cache:
            return self._search_cache[query]

        encoded = quote(query)
        paths = (
            'DramaList/Search?q=' + encoded,
            'DramaList/Search?q=' + encoded + '&type=0',
        )
        last_status = None
        for base in self.base_candidates:
            api = base.rstrip('/') + '/api/'
            for path in paths:
                url = urljoin(api, path)
                try:
                    data = self._get_json(url, referer=base.rstrip('/') + '/', quiet_404=True)
                    items = self._items_from_search_payload(data)
                    if items:
                        self._set_active_base(base)
                        self._search_cache[query] = items
                        fflog(f'[kisskh] search {query!r}: {len(items)} base={base}', 1)
                        return items
                    if data == []:
                        last_status = 'empty'
                except Exception:
                    fflog_exc()
        fflog(f'[kisskh] brak wyników dla {query!r}; last={last_status}', 1)
        self._search_cache[query] = []
        return []

    def _get_detail(self, drama_id):
        if not drama_id:
            return {}
        drama_id = int(drama_id)
        if drama_id in self._detail_cache:
            return self._detail_cache[drama_id]
        if time.time() < getattr(self, '_rate_limited_until', 0):
            fflog('[kisskh] pomijam detail: API ma chwilowy limit 429', 1)
            return {}

        # 2.41.02: najpierw tylko aktywna domena i tylko isq=false.
        # Dopiero 404/brak danych uruchamia krótkie fallbacki. To usuwa timeouty.
        paths = (f'DramaList/Drama/{drama_id}?isq=false',)
        bases = list(self.base_candidates[:2])
        if self.base_link not in bases:
            bases.insert(0, self.base_link)
        for base in bases:
            api = base.rstrip('/') + '/api/'
            for path in paths:
                url = urljoin(api, path)
                try:
                    data = self._get_json(url, referer=base.rstrip('/') + '/', quiet_404=True)
                except Exception:
                    fflog_exc()
                    continue
                if isinstance(data, dict) and data:
                    data = self._normalize_detail_payload(data)
                    self._set_active_base(base)
                    self._detail_cache[drama_id] = data
                    return data
                if time.time() < getattr(self, '_rate_limited_until', 0):
                    return {}
        return {}

    def _find_episode(self, detail, wanted_episode):
        episodes = detail.get('episodes') or []
        if not episodes:
            return None
        try:
            wanted = float(wanted_episode)
        except Exception:
            wanted = 1.0
        # Najpierw dokładny numer.
        for ep in episodes:
            try:
                if float(ep.get('number')) == wanted:
                    return ep
            except Exception:
                pass
        # Potem int fallback — KissKH czasem ma 1.0/1 lub odcinki specjalne .5.
        for ep in episodes:
            try:
                if int(float(ep.get('number'))) == int(wanted):
                    return ep
            except Exception:
                pass
        return None

    def _ensure_movie_episode(self, data):
        try:
            detail = self._get_detail(data.get('drama_id'))
            ep = self._find_episode(detail, data.get('episode_number') or 1)
            if not ep and detail.get('episodes'):
                ep = detail['episodes'][0]
            if ep:
                data['episode_id'] = ep.get('id')
                data['episode_number'] = ep.get('number', data.get('episode_number') or 1)
                data['sub_count'] = ep.get('sub', 0)
                if not data.get('title'):
                    data['title'] = detail.get('title')
        except Exception:
            fflog_exc()
        return data

    # ------------------------------------------------------------------ #
    #  Stream/subtitles                                                    #
    # ------------------------------------------------------------------ #

    def _source_quality(self, data):
        """Try to show the real KissKH quality on the source list.

        Older builds displayed 1080p unconditionally.  KissKH may label the
        stream as 1080 while the actual file is e.g. 1280x544.  We read the
        stream URL and, when it is cheap enough, probe HLS/MP4 metadata.
        """
        try:
            episode_id = int(data.get('episode_id') or 0)
            if not episode_id:
                return 'HD'
            cached = self._stream_quality_cache.get(episode_id)
            if cached and (time.time() - cached.get('ts', 0) < 900):
                return cached.get('quality') or 'HD'
            referer = self._episode_referer(data)
            stream_key = self.stream_key or self._get_auto_kkey(episode_id, 'vid')
            if not stream_key:
                return 'HD'
            stream_url = self._get_stream_url(episode_id, stream_key, referer)
            quality = self._detect_stream_quality(stream_url, referer) or 'HD'
            self._stream_quality_cache[episode_id] = {'quality': quality, 'ts': time.time()}
            fflog(f'[kisskh] detected source quality ep={episode_id}: {quality}', 1)
            return quality
        except Exception:
            fflog_exc()
            return 'HD'

    def _detect_stream_quality(self, stream_url, referer=''):
        try:
            url = str(stream_url or '').replace('\\/', '/').split('|', 1)[0]
            if not url.startswith('http'):
                return ''
            # Fast path: URL or HLS variant names sometimes include 1080p/720p.
            q = self._quality_from_text(url)
            if q:
                return q
            headers = dict(self.headers)
            headers.update({
                'Referer': referer or self.base_link + '/',
                'Origin': self.base_link,
                'Accept': '*/*',
                'Accept-Encoding': 'identity',
                'Connection': 'close',
            })
            if re.search(r'\.m3u8(?:\?|$)', url, re.I):
                return self._detect_m3u8_quality(url, headers)
            if re.search(r'\.mpd(?:\?|$)', url, re.I):
                return self._detect_mpd_quality(url, headers)
            if self._should_proxy_stream(url) or re.search(r'\.mp4(?:\?|$)', url, re.I):
                return self._detect_mp4_quality(url, headers)
        except Exception:
            fflog_exc()
        return ''

    def _quality_from_text(self, text):
        try:
            text = str(text or '')
            m = re.search(r'(?<!\d)(2160|1440|1080|720|576|544|540|480|360)p(?!\d)', text, re.I)
            if m:
                return m.group(1) + 'p'
            m = re.search(r'(\d{3,4})\s*[xX]\s*(\d{3,4})', text)
            if m:
                return self._quality_from_height(int(m.group(2)))
        except Exception:
            pass
        return ''

    def _quality_from_height(self, height):
        try:
            h = int(height or 0)
            if h >= 2000:
                return '2160p'
            if h >= 1300:
                return '1440p'
            if h >= 1000:
                return '1080p'
            if h >= 700:
                return '720p'
            if h >= 300:
                return f'{h}p'
        except Exception:
            pass
        return ''

    def _detect_m3u8_quality(self, url, headers):
        try:
            r = self._get_session().get(url, headers=headers, timeout=(5, 8))
            if r.status_code >= 400:
                return ''
            text = r.text or ''
            heights = []
            for m in re.finditer(r'RESOLUTION\s*=\s*(\d+)\s*x\s*(\d+)', text, re.I):
                try:
                    heights.append(int(m.group(2)))
                except Exception:
                    pass
            if heights:
                return self._quality_from_height(max(heights))
            return self._quality_from_text(text)
        except Exception:
            fflog_exc()
            return ''

    def _detect_mpd_quality(self, url, headers):
        try:
            r = self._get_session().get(url, headers=headers, timeout=(5, 8))
            if r.status_code >= 400:
                return ''
            text = r.text or ''
            heights = []
            for m in re.finditer(r'height\s*=\s*["\'](\d+)["\']', text, re.I):
                try:
                    heights.append(int(m.group(1)))
                except Exception:
                    pass
            if heights:
                return self._quality_from_height(max(heights))
            return self._quality_from_text(text)
        except Exception:
            fflog_exc()
            return ''

    def _detect_mp4_quality(self, url, headers):
        try:
            h = dict(headers or {})
            h['Range'] = 'bytes=0-1048575'
            r = self._get_session().get(url, headers=h, stream=True, timeout=(6, 10), allow_redirects=True)
            if r.status_code >= 400:
                return ''
            data = b''
            for chunk in r.iter_content(chunk_size=65536):
                if chunk:
                    data += chunk
                if len(data) >= 1048576:
                    break
            try:
                r.close()
            except Exception:
                pass
            wh = self._mp4_dimensions_from_bytes(data)
            if wh:
                w, hgt = wh
                fflog(f'[kisskh] MP4 dimensions detected: {w}x{hgt}', 1)
                return self._quality_from_height(hgt)
        except Exception:
            fflog_exc()
        return ''

    def _mp4_dimensions_from_bytes(self, data):
        try:
            if not data:
                return None
            # VisualSampleEntry boxes: 4-byte size + type avc1/hvc1/hev1/mp4v.
            # Width/height are 24/26 bytes from box start.
            for typ in (b'avc1', b'hvc1', b'hev1', b'mp4v'):
                start = 0
                while True:
                    idx = data.find(typ, start)
                    if idx < 4:
                        break
                    box_start = idx - 4
                    if box_start + 28 <= len(data):
                        width = struct.unpack('>H', data[box_start + 24:box_start + 26])[0]
                        height = struct.unpack('>H', data[box_start + 26:box_start + 28])[0]
                        if 160 <= width <= 10000 and 120 <= height <= 10000:
                            return width, height
                    start = idx + 4
        except Exception:
            pass
        return None

    def _get_stream_url(self, episode_id, kkey, referer):
        paths = (
            f'DramaList/Episode/{episode_id}.png?err=false&ts=&time=&kkey={quote(kkey)}',
            f'DramaList/Episode/{episode_id}.png?err=false&ts=null&time=null&kkey={quote(kkey)}',
        )
        for base in self.base_candidates:
            api = base.rstrip('/') + '/api/'
            for path in paths:
                url = urljoin(api, path)
                try:
                    data = self._get_json(url, referer=referer or base.rstrip('/') + '/', quiet_404=True)
                except Exception:
                    fflog_exc()
                    continue
                if isinstance(data, dict):
                    video = data.get('Video') or data.get('video') or data.get('src') or data.get('url')
                    if video:
                        self._set_active_base(base)
                        fflog(f'[kisskh] stream url OK for ep={episode_id} base={base}', 1)
                        return video
                    fflog(f'[kisskh] brak pola Video, keys={list(data.keys())}', 1)
                elif isinstance(data, str) and data.startswith('http'):
                    self._set_active_base(base)
                    return data
        return None

    def _get_subtitles(self, data, kkey=None):
        episode_id = data.get('episode_id')
        if not episode_id:
            return []
        if not kkey:
            kkey = self.sub_key or self._get_auto_kkey(int(episode_id), 'sub')
        if not kkey:
            return []
        referer = self._episode_referer(data)
        path = f'Sub/{int(episode_id)}?kkey={quote(kkey)}'
        for base in self.base_candidates:
            api = base.rstrip('/') + '/api/'
            try:
                raw = self._get_json(urljoin(api, path), referer=referer, quiet_404=True)
            except Exception:
                fflog_exc()
                continue
            if isinstance(raw, list):
                self._set_active_base(base)
                return raw
            items = self._items_from_search_payload(raw)
            if items:
                self._set_active_base(base)
                return items
        return []

    def _prepare_subtitles(self, data, referer):
        subs_out = {}
        try:
            subs = self._get_subtitles(data)
            if not subs:
                return subs_out

            try:
                raw_langs = []
                for sub in subs:
                    raw_langs.append('%s/%s' % (self._subtitle_label(sub), self._subtitle_lang(sub)))
                fflog(f'[kisskh] raw subtitles: {raw_langs}', 1)
            except Exception:
                pass

            temp_dir = os.path.join(control.dataPath, 'kisskh_subs')
            try:
                os.makedirs(temp_dir, exist_ok=True)
            except Exception:
                if not os.path.exists(temp_dir):
                    os.makedirs(temp_dir)

            candidates = []
            seen = set()
            for idx, sub in enumerate(subs, start=1):
                src = self._subtitle_src(sub)
                if not src:
                    fflog(f'[kisskh] pomijam napisy bez src: {sub}', 1)
                    continue
                src_key = src.split('?', 1)[0].lower()
                label = self._subtitle_label(sub, idx)
                land = self._subtitle_lang(sub, label)
                prio = self._subtitle_priority(label, land)
                key = (src_key, label.lower(), land.lower())
                if key in seen:
                    continue
                seen.add(key)
                candidates.append((prio, idx, src, label, land, sub))

            # Niemieckie napisy idą pierwsze, potem EN, potem reszta. Kodi dostaje tylko
            # listę plików, więc kolejność ma znaczenie przy domyślnym wyborze ścieżki.
            candidates.sort(key=lambda x: (x[0], x[1]))

            for order, (_, idx, src, label, land, sub) in enumerate(candidates, start=1):
                ext = os.path.splitext(src.split('?', 1)[0])[1].lower()
                if ext not in ('.srt', '.vtt', '.ass', '.ssa'):
                    ext = '.srt'
                safe_label = self._safe_subtitle_name(label, land)
                safe = re.sub(r'[^a-zA-Z0-9._-]+', '_', f'{order:02d}_{data.get("episode_id")}_{safe_label}_{idx}')
                path = os.path.join(temp_dir, safe + ext)
                if self._download_subtitle(src, path, referer):
                    display_label = self._display_subtitle_label(label, land, order)
                    # Jeśli dwa napisy mają tę samą nazwę, zachowaj oba pod unikalnym kluczem.
                    out_key = display_label
                    if out_key in subs_out:
                        out_key = f'{display_label} #{idx}'
                    subs_out[out_key] = path
            if subs_out:
                fflog(f'[kisskh] subtitles: {list(subs_out.keys())}', 1)
        except Exception:
            fflog_exc()
        return subs_out

    def _subtitle_src(self, sub):
        try:
            if isinstance(sub, str):
                src = sub
            elif isinstance(sub, dict):
                src = ''
                for key in ('src', 'url', 'link', 'file', 'path', 'subtitle', 'sub', 'href'):
                    val = sub.get(key)
                    if isinstance(val, str) and val.strip():
                        src = val.strip()
                        break
                # Czasem właściwy URL siedzi głębiej albo pod niestandardowym kluczem.
                if not src:
                    for val in sub.values():
                        if isinstance(val, str) and re.search(r'(?:https?:)?//|\.srt\b|\.vtt\b|\.ass\b|\.ssa\b', val, re.I):
                            src = val.strip()
                            break
            else:
                src = ''
            src = unescape(str(src or '')).replace('\\/', '/').strip().strip('"\'')
            if not src:
                return ''
            if src.startswith('//'):
                src = 'https:' + src
            elif src.startswith('/'):
                src = urljoin(self.base_link + '/', src.lstrip('/'))
            elif not src.startswith('http') and re.search(r'\.(?:srt|vtt|ass|ssa)(?:\?|$)', src, re.I):
                src = urljoin(self.base_link + '/', src)
            if not src.startswith('http'):
                return ''
            return src
        except Exception:
            fflog_exc()
            return ''

    def _subtitle_label(self, sub, idx=0):
        try:
            if isinstance(sub, dict):
                for key in ('label', 'name', 'title', 'language', 'lang', 'land'):
                    val = sub.get(key)
                    if isinstance(val, str) and val.strip():
                        return val.strip()
            elif isinstance(sub, str):
                m = re.search(r'([A-Za-z]{2,20})\.(?:srt|vtt|ass|ssa)\b', sub, re.I)
                if m:
                    return m.group(1)
        except Exception:
            pass
        return f'Sub {idx or 1}'

    def _subtitle_lang(self, sub, label=None):
        try:
            if isinstance(sub, dict):
                for key in ('land', 'lang', 'language', 'srclang'):
                    val = sub.get(key)
                    if isinstance(val, str) and val.strip():
                        return val.strip()
        except Exception:
            pass
        return (label or '').strip()

    def _is_german_subtitle(self, label, land):
        blob = ' '.join([str(label or ''), str(land or '')]).lower()
        return bool(re.search(r'\b(de|deu|ger|german|deutsch|alem[aá]n|allemand|germany)\b', blob, re.I))

    def _is_english_subtitle(self, label, land):
        blob = ' '.join([str(label or ''), str(land or '')]).lower()
        return bool(re.search(r'\b(en|eng|english)\b', blob, re.I))

    def _subtitle_priority(self, label, land):
        if self._is_german_subtitle(label, land):
            return 0
        if self._is_english_subtitle(label, land):
            return 10
        return 20

    def _safe_subtitle_name(self, label, land):
        if self._is_german_subtitle(label, land):
            return 'DE_Deutsch'
        if self._is_english_subtitle(label, land):
            return 'EN_English'
        value = (label or land or 'sub').strip()
        return re.sub(r'[^A-Za-z0-9._-]+', '_', value)[:40] or 'sub'

    def _display_subtitle_label(self, label, land, order):
        if self._is_german_subtitle(label, land):
            return 'Deutsch / German'
        if self._is_english_subtitle(label, land):
            return 'English'
        value = (label or land or f'Sub {order}').strip()
        return value

    def _download_subtitle(self, url, path, referer):
        try:
            # 2.41.03: najpierw próbujemy gotowego dekodera EncDecEndpoints.
            # KissKH często zwraca zaszyfrowane napisy; Kodi potrzebuje SRT/VTT.
            decrypted = self._dec_kisskh_subtitle(url)
            if decrypted:
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(decrypted)
                return True

            headers = dict(self.headers)
            headers['Referer'] = referer or self.base_link + '/'
            r = self._get_session().get(url, headers=headers, timeout=30)
            if r.status_code >= 400 or not r.content:
                return False
            content = r.content
            with open(path, 'wb') as f:
                f.write(content)
            return True
        except Exception:
            fflog_exc()
            return False

    def _normalize_stream_url(self, url, referer):
        url = (url or '').replace('\\/', '/').strip()
        if url.startswith('//'):
            url = 'https:' + url
        if not url.startswith('http'):
            url = urljoin(self.base_link + '/', url)

        headers = {
            'Referer': referer or self.base_link + '/',
            'Origin': self.base_link,
            'User-Agent': self.headers['User-Agent'],
            'Accept': '*/*',
            'Accept-Language': self.headers.get('Accept-Language') or 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
            'Accept-Encoding': 'identity',
            'Connection': 'close',
        }

        # 2.41.07: nie obniżamy jakości. Jeśli KissKH zwraca bezpośredni MP4
        # z CDN, Kodi czasem zrywa połączenie przez HTTP/2. Lokalny proxy pobiera
        # ten sam URL przez requests/HTTP/1.1 i podaje go Kodi po 127.0.0.1.
        if self.proxy_stream and self._should_proxy_stream(url):
            proxied = self._make_proxy_stream_url(url, headers)
            if proxied:
                fflog('[kisskh] using local HTTP/1.1 proxy for stream', 1)
                return proxied

        strhdr = urlencode(headers)
        if '|' not in url:
            url = url + '|' + strhdr
        return url

    def _should_proxy_stream(self, url):
        u = (url or '').lower()
        if '.m3u8' in u or '.mpd' in u:
            return False
        return bool(re.search(r'(?:videodelivery\d*\.site|\.mp4(?:\?|$)|/mp4/)', u, re.I))

    def _make_proxy_stream_url(self, remote_url, headers):
        try:
            port = _kisskh_proxy_start(self.proxy_port)
            if not port:
                return ''
            token = uuid.uuid4().hex
            _kisskh_proxy_cleanup()
            _KISSKH_PROXY_MAP[token] = {
                'url': remote_url,
                'headers': dict(headers or {}),
                'created': time.time(),
            }
            return f'http://127.0.0.1:{port}/kisskh/{token}/video.mp4'
        except Exception:
            fflog_exc()
            return ''

    def _setting_bool(self, value, default=False):
        if value is None or value == '':
            return bool(default)
        return str(value).strip().lower() in ('true', '1', 'yes', 'on')

    def _get_auto_kkey(self, episode_id, key_type):
        if not self.auto_key:
            return ''
        key_type = 'sub' if str(key_type).lower().startswith('sub') else 'vid'
        cache_key = (int(episode_id), key_type)
        if cache_key in self._kkey_cache:
            return self._kkey_cache[cache_key]
        try:
            api = (self.key_api or 'https://enc-dec.app/api').rstrip('/')
            url = f'{api}/enc-kisskh?text={int(episode_id)}&type={key_type}'
            fflog(f'[kisskh] auto kkey GET {url}', 1)
            headers = {
                'User-Agent': self.headers.get('User-Agent'),
                'Accept': 'application/json, text/plain, */*',
                'Referer': self.base_link + '/',
            }
            r = self._get_session().get(url, headers=headers, timeout=15)
            if r.status_code >= 400:
                fflog(f'[kisskh] auto kkey status={r.status_code}', 1)
                return ''
            try:
                data = r.json()
            except Exception:
                data = None
            result = ''
            if isinstance(data, dict):
                if str(data.get('status')) in ('200', 'OK', 'ok', 'True') or data.get('result'):
                    result = data.get('result') or data.get('key') or data.get('kkey') or ''
            else:
                text = (r.text or '').strip()
                if re.match(r'^[A-Za-z0-9_-]{20,}$', text):
                    result = text
            result = str(result or '').strip()
            if result:
                self._kkey_cache[cache_key] = result
                fflog(f'[kisskh] auto kkey OK type={key_type} ep={episode_id}', 1)
            return result
        except Exception:
            fflog_exc()
            return ''

    def _dec_kisskh_subtitle(self, subtitle_url):
        if not (self.auto_key and subtitle_url):
            return ''
        try:
            api = (self.key_api or 'https://enc-dec.app/api').rstrip('/')
            url = f'{api}/dec-kisskh?url={quote(subtitle_url, safe="")}'
            fflog('[kisskh] auto subtitle decrypt via enc-dec.app', 1)
            headers = {
                'User-Agent': self.headers.get('User-Agent'),
                'Accept': 'text/plain, */*',
                'Referer': self.base_link + '/',
            }
            r = self._get_session().get(url, headers=headers, timeout=25)
            if r.status_code >= 400:
                return ''
            text = (r.text or '').strip('﻿')
            if not text:
                return ''
            # Odrzuć ewidentne JSON-y błędów. Poprawny wynik to zwykle WEBVTT/SRT/plain.
            if text.lstrip().startswith('{') and 'error' in text[:200].lower():
                return ''
            if 'WEBVTT' not in text[:100] and not re.match(r'\s*\d+\s*\n\s*\d\d?:\d\d:', text[:200]):
                # Nie musi być idealny SRT, ale powinno wyglądać jak tekst napisów.
                if len(text) < 20:
                    return ''
            return text
        except Exception:
            fflog_exc()
            return ''

    def _make_base_candidates(self, preferred):
        bases = []
        # .xyz jest obecnie innym serwisem WordPress i jego stare API zwraca 404.
        # Nie odpytujemy go przy każdym tytule. Pozostają trzy aktywne fronty
        # korzystające z tego samego API Angular.
        if preferred and 'kisskh.xyz' in preferred:
            ordered = ['https://kisskh.nl', 'https://kisskh.do', 'https://kisskh.co']
        else:
            ordered = [preferred, 'https://kisskh.nl', 'https://kisskh.do', 'https://kisskh.co']
        for b in ordered:
            b = (b or '').strip().rstrip('/')
            if not b:
                continue
            if not b.startswith('http'):
                b = 'https://' + b
            if b not in bases:
                bases.append(b)
        return bases

    def _set_active_base(self, base):
        base = (base or '').strip().rstrip('/')
        if not base:
            return
        self.base_link = base
        self.api_link = base + '/api/'
        self.headers['Referer'] = base + '/'
        if base in self.base_candidates:
            self.base_candidates.remove(base)
        self.base_candidates.insert(0, base)

    def _items_from_search_payload(self, data):
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            for key in ('data', 'items', 'results', 'list'):
                val = data.get(key)
                if isinstance(val, list):
                    return val
        return []

    def _normalize_detail_payload(self, data):
        if not isinstance(data, dict):
            return {}
        # Ujednolicamy najczęstsze warianty nazw pól ze starego i nowego API.
        if not data.get('title'):
            data['title'] = data.get('name') or data.get('dramaName') or data.get('label')
        eps = data.get('episodes') or data.get('Episodes') or data.get('episode') or []
        if isinstance(eps, dict):
            eps = self._items_from_search_payload(eps)
        normalized = []
        for ep in eps or []:
            if not isinstance(ep, dict):
                continue
            if 'id' not in ep:
                ep['id'] = ep.get('episodeId') or ep.get('episode_id') or ep.get('ep')
            if 'number' not in ep:
                ep['number'] = ep.get('episode') or ep.get('episodeNumber') or ep.get('name')
            if isinstance(ep.get('number'), str):
                m = re.search(r'(\d+(?:\.\d+)?)', ep.get('number') or '')
                if m:
                    ep['number'] = m.group(1)
            normalized.append(ep)
        try:
            normalized = sorted(normalized, key=lambda x: float(x.get('number') or 0))
        except Exception:
            pass
        data['episodes'] = normalized
        return data

    # ------------------------------------------------------------------ #
    #  HTTP helpers                                                        #
    # ------------------------------------------------------------------ #

    def _init_session(self):
        self._get_session()

    def _get_session(self):
        if not self.session:
            self.session = requests.Session()
            self.session.headers.update(self.headers)
        return self.session

    def _get_json(self, url, referer=None, quiet_404=False):
        if time.time() < getattr(self, '_rate_limited_until', 0):
            fflog('[kisskh] API rate-limit aktywny — pomijam request', 1)
            return None
        session = self._get_session()
        headers = dict(self.headers)
        headers['Referer'] = referer or self.base_link + '/'
        fflog(f'[kisskh] GET {url}', 1)
        r = session.get(url, headers=headers, timeout=12)
        if r.status_code == 404 and quiet_404:
            fflog(f'[kisskh] 404 dla {url}', 1)
            return None
        if r.status_code == 429:
            self._rate_limited_until = time.time() + 45
            fflog(f'[kisskh] 429 Too Many Requests dla {url} — stopuję dalsze próby na 45s', 1)
            return None
        r.raise_for_status()
        try:
            return r.json()
        except Exception:
            text = r.text or ''
            try:
                return json.loads(text)
            except Exception:
                fflog(f'[kisskh] non-json response len={len(text)}', 1)
                return None

    # ------------------------------------------------------------------ #
    #  Tokeny/meta                                                         #
    # ------------------------------------------------------------------ #

    def _pack(self, data):
        raw = json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        return 'kisskh:' + base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')

    def _unpack(self, token):
        token = str(token or '')
        if token.startswith('kisskh:'):
            token = token.split(':', 1)[1]
        pad = '=' * (-len(token) % 4)
        return json.loads(base64.urlsafe_b64decode((token + pad).encode('ascii')).decode('utf-8'))

    def _episode_referer(self, data):
        title = data.get('title') or 'Drama'
        slug = self._slug(title)
        ep_num = self._fmt_ep(data.get('episode_number') or 1)
        drama_id = data.get('drama_id') or 0
        episode_id = data.get('episode_id') or 0
        # Stara aplikacja KissKH używała /Drama/<slug>/Episode-X?id=&ep=.
        # Nowy kisskh.xyz ma też krótsze slugi, ale referer API akceptuje klasyczny format.
        return f'{self.base_link}/Drama/{slug}/Episode-{ep_num}?id={drama_id}&ep={episode_id}&page=0&pageSize=100'

    def _slug(self, text):
        text = unescape(str(text or '')).strip()
        text = re.sub(r'[^A-Za-z0-9]+', '-', text)
        return re.sub(r'-+', '-', text).strip('-') or 'Drama'

    def _fmt_ep(self, num):
        try:
            f = float(num)
            if f.is_integer():
                return str(int(f))
            return str(f).rstrip('0').rstrip('.')
        except Exception:
            return str(num or 1)

    def _extract_year(self, text):
        m = re.search(r'\b((?:19|20)\d{2})\b', str(text or ''))
        return int(m.group(1)) if m else None

    def _year_pair(self, year):
        y1 = y2 = None
        if isinstance(year, (tuple, list)):
            try: y1 = int(year[0])
            except Exception: pass
            try: y2 = int(year[1])
            except Exception: pass
        else:
            try: y1 = int(year)
            except Exception: pass
        return y1, y2
