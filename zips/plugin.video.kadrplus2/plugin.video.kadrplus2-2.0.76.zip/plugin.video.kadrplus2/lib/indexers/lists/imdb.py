from typing import Optional, Sequence
from typing_extensions import Literal
from ..core import Indexer
from ..folder import item_folder_route, pagination, ApiPage, FolderRequest, list_directory, Folder
from ...ff.routing import route, info_for, PathArg
from ...ff.menu import directory, KodiDirectory
from ...ff.settings import settings
from ...api.imdb import imdb_api
from ...defs import Pagina, MediaRef
from ...kolang import L
# from ...ff.log_utils import fflog
from const import const


ListMediaType = Literal['movie', 'show', 'episode', 'person']


class ImdbLists(Indexer):

    @route('/')
    def home(self) -> None:
        """User IMDB lists."""
        with directory(view=const.indexer.lists_view) as kdir:
            # kdir.folder(L(30146, 'Favorites'), self.favorites, thumb='DefaultMovies.png')
            kdir.folder(L(32033, 'Watchlist'), self.watchlists, thumb='services/imdb/watchlist.png')
            kdir.folder(L(30149, 'My Lists'), self.mine, thumb='services/imdb/my.png')

    @route
    def watchlists(self) -> None:
        with list_directory(view=const.indexer.lists_view) as kdir:
            if const.indexer.imdb.watchlist.mixed:
                kdir.folder(L(30159, 'Mixed Watchlist'), info_for(self.watchlist), thumb='services/imdb/watchlist.png')
            kdir.folder(L(30160, 'Watchlist Movies'), info_for(self.watchlist, media='movie'), thumb='services/imdb/watchlist.png')
            kdir.folder(L(30161, 'Watchlist TV Shows'), info_for(self.watchlist, media='show'), thumb='services/imdb/watchlist.png')

    @item_folder_route('watchlist/{media}', list_spec='imdb:watchlist')
    def watchlist(self,
                  req: FolderRequest,
                  /, *,
                  user: Optional[str] = None,
                  media: Optional[Literal['movie', 'show']] = None,
                  page: PathArg[int] = 1,
                  ) -> Sequence[MediaRef]:
        """Return IMDB watchlist items."""
        if not user:
            user = settings.getString('imdb.user')
        items = imdb_api.watch_list(user, media_type=media)
        if req.as_folder:
            items = Pagina(items, page=page, limit=const.indexer.imdb.page_size)
        return items

    def _user_lists(self, user: str, *, media: Optional[ListMediaType] = None, page: int = 1) -> None:
        items = imdb_api.user_lists(user, page=page, list_type=media)
        with list_directory(items, view=const.indexer.imdb.mine.view) as kdir:
            for it in items:
                # it.mode = it.Mode.Folder
                kdir.add(it, url=info_for(self.user_list, list_id=it.vtag.getIMDBNumber(), media=media), thumb='services/imdb/lists.png')

    @route('/mine/{__page}')
    def mine(self, *, media: Optional[ListMediaType] = None, page: int = 1) -> None:
        """Show IMDB user or single user lists (`page` is used only for single user lists)."""
        users = [u for val in settings.getString('imdb.user').split(',') if (u := val.strip())]
        if settings.getString('imdb.at-main'):
            users.insert(0, 'me')
        users = list(dict.fromkeys(users))  # remove duplicates, keep order
        if not users:
            self.no_content()
        elif len(users) == 1:
            self._user_lists(users[0], media=media, page=page)
        else:
            with list_directory(view=const.indexer.imdb.mine.view) as kdir:
                imdb_ids = set()
                for it in imdb_api.user_info_list(users):
                    if it is not None and (usr := it.vtag.getIMDBNumber()):
                        if usr not in imdb_ids:
                            imdb_ids.add(usr)
                            if it.getProperty('imdb.access') == 'private':
                                usr = 'me'
                            kdir.add(it, url=info_for(self.user, user=usr, media=media), thumb='services/imdb/user.png')

    @route('/mine/{user}/{__page}')
    def user(self, *, media: Optional[ListMediaType] = None, user: str, page: int = 1) -> None:
        """Show IMDB user lists."""
        self._user_lists(user, media=media, page=page)

    @item_folder_route('list/{list_id}', list_spec='imdb:user:{list_id}')
    # @item_folder_route('list/{list_id}', list_spec=...)
    def user_list(self, *,
                  list_id: str,
                  media: Optional[Literal['movie', 'show']] = None,
                  page: PathArg[int] = 1,
                  ) -> Folder:
        """Return the list items."""
        items = imdb_api.list(list_id, media_type=media, page=page)
        return Folder(items, list_spec=items.mine)
