# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""FilmPalast source adapter written for Kadr+ 2.0.

The implementation consumes only FilmPalast's public search and detail pages.
It does not import code, data structures or authentication material from any
third-party Kodi add-on.
"""

from __future__ import annotations

import base64
import ipaddress
import json
import re
import socket
import threading
import time
import unicodedata
from difflib import SequenceMatcher
from html import unescape
from html.parser import HTMLParser
from urllib.parse import quote, urljoin, urlsplit

from lib.ff import requests, source_utils
from lib.ff.log_utils import fflog, fflog_exc


_BASE_URL = "https://filmpalast.to"
_BASE_HOST = urlsplit(_BASE_URL).hostname
_DOH_URL = "https://cloudflare-dns.com/dns-query"
_SHOW_REF_PREFIX = "kadr-fp-show:"
_EPISODE_RE = re.compile(r"\bS0*(\d{1,2})\s*E0*(\d{1,3})\b", re.IGNORECASE)
_YEAR_RE = re.compile(r"(?<!\d)((?:19|20)\d{2})(?!\d)")
_TITLE_SPLIT_RE = re.compile(r"\s+(?:/|\||(?:aka|alias):?)\s+", re.IGNORECASE)
_NON_GERMAN_TAG_RE = re.compile(
    r"(?:\*|\[|\()\s*(?:englisch|english)\s*(?:\*|\]|\))"
    r"|(?:^|[-_./])(?:englisch|english)(?:$|[-_./])",
    re.IGNORECASE,
)
_GERMAN_RE = re.compile(r"\b(?:deutsch|german)\b", re.IGNORECASE)
_DOH_CACHE = {}
_DOH_CACHE_LOCK = threading.Lock()
_DNS_PATCH_LOCK = threading.RLock()


def _attrs(values):
    return {str(key).lower(): (value or "") for key, value in values}


def _absolute_http_url(value, base=_BASE_URL):
    value = unescape(str(value or "")).strip()
    if not value or value == "#":
        return ""
    result = urljoin(base + "/", value)
    return result if urlsplit(result).scheme in ("http", "https") else ""


def _is_filmpalast_host(host):
    host = str(host or "").lower().rstrip(".")
    return host == _BASE_HOST or host.endswith("." + _BASE_HOST)


def _is_dns_error(error):
    """Recognize name-resolution failures without treating TLS errors alike."""
    pending, seen = [error], set()
    markers = (
        "failed to resolve",
        "getaddrinfo failed",
        "name or service not known",
        "name resolution",
        "nodename nor servname",
        "temporary failure in name resolution",
    )
    while pending:
        current = pending.pop()
        if id(current) in seen:
            continue
        seen.add(id(current))
        if isinstance(current, socket.gaierror):
            return True
        if type(current).__name__.lower() in ("gaierror", "nameresolutionerror"):
            return True
        if any(marker in str(current).lower() for marker in markers):
            return True
        for nested in (getattr(current, "__cause__", None), getattr(current, "__context__", None)):
            if isinstance(nested, BaseException):
                pending.append(nested)
        for nested in getattr(current, "args", ()):
            if isinstance(nested, BaseException):
                pending.append(nested)
    return False


def _cached_doh_address(host):
    with _DOH_CACHE_LOCK:
        cached = _DOH_CACHE.get(host)
        if cached and cached[1] > time.monotonic():
            return cached[0]
        if cached:
            _DOH_CACHE.pop(host, None)
    return None


def _cache_doh_address(host, address, ttl):
    ttl = max(60, min(int(ttl or 300), 3600))
    with _DOH_CACHE_LOCK:
        _DOH_CACHE[host] = (address, time.monotonic() + ttl)


def _make_verified_doh_adapter(resolver):
    """Build an adapter that changes only DNS while retaining normal TLS."""
    try:
        from requests.adapters import HTTPAdapter
    except Exception:
        return None

    class VerifiedDoHAdapter(HTTPAdapter):
        def send(self, request, **kwargs):
            host = (urlsplit(request.url).hostname or "").lower().rstrip(".")
            if not _is_filmpalast_host(host):
                return super().send(request, **kwargs)
            address = resolver(host)
            if not address:
                raise socket.gaierror(socket.EAI_NONAME, f"DoH could not resolve {host}")

            # requests still sees the original HTTPS URL, so Host, SNI and
            # certificate verification all use filmpalast.to. Only the TCP
            # destination returned by getaddrinfo is substituted temporarily.
            with _DNS_PATCH_LOCK:
                original = socket.getaddrinfo

                def patched(name, port, *args, **inner_kwargs):
                    normalized = name.decode("ascii", "ignore") if isinstance(name, bytes) else str(name)
                    if normalized.lower().rstrip(".") == host:
                        return original(address, port, *args, **inner_kwargs)
                    return original(name, port, *args, **inner_kwargs)

                socket.getaddrinfo = patched
                try:
                    # Never inherit an accidental insecure setting.
                    if kwargs.get("verify") is False:
                        kwargs["verify"] = True
                    return super().send(request, **kwargs)
                finally:
                    socket.getaddrinfo = original

    return VerifiedDoHAdapter()


class _SearchPageParser(HTMLParser):
    """Collect canonical FilmPalast detail links from a search response."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.items = []
        self._anchor = None
        self._seen = set()

    def handle_starttag(self, tag, attrs):
        if tag.lower() != "a":
            return
        data = _attrs(attrs)
        url = _absolute_http_url(data.get("href"))
        if not url or not urlsplit(url).path.startswith("/stream/"):
            return
        self._anchor = {
            "url": url,
            "title": unescape(data.get("title", "")).strip(),
            "text": [],
        }

    def handle_data(self, data):
        if self._anchor is not None:
            self._anchor["text"].append(data)

    def handle_endtag(self, tag):
        if tag.lower() != "a" or self._anchor is None:
            return
        item = self._anchor
        self._anchor = None
        if item["url"] in self._seen:
            return
        title = item["title"] or unescape("".join(item["text"])).strip()
        if not title:
            return
        self._seen.add(item["url"])
        self.items.append({"url": item["url"], "title": title})


class _DetailPageParser(HTMLParser):
    """Read the canonical title, release label and players from a detail page."""

    def __init__(self, page_url):
        super().__init__(convert_charrefs=True)
        self.page_url = page_url
        self.players = []
        self.title = ""
        self.release = ""
        self._host_label = ""
        self._host_parts = None
        self._release_parts = None
        self._title_parts = None

    def handle_starttag(self, tag, attrs):
        data = _attrs(attrs)
        classes = set(data.get("class", "").split())

        if tag.lower() == "p" and "hostName" in classes:
            self._host_parts = []
            return

        if tag.lower() == "h2" and "bgDark" in classes:
            self._title_parts = []
            return

        if tag.lower() == "span" and data.get("id") == "release_text":
            self._release_parts = []
            return

        if tag.lower() != "a" or "iconPlay" not in classes:
            return

        player_url = data.get("data-player-url") or data.get("href")
        player_url = _absolute_http_url(player_url, self.page_url)
        if player_url:
            self.players.append({"url": player_url, "label": self._host_label})

    def handle_data(self, data):
        if self._host_parts is not None:
            self._host_parts.append(data)
        if self._title_parts is not None:
            self._title_parts.append(data)
        if self._release_parts is not None:
            self._release_parts.append(data)

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag == "p" and self._host_parts is not None:
            self._host_label = re.sub(r"\s+", " ", "".join(self._host_parts)).strip()
            self._host_parts = None
        elif tag == "h2" and self._title_parts is not None:
            self.title = re.sub(r"\s+", " ", "".join(self._title_parts)).strip()
            self._title_parts = None
        elif tag == "span" and self._release_parts is not None:
            self.release = re.sub(r"\s+", " ", "".join(self._release_parts)).strip()
            self._release_parts = None


def _normal_title(value, strip_year=False):
    value = unescape(str(value or "")).replace("ß", "ss")
    value = _EPISODE_RE.sub(" ", value)
    if strip_year:
        value = _YEAR_RE.sub(" ", value)
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    value = re.sub(r"[^a-z0-9]+", " ", value.lower())
    return re.sub(r"\s+", " ", value).strip()


def _normalized_similarity(left, right):
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0
    sequence = SequenceMatcher(None, left, right).ratio()
    left_words, right_words = set(left.split()), set(right.split())
    union = left_words | right_words
    overlap = len(left_words & right_words) / float(len(union) or 1)
    return (sequence * 0.72) + (overlap * 0.28)


def _title_similarity(left, right):
    # Compare both literal titles and variants without a release-year token.
    # Keeping the literal path avoids breaking numeric titles such as "1917"
    # or "2001: A Space Odyssey".
    literal = _normalized_similarity(_normal_title(left), _normal_title(right))
    without_year = _normalized_similarity(
        _normal_title(left, strip_year=True),
        _normal_title(right, strip_year=True),
    )
    return max(literal, without_year)


def _title_keys(value):
    """Return safe comparison keys while retaining numeric movie titles."""
    return {
        key
        for key in (_normal_title(value), _normal_title(value, strip_year=True))
        if key
    }


def _title_match_score(candidate, wanted):
    """Score a title and reject common franchise/spin-off collisions."""
    best = 0.0
    for candidate_key in _title_keys(candidate):
        for wanted_key in _title_keys(wanted):
            if candidate_key == wanted_key:
                return 1.0

            candidate_words = candidate_key.split()
            wanted_words = wanted_key.split()
            candidate_set = set(candidate_words)
            wanted_set = set(wanted_words)
            candidate_numbers = {word for word in candidate_set if word.isdigit()}
            wanted_numbers = {word for word in wanted_set if word.isdigit()}

            # A different part number is never a fuzzy match. Release years
            # are already handled by the alternative keys without years.
            if candidate_numbers != wanted_numbers and (candidate_numbers or wanted_numbers):
                continue
            if candidate_set == wanted_set:
                best = max(best, 0.97)
                continue

            # Short titles are especially prone to false positives (for
            # example Dexter vs Dexter: New Blood or Reacher vs Preacher).
            if min(len(candidate_words), len(wanted_words)) <= 2:
                continue
            if candidate_set < wanted_set or wanted_set < candidate_set:
                continue

            union = candidate_set | wanted_set
            overlap = len(candidate_set & wanted_set) / float(len(union) or 1)
            sequence = SequenceMatcher(None, candidate_key, wanted_key).ratio()
            if overlap >= 0.72 and sequence >= 0.78:
                best = max(best, (overlap * 0.45) + (sequence * 0.55))
    return best


def _has_explicit_non_german(*values):
    text = " ".join(str(value or "") for value in values)
    return bool(_NON_GERMAN_TAG_RE.search(text) and not _GERMAN_RE.search(text))


def _slugify(value):
    return _normal_title(value).replace(" ", "-")


def _walk_titles(value):
    if not value:
        return
    if isinstance(value, str):
        yield value
        return
    if isinstance(value, dict):
        for key in (
            "title",
            "name",
            "localtitle",
            "local_title",
            "originaltitle",
            "original_title",
            "originalname",
            "original_name",
        ):
            if value.get(key):
                yield str(value[key])
        return
    if isinstance(value, (tuple, list, set)):
        for item in value:
            for title in _walk_titles(item):
                yield title


def _unique_titles(*values):
    result, seen = [], set()
    for value in values:
        for title in _walk_titles(value):
            title = re.sub(r"\s+", " ", unescape(title)).strip()
            variants = [title]
            parts = [part.strip(" -") for part in _TITLE_SPLIT_RE.split(title)]
            if len(parts) > 1:
                variants.extend(part for part in parts if len(_normal_title(part)) >= 2)
            for variant in variants:
                key = _normal_title(variant)
                if key and key not in seen:
                    result.append(variant[:180])
                    seen.add(key)
    return result[:12]


def _years(*values):
    result = set()
    for value in values:
        if isinstance(value, (tuple, list, set)):
            result.update(_years(*value))
            continue
        for match in _YEAR_RE.findall(str(value or "")):
            year = int(match)
            if 1900 <= year <= 2100:
                result.add(year)
    return result


def _title_number_tokens(titles):
    result = set()
    for title in titles:
        for word in _normal_title(title).split():
            if re.fullmatch(r"(?:19|20)\d{2}", word):
                result.add(int(word))
    return result


def _candidate_years(titles, *values):
    return _years(*values) - _title_number_tokens(titles)


def _episode_number(*values):
    for value in values:
        match = _EPISODE_RE.search(str(value or ""))
        if match:
            return int(match.group(1)), int(match.group(2))
    return None


def _encode_show_ref(titles, years):
    payload = json.dumps(
        {"titles": list(titles), "years": sorted(years)},
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8")
    token = base64.urlsafe_b64encode(payload).decode("ascii").rstrip("=")
    return _SHOW_REF_PREFIX + token


def _decode_show_ref(value):
    if not str(value or "").startswith(_SHOW_REF_PREFIX):
        return None
    try:
        token = str(value)[len(_SHOW_REF_PREFIX):]
        token += "=" * (-len(token) % 4)
        data = json.loads(base64.urlsafe_b64decode(token.encode("ascii")).decode("utf-8"))
        titles = _unique_titles(data.get("titles", []))
        return {"titles": titles, "years": _years(data.get("years", []))} if titles else None
    except Exception:
        return None


def _quality_from_text(value):
    value = str(value or "").lower()
    if re.search(r"(?:2160|\b4k\b|\buhd\b)", value):
        return "4K"
    if "1440" in value:
        return "1440p"
    if "1080" in value:
        return "1080p"
    if "720" in value or re.search(r"\bhd\b", value):
        return "720p"
    if re.search(r"\b(?:cam|telesync|hdts|tsrip)\b", value):
        return "CAM"
    return "SD"


class source:
    has_sort_order = True
    priority = 2
    language = ["de"]

    def __init__(self):
        self.priority = 2
        self.language = ["de"]
        self.base_link = _BASE_URL
        self.search_link = "/search/title/%s"
        self.session = None
        self._doh_session = None
        self._resolver_session = None
        self._search_cache = {}
        self._detail_cache = {}
        self._detail_info_cache = {}
        self.headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/140.0.0.0 Safari/537.36"
            ),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "de-DE,de;q=0.9,en;q=0.3",
            "Referer": _BASE_URL + "/",
        }

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        # FilmPalast is a German catalogue, so its local title is the most
        # likely slug. All aliases remain available for strict verification.
        titles = _unique_titles(localtitle, title, aliases)
        wanted_years = _years(year, kwargs.get("year_alt"))
        fflog(f"[filmpalast] movie titles={titles!r} years={sorted(wanted_years)!r}", 1)
        return self._locate(titles, wanted_years=wanted_years)

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        titles = _unique_titles(localtvshowtitle, tvshowtitle, aliases)
        if not titles:
            return None
        wanted_years = _years(year, kwargs.get("year_alt"))
        return _encode_show_ref(titles, wanted_years)

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        try:
            season, episode = int(season), int(episode)
        except (TypeError, ValueError):
            return None

        show = _decode_show_ref(url)
        if show:
            titles = show["titles"]
        else:
            # Compatibility with a cached URL produced by an older Kadr+ build.
            slug = urlsplit(str(url or "")).path.rsplit("/", 1)[-1]
            slug = _EPISODE_RE.sub(" ", slug.replace("-", " "))
            titles = _unique_titles(slug)
        if not titles:
            return None

        fflog(f"[filmpalast] episode titles={titles!r} S{season:02d}E{episode:02d}", 1)
        return self._locate(titles, episode=(season, episode))

    def sources(self, url, hostDict, hostprDict):
        if not str(url or "").startswith(("http://", "https://")):
            return []
        try:
            html = self._get(url, detail=True)
            if not html:
                return []
            parser = _DetailPageParser(url)
            parser.feed(html)
            parser.close()
            if _has_explicit_non_german(parser.title) or _has_explicit_non_german(parser.release):
                return []

            result, seen = [], set()
            for player in parser.players:
                link = player["url"]
                if link in seen:
                    continue
                seen.add(link)
                valid, hoster = source_utils.is_host_valid(link, hostDict)
                if not valid:
                    valid, hoster = source_utils.is_host_valid(link, hostprDict)
                if not hoster:
                    hoster = urlsplit(link).hostname or "FilmPalast"
                    if hoster.startswith("www."):
                        hoster = hoster[4:]

                label = re.sub(r"\s+", " ", player.get("label", "")).strip()
                quality = _quality_from_text(parser.release + " " + label)
                info = "Dubbing DE" + (" | " + label if label else "")
                path = urlsplit(link).path.lower()
                direct = path.endswith((".m3u8", ".mp4", ".webm"))
                result.append({
                    "source": hoster,
                    "quality": quality,
                    "language": "de",
                    "url": link,
                    "info": info,
                    "direct": direct,
                    "debridonly": False,
                })

            fflog(f"[filmpalast] sources={len(result)}", 1)
            return result
        except Exception:
            fflog_exc()
            return []

    def resolve(self, url):
        return url

    def _locate(self, titles, wanted_years=None, episode=None):
        if not titles:
            return None
        wanted_years = set(wanted_years or ())

        precise_queries, broad_queries = self._query_plan(titles, wanted_years, episode)
        # FilmPalast uses predictable public slugs for many titles. These
        # candidates are accepted only after the actual detail page confirms
        # the canonical title, episode, year and presence of players.
        direct = self._direct_candidates(titles, wanted_years, episode)
        # Direct URLs are generated in deliberate title order: German/local
        # title with year, the same title without a year, then other aliases.
        # Preserve that order instead of letting the small year score bonus
        # move an original-language alias ahead of the local plain slug.
        match = self._select_candidate(
            direct, titles, wanted_years, episode, preserve_order=True
        )
        if match:
            return match

        match = self._match_queries(precise_queries, titles, wanted_years, episode)
        if match:
            return match

        match = self._match_queries(broad_queries, titles, wanted_years, episode)
        if match:
            return match

        fflog(f"[filmpalast] no match for {titles!r}", 1)
        return None

    def _query_plan(self, titles, wanted_years, episode):
        precise, broad, seen = [], [], set()

        def add(target, value):
            value = re.sub(r"\s+", " ", str(value or "")).strip()
            key = value.casefold()
            if value and key not in seen:
                target.append(value)
                seen.add(key)

        if episode:
            season, number = episode
            token = f"S{season:02d}E{number:02d}"
            for title in titles[:6]:
                add(precise, f"{title} {token}")
            for title in titles[:4]:
                add(broad, title)
        else:
            for title in titles[:4]:
                for year in sorted(wanted_years)[:2]:
                    add(precise, f"{title} {year}")
            for title in titles[:6]:
                add(broad if precise else precise, title)
        return precise, broad

    def _match_queries(self, queries, titles, wanted_years, episode):
        candidates, seen = [], set()
        for query in queries:
            for item in self._search(query):
                if item["url"] not in seen:
                    candidates.append(item)
                    seen.add(item["url"])
        return self._select_candidate(candidates, titles, wanted_years, episode)

    def _direct_candidates(self, titles, wanted_years, episode):
        result, seen = [], set()
        for title in titles[:4]:
            slug = _slugify(title)
            if not slug:
                continue
            if episode:
                season, number = episode
                suffixes = [(f"{slug}-s{season:02d}e{number:02d}", f"{title} S{season:02d}E{number:02d}")]
            else:
                suffixes = [(f"{slug}-{year}", f"{title} {year}") for year in sorted(wanted_years)]
                suffixes.append((slug, title))
            for url_slug, label in suffixes:
                url = self.base_link + "/stream/" + url_slug
                if url not in seen:
                    result.append({"url": url, "title": label})
                    seen.add(url)
        return result

    def _select_candidate(
        self, candidates, titles, wanted_years, episode, preserve_order=False
    ):
        ranked = []
        for item in candidates:
            slug = urlsplit(item["url"]).path.rsplit("/", 1)[-1]
            if _has_explicit_non_german(item.get("title"), slug):
                continue

            item_episode = _episode_number(item.get("title"), slug)
            if episode and item_episode != episode:
                continue
            if not episode and item_episode:
                continue

            score = max(
                max(_title_match_score(item.get("title"), wanted), _title_match_score(slug, wanted))
                for wanted in titles
            )
            if score < 0.84:
                continue

            years = _candidate_years(titles, item.get("title"), slug)
            if wanted_years and years:
                if not self._years_match(wanted_years, years):
                    continue
                score += 0.08
            ranked.append((score, item))

        if not preserve_order:
            ranked.sort(key=lambda value: value[0], reverse=True)
        for preliminary_score, item in ranked[:10]:
            verified_score = self._verify_detail(item, titles, wanted_years, episode)
            if verified_score is None:
                continue
            fflog(
                f"[filmpalast] match score={max(preliminary_score, verified_score):.3f} "
                f"{item['title']!r}",
                1,
            )
            return item["url"]
        return None

    def _verify_detail(self, item, titles, wanted_years, episode):
        info = self._detail_info(item["url"])
        if not info or not info["title"] or not info["players"]:
            return None

        slug = urlsplit(item["url"]).path.rsplit("/", 1)[-1]
        if _has_explicit_non_german(info["title"], slug):
            return None
        if _has_explicit_non_german(info["release"]):
            return None

        detail_episode = _episode_number(info["title"], slug)
        if episode and detail_episode != episode:
            return None
        if not episode and detail_episode:
            return None

        score = max(_title_match_score(info["title"], wanted) for wanted in titles)
        if score < 0.84:
            return None

        years = _candidate_years(titles, info["title"], info["release"], slug)
        if wanted_years and years:
            if not self._years_match(wanted_years, years):
                return None
            score += 0.08
        return score

    @staticmethod
    def _years_match(wanted, candidate):
        return any(abs(left - right) <= 1 for left in wanted for right in candidate)

    def _search(self, query):
        key = re.sub(r"\s+", " ", str(query or "")).strip()
        if not key:
            return []
        if key in self._search_cache:
            return self._search_cache[key]
        url = self.base_link + self.search_link % quote(key, safe="")
        html = self._get(url)
        if not html:
            self._search_cache[key] = []
            return []
        parser = _SearchPageParser()
        parser.feed(html)
        parser.close()
        self._search_cache[key] = parser.items
        return parser.items

    def _detail_info(self, url):
        if url in self._detail_info_cache:
            return self._detail_info_cache[url]
        html = self._get(url, detail=True)
        if not html:
            self._detail_info_cache[url] = None
            return None
        parser = _DetailPageParser(url)
        parser.feed(html)
        parser.close()
        info = {
            "title": parser.title,
            "release": parser.release,
            "players": list(parser.players),
        }
        self._detail_info_cache[url] = info
        return info

    def _detail_years(self, url):
        info = self._detail_info(url)
        return _years(info["title"], info["release"]) if info else set()

    def _get(self, url, detail=False):
        cache = self._detail_cache if detail else None
        if cache is not None and url in cache:
            return cache[url]
        try:
            self._init_session()
            try:
                response = self._request_page(self.session, url)
            except Exception as error:
                if self.session is self._doh_session or not _is_dns_error(error):
                    raise
                fflog("[filmpalast] zwykły DNS nie działa; uruchamiam bezpieczny DoH", 1)
                doh_session = self._get_doh_session()
                if doh_session is None:
                    raise
                response = self._request_page(doh_session, url, verify=True)
                # Reuse the verified fallback for the rest of this provider
                # run instead of repeating a known failing system-DNS lookup.
                self.session = doh_session
            if response.status_code != 200:
                fflog(f"[filmpalast] HTTP {response.status_code}: {url}", 1)
                return ""
            html = response.text or ""
            if cache is not None:
                cache[url] = html
            return html
        except Exception:
            fflog_exc()
            return ""

    def _request_page(self, session, url, verify=None):
        kwargs = {
            "headers": self.headers,
            "timeout": (8, 28),
            "allow_redirects": True,
        }
        if verify is not None:
            kwargs["verify"] = verify
        return session.get(url, **kwargs)

    def _resolve_doh(self, host):
        host = str(host or "").lower().rstrip(".")
        if not _is_filmpalast_host(host):
            return None
        cached = _cached_doh_address(host)
        if cached:
            return cached
        try:
            if self._resolver_session is None:
                self._resolver_session = requests.Session(cache=False)
            response = self._resolver_session.get(
                _DOH_URL,
                params={"name": host, "type": "A"},
                headers={
                    "Accept": "application/dns-json",
                    "User-Agent": self.headers["User-Agent"],
                },
                timeout=(5, 10),
                allow_redirects=True,
                verify=True,
            )
            if response.status_code != 200:
                return None
            try:
                payload = response.json()
            except Exception:
                payload = json.loads(response.text or "{}")
            if int(payload.get("Status", -1)) != 0:
                return None
            for answer in payload.get("Answer") or ():
                if int(answer.get("type", 0)) != 1:
                    continue
                address = str(answer.get("data") or "").strip()
                try:
                    if ipaddress.ip_address(address).version != 4:
                        continue
                except ValueError:
                    continue
                _cache_doh_address(host, address, answer.get("TTL", 300))
                return address
        except Exception:
            fflog_exc()
        return None

    def _get_doh_session(self):
        if self._doh_session is not None:
            return self._doh_session
        try:
            adapter = _make_verified_doh_adapter(self._resolve_doh)
            if adapter is None:
                return None
            session = requests.Session(cache=False)
            session.headers.update(self.headers)
            session.verify = True
            session.mount("https://", adapter)
            self._doh_session = session
            return session
        except Exception:
            fflog_exc()
            return None

    def _init_session(self):
        if self.session is None:
            self.session = requests.Session(cache=False)
            self.session.headers.update(self.headers)
