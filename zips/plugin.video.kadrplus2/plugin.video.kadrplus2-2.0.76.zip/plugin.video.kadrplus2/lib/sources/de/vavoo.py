# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""Vavoo source adapter written for Kadr+ 2.0.

The adapter follows the public JSON requests made by the vavoo.to web client.
It contains no copied add-on code, embedded application token, device identity
or emulated signature exchange.
"""

from __future__ import annotations

import base64
import json
import re
from urllib.parse import urlsplit

from lib.ff import requests, source_utils
from lib.ff.log_utils import fflog, fflog_exc


_API_URL = "https://vavoo.to/mediahubmx-source.json"
_REF_PREFIX = "kadr-vavoo:"
_QUALITY_ORDER = {"4K": 0, "1440p": 1, "1080p": 2, "720p": 3, "HD": 4, "SD": 5}


def _positive_int(value):
    try:
        value = int(value)
        return value if value > 0 else None
    except (TypeError, ValueError):
        return None


def _encode_ref(data):
    raw = json.dumps(data, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return _REF_PREFIX + base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _decode_ref(value):
    value = str(value or "")
    if not value.startswith(_REF_PREFIX):
        # Read a cached reference created by Kadr+ 2.0.58, then immediately
        # convert it to the new self-contained format on the next method call.
        legacy = re.fullmatch(r"(movie|series):(\d+)(?::(\d+):(\d+))?", value)
        if not legacy:
            return None
        result = {"type": legacy.group(1), "tmdb_id": int(legacy.group(2))}
        if result["type"] == "series" and legacy.group(3) and legacy.group(4):
            result.update({"season": int(legacy.group(3)), "episode": int(legacy.group(4))})
        return result
    try:
        token = value[len(_REF_PREFIX):]
        token += "=" * (-len(token) % 4)
        result = json.loads(base64.urlsafe_b64decode(token.encode("ascii")).decode("utf-8"))
        kind = result.get("type")
        tmdb_id = _positive_int(result.get("tmdb_id"))
        if kind not in ("movie", "series") or not tmdb_id:
            return None
        clean = {"type": kind, "tmdb_id": tmdb_id}
        if kind == "series":
            season = _positive_int(result.get("season"))
            episode = _positive_int(result.get("episode"))
            if season:
                clean["season"] = season
            if episode:
                clean["episode"] = episode
        return clean
    except Exception:
        return None


def _quality(value):
    value = str(value or "").upper()
    if re.search(r"(?:2160|\b4K\b|\bUHD\b)", value):
        return "4K"
    if "1440" in value:
        return "1440p"
    if re.search(r"1080|\bFHD\b", value):
        return "1080p"
    if re.search(r"720|\bHD\b", value):
        return "720p"
    return "SD"


def _language_codes(value):
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, (tuple, list, set)):
        return set()
    result = set()
    for item in value:
        code = str(item or "").strip().lower().replace("_", "-").split("-", 1)[0]
        if code:
            result.add(code)
    return result


def _is_direct(item, link):
    mime = str(item.get("mimeType") or item.get("mime_type") or "").lower()
    path = urlsplit(link).path.lower()
    return mime in (
        "application/vnd.apple.mpegurl",
        "application/x-mpegurl",
        "video/mp4",
        "video/webm",
    ) or path.endswith((".m3u8", ".mp4", ".webm"))


class source:
    has_sort_order = True
    priority = 2
    language = ["de"]

    def __init__(self):
        self.priority = 2
        self.language = ["de"]
        self.session = None
        self._response_cache = {}
        self.headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/140.0.0.0 Safari/537.36"
            ),
            "Accept": "application/json",
            "Content-Type": "application/json; charset=utf-8",
            "Origin": "https://vavoo.to",
            "Referer": "https://vavoo.to/",
        }

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        tmdb_id = self._movie_tmdb_id()
        if not tmdb_id:
            fflog("[vavoo] missing movie tmdb_id", 1)
            return None
        return _encode_ref({"type": "movie", "tmdb_id": tmdb_id})

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        tmdb_id = self._show_tmdb_id()
        if not tmdb_id:
            fflog("[vavoo] missing series tmdb_id", 1)
            return None
        return _encode_ref({"type": "series", "tmdb_id": tmdb_id})

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        item = _decode_ref(url)
        season = _positive_int(season)
        episode = _positive_int(episode)
        if not item or item["type"] != "series" or not season or not episode:
            return None
        item.update({"season": season, "episode": episode})
        return _encode_ref(item)

    def sources(self, url, hostDict, hostprDict):
        item = _decode_ref(url)
        if not item:
            return []
        try:
            raw = self._fetch(item)
            result, seen = [], set()
            for entry in raw:
                if not isinstance(entry, dict):
                    continue
                if entry.get("type") not in (None, "url"):
                    continue

                link = str(entry.get("url") or "").strip()
                parsed = urlsplit(link)
                if parsed.scheme not in ("http", "https") or not parsed.hostname or link in seen:
                    continue
                languages = _language_codes(entry.get("languages"))
                if languages and "de" not in languages:
                    continue
                seen.add(link)

                valid, hoster = source_utils.is_host_valid(link, hostDict)
                if not valid:
                    valid, hoster = source_utils.is_host_valid(link, hostprDict)
                if not hoster:
                    hoster = parsed.hostname
                    if hoster.startswith("www."):
                        hoster = hoster[4:]

                tag = str(entry.get("tag") or "").strip()
                server_name = str(entry.get("name") or "").strip()
                quality = _quality(" ".join((tag, server_name, link)))
                details = ["Dubbing DE"]
                if server_name:
                    details.append(server_name)
                if tag and tag.lower() not in server_name.lower():
                    details.append(tag)

                result.append({
                    "source": hoster,
                    "quality": quality,
                    "language": "de",
                    "url": link,
                    "info": " | ".join(details),
                    "direct": _is_direct(entry, link),
                    "debridonly": False,
                })

            result.sort(key=lambda item: _QUALITY_ORDER.get(item["quality"], 99))
            fflog(f"[vavoo] sources={len(result)}", 1)
            return result
        except Exception:
            fflog_exc()
            return []

    def resolve(self, url):
        return url

    def _movie_tmdb_id(self):
        return _positive_int(getattr(getattr(self, "ffitem", None), "tmdb_id", None))

    def _show_tmdb_id(self):
        ffitem = getattr(self, "ffitem", None)
        show_item = getattr(ffitem, "show_item", None)
        return _positive_int(getattr(show_item, "tmdb_id", None)) or _positive_int(
            getattr(ffitem, "tmdb_id", None)
        )

    def _payload(self, item):
        payload = {
            "language": "de",
            "region": "DE",
            "type": item["type"],
            "ids": {"tmdb_id": item["tmdb_id"]},
            "name": "",
        }
        if item["type"] == "series":
            season = _positive_int(item.get("season"))
            episode = _positive_int(item.get("episode"))
            if not season or not episode:
                return None
            payload["episode"] = {
                "ids": {},
                "season": season,
                "episode": episode,
            }
        return payload

    def _fetch(self, item):
        payload = self._payload(item)
        if not payload:
            return []
        cache_key = json.dumps(payload, separators=(",", ":"), sort_keys=True)
        if cache_key in self._response_cache:
            return self._response_cache[cache_key]

        self._init_session()
        response = self.session.post(
            _API_URL,
            json=payload,
            headers=self.headers,
            timeout=(8, 30),
            allow_redirects=True,
        )
        if response.status_code != 200:
            fflog(f"[vavoo] HTTP {response.status_code}", 1)
            return []
        data = response.json()
        if isinstance(data, dict) and data.get("error"):
            fflog(f"[vavoo] API error: {data.get('error')}", 1)
            return []
        if not isinstance(data, list):
            return []
        self._response_cache[cache_key] = data
        return data

    def _init_session(self):
        if self.session is None:
            self.session = requests.Session(cache=False)
            self.session.headers.update(self.headers)
