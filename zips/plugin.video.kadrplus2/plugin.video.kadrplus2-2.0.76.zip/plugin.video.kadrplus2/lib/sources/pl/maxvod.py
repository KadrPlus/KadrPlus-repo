# -*- coding: utf-8 -*-
"""
Kadr+ 2.0 - źródło: maxvod.tv
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>

Wyszukiwanie po /search, odtwarzacz zwraca listę SOURCES (uuid + mediaType) w
inline JS, a /api/player/url/{uuid} + /player/play/{uuid} (Location header)
daje właściwy link: bezpośredni mp4 (mediaType=video) albo embed zewnętrznego
hostingu jak voe.sx/vidoza.net (mediaType=iframe, przez resolveurl). Wszystkie
zapytania wymagają Refereru z domeny maxvod.tv.
"""

from __future__ import annotations

import json
import re
from typing import ClassVar, Dict, List, Optional, Tuple, TYPE_CHECKING
from urllib.parse import parse_qs, urlsplit

from lib.ff import requests
from lib.ff import cleantitle
from lib.ff.source_utils import (DEFAULT_UA, append_headers, get_quality,
                                 get_lang_by_type, search_queries_extended)
from lib.ff.log_utils import fflog, fflog_exc

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.sources import SourceItem, SourceTitleAlias


_RE_SOURCES = re.compile(r'const\s+SOURCES\s*=\s*(\[.*?\]);')
_RE_YEAR = re.compile(r'bi-calendar3[^>]*></i>\s*(\d{4})')
_RE_TITLE_YEAR = re.compile(r'^(.*?)\s*\((\d{4})(?:-\d{4})?\)\s*$')
_RE_PLAYER_EPISODE = re.compile(
    r'const\s+EP_SEZON\s*=\s*(\d+)\s*;.*?const\s+EP_ODCINEK\s*=\s*(\d+)\s*;',
    re.DOTALL,
)
_QUALITY_MAP = {'4K': '4K', 'HD': '1080p', 'SD': 'SD', 'CAM': 'CAM',
                'WYSOKA': '1080p', 'NISKA': '720p'}


# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    ffitem: 'FFItem'

    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['pl']

    def __init__(self) -> None:
        self.base_link = 'https://maxvod.tv'
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': DEFAULT_UA,
            'Referer': self.base_link + '/',
        })

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str,
              aliases: 'list[SourceTitleAlias]', year: str) -> Optional[str]:
        return self._find(title, localtitle, year, 'movie')

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str,
               aliases: 'list[SourceTitleAlias]', year: str) -> Optional[str]:
        return self._find(tvshowtitle, localtvshowtitle, year, 'series')

    def episode(self, url: Optional[str], imdb: str, tvdb: str, title: str,
                premiered: str, season: str, episode: str) -> Optional[str]:
        if not url:
            return None
        return f'{url}?sezon={int(season)}&odcinek={int(episode)}'

    def sources(self, url: Optional[str], hostDict: List[str],
                hostprDict: List[str]) -> 'List[SourceItem]':
        if not url:
            return []
        player_path = self._player_path(url)
        if not player_path:
            return []

        try:
            resp = self.session.get(f'{self.base_link}{player_path}', timeout=15)
        except Exception:
            fflog_exc()
            return []
        if not resp.ok:
            fflog(f'player HTTP {resp.status_code}')
            return []

        requested_episode = self._requested_episode(url)
        if requested_episode:
            actual = self._player_episode(resp.text)
            if actual != requested_episode:
                fflog(
                    f'episode mismatch: requested S{requested_episode[0]:02d}E{requested_episode[1]:02d}, '
                    f'player returned {actual!r}'
                )
                return []

        results: 'List[SourceItem]' = []
        for src in self._extract_sources(resp.text):
            item = self._build_source(src)
            if item is not None:
                results.append(item)

        fflog(f'{len(results)} source(s)')
        return results

    def resolve(self, url: str) -> Optional[str]:
        return url

    # ── helpers ────────────────────────────────────────────────────────────

    def _player_path(self, url: str) -> Optional[str]:
        if url.startswith('/movie/'):
            return f'/player/{url[len("/movie/"):]}'
        if url.startswith('/series/'):
            return f'/player/series/{url[len("/series/"):]}'
        return None

    def _find(self, title: str, localtitle: str, year: str, media_type: str) -> Optional[str]:
        targets = {cleantitle.normalize(cleantitle.getsearch(t))
                  for t in (title, localtitle) if t}
        try:
            for query in search_queries_extended(localtitle or title, title or localtitle):
                candidates = self._search(query, media_type)
                fallback_slug = ''
                for slug, cand_title in candidates:
                    clean_title, cand_year = _split_title_year(cand_title)
                    if cleantitle.normalize(cleantitle.getsearch(clean_title)) not in targets:
                        continue
                    if not fallback_slug:
                        fallback_slug = slug
                    if not year:
                        continue
                    year_match = (cand_year == str(year)) if cand_year else self._check_year(media_type, slug, year)
                    if year_match:
                        return f'/{media_type}/{slug}'
                if fallback_slug and not year:
                    return f'/{media_type}/{fallback_slug}'
        except Exception:
            fflog_exc()
        return None

    @staticmethod
    def _requested_episode(url: str) -> Optional[Tuple[int, int]]:
        try:
            query = parse_qs(urlsplit(url).query)
            return int(query['sezon'][0]), int(query['odcinek'][0])
        except (KeyError, TypeError, ValueError, IndexError):
            return None

    @staticmethod
    def _player_episode(html: str) -> Optional[Tuple[int, int]]:
        match = _RE_PLAYER_EPISODE.search(html or '')
        return (int(match.group(1)), int(match.group(2))) if match else None

    def _search(self, query: str, media_type: str) -> 'List[Tuple[str, str]]':
        try:
            resp = self.session.get(f'{self.base_link}/search', params={'q': query}, timeout=15)
        except Exception:
            fflog_exc()
            return []
        if not resp.ok:
            return []
        pattern = re.compile(rf'href="/{media_type}/([a-z0-9-]+)".*?<img[^>]*alt="([^"]*)"', re.DOTALL)
        results = pattern.findall(resp.text)
        fflog(f'search {query!r} ({media_type}) -> {len(results)} result(s)')
        return results

    def _check_year(self, media_type: str, slug: str, year: str) -> bool:
        try:
            resp = self.session.get(f'{self.base_link}/{media_type}/{slug}', timeout=15)
        except Exception:
            return False
        if not resp.ok:
            return False
        match = _RE_YEAR.search(resp.text)
        return bool(match) and match.group(1) == str(year)

    def _extract_sources(self, player_html: str) -> 'List[Dict]':
        match = _RE_SOURCES.search(player_html)
        if not match:
            return []
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            fflog_exc()
            return []

    def _build_source(self, src: 'Dict') -> 'Optional[SourceItem]':
        uuid = src.get('uuid')
        is_direct = src.get('mediaType') == 'video'
        if not uuid or src.get('mediaType') not in ('video', 'iframe'):
            return None
        stream_url = self._resolve_stream(uuid)
        if not stream_url:
            return None

        lang, info = get_lang_by_type(str(src.get('langLabel') or src.get('langKey') or ''))
        if is_direct:
            headers = {'User-Agent': DEFAULT_UA, 'Referer': self.base_link + '/'}
            stream_url += append_headers(headers)

        return {
            'source': str(src.get('label') or 'MaxVOD'),
            'quality': _quality(str(src.get('quality') or '')),
            'language': lang or 'pl',
            'info': info,
            'url': stream_url,
            'direct': is_direct,
            'debridonly': False,
            'filename': '',
            'premium': False,
        }

    def _resolve_stream(self, uuid: str) -> Optional[str]:
        try:
            resp = self.session.get(f'{self.base_link}/api/player/url/{uuid}', timeout=15)
            if not resp.ok:
                return None
            rel = resp.json().get('url')
            if not rel:
                return None
            play_resp = self.session.get(f'{self.base_link}{rel}', timeout=15, allow_redirects=False)
            return play_resp.headers.get('Location')
        except Exception:
            fflog_exc()
            return None


# ─── module helpers ──────────────────────────────────────────────────────────────


def _split_title_year(raw: str) -> 'Tuple[str, str]':
    # cleantitle.getsearch() doesn't strip parens, so a year suffixed to the title must be cut separately
    match = _RE_TITLE_YEAR.match(raw)
    if not match:
        return raw, ''
    return match.group(1), match.group(2)


def _quality(raw: str) -> str:
    """maxvod reports a coarse label ('HD'/'4K'/...) or nothing at all for its own
    CDN 'Player 1' source; get_quality() only parses detailed resolution strings
    ('1080p' etc.) and would misread both 'HD' and empty as SD."""
    upper = raw.strip().upper()
    if not upper:
        return '1080p'
    return _QUALITY_MAP.get(upper) or get_quality(raw)
