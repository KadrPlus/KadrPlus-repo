# -*- coding: utf-8 -*-
"""
Kadr+ 2.0 - źródło: HDMovix (hdmovix.cc vidlink backend)
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>

Endpoint: /api/vidlink/{movie|tv}/{tmdb_id}[/{s}/{e}]
Zwraca HLS przez ich własny proxy (/api/hls-proxy), proxy obsługuje
auth do CDN (storm.vodvidl.site / vod*.ironwallnet.com via megacloud.live).
Wymaga sesyjnego cookie — najpierw GET /play/{tmdb}/{type} (movix_session),
potem API z Refererem do tej strony; bez cookie serwer wisi (timeout).
"""

from __future__ import annotations

import re
import time
from typing import ClassVar, Dict, List, Optional, Tuple, TYPE_CHECKING
from urllib.parse import urlencode, parse_qs

from lib.ff import requests
from lib.ff.source_utils import FF_UA, append_headers
from lib.ff.log_utils import fflog, fflog_exc

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.sources import SourceItem, SourceTitleAlias


_BASE = 'https://hdmovix.cc'
_VIDLINK_MOVIE = _BASE + '/api/vidlink/movie/{tmdb}'
_VIDLINK_TV = _BASE + '/api/vidlink/tv/{tmdb}/{season}/{episode}'
_PLAY_MOVIE = _BASE + '/play/{tmdb}/movie'
_PLAY_TV = _BASE + '/play/{tmdb}/tv'

_HEADERS: Dict[str, str] = {
    'User-Agent': FF_UA,
    'Referer': _BASE + '/',
    'Accept': 'application/json, text/plain, */*',
}
_STREAM_HEADERS: Dict[str, str] = {
    'User-Agent': FF_UA,
    'Referer': _BASE + '/',
}

_SCHEME = 'hdmovix://'
_RATE_LIMIT_RETRIES = 3
_RATE_LIMIT_DELAY = 2.0

_RE_STREAM = re.compile(
    r'#EXT-X-STREAM-INF:[^\n]*RESOLUTION=(\d+)x\d+[^\n]*\n(/api/hls-proxy\S+)',
    re.MULTILINE,
)
_WIDTH_TO_QUALITY: List[Tuple[int, str]] = [
    (3840, '4K'),
    (2560, '1440p'),
    (1920, '1080p'),
    (1280, '720p'),
]


class source:
    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['en']

    ffitem: 'FFItem'

    def __init__(self) -> None:
        self.session = requests.Session()
        self.session.headers.update(_HEADERS)

    # ── public api ──────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str,
              aliases: 'list[SourceTitleAlias]', year: str) -> Optional[str]:
        tmdb = str(self.ffitem.tmdb_id or '')
        if not tmdb:
            return None
        return _SCHEME + urlencode({'type': 'movie', 'tmdb': tmdb})

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str,
               aliases: 'list[SourceTitleAlias]', year: str) -> Optional[str]:
        show_item = getattr(self.ffitem, 'show_item', None)
        tmdb = str((show_item.tmdb_id if show_item else None) or self.ffitem.tmdb_id or '')
        if not tmdb:
            return None
        return _SCHEME + urlencode({'type': 'tv', 'tmdb': tmdb})

    def episode(self, url: Optional[str], imdb: str, tvdb: str, title: str,
                premiered: str, season: str, episode: str) -> Optional[str]:
        if not url:
            return None
        return f'{url}&s={int(season)}&e={int(episode)}'

    def sources(self, url: Optional[str], hostDict: List[str],
                hostprDict: List[str]) -> 'List[SourceItem]':
        if not url:
            return []
        params = _decode(url)
        if not params.get('tmdb'):
            return []

        media_type = params.get('type', 'movie')
        tmdb = params['tmdb']

        if media_type == 'tv':
            season = params.get('s', '1')
            episode = params.get('e', '1')
            vidlink_url = _VIDLINK_TV.format(tmdb=tmdb, season=season, episode=episode)
        else:
            vidlink_url = _VIDLINK_MOVIE.format(tmdb=tmdb)

        self._warm_session(media_type, tmdb)
        results = self._fetch_vidlink(vidlink_url)
        fflog(f'found {len(results)} streams')
        return results

    def resolve(self, url: str) -> Optional[str]:
        return url

    # ── helpers ─────────────────────────────────────────────────────────────

    def _warm_session(self, media_type: str, tmdb: str) -> None:
        """Visit the play page to obtain the session cookie required by /api/vidlink/*."""
        play_url = (_PLAY_TV if media_type == 'tv' else _PLAY_MOVIE).format(tmdb=tmdb)
        try:
            self.session.get(play_url, timeout=10)
            self.session.headers.update({'Referer': play_url})
        except Exception:
            fflog_exc()

    def _fetch_vidlink(self, api_url: str) -> List[dict]:
        try:
            data = self._call_vidlink_api(api_url)
            if not data:
                return []

            main_path = data.get('url', '')
            seen_manifest_paths: set = set()
            manifest_paths: List[str] = []
            for path in [main_path] + data.get('stream_urls', []):
                if path and path not in seen_manifest_paths:
                    seen_manifest_paths.add(path)
                    manifest_paths.append(path)

            seen_qualities: set = set()
            items: List[dict] = []
            for manifest_path in manifest_paths:
                manifest_url = _BASE + manifest_path
                if 'master.m3u8' in manifest_path:
                    resp = self.session.get(manifest_url, timeout=10)
                    if not resp.ok:
                        continue
                    for quality, variant_path in _parse_master_manifest(resp.text):
                        if quality not in seen_qualities:
                            seen_qualities.add(quality)
                            items.append(_make_item(
                                'HDMovix VidLink', quality,
                                f'isa+{_BASE}{variant_path}{append_headers(_STREAM_HEADERS)}'))
                else:
                    if 'direct' not in seen_qualities:
                        seen_qualities.add('direct')
                        items.append(_make_item(
                            'HDMovix VidLink', '1080p',
                            f'isa+{manifest_url}{append_headers(_STREAM_HEADERS)}'))

            if not items and main_path:
                items = [_make_item('HDMovix VidLink', '1080p',
                                    f'isa+{_BASE}{main_path}{append_headers(_STREAM_HEADERS)}')]

            fflog(f'vidlink: {len(items)} streams from {len(manifest_paths)} manifests')
            return items
        except Exception:
            fflog_exc()
            return []

    def _call_vidlink_api(self, api_url: str) -> Optional[Dict]:
        for attempt in range(_RATE_LIMIT_RETRIES):
            try:
                resp = self.session.get(api_url, timeout=10)
                if not resp.ok:
                    return None
                data = resp.json()
                if not data.get('success'):
                    error = data.get('error', '')
                    if 'rate limit' in error.lower() and attempt < _RATE_LIMIT_RETRIES - 1:
                        fflog(f'vidlink rate limited, retry {attempt + 1}')
                        time.sleep(_RATE_LIMIT_DELAY)
                        continue
                    fflog(f'vidlink error: {error}')
                    return None
                return data
            except Exception:
                fflog_exc()
                return None
        return None


def _parse_master_manifest(text: str) -> List[Tuple[str, str]]:
    results: List[Tuple[str, str]] = []
    for match in _RE_STREAM.finditer(text):
        width = int(match.group(1))
        path = match.group(2).strip()
        quality = 'SD'
        for min_width, label in _WIDTH_TO_QUALITY:
            if width >= min_width:
                quality = label
                break
        results.append((quality, path))
    return results


def _make_item(source_name: str, quality: str, stream_url: str) -> dict:
    return {
        'source': source_name,
        'quality': quality,
        'language': 'en',
        'url': stream_url,
        'direct': True,
        'debridonly': False,
    }


def _decode(url: str) -> Dict[str, str]:
    if not url.startswith(_SCHEME):
        return {}
    parsed = parse_qs(url[len(_SCHEME):], keep_blank_values=True)
    return {k: v[0] for k, v in parsed.items()}


if __name__ == '__main__':
    try:
        from lib.ff.cmdline import DebugArgumentParser as ArgumentParser
    except ImportError:
        from argparse import ArgumentParser
    parser = ArgumentParser(description='Test HDMovix source provider')
    parser.add_argument('tmdb_id', help='TMDB ID')
    parser.add_argument('--type', default='movie', choices=['movie', 'tv'])
    parser.add_argument('--season', type=int, default=1)
    parser.add_argument('--episode', type=int, default=1)
    args = parser.parse_args()

    src = source()
    if args.type == 'movie':
        url = _SCHEME + urlencode({'type': 'movie', 'tmdb': args.tmdb_id})
    else:
        url = _SCHEME + urlencode({'type': 'tv', 'tmdb': args.tmdb_id})
        url = f'{url}&s={args.season}&e={args.episode}'

    from pprint import pprint
    pprint(src.sources(url, [], []))
