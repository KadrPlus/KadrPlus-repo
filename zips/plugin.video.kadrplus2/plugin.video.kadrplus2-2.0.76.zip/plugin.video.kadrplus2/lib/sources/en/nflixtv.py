# -*- coding: utf-8 -*-
"""
Kadr+ 2.0 - źródło: nflixtv.cc (NflixMovies)
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>

"streamvault" backend. Two playable links, both effectively hdghartv, kept
after real-world testing dropped the rest (vaplayer hangs Kodi's player
outright on its obfuscated manifest; vidlink consistently failed to play):

1. TITAN — the private "ad-free" tier (needs a guest token, otherwise 403):
     GET /api/titan/play?id=<tmdb>&type=movie|tv[&season=&episode=]
   Returns an HLS stream TUNNELLED THROUGH nflix's own CDN
   (cdn.nflixmovies.app/api/hls-proxy/...).

2. APK SCRAPE — no auth, hdghartv entry only:
     GET /api/apk/scrape/sources?id=<tmdb>&type=movie|tv[&season=&episode=]
   Returns a ready, DIRECT HLS link from the external CDN.

Reliability of the two varies per title in practice (e.g. the direct apk link
has played smoothly where titan's own proxy buffered), so both are surfaced.
"""

from __future__ import annotations

import re
import time
from typing import ClassVar, Dict, List, Optional, Tuple, TYPE_CHECKING
from urllib.parse import urlencode, parse_qs

from lib.ff import requests
from lib.ff.source_utils import FF_UA, append_headers, get_quality
from lib.ff.log_utils import fflog, fflog_exc

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.sources import SourceItem, SourceTitleAlias


_BASE = 'https://nflixtv.cc'
_SCHEME = 'nflix://'
_TIMEOUT = 15
_GUEST_TTL = 3000  # seconds

_HEADERS: Dict[str, str] = {
    'User-Agent': FF_UA,
    'Accept': 'application/json, text/plain, */*',
    'Referer': _BASE + '/',
    'Origin': _BASE,
}
# headers used to play the titan stream (self-proxied through nflix's CDN)
_STREAM_HEADERS: Dict[str, str] = {
    'User-Agent': FF_UA,
    'Referer': _BASE + '/',
}

# only 'en'/'pl'/'' are valid values for the 'language' field (see _detect_languages)
_EN_NAMES = frozenset({'en', 'eng', 'english'})
_PL_NAMES = frozenset({'pl', 'pol', 'polish', 'polski'})
_RE_AUDIO_LANG = re.compile(r'#EXT-X-MEDIA:TYPE=AUDIO[^\n]*LANGUAGE="([^"]+)"')

# guest token cache: (guestId, guestToken, fetched_at)
_guest_cache: Tuple[str, str, float] = ('', '', 0.0)


# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['en']

    ffitem: 'FFItem'

    def __init__(self) -> None:
        self.session = requests.Session()
        self.session.headers.update(_HEADERS)

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str,
              aliases: 'list[SourceTitleAlias]', year: str) -> Optional[str]:
        tmdb = str(self.ffitem.tmdb_id or '')
        if not tmdb:
            return None
        return _SCHEME + urlencode({'type': 'movie', 'tmdb': tmdb})

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str,
               aliases: 'list[SourceTitleAlias]', year: str) -> Optional[str]:
        # for episodes ffitem.tmdb_id is the episode id; show-level id lives on show_item
        show_item = getattr(self.ffitem, 'show_item', None)
        tmdb = str((show_item.tmdb_id if show_item else None) or self.ffitem.tmdb_id or '')
        if not tmdb:
            return None
        return _SCHEME + urlencode({'type': 'tv', 'tmdb': tmdb})

    def episode(self, url: Optional[str], imdb: str, tvdb: str, title: str,
                premiered: str, season: str, episode: str) -> Optional[str]:
        if not url:
            return None
        return f'{url}&s={int(season)}&e={int(episode)}'

    def sources(self, url: Optional[str], hostDict: List[str],
                hostprDict: List[str]) -> 'List[SourceItem]':
        if not url:
            return []
        params = _decode(url)
        tmdb = params.get('tmdb')
        if not tmdb:
            return []

        media_type = params.get('type', 'movie')
        query: Dict[str, str] = {'id': tmdb, 'type': media_type}
        if media_type == 'tv':
            query['season'] = params.get('s') or '1'
            query['episode'] = params.get('e') or '1'

        results: 'List[SourceItem]' = []
        try:
            results.extend(self._titan(query))
        except Exception:
            fflog_exc()
        try:
            results.extend(self._apk_hdghartv(query))
        except Exception:
            fflog_exc()

        fflog(f'nflixtv: {len(results)} source(s) total')
        return results

    def resolve(self, url: str) -> Optional[str]:
        # URL already carries the appended headers (|Referer=...&...); return as-is.
        return url

    # ── helpers ────────────────────────────────────────────────────────────

    def _titan(self, query: Dict[str, str]) -> 'List[SourceItem]':
        guest = self._ensure_guest()
        if not guest:
            fflog('nflixtv: no guest token — skipping titan')
            return []
        gid, gtok = guest
        headers = {**_HEADERS, 'X-Guest-Id': gid, 'Authorization': f'Bearer {gtok}'}
        try:
            resp = self.session.get(f'{_BASE}/api/titan/play', params=query,
                                    headers=headers, timeout=_TIMEOUT)
        except Exception:
            fflog_exc()
            return []
        if not resp.ok:
            fflog(f'nflixtv: titan HTTP {resp.status_code}')
            return []

        try:
            data = resp.json()
        except Exception:
            return []
        if not data.get('ok'):
            if data.get('error'):
                fflog(f'nflixtv: titan error: {data["error"]}')
            return []

        stream_url = (data.get('hlsUrl') or data.get('hlsPath')
                      or data.get('playlistPath') or '').strip()
        if not stream_url.startswith(('http://', 'https://')):
            return []

        label = str(data.get('label') or data.get('instantProvider') or 'Titan')
        provider = re.sub(r'^\d+p?\s*[•\-|]\s*', '', label).strip() or 'Titan'
        language, info = self._detect_audio(stream_url)

        # Titan returns HLS through a proxy (URL without a .m3u8 extension), so we
        # must force inputstream.adaptive with the "isa+" prefix, otherwise Kodi
        # fails to detect the format ("error probing input format").
        return [{
            'source': f'nflix/{provider}',
            'quality': get_quality(label),
            'language': language,
            'url': _wrap(stream_url, append_headers(_STREAM_HEADERS)),
            'info': info,
            'direct': True,
            'debridonly': False,
            'filename': '',
            'premium': False,
        }]

    def _detect_audio(self, manifest_url: str) -> 'Tuple[str, str]':
        """Fetch the (small) master manifest and detect the declared audio track."""
        try:
            resp = self.session.get(manifest_url, headers=_STREAM_HEADERS, timeout=8)
            if resp.ok:
                return _detect_languages(resp.text)
        except Exception:
            fflog_exc()
        return 'en', ''

    def _apk_hdghartv(self, query: Dict[str, str]) -> 'List[SourceItem]':
        try:
            resp = self.session.get(f'{_BASE}/api/apk/scrape/sources',
                                    params=query, timeout=_TIMEOUT)
        except Exception:
            fflog_exc()
            return []
        if not resp.ok:
            fflog(f'nflixtv: apk sources HTTP {resp.status_code}')
            return []

        try:
            raw = resp.json().get('sources') or []
        except Exception:
            return []

        item = next((i for i in raw if str(i.get('provider') or '').lower() == 'hdghartv'), None)
        if item is None:
            return []
        stream_url = str(item.get('url') or '').strip()
        if not stream_url.startswith(('http://', 'https://')):
            return []

        headers: Dict[str, str] = {'User-Agent': FF_UA}
        if referer := str(item.get('referer') or ''):
            headers['Referer'] = referer
            headers['Origin'] = referer.rstrip('/')

        return [{
            'source': 'hdghartv',
            'quality': get_quality(str(item.get('label') or '')),
            'language': 'en',
            'url': _wrap(stream_url, append_headers(headers)),
            'info': '',
            'direct': True,
            'debridonly': False,
            'filename': '',
            'premium': False,
        }]

    def _ensure_guest(self) -> 'Optional[Tuple[str, str]]':
        global _guest_cache
        gid, gtok, ts = _guest_cache
        if gid and gtok and (time.time() - ts) < _GUEST_TTL:
            return gid, gtok
        try:
            resp = self.session.get(f'{_BASE}/api/auth/guest', timeout=_TIMEOUT)
            if not resp.ok:
                return (gid, gtok) if gid and gtok else None
            data = resp.json()
            gid = data.get('guestId') or ''
            gtok = data.get('guestToken') or ''
            if gid and gtok:
                _guest_cache = (gid, gtok, time.time())
                return gid, gtok
        except Exception:
            fflog_exc()
        return (gid, gtok) if gid and gtok else None


# ─── module helpers ──────────────────────────────────────────────────────────────


def _decode(url: str) -> Dict[str, str]:
    if not url.startswith(_SCHEME):
        return {}
    parsed = parse_qs(url[len(_SCHEME):], keep_blank_values=True)
    return {k: v[0] for k, v in parsed.items()}


def _is_hls(url: str) -> bool:
    """Whether the URL is an HLS stream (m3u8 or an extension-less proxy manifest)."""
    low = url.split('|', 1)[0].lower()
    return ('.m3u8' in low or '/hls-proxy/manifest' in low
            or 'manifest' in low.rsplit('/', 1)[-1] or '.mpd' in low)


def _wrap(stream_url: str, headers_tail: str) -> str:
    """Build the final URL: HLS/DASH gets the ``isa+`` prefix (forces
    inputstream.adaptive), progressive files (mp4/mkv) stay "direct"."""
    url = stream_url + headers_tail
    if _is_hls(stream_url):
        return f'isa+{url}'
    return url


def _detect_languages(manifest_text: str) -> 'Tuple[str, str]':
    """Detect the declared audio track's language (only 'en'/'pl'/'' — see _EN_NAMES)."""
    names = {n.strip().lower() for n in _RE_AUDIO_LANG.findall(manifest_text) if n.strip()}
    if not names:
        return 'en', ''
    if names & _EN_NAMES:
        return 'en', ''
    if names <= _PL_NAMES:
        return 'pl', ''
    return '', ''


if __name__ == '__main__':
    try:
        from lib.ff.cmdline import DebugArgumentParser as ArgumentParser
    except ImportError:
        from argparse import ArgumentParser
    parser = ArgumentParser(description='Test nflixtv source provider')
    parser.add_argument('tmdb_id', help='TMDB ID')
    parser.add_argument('--type', default='movie', choices=['movie', 'tv'])
    parser.add_argument('--season', type=int, default=1)
    parser.add_argument('--episode', type=int, default=1)
    args = parser.parse_args()

    src = source()
    if args.type == 'movie':
        url = _SCHEME + urlencode({'type': 'movie', 'tmdb': args.tmdb_id})
    else:
        url = _SCHEME + urlencode({'type': 'tv', 'tmdb': args.tmdb_id})
        url = f'{url}&s={args.season}&e={args.episode}'

    from pprint import pprint
    pprint(src.sources(url, [], []))
