# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import threading
import time
from typing import ClassVar, Dict, List, Optional, Set, TYPE_CHECKING
from urllib.parse import urlencode, unquote

from lib.ff import requests
from lib.ff import cache, control
from lib.ff.source_utils import append_headers, extract_cookie, probe_m3u8_quality
from lib.ff.log_utils import fflog, fflog_exc

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.sources import SourceItem, SourceTitleAlias


_API_BASE = 'https://dulo.tv/api'
_SESSION_CACHE_KEY = 'dulotv_session_cookie'
_SESSION_TTL_H = 7.5

_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
       'AppleWebKit/537.36 (KHTML, like Gecko) '
       'Chrome/137.0.0.0 Safari/537.36')

_API_HEADERS: Dict[str, str] = {
    'User-Agent': _UA,
    'Origin': 'https://dulo.tv',
    'Referer': 'https://dulo.tv/',
}

_PROVIDERS: List[str] = ['artemis', 'purstream', 'vidlink', 'xpass']

_V2_PROXY_PROVIDERS: Set[str] = {'vidlink', 'xpass'}
_V2_HLS_PROVIDERS: Set[str] = {'xpass'}

_SCHEME = 'dulotv://'

_STREAM_HEADERS: Dict[str, Dict[str, str]] = {
    'artemis': {
        'User-Agent': _UA,
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Origin': 'https://dulo.tv',
        'Referer': 'https://dulo.tv/',
    },
    'purstream': {
        'User-Agent': _UA,
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
    },
    'vidlink': {
        'User-Agent': _UA,
        'Accept': '*/*',
        'Origin': 'https://dulo.tv',
        'Referer': 'https://dulo.tv/',
    },
    'xpass': {
        'User-Agent': _UA,
        'Accept': '*/*',
        'Origin': 'https://dulo.tv',
        'Referer': 'https://dulo.tv/',
    },
}

_QUALITY_MAP: Dict[str, str] = {
    '4k': '4K', '2160p': '4K', '2160': '4K',
    '1080p': '1080p', '1080': '1080p',
    '800p': '1080p', '800': '1080p',
    '720p': '720p', '720': '720p',
    '532p': '720p', '532': '720p',
    '480p': 'SD', '480': 'SD',
    '360p': 'SD', '360': 'SD',
}


# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['en']

    ffitem: 'FFItem'

    def __init__(self) -> None:
        self.session = requests.Session()
        self.session.headers.update(_API_HEADERS)

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str,
              aliases: 'list[SourceTitleAlias]', year: str) -> Optional[str]:
        tmdb = str(self.ffitem.tmdb_id or '')
        if not tmdb:
            return None
        return f'{_SCHEME}movie/{tmdb}'

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str,
               aliases: 'list[SourceTitleAlias]', year: str) -> Optional[str]:
        show_item = getattr(self.ffitem, 'show_item', None)
        tmdb = str((show_item.tmdb_id if show_item else None) or self.ffitem.tmdb_id or '')
        if not tmdb:
            return None
        return f'{_SCHEME}tv/{tmdb}'

    def episode(self, url: Optional[str], imdb: str, tvdb: str, title: str,
                premiered: str, season: str, episode: str) -> Optional[str]:
        if not url:
            return None
        return f'{url}/{int(season)}/{int(episode)}'

    def sources(self, url: Optional[str], hostDict: List[str],
                hostprDict: List[str]) -> 'List[SourceItem]':
        if not url:
            return []
        parsed = _parse_url(url)
        if not parsed:
            return []
        media_type, tmdb, season, episode = parsed

        session_cookie = self._get_session_cookie()
        if not session_cookie:
            fflog('dulo: nie udało się uzyskać cookie sesji')
            return []

        headers_with_cookie = {**_API_HEADERS, 'Cookie': session_cookie}

        results: List[dict] = []
        lock = threading.Lock()

        threads = [
            threading.Thread(
                target=self._fetch_provider,
                args=(provider, media_type, tmdb, season, episode,
                      headers_with_cookie, results, lock),
                daemon=True,
            )
            for provider in _PROVIDERS
        ]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=20)

        fflog(f'dulo: znaleziono {len(results)} źródeł (tmdb={tmdb})')
        return results

    def resolve(self, url: str) -> Optional[str]:
        return url

    # ── session cookie ─────────────────────────────────────────────────────

    def _get_session_cookie(self) -> Optional[str]:
        cached = cache.cache_get(_SESSION_CACHE_KEY, control.providercacheFile)
        if cached:
            try:
                data = json.loads(cached['value'])
                stored_at = int(cached.get('date', 0))
                if time.time() - stored_at < _SESSION_TTL_H * 3600:
                    return data['cookie']
            except Exception:
                pass
        return self._refresh_session_cookie()

    def _refresh_session_cookie(self) -> Optional[str]:
        try:
            resp = self.session.get(
                f'{_API_BASE}/session',
                headers=_API_HEADERS,
                timeout=10,
                allow_redirects=True,
            )
            if not resp.ok:
                return None
            cookie_value = resp.cookies.get('amri_session')
            if not cookie_value:
                cookie_value = extract_cookie(resp.headers.get('set-cookie', ''), 'amri_session') or None
            if not cookie_value:
                return None
            cookie_str = f'amri_session={cookie_value}'
            cache.cache_insert(
                _SESSION_CACHE_KEY,
                json.dumps({'cookie': cookie_str}),
                control.providercacheFile,
            )
            fflog('dulo: nowe cookie sesji')
            return cookie_str
        except Exception:
            fflog_exc()
            return None

    # ── provider fetch ─────────────────────────────────────────────────────

    def _fetch_provider(self, provider: str, media_type: str, tmdb: str,
                        season: Optional[int], episode: Optional[int],
                        headers: Dict[str, str],
                        out: List[dict], lock: threading.Lock) -> None:
        try:
            params: Dict[str, str] = {'type': media_type, 'tmdb': tmdb, 'provider': provider}
            if media_type == 'tv' and season is not None and episode is not None:
                params['season'] = str(season)
                params['episode'] = str(episode)

            resp = self.session.get(
                f'{_API_BASE}/sources/call?{urlencode(params)}',
                headers=headers,
                timeout=25,
            )
            if not resp.ok:
                fflog(f'dulo {provider}: HTTP {resp.status_code}')
                return

            data = resp.json()
            sources = data.get('sources') or []
            if not sources:
                fflog(f'dulo {provider}: brak źródeł (reason={data.get("reason", "")})')
                return

            stream_headers = _STREAM_HEADERS.get(provider, {})
            is_v2 = provider in _V2_PROXY_PROVIDERS
            is_hls = provider in _V2_HLS_PROVIDERS

            for src in sources:
                stream_url = src.get('url', '')
                if not stream_url or not stream_url.startswith('http'):
                    continue

                if is_v2:
                    if '?u=' in stream_url:
                        stream_url = unquote(stream_url.split('?u=', 1)[1])
                    if is_hls:
                        if not _hls_segment_is_video(stream_url, stream_headers, self.session):
                            continue
                        final_url = f'isa+{stream_url}{append_headers(stream_headers)}'
                    else:
                        final_url = f'{stream_url}{append_headers(stream_headers)}'
                    quality = _extract_quality(src.get('title', ''), None)
                else:
                    src_headers = src.get('headers') or stream_headers
                    effective_headers = (
                        src_headers if isinstance(src_headers, dict) and src_headers
                        else stream_headers
                    )
                    quality = _extract_quality(src.get('title', ''), stream_url, effective_headers)
                    final_url = f'isa+{stream_url}{append_headers(effective_headers)}'

                with lock:
                    out.append({
                        'source': f'DULO {provider.upper()}',
                        'quality': quality,
                        'language': 'en',
                        'url': final_url,
                        'direct': True,
                        'debridonly': False,
                    })
        except Exception:
            fflog_exc()


# ─── helpers ──────────────────────────────────────────────────────────────────

def _hls_segment_is_video(playlist_url: str, headers: Dict[str, str], session) -> bool:
    try:
        resp = session.get(playlist_url, headers=headers, timeout=8)
        if not resp.ok:
            return True
        seg_url = next(
            (line.strip() for line in resp.text.split('\n') if line.strip().startswith('http')),
            None,
        )
        if not seg_url:
            return True
        head = session.head(seg_url, headers=headers, timeout=5, allow_redirects=True)
        return not head.headers.get('content-type', '').lower().startswith('image/')
    except Exception:
        return True


def _parse_url(url: str) -> Optional[tuple]:
    if not url.startswith(_SCHEME):
        return None
    parts = url[len(_SCHEME):].split('/')
    if len(parts) < 2:
        return None
    season: Optional[int] = None
    episode: Optional[int] = None
    if len(parts) >= 4:
        try:
            season, episode = int(parts[2]), int(parts[3])
        except (ValueError, IndexError):
            pass
    return parts[0], parts[1], season, episode


def _extract_quality(title: str, url: Optional[str] = None,
                     headers: Optional[Dict[str, str]] = None) -> str:
    if url and '.m3u8' in url and headers is not None:
        probed = probe_m3u8_quality(url, headers, timeout=5.0, on_unknown=None)
        if probed:
            return probed
    lower = title.lower()
    for key, quality in _QUALITY_MAP.items():
        if key in lower:
            return quality
    return '1080p'


if __name__ == '__main__':
    try:
        from lib.ff.cmdline import DebugArgumentParser as ArgumentParser
    except ImportError:
        from argparse import ArgumentParser
    parser = ArgumentParser(description='Test dulo.tv source provider')
    parser.add_argument('tmdb_id', help='TMDB ID')
    parser.add_argument('--type', default='movie', choices=['movie', 'tv'])
    parser.add_argument('--season', type=int, default=None)
    parser.add_argument('--episode', type=int, default=None)
    args = parser.parse_args()

    src = source()
    play_url: Optional[str] = f'{_SCHEME}{args.type}/{args.tmdb_id}'
    if args.type == 'tv' and args.season and args.episode:
        play_url = f'{play_url}/{args.season}/{args.episode}'

    try:
        from pprint import pprint
        pprint(src.sources(play_url, [], []))
    except Exception as exc:
        print(f'Error: {exc}')
