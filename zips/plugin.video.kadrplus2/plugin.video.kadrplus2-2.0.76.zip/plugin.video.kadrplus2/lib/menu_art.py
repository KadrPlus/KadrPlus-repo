"""Lossless, on-demand portrait wrappers for Kadr+ navigation artwork.

The add-on ships one sharp 512x512 icon for every navigation entry.  Poster
views need a 2:3 image, but packaging a second copy of every icon made the ZIP
larger and earlier downscaling softened the frame.  These wrappers are created
only when a menu actually needs them, in the add-on profile cache, with the
original 512x512 pixels pasted unchanged into a 512x768 canvas.
"""

from __future__ import annotations

import os
from pathlib import Path
import threading


_CACHE_SCHEMA = 'menu_posters_exact_v1'


def _translated(value: str) -> str:
    if not value:
        return ''
    try:
        import xbmcvfs
        return xbmcvfs.translatePath(value)
    except Exception:
        return value


def _profile_path() -> Path | None:
    try:
        import xbmcaddon
        profile = _translated(xbmcaddon.Addon().getAddonInfo('profile'))
        return Path(profile) if profile else None
    except Exception:
        return None


def _output_path(source: Path, media_root: Path, profile: Path) -> Path:
    try:
        relative = source.relative_to(media_root)
    except ValueError:
        relative = Path(source.name)
    return profile / _CACHE_SCHEMA / relative


def navigation_poster(
    source: str | Path,
    *,
    media_root: str | Path,
    profile: str | Path | None = None,
) -> str:
    """Return a sharp 2:3 wrapper for a square navigation icon.

    Non-square images and any generation failure fall back to the original
    path.  This keeps the menu functional even on unusual Pillow builds.
    """
    source_path = Path(_translated(str(source)))
    if not source_path.is_file():
        return str(source)

    profile_path = Path(_translated(str(profile))) if profile else _profile_path()
    if profile_path is None:
        return str(source_path)
    media_path = Path(_translated(str(media_root)))
    output = _output_path(source_path, media_path, profile_path)
    try:
        if output.stat().st_size > 0:
            return str(output)
    except OSError:
        pass

    try:
        from PIL import Image

        with Image.open(source_path) as original:
            original.load()
            width, height = original.size
            # Real posters, banners and landscapes already have the right
            # composition and must never be wrapped again.
            if width < 16 or height < 16 or abs(width - height) > max(width, height) * 0.04:
                return str(source_path)

            target_height = int(round(width * 1.5))
            top = max(0, (target_height - height) // 2)
            if original.mode == 'P':
                background = original.getpixel((0, 0))
                canvas = Image.new('P', (width, target_height), background)
                canvas.putpalette(original.getpalette())
                transparency = original.info.get('transparency')
                if transparency is not None:
                    canvas.info['transparency'] = transparency
                canvas.paste(original, (0, top))
            else:
                image = original.convert('RGBA')
                background = image.getpixel((0, 0))
                canvas = Image.new('RGBA', (width, target_height), background)
                # No alpha mask here: the source region must remain bit-for-bit
                # identical, including semi-transparent edge pixels.
                canvas.paste(image, (0, top))

            output.parent.mkdir(parents=True, exist_ok=True)
            temporary = output.with_name(
                f'.{output.name}.{os.getpid()}.{threading.get_ident()}.tmp'
            )
            try:
                # Pixel data and visual quality are identical at every PNG
                # compression level. A low level avoids Pillow's expensive
                # optimizer and makes the first opening of poster menus much
                # faster on Android; these files live only in the profile cache.
                canvas.save(temporary, format='PNG', compress_level=1)
                os.replace(temporary, output)
            finally:
                try:
                    temporary.unlink(missing_ok=True)
                except OSError:
                    pass
        return str(output)
    except Exception:
        return str(source_path)
