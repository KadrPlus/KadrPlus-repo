"""Very small renderer for the Kadr+ root menu.

The regular router intentionally supports many media types and integrations,
but importing all of them just to draw eight static root entries is expensive
on Android TV hardware.  This module only uses Kodi's built-in API and mirrors
the root entries without touching the API, database or source-search modules.
"""

from __future__ import annotations

from pathlib import Path
from time import monotonic

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin


ADDON_ID = 'plugin.video.kadrplus2'


def _setting(addon: xbmcaddon.Addon, setting_id: str) -> str:
    return addon.getSetting(setting_id)


def _setting_bool(addon: xbmcaddon.Addon, setting_id: str) -> bool:
    return _setting(addon, setting_id).strip().lower() == 'true'


def render_root(handle: int, *, started: float | None = None) -> None:
    """Render the main menu and return as soon as Kodi accepts the listing."""
    started = monotonic() if started is None else started
    addon = xbmcaddon.Addon()
    addon_path = Path(addon.getAddonInfo('path'))
    media_path = addon_path / 'resources' / 'media'
    fanart = str(addon_path / 'fanart.jpg')
    base_url = f'plugin://{ADDON_ID}'

    rows: list[tuple[int, str, str]] = [
        (32001, 'movie', 'movies/main.png'),
        (32002, 'show', 'tvshows/main.png'),
    ]
    if _setting_bool(addon, 'anime_folder'):
        rows.append((30518, 'anime', 'anime/main.png'))
    rows.append((30175, 'person', 'persons/main.png'))

    if _setting(addon, 'trakt.token'):
        rows.append((30164, 'trakt', 'services/trakt/lists.png'))
    if _setting(addon, 'tmdb.sessionid') or _setting(addon, 'tmdb.access_token'):
        rows.append((30165, 'tmdb', 'services/tmdb/lists.png'))
    if _setting(addon, 'imdb.at-main') or _setting(addon, 'imdb.user'):
        rows.append((30349, 'imdb', 'services/imdb/lists.png'))
    if _setting(addon, 'mdblist.api_key'):
        rows.append((30367, 'mdblist', 'services/mdblist/lists.png'))

    # Kadr+ own lists are enabled by default and do not require authorization.
    rows.extend([
        (30327, 'own', 'services/own/lists.png'),
        (32036, 'history', 'common/history.png'),
        (32008, 'tools', 'common/tools.png'),
        (32010, 'search', 'common/search.png'),
    ])

    items = []
    for label_id, route, relative_art in rows:
        label = addon.getLocalizedString(label_id)
        artwork = str(media_path / relative_art)
        item = xbmcgui.ListItem(label=label)
        item.setArt({
            'thumb': artwork,
            'icon': artwork,
            'fanart': fanart,
        })
        item.setProperty('IsPlayable', 'false')
        items.append((f'{base_url}/{route}/', item, True))

    xbmcplugin.setContent(handle, 'addons')
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(
        handle,
        succeeded=True,
        updateListing=False,
        cacheToDisc=False,
    )
    if _setting_bool(addon, 'diagnostics.enabled'):
        elapsed = monotonic() - started
        xbmc.log(
            f'[KADR2-DIAG][route] name=root; items={len(items)}; elapsed={elapsed:.3f}s',
            xbmc.LOGINFO,
        )
