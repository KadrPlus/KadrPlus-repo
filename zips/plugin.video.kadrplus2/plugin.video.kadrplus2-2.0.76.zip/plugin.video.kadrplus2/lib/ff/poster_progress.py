"""Render the classic Kadr+ movie-progress bar on poster artwork.

Remote artwork is exposed through the persistent local Kadr+ service. Kodi
therefore receives the directory immediately and downloads the decorated
poster asynchronously, just as it downloads ordinary remote artwork.
"""

from __future__ import annotations

import base64
import hashlib
import os
import threading
import time
from io import BytesIO
from urllib.parse import unquote, urlsplit, urlunsplit

from . import control
from .log_utils import fflog_exc
from .settings import settings


_CACHE_CLEANED = False
_CACHE_SCHEMA = 'v6-classic-square-jpeg'
_MAX_POSTER_BYTES = 12 * 1024 * 1024
_MAX_PROXY_TOKEN = 8192
_HTTP_SESSION = None
_HTTP_SESSION_LOCK = threading.Lock()
_OUTPUT_LOCKS: dict[str, threading.Lock] = {}
_OUTPUT_LOCKS_LOCK = threading.Lock()


def _enabled() -> bool:
    try:
        return settings.getBool('kadrplus.poster_progress')
    except Exception:
        return True


def poster_progress_active(percent: float | int | str) -> bool:
    """Return whether the movie should have a poster progress bar."""
    if not _enabled():
        return False
    try:
        value = float(percent)
    except (TypeError, ValueError):
        return False
    return 3 <= value <= 95


def normalise_image_path(path: str) -> str:
    """Convert Kodi image and special paths to a value Pillow can open."""
    value = str(path or '').strip()
    if value.startswith('image://'):
        value = unquote(value[8:])
        if value.startswith(('http://', 'https://')) and value.endswith('/'):
            value = value[:-1]
    if value.startswith('special://'):
        value = control.transPath(value)
    return value


def _cache_dir() -> str:
    path = os.path.join(control.dataPath, 'poster_progress')
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        return ''
    return path


def _progress_bucket(percent: float | int | str) -> int:
    value = int(round(float(percent)))
    return max(5, min(95, int(round(value / 5.0) * 5)))


def _progress_key(poster: str, bucket: int) -> str:
    value = f'{_CACHE_SCHEMA}|{poster}|{bucket}'
    return hashlib.md5(value.encode('utf-8')).hexdigest()


def _cache_output(poster: str, bucket: int, cache: str = '') -> str:
    cache = cache or _cache_dir()
    if not cache:
        return ''
    return os.path.join(cache, f'{_progress_key(poster, bucket)}.jpg')


def _cleanup_cache(path: str) -> None:
    """Bound generated artwork without touching Kodi's own image cache."""
    global _CACHE_CLEANED
    if _CACHE_CLEANED:
        return
    _CACHE_CLEANED = True
    try:
        now = time.time()
        current = []
        for name in os.listdir(path):
            full = os.path.join(path, name)
            if name.endswith('.png'):
                try:
                    os.remove(full)
                except OSError:
                    pass
                continue
            if not name.endswith(('.jpg', '.jpeg')):
                continue
            try:
                file_stat = os.stat(full)
            except OSError:
                continue
            if now - file_stat.st_mtime > 60 * 24 * 3600:
                try:
                    os.remove(full)
                except OSError:
                    pass
            else:
                current.append((file_stat.st_mtime, full))
        for _, full in sorted(current, reverse=True)[500:]:
            try:
                os.remove(full)
            except OSError:
                pass
    except Exception:
        pass


def _poster_download_url(source: str) -> str:
    """Avoid downloading oversized TMDB originals for a small poster tile."""
    try:
        parsed = urlsplit(source)
        if parsed.hostname and parsed.hostname.lower() == 'image.tmdb.org':
            parts = parsed.path.split('/')
            if len(parts) > 4 and parts[1:3] == ['t', 'p']:
                parts[3] = 'w500'
                return urlunsplit(parsed._replace(path='/'.join(parts)))
    except Exception:
        pass
    return source


def _http_session():
    global _HTTP_SESSION
    if _HTTP_SESSION is not None:
        return _HTTP_SESSION
    with _HTTP_SESSION_LOCK:
        if _HTTP_SESSION is None:
            import requests

            session = requests.Session()
            session.headers.update({'User-Agent': 'Mozilla/5.0 (Kadr+ 2.0)'})
            try:
                adapter = requests.adapters.HTTPAdapter(
                    pool_connections=12,
                    pool_maxsize=12,
                    max_retries=1,
                )
                session.mount('https://', adapter)
                session.mount('http://', adapter)
            except Exception:
                pass
            _HTTP_SESSION = session
    return _HTTP_SESSION


def _load_image(source: str):
    try:
        from PIL import Image
    except Exception:
        return None

    source = normalise_image_path(source)
    if source.startswith(('http://', 'https://')):
        try:
            response = _http_session().get(
                _poster_download_url(source),
                timeout=(2.0, 6.0),
            )
            response.raise_for_status()
            declared = int(response.headers.get('Content-Length', 0) or 0)
            if declared > _MAX_POSTER_BYTES:
                return None
            content = response.content
            if len(content) > _MAX_POSTER_BYTES:
                return None
            return Image.open(BytesIO(content)).convert('RGBA')
        except Exception:
            return None
    try:
        if not source or not os.path.exists(source):
            return None
        return Image.open(source).convert('RGBA')
    except Exception:
        return None


def _render_progress_poster(poster: str, bucket: int, output: str) -> str:
    image = _load_image(poster)
    if image is None:
        return poster

    temporary = f'{output}.{os.getpid()}.{threading.get_ident()}.tmp'
    try:
        from PIL import Image, ImageDraw

        resampling = getattr(Image, 'Resampling', Image)
        image.thumbnail((720, 1080), resampling.LANCZOS)
        width, height = image.size
        if width < 20 or height < 20:
            return poster

        bar_height = max(6, int(height * 0.035))
        padding = max(3, int(width * 0.025))
        x0, x1 = padding, width - padding
        y0 = height - bar_height - padding

        overlay = Image.new('RGBA', image.size, (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)
        draw.rectangle(
            [x0, y0, x1, y0 + bar_height],
            fill=(0, 0, 0, 145),
        )
        if bucket < 35:
            colour = (170, 170, 170, 235)
        elif bucket < 75:
            colour = (220, 180, 40, 235)
        else:
            colour = (40, 170, 70, 235)
        fill_width = max(1, int((x1 - x0) * bucket / 100.0))
        draw.rectangle(
            [x0, y0, x0 + fill_width, y0 + bar_height],
            fill=colour,
        )

        image = Image.alpha_composite(image, overlay).convert('RGB')
        image.save(
            temporary,
            'JPEG',
            quality=89,
            subsampling=2,
            progressive=False,
        )
        os.replace(temporary, output)
        return output
    except Exception:
        fflog_exc(0)
        return poster
    finally:
        try:
            if os.path.exists(temporary):
                os.remove(temporary)
        except OSError:
            pass


def _proxy_token(poster: str) -> str:
    encoded = base64.urlsafe_b64encode(poster.encode('utf-8'))
    return encoded.decode('ascii').rstrip('=')


def decode_proxy_source(token: str, key: str, bucket: int) -> str:
    """Decode and verify a source passed to the localhost poster endpoint."""
    try:
        if not token or len(token) > _MAX_PROXY_TOKEN:
            return ''
        padding = '=' * (-len(token) % 4)
        poster = base64.b64decode(
            token + padding,
            altchars=b'-_',
            validate=True,
        ).decode('utf-8')
        if _progress_key(poster, int(bucket)) != key:
            return ''
        normalised = normalise_image_path(poster)
        if not normalised.startswith(('http://', 'https://')):
            return ''
        return poster
    except Exception:
        return ''


def _proxy_progress_poster(poster: str, bucket: int) -> str:
    try:
        from ..service.client import service_client

        base = service_client.ready_url
        if not base:
            return ''
        key = _progress_key(poster, bucket)
        token = _proxy_token(poster)
        return (
            f'{base.rstrip("/")}/media/poster-progress/'
            f'{bucket}/{key}.jpg?source={token}'
        )
    except Exception:
        return ''


def _output_lock(output: str) -> threading.Lock:
    with _OUTPUT_LOCKS_LOCK:
        return _OUTPUT_LOCKS.setdefault(output, threading.Lock())


def progress_poster_bytes(poster: str, bucket: int) -> bytes | None:
    """Return one cached poster, rendering it once when first requested."""
    try:
        bucket = int(bucket)
    except (TypeError, ValueError):
        return None
    if not 5 <= bucket <= 95:
        return None

    cache = _cache_dir()
    if not cache:
        return None
    _cleanup_cache(cache)
    output = _cache_output(poster, bucket, cache)
    with _output_lock(output):
        try:
            cached = os.path.getsize(output) > 0
        except OSError:
            cached = False
        if not cached and _render_progress_poster(poster, bucket, output) != output:
            return None
    try:
        with open(output, 'rb') as stream:
            return stream.read()
    except OSError:
        return None


def progress_poster(poster: str, percent: float | int | str) -> str:
    """Return cached or service-backed artwork without blocking the list."""
    if not poster_progress_active(percent) or not poster or poster == '0':
        return poster
    try:
        bucket = _progress_bucket(percent)
    except (TypeError, ValueError):
        return poster

    output = _cache_output(poster, bucket)
    if output:
        try:
            if os.path.getsize(output) > 0:
                return output
        except OSError:
            pass

    normalised = normalise_image_path(poster)
    if normalised.startswith(('http://', 'https://')):
        return _proxy_progress_poster(poster, bucket) or poster

    cache = os.path.dirname(output)
    if cache:
        _cleanup_cache(cache)
    return _render_progress_poster(poster, bucket, output) if output else poster


def apply_poster_progress(item, percent: float | int | str) -> bool:
    """Apply decorated movie artwork and report whether it was selected."""
    try:
        if item.getProperty('kadrplus.progressposter') == 'true':
            return True
        art = item.getArt()
        poster = art.get('poster') or art.get('tvshow.poster') or art.get('thumb')
        generated = progress_poster(poster, percent)
        if not generated or generated == poster:
            return False

        updated = dict(art)
        updated['original.poster'] = poster
        updated['poster'] = generated
        updated['small_poster'] = generated
        updated['tvshow.poster'] = generated
        for key in ('thumb', 'icon'):
            if not updated.get(key) or updated.get(key) == poster:
                updated[key] = generated
        item.setArt(updated)
        item.setProperty('KadrPlus.ProgressPoster', 'true')
        item.setProperty(
            'KadrPlus.ProgressPercent',
            str(int(round(float(percent)))),
        )
        return True
    except Exception:
        fflog_exc(0)
        return False
