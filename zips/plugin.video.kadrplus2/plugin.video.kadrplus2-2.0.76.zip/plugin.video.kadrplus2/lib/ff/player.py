"""
    Kadr+ 2.0 Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import annotations
from typing import overload
import json
import xml.etree.ElementTree as ET
from ast import literal_eval
from functools import lru_cache
from urllib.parse import unquote, urlencode

from xbmc import getCondVisibility, getInfoLabel
from xbmcvfs import translatePath
from xbmcplugin import setResolvedUrl
from xbmcgui import ListItem

from . import control
from .db import state
from .item import FFItem
from ..indexers.defs import VideoIds
from .log_utils import fflog, fflog_exc
from .control import syshandle, resources_file
from .kotools import stop_playing
from .kodidb import video_db
from .settings import settings
from ..sources import Source
from const import const, PlayCancel, MediaWatchedMode


@lru_cache(maxsize=1)
def _external_player_exts() -> frozenset:
    try:
        tree = ET.parse(translatePath('special://userdata/playercorefactory.xml'))
    except Exception:
        return frozenset()
    ep = {p.get('name') for p in tree.findall('.//player') if p.get('type') == 'ExternalPlayer'}
    rules = [r for r in tree.findall('.//rule') if r.get('player') in ep]
    if any(r.get('video') == 'true' or r.get('internetstream') == 'true' for r in rules if not r.get('filetypes')):
        return frozenset({'*'})
    return frozenset(e.lstrip('*.') for r in rules if (ft := r.get('filetypes')) for e in ft.lower().split('|') if e and '!' not in e)


def _restore_playback_resume(item: FFItem) -> None:
    """Restore native resume metadata only on the final playable ListItem."""
    if not settings.getBool('kadrplus.poster_progress') or not item.progress or item.progress.play_count:
        return
    try:
        progress = float(item.progress.progress or 0)
        duration = item.vtag.getDuration() or const.indexer.episodes.missing_duration
        if 0 < progress < 100 and duration:
            item.vtag.setResumePoint(duration * progress / 100, duration)
            item.setProperty('PercentPlayed', str(int(progress)))
    except (TypeError, ValueError):
        pass


def server_file(fname: str) -> str:
    return resources_file(fname)  # HACK, use file from disk (resources/media/)
    # url = state.get('url', module='service', mode=state.StateMode.DB)
    # return f'{url}{fname}'


def fallback_path() -> str:
    """Falback for play movie/eposode FF3 URL."""
    from sys import argv
    if len(argv) >= 2:
        return argv[0] + argv[2]
    return ''


def cancel(ffitem: FFItem | None = None, *, clean: bool = False) -> None:  # TODO: remove ffitem?
    """Cancel starting a video play."""
    # fflog(f'[PLAYER] CANCEL, {ffitem=}')
    try:
        # pli = get_player_item()
        if clean:
            # Back/Cancel from the source windows must not resolve to any media.
            # Even an immediately stopped black placeholder briefly activates
            # Kodi's player, so skins can draw a playback badge on the selected
            # poster and artwork helpers try to thumbnail the plugin URL.
            # A failed resolution closes the pending plugin play request without
            # creating playback history, resume data or a transient Player item.
            cancel_mode = PlayCancel.FALSE
        elif getInfoLabel('ListItem.Label') and getInfoLabel('ListItem.PercentPlayed') == '0' and not getCondVisibility('ListItem.IsResumable'):
            # has info and play from beggining
            cancel_mode = const.player.cancel_start  # typically PlayCancel.EMPTY
        else:
            # resume or missing info (we don't know if resume or not, resume is more safty)
            cancel_mode = const.player.cancel_resume  # typically PlayCancel.TT430

        if cancel_mode is PlayCancel.FALSE:
            item = ListItem()
        elif cancel_mode is PlayCancel.EMPTY:
            item = ListItem(path=server_file('media/empty.m3u8'))
        elif cancel_mode is PlayCancel.TT430:
            item = ListItem(path=server_file('media/tt430.mp4'))
        else:
            fflog.error(f'Unknown player cancel mode {cancel_mode!r}')
            item = ListItem()
        item.setContentLookup(False)  # we don't need HEAD
        fflog(f'[PLAYER] CANCEL, mode={cancel_mode.name}, {ffitem=}, path={item.getPath()!r}')
        if ffitem:
            fflog(f'[PLAYER] CANCEL, {ffitem.getPath()=}')
        state.multi_set(module='player', values=(
            ('playing.empty', cancel_mode is not PlayCancel.FALSE),
            ('playing.run', False),
            ('cancel.mode', cancel_mode.value),
            ('state', 'cancel'),
        ))
        setResolvedUrl(syshandle, cancel_mode != PlayCancel.FALSE, item)
        if cancel_mode is not PlayCancel.FALSE:
            stop_playing()
        else:
            control.close_busy_dialog()
        # A clean Back/Cancel already returns to the existing directory. The
        # old refresh rebuilt it while the technical black placeholder was
        # stopping, so skins flashed a playback badge on the selected poster
        # and Kodi could subsequently request the ``noop`` route.
        if cancel_mode == PlayCancel.TT430 and const.player.refresh_on_cancel_resume and not clean:
            control.refresh()

    except Exception:
        fflog_exc()


@overload
def play(*, source: Source, start_directly: bool = False) -> None: ...

@overload
def play(*, ffitem: FFItem, url: str, start_directly: bool = False) -> None: ...

def play(*, source: Source | None = None, ffitem: FFItem | None = None, url: str | None = None,
         start_directly: bool = False) -> None:
    """Resolve and start a video play."""

    if source is None:
        if not url:
            return cancel(ffitem)
        if ffitem is None or url is None:
            raise ValueError(f'Use `source` or (`ffitem` and `url`): got nothing')
        source = Source(url=url, provider='', hosting='', ffitem=ffitem)
    elif ffitem is not None or url is not None:
        raise ValueError(f'Use `source` or (`ffitem` and `url`) not both')
    ffitem = source.ffitem
    main = ffitem.show_item or ffitem
    url = source.url

    fflog(f'[PLAYER] {url=}, ref={ffitem.ref:a}, {ffitem=}, ffid={ffitem.ffid}', stack_depth=2)
    if not url or url == 'empty':
        return cancel(ffitem)
    try:
        fflog(f'[PLAYER] {url=}')
        item = ffitem.clone()
        vtag = ffitem.vtag

        # Directory posters with the custom Kadr+ progress bar deliberately
        # hide Kodi's native resume marker so skins do not add a second black
        # bookmark.  Restore the real resume point only on the final playable
        # ListItem, preserving "continue watching" without the duplicate
        # poster decoration.
        _restore_playback_resume(item)

        imdb = vtag.getIMDBNumber() or vtag.getUniqueID('imdb') or ''
        tmdb = int(vtag.getUniqueID('tmdb') or 0)
        ids = VideoIds(tmdb=tmdb, imdb=imdb).ids()

        if const.player.set_dbid and (kodi_dbid := video_db.get_kodi_dbid(ffitem.ref)):
            vtag.setDbId(kodi_dbid)  # Kodi DBID
        elif const.core.media_watched_mode is not MediaWatchedMode.FAKE_DBID and ffitem.ffid not in VideoIds.KODI:
            vtag.setDbId(0)  # Reset Kodi DBID, seems it does NOT work

        # --- URL prefixes, pleas, don't use them ---
        play_mode = '...'
        if ia := url.startswith('ia://'):
            url = url[5:]  # remove 'ia://` prefix
        elif ia := (url.startswith('isa+') and '://' in url):
            url = url[4:]  # remove 'isa+ prefix
        elif ia := (url.startswith('direct+') and '://' in url):
            url = url[7:]  # remove 'direct+ prefix
        # --- play modes ---
        else:
            play_mode = source.attr.play
            if play_mode == 'isa':
                ia = True
            elif play_mode == 'direct':
                ia = False
            else:  # auto
                ia = settings.getBool('isa.enabled') and source.is_m3u8()

        fflog(f'Play mode {play_mode!r}: ISA = {ia}')
        if ia:
            import inputstreamhelper
            from .. import kodi

            if '.mpd' in url:
                protocol = 'mpd'
                mimetype = 'application/dash+xml'
            else:
                protocol = 'hls'
                mimetype = 'application/x-mpegURL'

            is_helper = inputstreamhelper.Helper(protocol)
            if not is_helper.check_inputstream():
                return cancel(ffitem)

            listitem = item
            listitem.setProperty('inputstream', is_helper.inputstream_addon)
            if kodi.version < 21:
                listitem.setProperty('inputstream.adaptive.manifest_type', protocol)
            listitem.setMimeType(mimetype)
            listitem.setContentLookup(False)
            if '|' in url:
                parts = url.split('|', 2)
                url = parts[0]
                strhdr = parts[1]
                listitem.setProperty('inputstream.adaptive.stream_headers', strhdr)
                if kodi.version > 19:
                    listitem.setProperty('inputstream.adaptive.manifest_headers', strhdr)
                if len(parts) == 3 and parts[2]:
                    listitem.setProperty('inputstream.adaptive.config', parts[2])
                listitem.setPath(url)

        if url.upper().startswith('DRMFF|'):
            item = get_drm_item(url, item=item)
            if not item:
                fflog('[DRM] could NOT resolve item')
        else:
            if not ia and '|' in url and not url.startswith(('plugin://', 'stack://')):
                base_url, headers_str = url.split('|', 1)
                for pair in headers_str.split('&'):
                    if '=' in pair:
                        key, _, val = pair.partition('=')
                        item.setProperty(unquote(key), unquote(val))
                ext = base_url.split('?')[0].rsplit('.', 1)[-1].replace('/', '').lower()
                if _external_player_exts() & {ext, '*'}:
                    url = base_url
                fflog(f'[PLAYER] Direct: headers via setProperty, ext={ext!r}, strip={url == base_url}')
            item.setPath(url)
            item.setContentLookup(const.player.head_lookup)
        if item is None:
            return cancel(ffitem)
        item.vtag.setUniqueIDs(main.vtag.getUniqueIDs(), 'tmdb')
        item.vtag.setIMDBNumber(main.vtag.getIMDBNumber() or main.vtag.getUniqueID('imdb') or '')

        # Check for subtitles stored in window property
        try:
            subtitles_json = control.window().getProperty('source.subtitles')
            if subtitles_json:
                subtitle_files = json.loads(subtitles_json)
                if subtitle_files:
                    item.setSubtitles(subtitle_files)
                    fflog(f'[PLAYER] Added {len(subtitle_files)} subtitles to ListItem')
                # Clear the property after use
                control.window().clearProperty('source.subtitles')
        except Exception as e:
            fflog(f'[PLAYER] Failed to load FlixHQ subtitles: {e}')

        # item.setInfo(type="video", infoLabels=control.metadataClean(meta))
        fflog(f'setResolvedUrl(url={url!r})')

        state.multi_set(module='player', values=(
            ('media.ref', ffitem.ref),
            ('media.imdb', imdb),
            ('media.tmdb', tmdb),
            ('media.season', ffitem.season),
            ('media.episode', ffitem.episode),
            ('media.ffid', ffitem.ffid),
            ('media.real_type', ffitem.ref.real_type),
            ('media.duration', ffitem.vtag.getDuration()),
            ('media.url', ffitem.getPath() or fallback_path()),
            ('playing.empty', False),
            ('playing.run', True),
            ('cancel_mode', None),
            ('state', 'play'),
        ))
        control.window().setProperty("script.trakt.ids", json.dumps(ids))
        if start_directly:
            # The initial source resolves the plugin:// handle. If the user
            # stops it and selects another source from the reopened list, that
            # original handle has already been consumed; start the next item via
            # xbmc.Player instead of sending a second setResolvedUrl response.
            # Use the final path stored in the ListItem.  DRMFF and ISA sources
            # replace their internal descriptor with the real manifest above;
            # passing ``url`` here made Kodi try to open the literal
            # ``DRMFF|{...}`` string as a protocol after returning to the list.
            control.player().play(item.getPath() or url, item)
        else:
            setResolvedUrl(syshandle, True, item)
        # close_busy_dialog()

    except Exception:
        fflog_exc()


def get_drm_item(url: str, *, item: FFItem | None = None) -> FFItem | None:
    """
    DRM support by Lantash.

    InputStream old properties – deprecated (Kodi 18-22).
    See: https://github.com/xbmc/inputstream.adaptive/wiki/Integration-DRM
    """
    import inputstreamhelper
    from .. import kodi
    stream_data = literal_eval(url.split('|', 1)[-1])
    if not isinstance(stream_data, dict):
        raise ValueError('Invalid DRMFF stream descriptor')

    protocol = str(stream_data.get('protocol') or 'mpd').lower()
    manifest = str(stream_data.get('manifest') or '')
    if not manifest:
        raise ValueError('DRMFF stream descriptor has no manifest')

    is_helper = inputstreamhelper.Helper(protocol)
    if not is_helper.check_inputstream():
        return None

    if item is None:
        item = FFItem(path=manifest, offscreen=True)
    else:
        item.setPath(manifest)
        item.vtag.setPath(manifest)
    item.setContentLookup(False)

    item.setProperty('inputstream', is_helper.inputstream_addon)
    item.setMimeType(str(stream_data.get('mimetype') or 'application/dash+xml'))
    if kodi.version < 21:
        item.setProperty('inputstream.adaptive.manifest_type', protocol)

    stream_headers = stream_data.get('stream_headers') or ''
    if isinstance(stream_headers, dict):
        stream_headers = urlencode({
            str(key): str(value)
            for key, value in stream_headers.items()
            if value is not None
        })
    elif not isinstance(stream_headers, str):
        stream_headers = ''
    if stream_headers:
        item.setProperty('inputstream.adaptive.stream_headers', stream_headers)
        if kodi.version > 19:
            item.setProperty('inputstream.adaptive.manifest_headers', stream_headers)

    licence_url = str(stream_data.get('licence_url') or '')
    licence_type = str(stream_data.get('licence_type') or '')
    if licence_url and licence_type and kodi.version <= 21:
        item.setProperty('inputstream.adaptive.license_type', licence_type)
        license_config = {'license_server_url': licence_url,
                          'headers': str(stream_data.get('licence_header') or ''),
                          'post_data': str(stream_data.get('post_data') or ''),
                          'response_data': str(stream_data.get('response_data') or '')
                          }
        item.setProperty('inputstream.adaptive.license_key', '|'.join(license_config.values()))
    if licence_url and licence_type and kodi.version >= 22:
        drm_configs = {
            licence_type: {
                "license": {
                    "server_url": licence_url,
                    "req_headers": str(stream_data.get('licence_header') or ''),
                }
            }
        }
        item.setProperty('inputstream.adaptive.drm', json.dumps(drm_configs))
    item.setProperty('IsPlayable', 'true')
    return item
