"""
Simple HTTP Web server for Kadr+ 2.0 Kodi addon users.

Used to help users set up their Kodi addon by providing a web interface.
"""

if True:  # to avoid: module level import not at top of file (flake8 E402)
    def cli_define():
        from ..dev.main import predefine as tui_predefine, base_args_parser
        p = base_args_parser()
        p.add_argument('-p', '--port', type=int, default=8663, help='server port')
        p.add_argument('-t', '--threading', action='store_true', help='multithreading / concurrent requests')
        p.add_argument('-j', '--user-js', choices=['stable', 'beta'], help='cat fanfilm.user.js file (for stable or beta version)')
        p.add_argument('--help', action='help', help='show this help message and exit')
        args, _ = tui_predefine(args=p.parse_args())
        return args

    if __name__ == '__main__':
        cli_args = cli_define()
    else:
        cli_args = None

from typing import Optional, Dict, Type, Mapping, TYPE_CHECKING
from pathlib import Path
from weakref import WeakSet
from fnmatch import fnmatch
from http.server import BaseHTTPRequestHandler, HTTPServer, ThreadingHTTPServer
from hmac import compare_digest
from secrets import token_urlsafe
import os
import re
from .http_request import (
    RequestHandler, Route, request, routes, Address,
    HTTPBadRequest, HTTPForbidden, HTTPNotFound, HTTPUnprocessableContent, ExpectedJsonObjectError,
)
from ..ff.threads import Thread, Event, Lock
from ..ff.routing import URL  # , Router
from ..ff.settings import settings
from ..ff.control import dataPath
from ..ff.types import JsonData, JsonResult
from ..ff.log_utils import fflog, fflog_exc
from ..kolang import L
from const import const
if TYPE_CHECKING:
    from .main import Works
    from socketserver import BaseRequestHandler
    import socket


if TYPE_CHECKING:
    class ServerBase(ThreadingHTTPServer):
        pass
elif __name__ == '__main__' and not cli_args.threading:  # DEBUG only !!!
    class ServerBase(HTTPServer):
        pass
else:
    class ServerBase(ThreadingHTTPServer):
        pass


class Server(ServerBase):
    """Kadr+ 2.0 Web Server."""

    daemon_threads = True  # terminate worker threads when main thread terminates

    MIME_TYPES = {
        '.js': 'application/javascript; charset=utf-8',
        '.css': 'text/css; charset=utf-8',
        '.html': 'text/html; charset=utf-8',
    }

    # list of all supported credentials settings names, taken from const.tune.service.web_server.cookies
    CREDENTIALS = frozenset(name for hc in const.tune.service.web_server.cookies.values() for name in hc.values())
    PUBLIC_ROUTES = frozenset({'static', 'static_beta', 'static_addon'})

    def __init__(self,
                 server_address: Address,
                 RequestHandlerClass: Type[BaseHTTPRequestHandler] = RequestHandler,
                 *,
                 works: Optional['Works'] = None,
                 token: str,
                 ) -> None:
        from ..ff.kotools import Notification
        super().__init__(server_address, RequestHandlerClass)
        host, port = self.server_address
        self.url = URL(f'http://{host}:{port}/')
        self.routes = tuple(route for route in routes if route.call.__module__ == __name__)
        self.response_headers = {
            'Cache-Control': 'no-store',
            'Referrer-Policy': 'no-referrer',
            'X-Content-Type-Options': 'nosniff',
            'X-Frame-Options': 'DENY',
        }
        self.token = token
        self.db_lock = Lock()
        self.works: Optional['Works'] = works
        self.events: Dict[str, Event] = {} if works is None else works.events  # no copy - shared events
        self.path = Path(__file__).parent.parent.parent / 'web'
        self._active_requests: 'WeakSet[socket.socket]' = WeakSet()
        self._update_notif = Notification('Kadr+ 2.0', L(30519, 'Received cookies'))

    def authorize_request(self, req) -> None:
        """Require the per-installation access key for every sensitive route."""
        if req.route.call.__name__ in self.PUBLIC_ROUTES:
            return
        supplied = req.headers.get('X-Kadr-Token', '') or req.params.get('token', '')
        if not supplied or not compare_digest(str(supplied), self.token):
            raise HTTPForbidden(message='invalid Kadr+ access key')

    @staticmethod
    def modify_js_for_beta(file: bytes) -> bytes:
        """Modify JavaScript file content for beta version."""
        import re
        file = re.sub(rb'^(//\s*@name\s+Kadr+ 2.0)$', rb'\1 Beta', file, flags=re.MULTILINE)
        file = re.sub(rb'^(// @(?:icon|downloadURL|updateURL)\b\s+ https://raw.githubusercontent.com/fanfilm-pl/)repository.fanfilm/',
                      rb'\1repository.fanfilm.beta/', file, flags=re.MULTILINE)
        return file

    def finish_request(self, request, client_address):
        """Finish one request by instantiating RequestHandlerClass."""
        fflog(f'New request {request} from {client_address}')
        self._active_requests.add(request)
        req = self.RequestHandlerClass(request, client_address, self)
        self._active_requests.discard(request)
        fflog(f'Finish request {request} from {client_address}')

    @Route.get(r'/(index.html)?')
    def root(self) -> str:
        try:
            return (self.path / 'index.html').read_text(encoding='utf-8')
        except OSError:
            fflog_exc()
            return '<!DOCTYPE html><html><head><title>Kadr+ 2.0 Web Server</title></head><body>Not supported</body></html>'

    @Route.post(r'/echo')
    def echo(self) -> JsonResult:
        data = request.json
        return data

    def file(self, path: Path) -> 'tuple[int, bytes, dict[str, str]]':
        """Read static file and return response tuple (status, content, headers)."""
        ext = path.suffix.lower()
        headers: 'dict[str, str]' = {}
        if ctype := self.MIME_TYPES.get(ext):
            headers['Content-Type'] = ctype
        try:
            if not path.is_file():
                raise FileNotFoundError(path)
            return 200, path.read_bytes(), headers
        except FileNotFoundError:
            fflog.info(f'Missing static file: {path}')
        except OSError:
            fflog_exc()
        raise HTTPNotFound(f'File not found: {path}')

    @staticmethod
    def _safe_file(base: Path, relative: str) -> Path:
        """Resolve a web asset without allowing ``..`` to escape its root."""
        root = base.resolve()
        candidate = (root / relative).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            raise HTTPNotFound(message='file not found')
        return candidate

    @Route.get(r'/(?P<path>(?:static|mod)/.+)')
    def static(self, path: str) -> 'tuple[int, bytes, dict[str, str]]':
        return self.file(self._safe_file(self.path, path))

    @Route.get(r'/beta/(?P<path>.+)')
    def static_beta(self, path: str) -> 'tuple[int, bytes, dict[str, str]]':
        status, file, headers = self.file(self._safe_file(self.path / 'mod', path))
        if path.endswith('.js') and status == 200 and isinstance(file, bytes):
            file = self.modify_js_for_beta(file)
        return status, file, headers

    @Route.get(r'/addon/(?P<path>(?:fanart\.jpg|icon\.png))')
    def static_addon(self, path: str) -> 'tuple[int, bytes, dict[str, str]]':
        return self.file(Path(__file__).parent.parent.parent / path)

    def _list_credentials(self) -> JsonData:
        def label(js_name: str, setting_name: str) -> str:
            if js_name == ':user_agent':
                return L(30353, 'User agent')
            if js_name.startswith(':'):
                return js_name[1:].replace('_', ' ').title()
            if js_name == 'cf_clearance':
                return L(30526, 'Cloudflare cookie')
            return L(30527, 'Cookie ({name})').format(name=js_name)

        return {
            'settings': [
                {
                    'name': name,
                    'value': value,
                    'section': host,
                    'cookie': js_name,
                    'label': label(js_name, name),
                    # 'buttons': ['user_agent'] if js_name == ':user_agent' else [],
                } for host, hsets in const.tune.service.web_server.cookies.items()
                for js_name, name in hsets.items()
                if (value := settings.get(name)) is not None
            ]
        }

    def _get_cookie_value(self, setting_name: str, cookie: str) -> str:
        from ..ff.source_utils import extract_cookie
        for cookies_defs in const.tune.service.web_server.cookies.values():
            for cookie_name, setting in cookies_defs.items():
                if setting == setting_name:
                    return extract_cookie(cookie=cookie, cookie_name=cookie_name)
        return cookie

    @Route.get(r'/credentials/?')  # (?P<name>[^/]+)')
    def list_credentials(self) -> JsonData:
        return self._list_credentials()

    @Route.post(r'/credentials/?')
    def set_all_credentials(self) -> JsonData:
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        if setting_list := data.get('settings'):
            if not isinstance(setting_list, list):
                raise HTTPBadRequest(message='settings must be a list')
            for setting in setting_list:
                if not isinstance(setting, Mapping):
                    continue
                name, cookie = setting.get('name'), setting.get('value')
                if name in self.CREDENTIALS:
                    cookie = self._get_cookie_value(name, str(cookie or ''))
                    settings.setString(name, cookie[:65536])
            fflog(f'Updated {len(setting_list)} credential fields')
        return self._list_credentials()

    @Route.get(r'/credentials/(?P<name>[^/]+)')
    def get_credentials(self, name: str) -> JsonData:
        if name not in self.CREDENTIALS:
            raise HTTPNotFound(message='credential not found')
        value = settings.get(name)
        return {
            'name': name,
            'value': value,
        }

    @Route.post(r'/credentials/(?P<name>[^/]+)')
    def set_credentials(self, name: str) -> JsonData:
        if name not in self.CREDENTIALS:
            raise HTTPNotFound(message='credential not found')
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        value = str(data.get('value') or '')[:65536]
        settings.setString(name, value)
        return {
            'name': name,
            'value': value,
        }

    @Route.post(r'/cookies')
    def update_cookies(self) -> JsonData:
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        cookie_list = data.get('cookies', [])
        if not isinstance(cookie_list, list):
            raise HTTPBadRequest(message='cookies must be a list')
        host = str(data.get('host') or '').strip().lower()
        if not re.fullmatch(r'[a-z0-9.-]{1,253}', host):
            raise HTTPBadRequest(message='invalid host')
        fflog(f'Updating cookies: {host} ({len(cookie_list)} fields)')
        settings_count = 0
        changed: 'set[str]' = set()
        if host:
            for host_def, conv in const.tune.service.web_server.cookies.items():
                if fnmatch(host, host_def) if isinstance(host_def, str) else host_def.fullmatch(host):
                    cookies = {
                        name: str(value)[:65536]
                        for cookie in cookie_list
                        if isinstance(cookie, Mapping)
                        and (name := cookie.get('name'))
                        and (value := cookie.get('value'))
                    }
                    for cookie_name, settings_name in conv.items():
                        if cookie_name == ':UA':  # user-agent
                            cookie_name = ':user_agent'
                        if cookie_name.startswith(':'):  # meta, ex: user-agent
                            value = str(data.get(cookie_name[1:], '') or '')[:65536]
                            if value != settings.getString(settings_name):
                                changed.add(settings_name)
                            settings.setString(settings_name, value)
                            settings_count += 1
                        else:
                            value = cookies.get(cookie_name, '')
                            if value != settings.getString(settings_name):
                                changed.add(settings_name)
                            settings.setString(settings_name, value)
                            settings_count += 1
        if changed or data.get('forced_by_user'):
            fflog(f'Changed settings: {", ".join(sorted(changed))}')
            if const.tune.service.web_server.update_notification:
                self._update_notif.show()
        return {
            'success': True,
            'settings_count': settings_count,
        }


class WebServer:
    """The main function that starts the HTTP Web Server."""

    def __init__(self,
                 *,
                 works: Optional['Works'] = None,
                 ) -> None:
        self._running: bool = False
        self._server: Optional[Server] = None
        self._httpd_thread: Optional[Thread] = None
        self.works: Optional['Works'] = works
        self._token = self._load_or_create_token()

    @staticmethod
    def _load_or_create_token() -> str:
        """Return a stable random access key stored in the add-on profile."""
        token_path = Path(dataPath) / 'web_server.token'
        try:
            token = token_path.read_text(encoding='ascii').strip()
            if re.fullmatch(r'[A-Za-z0-9_-]{32,128}', token):
                return token
        except OSError:
            pass

        token = token_urlsafe(32)
        try:
            token_path.parent.mkdir(parents=True, exist_ok=True)
            tmp_path = token_path.with_suffix('.tmp')
            tmp_path.write_text(token, encoding='ascii')
            try:
                os.chmod(tmp_path, 0o600)
            except OSError:
                pass
            tmp_path.replace(token_path)
        except OSError:
            fflog.warning('Could not persist the web server access key; using a temporary key')
        return token

    @property
    def running(self) -> bool:
        return self._running

    @property
    def token(self) -> str:
        return self._token

    def start(self) -> None:
        """Start proxy server (in new therad)."""
        if self._running:
            return

        address = '0.0.0.0'  # any address
        try:
            # create HTTP server and start serve in new therad
            self._server = Server(
                (address, const.tune.service.web_server.port),
                RequestHandler,
                works=self.works,
                token=self._token,
            )
            self._server.allow_reuse_address = True
            self._httpd_thread = Thread(target=self._server.serve_forever, name='Service WEB')
            self._httpd_thread.start()
            self._running = True

            # get port number and set server URL in the settings
            fflog(f'=== Web Server Started: {self._server.url} ===')

        except Exception:
            # creating HTTP server failed, clear URL in the settings
            self._running = False
            fflog_exc()
            raise

    def stop(self):
        """Stop proxy server."""
        if not self._running:
            return

        # shutdown and close the server
        try:
            if self._server is not None:
                self._server.shutdown()
                self._server.server_close()
                if self._server._active_requests:
                    fflog(f'Active requests: {self._server._active_requests}')
                for req in self._server._active_requests:
                    try:
                        req.shutdown(2)
                    except Exception as exc:
                        fflog(f'Exception during closing request socket: {exc}')
                    try:
                        req.close()
                    except Exception as exc:
                        fflog(f'Exception during closing request socket: {exc}')
                self._server._active_requests.clear()
                self._server.socket.close()
                self._server._update_notif.close()
                self._server = None
            if self._httpd_thread is not None:
                self._httpd_thread.join()
                self._httpd_thread = None
        except Exception as exc:
            fflog(f'Exception during stopping web server: {exc}')
            fflog_exc()
        self._running = False
        fflog('=== Web Server Stopped ===')


# DEBUG (command line tests)
def main(args):
    def _run_server():
        from .main import Works
        address = '0.0.0.0'
        works = Works(
            events={
                'folder': Event(),
            },
        )
        works.events['folder'].set()
        server = Server((address, args.port), RequestHandler, works=works, token=token_urlsafe(32))
        server.allow_reuse_address = True
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print('   Interrupted, shutting down ...')
            server.shutdown()
            server.server_close()
            print('Server stopped.')
        finally:
            from .main import stop
            from ..ff.kotools import destroy_xmonitor
            stop()
            destroy_xmonitor()
        # from threading import enumerate as thread_enumerate
        # from .main import threads
        # print('Active threads:', thread_enumerate())
        # print('Kadr+ 2.0 threads:', threads)

    if args.user_js == 'stable':
        print((Path(__file__).parent.parent.parent / 'web' / 'mod' / 'fanfilm.user.js').read_text(encoding='utf-8'))
    elif args.user_js == 'beta':
        print(Server.modify_js_for_beta((Path(__file__).parent.parent.parent / 'web' / 'mod' / 'fanfilm.user.js').read_bytes()).decode('utf-8'))
    else:
        _run_server()


if __name__ == '__main__' and cli_args is not None:
    main(cli_args)
