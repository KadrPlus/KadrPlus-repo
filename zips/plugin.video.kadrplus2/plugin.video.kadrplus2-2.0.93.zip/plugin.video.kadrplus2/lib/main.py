"""Main module."""

# parse command-line (debug) args on TOP, to set global options first
if __name__ == '__main__':
    try:
        from .dev.main import predefine as tui_predefine, parse_args as tui_parse_args
    except ModuleNotFoundError:
        import sys
        print('There is no module lib.dev, find a developer release.')
        sys.exit(0)
    cli_args, cli_argv = tui_predefine(args=tui_parse_args())
else:
    cli_args, cli_argv = None, []

import sys  # for exit()
from typing import Optional, List, Set, TYPE_CHECKING
from typing_extensions import Literal
from time import monotonic

import xbmcgui

from const import const
from .ff.settings import settings
from .ff.routing import URL, dispatch, main_router
from .ff import control
from .ff.control import Finally
from .ff.db import state
from .ff.log_utils import fflog, fflog_exc
from .ff.routing import route, PathArg
from .ff.calendar import utc_timestamp
from .ff.menu import KodiDirectory, directory
from .ff.info import ffinfo
from .service.client import service_client
# from .defs import VideoIds
from .indexers import navigator
from .kolang import L

if TYPE_CHECKING:
    from .service.misc import PluginRequestInfo


nav = navigator.Navigator()
# main_router.add_route('/', router=nav)  -- Navigator is now MainRouteObject
main_router.set_default_route_object(nav)
main_router.url = URL(control.plugin_url)


def reset() -> None:
    """Reset all stuff for reuse code (re-run in the same Python interpreter)."""
    L.reset()
    settings.reset()  # force recreate settings proxy
    control.reset()
    navigator.reset()
    ffinfo.reset()
    # trakt.trakt_credentials_manager.reset()


#: Folders to bypass.
empty_folders: Set[str] = set()


def bypass_scanning(info: 'PluginRequestInfo') -> bool:
    if info.scan_finished:
        empty_folders.clear()
    try:
        root, path, show_id, *waste, num = info.url.path.split('/')
    except Exception:
        return False
    if not root and not waste and path == 'tvshow' and f'/tvshow/{show_id}' == info.media_url.path and num.isdigit() and show_id.isdigit():
        with directory() as kdir:
            if info.scan_started:  # return all episodes (starting from 2nd sezon) in single folder
                from .defs import MediaRef
                from .ff.info import ffinfo
                from cdefs import InfoDetails
                details = InfoDetails.new(const.indexer.trakt.lists.info_details)
                ffitem = ffinfo.find_item(MediaRef.tvshow(int(show_id)), progress=ffinfo.Progress.NO, details=details)
                if ffitem:
                    for sz in ffitem.season_iter():
                        if sz.season and sz.season >= 2:
                            for ep in sz.episode_iter():
                                kdir.add(ep, url=kdir.no_op)
                        empty_folders.add(f'/tvshow/{show_id}/{sz.season}')
        return True
    return False


def main(argv: List[str]) -> None:
    """The main FF entry."""

    if 0:  # DEBUG: measure settings load time
        with fflog_exc():
            from xbmcaddon import Addon
            from .ff.tricks import timeit
            from .ff.settings import SettingsManager
            t = timeit(lambda: Addon().getSetting('plugin.video.kadrplus2'))
            fflog(f'|||||>>>>>>>>>>>>>>>>>>>>>>> SETTINGS (KODI)  !!!!! : {t:.6f} sec')
            t = timeit(settings.load_settings)
            fflog(f'|||||>>>>>>>>>>>>>>>>>>>>>>> SETTINGS (USER)  !!!!! : {t:.6f} sec')
            t = timeit(lambda: SettingsManager().load_settings())
            fflog(f'|||||>>>>>>>>>>>>>>>>>>>>>>> SETTINGS (ALL)   !!!!! : {t:.6f} sec')
            t = timeit(lambda: SettingsManager().load_defaults())
            fflog(f'|||||>>>>>>>>>>>>>>>>>>>>>>> SETTINGS (DEFS)  !!!!! : {t:.6f} sec')

    if 0:  # FFItem/ListItem tests
        from xbmcgui import ListItem
        it = ListItem()
        vtag = it.getVideoInfoTag()
        it.setDateTime('2025-12-31 11:22:33')
        fflog(f'>>>>>>>>>>>>>>>>>>>>>>>>>>>> {it.getDateTime()=}')
        fflog(f'>>>>>>>>>>>>>>>>>>>>>>>>>>>> {vtag.getFirstAiredAsW3C()=}')
        fflog(f'>>>>>>>>>>>>>>>>>>>>>>>>>>>> {it.getProperty("isPlayable")=}, {it.isFolder()=}')

    T = monotonic()
    url = URL(argv[0] + argv[2])
    if url.path in empty_folders:
        from xbmcplugin import endOfDirectory
        endOfDirectory(int(sys.argv[1]), updateListing=False, cacheToDisc=False)
        return
    Finally.clear()
    # /play is a long-lived resolved-URL request, not a folder generation. It
    # overlaps the real parent refresh after Player.OnStop; registering it in the
    # single folder-history tracker lets its late exit overwrite that refresh.
    track_folder_request = bool(
        control.is_plugin_folder()
        and not (url.path == '/play' or url.path.startswith('/play/'))
    )
    if track_folder_request:
        folder_info = service_client.plugin_request_enter(url, timestamp=utc_timestamp())
    else:
        from .service.misc import PluginRequestInfo
        folder_info = PluginRequestInfo()
    KodiDirectory.set_current_info(url, folder_info)
    master: bool = state.enter('plugin')
    state.delete_all(module='directory')
    state.multi_set((
        ('running', True),
        ('url', str(url)),
        ('path', url.path),
    ), module='directory')
    try:
        if folder_info.scan and bypass_scanning(folder_info):
            trakt_db_timestamp = state.get('db.timestamp', module='trakt', default=0)
        else:
            KodiDirectory.ready_for_data()
            trakt_db_timestamp = state.get('db.timestamp', module='trakt', default=0)
            # Keep the fast root path, but never swallow legacy query routes
            # such as /?action=play&tmdb=... . Those must go through dispatch().
            if url.path in ('', '/') and not url.query:
                fflog('[KADR2-DIR] direct root menu')
                nav.home()
                handled = True
            else:
                handled = dispatch(url)
            fflog(f'[KADR2-DIR] dispatch done: {url=}, {handled=}, created={KodiDirectory.CREATED}')
            if not handled:
                control.infoDialog(L(33100, 'Unsupported path: {path}').format(path=url.path), heading='Kadr+ 2.0')
    except Exception:
        fflog_exc()
        raise
    else:
        # handle queued jobs
        for job in state.jobs('plugin'):
            handle_job(job, argv)
        if KodiDirectory.INFO.refresh:
            new_timestamp = state.get('db.timestamp', module='trakt', default=0)
            fflog(f'Refresh? {trakt_db_timestamp=}, {new_timestamp=}')
            if new_timestamp != trakt_db_timestamp:
                control.refresh()
    finally:
        if track_folder_request:
            service_client.plugin_request_exit(folder=KodiDirectory.CONTENT if KodiDirectory.CREATED else None,
                                               focus=KodiDirectory.FOCUS_INDEX, timestamp=utc_timestamp())
        state.set('running', False, module='directory', connect=False)
        state.exit('plugin')
        for fin in Finally.iter():
            fin()
        Finally.clear()
        # Do not call endOfDirectory() after a /play route. Playback routes are
        # completed with setResolvedUrl(); a second directory result on the same
        # handle makes Kodi discard the stream and can also mark the item played.
        T = monotonic() - T
        fflog(f'[FF] main finished in {T:.3f} seconds')


@route
def xplay(type: PathArg[Literal['movie', 'tvshow']], ffid: PathArg[int],
          season: Optional[PathArg[int]] = None, episode: Optional[PathArg[int]] = None) -> None:
    """Play video."""
    print(f'play({type=}, {ffid=}, {season=}, {episode=}) ...')


# XXX  ---( DEBUG )---   XXX
@route('/play430/movie')
def fake_play_movie(ffid: PathArg[int], *, edit: bool = False) -> None:
    from pathlib import Path
    from .defs import MediaRef
    from .ff import player
    from .ff.item import FFItem
    import sty
    item: Optional[FFItem] = ffinfo.find_item(MediaRef('movie', ffid))
    fflog(f'{sty.fg.cyan}######{sty.rs.all} {ffid=}, {item=}')
    with state.with_var('playing.prepare', module='player'):
        if item and control.yesnoDialog('play fake video'):
            player.play(item, str(Path('~/Videos/Agent 700 _ WYSOKA JAKOŚĆ -g-bbImiyuPQ.mkv').expanduser()))
        else:
            player.cancel(item)


@route
def rescan(ffid: Optional[PathArg[int]] = None) -> None:
    """Rescan sources in source window."""
    # from lib.ff import sources
    from lib.ff.cache import cache_clear_sources  # cache_clear_providers

    # `ffid` is ignored now. This method clear cache and emulate click in gui.

    cache_clear_sources()
    checkWin = xbmcgui.getCurrentWindowId()

    control.execute("Dialog.Close(all,true)")
    control.execute(f"ReplaceWindow({checkWin})")
    control.execute("Action(Select)")


@route('/telegram/login-qr')
def telegram_login_qr() -> None:
    """Log in to Telegram using a QR code and reopen settings afterwards."""
    from .sources.tg.telegram import source
    try:
        source().login_qr_from_settings()
    finally:
        try:
            control.openSettings()
        except Exception:
            pass


@route('/telegram/check-session')
def telegram_check_session() -> None:
    """Verify the saved Telegram session and reopen settings afterwards."""
    from .sources.tg.telegram import source
    pd = None
    try:
        try:
            pd = control.progressDialog()
            pd.create('Telegram', 'Sprawdzanie statusu logowania...\nŁączenie z Telegramem')
            pd.update(5, 'Sprawdzanie statusu logowania...\nŁączenie z Telegramem')
        except Exception:
            pd = None
        ok = source().refresh_login_status_from_settings(force=True)
        try:
            if pd is not None:
                pd.update(100, 'Sprawdzanie statusu logowania...\nGotowe')
                pd.close()
                pd = None
        except Exception:
            pass
        if ok:
            control.infoDialog('Telegram: %s' % L(33135, 'Logged in'), heading='Telegram', time=3500, sound=False)
        else:
            control.infoDialog('Telegram: %s' % L(33136, 'Not logged in'), heading='Telegram', icon='WARNING', time=3500, sound=False)
        # Give Kodi's GUI loop a moment to render the top-right notification
        # before opening the settings dialog again.
        control.sleep(650)
    finally:
        try:
            if pd is not None:
                pd.close()
        except Exception:
            pass
        try:
            control.openSettings()
        except Exception:
            pass


@route('/telegram/clear-session')
def telegram_clear_session() -> None:
    """Remove the saved Telegram session and reopen settings afterwards."""
    from .sources.tg.telegram import source
    try:
        source().clear_session_from_settings()
    finally:
        try:
            control.openSettings()
        except Exception:
            pass


@route('/telegram/refresh-chats')
def telegram_refresh_chats() -> None:
    """Refresh the list of the user's Telegram groups and channels."""
    from .sources.tg.telegram import source
    source().refresh_chat_filter_list_from_settings()


@route('/telegram/choose-chats')
def telegram_choose_chats() -> None:
    """Choose Telegram groups/channels to include or exclude."""
    from .sources.tg.telegram import source
    source().choose_chat_filter_from_settings()


@route('/telegram/clear-chats')
def telegram_clear_chats() -> None:
    """Clear the saved Telegram chat selection."""
    from .sources.tg.telegram import source
    source().clear_chat_filter_from_settings()


@route('/telegram/refresh-topics')
def telegram_refresh_topics() -> None:
    """Refresh Telegram forum topics for user-selected forum groups."""
    from .sources.tg.telegram import source
    source().refresh_topic_filter_list_from_settings()


@route('/telegram/choose-topics')
def telegram_choose_topics() -> None:
    """Choose individual Telegram forum topics to search."""
    from .sources.tg.telegram import source
    source().choose_topic_filter_from_settings()


@route('/telegram/clear-topics')
def telegram_clear_topics() -> None:
    """Clear the saved Telegram forum-topic selection."""
    from .sources.tg.telegram import source
    source().clear_topic_filter_from_settings()


@route
def crash() -> None:
    """Forces crash, raises en exception."""
    raise Exception('Devleper forced CRASH')


def handle_job(job: state.Job, argv: List[str]) -> None:
    """Handle pending job."""

    if const.debug.enabled:
        if const.debug.tty:
            fflog(f'[JOB] \033[96mjob\033[0m: {job}')
        else:
            fflog(f'[JOB] job: {job}')
    if job.command == 'update':
        if job.args and job.args[0]:
            path = job.args[0]
        else:
            path = ''  # f'{argv[0]}{argv[2]}'  # path to current plugin call
        control.update(path)
    elif job.command == 'refresh':
        control.refresh()
    elif job.command == 'builtin':
        control.execute(job.args[0])


# --- testy (konsola)  ---


if __name__ == '__main__':
    from .dev.main import main as tui
    tui(args=cli_args)
