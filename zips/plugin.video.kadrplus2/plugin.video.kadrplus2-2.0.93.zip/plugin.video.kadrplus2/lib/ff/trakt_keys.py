"""Profile-local Trakt application keys. Copyright (C) 2026 divoff - MIT.

AES-256-CTR with encrypt-then-MAC (HMAC-SHA256), random IVs and separate
keys. Since Kadr+ 2.0.93 this module is strictly non-destructive: the one-time
key reset belonged to 2.0.92 and is never repeated here.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
from pathlib import Path
from time import monotonic
import uuid

from pyaes.aes import AESModeOfOperationCTR, Counter
from xbmcaddon import Addon
from xbmcvfs import translatePath
from .profile_lock import profile_lock

FIELDS = ('trakt.client_key', 'trakt.secret_key')
_CACHE_TTL = 2.0
_cache_value = None
_cache_time = 0.0


def _profile():
    return Path(translatePath(Addon().getAddonInfo('profile')))


def _locked(profile):
    """Serialize writes made by plugin and service interpreters."""
    return profile_lock(profile, 'trakt_keys.lock')


def _atomic(path, data):
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        fd = os.open(str(temp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'wb') as out:
            out.write(data)
            out.flush()
            os.fsync(out.fileno())
        os.replace(str(temp), str(path))
    finally:
        if temp.exists():
            temp.unlink()


def _read(profile):
    path = profile / 'trakt_keys.json'
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        raise ValueError('Invalid Trakt key storage')
    return data


def _save(profile, data):
    profile.mkdir(parents=True, exist_ok=True)
    _atomic(profile / 'trakt_keys.json', json.dumps(data, sort_keys=True).encode('utf-8'))


def _master(profile, *, create=False):
    path = profile / 'trakt_keys.key'
    if not path.exists() and create:
        profile.mkdir(parents=True, exist_ok=True)
        if any((_read(profile).get('keys') or {}).values()):
            raise OSError('Missing profile encryption key')
        _atomic(path, os.urandom(64))
    if not path.exists():
        raise OSError('Missing profile encryption key')
    key = path.read_bytes()
    if len(key) != 64:
        raise ValueError('Invalid profile encryption key')
    return key


def _encrypt(value, field, key):
    if not value:
        return ''
    iv = os.urandom(16)
    cipher = AESModeOfOperationCTR(key[:32], counter=Counter(int.from_bytes(iv, 'big')))
    payload = iv + cipher.encrypt(value.encode('utf-8'))
    mac = hmac.new(key[32:], b'kadr-trakt-v1\0' + field.encode('ascii') + payload, hashlib.sha256).digest()
    return 'v1:' + base64.b64encode(payload + mac).decode('ascii')


def _decrypt(value, field, key):
    if not value:
        return ''
    if not value.startswith('v1:'):
        raise ValueError('Unknown Trakt key format')
    raw = base64.b64decode(value[3:], validate=True)
    if len(raw) < 49:
        raise ValueError('Invalid encrypted Trakt key')
    payload, mac = raw[:-32], raw[-32:]
    expected = hmac.new(key[32:], b'kadr-trakt-v1\0' + field.encode('ascii') + payload, hashlib.sha256).digest()
    if not hmac.compare_digest(mac, expected):
        raise ValueError('Trakt key integrity check failed')
    cipher = AESModeOfOperationCTR(key[:32], counter=Counter(int.from_bytes(payload[:16], 'big')))
    return cipher.decrypt(payload[16:]).decode('utf-8')


def _invalidate_cache():
    global _cache_value, _cache_time
    _cache_value = None
    _cache_time = 0.0


def _encrypted_credentials(profile):
    data = _read(profile)
    values = data.get('keys') or {}
    if not isinstance(values, dict) or not any(values.values()):
        return None
    key = _master(profile)
    return tuple(_decrypt(values.get(field, ''), field, key) for field in FIELDS)


def credentials(*, force=False):
    """Return keys without migration, writes or profile locks.

    A short cache avoids repeated profile reads. It expires quickly so another
    Kodi interpreter can change keys without requiring a restart.
    """
    global _cache_value, _cache_time
    now = monotonic()
    if not force and _cache_value is not None and now - _cache_time < _CACHE_TTL:
        return _cache_value

    profile = _profile()
    stored = _encrypted_credentials(profile)
    if stored is None:
        # Non-destructive compatibility path for an old settings.xml. The
        # service imports these values into encrypted storage later.
        addon = Addon()
        stored = tuple(addon.getSetting(field).strip() for field in FIELDS)
    _cache_value = stored
    _cache_time = now
    return stored


def prepare():
    """Import plaintext legacy/user values into encrypted storage, never reset.

    2.0.92 performed the one-time reset. 2.0.93 only preserves/imports values
    that already exist and clears their plaintext copy after a successful save.
    """
    addon = Addon()
    pending = {field: addon.getSetting(field).strip() for field in FIELDS}
    pending = {field: value for field, value in pending.items() if value}
    profile = _profile()

    if not pending:
        return _read(profile)

    profile.mkdir(parents=True, exist_ok=True)
    with _locked(profile):
        data = _read(profile)
        keys = data.setdefault('keys', {})
        if not isinstance(keys, dict):
            raise ValueError('Invalid Trakt key storage')
        key = _master(profile, create=True)
        changed = False
        for field, value in pending.items():
            old_value = _decrypt(keys.get(field, ''), field, key) if keys.get(field) else ''
            if old_value != value:
                keys[field] = _encrypt(value, field, key)
                changed = True
        # A 2.0.92 pending notice must not be shown by 2.0.93, especially for
        # users upgrading directly from an older build where no reset occurs.
        if data.get('notice_pending'):
            data['notice_pending'] = False
            changed = True
        if changed:
            _save(profile, data)
        for field in pending:
            addon.setSetting(field, '')
            if addon.getSetting(field):
                raise OSError('Could not clear plaintext Trakt key after encrypted save')
    _invalidate_cache()
    return data


def migrate():
    """Backward-compatible name. It is non-destructive from 2.0.93 onward."""
    return prepare()


def set_key(field, value):
    if field not in FIELDS:
        raise ValueError('Unknown Trakt key')
    prepare()
    profile = _profile()
    profile.mkdir(parents=True, exist_ok=True)
    value = value.strip()
    changed = False
    with _locked(profile):
        data = _read(profile)
        keys = data.setdefault('keys', {})
        if not isinstance(keys, dict):
            raise ValueError('Invalid Trakt key storage')
        key = _master(profile, create=True)
        old_value = _decrypt(keys.get(field, ''), field, key) if keys.get(field) else ''
        if old_value != value:
            keys[field] = _encrypt(value, field, key)
            _save(profile, data)
            changed = True
        Addon().setSetting(field, '')

    _invalidate_cache()
    if changed:
        # OAuth tokens belong to the application key pair. Do not log the user
        # out when they re-enter exactly the same value.
        addon = Addon()
        for setting in ('trakt.token', 'trakt.internal'):
            addon.setSetting(setting, '')
    return changed


def show_migration_notice():
    """2.0.92-only reset notice; intentionally disabled from 2.0.93."""
    return None


def edit_key(field):
    from xbmcgui import Dialog, INPUT_ALPHANUM, ALPHANUM_HIDE_INPUT
    from ..kolang import L
    prepare()
    heading = L(30201, 'Trakt Client ID') if field == FIELDS[0] else L(30202, 'Trakt Client Secret')
    value = Dialog().input(heading, type=INPUT_ALPHANUM, option=ALPHANUM_HIDE_INPUT)
    if not value:  # Cancel must never erase an existing key.
        return
    set_key(field, value)
    Dialog().notification('Kadr+ - Trakt.tv', L(33202, 'Key saved securely.'))
