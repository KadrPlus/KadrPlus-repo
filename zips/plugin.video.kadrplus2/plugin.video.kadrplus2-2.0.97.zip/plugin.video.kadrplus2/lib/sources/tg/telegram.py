# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""
    Kadr+ 2.0 — Telegram source for the new FanFilm engine.

    Etap 4:
    - logowanie do konta Telegram przez MTProto/Telethon;
    - pobieranie listy grup/kanałów/dialogów z konta użytkownika;
    - wyszukiwanie plików wideo w tych dialogach;
    - odtwarzanie przez lokalny proxy HTTP z obsługą Range;
    - szybkie wyszukiwanie po koncie z twardym filtrem do własnych dialogów użytkownika;
    - skan plików wideo pod postem-plakatem/opisem dla filmów i seriali.

    Prywatność:
    - kod logowania i 2FA są wpisywane wyłącznie w Kodi;
    - sesja Telegrama jest zapisywana lokalnie w profilu dodatku.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import os
import re
import sys
import time
import uuid
import shutil
import threading
import queue
import struct
import unicodedata
import zlib
from html import unescape
from urllib.parse import quote, quote_plus, urlencode, urlparse

import requests

from ptw.debug import fflog, fflog_exc
from ptw.libraries import control, title_matcher
from lib.kolang import L

try:
    from lib import tg_asyncio_compat
except Exception:
    tg_asyncio_compat = None


# Vendored Telethon dependencies. Telethon is pure Python, but Kodi/Android
# usually does not provide it as script.module.telethon.
def _telegram_vendor_path():
    try:
        return os.path.join(control.addonPath, 'resources', 'lib', 'vendor', 'telegram')
    except Exception:
        return ''


_vp = _telegram_vendor_path()
if _vp and _vp not in sys.path:
    sys.path.insert(0, _vp)

# Telethon reports a routine idle-socket reconnect as a warning on stderr.
# Kodi classifies stderr as an add-on error even though Telethon reconnects and
# the search continues.  Actual login/search/stream failures are logged by the
# guarded Kadr+ calls below, so keep the transport's internal logger quiet.
_TG_TELETHON_LOGGER = logging.getLogger('kadrplus.telegram.telethon')
_TG_TELETHON_LOGGER.setLevel(logging.CRITICAL)

_TG_PROXY_SERVER = None
_TG_PROXY_PORT = None
_TG_PROXY_THREAD = None
_TG_PROXY_MAP = {}
_TG_RANGE_WORKERS = {}
_TG_LOOP_BY_THREAD = {}
_TG_WINDOWS_WORKER_LOCAL = threading.local()
_TG_SEARCH_LOCK = threading.Lock()
_TG_SEARCH_STATE_LOCK = threading.Lock()
_TG_ACTIVE_SEARCH = None
# Search-only metadata cache. It never stores media bytes or credentials.
# The key includes the saved session/filter signature, so a login/filter change
# cannot reuse another account's dialog list. A short TTL only avoids repeating
# the expensive iter_dialogs walk during consecutive source searches.
_TG_SEARCH_META_LOCK = threading.Lock()
_TG_TARGET_CACHE = {}
_TG_TARGET_CACHE_TTL = 300.0
_TG_MESSAGE_MISSING = object()

# Recent search-RPC latency profile.  It is process-local, short-lived and keyed
# by the same account/filter signature as the dialog cache.  The profile does
# not contain message text, chat names, media metadata or credentials; it only
# remembers a few elapsed times so a later search can avoid starting another
# expensive optional RPC when too little of the user's global budget remains.
_TG_SEARCH_LATENCY_LOCK = threading.Lock()
_TG_SEARCH_LATENCY = {}
_TG_SEARCH_LATENCY_TTL = 300.0
_TG_SEARCH_LATENCY_MAX_SAMPLES = 8

def _tg_latency_record(key, label, elapsed):
    try:
        if not key or not label:
            return
        elapsed = max(0.0, float(elapsed or 0.0))
        if elapsed <= 0.0:
            return
        now = time.monotonic()
        with _TG_SEARCH_LATENCY_LOCK:
            per_key = _TG_SEARCH_LATENCY.setdefault(key, {})
            samples = [
                (float(ts), float(value))
                for ts, value in (per_key.get(str(label)) or [])
                if now - float(ts) <= _TG_SEARCH_LATENCY_TTL
            ]
            samples.append((now, elapsed))
            per_key[str(label)] = samples[-_TG_SEARCH_LATENCY_MAX_SAMPLES:]
            # Bound stale account/filter signatures as well.
            if len(_TG_SEARCH_LATENCY) > 8:
                scored = []
                for cache_key, labels in _TG_SEARCH_LATENCY.items():
                    newest = max(
                        [float(ts) for vals in labels.values() for ts, _v in vals] or [0.0]
                    )
                    scored.append((newest, cache_key))
                for _ts, old_key in sorted(scored)[:-8]:
                    _TG_SEARCH_LATENCY.pop(old_key, None)
    except Exception:
        pass

def _tg_latency_predict(key, label):
    """Return a recent high-percentile elapsed time for one RPC class.

    Search latency is intentionally remembered only for five minutes.  Within
    that short window a single real 20-30 s MTProto stall must influence the
    next search immediately; otherwise the same title can hit the same global
    deadline twice in a row.  With at most eight samples nearest-rank p90 is
    effectively the recent peak, but the short TTL lets normal network speed
    recover quickly.
    """
    try:
        if not key or not label:
            return 0.0
        now = time.monotonic()
        with _TG_SEARCH_LATENCY_LOCK:
            per_key = _TG_SEARCH_LATENCY.get(key) or {}
            samples = [
                float(value)
                for ts, value in (per_key.get(str(label)) or [])
                if now - float(ts) <= _TG_SEARCH_LATENCY_TTL
            ]
        if not samples:
            return 0.0
        samples.sort()
        # Nearest-rank p90.  For our bounded <=8 sample window this keeps the
        # recent worst stall visible to the next search without persisting it.
        rank = max(1, int((9 * len(samples) + 9) // 10))
        return float(samples[min(len(samples) - 1, rank - 1)])
    except Exception:
        return 0.0

def _tg_clear_search_metadata_cache():
    """Invalidate search-only dialog metadata without touching Telegram session state."""
    try:
        with _TG_SEARCH_META_LOCK:
            _TG_TARGET_CACHE.clear()
    except Exception:
        pass
    try:
        with _TG_SEARCH_LATENCY_LOCK:
            _TG_SEARCH_LATENCY.clear()
    except Exception:
        pass

_TG_MIN_VISIBLE_MOVIE_SIZE = 200 * 1024 * 1024
_TG_MIN_VISIBLE_SERIES_SIZE = 100 * 1024 * 1024


def _tg_windows_worker_active():
    try:
        return bool(getattr(_TG_WINDOWS_WORKER_LOCAL, 'active', False))
    except Exception:
        return False


def _tg_run_windows_worker(callback, label='operation'):
    """Run a complete Telegram operation in a normal Python thread on Windows.

    Kodi may invoke plugin callbacks from a native CPythonInvoker/DummyThread.
    On Python 3.8/Windows that thread can reject event-loop registration and the
    default Proactor loop can raise ``set_wakeup_fd only works in main thread``.
    Keep the full Telethon client lifetime inside a normal child thread instead.
    Android/Linux never enter this path.
    """
    if not (tg_asyncio_compat and tg_asyncio_compat.is_windows()):
        return callback()
    if _tg_windows_worker_active():
        return callback()

    result_box = []
    error_box = []

    def runner():
        _TG_WINDOWS_WORKER_LOCAL.active = True
        try:
            tg_asyncio_compat.get_or_create_event_loop(
                _TG_LOOP_BY_THREAD,
                logger=lambda message: fflog(message, 1),
            )
            result_box.append(callback())
        except BaseException as exc:
            error_box.append(exc)
        finally:
            try:
                _TG_WINDOWS_WORKER_LOCAL.active = False
            except Exception:
                pass

    worker = threading.Thread(
        target=runner,
        name='KadrPlusTelegramWindows-%s' % str(label or 'operation'),
        daemon=True,
    )
    worker.start()
    worker.join()
    if error_box:
        raise error_box[0]
    return result_box[0] if result_box else None


def _token_tag(token):
    """Return a non-reversible correlation id instead of logging a stream token."""
    return hashlib.sha256(str(token).encode('utf-8')).hexdigest()[:8]


def _tg_cache_dir():
    try:
        folder = os.path.join(control.dataPath, 'telegram', 'stream_cache')
        try:
            control.makeDirs(folder)
        except Exception:
            if not os.path.exists(folder):
                os.makedirs(folder, exist_ok=True)
        return folder
    except Exception:
        try:
            folder = os.path.join(control.dataPath, 'telegram_stream_cache')
            os.makedirs(folder, exist_ok=True)
            return folder
        except Exception:
            return control.dataPath


def _tg_cache_size(spec):
    try:
        path = (spec or {}).get('cache_path') or ''
        if path and os.path.exists(path):
            return int(os.path.getsize(path) or 0)
    except Exception:
        pass
    try:
        return int((spec or {}).get('cache_pos') or 0)
    except Exception:
        return 0



def _tg_clear_stream_cache(max_age=0):
    """Remove old 2.41.24 progressive Telegram cache files.

    2.41.24 could start downloading multi-GB files in the background.  The new
    proxy no longer uses this cache, so it is safe to clean the addon-owned
    telegram/stream_cache folder.
    """
    try:
        cdir = _tg_cache_dir()
        if not cdir or not os.path.isdir(cdir):
            return 0
        now = time.time()
        removed = 0
        for name in os.listdir(cdir):
            path = os.path.join(cdir, name)
            try:
                if os.path.isfile(path) and (not max_age or now - os.path.getmtime(path) >= max_age):
                    os.remove(path)
                    removed += 1
            except Exception:
                pass
        if removed:
            fflog('[telegram-proxy] cleaned old stream_cache files=%s' % removed, 1)
        return removed
    except Exception:
        return 0



def _tg_temp_session_base(original_base):
    """Create a per-request copy of Telethon SQLite session.

    Kodi does HEAD/GET/range probes in parallel. Reusing the main .session
    file in every proxy request locks SQLite and playback ends with HTTP 503.
    A short-lived copy keeps the authorised auth key but avoids writing to the
    same database from multiple proxy threads.
    """
    try:
        folder = os.path.join(os.path.dirname(original_base), "proxy_sessions")
        if not os.path.exists(folder):
            os.makedirs(folder, exist_ok=True)
        tmp_base = os.path.join(folder, "tg_proxy_%s" % uuid.uuid4().hex)
        src = original_base + ".session"
        dst = tmp_base + ".session"
        if os.path.exists(src):
            shutil.copy2(src, dst)
            return tmp_base
    except Exception:
        fflog_exc(1)
    return original_base


def _tg_delete_session_copy(base):
    try:
        if not base:
            return
        folder = os.path.basename(os.path.dirname(base))
        if folder != "proxy_sessions":
            return
        for suffix in (".session", ".session-journal", ".session-wal", ".session-shm"):
            path = base + suffix
            try:
                if os.path.exists(path):
                    os.remove(path)
            except Exception:
                pass
    except Exception:
        pass


def _tg_safe_disconnect(client):
    """Disconnect Telethon without leaking CancelledError into Kodi threads."""
    loop = None
    disconnect_result = None
    try:
        if client:
            loop = getattr(client, 'loop', None)
            disconnect_result = client.disconnect()
            # Telethon's sync facade normally waits itself. In a Kodi worker it
            # can occasionally return an awaitable instead, leaving receive and
            # Queue.get tasks alive until Python destroys the interpreter.
            if (asyncio.iscoroutine(disconnect_result) or asyncio.isfuture(disconnect_result)) and loop and not loop.is_running():
                loop.run_until_complete(disconnect_result)
    except BaseException:
        # On Kodi/Android Telethon may raise asyncio.CancelledError during
        # disconnect. It is BaseException on Python 3.11, so except Exception
        # does not catch it and the HTTP request thread explodes in the log.
        pass
    finally:
        # If run_until_complete itself failed (for example because Kodi closed
        # the loop), explicitly close the coroutine.  Otherwise Python emits a
        # misleading "was never awaited" error during garbage collection.
        try:
            if asyncio.iscoroutine(disconnect_result):
                disconnect_result.close()
        except BaseException:
            pass
    try:
        # Give Telethon's cancellation callbacks one event-loop turn and drain
        # anything it left behind. Every Kadr+ worker owns its loop, so this does
        # not cancel tasks belonging to another source search.
        if loop and not loop.is_closed() and not loop.is_running():
            pending = [task for task in asyncio.all_tasks(loop) if not task.done()]
            for task in pending:
                task.cancel()
            if pending:
                loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
    except BaseException:
        pass
    try:
        if client:
            _tg_delete_session_copy(getattr(client, '_kadrplus_temp_session_base', ''))
    except Exception:
        pass
    # ``disconnect()`` normally closes Telethon's SQLite session.  If the
    # asyncio loop failed half-way through disconnecting (most notably in a
    # Kodi callback thread on Windows), make sure the database handle cannot
    # remain alive and block the next login attempt.
    try:
        session = getattr(client, 'session', None) if client else None
        if session:
            session.close()
    except BaseException:
        pass


def _tg_close_current_loop():
    """Close the search worker's private loop after Telethon disconnects.

    Kodi can keep provider threads alive between plugin invocations.  Leaving a
    stopped Telethon loop in that thread produced ``Task was destroyed but it
    is pending`` during the next scan and made the number of Telegram results
    depend on timing.  Stream proxy workers own separate loops and do not call
    this helper.
    """
    loop = _TG_LOOP_BY_THREAD.pop(threading.get_ident(), None)
    idle_coro = None
    try:
        if not loop or loop.is_closed() or loop.is_running():
            return
        pending = [task for task in asyncio.all_tasks(loop) if not task.done()]
        for task in pending:
            task.cancel()
        if pending:
            loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
        idle_coro = asyncio.sleep(0)
        loop.run_until_complete(idle_coro)
        try:
            policy = asyncio.get_event_loop_policy()
            if policy.get_event_loop() is loop:
                policy.set_event_loop(None)
        except Exception:
            pass
        loop.close()
    except BaseException:
        pass
    finally:
        # The failing Android trace ended here after loop shutdown and left the
        # freshly-created sleep coroutine unawaited. Closing it is safe both
        # before and after completion and keeps cleanup deterministic.
        try:
            if idle_coro is not None:
                idle_coro.close()
        except BaseException:
            pass


def _tg_claim_search(owner):
    """Serialize account searches and cooperatively replace an older scan."""
    global _TG_ACTIVE_SEARCH
    current = threading.current_thread()
    try:
        with _TG_SEARCH_STATE_LOCK:
            previous = _TG_ACTIVE_SEARCH
            if previous is not None:
                try:
                    _previous_owner, previous_thread = previous
                    if previous_thread is not current:
                        stop_event = getattr(previous_thread, 'stop_event', None)
                        if stop_event is not None:
                            stop_event.set()
                except Exception:
                    pass

        while True:
            try:
                if owner._cancelled():
                    return False
            except Exception:
                pass
            if _TG_SEARCH_LOCK.acquire(timeout=0.2):
                with _TG_SEARCH_STATE_LOCK:
                    _TG_ACTIVE_SEARCH = (owner, current)
                return True
    except BaseException:
        return False


def _tg_release_search(owner):
    global _TG_ACTIVE_SEARCH
    try:
        current = threading.current_thread()
        with _TG_SEARCH_STATE_LOCK:
            if _TG_ACTIVE_SEARCH == (owner, current):
                _TG_ACTIVE_SEARCH = None
    except Exception:
        pass
    try:
        _TG_SEARCH_LOCK.release()
    except RuntimeError:
        pass



def _tg_export_session_string(session_base):
    """Export authorised Telethon SQLite session to an in-memory StringSession.

    Proxy playback must not keep opening/copying the same .session database.
    Kodi fires HEAD/GET/Range requests in parallel and SQLite sessions were
    causing locks or broken reconnects on Android.  A StringSession contains
    the auth key/DC only and is safe to instantiate per proxy request.
    """
    try:
        if not session_base:
            return ''
        from telethon.sessions import SQLiteSession, StringSession
        sess = SQLiteSession(session_base)
        try:
            value = StringSession.save(sess)
        finally:
            try:
                sess.close()
            except Exception:
                pass
        return value or ''
    except Exception:
        fflog_exc(1)
        return ''


def _tg_proxy_cleanup(max_age=7200):
    try:
        now = time.time()
        for key, value in list(_TG_PROXY_MAP.items()):
            if now - float(value.get('created') or 0) > max_age:
                try:
                    value['cache_stop'] = True
                    ev = value.get('_cache_event')
                    if ev:
                        ev.set()
                    worker = value.get('_range_worker')
                    if worker:
                        worker.stop()
                except Exception:
                    pass
                _TG_RANGE_WORKERS.pop(key, None)
                _TG_PROXY_MAP.pop(key, None)
        # Clean orphaned per-request Telethon session copies.
        try:
            base_dir = ''
            for value in list(_TG_PROXY_MAP.values()):
                sp = value.get('session_path') or ''
                if sp:
                    base_dir = os.path.join(os.path.dirname(sp), 'proxy_sessions')
                    break
            if base_dir and os.path.isdir(base_dir):
                for name in os.listdir(base_dir):
                    path = os.path.join(base_dir, name)
                    try:
                        if os.path.isfile(path) and now - os.path.getmtime(path) > max_age:
                            os.remove(path)
                    except Exception:
                        pass
        except Exception:
            pass
        # Clean old progressive playback cache files.
        try:
            cdir = _tg_cache_dir()
            if cdir and os.path.isdir(cdir):
                files = []
                for name in os.listdir(cdir):
                    path = os.path.join(cdir, name)
                    try:
                        if os.path.isfile(path):
                            age = now - os.path.getmtime(path)
                            size = os.path.getsize(path)
                            if age > 24 * 3600:
                                os.remove(path)
                            else:
                                files.append((os.path.getmtime(path), size, path))
                    except Exception:
                        pass
                # Keep cache under ~8 GB when possible.
                total = sum(x[1] for x in files)
                for _mtime, size, path in sorted(files):
                    if total <= 8 * 1024 ** 3:
                        break
                    try:
                        os.remove(path)
                        total -= size
                    except Exception:
                        pass
        except Exception:
            pass
    except Exception:
        pass



def _tg_proxy_prefetch_start(spec, wait_seconds=8.0, min_ready=1536 * 1024, max_bytes=0):
    """Start progressive Telegram->disk cache before Kodi opens the URL.

    Kodi probes local HTTP URLs aggressively and times out when the proxy has to
    connect to Telegram, resolve the entity and fetch the first MTProto chunks
    inside the first GET.  This prefetch starts at resolve() time, so the proxy
    can feed Kodi from a growing local file immediately.
    """
    try:
        if not spec or spec.get('_cache_started'):
            return bool(spec and spec.get('cache_path'))
        total = int(spec.get('size') or 0)
        try:
            max_bytes = int(max_bytes or spec.get('progressive_cache_max') or 0)
            if max_bytes and total:
                max_bytes = max(1024 * 1024, min(max_bytes, total))
        except Exception:
            max_bytes = 0
        if total <= 0:
            return False
        folder = _tg_cache_dir()
        token = spec.get('token') or uuid.uuid4().hex
        name = _tg_ascii_filename(spec.get('filename') or 'video.mp4')
        path = os.path.join(folder, '%s_%s' % (token[:16], name))
        spec['cache_path'] = path
        spec['cache_pos'] = 0
        spec['cache_done'] = False
        spec['cache_error'] = ''
        spec['cache_stop'] = False
        spec['cache_last_read'] = time.time()
        spec['_cache_event'] = threading.Event()
        spec['_cache_lock'] = threading.RLock()
        spec['_cache_started'] = True

        def _worker():
            client = None
            try:
                # Fresh cache for this playback token.
                try:
                    if os.path.exists(path):
                        os.remove(path)
                except Exception:
                    pass
                client = _tg_proxy_client(spec)
                if not client:
                    spec['cache_error'] = 'client unavailable'
                    return
                entity = _tg_find_entity(client, int(spec.get('chat_id') or 0), spec.get('chat_ref') or '', spec)
                if not entity:
                    spec['cache_error'] = 'entity unavailable'
                    return
                msg = client.get_messages(entity, ids=int(spec.get('message_id') or 0))
                if not msg or not getattr(msg, 'media', None):
                    spec['cache_error'] = 'media unavailable'
                    return
                fflog('[telegram-proxy] prefetch start size=%s file=%r' % (total, os.path.basename(path)), 1)
                written = 0
                with open(path, 'ab') as fh:
                    for chunk in client.iter_download(msg.media, offset=0, request_size=1024 * 1024, chunk_size=256 * 1024, file_size=total or None):
                        if spec.get('cache_stop'):
                            break
                        if not chunk:
                            continue
                        with spec.get('_cache_lock') or threading.RLock():
                            fh.write(chunk)
                            written += len(chunk)
                            spec['cache_pos'] = written
                        try:
                            spec['_cache_event'].set()
                        except Exception:
                            pass
                        # Do not keep downloading a multi-GB file forever when
                        # Kodi failed to open or the user backed out. While Kodi
                        # is reading, _tg_proxy_send_from_cache refreshes this
                        # timestamp on every served chunk.
                        try:
                            last_read = float(spec.get('cache_last_read') or spec.get('created') or time.time())
                            if written >= 4 * 1024 * 1024 and time.time() - last_read > 75:
                                spec['cache_stop'] = True
                                fflog('[telegram-proxy] prefetch idle stop bytes=%s' % written, 1)
                                break
                        except Exception:
                            pass
                        if max_bytes and written >= max_bytes:
                            try:
                                fflog('[telegram-proxy] prefetch reached soft cap bytes=%s' % written, 1)
                            except Exception:
                                pass
                            break
                        if total and written >= total:
                            break
                spec['cache_done'] = True
                fflog('[telegram-proxy] prefetch done bytes=%s' % written, 1)
            except Exception as exc:
                spec['cache_error'] = repr(exc)
                fflog_exc(1)
            finally:
                try:
                    spec['cache_done'] = bool(spec.get('cache_done')) or bool(spec.get('cache_error'))
                    ev = spec.get('_cache_event')
                    if ev:
                        ev.set()
                except Exception:
                    pass
                _tg_safe_disconnect(client)

        t = threading.Thread(target=_worker, name='KadrPlusTGPrefetch', daemon=True)
        spec['_cache_thread'] = t
        t.start()

        # Give the worker a small head start, but do not block Kodi forever.
        started = time.time()
        while time.time() - started < float(wait_seconds or 0):
            if _tg_cache_size(spec) >= int(min_ready or 0):
                return True
            if spec.get('cache_error'):
                return False
            ev = spec.get('_cache_event')
            if ev:
                ev.wait(0.25)
                try:
                    ev.clear()
                except Exception:
                    pass
            else:
                time.sleep(0.25)
        return bool(_tg_cache_size(spec) > 0)
    except Exception:
        fflog_exc(1)
        return False


def _tg_proxy_send_from_cache(handler, spec, start, end, total, wait_for_more=False):
    """Serve bytes that are already present in the growing progressive cache.

    2.41.34: never send HTTP headers and then wait for the cache to catch up for
    many seconds. Kodi/libcurl treats that as a dead stream.  The caller should
    shrink Content-Range to the currently cached bytes, call this function, flush
    them, close the response and let Kodi request the next range.

    Returns the number of bytes actually written.
    """
    sent = 0
    try:
        path = (spec or {}).get('cache_path') or ''
        if not path:
            return 0
        pos = int(start or 0)
        end = int(end if end is not None else (total - 1))
        try:
            spec['cache_last_read'] = time.time()
        except Exception:
            pass
        last_progress = time.time()
        last_cached_seen = _tg_cache_size(spec)
        while pos <= end:
            cached = _tg_cache_size(spec)
            if cached > last_cached_seen:
                last_cached_seen = cached
                last_progress = time.time()
            if cached <= pos:
                if wait_for_more and not spec.get('cache_done') and not spec.get('cache_error'):
                    # Avoid orphaned HTTP threads when Telegram stalls. Kodi may
                    # reconnect/request again, but a stuck Python thread blocks
                    # shutdown and log upload on Android.
                    if time.time() - last_progress > 35:
                        try:
                            fflog('[telegram-proxy] cache wait timeout pos=%s cached=%s sent=%s' % (pos, cached, sent), 1)
                        except Exception:
                            pass
                        break
                    ev = spec.get('_cache_event')
                    if ev:
                        ev.wait(0.25)
                        try:
                            ev.clear()
                        except Exception:
                            pass
                    else:
                        time.sleep(0.1)
                    continue
                break
            to_read = min(256 * 1024, end - pos + 1, cached - pos)
            if to_read <= 0:
                break
            try:
                with open(path, 'rb') as fh:
                    fh.seek(pos)
                    data = fh.read(to_read)
            except Exception:
                data = b''
            if not data:
                break
            try:
                handler.wfile.write(data)
                try:
                    handler.wfile.flush()
                except Exception:
                    pass
                try:
                    spec['cache_last_read'] = time.time()
                except Exception:
                    pass
            except (BrokenPipeError, ConnectionResetError):
                return sent
            n = len(data)
            pos += n
            sent += n
        return sent
    except (BrokenPipeError, ConnectionResetError):
        return sent
    except Exception:
        fflog_exc(1)
        return sent

def _tg_ascii_filename(value, default='video.mp4'):
    """Return a latin-1/HTTP-header safe filename fallback.

    BaseHTTPRequestHandler encodes headers as latin-1. Telegram filenames often
    contain Polish/German characters; sending them raw breaks playback before
    Kodi can even read the first byte. Keep the real UTF-8 filename in
    filename*=..., but use a plain ASCII fallback in filename="...".
    """
    try:
        name = os.path.basename(str(value or default).replace('\\', '/')) or default
        name = unicodedata.normalize('NFKD', name).encode('ascii', 'ignore').decode('ascii')
        name = re.sub(r'[^A-Za-z0-9._ -]+', '_', name)
        name = re.sub(r'\s+', ' ', name).strip(' ._-') or default
        if '.' not in os.path.basename(name):
            name += '.mp4'
        return name[:160]
    except Exception:
        return default


def _tg_content_disposition(filename):
    try:
        original = os.path.basename(str(filename or 'video.mp4').replace('\\', '/')) or 'video.mp4'
        fallback = _tg_ascii_filename(original)
        # RFC 5987 keeps UTF-8 name available while the whole header stays ASCII.
        return "inline; filename=\"%s\"; filename*=UTF-8''%s" % (
            fallback.replace('"', ''), quote(original.encode('utf-8'))
        )
    except Exception:
        return 'inline; filename="video.mp4"'



def _tg_document_location_from_spec(spec):
    """Build a direct Telegram file location from metadata saved with source.

    This avoids get_messages()/get_entity() on every Kodi Range request.  Kodi
    opens several ranges in parallel during demuxing, and every extra MTProto
    lookup makes the first body bytes arrive too late on Android.
    """
    try:
        spec = spec or {}
        doc_id = int(spec.get('doc_id') or 0)
        doc_hash = int(spec.get('doc_access_hash') or 0)
        ref = spec.get('doc_file_reference') or ''
        if not (doc_id and doc_hash and ref):
            return None
        try:
            ref_bytes = base64.urlsafe_b64decode((str(ref) + '=' * (-len(str(ref)) % 4)).encode('ascii'))
        except Exception:
            ref_bytes = base64.b64decode(str(ref).encode('ascii'))
        from telethon.tl.types import InputDocumentFileLocation
        return InputDocumentFileLocation(doc_id, doc_hash, ref_bytes, '')
    except Exception:
        return None


def _tg_get_message_for_download(client, spec):
    """Fallback resolver used only when direct document location is missing/expired."""
    try:
        entity = _tg_find_entity(client, int((spec or {}).get('chat_id') or 0), (spec or {}).get('chat_ref') or '', spec)
        if not entity:
            return None
        msg = client.get_messages(entity, ids=int((spec or {}).get('message_id') or 0))
        if not msg or not getattr(msg, 'media', None):
            return None
        return msg
    except Exception:
        fflog_exc(1)
        return None


def _tg_download_target(client, spec, force_message=False):
    """Return (file_like, dc_id, msg) for Telethon.iter_download."""
    try:
        if not force_message:
            loc = _tg_document_location_from_spec(spec)
            if loc:
                try:
                    dc_id = int((spec or {}).get('doc_dc_id') or 0) or None
                except Exception:
                    dc_id = None
                return loc, dc_id, None
        msg = _tg_get_message_for_download(client, spec)
        if not msg:
            return None, None, None
        return getattr(msg, 'media', None), None, msg
    except Exception:
        fflog_exc(1)
        return None, None, None


def _tg_iter_download(client, spec, offset, total, request_size=256 * 1024, force_message=False):
    """Create a Telethon download iterator for an exact byte offset."""
    file_like, dc_id, _msg = _tg_download_target(client, spec, force_message=force_message)
    if not file_like:
        return None
    kwargs = {
        'offset': int(offset or 0),
        'request_size': int(request_size or 256 * 1024),
        'chunk_size': int(request_size or 256 * 1024),
    }
    try:
        if total:
            kwargs['file_size'] = int(total)
    except Exception:
        pass
    try:
        if dc_id:
            kwargs['dc_id'] = int(dc_id)
    except Exception:
        pass
    return client.iter_download(file_like, **kwargs)



def _tg_round_1024(value, up=False):
    try:
        value = int(value or 0)
        if up:
            return ((value + 1023) // 1024) * 1024
        return (value // 1024) * 1024
    except Exception:
        return 0


def _tg_file_part_sync(client, spec, offset, want, total=0, force_message=False, timeout=9.0):
    """Fetch one small Telegram byte part through raw upload.getFile.

    This deliberately avoids Telethon.iter_download for Kodi's first bytes.
    Telegram's file API is chunked: with the precise flag offset and limit must
    be 1 KiB aligned, limit <= 1 MiB and a request may not cross a 1 MiB block.
    We align down, fetch a legal part, then slice back to the exact HTTP range.
    """
    try:
        if not client:
            return b''
        total = int(total or (spec or {}).get('size') or 0)
        offset = int(max(0, offset or 0))
        want = int(max(1, want or 0))
        if total and offset >= total:
            return b''
        if total:
            want = min(want, max(0, total - offset))
        if want <= 0:
            return b''

        file_like, dc_id, _msg = _tg_download_target(client, spec, force_message=force_message)
        if not file_like:
            return b''

        from telethon import functions, types, utils, errors
        info = utils._get_file_info(file_like)
        location = info.location
        try:
            if getattr(info, 'dc_id', None):
                dc_id = int(info.dc_id)
        except Exception:
            pass

        aligned = _tg_round_1024(offset, up=False)
        skip = offset - aligned
        # Telegram requires a single upload.getFile request to stay inside a
        # 1 MiB block. Keep the first request small so Kodi receives body bytes
        # before libcurl's open timeout.
        block_end = ((aligned // (1024 * 1024)) + 1) * (1024 * 1024)
        max_limit = max(1024, block_end - aligned)
        if total:
            max_limit = min(max_limit, max(0, total - aligned))
        limit = min(256 * 1024, max_limit)
        limit = max(1024, min(limit, _tg_round_1024(skip + want, up=True)))
        limit = min(limit, max_limit)
        limit = _tg_round_1024(limit, up=False)
        if limit <= skip:
            return b''

        async def _call_one(use_dc):
            sender = client._sender
            exported = False
            try:
                if use_dc and int(getattr(client.session, 'dc_id', 0) or 0) != int(use_dc):
                    sender = await client._borrow_exported_sender(int(use_dc))
                    exported = True
                req = functions.upload.GetFileRequest(
                    location=location,
                    offset=int(aligned),
                    limit=int(limit),
                    precise=True,
                    cdn_supported=False,
                )
                result = await asyncio.wait_for(client._call(sender, req), timeout=float(timeout or 9.0))
                if isinstance(result, types.upload.FileCdnRedirect):
                    raise RuntimeError('unexpected CDN redirect')
                return bytes(getattr(result, 'bytes', b'') or b'')
            finally:
                try:
                    if exported and sender:
                        await client._return_exported_sender(sender)
                except Exception:
                    pass

        async def _work():
            try:
                return await _call_one(dc_id)
            except errors.FileMigrateError as exc:
                return await _call_one(int(getattr(exc, 'new_dc', 0) or 0))

        loop = _tg_ensure_event_loop()
        _tg_bind_event_loop(loop)
        raw = loop.run_until_complete(_work())
        if not raw:
            return b''
        return raw[skip:skip + want]
    except Exception as exc:
        try:
            fflog('[telegram-proxy] raw getFile failed offset=%s want=%s force_msg=%s err=%r' % (offset, want, force_message, exc), 1)
        except Exception:
            pass
        return b''


def _tg_fetch_part_retry(client, spec, offset, want, total=0, timeout=9.0):
    """Fetch a byte part, refreshing message/file_reference if direct document fails."""
    last = b''
    for force_message in (False, True):
        try:
            data = _tg_file_part_sync(client, spec, offset, want, total=total, force_message=force_message, timeout=timeout)
            if data:
                if force_message:
                    try:
                        fflog('[telegram-proxy] raw getFile OK via refreshed message offset=%s bytes=%s' % (offset, len(data)), 1)
                    except Exception:
                        pass
                return data
            last = data
        except Exception:
            fflog_exc(1)
    return last or b''


def _tg_fetch_range_retry(client, spec, offset, want, total=0, timeout=7.0, max_parts=16):
    """Fetch up to ``want`` bytes using Telegram upload.getFile chunks.

    upload.getFile may not cross a 1 MiB Telegram block. The older one-part
    code returned only the first legal slice, so requests such as bytes=1966080-
    yielded about 128 KiB and Kodi treated the stream as too short. This helper
    loops across Telegram block boundaries and returns one contiguous buffer.
    It is still bounded: no full-file download is attempted here.
    """
    out = []
    got = 0
    try:
        total = int(total or (spec or {}).get('size') or 0)
        pos = int(max(0, offset or 0))
        want = int(max(1, want or 0))
        if total:
            want = min(want, max(0, total - pos))
        if want <= 0:
            return b''
        parts = 0
        while got < want and parts < int(max_parts or 1):
            need = want - got
            # Ask for at most 1 MiB, but _tg_file_part_sync will shrink further
            # if the current offset is near a 1 MiB block boundary.
            ask = min(1024 * 1024, need)
            data = _tg_fetch_part_retry(client, spec, pos, ask, total=total, timeout=timeout)
            if not data:
                break
            out.append(data)
            n = len(data)
            got += n
            pos += n
            parts += 1
            if total and pos >= total:
                break
            if n <= 0:
                break
        return b''.join(out)
    except Exception:
        fflog_exc(1)
        try:
            return b''.join(out)
        except Exception:
            return b''


def _tg_parallel_prefix_to_cache(spec, path, total, prefix_bytes=2 * 1024 * 1024, chunk_size=512 * 1024, workers=2, deadline_seconds=18.0):
    """Download the first few MiB through a tiny FastTelethon-style fan-out.

    Telethon's own FAQ says file transfer is single-connection and not parallel.
    Kodi, however, needs the startup bytes quickly.  This helper uses 2-3 short
    lived MTProto clients from the exported StringSession to fetch consecutive
    upload.getFile blocks in parallel, then writes only contiguous bytes to the
    cache file.  It stops at a small prefix; the normal worker continues
    progressively afterwards.
    """
    try:
        spec = spec or {}
        total = int(total or spec.get('size') or 0)
        if total <= 0 or not path:
            return 0
        prefix_bytes = int(max(256 * 1024, min(prefix_bytes or 0, total, 8 * 1024 * 1024)))
        chunk_size = int(max(128 * 1024, min(chunk_size or 0, 1024 * 1024)))
        workers = int(max(1, min(workers or 1, 3)))
        offsets = list(range(0, prefix_bytes, chunk_size))
        if not offsets:
            return 0
        q = queue.Queue()
        for off in offsets:
            q.put(off)
        results = {}
        errors = []
        lock = threading.RLock()
        stop = threading.Event()
        deadline = time.time() + float(deadline_seconds or 0)

        def _fetcher(idx):
            client = None
            try:
                client = _tg_proxy_client(spec)
                if not client:
                    with lock:
                        errors.append('client unavailable')
                    return
                while not stop.is_set() and time.time() < deadline:
                    try:
                        off = q.get_nowait()
                    except queue.Empty:
                        return
                    want = min(chunk_size, max(0, total - off), max(0, prefix_bytes - off))
                    data = _tg_fetch_range_retry(client, spec, off, want, total=total, timeout=7.0, max_parts=8)
                    with lock:
                        results[off] = data or b''
                    ev = spec.get('_cache_event')
                    if ev:
                        ev.set()
            except Exception as exc:
                with lock:
                    errors.append(repr(exc))
                fflog_exc(1)
            finally:
                _tg_safe_disconnect(client)

        threads = [threading.Thread(target=_fetcher, args=(i,), name='KadrPlusTGPrefix%d' % i, daemon=True) for i in range(workers)]
        for t in threads:
            t.start()

        written = 0
        next_off = 0
        last_report = 0
        with open(path, 'ab') as fh:
            while next_off < prefix_bytes and time.time() < deadline and not stop.is_set():
                with lock:
                    have = results.pop(next_off, None) if next_off in results else None
                if have is None:
                    ev = spec.get('_cache_event')
                    if ev:
                        ev.wait(0.15)
                        try:
                            ev.clear()
                        except Exception:
                            pass
                    else:
                        time.sleep(0.05)
                    continue
                if not have:
                    # Cannot build a contiguous prefix past this point.
                    break
                fh.write(have)
                written += len(have)
                next_off += len(have)
                spec['cache_pos'] = written
                try:
                    fh.flush()
                except Exception:
                    pass
                ev = spec.get('_cache_event')
                if ev:
                    ev.set()
                if written - last_report >= 512 * 1024:
                    last_report = written
                    try:
                        fflog('[telegram-proxy] parallel prefix cached=%s/%s' % (written, prefix_bytes), 1)
                    except Exception:
                        pass
                if len(have) < chunk_size:
                    break
        stop.set()
        for t in threads:
            try:
                t.join(0.2)
            except Exception:
                pass
        if written:
            try:
                fflog('[telegram-proxy] parallel prefix done bytes=%s target=%s workers=%s errors=%s' % (written, prefix_bytes, workers, len(errors)), 1)
            except Exception:
                pass
        return written
    except Exception:
        fflog_exc(1)
        return 0






def _tg_proxy_raw_cache_start(spec, wait_seconds=64.0, min_ready=6 * 1024 * 1024, max_bytes=0):
    """Start one fast Telegram->disk progressive cache.

    2.41.37 architecture:
    - one Telethon client owns the download for this playback token;
    - it uses Telethon's direct downloader/iter_download so an exported DC sender
      is borrowed once and reused for all chunks;
    - no fsync on every 256 KiB chunk. On Android that made the buffer grow at
      only a few KB/s and Kodi timed out while waiting for the 0-4 MiB probe;
    - Kodi receives the URL only after enough startup bytes are ready for its
      first demuxer probes. This is buffering, not full pre-download.
    """
    try:
        if not spec or spec.get('_raw_cache_started'):
            return bool(spec and spec.get('cache_path'))
        total = int(spec.get('size') or 0)
        if total <= 0:
            return False
        try:
            max_bytes = int(max_bytes or spec.get('progressive_cache_max') or 0)
            if max_bytes and total:
                max_bytes = max(8 * 1024 * 1024, min(max_bytes, total))
        except Exception:
            max_bytes = 0
        folder = _tg_cache_dir()
        token = spec.get('token') or uuid.uuid4().hex
        name = _tg_ascii_filename(spec.get('filename') or 'video.mp4')
        path = os.path.join(folder, '%s_stream_%s' % (token[:16], name))
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass
        spec['cache_path'] = path
        spec['cache_pos'] = 0
        spec['cache_done'] = False
        spec['cache_error'] = ''
        spec['cache_stop'] = False
        spec['cache_last_read'] = time.time()
        spec['_cache_event'] = threading.Event()
        spec['_cache_lock'] = threading.RLock()
        spec['_raw_cache_started'] = True

        def _worker():
            client = None
            written = 0
            try:
                client = _tg_proxy_client(spec)
                if not client:
                    spec['cache_error'] = 'client unavailable'
                    return
                fflog('[telegram-proxy] fast cache start size=%s max=%s file=%r' % (total, max_bytes or 0, os.path.basename(path)), 1)

                # First build a small contiguous prefix using 2-3 bounded
                # getFile workers. This avoids the 70 s wait seen in the log
                # where a single iterator produced only ~1 MiB too late.
                try:
                    written = _tg_parallel_prefix_to_cache(spec, path, total, prefix_bytes=2 * 1024 * 1024, chunk_size=512 * 1024, workers=2, deadline_seconds=16.0)
                except Exception:
                    fflog_exc(1)
                    written = int(spec.get('cache_pos') or 0)

                # 2.41.38: do not use a long Telethon.iter_download iterator for
                # the startup cache. On Android/Kodi it could sit for tens of
                # seconds before giving enough data. Use bounded upload.getFile
                # calls instead: every request has its own short timeout, and the
                # worker can reconnect/resume at the exact written offset.
                last_flush = 0
                empty_rounds = 0
                with open(path, 'ab') as fh:
                    while not spec.get('cache_stop'):
                        if max_bytes and written >= max_bytes:
                            fflog('[telegram-proxy] fast cache soft cap bytes=%s' % written, 1)
                            break
                        if total and written >= total:
                            break
                        want = 512 * 1024
                        if max_bytes:
                            want = min(want, max(0, max_bytes - written))
                        if total:
                            want = min(want, max(0, total - written))
                        if want <= 0:
                            break
                        data = _tg_fetch_range_retry(client, spec, written, want, total=total, timeout=7.0, max_parts=4)
                        if not data:
                            empty_rounds += 1
                            if empty_rounds == 1:
                                # Recreate the MTProto connection once, but do
                                # not keep a dead downloader alive forever.
                                _tg_safe_disconnect(client)
                                client = _tg_proxy_client(spec)
                                if not client:
                                    spec['cache_error'] = 'client unavailable after reconnect'
                                    break
                                continue
                            if empty_rounds >= 3:
                                spec['cache_error'] = 'raw getFile returned no bytes at %s' % written
                                break
                            time.sleep(0.25)
                            continue
                        empty_rounds = 0
                        with spec.get('_cache_lock') or threading.RLock():
                            fh.write(data)
                            written += len(data)
                            spec['cache_pos'] = written
                            if written - last_flush >= 128 * 1024:
                                try:
                                    fh.flush()
                                except Exception:
                                    pass
                                last_flush = written
                        ev = spec.get('_cache_event')
                        if ev:
                            ev.set()
                        try:
                            last_read = float(spec.get('cache_last_read') or spec.get('created') or time.time())
                            # Stop quickly after failed opens, but keep going
                            # during playback where cache_last_read is refreshed.
                            if written >= max(2 * 1024 * 1024, int(min_ready or 0)) and time.time() - last_read > 45:
                                spec['cache_stop'] = True
                                fflog('[telegram-proxy] fast cache idle stop bytes=%s' % written, 1)
                                break
                        except Exception:
                            pass
                    try:
                        fh.flush()
                    except Exception:
                        pass
                spec['cache_done'] = bool(total and written >= total) or bool(max_bytes and written >= max_bytes) or bool(spec.get('cache_stop'))
                fflog('[telegram-proxy] fast cache done bytes=%s done=%s err=%r' % (written, spec.get('cache_done'), spec.get('cache_error') or ''), 1)
            except Exception as exc:
                spec['cache_error'] = repr(exc)
                fflog('[telegram-proxy] fast cache failed bytes=%s err=%r' % (written, exc), 1)
                fflog_exc(1)
            finally:
                try:
                    ev = spec.get('_cache_event')
                    if ev:
                        ev.set()
                except Exception:
                    pass
                _tg_safe_disconnect(client)

        t = threading.Thread(target=_worker, name='KadrPlusTGFastCache', daemon=True)
        spec['_cache_thread'] = t
        t.start()

        started = time.time()
        # Wait for a real demuxer startup buffer. Kodi's first opening pattern
        # in the failing logs was bytes=0-2097151 and bytes=1966080-4063231,
        # so 6 MiB is a practical minimum that avoids immediate live fallback.
        while time.time() - started < float(wait_seconds or 0):
            cached = _tg_cache_size(spec)
            if cached >= int(min_ready or 0):
                fflog('[telegram-proxy] fast cache ready cached=%s wait=%.2fs' % (cached, time.time() - started), 1)
                return True
            if spec.get('cache_error') and cached <= 0:
                fflog('[telegram-proxy] fast cache startup error=%r' % (spec.get('cache_error'),), 1)
                return False
            ev = spec.get('_cache_event')
            if ev:
                ev.wait(0.25)
                try:
                    ev.clear()
                except Exception:
                    pass
            else:
                time.sleep(0.25)
        cached = _tg_cache_size(spec)
        fflog('[telegram-proxy] fast cache wait timeout cached=%s min=%s' % (cached, int(min_ready or 0)), 1)
        # Do not block playItem for a minute. If we have at least a small
        # contiguous head, hand Kodi the URL and let the growing cache feed it.
        return bool(cached >= 256 * 1024)
    except Exception:
        fflog_exc(1)
        return False


def _tg_proxy_wait_cache(spec, pos, timeout=12.0):
    """Wait until the progressive cache contains byte position pos."""
    try:
        deadline = time.time() + float(timeout or 0)
        while time.time() < deadline:
            if _tg_cache_size(spec) > int(pos or 0):
                return True
            if spec.get('cache_done') or spec.get('cache_error'):
                return False
            ev = spec.get('_cache_event')
            if ev:
                ev.wait(0.25)
                try:
                    ev.clear()
                except Exception:
                    pass
            else:
                time.sleep(0.1)
        return _tg_cache_size(spec) > int(pos or 0)
    except Exception:
        return False

def _tg_proxy_stream_one_part_response(handler, spec, start, end, total, mime, filename, partial):
    """Serve one truthful Telegram byte part and close the HTTP response.

    Kodi/libcurl times out when we declare a multi-MB Content-Length and MTProto
    stalls before that whole window is delivered.  For Telegram playback we must
    be conservative: fetch one small getFile part first, then return a 206 whose
    Content-Range/Content-Length exactly match the bytes we actually have.  Kodi
    can then ask for the next byte range, while no proxy thread remains stuck
    waiting for the rest of a large declared response.
    """
    client = None
    try:
        total = int(total or (spec or {}).get('size') or 0)
        start = int(max(0, start or 0))
        end = int(end if end is not None else (total - 1 if total else start))
        if total and start >= total:
            handler.send_error(416, 'Requested Range Not Satisfiable')
            return False
        if end < start:
            end = start
        # Keep the first response deliberately small.  The previous 2 MB window
        # caused Kodi to wait for bytes that Telegram had not delivered yet.
        max_chunk = 1024 * 1024
        try:
            if total and start >= max(0, total - 16 * 1024 * 1024):
                # Tail probes are sparse but important for MP4/MKV indexes.
                max_chunk = 1024 * 1024
        except Exception:
            pass
        want = min(max_chunk, max(1, end - start + 1))
        client = _tg_proxy_client(spec)
        if not client:
            handler.send_error(502, 'Telegram client unavailable')
            return False
        data = _tg_fetch_range_retry(client, spec, start, want, total=total, timeout=7.0, max_parts=8)
        if not data:
            try:
                fflog('[telegram-proxy] one-part empty start=%s want=%s total=%s' % (start, want, total), 1)
            except Exception:
                pass
            handler.send_error(504, 'Telegram did not return bytes')
            return False
        real_end = start + len(data) - 1
        # Always be truthful and partial for Telegram.  Even for a non-Range GET,
        # returning the whole file size would make Kodi wait for a long MTProto
        # stream inside one HTTP response and block the UI on failure.
        _tg_proxy_write_headers(handler, 206, mime, filename, total, start, real_end, True)
        handler.wfile.write(data)
        try:
            handler.wfile.flush()
        except Exception:
            pass
        try:
            fflog('[telegram-proxy] one-part sent start=%s end=%s bytes=%s requested_end=%s' % (start, real_end, len(data), end), 1)
        except Exception:
            pass
        return True
    except (BrokenPipeError, ConnectionResetError):
        return True
    except Exception:
        fflog_exc(1)
        try:
            handler.send_error(502, 'Telegram one-part stream error')
        except Exception:
            pass
        return False
    finally:
        _tg_safe_disconnect(client)

def _tg_probe_edges(spec, head_bytes=256 * 1024, tail_bytes=0, timeout_each=10.0):
    """Warm tiny edge chunks only; this is not full-file downloading.

    Kodi's first HTTP open fails if the local proxy accepts the connection but
    waits too long before body bytes. A 256 KiB head probe lets the first
    response start immediately, while the rest keeps streaming on demand.
    """
    client = None
    try:
        total = int((spec or {}).get('size') or 0)
        if total <= 0:
            return False
        client = _tg_proxy_client(spec)
        if not client:
            return False
        head_target = int(max(64 * 1024, min(int(head_bytes or 0), 512 * 1024, total)))
        started = time.time()
        head = _tg_fetch_part_retry(client, spec, 0, head_target, total=total, timeout=timeout_each)
        if head:
            spec['edge_head'] = head
            spec['edge_head_len'] = len(head)
            fflog('[telegram-proxy] edge head ready bytes=%s dt=%.2fs' % (len(head), time.time() - started), 1)
        else:
            spec['edge_head_error'] = 'no bytes'
            fflog('[telegram-proxy] edge head failed dt=%.2fs' % (time.time() - started), 1)

        # Keep tail probing disabled by default. It can be enabled later if logs
        # show MP4 moov-tail is the only remaining issue. The worker can fetch
        # arbitrary tail ranges on demand with the same raw getFile primitive.
        if tail_bytes and total > 2 * 1024 * 1024:
            tail_start = max(0, total - int(tail_bytes))
            tail = _tg_fetch_part_retry(client, spec, tail_start, min(int(tail_bytes), total - tail_start), total=total, timeout=timeout_each)
            if tail:
                spec['edge_tail_start'] = tail_start
                spec['edge_tail'] = tail
                spec['edge_tail_len'] = len(tail)
                fflog('[telegram-proxy] edge tail ready start=%s bytes=%s' % (tail_start, len(tail)), 1)
        return bool(spec.get('edge_head'))
    except Exception:
        fflog_exc(1)
        return False
    finally:
        _tg_safe_disconnect(client)


def _tg_edge_slice(spec, start, end):
    try:
        start = int(start or 0)
        end = int(end if end is not None else start)
        if end < start:
            return b''
        head = (spec or {}).get('edge_head') or b''
        if head and start < len(head):
            return bytes(head[start:min(end + 1, len(head))])
        tail = (spec or {}).get('edge_tail') or b''
        tail_start = int((spec or {}).get('edge_tail_start') or 0)
        if tail and start >= tail_start and start < tail_start + len(tail):
            off = start - tail_start
            return bytes(tail[off:min(len(tail), off + (end - start + 1))])
    except Exception:
        pass
    return b''

def _tg_head_prefetch_start(spec, wait_seconds=7.0, min_ready=192 * 1024, max_bytes=3 * 1024 * 1024):
    """Warm only the beginning of the Telegram file for Kodi.

    Kodi's curl input times out if the first GET to 127.0.0.1 does not receive
    bytes quickly. 2.41.24 tried a full progressive cache and could download
    multi-GB files in the background. This function deliberately caches only a
    tiny head segment, then the proxy continues normal Range streaming.
    """
    try:
        if not spec or spec.get('_head_started'):
            return bool(spec and int(spec.get('head_cache_pos') or 0) > 0)
        total = int(spec.get('size') or 0)
        if total <= 0:
            return False
        token = spec.get('token') or uuid.uuid4().hex
        folder = _tg_cache_dir()
        path = os.path.join(folder, '%s.head' % token[:24])
        spec['head_cache_path'] = path
        spec['head_cache_pos'] = 0
        spec['head_cache_done'] = False
        spec['head_cache_error'] = ''
        spec['_head_event'] = threading.Event()
        spec['_head_lock'] = threading.RLock()
        spec['_head_started'] = True
        max_bytes = int(max(256 * 1024, min(int(max_bytes or 0), total, 8 * 1024 * 1024)))
        spec['head_cache_max'] = max_bytes

        def _worker():
            client = None
            written = 0
            try:
                try:
                    if os.path.exists(path):
                        os.remove(path)
                except Exception:
                    pass
                client = _tg_proxy_client(spec)
                if not client:
                    spec['head_cache_error'] = 'client unavailable'
                    return
                entity = _tg_find_entity(client, int(spec.get('chat_id') or 0), spec.get('chat_ref') or '', spec)
                if not entity:
                    spec['head_cache_error'] = 'entity unavailable'
                    return
                msg = client.get_messages(entity, ids=int(spec.get('message_id') or 0))
                if not msg or not getattr(msg, 'media', None):
                    spec['head_cache_error'] = 'media unavailable'
                    return
                fflog('[telegram-proxy] head prefetch start max=%s file=%r' % (max_bytes, spec.get('filename') or ''), 1)
                remaining = max_bytes
                with open(path, 'wb') as fh:
                    for chunk in client.iter_download(msg.media, offset=0, request_size=64 * 1024, chunk_size=64 * 1024, file_size=total or None):
                        if not chunk or remaining <= 0:
                            break
                        if len(chunk) > remaining:
                            chunk = chunk[:remaining]
                        fh.write(chunk)
                        written += len(chunk)
                        remaining -= len(chunk)
                        with spec.get('_head_lock') or threading.RLock():
                            spec['head_cache_pos'] = written
                        try:
                            spec['_head_event'].set()
                        except Exception:
                            pass
                        if written >= max_bytes:
                            break
                spec['head_cache_done'] = True
                fflog('[telegram-proxy] head prefetch done bytes=%s' % written, 1)
            except Exception as exc:
                spec['head_cache_error'] = repr(exc)
                fflog_exc(1)
            finally:
                try:
                    spec['head_cache_done'] = True
                    ev = spec.get('_head_event')
                    if ev:
                        ev.set()
                except Exception:
                    pass
                _tg_safe_disconnect(client)

        t = threading.Thread(target=_worker, name='KadrPlusTGHeadPrefetch', daemon=True)
        spec['_head_thread'] = t
        t.start()

        started = time.time()
        while time.time() - started < float(wait_seconds or 0):
            if int(spec.get('head_cache_pos') or 0) >= int(min_ready or 0):
                return True
            if spec.get('head_cache_error'):
                return False
            ev = spec.get('_head_event')
            if ev:
                ev.wait(0.20)
                try:
                    ev.clear()
                except Exception:
                    pass
            else:
                time.sleep(0.20)
        return int(spec.get('head_cache_pos') or 0) > 0
    except Exception:
        fflog_exc(1)
        return False


def _tg_proxy_write_headers(handler, status, mime, filename, total, start, end, partial):
    length = (int(end) - int(start) + 1) if total else 0
    handler.send_response(status)
    handler.send_header('Content-Type', mime or 'video/mp4')
    handler.send_header('Accept-Ranges', 'bytes')
    handler.send_header('Content-Disposition', _tg_content_disposition(filename or 'video.mp4'))
    # Help Kodi/libcurl keep a local HTTP stream open long enough for MTProto.
    handler.send_header('Cache-Control', 'no-cache')
    if total:
        if partial:
            handler.send_header('Content-Range', 'bytes %d-%d/%d' % (int(start), int(end), int(total)))
        handler.send_header('Content-Length', str(length))
    handler.send_header('Connection', 'close')
    handler.end_headers()
    try:
        handler.wfile.flush()
    except Exception:
        pass


def _tg_proxy_send_head_cache(handler, spec, start, end):
    """Write available cached head bytes for a requested range and return bytes sent."""
    try:
        path = (spec or {}).get('head_cache_path') or ''
        cached = int((spec or {}).get('head_cache_pos') or 0)
        if not path or not os.path.exists(path) or cached <= int(start or 0):
            return 0
        pos = int(start or 0)
        limit = min(int(end) + 1, cached)
        sent = 0
        with open(path, 'rb') as fh:
            fh.seek(pos)
            while pos < limit:
                data = fh.read(min(128 * 1024, limit - pos))
                if not data:
                    break
                handler.wfile.write(data)
                try:
                    handler.wfile.flush()
                except Exception:
                    pass
                pos += len(data)
                sent += len(data)
        return sent
    except (BrokenPipeError, ConnectionResetError):
        return max(1, int(locals().get('sent', 0)))
    except Exception:
        fflog_exc(1)
        return 0



def _tg_tail_prefetch_start(spec, wait_seconds=0.0, min_ready=0, max_bytes=8 * 1024 * 1024):
    """Warm the last bytes of the Telegram file for Kodi's MP4/MKV tail probe.

    Kodi/libcurl often opens a local HTTP file, reads the head, and then asks for
    a Range close to EOF to inspect the container index.  Telegram MTProto may
    take longer than Kodi's ~20 s read timeout to connect and seek to that
    position, so playback dies although the source is valid.  Keep only a small
    tail cache, not the whole movie.
    """
    try:
        if not spec or spec.get('_tail_started'):
            return bool(spec and spec.get('tail_cache_path'))
        total = int(spec.get('size') or 0)
        if total <= 0:
            return False
        max_bytes = int(max(256 * 1024, min(int(max_bytes or 0), total, 16 * 1024 * 1024)))
        # Telegram's getFile offsets are happiest on 4 KiB boundaries.
        tail_start = max(0, total - max_bytes)
        tail_start -= tail_start % 4096
        folder = _tg_cache_dir()
        token = spec.get('token') or uuid.uuid4().hex
        name = _tg_ascii_filename(spec.get('filename') or 'video.mp4')
        path = os.path.join(folder, '%s_tail_%s' % (token[:16], name))
        spec['tail_cache_path'] = path
        spec['tail_cache_start'] = tail_start
        spec['tail_cache_pos'] = 0
        spec['tail_cache_done'] = False
        spec['tail_cache_error'] = ''
        spec['_tail_event'] = threading.Event()
        spec['_tail_lock'] = threading.RLock()
        spec['_tail_started'] = True

        def _worker():
            client = None
            written = 0
            try:
                try:
                    if os.path.exists(path):
                        os.remove(path)
                except Exception:
                    pass
                client = _tg_proxy_client(spec)
                if not client:
                    spec['tail_cache_error'] = 'client unavailable'
                    return
                entity = _tg_find_entity(client, int(spec.get('chat_id') or 0), spec.get('chat_ref') or '', spec)
                if not entity:
                    spec['tail_cache_error'] = 'entity unavailable'
                    return
                msg = client.get_messages(entity, ids=int(spec.get('message_id') or 0))
                if not msg or not getattr(msg, 'media', None):
                    spec['tail_cache_error'] = 'media unavailable'
                    return
                fflog('[telegram-proxy] tail prefetch start offset=%s max=%s file=%r' % (tail_start, max_bytes, spec.get('filename') or ''), 1)
                remaining = total - tail_start
                with open(path, 'wb') as fh:
                    for chunk in client.iter_download(msg.media, offset=tail_start, request_size=512 * 1024, chunk_size=256 * 1024, file_size=total or None):
                        if not chunk or remaining <= 0:
                            break
                        if len(chunk) > remaining:
                            chunk = chunk[:remaining]
                        fh.write(chunk)
                        written += len(chunk)
                        remaining -= len(chunk)
                        with spec.get('_tail_lock') or threading.RLock():
                            spec['tail_cache_pos'] = written
                        ev = spec.get('_tail_event')
                        if ev:
                            ev.set()
                        if remaining <= 0:
                            break
                spec['tail_cache_done'] = True
                fflog('[telegram-proxy] tail prefetch done bytes=%s' % written, 1)
            except Exception as exc:
                spec['tail_cache_error'] = repr(exc)
                fflog_exc(1)
            finally:
                try:
                    spec['tail_cache_done'] = True
                    ev = spec.get('_tail_event')
                    if ev:
                        ev.set()
                except Exception:
                    pass
                _tg_safe_disconnect(client)

        t = threading.Thread(target=_worker, name='KadrPlusTGTailPrefetch', daemon=True)
        spec['_tail_thread'] = t
        t.start()

        started = time.time()
        while time.time() - started < float(wait_seconds or 0):
            if int(spec.get('tail_cache_pos') or 0) >= int(min_ready or 0):
                return True
            if spec.get('tail_cache_error'):
                return False
            ev = spec.get('_tail_event')
            if ev:
                ev.wait(0.20)
                try:
                    ev.clear()
                except Exception:
                    pass
            else:
                time.sleep(0.20)
        return int(spec.get('tail_cache_pos') or 0) > 0
    except Exception:
        fflog_exc(1)
        return False



def _tg_tail_cache_ready(spec, start, end, wait_seconds=0.0):
    """Return True only when the requested tail range is fully cached.

    This deliberately checks *before* sending HTTP headers.  If Kodi receives a
    206 response with a large Content-Length and the proxy then waits on MTProto,
    libcurl times out and Kodi can keep Python request threads alive.  For MP4
    open probes the tail range must be served immediately from disk or fail
    quickly and cleanly.
    """
    try:
        spec = spec or {}
        path = spec.get('tail_cache_path') or ''
        tail_start = int(spec.get('tail_cache_start') or 0)
        if not path or int(start or 0) < tail_start:
            return False
        need_until = int(end) - tail_start + 1
        deadline = time.time() + float(wait_seconds or 0)
        while int(spec.get('tail_cache_pos') or 0) < need_until and not spec.get('tail_cache_done'):
            if time.time() >= deadline:
                break
            ev = spec.get('_tail_event')
            if ev:
                ev.wait(0.10)
                try:
                    ev.clear()
                except Exception:
                    pass
            else:
                time.sleep(0.10)
        cached = int(spec.get('tail_cache_pos') or 0)
        return bool(path and os.path.exists(path) and cached >= need_until)
    except Exception:
        return False

def _tg_proxy_send_tail_cache(handler, spec, start, end, wait_seconds=10.0):
    """Write cached tail bytes for a requested range and return bytes sent."""
    try:
        path = (spec or {}).get('tail_cache_path') or ''
        tail_start = int((spec or {}).get('tail_cache_start') or 0)
        if not path or int(start or 0) < tail_start:
            return 0
        need_until = int(end) - tail_start + 1
        deadline = time.time() + float(wait_seconds or 0)
        while int((spec or {}).get('tail_cache_pos') or 0) < need_until and not (spec or {}).get('tail_cache_done'):
            if time.time() >= deadline:
                break
            ev = (spec or {}).get('_tail_event')
            if ev:
                ev.wait(0.20)
                try:
                    ev.clear()
                except Exception:
                    pass
            else:
                time.sleep(0.20)
        cached = int((spec or {}).get('tail_cache_pos') or 0)
        if not os.path.exists(path) or cached <= int(start or 0) - tail_start:
            return 0
        pos = int(start or 0)
        limit = min(int(end) + 1, tail_start + cached)
        sent = 0
        with open(path, 'rb') as fh:
            fh.seek(pos - tail_start)
            while pos < limit:
                data = fh.read(min(128 * 1024, limit - pos))
                if not data:
                    break
                handler.wfile.write(data)
                pos += len(data)
                sent += len(data)
        return sent
    except (BrokenPipeError, ConnectionResetError):
        return max(1, int(locals().get('sent', 0)))
    except Exception:
        fflog_exc(1)
        return 0



def _tg_edge_prefetch_sync(spec, head_bytes=512 * 1024, tail_bytes=8 * 1024 * 1024, timeout=16.0):
    """Synchronously warm head and tail caches before Kodi opens the URL.

    Previous builds started background Telethon threads. On Kodi/Android those
    threads can outlive the plugin invocation and block GUI operations when
    MTProto stalls.  This version uses one temporary Telethon client, downloads
    a small head segment and a tail segment that reaches EOF, then disconnects.
    The local HTTP proxy can then answer Kodi's startup range probes without
    opening extra Telegram connections.
    """
    client = None
    try:
        spec = spec or {}
        total = int(spec.get('size') or 0)
        if total <= 0:
            return False
        deadline = time.time() + float(timeout or 0)
        folder = _tg_cache_dir()
        token = spec.get('token') or uuid.uuid4().hex
        safe_name = _tg_ascii_filename(spec.get('filename') or 'video.mp4')

        head_bytes = int(max(128 * 1024, min(int(head_bytes or 0), total, 2 * 1024 * 1024)))
        tail_bytes = int(max(1024 * 1024, min(int(tail_bytes or 0), total, 16 * 1024 * 1024)))
        tail_start = max(0, total - tail_bytes)
        # Align down for Telegram getFile, but extend target length to EOF.
        tail_start -= tail_start % 4096
        tail_target = total - tail_start

        head_path = os.path.join(folder, '%s.head' % token[:24])
        tail_path = os.path.join(folder, '%s_tail_%s' % (token[:16], safe_name))
        for path in (head_path, tail_path):
            try:
                if os.path.exists(path):
                    os.remove(path)
            except Exception:
                pass

        spec['head_cache_path'] = head_path
        spec['head_cache_pos'] = 0
        spec['head_cache_done'] = False
        spec['head_cache_error'] = ''
        spec['_head_event'] = threading.Event()
        spec['_head_lock'] = threading.RLock()
        spec['_head_started'] = True
        spec['head_cache_max'] = head_bytes

        spec['tail_cache_path'] = tail_path
        spec['tail_cache_start'] = tail_start
        spec['tail_cache_pos'] = 0
        spec['tail_cache_done'] = False
        spec['tail_cache_error'] = ''
        spec['_tail_event'] = threading.Event()
        spec['_tail_lock'] = threading.RLock()
        spec['_tail_started'] = True

        client = _tg_proxy_client(spec)
        if not client:
            spec['head_cache_error'] = 'client unavailable'
            spec['tail_cache_error'] = 'client unavailable'
            return False
        entity = _tg_find_entity(client, int(spec.get('chat_id') or 0), spec.get('chat_ref') or '', spec)
        if not entity:
            spec['head_cache_error'] = 'entity unavailable'
            spec['tail_cache_error'] = 'entity unavailable'
            return False
        msg = client.get_messages(entity, ids=int(spec.get('message_id') or 0))
        if not msg or not getattr(msg, 'media', None):
            spec['head_cache_error'] = 'media unavailable'
            spec['tail_cache_error'] = 'media unavailable'
            return False

        def fetch_segment(label, path, offset, target, pos_key, done_key, event_key, error_key):
            written = 0
            try:
                fflog('[telegram-proxy] edge %s prefetch start offset=%s bytes=%s file=%r' % (label, offset, target, spec.get('filename') or ''), 1)
                with open(path, 'wb') as fh:
                    for chunk in client.iter_download(msg.media, offset=int(offset or 0), request_size=128 * 1024, chunk_size=64 * 1024, file_size=total or None):
                        if time.time() >= deadline:
                            spec[error_key] = 'timeout after %s bytes' % written
                            break
                        if not chunk:
                            continue
                        if written + len(chunk) > target:
                            chunk = chunk[:max(0, target - written)]
                        if not chunk:
                            break
                        fh.write(chunk)
                        written += len(chunk)
                        spec[pos_key] = written
                        ev = spec.get(event_key)
                        if ev:
                            ev.set()
                        if written >= target:
                            break
                spec[done_key] = True
                fflog('[telegram-proxy] edge %s prefetch done bytes=%s target=%s' % (label, written, target), 1)
            except Exception as exc:
                spec[error_key] = repr(exc)
                spec[done_key] = True
                fflog('[telegram-proxy] edge %s prefetch failed bytes=%s err=%r' % (label, written, exc), 1)
                fflog_exc(1)
            finally:
                ev = spec.get(event_key)
                if ev:
                    ev.set()
            return written

        head_written = fetch_segment('head', head_path, 0, head_bytes, 'head_cache_pos', 'head_cache_done', '_head_event', 'head_cache_error')
        tail_written = 0
        if time.time() < deadline:
            tail_written = fetch_segment('tail', tail_path, tail_start, tail_target, 'tail_cache_pos', 'tail_cache_done', '_tail_event', 'tail_cache_error')
        else:
            spec['tail_cache_error'] = 'timeout before tail'
            spec['tail_cache_done'] = True
        ok = bool(head_written > 0 and tail_written >= tail_target)
        fflog('[telegram-proxy] edge prefetch summary head=%s/%s tail=%s/%s ok=%s' % (head_written, head_bytes, tail_written, tail_target, ok), 1)
        return ok
    except Exception:
        fflog_exc(1)
        return False
    finally:
        try:
            spec['head_cache_done'] = True
            spec['tail_cache_done'] = True
            ev = spec.get('_head_event') if spec else None
            if ev:
                ev.set()
            ev = spec.get('_tail_event') if spec else None
            if ev:
                ev.set()
        except Exception:
            pass
        _tg_safe_disconnect(client)

def _tg_proxy_stream_direct_body(handler, spec, start, end, total):
    """Continue an already-open HTTP response with Telegram bytes.

    The source token stores the document file location, so this function can
    stream a requested range without resolving the chat/message for every Kodi
    read.  If Telegram says the file_reference is stale, we retry once through
    get_messages() and then continue streaming.
    """
    try:
        start = int(start or 0)
        end = int(end if end is not None else (int(total or 0) - 1))
        if total and start > end:
            return True
        pos = start
        remaining = (end - start + 1) if total else None
        sent_total = 0
        # First use direct InputDocumentFileLocation; fallback to message refresh.
        for attempt, force_message in enumerate((False, True, True), start=1):
            client = None
            try:
                client = _tg_proxy_client(spec)
                if not client:
                    return sent_total > 0
                iterator = _tg_iter_download(client, spec, pos, total, request_size=256 * 1024, force_message=force_message)
                if iterator is None:
                    return sent_total > 0
                fflog('[telegram-proxy] body stream range=%s-%s/%s attempt=%s mode=%s' % (
                    pos, end, total, attempt, 'msg' if force_message else 'doc'), 1)
                for chunk in iterator:
                    if not chunk:
                        continue
                    if remaining is not None:
                        if remaining <= 0:
                            break
                        if len(chunk) > remaining:
                            chunk = chunk[:remaining]
                    handler.wfile.write(chunk)
                    try:
                        handler.wfile.flush()
                    except Exception:
                        pass
                    n = len(chunk)
                    pos += n
                    sent_total += n
                    if remaining is not None:
                        remaining -= n
                        if remaining <= 0:
                            return True
                return True
            except (BrokenPipeError, ConnectionResetError):
                return True
            except Exception as exc:
                fflog('[telegram-proxy] body stream failed attempt=%s sent=%s err=%r' % (attempt, sent_total, exc), 1)
                if sent_total > 0:
                    fflog_exc(1)
                    return True
                time.sleep(0.25)
            finally:
                _tg_safe_disconnect(client)
        return sent_total > 0
    except Exception:
        fflog_exc(1)
        return False


def _tg_proxy_stream_range_response(handler, spec, start, end, total, mime, filename, partial):
    """Open Telegram first, get the first chunk, then send HTTP headers.

    Kodi/libcurl is much happier when a 206 response is followed immediately by
    body bytes.  Older builds sent headers first and then waited on MTProto; the
    result was timeout(28), failed demuxing, or a deliberate 503 for tail probes.
    """
    start = int(start or 0)
    end = int(end if end is not None else (int(total or 0) - 1))
    length = (end - start + 1) if total else 0
    remaining = length if total else None
    pos = start
    sent_total = 0
    last_exc = None
    for attempt, force_message in enumerate((False, True, True), start=1):
        client = None
        try:
            client = _tg_proxy_client(spec)
            if not client:
                last_exc = 'client unavailable'
                continue
            iterator = _tg_iter_download(client, spec, pos, total, request_size=256 * 1024, force_message=force_message)
            if iterator is None:
                last_exc = 'download target unavailable'
                continue
            fflog('[telegram-proxy] live response range=%s-%s/%s attempt=%s mode=%s file=%r' % (
                pos, end, total, attempt, 'msg' if force_message else 'doc', filename), 1)
            first = None
            for chunk in iterator:
                if chunk:
                    first = bytes(chunk)
                    break
            if not first:
                last_exc = 'empty first chunk'
                continue
            if remaining is not None and len(first) > remaining:
                first = first[:remaining]
            _tg_proxy_write_headers(handler, 206 if partial else 200, mime, filename, total, start, end, partial)
            handler.wfile.write(first)
            try:
                handler.wfile.flush()
            except Exception:
                pass
            n = len(first)
            pos += n
            sent_total += n
            if remaining is not None:
                remaining -= n
                if remaining <= 0:
                    return True
            for chunk in iterator:
                if not chunk:
                    continue
                data = bytes(chunk)
                if remaining is not None:
                    if remaining <= 0:
                        break
                    if len(data) > remaining:
                        data = data[:remaining]
                handler.wfile.write(data)
                try:
                    handler.wfile.flush()
                except Exception:
                    pass
                n = len(data)
                pos += n
                sent_total += n
                if remaining is not None:
                    remaining -= n
                    if remaining <= 0:
                        return True
            return True
        except (BrokenPipeError, ConnectionResetError):
            return True
        except Exception as exc:
            last_exc = exc
            fflog('[telegram-proxy] live response failed attempt=%s sent=%s err=%r' % (attempt, sent_total, exc), 1)
            if sent_total > 0:
                fflog_exc(1)
                return True
            time.sleep(0.25)
        finally:
            _tg_safe_disconnect(client)
    try:
        fflog('[telegram-proxy] live response cannot start range=%s-%s err=%r' % (start, end, last_exc), 1)
        handler.send_error(502, 'Telegram stream did not start')
    except Exception:
        pass
    return False


class _TGRangeWorker:
    """Persistent per-playback Telegram byte-window worker.

    Important: do not open a new Telethon client for every HTTP Range. Kodi may
    fire 2-4 requests while opening a single MP4. On Android this caused broken
    reconnects and long-lived Python threads. This worker owns one Telethon
    client and serves bounded Range jobs through small queues.
    """

    def __init__(self, spec):
        self.spec = spec or {}
        self.token = self.spec.get('token') or uuid.uuid4().hex
        self.jobs = queue.PriorityQueue()
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, name='KadrPlusTGRangeWorker', daemon=True)
        self.client = None
        self.started = False

    def start(self):
        if not self.started:
            self.started = True
            self.thread.start()
        return self

    def is_alive(self):
        try:
            return bool(self.thread and self.thread.is_alive() and not self.stop_event.is_set())
        except Exception:
            return False

    def stop(self):
        try:
            self.stop_event.set()
            self.jobs.put_nowait((999, time.time(), {'stop': True}))
        except Exception:
            pass

    def _priority(self, start, total):
        try:
            start = int(start or 0)
            total = int(total or 0)
            if total and start >= max(0, total - 32 * 1024 * 1024):
                return 0  # MP4/MKV tail probe
            if start < 4 * 1024 * 1024:
                return 1  # startup head probe
        except Exception:
            pass
        return 2

    def submit(self, start, end, total):
        job = {
            'id': uuid.uuid4().hex,
            'start': int(start or 0),
            'end': int(end if end is not None else max(0, int(total or 0) - 1)),
            'total': int(total or 0),
            'q': queue.Queue(maxsize=64),
            'cancel': threading.Event(),
        }
        self.jobs.put((self._priority(job['start'], job['total']), time.time(), job))
        return job

    def _put(self, job, item):
        try:
            q = job.get('q')
            cancel = job.get('cancel')
            while q and not (cancel and cancel.is_set()) and not self.stop_event.is_set():
                try:
                    q.put(item, timeout=0.5)
                    return True
                except queue.Full:
                    continue
        except Exception:
            pass
        return False

    def _ensure_client(self):
        try:
            if self.client:
                return self.client
            self.client = _tg_proxy_client(self.spec)
            return self.client
        except Exception:
            fflog_exc(1)
            self.client = None
            return None

    def _drop_client(self):
        try:
            _tg_safe_disconnect(self.client)
        except Exception:
            pass
        self.client = None

    def _run(self):
        try:
            fflog('[telegram-proxy] range worker start token=%s' % _token_tag(self.token), 1)
            while not self.stop_event.is_set():
                try:
                    _prio, _ts, job = self.jobs.get(timeout=90)
                except queue.Empty:
                    # Keep no idle MTProto connection forever.
                    self._drop_client()
                    continue
                if job.get('stop'):
                    break
                if job.get('cancel') and job['cancel'].is_set():
                    continue
                self._process(job)
        except Exception:
            fflog_exc(1)
        finally:
            self._drop_client()
            fflog('[telegram-proxy] range worker stop token=%s' % _token_tag(self.token), 1)

    def _process(self, job):
        start = int(job.get('start') or 0)
        end = int(job.get('end') or 0)
        total = int(job.get('total') or 0)
        pos = start
        sent = 0
        last_err = None
        try:
            fflog('[telegram-proxy] worker raw job start range=%s-%s/%s' % (start, end, total), 1)
            client = self._ensure_client()
            if not client:
                self._put(job, ('error', 'client unavailable'))
                return
            while pos <= end and not job['cancel'].is_set() and not self.stop_event.is_set():
                remaining = end - pos + 1
                # First byte should be small and fast. Later chunks can be larger,
                # but still bounded so a cancelled Kodi request does not pin a
                # Telethon download for minutes.
                want = 64 * 1024 if sent == 0 else min(256 * 1024, remaining)
                try:
                    data = _tg_fetch_part_retry(client, self.spec, pos, want, total=total, timeout=(8.0 if sent == 0 else 12.0))
                except Exception as exc:
                    last_err = exc
                    data = b''
                if not data:
                    if sent == 0:
                        # Reconnect once for the first chunk. Do not leave the
                        # worker blocked forever; Kodi must get either bytes or a
                        # quick HTTP error.
                        self._drop_client()
                        client = self._ensure_client()
                        if client:
                            try:
                                data = _tg_fetch_part_retry(client, self.spec, pos, want, total=total, timeout=8.0)
                            except Exception as exc:
                                last_err = exc
                                data = b''
                    if not data:
                        break
                if remaining and len(data) > remaining:
                    data = data[:remaining]
                if not self._put(job, ('data', data)):
                    break
                n = len(data)
                pos += n
                sent += n
            if sent > 0:
                self._put(job, ('done', sent))
                fflog('[telegram-proxy] worker raw job done range=%s-%s sent=%s' % (start, end, sent), 1)
            else:
                self._put(job, ('error', repr(last_err or 'empty first chunk')))
                fflog('[telegram-proxy] worker raw job empty range=%s-%s err=%r' % (start, end, last_err), 1)
        except Exception as exc:
            try:
                self._put(job, ('error', repr(exc)))
            except Exception:
                pass
            fflog_exc(1)

    def stream_response(self, handler, start, end, total, mime, filename, partial):
        job = self.submit(start, end, total)
        q = job.get('q')
        sent = 0
        try:
            first = None
            first_deadline = time.time() + 22.0
            while time.time() < first_deadline:
                try:
                    kind, payload = q.get(timeout=0.25)
                except queue.Empty:
                    continue
                if kind == 'data' and payload:
                    first = payload
                    break
                if kind == 'error':
                    raise RuntimeError(payload)
                if kind == 'done':
                    break
            if not first:
                job['cancel'].set()
                fflog('[telegram-proxy] worker no first byte range=%s-%s/%s' % (start, end, total), 1)
                try:
                    handler.send_error(502, 'Telegram stream did not start')
                except Exception:
                    pass
                return False
            _tg_proxy_write_headers(handler, 206 if partial else 200, mime, filename, total, start, end, partial)
            handler.wfile.write(first)
            sent += len(first)
            while True:
                try:
                    kind, payload = q.get(timeout=28.0)
                except queue.Empty:
                    fflog('[telegram-proxy] worker read timeout after sent=%s range=%s-%s' % (sent, start, end), 1)
                    return sent > 0
                if kind == 'data' and payload:
                    handler.wfile.write(payload)
                    sent += len(payload)
                    continue
                if kind == 'done':
                    return True
                if kind == 'error':
                    fflog('[telegram-proxy] worker stream error after sent=%s err=%r' % (sent, payload), 1)
                    return sent > 0
        except (BrokenPipeError, ConnectionResetError):
            try:
                job['cancel'].set()
            except Exception:
                pass
            return True
        except Exception as exc:
            try:
                job['cancel'].set()
            except Exception:
                pass
            fflog('[telegram-proxy] worker response failed range=%s-%s err=%r' % (start, end, exc), 1)
            try:
                handler.send_error(502, 'Telegram proxy worker error')
            except Exception:
                pass
            return False


def _tg_get_range_worker(spec):
    try:
        if not spec:
            return None
        token = spec.get('token') or ''
        worker = spec.get('_range_worker') or (_TG_RANGE_WORKERS.get(token) if token else None)
        if worker and worker.is_alive():
            return worker
        worker = _TGRangeWorker(spec).start()
        spec['_range_worker'] = worker
        if token:
            _TG_RANGE_WORKERS[token] = worker
        return worker
    except Exception:
        fflog_exc(1)
        return None

def _tg_proxy_start(preferred_port=0):
    global _TG_PROXY_SERVER, _TG_PROXY_PORT, _TG_PROXY_THREAD
    try:
        if _TG_PROXY_SERVER and _TG_PROXY_PORT:
            return _TG_PROXY_PORT

        import http.server
        import socketserver
        import threading

        class _TGThreadingServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
            daemon_threads = True
            allow_reuse_address = True

        class _TGProxyHandler(http.server.BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'
            server_version = 'KadrPlusTGProxy/1.0'

            def log_message(self, fmt, *args):
                try:
                    fflog('[telegram-proxy] ' + (fmt % args), 0)
                except Exception:
                    pass

            def do_HEAD(self):
                self._handle(head_only=True)

            def do_GET(self):
                self._handle(head_only=False)

            def _token_from_path(self):
                m = re.match(r'^/telegram/([A-Za-z0-9_-]{16,64})(?:/.*)?$', urlparse(self.path).path or '')
                return m.group(1) if m else ''

            def _range(self, total):
                try:
                    rng = self.headers.get('Range') or ''
                    m = re.match(r'bytes=(\d*)-(\d*)', rng)
                    if not m or not total:
                        return 0, max(0, int(total or 0) - 1), False
                    if m.group(1) == '' and m.group(2):
                        # suffix range: last N bytes
                        n = int(m.group(2))
                        start = max(0, total - n)
                        end = total - 1
                    else:
                        start = int(m.group(1) or 0)
                        end = int(m.group(2) or (total - 1))
                    start = max(0, min(start, total - 1))
                    end = max(start, min(end, total - 1))
                    return start, end, True
                except Exception:
                    return 0, max(0, int(total or 0) - 1), False

            def _bounded_range(self, total, start, end, partial):
                """Limit Kodi's open-ended byte ranges to streaming windows.

                Kodi commonly asks for ``Range: bytes=N-``. If the proxy answers
                with Content-Length from N to EOF, one HTTP request may try to
                stream 1.5 GB through one Telethon iterator and block the demuxer
                from issuing/finishing other important probes.  A real HTTP server
                can satisfy the request with a smaller 206 range; Kodi/libcurl will
                request the next window when it needs more.  This is buffering on
                demand, not full-file predownload.
                """
                try:
                    total = int(total or 0)
                    start = int(start or 0)
                    end = int(end if end is not None else max(0, total - 1))
                    if total <= 0:
                        return start, end, partial
                    raw = self.headers.get('Range') or ''
                    requested_start, requested_end = start, end
                    remaining_to_eof = max(0, total - start)
                    if start < 2 * 1024 * 1024:
                        window = 2 * 1024 * 1024
                    elif remaining_to_eof <= 24 * 1024 * 1024:
                        window = 8 * 1024 * 1024
                    else:
                        window = 4 * 1024 * 1024
                    if not partial:
                        partial = True
                    if end >= total - 1 and (end - start + 1) > window:
                        end = min(total - 1, start + window - 1)
                    if end != requested_end or partial != bool(raw):
                        try:
                            fflog('[telegram-proxy] bounded range raw=%r %s-%s -> %s-%s/%s' % (raw, requested_start, requested_end, start, end, total), 1)
                        except Exception:
                            pass
                    else:
                        try:
                            fflog('[telegram-proxy] range raw=%r %s-%s/%s' % (raw, start, end, total), 1)
                        except Exception:
                            pass
                    return start, end, partial
                except Exception:
                    return start, end, partial

            def _handle(self, head_only=False):
                token = self._token_from_path()
                spec = _TG_PROXY_MAP.get(token)
                if not spec:
                    self.send_error(404, 'Telegram proxy token not found')
                    return
                try:
                    self.connection.settimeout(24)
                except Exception:
                    pass

                if head_only:
                    try:
                        total = int(spec.get('size') or 0)
                        mime = spec.get('mime') or 'video/mp4'
                        filename = spec.get('filename') or 'video.mp4'
                        start, end, partial = self._range(total)
                        length = (end - start + 1) if total else 0
                        self.send_response(206 if partial else 200)
                        self.send_header('Content-Type', mime)
                        self.send_header('Accept-Ranges', 'bytes')
                        self.send_header('Content-Disposition', _tg_content_disposition(filename))
                        if total:
                            if partial:
                                self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, total))
                            self.send_header('Content-Length', str(length))
                        self.send_header('Connection', 'close')
                        self.end_headers()
                    except Exception:
                        fflog_exc(1)
                        try:
                            self.send_error(502, 'Telegram proxy head error')
                        except Exception:
                            pass
                    return

                # 2.41.26: warm only the first few MB and immediately feed Kodi.
                # The previous full-cache idea could download multi-GB files. Here
                # Content-Length still describes the requested range, but cached
                # head bytes are sent first, then the same HTTP response continues
                # with live MTProto Range streaming.
                try:
                    total0 = int(spec.get('size') or 0)
                    mime0 = spec.get('mime') or 'video/mp4'
                    filename0 = spec.get('filename') or 'video.mp4'
                    start0, end0, partial0 = self._range(total0)
                    start0, end0, partial0 = self._bounded_range(total0, start0, end0, partial0)
                    # Main path: all Kodi startup ranges read from the same growing
                    # progressive cache.  Kodi opens duplicate bytes=0- requests and
                    # another request around ~2 MB; serving all of them from one
                    # file avoids serial Telegram jobs and libcurl read timeouts.
                    cached_now = _tg_cache_size(spec)
                    if spec.get('cache_path'):
                        # 2.41.37: cache-only HTTP path. Do not spawn a new
                        # Telethon live stream from request threads. The previous
                        # live fallback was what kept Kodi busy after failed opens.
                        if cached_now <= start0:
                            _tg_proxy_wait_cache(spec, start0, timeout=24.0)
                            cached_now = _tg_cache_size(spec)
                        if cached_now > start0:
                            try:
                                fflog('[telegram-proxy] cache-only response range=%s-%s cached=%s' % (start0, end0, cached_now), 1)
                            except Exception:
                                pass
                            _tg_proxy_write_headers(self, 206, mime0, filename0, total0, start0, end0, True)
                            sent_cache = _tg_proxy_send_from_cache(self, spec, start0, end0, total0, wait_for_more=True)
                            try:
                                fflog('[telegram-proxy] cache-only sent=%s range=%s-%s cached=%s done=%s err=%r' % (sent_cache, start0, end0, _tg_cache_size(spec), spec.get('cache_done'), spec.get('cache_error') or ''))
                            except Exception:
                                pass
                            return
                        try:
                            fflog('[telegram-proxy] cache-only miss range=%s-%s cached=%s err=%r; using bounded raw response' % (start0, end0, cached_now, spec.get('cache_error') or ''), 1)
                        except Exception:
                            pass
                        _tg_proxy_stream_one_part_response(self, spec, start0, end0, total0, mime0, filename0, True)
                        return
                    cached0 = int(spec.get('head_cache_pos') or 0)
                    if spec.get('head_cache_path') and cached0 > start0:
                        _tg_proxy_write_headers(self, 206 if partial0 else 200, mime0, filename0, total0, start0, end0, partial0)
                        sent0 = _tg_proxy_send_head_cache(self, spec, start0, end0)
                        next_pos = start0 + int(sent0 or 0)
                        if total0 and next_pos <= end0:
                            _tg_proxy_stream_direct_body(self, spec, next_pos, end0, total0)
                        return

                    # Kodi often asks for a tail Range while opening MP4/MKV.
                    # Serve it from the small tail cache when possible; otherwise
                    # the first byte can arrive after Kodi's libcurl timeout.
                    tail_start0 = int(spec.get('tail_cache_start') or 0)
                    if spec.get('tail_cache_path') and total0 and start0 >= tail_start0:
                        if _tg_tail_cache_ready(spec, start0, end0, wait_seconds=0.05):
                            _tg_proxy_write_headers(self, 206 if partial0 else 200, mime0, filename0, total0, start0, end0, partial0)
                            _tg_proxy_send_tail_cache(self, spec, start0, end0, wait_seconds=0.0)
                            return
                        try:
                            fflog('[telegram-proxy] tail cache miss; streaming live range=%s-%s cached=%s start=%s err=%r' % (
                                start0, end0, int(spec.get('tail_cache_pos') or 0), tail_start0, spec.get('tail_cache_error') or ''), 1)
                        except Exception:
                            pass
                        # Nie zwracaj 503. To zabija demuxer Kodi. Przejdź do
                        # live Range i wyślij nagłówki dopiero po pierwszym chunku.
                except (BrokenPipeError, ConnectionResetError):
                    return
                except Exception:
                    fflog_exc(1)

                try:
                    total = int(spec.get('size') or 0)
                    mime = spec.get('mime') or 'video/mp4'
                    filename = spec.get('filename') or 'video.mp4'
                    start, end, partial = self._range(total)
                    start, end, partial = self._bounded_range(total, start, end, partial)
                    if head_only:
                        _tg_proxy_write_headers(self, 206 if partial else 200, mime, filename, total, start, end, partial)
                        return
                    edge = _tg_edge_slice(spec, start, end)
                    if edge:
                        try:
                            fflog('[telegram-proxy] edge cache hit start=%s bytes=%s' % (start, len(edge)), 1)
                        except Exception:
                            pass
                        _tg_proxy_write_headers(self, 206 if partial else 200, mime, filename, total, start, end, partial)
                        self.wfile.write(edge)
                        try:
                            self.wfile.flush()
                        except Exception:
                            pass
                        next_start = start + len(edge)
                        if next_start > end:
                            return
                        start = next_start
                    # 2.41.35: return only a truthful small 206 range.
                    # Do not keep a long response open waiting for Telegram to
                    # fill a 2 MB window; that is what froze Kodi/libcurl.
                    _tg_proxy_stream_one_part_response(self, spec, start, end, total, mime, filename, partial)
                except Exception:
                    fflog_exc(1)
                    try:
                        self.send_error(502, 'Telegram proxy upstream error')
                    except Exception:
                        pass

        preferred_port = int(preferred_port or 0)
        if preferred_port and not (1024 < preferred_port < 65536):
            preferred_port = 0
        try_ports = [preferred_port] if preferred_port else []
        try_ports += [0]
        last_exc = None
        for port in try_ports:
            try:
                srv = _TGThreadingServer(('127.0.0.1', port), _TGProxyHandler)
                _TG_PROXY_SERVER = srv
                _TG_PROXY_PORT = int(srv.server_address[1])
                _TG_PROXY_THREAD = threading.Thread(target=srv.serve_forever, name='KadrPlusTelegramProxy', daemon=True)
                _TG_PROXY_THREAD.start()
                fflog(f'[telegram-proxy] started on 127.0.0.1:{_TG_PROXY_PORT}', 1)
                return _TG_PROXY_PORT
            except Exception as exc:
                last_exc = exc
        if last_exc:
            fflog(f'[telegram-proxy] cannot start: {last_exc!r}', 1)
        return 0
    except Exception:
        fflog_exc(1)
        return 0


def _tg_bind_event_loop(loop):
    """Bind the selected Telegram loop to the current execution thread.

    Windows Telegram work has already been moved to a normal ``threading.Thread``
    before this is called, so no Kodi/DummyThread policy workaround is needed.
    """
    if loop is None or loop.is_closed():
        raise RuntimeError('Telegram event loop is unavailable')
    if tg_asyncio_compat is not None and tg_asyncio_compat.is_windows():
        return tg_asyncio_compat.bind_event_loop(loop)
    try:
        asyncio.set_event_loop(loop)
    except Exception:
        try:
            asyncio.get_event_loop_policy().set_event_loop(loop)
        except Exception:
            pass
    return loop


def _tg_new_client(TelegramClient, session, api_id, api_hash, loop, **kwargs):
    """Construct Telethon with the selected loop visible to Python 3.8.

    Windows uses the dedicated Telegram worker and its explicit Selector loop.
    Android/Linux keep the exact construction behaviour used by this Kadr+ build.
    """
    session_obj = session
    owns_session = False
    if isinstance(session, (str, os.PathLike)):
        from telethon.sessions import SQLiteSession
        session_obj = SQLiteSession(str(session))
        owns_session = True

    events_mod = getattr(asyncio, 'events', None)
    get_running = getattr(events_mod, '_get_running_loop', None)
    set_running = getattr(events_mod, '_set_running_loop', None)
    changed_running = False
    previous_running = None

    try:
        if tg_asyncio_compat is not None and tg_asyncio_compat.is_windows():
            with tg_asyncio_compat.construction_loop(loop):
                return TelegramClient(session_obj, int(api_id), api_hash, loop=loop, **kwargs)

        # Preserve Kadr+'s existing Android/Linux behaviour byte-for-byte in
        # semantics: bind the loop and temporarily publish it while Telethon
        # creates its asyncio.Lock/Queue objects.
        _tg_bind_event_loop(loop)
        if callable(get_running) and callable(set_running):
            try:
                previous_running = get_running()
                if previous_running is None:
                    set_running(loop)
                    changed_running = True
            except Exception:
                previous_running = None
                changed_running = False

        return TelegramClient(session_obj, int(api_id), api_hash, loop=loop, **kwargs)
    except BaseException:
        if owns_session:
            try:
                session_obj.close()
            except BaseException:
                pass
        raise
    finally:
        if changed_running and callable(set_running):
            try:
                set_running(previous_running)
            except Exception:
                pass


def _tg_ensure_event_loop():
    """Return a Telethon-safe asyncio loop in Kodi worker threads.

    Windows uses the explicit SelectorEventLoop owned by the dedicated Telegram
    thread. Android/Linux retain Kadr+'s established per-thread fallback path.
    """
    if tg_asyncio_compat is not None and tg_asyncio_compat.is_windows():
        return tg_asyncio_compat.get_or_create_event_loop(
            _TG_LOOP_BY_THREAD,
            logger=lambda message: fflog(message, 1),
        )

    tid = threading.get_ident()

    try:
        loop = _TG_LOOP_BY_THREAD.get(tid)
        if loop and not loop.is_closed():
            return loop
    except Exception:
        pass

    try:
        loop = asyncio.get_running_loop()
        if loop and not loop.is_closed():
            _TG_LOOP_BY_THREAD[tid] = loop
            return loop
    except Exception:
        pass

    try:
        loop = asyncio.get_event_loop()
        if loop and not loop.is_closed():
            _TG_LOOP_BY_THREAD[tid] = loop
            return loop
    except Exception as exc:
        try:
            fflog(f'[telegram] asyncio.get_event_loop failed, creating local loop: {exc!r}', 1)
        except Exception:
            pass

    try:
        loop = asyncio.new_event_loop()
    except Exception as exc:
        try:
            fflog(f'[telegram] asyncio.new_event_loop failed, using SelectorEventLoop: {exc!r}', 1)
        except Exception:
            pass
        try:
            loop = asyncio.SelectorEventLoop()
        except Exception:
            policy_cls = getattr(asyncio, 'DefaultEventLoopPolicy', None)
            if not policy_cls:
                raise
            asyncio.set_event_loop_policy(policy_cls())
            loop = asyncio.new_event_loop()

    _tg_bind_event_loop(loop)
    _TG_LOOP_BY_THREAD[tid] = loop
    return loop


def _tg_running_loop_for_telethon():
    """Small wrapper used to patch Telethon's helpers.get_running_loop.

    Telethon 1.x exposes client.loop as helpers.get_running_loop() and in Kodi
    request/proxy threads that function may ask Python's default policy for a
    loop before Kodi has registered one.  The symptom is playback ending with:
    "There is no current event loop in thread process_request_thread".
    Always return our per-thread loop instead.
    """
    return _tg_ensure_event_loop()


def _tg_patch_telethon_helpers():
    try:
        import telethon.helpers as helpers
        if not getattr(helpers.get_running_loop, '_kadrplus_patched', False):
            def _patched_get_running_loop():
                return _tg_running_loop_for_telethon()
            _patched_get_running_loop._kadrplus_patched = True
            helpers.get_running_loop = _patched_get_running_loop

        # Kodi/Android TV potrafi wyrzucić asyncio.CancelledError podczas
        # telethonowego przełączania DC (_switch_dc -> _disconnect). W normalnym
        # Pythonie Telethon to wycisza, ale na niektórych buildach Androida błąd
        # potrafi wyjść wyżej i przerwać login. Patch ograniczamy do helpera
        # cancelującego wewnętrzne taski Telethona.
        if not getattr(getattr(helpers, '_cancel', None), '_kadrplus_patched', False):
            _orig_cancel = helpers._cancel
            async def _patched_cancel(log, **tasks):
                try:
                    return await _orig_cancel(log, **tasks)
                except BaseException:
                    return None
            _patched_cancel._kadrplus_patched = True
            helpers._cancel = _patched_cancel
    except Exception:
        pass


def _tg_telethon_imports():
    try:
        from telethon.sync import TelegramClient
        from telethon import errors
        from telethon.tl.types import PeerChannel, PeerChat, PeerUser
        _tg_patch_telethon_helpers()
        return TelegramClient, errors, PeerChannel, PeerChat, PeerUser
    except Exception:
        return None, None, None, None, None


def _tg_proxy_client(spec):
    try:
        TelegramClient, _, _, _, _ = _tg_telethon_imports()
        if not TelegramClient:
            return None
        api_id = int(spec.get('api_id') or 0)
        api_hash = spec.get('api_hash') or ''
        if not (api_id and api_hash):
            return None
        loop = _tg_ensure_event_loop()
        _tg_patch_telethon_helpers()
        _tg_bind_event_loop(loop)

        session_string = spec.get('session_string') or ''
        if not session_string:
            session_path = spec.get('session_path') or ''
            session_string = _tg_export_session_string(session_path)
            if session_string:
                spec['session_string'] = session_string
        if session_string:
            from telethon.sessions import StringSession
            client = _tg_new_client(
                TelegramClient, StringSession(session_string), api_id, api_hash, loop,
                timeout=10, request_retries=0, connection_retries=2,
                retry_delay=0.5, auto_reconnect=True, receive_updates=False,
                flood_sleep_threshold=0, entity_cache_limit=128,
                base_logger=_TG_TELETHON_LOGGER,
            )
            try:
                setattr(client, '_kadrplus_temp_session_base', '')
            except Exception:
                pass
        else:
            # Awaryjny fallback tylko gdy nie da się wyeksportować sesji.
            session_path = spec.get('session_path') or ''
            if not session_path:
                return None
            client_session_path = _tg_temp_session_base(session_path)
            client = _tg_new_client(
                TelegramClient, client_session_path, api_id, api_hash, loop,
                timeout=10, request_retries=0, connection_retries=2,
                retry_delay=0.5, auto_reconnect=True, receive_updates=False,
                flood_sleep_threshold=0, entity_cache_limit=128,
                base_logger=_TG_TELETHON_LOGGER,
            )
            try:
                setattr(client, '_kadrplus_temp_session_base', client_session_path if client_session_path != session_path else '')
            except Exception:
                pass
        client.connect()
        if not client.is_user_authorized():
            _tg_safe_disconnect(client)
            return None
        return client
    except Exception:
        fflog_exc(1)
        return None


def _tg_find_entity(client, chat_id, chat_ref='', spec=None):
    try:
        # Fast path for playback: store peer type/access_hash in the source token,
        # so the proxy does not have to iterate hundreds of dialogs before every
        # Kodi Range/GET request.  That dialog scan was the main reason local TG
        # playback timed out before the first bytes arrived.
        try:
            spec = spec or {}
            peer_type = (spec.get('peer_type') or '').lower()
            access_hash = int(spec.get('access_hash') or 0)
            cid = int(chat_id or spec.get('chat_id') or 0)
            if cid:
                from telethon.tl.types import InputPeerChannel, InputPeerChat, PeerChannel, PeerChat
                if peer_type in ('channel', 'megagroup', 'broadcast') and access_hash:
                    return InputPeerChannel(cid, access_hash)
                if peer_type in ('chat', 'group'):
                    return InputPeerChat(cid)
                # If we do not know the peer type but have an access_hash, this
                # is almost always a channel/megagroup.
                if access_hash:
                    return InputPeerChannel(cid, access_hash)
        except Exception:
            pass
        if chat_ref:
            try:
                return client.get_entity(chat_ref)
            except Exception:
                pass
        # Slow fallback: search known dialogs.
        for d in client.iter_dialogs(limit=500):
            ent = getattr(d, 'entity', None)
            if ent and int(getattr(ent, 'id', 0) or 0) == int(chat_id or 0):
                return ent
    except Exception:
        fflog_exc(1)
    return None


class source:
    has_sort_order = True
    has_color_identify2 = True
    use_premium_color = False

    def __init__(self):
        # Startuj wcześnie: Telegram potrafi skanować wiele dialogów, więc
        # przy niskim priorytecie wyniki wracały dopiero po timeoutcie i były odrzucane.
        self.priority = 0
        # Osobna grupa źródeł [TG]; sources.py dołącza ją tylko gdy provider.telegram=true.
        self.language = ['pl', 'de', 'en']
        from lib.ff.bundled_credentials import telegram_credentials
        self.api_id, self.api_hash = telegram_credentials(
            control.setting('telegram.api_id'), control.setting('telegram.api_hash'))
        # QR-only login: no phone number is stored or required.
        # Production defaults: Telegram only searches the user's logged-in
        # account dialogs. Old public t.me/s and local proxy switches were
        # experimental and are intentionally hidden/disabled now.
        self.chats = []
        self.session_name = 'kadrplus_telegram'
        self.only_account = True
        self.public_web = False
        self.use_dialogs = True
        self.login_on_search = False
        self.qr_login = True
        # MTProto playback in current Kadr+ always requires the persistent
        # local Range service.  Exposing an off switch made it possible to put
        # Telegram into a configuration that cannot play at all.  Likewise a
        # hand-picked port only adds collision risk; port 0 lets the OS choose
        # a free localhost port.  Keep the old setting IDs only for migration/UI
        # compatibility, but production behaviour is intentionally fixed.
        self.proxy_stream = True
        self.proxy_port = 0
        self.diagnostics_enabled = self._setting_bool(
            control.setting('diagnostics.enabled'),
            default=False,
        )
        try:
            self.chat_filter_mode = int(control.setting('telegram.chat_filter_mode') or 0)
        except Exception:
            self.chat_filter_mode = 0
        self.chat_filter_mode = max(0, min(int(self.chat_filter_mode or 0), 2))
        # Cached per-instance map: {chat_id: {topic_id, ...}}.  A chat only
        # becomes topic-restricted when at least one topic was explicitly selected.
        self._selected_topic_map_cache = None
        def _int_setting(setting_id, default, low, high):
            try:
                value = int(control.setting(setting_id) or default)
            except Exception:
                value = int(default)
            return max(int(low), min(int(value), int(high)))

        self.search_limit = _int_setting('telegram.search_limit', 100, 5, 500)
        self.dialog_limit = _int_setting('telegram.dialog_limit', 500, 5, 1000)
        # Telegram uses the common Kadr+ source-search timeout. There is no
        # independent Telegram deadline in settings anymore. The parent engine
        # injects the real budget/deadline for each scan in lib/ff/sources.py.
        self.search_timeout = 100.0
        self.search_rpc_timeout = 8.0
        self._search_deadline = None
        self._chat_filter_data_cache = None
        self._chat_filter_data_signature = None
        self._search_message_cache = {}
        self._search_message_cache_hits = 0
        self._search_message_cache_misses = 0
        self._search_message_cache_rpcs = 0
        self._search_context_scanned = set()
        self._search_latency_key = None
        self._search_dynamic_reserve = 0.0
        # Thread-safe partial-result snapshot used only when the parent source
        # scheduler reaches its authoritative global deadline.  It contains
        # already validated Telegram result dictionaries, never live Telethon
        # objects.  The worker keeps running only long enough to let an in-flight
        # MTProto call return naturally; after the snapshot is consumed it is not
        # allowed to publish a second aggregate.
        self._kadr_snapshot_lock = threading.RLock()
        self._kadr_partial_snapshot = None
        self._kadr_timeout_snapshot_consumed = False
        self._kadr_snapshot_generation = 0
        self.min_size_mb = _int_setting('telegram.min_size_mb', 200, 0, 3000)
        self.min_size_series_mb = _int_setting('telegram.min_size_series_mb', 100, 0, 1500)
        self.min_file_size = int(self.min_size_mb) * 1024 * 1024
        self.min_series_file_size = int(self.min_size_series_mb) * 1024 * 1024

        # Ustawialne limity Telegrama. Domyślne wartości są kompromisem:
        # szybkie wyszukiwanie po koncie + mały fallback na grupy/tematy + skan plakatów.
        self.max_results = _int_setting('telegram.max_results', 200, 20, 500)
        self.max_per_chat = _int_setting('telegram.max_per_chat', 20, 5, 100)
        self.quick_budget_pct = _int_setting('telegram.quick_budget_pct', 50, 15, 80)
        self.topic_budget = _int_setting('telegram.topic_budget', 12, 0, 40)
        # Ile wiadomości sprawdzać wewnątrz tematu/forum oraz jak szeroko
        # sprawdzać posty-plakaty dla filmów. Więcej = dokładniej, ale wolniej.
        self.topic_scan_limit = _int_setting('telegram.topic_scan_limit', 80, 40, 160)
        self.dialog_fallback_budget = _int_setting('telegram.dialog_fallback_budget', 10, 0, 40)
        self.max_context_headers = _int_setting('telegram.context_headers', 32, 0, 100)
        self.context_budget = _int_setting('telegram.context_budget', 18, 0, 60)
        self.movie_context_files = _int_setting('telegram.movie_context_files', 3, 0, 10)
        self.series_context_files = _int_setting('telegram.series_context_files', 30, 0, 100)
        self.startup_buffer_mb = _int_setting('telegram.startup_buffer_mb', 4, 1, 16)
        self.strict_episode_match = self._setting_bool(control.setting('telegram.strict_episode_match'), default=False)
        # True only when the user backed out of the nested Telegram result list.
        # The source engine uses it to distinguish Cancel from a broken stream.
        self.selection_cancelled = False
        self.session = None
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'pl-PL,pl;q=0.9,de-DE;q=0.8,en-US;q=0.7,en;q=0.6',
        }

    def _diag(self, message):
        if not self.diagnostics_enabled:
            return
        try:
            # One master switch controls all Kadr+ diagnostics.  The helper
            # writes to kodi.log and strips queries, chat names, identifiers,
            # URLs and credentials before anything leaves this module.
            from lib.ff.diagnostics import log_event
            log_event('telegram', message)
        except Exception:
            pass

    def _refresh_search_budget(self):
        """Use the common Kadr+ source-search budget for Telegram.

        Telegram keeps the proven 2.0.94 search stages and never cancels an
        already-issued Telethon RPC just to satisfy an internal timer. The common
        source engine remains authoritative; this method only gives the staged
        search the same remaining budget so it does not invent a second clock.
        """
        try:
            parent = float(getattr(self, '_kadr_parent_timeout', 0.0) or 0.0)
        except Exception:
            parent = 0.0
        if parent <= 0.0:
            try:
                parent = float(control.setting('scrapers.timeout.1') or 100.0)
            except Exception:
                parent = 100.0
        configured = max(5.0, min(parent, 200.0))

        remaining = configured
        try:
            parent_deadline = float(getattr(self, '_kadr_parent_deadline_monotonic', 0.0) or 0.0)
            if parent_deadline > 0.0:
                remaining = max(0.0, min(configured, parent_deadline - time.monotonic()))
        except Exception:
            pass

        self.search_timeout = max(0.1, float(remaining))
        self.search_rpc_timeout = max(1.0, min(8.0, self.search_timeout / 10.0))
        # Wall-clock deadline is used by the legacy stage code below. It is
        # derived from monotonic remaining time, not from a second setting.
        self._search_deadline = time.time() + self.search_timeout

        # Soft-stop reserve: do not spend the last part of the *global* source
        # timeout starting another optional Telegram stage.  This is deliberately
        # derived from the user's common timeout instead of being a second
        # Telegram setting.  It leaves time for result sorting/history merge,
        # aggregate creation and a clean Telethon disconnect before the parent
        # scheduler reaches its authoritative deadline.
        #
        # 5% of the configured global timeout matched the real-device trace
        # (about 1.6 s of post-scan work at 100 s) with a conservative floor and
        # ceiling.  Examples: 30/60/100/120/180 s -> 4/4/5/6/8 s reserve.
        self._search_configured_timeout = configured
        self._search_finish_reserve = max(4.0, min(8.0, configured * 0.05))
        # Minimum useful window for beginning a *new* optional network stage.
        # It scales with the same global timeout and is not used to interrupt an
        # RPC that has already started.
        self._search_min_stage_window = max(2.0, min(5.0, configured * 0.04))
        self._diag(
            '[telegram] ustawienia wyszukiwania; parent_timeout=%.1fs remaining=%.1fs '
            'soft_reserve=%.1fs min_stage=%.1fs '
            'execution=legacy-2.0.94-global-budget search_limit=%s max_results=%s '
            'movie_min=%sMB series_min=%sMB' % (
                configured, self.search_timeout, self._search_finish_reserve,
                self._search_min_stage_window, self.search_limit, self.max_results,
                self.min_size_mb, self.min_size_series_mb,
            )
        )
        return self.search_timeout

    def _search_rpc_seconds(self, deadline=None, timeout=None):
        """Return a hard timeout that cannot cross the current search deadline."""
        try:
            value = float(timeout if timeout is not None else self.search_rpc_timeout)
        except Exception:
            value = 6.0
        value = max(0.05, value)
        limits = []
        for item in (deadline, getattr(self, '_search_deadline', None)):
            try:
                if item is not None:
                    limits.append(float(item) - time.time())
            except Exception:
                pass
        if limits:
            value = min(value, max(0.0, min(limits)))
        return max(0.0, value)

    def _search_run_coro(self, client, coro, *, deadline=None, timeout=None, label='rpc'):
        """Run one Telethon coroutine with a *real* asyncio.wait_for timeout.

        Telethon's ``TelegramClient(timeout=...)`` controls connection setup; it
        does not bound an already-issued API request.  Search runs synchronously
        in Kadr+'s provider worker, so execute the original coroutine on the
        client's own loop and cancel it if the request exceeds its stage/total
        budget.
        """
        seconds = self._search_rpc_seconds(deadline=deadline, timeout=timeout)
        if seconds <= 0.0 or self._cancelled():
            try:
                if hasattr(coro, 'close'):
                    coro.close()
            except Exception:
                pass
            raise asyncio.TimeoutError('Telegram search deadline reached')
        loop = getattr(client, 'loop', None) or _tg_ensure_event_loop()
        _tg_bind_event_loop(loop)
        if loop.is_running():
            # Search provider code is intentionally synchronous and must never
            # enter this branch.  Failing explicitly is safer than starting a
            # second event loop around an already-running Telethon client.
            try:
                if hasattr(coro, 'close'):
                    coro.close()
            except Exception:
                pass
            raise RuntimeError('Telegram search loop is already running')
        try:
            return loop.run_until_complete(asyncio.wait_for(coro, timeout=seconds))
        except asyncio.TimeoutError:
            self._diag('[telegram] RPC timeout label=%s limit=%.2fs' % (label, seconds))
            raise

    def _search_call_method(self, client, method_name, *args, deadline=None, timeout=None, label=None, **kwargs):
        """Call a syncified Telethon coroutine method under hard timeout."""
        method = getattr(client, method_name)
        raw = getattr(method, '__tl.sync', None) or getattr(method, '__wrapped__', None)
        if raw is None:
            # Do not call an unbounded synchronous method from source search.
            raise RuntimeError('Telegram method %s is not timeout-capable' % method_name)
        coro = raw(client, *args, **kwargs)
        return self._search_run_coro(
            client, coro, deadline=deadline, timeout=timeout,
            label=label or method_name,
        )

    def _search_request(self, client, request, *, deadline=None, timeout=None, label='request'):
        method = getattr(client, '__call__')
        raw = getattr(method, '__tl.sync', None) or getattr(method, '__wrapped__', None)
        if raw is None:
            raise RuntimeError('Telegram __call__ is not timeout-capable')
        coro = raw(client, request)
        return self._search_run_coro(client, coro, deadline=deadline, timeout=timeout, label=label)

    def _search_iter(self, iterator, client, *, deadline=None, timeout=None, label='iter'):
        """Yield RequestIter items while bounding every network-producing step."""
        try:
            iterator = iterator.__aiter__()
        except Exception:
            pass
        while not self._cancelled():
            seconds = self._search_rpc_seconds(deadline=deadline, timeout=timeout)
            if seconds <= 0.0:
                break
            try:
                item = self._search_run_coro(
                    client, iterator.__anext__(), deadline=deadline,
                    timeout=seconds, label=label,
                )
            except StopAsyncIteration:
                break
            except asyncio.TimeoutError:
                # A timed-out fallback is optional.  Preserve results already
                # collected and let the next stage/query use the remaining budget.
                break
            yield item

    def _search_iter_messages(self, client, *args, deadline=None, timeout=None, label='iter_messages', **kwargs):
        return self._search_iter(
            client.iter_messages(*args, **kwargs), client,
            deadline=deadline, timeout=timeout, label=label,
        )

    def _search_iter_dialogs(self, client, *args, deadline=None, timeout=None, label='iter_dialogs', **kwargs):
        return self._search_iter(
            client.iter_dialogs(*args, **kwargs), client,
            deadline=deadline, timeout=timeout, label=label,
        )

    def _search_get_messages(self, client, *args, deadline=None, timeout=None, **kwargs):
        try:
            return self._search_call_method(
                client, 'get_messages', *args, deadline=deadline, timeout=timeout,
                label='get_messages', **kwargs,
            )
        except asyncio.TimeoutError:
            return []

    def _search_get_entity(self, client, entity, *, deadline=None, timeout=None):
        try:
            return self._search_call_method(
                client, 'get_entity', entity, deadline=deadline, timeout=timeout,
                label='get_entity',
            )
        except asyncio.TimeoutError:
            return None

    def _search_disconnect(self, client, timeout=1.25):
        """Disconnect a search client without letting cleanup overrun the parent."""
        if not client:
            return
        loop = getattr(client, 'loop', None)
        try:
            raw_disconnect = getattr(client, '_disconnect_coro', None)
            if raw_disconnect is not None and loop and not loop.is_running():
                _tg_bind_event_loop(loop)
                loop.run_until_complete(asyncio.wait_for(
                    raw_disconnect(), timeout=max(0.1, float(timeout or 1.25))
                ))
            else:
                _tg_safe_disconnect(client)
                return
        except BaseException:
            pass
        # Mirror the important tail of _tg_safe_disconnect without another
        # potentially unbounded syncified disconnect call.
        try:
            if loop and not loop.is_closed() and not loop.is_running():
                pending = [task for task in asyncio.all_tasks(loop) if not task.done()]
                for task in pending:
                    task.cancel()
                if pending:
                    loop.run_until_complete(asyncio.wait_for(
                        asyncio.gather(*pending, return_exceptions=True), timeout=0.5
                    ))
        except BaseException:
            pass
        try:
            session = getattr(client, 'session', None)
            if session:
                session.close()
        except BaseException:
            pass
        try:
            _tg_delete_session_copy(getattr(client, '_kadrplus_temp_session_base', ''))
        except Exception:
            pass

    def _cancelled(self):
        """Return True when the FanFilm source window requested cancellation."""
        try:
            thread = threading.current_thread()
            stop_event = getattr(thread, 'stop_event', None)
            thread_stopped = bool(stop_event and stop_event.is_set())
            return bool(getattr(self, 'canceled', False) or thread_stopped)
        except Exception:
            return False

    def _is_api_id_invalid(self, exc, errors=None):
        try:
            api_err = getattr(errors, 'ApiIdInvalidError', None) if errors else None
            if api_err and isinstance(exc, api_err):
                return True
        except Exception:
            pass
        name = exc.__class__.__name__
        text = str(exc)
        return name == 'ApiIdInvalidError' or 'API_ID_INVALID' in text or 'api_id/api_hash combination is invalid' in text

    def _show_api_id_invalid(self):
        try:
            control.infoDialog(L(33005, 'Telegram rejected the application API credentials. Update the add-on or restore valid settings.'), heading='Telegram', icon='WARNING', time=9000, sound=False)
        except Exception:
            pass

    def _client_dc_id(self, client):
        try:
            return int(getattr(getattr(client, 'session', None), 'dc_id', 0) or 0)
        except Exception:
            return 0

    def _is_dc_migration_error(self, exc):
        try:
            name = exc.__class__.__name__
            text = str(exc)
        except Exception:
            name, text = '', ''
        markers = (
            'PhoneMigrateError', 'NetworkMigrateError', 'UserMigrateError', 'FileMigrateError',
            'PHONE_MIGRATE', 'NETWORK_MIGRATE', 'USER_MIGRATE', 'FILE_MIGRATE',
            'associated with DC', '_switch_dc', 'new data center'
        )
        return any(m in name or m in text for m in markers)

    def _is_dc_switch_interrupt(self, exc):
        try:
            if isinstance(exc, asyncio.CancelledError):
                return True
        except Exception:
            pass
        return self._is_dc_migration_error(exc)

    def _new_login_client(self, session_path, api_id, api_hash, loop):
        try:
            TelegramClient, _, _, _, _ = _tg_telethon_imports()
            if not TelegramClient:
                return None
            _tg_patch_telethon_helpers()
            _tg_bind_event_loop(loop)
            client = _tg_new_client(
                TelegramClient, session_path, int(api_id), api_hash, loop,
                base_logger=_TG_TELETHON_LOGGER,
            )
            client.connect()
            return client
        except BaseException:
            fflog_exc(1)
            return None

    def _recover_client_after_dc_switch(self, client, session_path, api_id, api_hash, loop, before_dc=0, reason='login'):
        try:
            after_dc = self._client_dc_id(client)
            if not after_dc or (before_dc and after_dc == before_dc):
                return None
            try:
                fflog('[telegram] %s: DC migration detected %s -> %s, recreating client' % (reason, before_dc or '?', after_dc), 1)
            except Exception:
                pass
            try:
                control.infoDialog(L(33006, 'Telegram: switching login to data center {dc} and trying again').format(dc=after_dc), heading='Telegram', time=4500, sound=False)
            except Exception:
                pass
            _tg_safe_disconnect(client)
            try:
                time.sleep(0.35)
            except Exception:
                pass
            return self._new_login_client(session_path, api_id, api_hash, loop)
        except BaseException:
            fflog_exc(1)
            return None

    def _qr_login_with_dc_retry(self, client, session_path, api_id, api_hash, loop, errors=None):
        before_dc = self._client_dc_id(client)
        try:
            self._last_qr_dc_migrated = False
            ok = self._qr_login(client, errors)
            if ok:
                return client, True
            if not getattr(self, '_last_qr_dc_migrated', False):
                return client, False
            new_client = self._recover_client_after_dc_switch(client, session_path, api_id, api_hash, loop, before_dc, 'qr_login')
            if not new_client:
                return client, False
            self._last_qr_dc_migrated = False
            ok = self._qr_login(new_client, errors)
            return new_client, bool(ok)
        except BaseException as exc:
            if self._is_api_id_invalid(exc, errors):
                self._show_api_id_invalid()
                return client, False
            if self._is_dc_switch_interrupt(exc):
                new_client = self._recover_client_after_dc_switch(client, session_path, api_id, api_hash, loop, before_dc, 'qr_login')
                if new_client:
                    try:
                        ok = self._qr_login(new_client, errors)
                        return new_client, bool(ok)
                    except BaseException:
                        fflog_exc(1)
                        return new_client, False
            fflog_exc(1)
            return client, False

    # ------------------------------------------------------------------ #
    # Kadr+/FanFilm interface                                             #
    # ------------------------------------------------------------------ #

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        if not self._configured():
            return None
        return self._pack({
            'kind': 'movie',
            'imdb': imdb or '',
            'title': title or localtitle,
            'localtitle': localtitle,
            'aliases': aliases or [],
            'year': year,
        })

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        if not self._configured():
            return None
        return self._pack({
            'kind': 'series',
            'imdb': imdb or '',
            'tvdb': tvdb or '',
            'title': tvshowtitle or localtvshowtitle,
            'localtitle': localtvshowtitle,
            'aliases': aliases or [],
            'year': year,
        })

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        if not url:
            return None
        try:
            data = self._unpack(url)
            data['season'] = int(season or 1)
            data['episode'] = int(float(episode or 1))
            data['episode_title'] = title or ''
            return self._pack(data)
        except Exception:
            fflog_exc(1)
            return None

    def _reset_timeout_snapshot(self, data=None):
        try:
            lock = getattr(self, '_kadr_snapshot_lock', None)
            if lock is None:
                lock = threading.RLock()
                self._kadr_snapshot_lock = lock
            with lock:
                self._kadr_snapshot_generation = int(getattr(self, '_kadr_snapshot_generation', 0) or 0) + 1
                self._kadr_partial_snapshot = {
                    'generation': self._kadr_snapshot_generation,
                    'items': [],
                    'data': dict(data or {}),
                    'stage': 'start',
                    'saved': time.monotonic(),
                }
                self._kadr_timeout_snapshot_consumed = False
                self._kadr_partial_ready = False
        except Exception:
            pass

    def _publish_timeout_snapshot(self, items, data=None, stage=''):
        """Publish a copy of already validated hits for the parent deadline.

        This method performs no network or disk I/O.  It deliberately stores
        only provider-result dictionaries already accepted by the normal search
        matcher so the scheduler can recover useful work even if one later
        MTProto request stalls past the common source-search deadline.
        """
        try:
            lock = getattr(self, '_kadr_snapshot_lock', None)
            if lock is None:
                return
            values = [dict(item or {}) for item in (items or []) if isinstance(item, dict)]
            # Keep the same maximum-result contract as the final provider path.
            if len(values) > int(getattr(self, 'max_results', 200) or 200):
                values = values[:int(getattr(self, 'max_results', 200) or 200)]
            with lock:
                if bool(getattr(self, '_kadr_timeout_snapshot_consumed', False)):
                    return
                current = self._kadr_partial_snapshot or {}
                current_count = len(current.get('items') or [])
                # Never replace a richer snapshot with an older/smaller one.
                if len(values) < current_count:
                    return
                self._kadr_partial_snapshot = {
                    'generation': int(current.get('generation') or getattr(self, '_kadr_snapshot_generation', 0) or 0),
                    'items': values,
                    'data': dict(data or current.get('data') or {}),
                    'stage': str(stage or current.get('stage') or ''),
                    'saved': time.monotonic(),
                }
        except Exception:
            pass

    def _kadr_consume_timeout_snapshot(self):
        """Return one ready aggregate from the latest safe partial snapshot.

        Called synchronously by the common source scheduler only after the
        global deadline has been reached.  No Telegram RPC is issued here.
        Consuming is atomic: the still-unwinding provider worker is then barred
        from publishing a second aggregate or source-cache entry.
        """
        try:
            lock = getattr(self, '_kadr_snapshot_lock', None)
            if lock is None:
                return None
            with lock:
                if bool(getattr(self, '_kadr_timeout_snapshot_consumed', False)):
                    return None
                snap = dict(self._kadr_partial_snapshot or {})
                data = dict(snap.get('data') or {})
                raw_items = [dict(item or {}) for item in (snap.get('items') or []) if isinstance(item, dict)]
                # Mark consumed before local processing so the worker can never
                # race us and publish a later duplicate aggregate.
                self._kadr_timeout_snapshot_consumed = True

            raw_items.sort(
                key=lambda item: int((item or {}).get('telegram_match_score') or 0),
                reverse=True,
            )
            dedup = []
            seen = set()
            for item in raw_items:
                key = self._search_result_key(item)
                if not key or key in seen:
                    continue
                seen.add(key)
                dedup.append(item)
                if len(dedup) >= int(getattr(self, 'max_results', 200) or 200):
                    break

            items = []
            for item in dedup:
                item = dict(item or {})
                item['language'] = item.get('language') if item.get('language') in ('pl', 'de', 'en', 'multi') else 'pl'
                item['direct'] = True
                item['debridonly'] = False
                item['color_identify'] = control.setting('telegram.color.identify2') or 'FF2196F3'
                items.append(item)
            fresh_count = len(items)
            # This is local JSON cache/history I/O only; no MTProto call. It
            # preserves the same one-hour result-history behavior as a normal
            # provider completion.
            items, restored_count = self._merge_recent_search_results(items, data)
            if not items:
                self._diag('[telegram] deadline snapshot empty; stage=%s' % (snap.get('stage') or '-'))
                return None
            aggregate = self._aggregate_source(items, data)
            if not aggregate:
                return None
            aggregate['color_identify'] = control.setting('telegram.color.identify2') or 'FF2196F3'
            aggregate['filename'] = L(33009, 'Telegram — {count} results').format(count=len(items))
            self._kadr_partial_ready = True
            self._diag(
                '[telegram] deadline snapshot consumed; stage=%s results=%s fresh=%s restored=%s' % (
                    snap.get('stage') or '-', len(items), fresh_count, restored_count,
                )
            )
            return aggregate
        except Exception:
            fflog_exc(1)
            return None

    def sources(self, url, hostDict, hostprDict, from_cache=False):
        self._refresh_search_budget()
        # Set only after a complete, internally consistent aggregate has been
        # built.  The common source engine may cancel this provider at its global
        # deadline; a later optional RPC must never erase files already found.
        self._kadr_partial_ready = False
        self._reset_timeout_snapshot()
        if tg_asyncio_compat and tg_asyncio_compat.is_windows() and not _tg_windows_worker_active():
            return _tg_run_windows_worker(
                lambda: self.sources(url, hostDict, hostprDict, from_cache=from_cache),
                'sources',
            )
        try:
            if not url or not self._configured():
                return []
            data = self._unpack(url)
            self._reset_timeout_snapshot(data)
            fflog(f'[telegram] Stage 5 search for {data.get("title")!r}', 1)
            results = []
            if self._cancelled():
                return []

            # Stage 3: logged account dialogs first. This is what private groups/channels need.
            if self.use_dialogs and self._mtproto_ready():
                results.extend(self._sources_mtproto(data))

            # Manual public web fallback is still useful for public channels.
            if self.public_web and not self.only_account and (not results or self.chats):
                results.extend(self._sources_public_web(data))

            # If the common scheduler already consumed the partial snapshot at
            # its global deadline, this worker is only unwinding a previously
            # issued MTProto call.  Never publish/cache a second aggregate later.
            if bool(getattr(self, '_kadr_timeout_snapshot_consumed', False)):
                self._diag('[telegram] late worker exit after consumed deadline snapshot')
                return []

            if self._cancelled() and results:
                fflog('[telegram] search deadline/cancel reached; preserving already found results', 1)
            if not results:
                self._log_telethon_status()

            dedup = []
            seen = set()
            for item in results:
                key = self._search_result_key(item)
                if not key or key in seen:
                    continue
                seen.add(key)
                dedup.append(item)
            items = []
            for item in dedup[:self.max_results]:
                item = dict(item or {})
                item['language'] = item.get('language') if item.get('language') in ('pl', 'de', 'en', 'multi') else 'pl'
                item['direct'] = True
                item['debridonly'] = False
                item['color_identify'] = control.setting('telegram.color.identify2') or 'FF2196F3'
                items.append(item)
            fresh_count = len(items)
            # History must also be consulted after a temporarily empty server
            # scan.  Previously this call lived under ``if dedup`` and an empty
            # scan hid still-valid results even though their one-hour cache had
            # not expired.
            items, restored_count = self._merge_recent_search_results(items, data)
            # The common scheduler may consume the safe deadline snapshot while
            # this worker is doing local history/cache work. Re-check here, just
            # before creating a fresh aggregate/cache token, so a late worker
            # can never publish a second Telegram row for the same scan.
            if bool(getattr(self, '_kadr_timeout_snapshot_consumed', False)):
                self._diag('[telegram] late worker exit after snapshot consumed during finalization')
                return []
            if items:
                aggregate = self._aggregate_source(items, data)
                if aggregate:
                    aggregate['color_identify'] = control.setting('telegram.color.identify2') or 'FF2196F3'
                    aggregate['filename'] = L(33009, 'Telegram — {count} results').format(count=len(items))
                    fflog(
                        f'[telegram] Kadr+ 2.0 returned aggregate with {len(items)} results '
                        f'(fresh={fresh_count}, restored={restored_count})',
                        1,
                    )
                    self._kadr_partial_ready = True
                    return [aggregate]
            fflog('[telegram] Kadr+ 2.0 returned 0 sources', 1)
            return []
        except Exception:
            fflog_exc(1)
            return []

    def _aggregate_source(self, items, data=None):
        try:
            count = len(items or [])
            cache_id = self._save_selection_cache(items or [], data or {})
            if cache_id:
                token = self._pack({
                    'mode': 'select_cache',
                    'cache_id': cache_id,
                    'title': (data or {}).get('title') or (data or {}).get('localtitle') or '',
                })
            else:
                token = self._pack({
                    'mode': 'select',
                    'items': items or [],
                    'title': (data or {}).get('title') or (data or {}).get('localtitle') or '',
                })
            return {
                'provider': 'telegram',
                'source': 'Telegram',
                # Nie używamy quality=0, bo część filtrów traktuje to jak
                # źródło techniczne/niepełne. To tylko agregat do otwarcia listy.
                'quality': 'HD',
                'language': 'multi',
                'url': token,
                'info': L(33010, '{count} results found').format(count=count),
                'direct': True,
                'debridonly': False,
                'filename': '',
                'premium': False,
                'telegram_aggregate': True,
                'telegram_count': count,
                'size': '',
            }
        except Exception:
            fflog_exc(1)
            return {}

    def _selection_cache_dir(self):
        try:
            path = os.path.join(control.dataPath, 'telegram', 'search_results')
            try:
                control.makeDirs(path)
            except Exception:
                os.makedirs(path, exist_ok=True)
            return path
        except Exception:
            return ''

    @staticmethod
    def _normalized_cache_title(value):
        try:
            value = unicodedata.normalize('NFKD', str(value or ''))
            value = ''.join(ch for ch in value if not unicodedata.combining(ch))
            return re.sub(r'[^a-z0-9]+', ' ', value.lower()).strip()
        except Exception:
            return ''

    def _search_history_identity(self, data):
        """Return a stable, non-readable key for one movie/episode query."""
        try:
            aliases = data.get('aliases') or []
            identity = {
                'kind': data.get('kind') or '',
                'title': self._normalized_cache_title(data.get('title')),
                'localtitle': self._normalized_cache_title(data.get('localtitle')),
                'aliases': sorted(
                    self._normalized_cache_title(alias.get('title') if isinstance(alias, dict) else alias)
                    for alias in aliases
                    if alias
                ),
                'year': str(data.get('year') or ''),
                'season': str(data.get('season') or ''),
                'episode': str(data.get('episode') or ''),
                'imdb': str(data.get('imdb') or ''),
                'tvdb': str(data.get('tvdb') or ''),
            }
            raw = json.dumps(identity, ensure_ascii=True, sort_keys=True, separators=(',', ':'))
            return hashlib.sha256(raw.encode('utf-8')).hexdigest()[:32]
        except Exception:
            return ''

    def _recent_search_items(self, data):
        """Load recent results for this exact query (plus legacy picker cache).

        Telegram's server ranking and a strict time budget can make two scans
        return slightly different subsets.  Reusing only recent local metadata
        prevents a rescan from losing a valid file that was found moments ago.
        """
        folder = self._selection_cache_dir()
        if not folder:
            return []
        now = time.time()
        max_age = 3600
        identity = self._search_history_identity(data or {})
        requested_titles = {
            self._normalized_cache_title((data or {}).get('title')),
            self._normalized_cache_title((data or {}).get('localtitle')),
        }
        requested_titles.discard('')

        paths = []
        if identity:
            paths.append(os.path.join(folder, f'recent_{identity}.json'))
        try:
            legacy = [
                os.path.join(folder, name)
                for name in os.listdir(folder)
                if name.endswith('.json') and not name.startswith('recent_')
            ]
            legacy.sort(key=lambda path: os.path.getmtime(path), reverse=True)
            paths.extend(legacy[:24])
        except Exception:
            pass

        cached = []
        for path in paths:
            try:
                if not os.path.isfile(path) or now - os.path.getmtime(path) > max_age:
                    continue
                with open(path, 'r', encoding='utf-8') as fh:
                    payload = json.load(fh) or {}
                # Stable history is already keyed by the complete query.  Old
                # picker files only had a title, so accept those conservatively.
                if not os.path.basename(path).startswith('recent_'):
                    cached_title = self._normalized_cache_title(payload.get('title'))
                    if requested_titles and cached_title not in requested_titles:
                        continue
                values = payload.get('items') or []
                if isinstance(values, list):
                    cached.extend(item for item in values if isinstance(item, dict))
            except Exception:
                continue
        return cached

    def _search_result_key(self, item):
        """Return a stable identity for one Telegram result.

        Packed MTProto URLs contain mutable fields such as ``file_reference``.
        Telegram may refresh that value between searches, so URL-based history
        deduplication treated the same chat/message as a new file every time.
        Prefer the immutable Telegram document id (actual media file), then the
        post identity (chat + message id), while retaining the old URL fallback
        for non-Telegram/legacy entries.
        """
        try:
            item = item or {}
            chat_id = str(item.get('telegram_chat_id') or '').strip()
            message_id = str(item.get('telegram_message_id') or '').strip()
            document_id = str(item.get('telegram_document_id') or '').strip()
            url = str(item.get('url') or '').split('|', 1)[0].strip()
            spec = {}
            if url.startswith('telegram:'):
                try:
                    spec = self._unpack(url) or {}
                except Exception:
                    spec = {}
                if not chat_id:
                    chat_id = str(spec.get('chat_id') or spec.get('chat') or '').strip()
                if not message_id:
                    message_id = str(spec.get('message_id') or '').strip()
                if not document_id:
                    document_id = str(spec.get('doc_id') or '').strip()
            # Telegram document id identifies the actual media file and survives
            # file_reference refreshes and forwards/reposts. Prefer it so the
            # same video cannot accumulate as several rows across searches or
            # when the same document appears in another channel/group.
            if document_id and document_id != '0':
                return 'tgdoc:%s' % document_id
            if chat_id and message_id:
                return 'tgmsg:%s:%s' % (chat_id.casefold(), message_id)
            if url:
                return 'url:' + url
            raw = json.dumps(item, ensure_ascii=True, sort_keys=True, default=str, separators=(',', ':'))
            return 'meta:' + hashlib.sha256(raw.encode('utf-8')).hexdigest()
        except Exception:
            return ''

    def _merge_recent_search_results(self, fresh, data):
        """Merge fresh Telegram hits with a short-lived, query-specific history."""
        fresh = [dict(item or {}) for item in fresh if isinstance(item, dict)]
        previous = self._recent_search_items(data or {})
        fresh_unique = []
        restored_unique = []
        seen = set()
        for item in fresh:
            key = self._search_result_key(item)
            if not key or key in seen:
                continue
            seen.add(key)
            fresh_unique.append(item)
            if len(fresh_unique) >= self.max_results:
                break

        # Never let history displace a result found by the current scan.
        remaining = max(0, self.max_results - len(fresh_unique))
        for item in previous:
            if len(restored_unique) >= remaining:
                break
            key = self._search_result_key(item)
            if not key or key in seen:
                continue
            seen.add(key)
            restored_unique.append(item)

        # Keep files belonging to a Telegram post together.  Appending all
        # restored files at the very end could split one group into two visual
        # blocks; inserting them after the last fresh member preserves both the
        # provider's current ranking and clean group separators.
        restored_by_group = {}
        for item in restored_unique:
            group_id = str((item or {}).get('telegram_parent_header_id') or '')
            if group_id:
                restored_by_group.setdefault(group_id, []).append(item)
        last_fresh_group_index = {}
        for index, item in enumerate(fresh_unique):
            group_id = str((item or {}).get('telegram_parent_header_id') or '')
            if group_id:
                last_fresh_group_index[group_id] = index

        merged = []
        placed_groups = set()
        for index, item in enumerate(fresh_unique):
            merged.append(item)
            group_id = str((item or {}).get('telegram_parent_header_id') or '')
            if group_id and last_fresh_group_index.get(group_id) == index:
                merged.extend(restored_by_group.get(group_id, ()))
                placed_groups.add(group_id)
        for item in restored_unique:
            group_id = str((item or {}).get('telegram_parent_header_id') or '')
            if not group_id:
                merged.append(item)
            elif group_id not in placed_groups:
                merged.extend(restored_by_group.get(group_id, ()))
                placed_groups.add(group_id)

        identity = self._search_history_identity(data or {})
        folder = self._selection_cache_dir()
        if identity and folder:
            path = os.path.join(folder, f'recent_{identity}.json')
            temp_path = path + '.tmp'
            try:
                with open(temp_path, 'w', encoding='utf-8') as fh:
                    json.dump(
                        {
                            'items': merged,
                            'title': (data or {}).get('title') or (data or {}).get('localtitle') or '',
                            'saved_at': int(time.time()),
                        },
                        fh,
                        ensure_ascii=False,
                        separators=(',', ':'),
                    )
                os.replace(temp_path, path)
            except Exception:
                try:
                    if os.path.exists(temp_path):
                        os.unlink(temp_path)
                except Exception:
                    pass

        fresh_keys = {self._search_result_key(item) for item in fresh}
        restored = sum(1 for item in merged if self._search_result_key(item) not in fresh_keys)
        self._diag(
            '[telegram] historia wyników 1h; fresh=%s fresh_unique=%s '
            'previous_loaded=%s restored=%s merged=%s' % (
                len(fresh), len(fresh_unique), len(previous), restored,
                len(merged),
            )
        )
        return merged, restored

    def _save_selection_cache(self, items, data):
        try:
            folder = self._selection_cache_dir()
            if not folder:
                return ''
            now = time.time()
            # Sprzątnij stare wyniki, żeby cache nie rósł bez końca.
            try:
                for name in os.listdir(folder):
                    if not name.endswith('.json'):
                        continue
                    path = os.path.join(folder, name)
                    if now - os.path.getmtime(path) > 3600:
                        os.remove(path)
            except Exception:
                pass
            cache_id = uuid.uuid4().hex
            path = os.path.join(folder, cache_id + '.json')
            with open(path, 'w', encoding='utf-8') as fh:
                json.dump({'items': items or [], 'title': (data or {}).get('title') or (data or {}).get('localtitle') or ''}, fh, ensure_ascii=False, separators=(',', ':'))
            return cache_id
        except Exception:
            fflog_exc(1)
            return ''

    def _load_selection_cache(self, cache_id):
        try:
            cache_id = re.sub(r'[^A-Fa-f0-9]+', '', str(cache_id or ''))
            if not cache_id:
                return {}
            path = os.path.join(self._selection_cache_dir(), cache_id + '.json')
            with open(path, 'r', encoding='utf-8') as fh:
                return json.load(fh) or {}
        except Exception:
            fflog_exc(1)
            return {}

    def _selection_label(self, item):
        try:
            fname = self._clean_filename_label(item.get('filename') or item.get('info2') or '', limit=220)
            if not fname:
                # Last fallback: filename is also embedded in info as the final segment.
                parts = [p.strip() for p in str(item.get('info') or '').split('•') if p.strip()]
                fname = parts[-1] if parts else L(33002, 'Telegram file')
            quality = str(item.get('quality') or '').strip() or self._quality_from_text(fname)
            size = str(item.get('size') or '').strip()
            chat = self._display_chat_title(item.get('source') or 'Telegram')
            language = str(item.get('language') or '').strip().upper()
            date = str(item.get('telegram_date') or '').strip()
            pieces = [fname]
            if language:
                pieces.append(language)
            if quality and quality != '0':
                pieces.append(quality)
            if size:
                pieces.append(size)
            if date:
                pieces.append(date)
            if chat:
                pieces.append(chat)
            return ' • '.join([p for p in pieces if p])
        except Exception:
            return L(33002, 'Telegram file')

    def directory_from_source(self, source, meta=None, title=''):
        """Legacy renderer kept for old Kadr+ routes; unused by the new engine.

        Kadr+ 2.0 opens a nested picker inside the source window instead. Running
        a second plugin directory from an unresolved /play invocation would leave
        two Kodi handles alive and recreate the false playback error on Back.
        """
        fflog('[TELEGRAM] ignored obsolete directory_from_source route', 1)
        return False

    def _resolve_selected_result(self, data, before_stream_start=None):
        try:
            self.selection_cancelled = False
            items = data.get('items') or []
            if not items:
                return None

            def _header_label(txt):
                txt = re.sub(r'\s+', ' ', str(txt or '')).strip()
                if not txt:
                    txt = L(33001, 'Files from a Telegram post')
                if len(txt) > 220:
                    txt = txt[:217].rstrip() + '...'
                return txt

            def _separator_label():
                return 'KONIEC GRUPY'

            rows = []
            open_header = None
            for item in items:
                hid = str(item.get('telegram_parent_header_id') or '')
                if hid:
                    if open_header != hid:
                        if open_header is not None:
                            rows.append((_separator_label(), None))
                        rows.append((_header_label(item.get('telegram_parent_header_text') or ''), None))
                        open_header = hid
                else:
                    if open_header is not None:
                        rows.append((_separator_label(), None))
                        open_header = None
                rows.append((self._selection_label(item), item))
            if open_header is not None:
                rows.append((_separator_label(), None))

            while True:
                try:
                    from lib.windows.telegram import TelegramResultsDialog
                    idx = TelegramResultsDialog(rows=rows).doModal()
                except Exception:
                    # Awaryjny fallback dla nietypowych skórek/instalacji, w
                    # których Kodi odmówi załadowania naszego XML-a.  Także tu
                    # pokazuj wyłącznie wybieralne pliki, bez nagłówków.
                    fflog_exc(1)
                    selectable = [
                        (pos, label)
                        for pos, (label, payload) in enumerate(rows)
                        if payload is not None
                    ]
                    selected = control.selectDialog(
                        [label for _pos, label in selectable],
                        heading='Telegram • ' + L(32995, 'search results'),
                    )
                    idx = selectable[selected][0] if selected is not None and selected >= 0 else -1
                if idx is None or idx < 0 or idx >= len(rows):
                    self.selection_cancelled = True
                    fflog('[TELEGRAM] result list closed without playback', 1)
                    return False
                selected = rows[idx][1]
                # Zielone opisy i czerwone kreski są tylko nagłówkami wizualnymi.
                if not selected:
                    continue
                # Ask only after the exact Telegram file is known, but before the
                # local service builds its 10 MB startup buffer.  The source
                # manager consumes this answer after resolve, so no second prompt
                # is shown and Kodi's directory-level prompt remains suppressed.
                playback_session_id = ''
                if callable(before_stream_start):
                    try:
                        playback_session_id = str(before_stream_start() or '')
                    except Exception:
                        # Resume UI is optional.  The source manager will use its
                        # normal post-resolve fallback if this callback fails.
                        fflog_exc(1)
                # Rejestracja strumienia i pobranie pierwszych bajtów potrafią
                # zająć kilka–kilkanaście sekund. Pokaż użytkownikowi, że klik
                # został przyjęty, zanim zaczniemy kontakt z usługą proxy.
                try:
                    control.busy_dialog(
                        True,
                        owner=playback_session_id,
                        owner_timeout=180.0,
                    )
                except Exception:
                    pass
                return self.resolve(selected.get('url') or '')
        except Exception:
            fflog_exc(1)
            return None

    def resolve(self, url, **kwargs):
        try:
            self.selection_cancelled = False
            data = self._unpack(url)
            mode = data.get('mode') or ''
            if mode == 'select_cache':
                cached = self._load_selection_cache(data.get('cache_id') or '')
                if cached:
                    data.update(cached)
                return self._resolve_selected_result(
                    data,
                    before_stream_start=kwargs.get('before_stream_start'),
                )
            if mode == 'select':
                return self._resolve_selected_result(
                    data,
                    before_stream_start=kwargs.get('before_stream_start'),
                )
            if mode == 'mtproto':
                return self._resolve_mtproto(data)
            src = data.get('url') or ''
            if not src:
                return None
            headers = urlencode({
                'User-Agent': self.headers['User-Agent'],
                'Referer': data.get('referer') or 'https://t.me/',
                'Accept': '*/*',
                'Accept-Language': self.headers.get('Accept-Language', 'pl-PL,pl;q=0.9,en;q=0.7'),
                'Connection': 'keep-alive',
            })
            if '|' not in src:
                src = src + '|' + headers
            return src
        except Exception:
            fflog_exc(1)
            return None

    def _chat_filter_path(self):
        try:
            return os.path.join(self._session_dir(), 'chat_filter.json')
        except Exception:
            return os.path.join(control.dataPath, 'telegram_chat_filter.json')

    def _load_chat_filter(self):
        path = self._chat_filter_path()
        try:
            st = os.stat(path)
            signature = (int(getattr(st, 'st_mtime_ns', int(st.st_mtime * 1000000000))), int(st.st_size))
        except Exception:
            signature = (0, 0)
        try:
            if self._chat_filter_data_cache is not None and self._chat_filter_data_signature == signature:
                return self._chat_filter_data_cache
        except Exception:
            pass
        try:
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as fh:
                    data = json.load(fh) or {}
            else:
                data = {}
        except Exception:
            data = {}
        try:
            if not isinstance(data.get('chats'), list):
                data['chats'] = []
            ids = data.get('selected_ids') or []
            data['selected_ids'] = [str(x) for x in ids if str(x).strip()]
            if not isinstance(data.get('topics'), list):
                data['topics'] = []
            cleaned_topics = []
            seen_topics = set()
            for topic in data.get('topics') or []:
                if not isinstance(topic, dict):
                    continue
                chat_id = str(topic.get('chat_id') or '').strip()
                topic_id = str(topic.get('topic_id') or '').strip()
                if not chat_id or not topic_id:
                    continue
                key = '%s:%s' % (chat_id, topic_id)
                if key in seen_topics:
                    continue
                seen_topics.add(key)
                cleaned_topics.append({
                    'chat_id': chat_id,
                    'chat_title': str(topic.get('chat_title') or '').strip(),
                    'topic_id': topic_id,
                    'title': str(topic.get('title') or '').strip(),
                })
            data['topics'] = cleaned_topics
            keys = data.get('selected_topic_keys') or []
            data['selected_topic_keys'] = sorted(set([str(x) for x in keys if ':' in str(x)]))
        except Exception:
            data = {'chats': [], 'selected_ids': [], 'topics': [], 'selected_topic_keys': []}
        try:
            self._chat_filter_data_cache = data
            self._chat_filter_data_signature = signature
        except Exception:
            pass
        return data

    def _save_chat_filter(self, data):
        try:
            if not isinstance(data, dict):
                data = {}
            data.setdefault('chats', [])
            data.setdefault('selected_ids', [])
            data.setdefault('topics', [])
            data.setdefault('selected_topic_keys', [])
            self._selected_topic_map_cache = None
            self._chat_filter_data_cache = None
            self._chat_filter_data_signature = None
            _tg_clear_search_metadata_cache()
            data['saved'] = int(time.time())
            path = self._chat_filter_path()
            folder = os.path.dirname(path)
            if folder and not os.path.exists(folder):
                try:
                    control.makeDirs(folder)
                except Exception:
                    os.makedirs(folder, exist_ok=True)
            with open(path, 'w', encoding='utf-8') as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2, sort_keys=True)
            return True
        except Exception:
            fflog_exc(1)
            return False

    def _chat_filter_mode_name(self):
        try:
            return ['all', 'selected', 'excluded'][int(self.chat_filter_mode or 0)]
        except Exception:
            return 'all'

    def _selected_chat_ids(self):
        try:
            data = self._load_chat_filter()
            return set([str(x) for x in (data.get('selected_ids') or []) if str(x).strip()])
        except Exception:
            return set()

    @staticmethod
    def _topic_filter_key(chat_id, topic_id):
        try:
            cid = int(chat_id or 0)
            tid = int(topic_id or 0)
            if cid and tid:
                return '%s:%s' % (cid, tid)
        except Exception:
            pass
        return ''

    def _selected_topic_map(self):
        """Return selected topic IDs grouped by chat ID.

        Backwards compatible semantics: chats without a selected topic entry are
        searched exactly as before.  Only a chat present in this map is restricted
        to the selected topic IDs.
        """
        try:
            cached = self._selected_topic_map_cache
            if cached is not None:
                return cached
        except Exception:
            pass
        out = {}
        try:
            data = self._load_chat_filter()
            for raw in data.get('selected_topic_keys') or []:
                try:
                    chat_s, topic_s = str(raw).split(':', 1)
                    chat_id = int(chat_s or 0)
                    topic_id = int(topic_s or 0)
                    if chat_id and topic_id:
                        out.setdefault(chat_id, set()).add(topic_id)
                except Exception:
                    continue
        except Exception:
            out = {}
        try:
            self._selected_topic_map_cache = out
        except Exception:
            pass
        return out

    def _message_topic_id(self, msg):
        """Resolve the numeric forum-topic root ID for a Telegram message."""
        try:
            topic_id = int(self._reply_topic_id_from_message(msg) or 0)
            if topic_id:
                return topic_id
        except Exception:
            pass
        try:
            rr = getattr(msg, 'reply_to', None)
            if rr and bool(getattr(rr, 'forum_topic', False)):
                val = getattr(rr, 'reply_to_msg_id', None)
                if val and not isinstance(val, bool):
                    return int(val)
        except Exception:
            pass
        return 0

    def _message_allowed_by_topic_filter(self, ent, msg):
        """Apply the optional per-forum topic allow-list.

        A selected Forum Topic belongs to one concrete forum supergroup.  Never
        apply that filter to ordinary broadcast channels or non-forum groups;
        those must keep the historical Kadr+ search behaviour.
        """
        try:
            if not bool(getattr(ent, 'forum', False)):
                return True
            chat_id = int(getattr(ent, 'id', 0) or getattr(msg, 'chat_id', 0) or 0)
            allowed = self._selected_topic_map().get(chat_id)
            if not allowed:
                return True
            topic_id = self._message_topic_id(msg)
            # When the user explicitly restricted a forum group, an unknown topic
            # must not leak through from account-wide search.
            return bool(topic_id and int(topic_id) in allowed)
        except Exception:
            return True

    def _chat_filter_is_forum(self, ch):
        try:
            if bool(ch.get('forum')):
                return True
            kind = self._clean_chat_filter_text(ch.get('kind') or '', 40).lower()
            marker = self._clean_chat_filter_text(L(33015, 'topics'), 40).lower()
            if marker and marker in kind:
                return True
            # Old chat_filter.json files stored the translated kind string and did
            # not have a separate forum flag. Keep them recognizable even after a
            # Kodi language change.
            return any(token in kind for token in ('topics', 'tematy', 'themen'))
        except Exception:
            return False

    def _clean_chat_filter_text(self, value, max_len=90):
        """Minimal cleanup for Telegram chat/channel names in Kodi UI.

        Keep the name as close as possible to Telegram.  Only remove Kodi markup
        and control/newline characters that can break settings lists.
        """
        try:
            text = str(value or '')
            text = unescape(text)
            text = text.replace('[CR]', ' ').replace('\r', ' ').replace('\n', ' ').replace('\t', ' ')
            text = re.sub(r'\[(?:/?(?:COLOR|B|I|LIGHT|UPPERCASE)|COLOR\s+[^\]]+)\]', '', text, flags=re.I)
            cleaned = []
            for ch in text:
                cat = unicodedata.category(ch)
                if cat in ('Cc', 'Cf', 'Cs', 'Cn'):
                    continue
                cleaned.append(ch)
            text = ''.join(cleaned)
            text = text.replace('＠', '@').replace('﹫', '@')
            text = re.sub(r'\s+', ' ', text).strip()
            if max_len and text and len(text) > int(max_len):
                text = text[:int(max_len) - 1].rstrip() + '…'
            return text
        except Exception:
            try:
                return re.sub(r'\s+', ' ', str(value or '')).strip()
            except Exception:
                return ''

    def _chat_filter_display_label(self, ch):
        try:
            cid = self._clean_chat_filter_text(ch.get('id') or '', 40)
            username = self._clean_chat_filter_text(ch.get('username') or '', 50).lstrip('@')
            title = self._clean_chat_filter_text(ch.get('title') or '', 70)
            kind = self._clean_chat_filter_text(ch.get('kind') or L(33012, 'group/channel'), 18) or L(33012, 'group/channel')

            # Normal, predictable format requested by user:
            # "Nazwa (@username) (kanał/grupa/tematy)".
            # Do not try to outsmart decorative Telegram titles here; display them
            # as Telegram reports them.  If there is no readable title, fall back
            # to @username or ID.
            if title and username and username.lower() not in title.lower().replace('@', ''):
                label = '%s (@%s) (%s)' % (title, username, kind)
            elif title:
                label = '%s (%s)' % (title, kind)
            elif username:
                label = '@%s (%s)' % (username, kind)
            else:
                label = 'ID %s (%s)' % (cid or '?', kind)
            return re.sub(r'\s+', ' ', label).strip()
        except Exception:
            return str(ch.get('title') or ch.get('username') or ch.get('id') or '')

    def _chat_filter_item_from_dialog(self, d):
        try:
            ent = getattr(d, 'entity', None)
            if not ent:
                return None
            eid = int(getattr(ent, 'id', 0) or 0)
            if not eid:
                return None
            if not (getattr(d, 'is_channel', False) or getattr(d, 'is_group', False) or self._is_group_channel(ent)):
                return None
            username = ''
            try:
                username = getattr(ent, 'username', None) or ''
            except Exception:
                username = ''
            username = self._clean_chat_filter_text(username, 60).lstrip('@')
            raw_title = getattr(d, 'name', None) or getattr(ent, 'title', None) or ''
            title = self._clean_chat_filter_text(raw_title, 90)
            if not title:
                title = ('@%s' % username) if username else str(eid)
            kind = L(33013, 'channel') if getattr(d, 'is_channel', False) and not getattr(d, 'is_group', False) else L(33014, 'group')
            try:
                if getattr(ent, 'forum', False):
                    kind += ' / ' + L(33015, 'topics')
            except Exception:
                pass
            return {
                'id': str(eid),
                'title': str(title or '').strip() or str(eid),
                'username': str(username or '').strip(),
                'kind': kind,
                'forum': bool(getattr(ent, 'forum', False)),
                'score': int(self._chat_scan_score(title) or 0),
            }
        except Exception:
            return None

    def _collect_chat_filter_dialogs(self, client, limit=1000, progress=None):
        chats = []
        seen = set()
        scanned = 0
        try:
            for d in client.iter_dialogs(limit=int(limit or 1000)):
                scanned += 1
                if progress and scanned % 5 == 0:
                    try:
                        if hasattr(progress, 'iscanceled') and progress.iscanceled():
                            break
                        pct = min(90, 10 + int(scanned * 80 / max(80, int(limit or 1000))))
                        progress.update(pct, L(33016, 'Checking Telegram groups/channels…\nFound: {count}').format(count=len(chats)))
                    except Exception:
                        pass
                item = self._chat_filter_item_from_dialog(d)
                if not item:
                    continue
                eid = item.get('id') or ''
                if not eid or eid in seen:
                    continue
                seen.add(eid)
                chats.append(item)
        except Exception:
            fflog_exc(1)
        try:
            chats = sorted(chats, key=lambda x: (str(x.get('title') or '').lower(), str(x.get('id') or '')))
        except Exception:
            pass
        return chats

    def refresh_chat_filter_list_from_settings(self):
        if tg_asyncio_compat and tg_asyncio_compat.is_windows() and not _tg_windows_worker_active():
            return _tg_run_windows_worker(self.refresh_chat_filter_list_from_settings, 'refresh-chats')
        progress = None
        try:
            try:
                progress = control.progressDialog
                progress.create('Telegram', L(33017, 'Connecting to the Telegram account…'))
                progress.update(0, L(33018, 'Downloading the group/channel list…'))
            except Exception:
                progress = None
            client = self._get_client(interactive=False)
            if not (client and client.is_user_authorized()):
                try:
                    if progress:
                        progress.close()
                except Exception:
                    pass
                control.infoDialog(L(33019, 'Telegram: log in to the account first'), heading='Telegram', icon='WARNING', time=5000, sound=False)
                try:
                    _tg_safe_disconnect(client)
                except Exception:
                    pass
                return False
            try:
                if progress:
                    progress.update(10, L(33020, 'Refreshing the group/channel list…'))
            except Exception:
                pass
            chats = self._collect_chat_filter_dialogs(client, limit=1000, progress=progress)
            try:
                if progress:
                    progress.update(92, L(33021, 'Saving the group/channel list…'))
            except Exception:
                pass
            _tg_safe_disconnect(client)
            data = self._load_chat_filter()
            old_selected = set([str(x) for x in data.get('selected_ids') or []])
            available = set([str(x.get('id')) for x in chats])
            data['chats'] = chats
            data['selected_ids'] = sorted([x for x in old_selected if x in available])
            # Keep cached topic data only for chats that still exist on the account.
            data['topics'] = [
                x for x in (data.get('topics') or [])
                if str(x.get('chat_id') or '') in available
            ]
            data['selected_topic_keys'] = [
                x for x in (data.get('selected_topic_keys') or [])
                if str(x).split(':', 1)[0] in available
            ]
            self._save_chat_filter(data)
            try:
                if progress:
                    progress.update(100, L(33022, 'Refreshed: {count} groups/channels').format(count=len(chats)))
                    control.sleep(250)
                    progress.close()
            except Exception:
                pass
            control.infoDialog(L(33022, 'Refreshed: {count} groups/channels').format(count=len(chats)), heading='Telegram', time=4500, sound=False)
            return True
        except Exception:
            fflog_exc(1)
            try:
                if progress:
                    progress.close()
            except Exception:
                pass
            control.infoDialog(L(33023, 'Telegram: could not refresh the group/channel list'), heading='Telegram', icon='WARNING', time=5500, sound=False)
            return False

    def choose_chat_filter_from_settings(self):
        try:
            data = self._load_chat_filter()
            chats = data.get('chats') or []
            if not chats:
                if not self.refresh_chat_filter_list_from_settings():
                    return False
                data = self._load_chat_filter()
                chats = data.get('chats') or []
            if not chats:
                control.infoDialog(L(33024, 'Telegram: there are no groups/channels to select'), heading='Telegram', icon='WARNING', time=4500, sound=False)
                return False
            selected = set([str(x) for x in data.get('selected_ids') or []])
            labels = []
            preselect = []
            for idx, ch in enumerate(chats):
                labels.append(self._chat_filter_display_label(ch))
                if str(ch.get('id') or '') in selected:
                    preselect.append(idx)
            mode = self._chat_filter_mode_name()
            if mode == 'selected':
                heading = L(33025, 'Telegram: select groups/channels to search')
            elif mode == 'excluded':
                heading = L(33026, 'Telegram: select groups/channels to exclude')
            else:
                heading = L(33027, 'Telegram: selection saved; it will become active after changing mode')
            try:
                picked = control.dialog.multiselect(heading, labels, preselect=preselect)
            except TypeError:
                picked = control.dialog.multiselect(heading, labels)
            if picked is None:
                return False
            new_ids = []
            for idx in picked:
                try:
                    new_ids.append(str(chats[int(idx)].get('id') or ''))
                except Exception:
                    pass
            data['selected_ids'] = sorted([x for x in new_ids if x])
            self._save_chat_filter(data)
            if mode == 'selected':
                msg = L(33028, 'Telegram: selected {count} groups/channels to search').format(count=len(data['selected_ids']))
            elif mode == 'excluded':
                msg = L(33029, 'Telegram: excluded {count} groups/channels from search').format(count=len(data['selected_ids']))
            else:
                msg = L(33030, 'Telegram: saved {count} selections. Choose selected/excluded mode to use them.').format(count=len(data['selected_ids']))
            control.infoDialog(msg, heading='Telegram', time=5500, sound=False)
            return True
        except Exception:
            fflog_exc(1)
            control.infoDialog(L(33031, 'Telegram: could not save the group/channel selection'), heading='Telegram', icon='WARNING', time=5500, sound=False)
            return False

    def clear_chat_filter_from_settings(self):
        try:
            data = self._load_chat_filter()
            data['selected_ids'] = []
            self._save_chat_filter(data)
            control.infoDialog(L(33032, 'Telegram: group/channel selection cleared'), heading='Telegram', time=4000, sound=False)
            return True
        except Exception:
            fflog_exc(1)
            control.infoDialog(L(33033, 'Telegram: could not clear the group/channel selection'), heading='Telegram', icon='WARNING', time=5000, sound=False)
            return False

    def _topic_filter_display_label(self, topic):
        try:
            chat_title = self._clean_chat_filter_text(topic.get('chat_title') or '', 60)
            topic_title = self._clean_chat_filter_text(topic.get('title') or '', 75)
            if chat_title and topic_title:
                return '%s / %s' % (chat_title, topic_title)
            return topic_title or chat_title or ('ID %s' % (topic.get('topic_id') or '?'))
        except Exception:
            return str(topic.get('title') or topic.get('topic_id') or '')

    def _forum_topic_items_for_entity(self, client, ent, chat_title='', max_topics=1000):
        """Fetch and paginate a forum's topics using ForumTopic.id as the root ID.

        Returns ``None`` on an API/transport failure so a refresh never erases a
        previously working cached topic list just because Telegram was temporarily
        unavailable.
        """
        items = []
        seen = set()
        try:
            from telethon.tl.functions.channels import GetForumTopicsRequest
            chat_id = int(getattr(ent, 'id', 0) or 0)
            if not chat_id or not getattr(ent, 'forum', False):
                return None
            offset_date = None
            offset_id = 0
            offset_topic = 0
            while len(items) < int(max_topics or 1000):
                limit = min(100, int(max_topics or 1000) - len(items))
                res = client(GetForumTopicsRequest(
                    channel=ent, offset_date=offset_date, offset_id=offset_id,
                    offset_topic=offset_topic, limit=limit, q=None,
                ))
                batch = list(getattr(res, 'topics', []) or [])
                added = 0
                last = None
                for topic in batch:
                    topic_id = int(getattr(topic, 'id', 0) or 0)
                    if not topic_id or topic_id in seen:
                        continue
                    seen.add(topic_id)
                    last = topic
                    title = self._clean_chat_filter_text(getattr(topic, 'title', '') or '', 100)
                    if not title:
                        title = L(33142, 'Topic {id}').format(id=topic_id)
                    items.append({
                        'chat_id': str(chat_id),
                        'chat_title': self._clean_chat_filter_text(chat_title, 90),
                        'topic_id': str(topic_id),
                        'title': title,
                    })
                    added += 1
                if not batch or not added or len(batch) < limit:
                    break
                if last is None:
                    break
                next_topic = int(getattr(last, 'id', 0) or 0)
                next_id = int(getattr(last, 'top_message', 0) or 0)
                next_date = getattr(last, 'date', None)
                if not next_topic or (next_topic == offset_topic and next_id == offset_id):
                    break
                offset_topic = next_topic
                offset_id = next_id
                offset_date = next_date
        except Exception:
            fflog_exc(1)
            return None
        try:
            return sorted(items, key=lambda x: (str(x.get('title') or '').lower(), int(x.get('topic_id') or 0)))
        except Exception:
            return items

    def _topic_refresh_entity(self, client, chat):
        try:
            chat_id = int(chat.get('id') or 0)
            username = str(chat.get('username') or '').strip().lstrip('@')
            ent = _tg_find_entity(client, chat_id, username)
            if ent and getattr(ent, 'forum', False):
                return ent
        except Exception:
            pass
        return None

    def refresh_topic_filter_list_from_settings(self):
        """Let the user choose forum groups, then refresh only those topic lists."""
        try:
            data = self._load_chat_filter()
            chats = [x for x in (data.get('chats') or []) if self._chat_filter_is_forum(x)]
            if not chats:
                control.infoDialog(L(33143, 'Telegram: refresh the group/channel list first; no forum groups are cached'), heading='Telegram', icon='WARNING', time=5500, sound=False)
                return False
            cached_chat_ids = set([str(x.get('chat_id') or '') for x in (data.get('topics') or [])])
            selected_chat_ids = set([str(x).split(':', 1)[0] for x in (data.get('selected_topic_keys') or [])])
            chosen_chat_ids = set([str(x) for x in (data.get('selected_ids') or [])]) if self._chat_filter_mode_name() != 'excluded' else set()
            labels = [self._chat_filter_display_label(ch) for ch in chats]
            preselect = [
                idx for idx, ch in enumerate(chats)
                if (str(ch.get('id') or '') in cached_chat_ids
                    or str(ch.get('id') or '') in selected_chat_ids
                    or str(ch.get('id') or '') in chosen_chat_ids)
            ]
            try:
                picked = control.dialog.multiselect(L(33144, 'Telegram: choose forum groups whose topics should be refreshed'), labels, preselect=preselect)
            except TypeError:
                picked = control.dialog.multiselect(L(33144, 'Telegram: choose forum groups whose topics should be refreshed'), labels)
            if picked is None:
                self._diag('[telegram] odświeżanie tematów anulowane na wyborze grup; bez zmian')
                return False
            chosen = []
            for idx in picked:
                try:
                    chosen.append(chats[int(idx)])
                except Exception:
                    pass
            if not chosen:
                control.infoDialog(L(33145, 'Telegram: no forum groups selected'), heading='Telegram', icon='WARNING', time=4500, sound=False)
                return False
            chosen_ids = [str(x.get('id') or '') for x in chosen if str(x.get('id') or '')]
            return self._refresh_topic_filter_groups(chosen_ids)
        except Exception:
            fflog_exc(1)
            control.infoDialog(L(33150, 'Telegram: could not prepare the topic refresh'), heading='Telegram', icon='WARNING', time=5500, sound=False)
            return False

    def _refresh_topic_filter_groups(self, chat_ids):
        if tg_asyncio_compat and tg_asyncio_compat.is_windows() and not _tg_windows_worker_active():
            ids = list(chat_ids or [])
            return _tg_run_windows_worker(lambda: self._refresh_topic_filter_groups(ids), 'refresh-topics')
        self._diag('[telegram] start odświeżania tematów; groups=%s' % len(list(chat_ids or [])))
        progress = None
        client = None
        try:
            wanted = set([str(x) for x in (chat_ids or []) if str(x).strip()])
            data = self._load_chat_filter()
            chosen = [x for x in (data.get('chats') or []) if str(x.get('id') or '') in wanted and self._chat_filter_is_forum(x)]
            if not chosen:
                return False
            try:
                progress = control.progressDialog
                progress.create('Telegram', L(33146, 'Connecting to Telegram and downloading topics…'))
                progress.update(0, L(33147, 'Downloading forum topics…'))
            except Exception:
                progress = None
            client = self._get_client(interactive=False)
            if not (client and client.is_user_authorized()):
                try:
                    if progress:
                        progress.close()
                        progress = None
                except Exception:
                    pass
                control.infoDialog(L(33019, 'Telegram: log in to the account first'), heading='Telegram', icon='WARNING', time=5000, sound=False)
                return False

            # Resolve all selected dialog entities in one pass. Private forum groups
            # often have no username; repeatedly scanning hundreds of dialogs once
            # per group would make topic refresh unnecessarily slow.
            entity_map = {}
            try:
                for d in client.iter_dialogs(limit=1000):
                    ent = getattr(d, 'entity', None)
                    chat_id = str(int(getattr(ent, 'id', 0) or 0)) if ent else ''
                    if chat_id in wanted:
                        entity_map[chat_id] = ent
                        if len(entity_map) >= len(wanted):
                            break
            except Exception:
                fflog_exc(1)

            refreshed_topics = []
            refreshed_chat_ids = set()
            for pos, ch in enumerate(chosen):
                if progress:
                    try:
                        pct = int(pos * 90 / max(1, len(chosen)))
                        progress.update(pct, L(33148, 'Downloading topics: {group}').format(group=self._clean_chat_filter_text(ch.get('title') or '', 55)))
                    except Exception:
                        pass
                chat_id = str(ch.get('id') or '')
                ent = entity_map.get(chat_id) or self._topic_refresh_entity(client, ch)
                if not ent:
                    continue
                items = self._forum_topic_items_for_entity(client, ent, ch.get('title') or '', max_topics=1000)
                if items is None:
                    continue
                refreshed_topics.extend(items)
                refreshed_chat_ids.add(chat_id)
            if not refreshed_chat_ids:
                try:
                    if progress:
                        progress.close()
                        progress = None
                except Exception:
                    pass
                control.infoDialog(L(33150, 'Telegram: could not refresh the topic list'), heading='Telegram', icon='WARNING', time=5500, sound=False)
                return False
            old_topics = [
                x for x in (data.get('topics') or [])
                if str(x.get('chat_id') or '') not in refreshed_chat_ids
            ]
            data['topics'] = old_topics + refreshed_topics
            available_keys = set([
                self._topic_filter_key(x.get('chat_id'), x.get('topic_id'))
                for x in data.get('topics') or []
            ])
            old_selected = [str(x) for x in (data.get('selected_topic_keys') or [])]
            # Only prune stale selections in groups that were actually refreshed.
            kept_selected = []
            for key in old_selected:
                chat_id = key.split(':', 1)[0] if ':' in key else ''
                if chat_id in refreshed_chat_ids and key not in available_keys:
                    continue
                kept_selected.append(key)
            data['selected_topic_keys'] = sorted(set(kept_selected))
            self._save_chat_filter(data)
            if progress:
                try:
                    progress.update(100, L(33149, 'Refreshed {topics} topics in {groups} groups').format(topics=len(refreshed_topics), groups=len(refreshed_chat_ids)))
                    control.sleep(250)
                    progress.close()
                    progress = None
                except Exception:
                    pass
            control.infoDialog(L(33149, 'Refreshed {topics} topics in {groups} groups').format(topics=len(refreshed_topics), groups=len(refreshed_chat_ids)), heading='Telegram', time=5000, sound=False)
            return bool(refreshed_chat_ids)
        except Exception:
            fflog_exc(1)
            control.infoDialog(L(33150, 'Telegram: could not refresh the topic list'), heading='Telegram', icon='WARNING', time=5500, sound=False)
            return False
        finally:
            try:
                if progress:
                    progress.close()
            except Exception:
                pass
            _tg_safe_disconnect(client)

    def choose_topic_filter_from_settings(self):
        try:
            data = self._load_chat_filter()
            topics = list(data.get('topics') or [])
            if not topics:
                control.infoDialog(L(33151, 'Telegram: refresh the topic list first'), heading='Telegram', icon='WARNING', time=5000, sound=False)
                return False
            topics = sorted(topics, key=lambda x: (str(x.get('chat_title') or '').lower(), str(x.get('title') or '').lower(), int(x.get('topic_id') or 0)))
            selected = set([str(x) for x in (data.get('selected_topic_keys') or [])])
            labels = []
            preselect = []
            for idx, topic in enumerate(topics):
                labels.append(self._topic_filter_display_label(topic))
                key = self._topic_filter_key(topic.get('chat_id'), topic.get('topic_id'))
                if key in selected:
                    preselect.append(idx)
            try:
                picked = control.dialog.multiselect(L(33152, 'Telegram: select topics to search'), labels, preselect=preselect)
            except TypeError:
                picked = control.dialog.multiselect(L(33152, 'Telegram: select topics to search'), labels)
            if picked is None:
                self._diag('[telegram] wybór tematów anulowany; zachowuję poprzedni filtr')
                return False
            new_keys = []
            groups = set()
            for idx in picked:
                try:
                    topic = topics[int(idx)]
                    key = self._topic_filter_key(topic.get('chat_id'), topic.get('topic_id'))
                    if key:
                        new_keys.append(key)
                        groups.add(str(topic.get('chat_id') or ''))
                except Exception:
                    pass
            data['selected_topic_keys'] = sorted(set(new_keys))
            self._save_chat_filter(data)
            self._diag('[telegram] zapisano filtr tematów; selected_topics=%s groups=%s' % (len(set(new_keys)), len(groups)))
            if new_keys:
                msg = L(33153, 'Telegram: selected {topics} topics in {groups} groups').format(topics=len(set(new_keys)), groups=len(groups))
            else:
                msg = L(33154, 'Telegram: no topic restrictions; whole groups will be searched')
            control.infoDialog(msg, heading='Telegram', time=5500, sound=False)
            return True
        except Exception:
            fflog_exc(1)
            control.infoDialog(L(33155, 'Telegram: could not save the topic selection'), heading='Telegram', icon='WARNING', time=5500, sound=False)
            return False

    def clear_topic_filter_from_settings(self):
        try:
            data = self._load_chat_filter()
            data['selected_topic_keys'] = []
            self._save_chat_filter(data)
            control.infoDialog(L(33156, 'Telegram: topic selection cleared; whole groups will be searched'), heading='Telegram', time=4500, sound=False)
            return True
        except Exception:
            fflog_exc(1)
            control.infoDialog(L(33157, 'Telegram: could not clear the topic selection'), heading='Telegram', icon='WARNING', time=5000, sound=False)
            return False

    def login_from_settings(self):
        """Backward-compatible alias: the only interactive login is QR."""
        return self.login_qr_from_settings()

    def login_qr_from_settings(self):
        if tg_asyncio_compat and tg_asyncio_compat.is_windows() and not _tg_windows_worker_active():
            return _tg_run_windows_worker(self.login_qr_from_settings, 'login-qr')
        """Public settings action for QR-only Telegram login."""
        try:
            if not (int(self.api_id or 0) and self.api_hash):
                control.infoDialog(L(33034, 'Saved Telegram API credentials are incomplete. Restore valid settings.'), heading='Telegram', icon='WARNING', time=5500, sound=False)
                return False
        except Exception:
            control.infoDialog(L(33044, 'The saved Telegram API ID is invalid. Restore valid settings.'), heading='Telegram', icon='WARNING', time=5500, sound=False)
            return False
        return self._login_qr_from_settings()

    def clear_session_from_settings(self):
        try:
            self._delete_session_files()
            self._set_login_status(False)
            control.infoDialog(L(33049, 'Telegram session cleared'), heading='Telegram', time=4000, sound=False)
            return True
        except Exception:
            fflog_exc(1)
            control.infoDialog(L(33050, 'Could not clear the Telegram session'), heading='Telegram', icon='WARNING', time=5000, sound=False)
            return False

    def _login_qr_from_settings(self):
        client = None
        try:
            TelegramClient, errors, _, _, _ = _tg_telethon_imports()
            if not TelegramClient:
                control.infoDialog(L(33045, 'The Telethon library is missing from the add-on'), heading='Telegram', icon='WARNING', time=3500, sound=False)
                return False
            api_id = int(self.api_id or 0)
            api_hash = self.api_hash
            if not (api_id and api_hash):
                control.infoDialog(L(33034, 'Saved Telegram API credentials are incomplete. Restore valid settings.'), heading='Telegram', icon='WARNING', time=5500, sound=False)
                return False
            self._delete_session_files()
            self._set_login_status(False)
            loop = _tg_ensure_event_loop()
            _tg_patch_telethon_helpers()
            _tg_bind_event_loop(loop)
            session_path = self._session_path()
            client = _tg_new_client(
                TelegramClient, session_path, api_id, api_hash, loop,
                base_logger=_TG_TELETHON_LOGGER,
            )
            client.connect()
            if client.is_user_authorized():
                self._set_login_status(True)
                control.infoDialog(L(33051, 'Telegram is already logged in'), heading='Telegram', time=3500, sound=False)
                return True
            client, ok = self._qr_login_with_dc_retry(client, session_path, api_id, api_hash, loop, errors)
            if ok:
                self._set_login_status(True)
                control.infoDialog(L(33052, 'Telegram logged in via QR'), heading='Telegram', time=3500, sound=False)
            else:
                self._set_login_status(False)
            return bool(ok)
        except BaseException as exc:
            self._set_login_status(False)
            if self._is_api_id_invalid(exc, errors if 'errors' in locals() else None):
                self._show_api_id_invalid()
                return False
            fflog_exc(1)
            control.infoDialog(L(33053, 'Telegram QR login failed — check the log'), heading='Telegram', icon='WARNING', time=6000, sound=False)
            return False
        finally:
            _tg_safe_disconnect(client)

    # ------------------------------------------------------------------ #
    # MTProto / account dialogs                                           #
    # ------------------------------------------------------------------ #

    def _set_login_status(self, logged_in):
        """Store the visible status and a persistent marker used by settings.xml."""
        state = bool(logged_in)
        value = L(33135, 'Logged in') if state else L(33136, 'Not logged in')
        try:
            control.setSetting('telegram.login_status', value)
        except Exception:
            pass
        try:
            # Empty = QR login button visible, non-empty = session is logged in.
            # A string marker is used because Kodi settings dependencies persist
            # and compare string values reliably when the settings dialog is reopened.
            control.setSetting('telegram.session_marker', '1' if state else '')
        except Exception:
            pass
        return state

    def refresh_login_status_from_settings(self, force=False):
        """Refresh the visible status from the real saved Telethon session."""
        if tg_asyncio_compat and tg_asyncio_compat.is_windows() and not _tg_windows_worker_active():
            return _tg_run_windows_worker(
                lambda: self.refresh_login_status_from_settings(force=force),
                'status-check',
            )
        if not self._api_credentials_ready() or not self._has_saved_session():
            return self._set_login_status(False)
        try:
            if not force and (control.setting('telegram.login_status') or '').strip() == L(33135, 'Logged in'):
                # Migrate the status saved by 2.0.84 to the persistent marker.
                try:
                    control.setSetting('telegram.session_marker', '1')
                except Exception:
                    pass
                return True
        except Exception:
            pass
        client = None
        try:
            client = self._get_client(interactive=False)
            return self._set_login_status(bool(client and client.is_user_authorized()))
        except BaseException:
            fflog_exc(1)
            return self._set_login_status(False)
        finally:
            _tg_safe_disconnect(client)

    def _api_credentials_ready(self):
        try:
            return bool(int(self.api_id or 0) and self.api_hash)
        except Exception:
            return False

    def _has_saved_session(self):
        """Return True when a reusable Telethon SQLite session exists."""
        try:
            path = self._session_base() + '.session'
            return os.path.isfile(path) and os.path.getsize(path) > 0
        except Exception:
            return False

    def _mtproto_ready(self):
        # QR login is deliberately phone-less. Authorization is verified by
        # _get_client(), so an existing session is sufficient for searching.
        return bool(self._api_credentials_ready() and self._has_saved_session())

    def _extract_channel_hint(self, text):
        try:
            text = str(text or '')
            # Często nazwa grupy jest dopisana w podpisie/pliku jako @KANAL.
            handles = re.findall(r'(?<![A-Za-z0-9_])@([A-Za-z0-9_]{3,64})', text)
            if handles:
                return '@' + handles[0]
        except Exception:
            pass
        return ''

    def _clean_filename_label(self, value, limit=96):
        try:
            value = os.path.basename(str(value or '').replace('\\', '/'))
            value = unescape(value)
            value = re.sub(r'[\r\n\t]+', ' ', value)
            value = re.sub(r'\s+', ' ', value).strip(' ._-')
            return value[:limit]
        except Exception:
            return ''

    def _best_filename_label(self, msg_dict):
        try:
            fn = self._clean_filename_label((msg_dict or {}).get('filename') or '')
            if fn:
                return fn
            text = str((msg_dict or {}).get('text') or '')
            text = re.sub(r'(?<![A-Za-z0-9_])@[A-Za-z0-9_]{3,64}', ' ', text)
            text = re.sub(r'https?://\S+', ' ', text, flags=re.I)
            text = re.sub(r'[\r\n\t]+', ' ', text)
            text = re.sub(r'\s+', ' ', text).strip(' ._-')
            return self._clean_filename_label(text, limit=140)
        except Exception:
            return ''

    def _tg_chat_label(self, title, text=''):
        chat = self._display_chat_title(title)
        if not chat or chat.lower() == 'telegram':
            hint = self._extract_channel_hint(text)
            if hint:
                chat = hint
        return chat or 'Telegram'

    def _message_text_blob(self, msg):
        try:
            m = self._message_dict_from_mtproto(msg, '', '')
            return ' '.join([m.get('filename') or '', m.get('text') or ''])
        except Exception:
            try:
                return ' '.join([
                    str(getattr(getattr(msg, 'file', None), 'name', '') or ''),
                    str(getattr(msg, 'message', '') or ''),
                ])
            except Exception:
                return ''

    def _message_contains_query(self, msg, query):
        """Require the searched title word/phrase to be present in the result.

        Telegram's account-wide search can return fuzzy/broad hits, so a hit must
        contain the query we actually sent.  Do not apply a separate stop-word or
        case rule here: if a word is the selected PL/DE title word (even From/Ted),
        it is allowed.  For combined series queries every token must be present,
        e.g. "Stamtąd S04E10".
        """
        try:
            q = re.sub(r'\s+', ' ', str(query or '')).strip()
            if not q:
                return True
            blob = self._message_text_blob(msg)
            if not blob:
                return False

            tokens = re.findall(r'[0-9A-Za-ząćęłńóśżźĄĆĘŁŃÓŚŻŹÄÖÜäöüß]{2,}', q, flags=re.I)
            if not tokens:
                return True
            raw_blob = str(blob or '')
            folded_blob = self._ascii_fold(raw_blob).lower()
            norm_blob = title_matcher.normalize(raw_blob)

            for tok in tokens:
                t = str(tok or '').strip()
                if not t:
                    continue
                # Whole-token match first. This keeps short real titles valid
                # (Ted, From, It) while still rejecting random fuzzy results that
                # do not contain the searched word at all.
                pat = r'(?<![0-9A-Za-z])%s(?![0-9A-Za-z])' % re.escape(t)
                if re.search(pat, raw_blob, re.I):
                    continue
                tf = self._ascii_fold(t).lower()
                if tf:
                    pat_f = r'(?<![0-9A-Za-z])%s(?![0-9A-Za-z])' % re.escape(tf)
                    if re.search(pat_f, folded_blob, re.I):
                        continue
                nt = title_matcher.normalize(t)
                if nt and nt in norm_blob:
                    continue
                return False
            return True
        except Exception:
            return False

    def _header_text_from_message(self, msg, chat_title='', ref=''):
        try:
            m = self._message_dict_from_mtproto(msg, chat_title, ref)
            txt = m.get('text') or m.get('filename') or ''
            txt = re.sub(r'(?<![A-Za-z0-9_])@[A-Za-z0-9_]{3,64}', ' ', txt)
            txt = re.sub(r'https?://\S+', ' ', txt, flags=re.I)
            txt = re.sub(r'[\r\n\t]+', ' ', txt)
            txt = re.sub(r'\s+', ' ', txt).strip(' ._-')
            return txt[:260]
        except Exception:
            return ''

    def _series_episode_conflict(self, blob, data):
        """Return True when a Telegram hit is clearly another episode.

        We still allow unnamed/garbled files, but if the file/message contains
        an explicit SxxEyy / 1x13 / E13 token that does not match the requested
        episode, it must not be shown as a source for the current episode.
        """
        try:
            if (data or {}).get('kind') != 'series':
                return False
            s = int((data or {}).get('season') or 0)
            e = int((data or {}).get('episode') or 0)
            if s <= 0 or e <= 0:
                return False
            txt = self._ascii_fold(str(blob or ''))
            if not txt:
                return False

            pairs = []
            for a, b in re.findall(r'(?i)\bS\s*0?(\d{1,3})\s*[\._\-\s]*E\s*0?(\d{1,3})\b', txt):
                try:
                    pairs.append((int(a), int(b)))
                except Exception:
                    pass
            for a, b in re.findall(r'(?i)\b0?(\d{1,3})\s*x\s*0?(\d{1,3})\b', txt):
                try:
                    pairs.append((int(a), int(b)))
                except Exception:
                    pass

            if pairs:
                return not any((ps == s and pe == e) for ps, pe in pairs)

            # Plain E-number without season is weaker, but if it is explicit and
            # different, it is almost certainly another episode.
            eps = []
            for b in re.findall(r'(?i)(?:^|[^\w])E\s*0?(\d{1,3})(?:[^\w]|$)', txt):
                try:
                    eps.append(int(b))
                except Exception:
                    pass
            if eps and not any(pe == e for pe in eps):
                return True
            return False
        except Exception:
            return False

    def _series_episode_match_level(self, blob, data):
        """Return 3 for SxxEyy/1x02, 2 for Exx, 0 unknown, -1 conflict."""
        try:
            if (data or {}).get('kind') != 'series':
                return 0
            s = int((data or {}).get('season') or 0)
            e = int((data or {}).get('episode') or 0)
            if s <= 0 or e <= 0:
                return 0
            text = self._ascii_fold(str(blob or ''))
            pairs = []
            for a, b in re.findall(r'(?i)\bS\s*0?(\d{1,3})\s*[\._\-\s]*E\s*0?(\d{1,3})\b', text):
                pairs.append((int(a), int(b)))
            for a, b in re.findall(r'(?i)\b0?(\d{1,3})\s*x\s*0?(\d{1,3})\b', text):
                pairs.append((int(a), int(b)))
            if pairs:
                return 3 if (s, e) in pairs else -1
            episodes = [int(v) for v in re.findall(r'(?i)(?:^|[^\w])E\s*0?(\d{1,3})(?:[^\w]|$)', text)]
            if episodes:
                return 2 if e in episodes else -1
            return 0
        except Exception:
            return 0

    def _movie_year_conflict(self, blob, data):
        """Reject only a clearly different release year, not a numeric title."""
        try:
            if (data or {}).get('kind') != 'movie':
                return False
            wanted = str((data or {}).get('year') or '').strip()
            if not re.fullmatch(r'(?:19|20)\d{2}', wanted):
                return False
            years = set(re.findall(r'(?<!\d)((?:19|20)\d{2})(?!\d)', str(blob or '')))
            if not years or wanted in years:
                return False
            title_years = set()
            for variant in self._wanted_variants(data, max_items=18):
                title_years.update(re.findall(r'(?<!\d)((?:19|20)\d{2})(?!\d)', str(variant or '')))
            release_years = years - title_years
            return bool(release_years and wanted not in release_years)
        except Exception:
            return False

    def _telegram_result_score(self, blob, data, query='', query_rank=99, parent_header=None):
        """Rank broad Telegram hits without hiding uncertain filenames."""
        try:
            header_text = ''
            if isinstance(parent_header, dict):
                header_text = str(parent_header.get('text') or '')
            lookup = ' '.join([str(blob or ''), header_text]).strip()
            variants = self._wanted_variants(data, max_items=18)
            title_score = max([title_matcher.score(lookup, v) for v in variants if v] or [0])
            score = int(round(title_score))
            compact_lookup = title_matcher.compact(lookup)
            if any(
                (cv := title_matcher.compact(v)) and len(cv) >= 4 and cv in compact_lookup
                for v in variants
            ):
                score += 30
            if query:
                query_tokens = [self._ascii_fold(x).lower() for x in re.findall(r'[\wÄÖÜäöüß]+', str(query), re.UNICODE)]
                folded = self._ascii_fold(lookup).lower()
                if query_tokens and all(token in folded for token in query_tokens):
                    score += 15
            try:
                score += max(0, 8 - min(8, int(query_rank or 0)))
            except Exception:
                pass
            if (data or {}).get('kind') == 'movie':
                wanted_year = str((data or {}).get('year') or '').strip()
                if wanted_year and re.search(r'(?<!\d)%s(?!\d)' % re.escape(wanted_year), lookup):
                    score += 25
            elif (data or {}).get('kind') == 'series':
                level = self._series_episode_match_level(lookup, data)
                if level == 3:
                    score += 70
                elif level == 2:
                    score += 45
                if parent_header:
                    score += 20
            return score
        except Exception:
            return 0

    def _effective_min_file_size(self, data):
        try:
            # The settings label explicitly says "0 = no filter".  Earlier
            # builds nevertheless re-applied a hidden 100/200 MB floor here, so
            # selecting 0 could never work.  Honour the configured value exactly:
            # 0 disables only the size filter; normal video/type matching remains.
            if (data or {}).get('kind') == 'series':
                configured = int(getattr(self, 'min_series_file_size', 0) or 0)
            else:
                configured = int(getattr(self, 'min_file_size', 0) or 0)
            return max(0, configured)
        except Exception:
            return 0

    def _append_mtproto_source(self, out, msg, ent, title, ref, data, seen=None, force_match=False,
                               parent_header=None, match_query='', query_rank=99):
        try:
            if not self._message_allowed_by_topic_filter(ent, msg):
                return False
            if not self._message_has_video_file(msg):
                return False
            size_bytes = self._message_file_size(msg)
            _min_file_size = self._effective_min_file_size(data)
            if _min_file_size and size_bytes and size_bytes < _min_file_size:
                return False
            m = self._message_dict_from_mtproto(msg, title, ref)
            try:
                _blob_for_ep = ' '.join([m.get('filename') or '', m.get('text') or '', m.get('message_url') or ''])
                # Always reject a clearly different episode/year. Unnamed files
                # remain allowed, especially when attached to a matched poster.
                episode_level = self._series_episode_match_level(_blob_for_ep, data)
                if episode_level < 0 or self._movie_year_conflict(_blob_for_ep, data):
                    return False
                # Optional strict mode additionally requires an explicit episode
                # token for direct hits. Poster/album children remain contextual.
                if self.strict_episode_match and (data or {}).get('kind') == 'series' and not parent_header and episode_level <= 0:
                    return False
            except Exception:
                pass
            if not force_match and not self._message_matches(m, data):
                return False
            message_id = int(getattr(msg, 'id', 0) or 0)
            chat_id = int(getattr(ent, 'id', 0) or getattr(msg, 'chat_id', 0) or 0)
            key = (chat_id, message_id)
            if seen is not None:
                if key in seen:
                    return False
                seen.add(key)
            chat_label = self._tg_chat_label(title, ' '.join([m.get('filename') or '', m.get('text') or '']))
            file_name = self._best_filename_label(m)
            peer_type = 'channel'
            try:
                cls_name = ent.__class__.__name__.lower()
                if 'chat' in cls_name and not getattr(ent, 'access_hash', None):
                    peer_type = 'chat'
                elif getattr(ent, 'broadcast', False):
                    peer_type = 'broadcast'
                elif getattr(ent, 'megagroup', False):
                    peer_type = 'megagroup'
            except Exception:
                pass
            doc_id = ''
            doc_access_hash = ''
            doc_file_reference = ''
            doc_dc_id = ''
            try:
                doc = getattr(getattr(msg, 'media', None), 'document', None)
                if doc:
                    doc_id = str(getattr(doc, 'id', '') or '')
                    doc_access_hash = str(getattr(doc, 'access_hash', '') or '')
                    ref_bytes = getattr(doc, 'file_reference', b'') or b''
                    if ref_bytes:
                        doc_file_reference = base64.urlsafe_b64encode(ref_bytes).decode('ascii').rstrip('=')
                    doc_dc_id = str(getattr(doc, 'dc_id', '') or '')
            except Exception:
                pass
            token = self._pack({
                'mode': 'mtproto',
                'chat_id': chat_id,
                'chat_ref': ref or '',
                'chat_title': chat_label,
                'message_id': message_id,
                'peer_type': peer_type,
                'access_hash': str(getattr(ent, 'access_hash', '') or ''),
                'api_id': int(self.api_id or 0),
                # api_hash itself is not stored in the token; resolve reads settings.
                'size': int(size_bytes or 0),
                'mime': getattr(getattr(msg, 'file', None), 'mime_type', None) or 'video/mp4',
                'filename': file_name or getattr(getattr(msg, 'file', None), 'name', None) or '',
                # Direct document location for fast Range playback; fallback still
                # uses chat_id/message_id when the file_reference expires.
                'doc_id': doc_id,
                'doc_access_hash': doc_access_hash,
                'doc_file_reference': doc_file_reference,
                'doc_dc_id': doc_dc_id,
            })
            _blob = ' '.join([m.get('filename') or '', m.get('text') or ''])
            _match_score = self._telegram_result_score(
                _blob, data, query=match_query, query_rank=query_rank, parent_header=parent_header
            )
            _src = {
                'provider': 'telegram',
                'source': chat_label,
                'quality': self._quality_from_text(_blob),
                'language': self._language_from_text(_blob),
                'url': token,
                'info': self._info_from_message(m, chat_label),
                'direct': True,
                'debridonly': False,
                'debrid': '',
                'filename': file_name,
                'premium': False,
                'size': m.get('size') or self._fmt_size(size_bytes),
                'telegram_date': m.get('date') or '',
                'telegram_chat_id': str(chat_id or ''),
                'telegram_message_id': str(message_id or ''),
                'telegram_document_id': str(doc_id or ''),
                'telegram_match_score': int(_match_score or 0),
            }
            if parent_header:
                try:
                    _src['telegram_parent_header_id'] = str(parent_header.get('id') or '')
                    _src['telegram_parent_header_text'] = parent_header.get('text') or ''
                    _src['telegram_context_child'] = True
                except Exception:
                    pass
            out.append(_src)
            return True
        except Exception:
            fflog_exc(1)
            return False

    def _message_title_header_matches(self, msg, data, chat_title='', ref='', require_season=False):
        """Detect title/description posts that can act as a Telegram header.

        Channels often publish a poster/caption first and then put unnamed video
        files underneath it.  The search hits the caption, not the file, so the
        source has to scan the small block below that caption.
        """
        try:
            m = self._message_dict_from_mtproto(msg, chat_title, ref)
            blob = ' '.join([m.get('filename') or '', m.get('text') or ''])
            if not blob:
                return False

            raw_variants = self._wanted_variants(data, max_items=16)
            variants = []
            for v in raw_variants:
                for vv in ([v] + self._search_phrase_variants(v)):
                    vv = re.sub(r'\s+', ' ', str(vv or '')).strip(' ._-')
                    if vv and vv not in variants:
                        variants.append(vv)
            variants = variants[:36] or raw_variants

            score = max([title_matcher.score(blob, v) for v in variants if v] or [0])
            compact_blob = title_matcher.compact(blob)
            compact_hit = False
            for v in variants:
                cv = title_matcher.compact(v)
                if cv and len(cv) >= 8 and cv in compact_blob:
                    compact_hit = True
                    break
            if score < 55 and not compact_hit:
                return False

            nb = title_matcher.normalize(blob)
            if require_season:
                try:
                    s = int(data.get('season') or 1)
                    season_ok = bool(re.search(r'\b(?:s|season|sezon)\s*0?%d\b' % s, nb, re.I))
                except Exception:
                    season_ok = False
                return season_ok or ((score >= 84 or compact_hit) and not self._message_has_video_file(msg))

            # For movies the year is helpful, but not mandatory: many TG posts
            # have just a poster + Polish/German/English title and the file below.
            year = str((data or {}).get('year') or '').strip()
            year_ok = bool(year and re.search(r'(?<!\d)%s(?!\d)' % re.escape(year), blob))
            return year_ok or score >= 70 or compact_hit
        except Exception:
            return False

    def _series_header_matches(self, msg, data, chat_title='', ref=''):
        """Detect Telegram posts like "Szpital św. Anny sezon 1"."""
        try:
            if (data or {}).get('kind') != 'series':
                return False
            return self._message_title_header_matches(msg, data, chat_title, ref, require_season=True)
        except Exception:
            return False

    def _movie_header_matches(self, msg, data, chat_title='', ref=''):
        """Detect movie poster/caption posts with video files directly below."""
        try:
            if (data or {}).get('kind') != 'movie':
                return False
            if self._message_has_video_file(msg):
                return False
            return self._message_title_header_matches(msg, data, chat_title, ref, require_season=False)
        except Exception:
            return False

    def _context_child_allowed(self, msg, data):
        """Allow unnamed/garbled files under a matched poster, reject clear other titles.

        Poster-context scan exists for this pattern:
            poster/caption with the real title -> video messages below with no useful name.
        It must *not* attach a clearly named different movie/series, e.g. a
        "Zwierzogród 2" header followed by a file named "Troll 2 2025".
        """
        try:
            blob = self._message_text_blob(msg)
            blob = re.sub(r'\s+', ' ', str(blob or '')).strip()
            if not blob:
                return True

            # Series: explicit other SxxEyy/Eyy is always a conflict.
            if self._series_episode_conflict(blob, data):
                return False

            variants = []
            wanted_words = set()
            for v in self._wanted_variants(data, max_items=12):
                for vv in ([v] + self._search_phrase_variants(v)):
                    vv = re.sub(r'\s+', ' ', str(vv or '')).strip(' ._-')
                    if vv and vv not in variants:
                        variants.append(vv)
                    for w in re.findall(r'[A-Za-zĄĆĘŁŃÓŚŻŹąćęłńóśżźÄÖÜäöüß0-9]{3,}', vv, flags=re.I):
                        wanted_words.add(self._ascii_fold(w).lower())

            folded_blob = self._ascii_fold(blob).lower()
            norm_blob = title_matcher.normalize(blob)
            for v in variants:
                vf = self._ascii_fold(v).lower()
                vn = title_matcher.normalize(v)
                if (vf and len(vf) >= 4 and vf in folded_blob) or (vn and len(vn) >= 4 and vn in norm_blob):
                    return True

            kind = (data or {}).get('kind') or ''
            season = int((data or {}).get('season') or 0)
            episode = int((data or {}).get('episode') or 0)

            # For series, SxxEyy / Eyy / Odcinek yy under the correct header is expected.
            if kind == 'series':
                if season and episode:
                    if re.search(r'(?i)\bS0?%d\s*E0?%d\b' % (season, episode), blob):
                        return True
                    if re.search(r'(?i)\bE0?%d\b' % episode, blob):
                        return True
                    if re.search(r'(?i)\b(?:odcinek|odc|episode|ep)\.?\s*0?%d\b' % episode, blob):
                        return True
                if season and re.search(r'(?i)\bS0?%d\b' % season, blob):
                    return True

            clean = re.sub(r'\.[A-Za-z0-9]{2,5}$', '', blob)
            clean = re.sub(r'[_\\./\\[\\]\\(\\)\-]+', ' ', clean)
            words = re.findall(r'[A-Za-zĄĆĘŁŃÓŚŻŹąćęłńóśżźÄÖÜäöüß0-9]{2,}', clean, flags=re.I)
            lower_words = [self._ascii_fold(w).lower() for w in words]
            generic = set([
                'video','vid','movie','film','plik','file','document','telegram','odcinek','odc','episode','ep',
                'part','part1','part2','part3','cd1','cd2','cd3','disc1','disc2',
                'mkv','mp4','avi','xvid','x264','x265','h264','h265','hevc',
                '720p','1080p','2160p','4k','uhd','hdr','web','webrip','webdl',
                'bluray','brrip','dvdrip','proper','repack','aac','ac3','dts',
                'lektor','dubbing','napisy','pl','de','german','english','eng',
                'www','com','net','org','tv','dl','hd','sd','filmostrada','filmostradatv',
                'kino','vod','online','release','releases','rips','rip','p2p'
            ])
            content_words = [w for w in lower_words if w not in generic and not re.match(r'^\d+$', w)]

            # If there are no meaningful title-like words, this is exactly the
            # unnamed/technical child we want to keep.
            if not content_words:
                return True

            # Movie poster blocks should be strict. A named child that does not
            # contain the requested movie title is probably another movie.
            if kind == 'movie':
                if len(content_words) == 1:
                    w = content_words[0]
                    if w in wanted_words:
                        return True
                    # Allow a single long hash/random string, reject normal title
                    # words like "troll".
                    if len(w) >= 12:
                        vowels = len(re.findall(r'[aeiouyąęó]', w))
                        if float(vowels) / float(max(len(w), 1)) < 0.20:
                            return True
                    return False
                # Multiple meaningful words under a movie header look like a real
                # different filename/title, so reject.
                return False

            # Series may have odd package names; allow long random strings, but
            # reject normal named children not matching the title/episode.
            if len(content_words) <= 1:
                w = content_words[0] if content_words else ''
                if not w:
                    return True
                if len(w) >= 10:
                    vowels = len(re.findall(r'[aeiouyąęó]', w))
                    return float(vowels) / float(max(len(w), 1)) < 0.22
                return False

            joined = ''.join(content_words)
            if joined and len(joined) >= 14:
                vowels = len(re.findall(r'[aeiouyąęó]', joined))
                if float(vowels) / float(max(len(joined), 1)) < 0.20:
                    return True

            return False
        except Exception:
            # Safer default for context scan: if we cannot understand a named
            # child, do not attach it to the poster. Direct search can still find it.
            return False

    def _search_message_chat_key(self, ent):
        try:
            peer_type = type(ent).__name__ or 'peer'
            for attr in ('id', 'channel_id', 'chat_id'):
                value = int(getattr(ent, attr, 0) or 0)
                if value:
                    # Telegram's raw numeric IDs are not globally unique across
                    # all peer classes (e.g. Chat vs Channel). Keep the peer type
                    # in the cache key so messages from two different dialogs
                    # can never collide inside one search.
                    return (peer_type, value)
        except Exception:
            pass
        return ('object', id(ent))

    def _search_recent_latency(self, label):
        # 2.0.96: do not carry RPC timing predictions between searches.
        # One slow chat must never suppress context checks for another title.
        return 0.0

    def _search_context_rpc_allowed(self, label='get-messages'):
        """Guard the next *additional* context RPC against the global deadline.

        The first RPC for a header is always allowed by the caller.  After that
        we can use completed calls from this and recent searches to decide
        whether another batch has a realistic chance to finish before the
        final-result reserve.  Nothing already in flight is cancelled here.
        """
        try:
            deadline = float(getattr(self, '_search_deadline', 0.0) or 0.0)
            if deadline <= 0.0:
                return True
            reserve = max(
                0.0,
                float(getattr(self, '_search_finish_reserve', 0.0) or 0.0),
                float(getattr(self, '_search_dynamic_reserve', 0.0) or 0.0),
            )
            work_left = max(0.0, deadline - time.time() - reserve)
            predicted = max(0.0, self._search_recent_latency(label))
            minimum = max(0.75, min(3.0, float(getattr(self, '_search_min_stage_window', 2.0) or 2.0) * 0.5))
            need = max(minimum, predicted)
            if work_left < need:
                self._diag(
                    '[telegram] soft-stop przed context RPC; label=%s work_left=%.1fs predicted=%.1fs reserve=%.1fs' % (
                        label, work_left, predicted, reserve,
                    )
                )
                return False
            return True
        except Exception:
            return True

    def _search_get_messages_cached(self, client, ent, ids):
        """Read message IDs once per Telegram source search.

        The legacy 2.0.94 context scan already batches adjacent IDs. This
        read-through cache keeps exactly the same requested ID set/order while
        avoiding duplicate network reads when album and nearby/header scans
        overlap or a later fallback reaches the same post again.
        """
        try:
            requested = [int(x) for x in (ids or []) if int(x or 0) > 0]
        except Exception:
            requested = []
        if not requested:
            return []
        cache = getattr(self, '_search_message_cache', None)
        if not isinstance(cache, dict):
            cache = {}
            self._search_message_cache = cache
        chat_key = self._search_message_chat_key(ent)
        missing = []
        seen_missing = set()
        for mid in requested:
            key = (chat_key, mid)
            if key in cache:
                self._search_message_cache_hits = int(getattr(self, '_search_message_cache_hits', 0) or 0) + 1
                continue
            if mid not in seen_missing:
                seen_missing.add(mid)
                missing.append(mid)
        if missing:
            self._search_message_cache_misses = int(getattr(self, '_search_message_cache_misses', 0) or 0) + len(missing)
            fetch_ok = False
            # Within one header/context block the first network batch is allowed
            # to preserve coverage.  Before every additional batch, consult the
            # learned latency profile and the common Kadr+ deadline.
            rpc_index = int(getattr(self, '_search_context_rpc_count', 0) or 0)
            if bool(getattr(self, '_search_context_rpc_guard_active', False)) and rpc_index > 0:
                if not self._search_context_rpc_allowed('get-messages'):
                    return []
            self._search_context_rpc_count = rpc_index + 1
            rpc_started = time.time()
            try:
                fetched = client.get_messages(ent, ids=missing) or []
                rpc_elapsed = time.time() - rpc_started
                _tg_latency_record(getattr(self, '_search_latency_key', None), 'get-messages', rpc_elapsed)
                self._search_message_cache_rpcs = int(getattr(self, '_search_message_cache_rpcs', 0) or 0) + 1
                fetch_ok = True
            except Exception:
                rpc_elapsed = time.time() - rpc_started
                _tg_latency_record(getattr(self, '_search_latency_key', None), 'get-messages', rpc_elapsed)
                # A transient Telegram/MTProto failure must stay retryable.  Do
                # not poison the rest of this search by caching failed reads as
                # "message missing".
                fetched = []
            try:
                fetched = list(fetched)
            except Exception:
                fetched = [fetched]
            fetched_by_id = {}
            for msg in fetched:
                if not msg:
                    continue
                try:
                    mid = int(getattr(msg, 'id', 0) or 0)
                    if mid:
                        fetched_by_id[mid] = msg
                except Exception:
                    pass
            if fetch_ok:
                # A successful GetMessages response is authoritative for this
                # one source-search. Missing/deleted IDs can be memoized, but
                # failed RPCs above remain uncached and can be retried later.
                for mid in missing:
                    cache[(chat_key, mid)] = fetched_by_id.get(mid, _TG_MESSAGE_MISSING)
        out = []
        for mid in requested:
            msg = cache.get((chat_key, mid), _TG_MESSAGE_MISSING)
            if msg is not _TG_MESSAGE_MISSING:
                out.append(msg)
        return out

    def _search_context_key(self, ent, header_msg, data, title='', ref='', max_scan=0, max_add=0,
                            stop_on_new_header=True, allow_reverse_fallback=False):
        """Exact signature for a completed context scan.

        Dedupe is intentionally narrower than just (chat_id, message_id).  The
        same header may be revisited later with a larger max_add/window or with a
        topic-qualified title.  Those calls are *not* equivalent and must still
        run so the optimized code cannot reduce 2.0.94 coverage.
        """
        try:
            chat_id = self._search_message_chat_key(ent)
            message_id = int(getattr(header_msg, 'id', 0) or 0)
            kind = str((data or {}).get('kind') or '')
            if chat_id and message_id:
                return (
                    chat_id, message_id, kind, str(title or ''), str(ref or ''),
                    int(max_scan or 0), int(max_add or 0),
                    bool(stop_on_new_header), bool(allow_reverse_fallback),
                )
        except Exception:
            pass
        return None

    def _search_context_is_done(self, ent, header_msg, data, title='', ref='', max_scan=0, max_add=0,
                                stop_on_new_header=True, allow_reverse_fallback=False):
        key = self._search_context_key(
            ent, header_msg, data, title, ref, max_scan, max_add,
            stop_on_new_header, allow_reverse_fallback,
        )
        return bool(key and key in getattr(self, '_search_context_scanned', set()))

    def _search_context_mark_done(self, ent, header_msg, data, title='', ref='', max_scan=0, max_add=0,
                                  stop_on_new_header=True, allow_reverse_fallback=False, deadline=None, added=0):
        # Never memoize a scan that ran out of its local budget. A later fallback
        # must be allowed to retry it. Reaching max_add is complete for this exact
        # signature only; a later call with a larger max_add has a different key.
        try:
            complete = bool(int(added or 0) >= int(max_add or 0) > 0)
            if not complete:
                complete = deadline is None or time.time() < float(deadline)
            key = self._search_context_key(
                ent, header_msg, data, title, ref, max_scan, max_add,
                stop_on_new_header, allow_reverse_fallback,
            )
            if complete and key:
                self._search_context_scanned.add(key)
        except Exception:
            pass

    def _message_grouped_id(self, msg):
        try:
            gid = getattr(msg, 'grouped_id', None)
            if gid:
                return str(gid)
        except Exception:
            pass
        return ''

    def _reply_topic_id_from_message(self, msg):
        """Return a numeric Telegram forum-topic id, never the boolean forum flag.

        Telethon exposes reply_to.forum_topic as a bool in some cases. Older code
        treated True as topic id 1, which could incorrectly reject nearby files in
        real topic groups.  When the numeric top id is missing, be permissive and
        return 0 instead of inventing a topic.
        """
        try:
            rr = getattr(msg, 'reply_to', None)
            if not rr:
                return 0
            for attr in ('reply_to_top_id', 'top_msg_id'):
                val = getattr(rr, attr, None)
                if val and not isinstance(val, bool):
                    try:
                        return int(val)
                    except Exception:
                        pass
            # For a direct post in a forum topic Telegram may omit top_id and keep
            # only reply_to_msg_id.  Use it only when forum_topic is explicitly set.
            if bool(getattr(rr, 'forum_topic', False)):
                val = getattr(rr, 'reply_to_msg_id', None)
                if val and not isinstance(val, bool):
                    try:
                        return int(val)
                    except Exception:
                        pass
            return 0
        except Exception:
            return 0

    def _append_album_video_group(self, client, out, ent, title, ref, data, header_msg, seen=None, max_add=10, deadline=None):
        """Add video siblings from the same Telegram media album/group.

        Telegram often stores one visual post as a media album: poster/photo with
        caption + video tile in the same grouped_id. In the app it looks like one
        post, not "messages below". The older context scan only checked messages
        after/before the header, so album video siblings could be missed.
        """
        try:
            header_id = int(getattr(header_msg, 'id', 0) or 0)
            gid = self._message_grouped_id(header_msg)
            if not header_id or not gid or max_add <= 0:
                return 0
            if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                return 0
            # A Telegram media album has adjacent message IDs and at most a small
            # number of cells.  The old +/-48 scan issued as many as 13 separate
            # RPCs for one poster; on the device trace that made a nominal 2.4 s
            # header scan last 24.7 s and starved all later candidates.  One
            # bounded GetMessages request covers the complete album plus a small
            # safety margin, while grouped_id still prevents unrelated files from
            # being attached to the poster.
            lo = max(1, header_id - 12)
            hi = header_id + 13
            msg_by_id = {}
            ids_all = list(range(lo, hi))
            try:
                msgs_near = self._search_get_messages_cached(client, ent, ids_all) or []
            except Exception:
                msgs_near = []
            try:
                msgs_near = list(msgs_near)
            except Exception:
                msgs_near = [msgs_near]
            for m in msgs_near:
                if not m:
                    continue
                try:
                    msg_by_id[int(getattr(m, 'id', 0) or 0)] = m
                except Exception:
                    pass

            added = 0
            for near in [msg_by_id.get(i) for i in ids_all]:
                if not near:
                    continue
                try:
                    if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                        break
                    if added >= max_add:
                        break
                    if int(getattr(near, 'id', 0) or 0) == header_id:
                        continue
                    if self._message_grouped_id(near) != gid:
                        continue
                    if not self._message_has_video_file(near):
                        continue
                    if not self._context_child_allowed(near, data):
                        continue
                    parent_header = {
                        'id': header_id,
                        'text': self._header_text_from_message(header_msg, title, ref),
                    }
                    if self._append_mtproto_source(out, near, ent, title, ref, data, seen, force_match=True, parent_header=parent_header):
                        try:
                            self._diag('[telegram] album group match kind=%s header_id=%s video_msg=%s gid=%s' % ((data or {}).get('kind') or '', header_id, getattr(near, 'id', ''), gid))
                        except Exception:
                            pass
                        added += 1
                except Exception:
                    continue
            return added
        except Exception:
            fflog_exc(1)
            return 0

    def _append_nearby_video_block(self, client, out, ent, title, ref, data, header_msg, seen=None, max_scan=40, max_add=10, stop_on_new_header=True, allow_reverse_fallback=False, deadline=None):
        try:
            header_id = int(getattr(header_msg, 'id', 0) or 0)
            if not header_id or max_add <= 0:
                return 0
            if self._search_context_is_done(ent, header_msg, data, title, ref, max_scan, max_add, stop_on_new_header, allow_reverse_fallback):
                self._search_message_cache_hits = int(getattr(self, '_search_message_cache_hits', 0) or 0) + 1
                return 0
            header_topic = self._reply_topic_id_from_message(header_msg)

            def same_topic(m):
                # Be strict only when both sides expose a numeric topic id. If one
                # message only has forum_topic=True, do not treat True as id=1.
                try:
                    if not header_topic:
                        return True
                    top = self._reply_topic_id_from_message(m)
                    if not top:
                        return True
                    return int(top or 0) == int(header_topic or 0)
                except Exception:
                    return True

            def is_new_header(m):
                try:
                    if self._message_has_video_file(m):
                        return False
                    txt = (getattr(m, 'message', None) or '').strip()
                    if len(txt) < 20:
                        return False
                    if (data or {}).get('kind') == 'series':
                        return self._series_header_matches(m, data, title, ref)
                    return self._movie_header_matches(m, data, title, ref)
                except Exception:
                    return False

            if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                return 0

            def append_near(near, parent_header, added):
                try:
                    if added >= max_add:
                        return added
                    if int(getattr(near, 'id', 0) or 0) == header_id:
                        return added
                    if not same_topic(near):
                        return added
                    if not self._message_has_video_file(near):
                        return added
                    if not self._context_child_allowed(near, data):
                        return added
                    if self._append_mtproto_source(out, near, ent, title, ref, data, seen, force_match=True, parent_header=parent_header):
                        try:
                            self._diag('[telegram] context block match kind=%s header_id=%s video_msg=%s' % ((data or {}).get('kind') or '', header_id, getattr(near, 'id', '')))
                        except Exception:
                            pass
                        return added + 1
                except Exception:
                    pass
                return added

            parent_header = {
                'id': header_id,
                'text': self._header_text_from_message(header_msg, title, ref),
            }

            # Album/grouped_id first: required for posts like poster + video tile
            # (e.g. Krzyk 7). Keep it before the generic neighbour scan.
            album_added = self._append_album_video_group(client, out, ent, title, ref, data, header_msg, seen, max_add=max_add, deadline=deadline)
            added_total = int(album_added or 0)
            if added_total >= max_add:
                self._search_context_mark_done(ent, header_msg, data, title, ref, max_scan, max_add, stop_on_new_header, allow_reverse_fallback, deadline, added_total)
                return added_total

            # 2.42.00: do not let one slow header consume the entire poster budget.
            # Telethon iter_messages(min_id=..., reverse=True) can block for many seconds
            # in large/closed topic groups.  For header/context posts the video files are
            # normally adjacent by message id, so fetch a bounded id window in chunks.
            # This restores the .88 behaviour for "Szpital św. Anny": several header
            # candidates are actually checked, instead of scanned=1 added=0.
            def scan_id_window(direction=1):
                added = 0
                try:
                    # Series blocks can contain a whole season, films usually only 1-3 files.
                    span = int(max_scan or 1)
                    if (data or {}).get('kind') == 'series':
                        span = max(span, 100)
                    else:
                        span = min(max(span, 16), 60)
                    span = min(span, 180)
                    ids = []
                    if direction >= 0:
                        ids = list(range(header_id + 1, header_id + span + 1))
                    else:
                        lo = max(1, header_id - span)
                        ids = list(range(header_id - 1, lo - 1, -1))
                    # GetMessages accepts a bounded list of IDs in one RPC.  A
                    # 24-message batch keeps the same physical-neighbour search,
                    # but avoids paying network latency eight times for a movie
                    # poster before the deadline can even be checked.
                    chunk_size = 24
                    passed = 0
                    for off in range(0, len(ids), chunk_size):
                        if added_total + added >= max_add:
                            break
                        if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                            break
                        chunk = ids[off:off + chunk_size]
                        try:
                            msgs = self._search_get_messages_cached(client, ent, chunk) or []
                        except Exception:
                            msgs = []
                        try:
                            msgs = list(msgs)
                        except Exception:
                            msgs = [msgs]
                        # Preserve physical order under/above the header.
                        msg_by_id = {}
                        for m in msgs:
                            if m:
                                try:
                                    msg_by_id[int(getattr(m, 'id', 0) or 0)] = m
                                except Exception:
                                    pass
                        for mid in chunk:
                            if added_total + added >= max_add:
                                break
                            if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                                break
                            near = msg_by_id.get(int(mid))
                            if not near:
                                continue
                            if not same_topic(near):
                                continue
                            # Stop only after seeing actual non-video content past the header.
                            # Do not stop on the first unrelated poster if no video was seen yet;
                            # some Telegram posts insert images/text between caption and files.
                            if stop_on_new_header and passed and is_new_header(near):
                                break
                            passed += 1
                            before = added
                            added = append_near(near, parent_header, added)
                            # For movies, after one matching file, avoid accidentally pulling
                            # the next unrelated movie block. Series may continue collecting.
                            if (data or {}).get('kind') == 'movie' and added > before:
                                if added_total + added >= max_add:
                                    break
                    return added
                except Exception:
                    return added

            remaining_add = max(0, int(max_add or 0) - int(added_total or 0))
            if remaining_add > 0:
                old_max_add = max_add
                try:
                    max_add = remaining_add
                    # First scan messages after the header; then, if needed, the older side.
                    added_total += scan_id_window(direction=1)
                    if added_total < old_max_add and allow_reverse_fallback:
                        max_add = old_max_add - added_total
                        added_total += scan_id_window(direction=-1)
                finally:
                    max_add = old_max_add

            if added_total:
                self._search_context_mark_done(ent, header_msg, data, title, ref, max_scan, max_add, stop_on_new_header, allow_reverse_fallback, deadline, added_total)
                return added_total

            # Do not use the old unbounded iter_messages fallback for series
            # headers. On large topic groups it can block inside Telethon longer than
            # our deadline can be checked, which is exactly what caused scanned=1.
            # Movies are protected by album + small id-window; keep a tiny fallback only
            # if there is still enough per-header time left.
            if (data or {}).get('kind') == 'series':
                self._search_context_mark_done(ent, header_msg, data, title, ref, max_scan, max_add, stop_on_new_header, allow_reverse_fallback, deadline, added_total)
                return added_total

            def scan(reverse=True):
                added = 0
                passed = 0
                kwargs = {'limit': 8}
                if reverse:
                    kwargs.update({'min_id': header_id, 'reverse': True})
                else:
                    kwargs.update({'max_id': header_id})
                for near in client.iter_messages(ent, **kwargs):
                    try:
                        if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                            break
                        if added >= max_add:
                            break
                        if int(getattr(near, 'id', 0) or 0) == header_id:
                            continue
                        if not same_topic(near):
                            continue
                        if stop_on_new_header and passed and is_new_header(near):
                            break
                        passed += 1
                        added = append_near(near, parent_header, added)
                    except Exception:
                        continue
                return added

            remaining_add = max(0, int(max_add or 0) - int(added_total or 0))
            if remaining_add > 0 and (deadline is None or time.time() + 1.5 < float(deadline)):
                old_max_add = max_add
                try:
                    max_add = remaining_add
                    added_total += scan(reverse=True)
                    if added_total < old_max_add and allow_reverse_fallback and (deadline is None or time.time() + 1.5 < float(deadline)):
                        max_add = old_max_add - added_total
                        added_total += scan(reverse=False)
                finally:
                    max_add = old_max_add
            self._search_context_mark_done(ent, header_msg, data, title, ref, max_scan, max_add, stop_on_new_header, allow_reverse_fallback, deadline, added_total)
            return added_total
        except Exception:
            fflog_exc(1)
            return 0

    def _append_series_nearby_videos(self, client, out, ent, title, ref, data, header_msg, seen=None, max_scan=80, max_add=30, deadline=None):
        try:
            if (data or {}).get('kind') != 'series' or not header_msg:
                return 0
            # Show a block of episodes below the matched header instead of only
            # guessing the requested episode number. The user wants broad raw TG
            # results and will choose manually.
            return self._append_nearby_video_block(client, out, ent, title, ref, data, header_msg, seen, max_scan=max_scan, max_add=max_add, stop_on_new_header=True, allow_reverse_fallback=True, deadline=deadline)
        except Exception:
            fflog_exc(1)
            return 0

    def _append_movie_nearby_videos(self, client, out, ent, title, ref, data, header_msg, seen=None, max_scan=40, max_add=3, deadline=None):
        try:
            if (data or {}).get('kind') != 'movie' or not header_msg:
                return 0
            # Movie posts are usually one file, sometimes CD1/CD2/CD3. Keep this
            # small so a poster hit does not pull an unrelated channel block.
            return self._append_nearby_video_block(client, out, ent, title, ref, data, header_msg, seen, max_scan=max_scan, max_add=max_add, stop_on_new_header=True, allow_reverse_fallback=True, deadline=deadline)
        except Exception:
            fflog_exc(1)
            return 0

    def _query_looks_german(self, value):
        try:
            v = str(value or '').lower()
            if re.search(r'[äöüß]', v):
                return True
            if self._looks_german_title(v):
                return True
            return bool(re.search(r'\b(?:drachen|zahmen|zaehmen|deutsch|german|filme|kino)\b', v, re.I))
        except Exception:
            return False

    def _sources_mtproto(self, data):
        out = []
        if self._cancelled():
            return out
        if not _tg_claim_search(self):
            return out
        # Keep the proven .88 search semantics: connection/dialog discovery is
        # separate from the configured scan budget and Telethon iterators are not
        # cancelled underneath a running fallback stage.
        client = self._get_client(interactive=self.login_on_search)
        if not client:
            if not self.login_on_search:
                fflog('[telegram] nie zalogowano - użyj przycisku w ustawieniach Telegram', 1)
            _tg_close_current_loop()
            _tg_release_search(self)
            return out
        try:
            # Szybka ścieżka: używamy serwerowego wyszukiwania Telegrama po koncie
            # (jak w aplikacji), ale KAŻDY wynik przepuszczamy przez mapę własnych
            # dialogów. Nie pokazujemy wyników spoza konta użytkownika.
            # Od 2.41.73 nie skanujemy od razu plików spod plakatów, bo to zjadało
            # cały timeout na pierwszym wariancie tytułu i blokowało np. DE wyniki.
            started = time.time()
            self._search_message_cache = {}
            self._search_message_cache_hits = 0
            self._search_message_cache_misses = 0
            self._search_message_cache_rpcs = 0
            self._search_context_scanned = set()
            self._search_context_rpc_guard_active = False
            self._search_context_rpc_count = 0
            self._search_latency_key = None
            self._search_dynamic_reserve = 0.0
            own_deadline = started + max(0.1, float(self.search_timeout or 100.0))
            try:
                inherited_deadline = float(getattr(self, '_search_deadline', 0.0) or 0.0)
            except Exception:
                inherited_deadline = 0.0
            total_deadline = min(own_deadline, inherited_deadline) if inherited_deadline > 0.0 else own_deadline
            try:
                base_finish_reserve = max(0.0, float(getattr(self, '_search_finish_reserve', 0.0) or 0.0))
            except Exception:
                base_finish_reserve = 0.0
            try:
                configured_global = max(5.0, float(getattr(self, '_search_configured_timeout', self.search_timeout) or self.search_timeout))
            except Exception:
                configured_global = max(5.0, float(self.search_timeout or 100.0))
            try:
                min_stage_window = max(0.5, float(getattr(self, '_search_min_stage_window', 2.0) or 2.0))
            except Exception:
                min_stage_window = 2.0

            # Adaptive point-5 guard. The fixed part reserves enough time for
            # sort/history/aggregate/disconnect. The dynamic part learns from
            # the slowest completed unit in this search (query/header/forum
            # call). A slow Telegram response therefore makes the *next*
            # optional stage more conservative, while normal 2-3 s calls keep
            # almost the entire user-selected global budget available.
            slowest_unit = 0.0
            slowest_label = ''
            max_dynamic_reserve = max(base_finish_reserve, min(30.0, configured_global * 0.30))

            def _effective_finish_reserve():
                # Fixed finalization reserve only.  Do not predict future RPC
                # cost from previous/slow calls; the deadline snapshot already
                # preserves verified results when Telegram runs long.
                return base_finish_reserve

            def _work_deadline():
                # Never move beyond the authoritative parent deadline. If setup
                # consumed most of the time, the work window simply collapses.
                return max(started, float(total_deadline) - _effective_finish_reserve())

            def _remaining_total(reserve=0.0):
                try:
                    return max(0.0, float(total_deadline) - time.time() - float(reserve or 0.0))
                except Exception:
                    return 0.0

            def _remaining_work(reserve=0.0):
                try:
                    return max(0.0, _work_deadline() - time.time() - float(reserve or 0.0))
                except Exception:
                    return 0.0

            def _note_stage_unit(label, elapsed):
                # Keep measurements local for diagnostics only; they must not
                # shrink the remaining search window or affect later searches.
                nonlocal slowest_unit, slowest_label
                try:
                    elapsed = max(0.0, float(elapsed or 0.0))
                    if elapsed > slowest_unit:
                        slowest_unit = elapsed
                        slowest_label = str(label or '')
                    self._search_dynamic_reserve = base_finish_reserve
                except Exception:
                    pass

            # Start with only the fixed finalization reserve. Recent per-RPC
            # latency is consulted before starting additional context work, but
            # it does not suppress the first high-value header candidate of a
            # new title.
            self._search_dynamic_reserve = _effective_finish_reserve()

            def _optional_stage_budget(label, desired, minimum=None):
                """Budget a new optional stage without crossing the adaptive soft stop."""
                try:
                    desired = max(0.0, float(desired or 0.0))
                    available = _remaining_work()
                    threshold = min_stage_window if minimum is None else max(0.5, float(minimum))
                    threshold = min(desired, threshold) if desired > 0.0 else threshold
                    if desired <= 0.0 or available < threshold:
                        self._diag(
                            '[telegram] soft-stop przed %s; global_left=%.1fs work_left=%.1fs reserve=%.1fs need=%.1fs slowest=%s/%.1fs' % (
                                label, _remaining_total(), available, _effective_finish_reserve(), threshold,
                                slowest_label or '-', slowest_unit,
                            )
                        )
                        return 0.0
                    return min(desired, available)
                except Exception:
                    return 0.0

            queries = self._build_queries(data)
            targets = self._get_mtproto_targets(client)
            if not targets:
                fflog('[telegram] konto zalogowane, ale brak dialogów/kanałów do skanowania', 1)
                return out

            target_map = self._build_target_map(client, targets)
            seen = set()
            seen_headers = set()
            header_buckets = {}
            found_by_chat = {}

            max_queries = 10 if data.get('kind') == 'series' else 12
            # Kolejność jest istotna: seriale zaczynają od dokładnych kombinacji
            # PL/DE/EN + SxxEyy, potem przechodzą do szerokich słów tytułowych.
            # Filmy zachowują słowa PL/DE/EN jako główną metodę, a pełne frazy
            # są tylko krótkim pomocniczym ogonem. Bez losowych aliasów.
            queries_used = queries[:max_queries]
            # Niższy limit na pojedyncze zapytanie daje większą szerokość i zostawia czas
            # na pliki pod plakatami. Surowych wyników nadal nie filtrujemy po tytule.
            # Account-wide search is closest to the Telegram app search.  The old
            # per-query limit (~33) could miss valid hits that are slightly lower
            # in Telegram's ranking, e.g. a channel post with a poster/caption.
            # Keep it bounded, but let it use the configured search limit.
            # 2.42.21: nie pozwól, żeby pierwsze szerokie słowo (np. "Siedem")
            # zjadło cały szybki etap i zablokowało kolejne poprawne warianty
            # (np. "Pounds"). Każde zapytanie dostaje własny mały wycinek czasu.
            per_query_limit = min(max(40, int(self.search_limit or 100)), 150)
            # Account-wide search can block for a long time on broad words like
            # "Siedem".  Reserve real time for own-dialog/forum-topic fallback,
            # because the valid files are often inside topic groups.
            quick_budget = max(5.0, min(float(self.search_timeout) * (float(self.quick_budget_pct or 35) / 100.0), max(5.0, float(self.search_timeout) - 2.0)))
            quick_budget = min(quick_budget, _remaining_work(reserve=1.0))
            quick_deadline = time.time() + quick_budget
            quick_per_query_budget = max(4.0, min(12.0, (quick_budget / float(max(1, len(queries_used)))) + 1.0))
            _eff_min_mb = int(self._effective_min_file_size(data) / (1024 * 1024)) if self._effective_min_file_size(data) else 0
            _topic_map_diag = self._selected_topic_map()
            _topic_group_count = len(_topic_map_diag)
            _topic_selected_count = sum(len(v) for v in _topic_map_diag.values())
            self._diag('[telegram] szybkie wyszukiwanie po koncie, filtrowane do własnych dialogów; queries=%s targets=%s limit=%s min_size=%sMB quick_budget=%.1fs per_q=%.1fs max_results=%s max_per_chat=%s topic_budget=%ss topic_scan_limit=%s fallback_budget=%ss headers=%s context_budget=%ss topic_filter_groups=%s selected_topics=%s' % (len(queries_used), len(targets), per_query_limit, _eff_min_mb, quick_budget, quick_per_query_budget, self.max_results, self.max_per_chat, self.topic_budget, self.topic_scan_limit, self.dialog_fallback_budget, self.max_context_headers, getattr(self, 'context_budget', 14), _topic_group_count, _topic_selected_count))
            try:
                self._diag('[telegram] zapytania: %s' % ', '.join([repr(q) for q in queries_used]))
            except Exception:
                pass

            def chat_key_for(ent, title):
                return str(getattr(ent, 'id', '') or title)

            def remember_header(q_idx, msg, ent, title, ref):
                try:
                    message_id = int(getattr(msg, 'id', 0) or 0)
                    chat_id = int(getattr(ent, 'id', 0) or getattr(msg, 'chat_id', 0) or 0)
                    if not message_id or not chat_id:
                        return False
                    key = (chat_id, message_id)
                    if key in seen_headers:
                        return False
                    if self._series_header_matches(msg, data, title, ref) or self._movie_header_matches(msg, data, title, ref):
                        seen_headers.add(key)
                        header_buckets.setdefault(int(q_idx or 0), []).append((msg, ent, title, ref))
                        return True
                except Exception:
                    pass
                return False

            def process_msg(q_idx, msg, ent, title, ref, collect_header=True, query=''):
                try:
                    if not self._message_allowed_by_topic_filter(ent, msg):
                        return 0
                    # Nie ufaj ślepo serwerowemu searchowi Telegrama: wynik musi naprawdę
                    # zawierać aktualnie szukane słowo/frazę.  Dzięki temu nie wpadają
                    # losowe pliki z kanału, które nie mają nic wspólnego ze Stamtąd/FROM.
                    if query and not self._message_contains_query(msg, query):
                        if collect_header:
                            return 0
                        return 0
                    chat_key = chat_key_for(ent, title)
                    if found_by_chat.get(chat_key, 0) >= self.max_per_chat:
                        return 0
                    if self._append_mtproto_source(
                        out, msg, ent, title, ref, data, seen, force_match=True,
                        match_query=query, query_rank=q_idx,
                    ):
                        found_by_chat[chat_key] = found_by_chat.get(chat_key, 0) + 1
                        # Publish immediately after a validated direct hit.  If a
                        # later optional MTProto call stalls past the common
                        # deadline, the scheduler can still return this exact hit.
                        self._publish_timeout_snapshot(out, data, 'direct')
                        return 1
                    if collect_header:
                        remember_header(q_idx, msg, ent, title, ref)
                except Exception:
                    pass
                return 0

            # Context budget is shared by both passes below.  We first inspect
            # header/poster candidates already returned by Telegram's account-wide
            # search, then run the legacy short dialog fallback, and finally spend
            # only the *unused* context budget on any new headers found there.
            # This changes priority, not the matcher/query set or the total header
            # cap: high-value known candidates no longer wait behind a fixed 10 s
            # dialog pass, while legacy fallback coverage is still available.
            context_header_cap = int(self.max_context_headers or 32)
            if data.get('kind') == 'movie':
                context_header_cap = min(context_header_cap, 24)
            context_setting = float(getattr(self, 'context_budget', 18) or 0)
            if data.get('kind') == 'series' and context_setting > 0:
                context_setting = max(18.0, context_setting)
            context_spent = 0.0
            context_started_keys = set()
            context_scanned_total = 0
            context_added_total = 0

            def _ordered_header_candidates():
                ordered = []
                try:
                    max_depth = max([len(v) for v in header_buckets.values()] or [0])
                    for pos in range(max_depth):
                        for q_idx in range(len(queries_used)):
                            bucket = header_buckets.get(q_idx) or []
                            if pos < len(bucket):
                                ordered.append(bucket[pos])
                except Exception:
                    pass
                return ordered

            def _header_identity(ent, msg):
                try:
                    return (
                        type(ent).__name__,
                        int(getattr(ent, 'id', 0) or getattr(msg, 'chat_id', 0) or 0),
                        int(getattr(msg, 'id', 0) or 0),
                    )
                except Exception:
                    return ('object', id(ent), id(msg))

            def _run_context_pass(stage_label):
                nonlocal context_spent, context_scanned_total, context_added_total
                header_total = sum(len(v) for v in header_buckets.values())
                if not header_total or context_setting <= 0 or context_scanned_total >= context_header_cap:
                    return 0
                remaining_context = max(0.0, context_setting - context_spent)
                if remaining_context <= 0.0:
                    return 0
                pass_budget = _optional_stage_budget(
                    stage_label, min(remaining_context, _remaining_work())
                )
                if pass_budget <= 0.0:
                    return 0
                pass_started = time.time()
                pass_deadline = min(_work_deadline(), pass_started + pass_budget)
                pass_scanned = 0
                pass_added = 0
                self._diag(
                    '[telegram] %s: candidates=%s budget=%.1fs cap_left=%s' % (
                        stage_label, header_total, pass_budget,
                        max(0, context_header_cap - context_scanned_total),
                    )
                )
                for msg, ent, title, ref in _ordered_header_candidates():
                    if self._cancelled() or len(out) >= self.max_results or time.time() >= pass_deadline or _remaining_work() <= 0:
                        break
                    if context_scanned_total >= context_header_cap:
                        break
                    ident = _header_identity(ent, msg)
                    if ident in context_started_keys:
                        continue
                    chat_key = chat_key_for(ent, title)
                    remaining = max(0, self.max_per_chat - int(found_by_chat.get(chat_key, 0) or 0))
                    if remaining <= 0:
                        continue

                    per_header = 3.2 if data.get('kind') == 'series' else 2.4
                    work_left = _remaining_work()
                    if work_left < min(per_header, min_stage_window):
                        self._diag('[telegram] soft-stop w skanie plakatów; work_left=%.1fs' % work_left)
                        break

                    # The first high-value header in a search is always allowed.
                    # Before every later header, use recent *real* device latency
                    # for this account/filter signature.  A 29 s stall observed in
                    # one search therefore prevents starting another 29 s gamble
                    # when only e.g. 20 s of the user's global budget remains.
                    predicted_header = max(0.0, self._search_recent_latency('header'))
                    if context_scanned_total > 0 and predicted_header > 0.0 and out:
                        predicted_need = predicted_header * 1.10 + 1.0
                        if work_left < max(min_stage_window, predicted_need):
                            self._diag(
                                '[telegram] soft-stop przed nowym header RPC; work_left=%.1fs predicted=%.1fs need=%.1fs' % (
                                    work_left, predicted_header, predicted_need,
                                )
                            )
                            break

                    context_started_keys.add(ident)
                    context_scanned_total += 1
                    pass_scanned += 1
                    header_deadline = min(float(pass_deadline), _work_deadline(), time.time() + per_header)
                    header_id_dbg = int(getattr(msg, 'id', 0) or 0)
                    try:
                        self._diag('[telegram] header scan start %s/%s id=%s chat=%s per=%.1fs' % (
                            context_scanned_total, header_total, header_id_dbg, title,
                            max(0.0, header_deadline - time.time()),
                        ))
                    except Exception:
                        pass
                    h_started = time.time()
                    added = 0
                    self._search_context_rpc_guard_active = True
                    self._search_context_rpc_count = 0
                    try:
                        if self._series_header_matches(msg, data, title, ref):
                            added = self._append_series_nearby_videos(
                                client, out, ent, title, ref, data, msg, seen,
                                max_add=min(int(getattr(self, 'series_context_files', 30) or 0), remaining),
                                deadline=header_deadline,
                            )
                        elif self._movie_header_matches(msg, data, title, ref):
                            added = self._append_movie_nearby_videos(
                                client, out, ent, title, ref, data, msg, seen,
                                max_add=min(int(getattr(self, 'movie_context_files', 3) or 0), remaining),
                                deadline=header_deadline,
                            )
                    finally:
                        self._search_context_rpc_guard_active = False
                        self._search_context_rpc_count = 0
                    h_elapsed = time.time() - h_started
                    _note_stage_unit('header', h_elapsed)
                    try:
                        self._diag('[telegram] header scan end id=%s added=%s elapsed=%.1fs' % (header_id_dbg, added, h_elapsed))
                    except Exception:
                        pass
                    if added:
                        pass_added += int(added or 0)
                        context_added_total += int(added or 0)
                        found_by_chat[chat_key] = found_by_chat.get(chat_key, 0) + int(added or 0)
                        self._publish_timeout_snapshot(out, data, stage_label)

                context_spent += max(0.0, time.time() - pass_started)
                self._diag(
                    '[telegram] %s end: scanned=%s added=%s total_scanned=%s total_added=%s spent=%.1fs/%.1fs' % (
                        stage_label, pass_scanned, pass_added, context_scanned_total,
                        context_added_total, context_spent, context_setting,
                    )
                )
                return pass_added

            # 1) Szybkie wyszukiwanie po koncie: najpierw zbieramy bezpośrednie
            # pliki i same nagłówki/plakaty. Kontekst spod plakatów skanujemy dopiero
            # po przejściu wszystkich wariantów PL/DE/EN.
            for q_idx, q in enumerate(queries_used):
                if self._cancelled() or len(out) >= self.max_results:
                    break
                if time.time() >= quick_deadline or _remaining_work() <= 0:
                    self._diag('[telegram] kończę szybki skan po %.1fs, zostawiam czas na plakaty/fallback' % (time.time() - started))
                    break
                query_deadline = min(quick_deadline, time.time() + quick_per_query_budget)
                q_added_before = len(out)
                q_headers_before = sum(len(v) for v in header_buckets.values())
                q_started = time.time()
                try:
                    for msg in client.iter_messages(None, search=q, limit=per_query_limit):
                        if self._cancelled() or len(out) >= self.max_results or time.time() >= query_deadline or time.time() >= quick_deadline:
                            break
                        target = self._target_for_message(msg, target_map)
                        if not target:
                            # Twardy filtr: żadnych wyników spoza dialogów konta.
                            continue
                        ent, title, ref = target
                        process_msg(q_idx, msg, ent, title, ref, collect_header=True, query=q)
                except Exception:
                    fflog_exc(1)
                    continue
                q_elapsed = time.time() - q_started
                _note_stage_unit('quick-query', q_elapsed)
                try:
                    q_headers_after = sum(len(v) for v in header_buckets.values())
                    self._diag('[telegram] quick query %r end; added=%s headers=%s elapsed=%.1fs' % (q, len(out)-q_added_before, q_headers_after-q_headers_before, time.time()-started))
                except Exception:
                    pass

            # Do NOT return merely because account-wide search found *something*.
            # In .57 the dialog/topic/context fallbacks still run and can reveal a
            # better channel post (for example the known Krzyk 7 / Scream 7 case).
            # Stage/total budgets below decide whether another fallback begins;
            # collected direct hits remain in ``out`` throughout the scan.

            # 2) Najpierw sprawdź kontekst nagłówków/plakatów już znalezionych
            # przez szybki account-wide search.  To usuwa stałe ~10 s oczekiwania
            # przed najbardziej obiecującymi kandydatami, bez zmiany matcherów.
            self._publish_timeout_snapshot(out, data, 'quick')
            _run_context_pass('context-quick')

            # 3) Krótki fallback po własnych dialogach. To przywraca zachowanie ze
            # starszych wersji dla kanałów/grup, których serwerowe account-search nie
            # zwraca wysoko. Priorytet mają niemieckie słowa, bo tam było widać regres.
            try:
                if len(out) < self.max_results and _remaining_work() > 0:
                    de_idxs = [i for i, q in enumerate(queries_used) if self._query_looks_german(q)]
                    first_idxs = list(range(min(5, len(queries_used))))
                    ordered_idxs = []
                    for i in first_idxs + de_idxs:
                        if i not in ordered_idxs:
                            ordered_idxs.append(i)
                    if ordered_idxs:
                        fallback_started = time.time()
                        fallback_setting = float(getattr(self, 'dialog_fallback_budget', 10) or 0)
                        fallback_desired = max(8.0, fallback_setting) if fallback_setting > 0 else 0.0
                        fallback_budget = _optional_stage_budget('dialog-fallback-1', fallback_desired)
                        if fallback_budget <= 0:
                            ordered_idxs = []
                        self._diag('[telegram] krótki fallback po własnych dialogach; query_idx=%s budget=%.1fs' % (ordered_idxs, fallback_budget))
                        # Fair fallback: dla każdego wysoko ocenionego dialogu spróbuj
                        # wszystkich zapytań krótko, zamiast mielić najpierw samo PL.
                        for ent, title, ref in targets:
                            if self._cancelled() or len(out) >= self.max_results or time.time() - fallback_started > fallback_budget or _remaining_work() <= 0:
                                break
                            chat_key = chat_key_for(ent, title)
                            if found_by_chat.get(chat_key, 0) >= self.max_per_chat:
                                continue
                            for q_idx in ordered_idxs:
                                if self._cancelled() or len(out) >= self.max_results or time.time() - fallback_started > fallback_budget or _remaining_work() <= 0:
                                    break
                                q = queries_used[q_idx]
                                fallback_call_started = time.time()
                                try:
                                    for msg in client.iter_messages(ent, search=q, limit=min(max(6, int(self.search_limit or 100) // 12), 12)):
                                        if self._cancelled() or len(out) >= self.max_results or time.time() - fallback_started > fallback_budget or _remaining_work() <= 0:
                                            break
                                        process_msg(q_idx, msg, ent, title, ref, collect_header=True, query=q)
                                except Exception:
                                    pass
                                finally:
                                    _note_stage_unit('dialog-query', time.time() - fallback_call_started)
            except Exception:
                pass


            # 3b) Dialog fallback mógł dorzucić nowe nagłówki.  Zużyj na nie
            # wyłącznie niewykorzystaną część tego samego context budget/cap.
            self._publish_timeout_snapshot(out, data, 'dialog-fallback-1')
            _run_context_pass('context-post-dialog')

            # 4) Fallback dla tematów/forum. Część supergrup nie oddaje
            # wyników z topiców w zwykłym account-search.  Sprawdzamy wszystkie
            # własne dialogi-fora, nie tylko pierwszych kilkadziesiąt, ale pilnujemy
            # limitu czasu.
            if len(out) < self.max_results and _remaining_work() > 0:
                try:
                    topic_started = time.time()
                    topic_setting = float(getattr(self, 'topic_budget', 12) or 0)
                    topic_budget = _optional_stage_budget('topics', max(10.0, topic_setting) if topic_setting > 0 else 0.0)
                    topic_queries = queries_used[:min(5, len(queries_used))]
                    self._diag('[telegram] fallback topiców/forum; queries=%s targets=%s budget=%.1fs' % (len(topic_queries), len(targets), topic_budget))
                    # Fair topic fallback: nie mielimy wszystkich forów dla jednego
                    # szerokiego słowa. W każdym forum próbujemy kolejno PL/DE/EN.
                    for ent, title, ref in targets:
                        if self._cancelled() or len(out) >= self.max_results or _remaining_work() <= 0 or time.time() - topic_started > topic_budget:
                            break
                        if not getattr(ent, 'forum', False):
                            continue
                        chat_key = chat_key_for(ent, title)
                        if found_by_chat.get(chat_key, 0) >= self.max_per_chat:
                            continue
                        for q_idx, q in enumerate(topic_queries):
                            if self._cancelled() or len(out) >= self.max_results or _remaining_work() <= 0 or time.time() - topic_started > topic_budget:
                                break
                            topic_call_started = time.time()
                            added_topic = self._search_forum_topics(client, out, ent, title, ref, q, data, seen, found_by_chat.get(chat_key, 0), self.max_per_chat, deadline=min(topic_started + topic_budget, _work_deadline()))
                            _note_stage_unit('topic-query', time.time() - topic_call_started)
                            if added_topic:
                                found_by_chat[chat_key] = found_by_chat.get(chat_key, 0) + added_topic
                                self._publish_timeout_snapshot(out, data, 'topics')
                except Exception:
                    pass

            # 4b) Krótki fallback po własnych dialogach, ale dopiero PO plakatach.
            # Używamy go głównie dla niemieckich zapytań i kanałów, których account-search
            # nie zwrócił wysoko.
            try:
                if len(out) < self.max_results and _remaining_work() > 0:
                    de_idxs = [i for i, q in enumerate(queries_used) if self._query_looks_german(q)]
                    first_idxs = list(range(min(5, len(queries_used))))
                    ordered_idxs = []
                    for i in first_idxs + de_idxs:
                        if i not in ordered_idxs:
                            ordered_idxs.append(i)
                    if ordered_idxs:
                        fallback_started = time.time()
                        fallback_setting = float(getattr(self, 'dialog_fallback_budget', 10) or 0)
                        fallback_desired = max(8.0, fallback_setting) if fallback_setting > 0 else 0.0
                        fallback_budget = _optional_stage_budget('dialog-fallback-2', fallback_desired)
                        if fallback_budget <= 0:
                            ordered_idxs = []
                        self._diag('[telegram] krótki fallback po własnych dialogach po plakatach; query_idx=%s budget=%.1fs' % (ordered_idxs, fallback_budget))
                        for ent, title, ref in targets:
                            if self._cancelled() or len(out) >= self.max_results or _remaining_work() <= 0 or time.time() - fallback_started > fallback_budget:
                                break
                            chat_key = chat_key_for(ent, title)
                            if found_by_chat.get(chat_key, 0) >= self.max_per_chat:
                                continue
                            for q_idx in ordered_idxs:
                                if self._cancelled() or len(out) >= self.max_results or _remaining_work() <= 0 or time.time() - fallback_started > fallback_budget:
                                    break
                                q = queries_used[q_idx]
                                fallback_call_started = time.time()
                                try:
                                    for msg in client.iter_messages(ent, search=q, limit=min(max(5, int(self.search_limit or 100) // 15), 10)):
                                        if self._cancelled() or len(out) >= self.max_results or _remaining_work() <= 0 or time.time() - fallback_started > fallback_budget:
                                            break
                                        process_msg(q_idx, msg, ent, title, ref, collect_header=True, query=q)
                                except Exception:
                                    pass
                                finally:
                                    _note_stage_unit('dialog-query', time.time() - fallback_call_started)
            except Exception:
                pass
            self._publish_timeout_snapshot(out, data, 'dialog-fallback-2')

            # 5) Głębszy fallback po własnych grupach/tematach.
            # To nadal NIE zmienia koncepcji zapytań: używamy tych samych
            # najdłuższych słów z zaakceptowanych tytułów PL/DE/EN/original, bez
            # pełnych fraz. Różnica: nie uznajemy kilku znalezionych wyników za
            # powód do przerwania. Szukamy głębiej zawsze, dopóki jest budżet czasu
            # i miejsce na kolejne surowe wyniki.
            try:
                if queries_used and len(out) < self.max_results:
                    rescue_started = time.time()
                    # Point 5: deep fallback is optional and may no longer consume
                    # the final seconds reserved for result/history/disconnect.
                    # Crucially, there is no max(8, remaining) here: that old shape
                    # could start an 8 s stage even when only a tiny global window
                    # remained.  Budget scales automatically with the user's common
                    # source-search timeout through the adaptive work deadline.
                    rescue_budget = _optional_stage_budget('deep-fallback', 24.0)
                    rescue_deadline = min(rescue_started + rescue_budget, _work_deadline())
                    if rescue_budget <= 0.0:
                        raise RuntimeError('soft stop before deep fallback')
                    rescue_queries = queries_used[:min(3, len(queries_used))]
                    self._diag('[telegram] deep fallback always; have=%s max=%s queries=%s budget=%.1fs' % (len(out), self.max_results, rescue_queries, rescue_budget))

                    def rescue_process(q_idx, q, msg, ent, title, ref):
                        try:
                            if not self._message_allowed_by_topic_filter(ent, msg):
                                return 0
                            if q and not self._message_contains_query(msg, q):
                                return 0
                            chat_key = chat_key_for(ent, title)
                            if found_by_chat.get(chat_key, 0) >= self.max_per_chat:
                                return 0
                            if self._append_mtproto_source(
                                out, msg, ent, title, ref, data, seen, force_match=True,
                                match_query=q, query_rank=q_idx,
                            ):
                                found_by_chat[chat_key] = found_by_chat.get(chat_key, 0) + 1
                                self._publish_timeout_snapshot(out, data, 'deep-fallback')
                                return 1
                            remaining = max(0, self.max_per_chat - int(found_by_chat.get(chat_key, 0) or 0))
                            if remaining <= 0:
                                return 0
                            added = 0
                            if self._movie_header_matches(msg, data, title, ref):
                                added = self._append_movie_nearby_videos(client, out, ent, title, ref, data, msg, seen, max_add=min(int(getattr(self, 'movie_context_files', 3) or 0), remaining), deadline=rescue_deadline)
                            elif self._series_header_matches(msg, data, title, ref):
                                added = self._append_series_nearby_videos(client, out, ent, title, ref, data, msg, seen, max_add=min(int(getattr(self, 'series_context_files', 30) or 0), remaining), deadline=rescue_deadline)
                            if added:
                                found_by_chat[chat_key] = found_by_chat.get(chat_key, 0) + int(added or 0)
                                self._diag('[telegram] deep fallback context added=%s chat=%s msg=%s' % (added, title, getattr(msg, 'id', '')))
                                self._publish_timeout_snapshot(out, data, 'deep-fallback-context')
                                return int(added or 0)
                        except Exception:
                            pass
                        return 0

                    # Najpierw tematy/forum, bo tam najczęściej giną posty publikowane
                    # w grupach podzielonych na tematy.
                    try:
                        for ent, title, ref in targets:
                            if self._cancelled() or len(out) >= self.max_results or time.time() >= rescue_deadline:
                                break
                            if not getattr(ent, 'forum', False):
                                continue
                            chat_key = chat_key_for(ent, title)
                            if found_by_chat.get(chat_key, 0) >= self.max_per_chat:
                                continue
                            for q_idx, q in enumerate(rescue_queries):
                                if self._cancelled() or len(out) >= self.max_results or time.time() >= rescue_deadline:
                                    break
                                added_topic = self._search_forum_topics(client, out, ent, title, ref, q, data, seen, found_by_chat.get(chat_key, 0), self.max_per_chat, deadline=rescue_deadline)
                                if added_topic:
                                    found_by_chat[chat_key] = found_by_chat.get(chat_key, 0) + added_topic
                    except Exception:
                        pass

                    # Potem własne dialogi bez warunku "out musi być puste".
                    try:
                        for ent, title, ref in targets:
                            if self._cancelled() or len(out) >= self.max_results or time.time() >= rescue_deadline:
                                break
                            chat_key = chat_key_for(ent, title)
                            if found_by_chat.get(chat_key, 0) >= self.max_per_chat:
                                continue
                            for q_idx, q in enumerate(rescue_queries):
                                if self._cancelled() or len(out) >= self.max_results or time.time() >= rescue_deadline:
                                    break
                                try:
                                    rescue_limit = min(max(12, int(self.search_limit or 100) // 6), 30)
                                    for msg in client.iter_messages(ent, search=q, limit=rescue_limit):
                                        if self._cancelled() or len(out) >= self.max_results or time.time() >= rescue_deadline:
                                            break
                                        rescue_process(q_idx, q, msg, ent, title, ref)
                                except Exception:
                                    continue
                    except Exception:
                        pass
                    self._diag('[telegram] deep fallback end; results=%s elapsed=%.1fs' % (len(out), time.time() - rescue_started))
            except Exception:
                pass

            self._publish_timeout_snapshot(out, data, 'scan-complete')

            # Keep all broad/uncertain hits, but place exact title/year/episode
            # matches first. Python's stable sort preserves PL/DE/EN query order
            # for equal scores.
            out.sort(key=lambda item: int((item or {}).get('telegram_match_score') or 0), reverse=True)
            self._diag('[telegram] pełny skan zakończony: results=%s elapsed=%.1fs msg_cache_hits=%s misses=%s rpcs=%s context_done=%s reserve=%.1fs global_left=%.1fs' % (
                len(out), time.time() - started,
                int(getattr(self, '_search_message_cache_hits', 0) or 0),
                int(getattr(self, '_search_message_cache_misses', 0) or 0),
                int(getattr(self, '_search_message_cache_rpcs', 0) or 0),
                len(getattr(self, '_search_context_scanned', set()) or set()),
                _effective_finish_reserve(), _remaining_total(),
            ))
        except asyncio.CancelledError:
            # CancelledError is a BaseException on Python 3.11, so the local
            # ``except Exception`` guards cannot catch it.  Preserve files that
            # were already validated instead of turning a late MTProto cancel
            # into a zero-result Telegram provider.  A real user/provider
            # cancellation is still visible through _cancelled() and the common
            # source engine keeps its own authoritative stop policy.
            self._diag(
                '[telegram] MTProto przerwał późny etap; zachowuję poprawne '
                'wyniki=%s requested=%s' % (len(out), self._cancelled())
            )
        finally:
            _tg_safe_disconnect(client)
            _tg_close_current_loop()
            _tg_release_search(self)
        return out

    def _peer_keys_for_entity(self, ent):
        keys = set()
        try:
            eid = int(getattr(ent, 'id', 0) or 0)
            if eid:
                keys.add(eid)
                keys.add(-eid)
                try:
                    keys.add(int('-100%s' % abs(eid)))
                except Exception:
                    pass
        except Exception:
            pass
        try:
            from telethon import utils
            pid = int(utils.get_peer_id(ent) or 0)
            if pid:
                keys.add(pid)
        except Exception:
            pass
        return keys

    def _peer_keys_for_message(self, msg):
        keys = set()
        try:
            cid = int(getattr(msg, 'chat_id', 0) or 0)
            if cid:
                keys.add(cid)
                keys.add(-cid)
                scid = str(abs(cid))
                if scid.startswith('100') and len(scid) > 4:
                    try:
                        keys.add(int(scid[3:]))
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            peer = getattr(msg, 'peer_id', None)
            for attr in ('channel_id', 'chat_id', 'user_id'):
                val = int(getattr(peer, attr, 0) or 0)
                if val:
                    keys.add(val)
                    keys.add(-val)
                    try:
                        keys.add(int('-100%s' % abs(val)))
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            chat = getattr(msg, 'chat', None)
            if chat:
                keys.update(self._peer_keys_for_entity(chat))
        except Exception:
            pass
        return keys

    def _build_target_map(self, client, targets):
        target_map = {}
        try:
            for ent, title, ref in targets:
                for key in self._peer_keys_for_entity(ent):
                    target_map[int(key)] = (ent, title, ref)
        except Exception:
            pass
        return target_map

    def _target_for_message(self, msg, target_map):
        try:
            for key in self._peer_keys_for_message(msg):
                if int(key) in target_map:
                    return target_map[int(key)]
        except Exception:
            pass
        return None

    def _get_client(self, interactive=False, search_mode=False):
        """Return the authorised saved Telegram client; login itself is QR-only.

        ``search_mode`` keeps one slow Telegram RPC from exceeding the user's
        whole source-search budget.  Telethon defaults to five request retries
        and may auto-sleep on FloodWait; either can turn a nominal 10-second
        fallback into tens of seconds and make the source engine discard already
        found Telegram results when its provider timeout expires.
        """
        client = None
        try:
            TelegramClient, errors, _, _, _ = _tg_telethon_imports()
            if not TelegramClient:
                control.infoDialog(L(33045, 'The Telethon library is missing from the add-on'), heading='Telegram', icon='WARNING', time=3500, sound=False)
                return None
            api_id = int(self.api_id or 0)
            api_hash = self.api_hash
            if not (api_id and api_hash):
                fflog('[telegram] brak api_id/api_hash - pomijam MTProto', 1)
                self._set_login_status(False)
                return None

            session_path = self._session_path()
            loop = _tg_ensure_event_loop()
            _tg_patch_telethon_helpers()
            _tg_bind_event_loop(loop)

            def _complete_sync_result(value, label):
                """Reject, rather than leak, an unexpected Telethon awaitable."""
                if not (asyncio.iscoroutine(value) or asyncio.isfuture(value)):
                    return value
                if not loop.is_running():
                    return loop.run_until_complete(value)
                try:
                    if asyncio.iscoroutine(value):
                        value.close()
                    else:
                        value.cancel()
                except BaseException:
                    pass
                raise RuntimeError(
                    'Telegram %s returned an awaitable on an already-running loop'
                    % label
                )

            client_kwargs = {'base_logger': _TG_TELETHON_LOGGER}
            if search_mode:
                # Pull-only search worker. One RPC gets one bounded attempt; the
                # outer Kadr+ search algorithm already has query/fallback stages
                # and can continue with the next candidate after a failed call.
                # Never let Telethon sleep/retry underneath those explicit budgets.
                client_kwargs.update({
                    'timeout': int(getattr(self, 'search_rpc_timeout', 6) or 6),
                    'request_retries': 0,
                    'connection_retries': 0,
                    'receive_updates': False,
                    'flood_sleep_threshold': 0,
                })
            client = _tg_new_client(
                TelegramClient, session_path, api_id, api_hash, loop,
                **client_kwargs,
            )
            if search_mode:
                self._search_call_method(
                    client, 'connect', timeout=self.search_rpc_timeout,
                    label='connect',
                )
            else:
                _complete_sync_result(client.connect(), 'connect')
            if search_mode:
                try:
                    authorized = bool(self._search_call_method(
                        client, 'is_user_authorized', timeout=self.search_rpc_timeout,
                        label='is-user-authorized',
                    ))
                except asyncio.TimeoutError:
                    # A transient source-search timeout is not evidence that the
                    # saved Telegram session became unauthorized.  Keep the last
                    # known login status and simply skip this provider run.
                    self._search_disconnect(client)
                    return None
            else:
                authorized = bool(_complete_sync_result(
                    client.is_user_authorized(), 'is-user-authorized',
                ))
            if authorized:
                self._set_login_status(True)
                return client

            self._set_login_status(False)
            if search_mode:
                self._search_disconnect(client)
            else:
                _tg_safe_disconnect(client)
            return None
        except BaseException as exc:
            # A search timeout/cancel is transient and must not turn a valid
            # saved QR session into "logged out".  Also retire the partially
            # connected client here; otherwise a timed-out connect can leave
            # Telethon tasks behind when the provider loop is closed.
            if search_mode:
                self._search_disconnect(client)
            if not (search_mode and isinstance(exc, asyncio.TimeoutError)):
                self._set_login_status(False)
            try:
                self._kadr_last_error = '%s: %s' % (
                    exc.__class__.__name__, str(exc),
                )
            except Exception:
                pass
            if self._is_api_id_invalid(exc, errors if 'errors' in locals() else None):
                self._show_api_id_invalid()
                return None
            fflog_exc(1)
            return None

    def _qr_login(self, client, errors=None):
        picture_open = False
        try:
            start_dc = self._client_dc_id(client)
            self._last_qr_dc_migrated = False
            control.infoDialog(L(33065, 'Telegram: preparing the login QR code'), heading='Telegram', time=3500, sound=False)
            qr = client.qr_login()
            path = self._qr_image_path()
            if self._write_qr_png(qr.url, path):
                try:
                    control.execute('ShowPicture("%s")' % path.replace('"', '').replace('\\', '/'))
                    picture_open = True
                except Exception:
                    pass
                try:
                    control.infoDialog(L(33066, 'Scan the QR code in Telegram: Settings > Devices > Link Desktop Device'), heading='Telegram', time=9000, sound=False)
                except Exception:
                    pass
            else:
                # Awaryjnie pokaż tg:// URL w oknie tekstowym. Na TV jest mniej wygodne,
                # ale logika QR dalej czeka na potwierdzenie.
                try:
                    control.dialog.textviewer('Telegram QR URL', qr.url)
                except Exception:
                    pass

            try:
                wait_result = qr.wait(timeout=120)
                if asyncio.iscoroutine(wait_result):
                    loop = _tg_ensure_event_loop()
                    _tg_patch_telethon_helpers()
                    _tg_bind_event_loop(loop)
                    user = loop.run_until_complete(wait_result)
                else:
                    user = wait_result
                fflog('[telegram] QR login OK user=%s' % (getattr(user, 'id', '') or ''), 1)
                return bool(client.is_user_authorized())
            except asyncio.CancelledError:
                try:
                    end_dc = self._client_dc_id(client)
                    if end_dc and start_dc and end_dc != start_dc:
                        self._last_qr_dc_migrated = True
                        try:
                            fflog('[telegram] QR login interrupted during DC migration %s -> %s' % (start_dc, end_dc), 1)
                        except Exception:
                            pass
                        control.infoDialog(L(33067, 'Telegram QR: switching data centers and showing a new QR code.'), heading='Telegram', time=6500, sound=False)
                    else:
                        control.infoDialog(L(33068, 'Telegram QR: waiting was cancelled or expired'), heading='Telegram', icon='WARNING', time=6000, sound=False)
                except Exception:
                    pass
                return False
            except BaseException as exc:
                if errors and isinstance(exc, getattr(errors, 'SessionPasswordNeededError', ())):
                    password = self._ask_text(L(33069, 'Telegram: 2FA password after QR login'), hidden=True)
                    if not password:
                        return False
                    client.sign_in(password=password)
                    return bool(client.is_user_authorized())
                if self._is_dc_migration_error(exc):
                    try:
                        end_dc = self._client_dc_id(client)
                        if end_dc and start_dc and end_dc != start_dc:
                            self._last_qr_dc_migrated = True
                            fflog('[telegram] QR login interrupted by migration exception %s -> %s' % (start_dc, end_dc), 1)
                            control.infoDialog(L(33067, 'Telegram QR: switching data centers and showing a new QR code.'), heading='Telegram', time=6500, sound=False)
                            return False
                    except Exception:
                        pass
                    raise
                fflog_exc(1)
                try:
                    control.infoDialog(L(33070, 'Telegram QR: login was not completed within 120 seconds'), heading='Telegram', icon='WARNING', time=6000, sound=False)
                except Exception:
                    pass
                return False
        except Exception as exc:
            if self._is_api_id_invalid(exc, errors):
                self._show_api_id_invalid()
                return False
            fflog_exc(1)
            return False
        finally:
            if picture_open:
                self._close_qr_picture()

    @staticmethod
    def _close_qr_picture():
        """Close only Kodi's ShowPicture window, leaving settings untouched."""
        try:
            if control.condVisibility('Window.IsActive(slideshow)'):
                control.execute('Action(Back)')
                control.sleep(250)
        except Exception:
            pass

    def _qr_image_path(self):
        try:
            folder = os.path.join(control.dataPath, 'telegram')
            try:
                control.makeDirs(folder)
            except Exception:
                if not os.path.exists(folder):
                    os.makedirs(folder)
            return os.path.join(folder, 'telegram_login_qr.png')
        except Exception:
            return os.path.join(control.dataPath, 'telegram_login_qr.png')

    def _write_qr_png(self, data, path, scale=8, border=4):
        try:
            matrix = None
            # Na części Android TV brakuje script.module.pyqrcode. Najpierw próbujemy
            # starej metody, a potem vendored qrcode z paczki dodatku. Dzięki temu
            # QR działa bez instalowania dodatkowych bibliotek z repozytorium Kodi.
            try:
                import pyqrcode
                qr = pyqrcode.create(data, error='M')
                matrix = qr.code
            except Exception as exc:
                try:
                    fflog('[telegram] pyqrcode unavailable, using bundled qrcode fallback: %r' % exc, 1)
                except Exception:
                    pass
                import qrcode
                qr = qrcode.QRCode(
                    version=None,
                    error_correction=qrcode.constants.ERROR_CORRECT_M,
                    box_size=1,
                    border=0,
                )
                qr.add_data(data)
                qr.make(fit=True)
                matrix = qr.get_matrix()

            if not matrix:
                return False
            size = len(matrix)
            width = (size + border * 2) * scale
            height = width

            def png_chunk(tag, payload):
                raw = tag + payload
                return struct.pack('>I', len(payload)) + raw + struct.pack('>I', zlib.crc32(raw) & 0xffffffff)

            rows = []
            white = 255
            black = 0
            for y in range(size + border * 2):
                if y < border or y >= size + border:
                    row = bytes([white]) * width
                else:
                    src = matrix[y - border]
                    pixels = []
                    pixels.extend([white] * (border * scale))
                    for cell in src:
                        v = black if cell else white
                        pixels.extend([v] * scale)
                    pixels.extend([white] * (border * scale))
                    row = bytes(pixels)
                for _ in range(scale):
                    rows.append(b'\x00' + row)
            raw = b''.join(rows)
            png = b'\x89PNG\r\n\x1a\n'
            png += png_chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 0, 0, 0, 0))
            png += png_chunk(b'IDAT', zlib.compress(raw, 9))
            png += png_chunk(b'IEND', b'')
            with open(path, 'wb') as f:
                f.write(png)
            return True
        except Exception:
            fflog_exc(1)
            return False

    def _sent_code_description(self, sent):
        try:
            t = getattr(sent, 'type', None)
            tname = type(t).__name__ if t is not None else type(sent).__name__
            next_type = getattr(sent, 'next_type', None)
            nname = type(next_type).__name__ if next_type is not None else ''
            timeout = getattr(sent, 'timeout', None)
            length = getattr(t, 'length', None) if t is not None else None
            if 'App' in tname:
                where = L(33081, 'Telegram app / Telegram chat')
            elif 'Sms' in tname or 'SMS' in tname:
                where = 'SMS'
            elif 'Call' in tname:
                where = L(33082, 'phone call')
            elif 'FlashCall' in tname:
                where = 'flash-call'
            elif 'MissedCall' in tname:
                where = L(33083, 'missed call')
            elif 'Email' in tname:
                where = 'e-mail'
            else:
                where = tname
            extra = []
            if length:
                extra.append(L(33084, 'length: {length}').format(length=length))
            if timeout:
                extra.append(L(33085, 'retry in: {seconds}s').format(seconds=timeout))
            if nname:
                extra.append(L(33086, 'next method: {method}').format(method=nname.replace('SentCodeType', '')))
            return where + ((' (' + ', '.join(extra) + ')') if extra else '')
        except Exception:
            return type(sent).__name__

    def _mask_phone(self, phone):
        try:
            p = str(phone or '').strip()
            if len(p) <= 5:
                return p
            return p[:3] + '***' + p[-3:]
        except Exception:
            return '***'

    def _chat_scan_score(self, title):
        try:
            t = title_matcher.normalize(title or '')
            score = 0
            keywords = [
                'film', 'filmy', 'movie', 'movies', 'kino', 'cinema', 'serial', 'seriale',
                'serien', 'serie', 'deutsch', 'german', 'lektor', 'dubbing', 'napisy',
                'bajki', 'cartoon', 'anime', 'ghibli', 'stream', 'vod', 'hd', '4k'
            ]
            for kw in keywords:
                if kw in t:
                    score += 10
            negative = ['apk', 'iptv', 'programy', 'konto', 'konta', 'czat', 'gadu', 'bot']
            for kw in negative:
                if kw in t:
                    score -= 8
            return score
        except Exception:
            return 0

    def _is_group_channel(self, ent):
        try:
            if not ent:
                return False
            if getattr(ent, 'bot', False) or getattr(ent, 'first_name', None) or getattr(ent, 'phone', None):
                return False
            if getattr(ent, 'megagroup', False) or getattr(ent, 'broadcast', False):
                return True
            return bool(getattr(ent, 'title', None))
        except Exception:
            return False

    def _search_forum_topics(self, client, out, ent, title, ref, q, data, seen, current_count=0, max_per_chat=5, deadline=None):
        """Search message contents across a forum, then apply the topic filter.

        Telethon explicitly ignores ``search=`` when ``reply_to=`` is supplied.
        The previous implementation combined both arguments, so it read only a
        short recent slice of each topic and filtered that slice locally.  A
        normal peer search is Telegram's server-side full-text search across the
        entire forum; filtering the returned messages by their numeric topic ID
        preserves the optional allow-list without converting search into a
        recent-message scan.
        """
        chat_id = int(getattr(ent, 'id', 0) or 0)
        allowed = self._selected_topic_map().get(chat_id)
        added = 0
        try:
            if current_count >= max_per_chat:
                return 0
            title_cache = getattr(self, '_forum_topic_title_cache', None)
            if not isinstance(title_cache, dict):
                title_cache = {}
                self._forum_topic_title_cache = title_cache
            topic_titles = title_cache.get(chat_id)
            if topic_titles is None:
                topic_titles = {}
                try:
                    # Topic names are cosmetic and are already cached by the
                    # settings-side topic refresh.  Never spend a search RPC on
                    # labels before asking Telegram for the actual matching
                    # messages; a slow label lookup used to consume the fallback
                    # budget without checking any file.
                    for topic in (self._load_chat_filter().get('topics') or []):
                        if int(topic.get('chat_id') or 0) != chat_id:
                            continue
                        topic_id = int(topic.get('topic_id') or 0)
                        if topic_id:
                            topic_titles[topic_id] = str(topic.get('title') or '')
                except Exception:
                    topic_titles = {}
                title_cache[chat_id] = topic_titles

            scan_limit = min(
                max(24, int(self.search_limit or 100)),
                max(24, int(getattr(self, 'topic_scan_limit', 80) or 80)),
            )
            for msg in client.iter_messages(ent, search=q, limit=scan_limit):
                if self._cancelled() or (deadline is not None and time.time() >= float(deadline)):
                    break
                if current_count + added >= max_per_chat or len(out) >= self.max_results:
                    break
                topic_id = int(self._message_topic_id(msg) or 0)
                if allowed and (not topic_id or topic_id not in allowed):
                    continue
                topic_title = topic_titles.get(topic_id, '')
                chat_title = '%s / %s' % (title, topic_title) if topic_title else title
                if not self._message_contains_query(msg, q):
                    continue
                if self._append_mtproto_source(
                    out, msg, ent, chat_title, ref, data, seen,
                    force_match=True, match_query=q, query_rank=6,
                ):
                    added += 1
                    continue

                remaining = max(
                    0,
                    int(max_per_chat or 0)
                    - int(current_count or 0)
                    - int(added or 0),
                )
                ctx_added = 0
                if self._series_header_matches(msg, data, chat_title, ref):
                    ctx_added = self._append_series_nearby_videos(
                        client, out, ent, chat_title, ref, data, msg, seen,
                        max_add=min(int(getattr(self, 'series_context_files', 30) or 0), remaining),
                        deadline=deadline,
                    )
                elif self._movie_header_matches(msg, data, chat_title, ref):
                    ctx_added = self._append_movie_nearby_videos(
                        client, out, ent, chat_title, ref, data, msg, seen,
                        max_add=min(int(getattr(self, 'movie_context_files', 3) or 0), remaining),
                        deadline=deadline,
                    )
                if ctx_added:
                    added += ctx_added
        except Exception:
            pass
        return added

    def _mtproto_target_cache_key(self):
        try:
            session_file = self._session_path() + '.session'
            try:
                st = os.stat(session_file)
                # SQLite updates the session file mtime during normal Telethon
                # use, which would make an mtime-based dialog cache miss on every
                # search.  File identity (device+inode) stays stable for normal
                # writes but changes when the saved session is replaced.  On
                # platforms without a useful inode, fall back to the conservative
                # size+mtime signature.
                inode = int(getattr(st, 'st_ino', 0) or 0)
                device = int(getattr(st, 'st_dev', 0) or 0)
                if inode:
                    session_sig = ('inode', device, inode)
                else:
                    session_sig = (
                        'stat', int(st.st_size),
                        int(getattr(st, 'st_mtime_ns', int(st.st_mtime * 1000000000))),
                    )
            except Exception:
                session_sig = ('missing', 0, 0)
            filter_path = self._chat_filter_path()
            try:
                st = os.stat(filter_path)
                filter_sig = (
                    int(getattr(st, 'st_mtime_ns', int(st.st_mtime * 1000000000))),
                    int(st.st_size),
                )
            except Exception:
                filter_sig = (0, 0)
            selected = tuple(sorted(self._selected_chat_ids()))
            manual = tuple(sorted([self._public_chat_name(c) for c in self.chats if self._public_chat_name(c)]))
            return (
                str(session_file), session_sig, filter_sig, int(self.api_id or 0),
                bool(self.use_dialogs), int(self.dialog_limit or 0),
                self._chat_filter_mode_name(), selected, manual,
            )
        except Exception:
            return None

    def _mtproto_target_cache_get(self, key):
        if not key:
            return None
        try:
            now = time.monotonic()
            with _TG_SEARCH_META_LOCK:
                entry = _TG_TARGET_CACHE.get(key)
                if not entry:
                    return None
                if now - float(entry.get('saved') or 0.0) > float(_TG_TARGET_CACHE_TTL):
                    _TG_TARGET_CACHE.pop(key, None)
                    return None
                targets = list(entry.get('targets') or [])
            # A cached full Channel/Chat object carries the access hash required
            # by a fresh Telethon client. Reject malformed cache entries and
            # fall back to live dialog discovery rather than risking coverage.
            if not targets or any(not int(getattr(x[0], 'id', 0) or 0) for x in targets):
                return None
            return targets
        except Exception:
            return None

    def _mtproto_target_cache_put(self, key, targets):
        if not key or not targets:
            return
        try:
            with _TG_SEARCH_META_LOCK:
                _TG_TARGET_CACHE[key] = {
                    'saved': time.monotonic(),
                    'targets': tuple(targets),
                }
                # Bound process memory even if the user changes filters often.
                if len(_TG_TARGET_CACHE) > 8:
                    oldest = sorted(
                        _TG_TARGET_CACHE.items(),
                        key=lambda item: float((item[1] or {}).get('saved') or 0.0),
                    )
                    for old_key, _entry in oldest[:-8]:
                        _TG_TARGET_CACHE.pop(old_key, None)
        except Exception:
            pass

    def _get_mtproto_targets(self, client, deadline=None):
        cache_key = self._mtproto_target_cache_key()
        cached = self._mtproto_target_cache_get(cache_key)
        if cached is not None:
            try:
                self._diag('[telegram] dialog metadata cache hit; targets=%s' % len(cached))
            except Exception:
                pass
            return cached

        targets = []
        seen = set()
        manual = [self._public_chat_name(c) for c in self.chats]
        manual = [x for x in manual if x]
        if manual:
            for ref in manual:
                try:
                    ent = client.get_entity(ref)
                    eid = int(getattr(ent, 'id', 0) or 0)
                    if eid in seen:
                        continue
                    seen.add(eid)
                    title = getattr(ent, 'title', None) or getattr(ent, 'username', None) or ref
                    targets.append((ent, title, ref, 9999))
                except Exception:
                    fflog_exc(1)

        if self.use_dialogs:
            try:
                for d in client.iter_dialogs(limit=self.dialog_limit):
                    ent = getattr(d, 'entity', None)
                    if not ent:
                        continue
                    eid = int(getattr(ent, 'id', 0) or 0)
                    if not eid or eid in seen:
                        continue
                    # channels/groups/supergroups only; skip private users/bots by default.
                    if not (getattr(d, 'is_channel', False) or getattr(d, 'is_group', False) or self._is_group_channel(ent)):
                        continue
                    seen.add(eid)
                    ref = ''
                    try:
                        username = getattr(ent, 'username', None)
                        if username:
                            ref = username
                    except Exception:
                        pass
                    title = getattr(d, 'name', None) or getattr(ent, 'title', None) or ref or str(eid)
                    targets.append((ent, title, ref, self._chat_scan_score(title)))
            except Exception:
                fflog_exc(1)

        try:
            mode = self._chat_filter_mode_name()
            selected = self._selected_chat_ids()
            if mode == 'selected':
                if selected:
                    targets = [x for x in targets if str(int(getattr(x[0], 'id', 0) or 0)) in selected]
                else:
                    # Tryb tylko wybrane bez wyboru ma nie skanować wszystkiego przez pomyłkę.
                    fflog('[telegram] chat filter selected_only, ale lista wybranych jest pusta', 1)
                    targets = []
            elif mode == 'excluded' and selected:
                targets = [x for x in targets if str(int(getattr(x[0], 'id', 0) or 0)) not in selected]
        except Exception:
            fflog_exc(1)

        try:
            targets = sorted(targets, key=lambda x: x[3], reverse=True)
        except Exception:
            pass
        # Nie skanuj setek dialogów w jednym wyszukiwaniu, ale po odwróceniu pętli
        # zapytań możemy bezpiecznie sprawdzić więcej własnych grup/kanałów.
        limit = min(max(5, int(self.dialog_limit or 1000)), 1000)
        targets = targets[:limit]
        try:
            fflog('[telegram] MTProto account targets=%s filter=%s selected=%s' % (len(targets), self._chat_filter_mode_name(), len(self._selected_chat_ids())), 1)
        except Exception:
            fflog(f'[telegram] MTProto account targets={len(targets)} own_dialogs_filter', 1)
        final_targets = [(ent, title, ref) for ent, title, ref, _score in targets]
        self._mtproto_target_cache_put(cache_key, final_targets)
        return final_targets

    def _document_from_message(self, msg):
        try:
            doc = getattr(msg, 'document', None)
            if doc:
                return doc
        except Exception:
            pass
        try:
            doc = getattr(getattr(msg, 'media', None), 'document', None)
            if doc:
                return doc
        except Exception:
            pass
        return None

    def _filename_from_document(self, doc):
        try:
            for a in getattr(doc, 'attributes', []) or []:
                name = getattr(a, 'file_name', None)
                if name:
                    return str(name)
        except Exception:
            pass
        return ''

    def _message_file_size(self, msg):
        try:
            size = int(getattr(getattr(msg, 'file', None), 'size', 0) or 0)
            if size:
                return size
        except Exception:
            pass
        try:
            doc = self._document_from_message(msg)
            return int(getattr(doc, 'size', 0) or 0) if doc else 0
        except Exception:
            return 0

    def _message_has_video_file(self, msg):
        try:
            # Telethon exposes some videos as msg.video/msg.document even when
            # msg.file.mime_type/name is empty.  The previous check missed such
            # album video tiles under poster/caption posts.
            if getattr(msg, 'video', None):
                return True
            file_obj = getattr(msg, 'file', None)
            name = (getattr(file_obj, 'name', None) or '').lower() if file_obj else ''
            mime = (getattr(file_obj, 'mime_type', None) or '').lower() if file_obj else ''
            if mime.startswith('video/'):
                return True
            if re.search(r'\.(mp4|mkv|avi|mov|webm|m4v)$', name, re.I):
                return True
            doc = self._document_from_message(msg)
            if doc:
                dmime = (getattr(doc, 'mime_type', None) or '').lower()
                if dmime.startswith('video/'):
                    return True
                dname = self._filename_from_document(doc).lower()
                if re.search(r'\.(mp4|mkv|avi|mov|webm|m4v)$', dname, re.I):
                    return True
                for a in getattr(doc, 'attributes', []) or []:
                    cls = a.__class__.__name__.lower()
                    if 'video' in cls:
                        return True
        except Exception:
            pass
        return False

    def _message_dict_from_mtproto(self, msg, chat_title, ref=''):
        file_obj = getattr(msg, 'file', None)
        doc = self._document_from_message(msg)
        filename = (getattr(file_obj, 'name', None) or self._filename_from_document(doc) or '')
        size = self._fmt_size(int(self._message_file_size(msg) or 0))
        text = ' '.join(x for x in (filename, getattr(msg, 'message', None) or '') if x).strip()
        try:
            msg_date = getattr(msg, 'date', None)
            date_label = msg_date.strftime('%Y-%m-%d') if msg_date else ''
        except Exception:
            date_label = ''
        return {
            'chat': chat_title,
            'message_id': str(getattr(msg, 'id', '') or ''),
            'date': date_label,
            'message_url': ('https://t.me/%s/%s' % (ref, getattr(msg, 'id', ''))) if ref else '',
            'text': text,
            'filename': filename,
            'size': size,
            'video_url': 'mtproto',
        }

    def _resolve_mtproto(self, data):
        try:
            if not self.proxy_stream:
                control.infoDialog(L(33075, 'Telegram requires the local proxy service for MTProto playback'), heading='Telegram', icon='WARNING', time=4000, sound=False)
                return None

            spec = dict(data or {})
            spec['api_hash'] = self.api_hash
            spec['session_path'] = self._session_path()
            spec['session_string'] = _tg_export_session_string(spec['session_path'])
            spec['created'] = time.time()
            spec['startup_buffer_mb'] = int(self.startup_buffer_mb or 4)
            if not spec.get('session_string'):
                control.infoDialog(L(33076, 'Telegram: could not read the active session.'), heading='Telegram', icon='WARNING', time=5000, sound=False)
                return None

            # 2.41.39: playback is registered in the persistent service.py
            # Telegram stream service. The old in-resolver proxy is intentionally
            # not used here: it created Telethon clients in Kodi HTTP/request
            # threads and repeatedly blocked Android/Kodi after failed opens.
            register_started = time.time()
            try:
                from resources.lib import tg_stream_service
                # Metadane + bufor są przygotowywane w usłudze. Daj im czas
                # zależny od wybranego bufora, ale nie blokuj bez końca.
                # A tail-indexed MP4 is now registered transactionally: metadata,
                # the configured prefix and the exact post-mdat index may each use
                # their existing 24-second service budget.  Keep the local control
                # request alive for that bounded sequence; this does not add delay
                # when a stage completes normally.
                register_timeout = max(24.0, min(48.0, 20.0 + float(self.startup_buffer_mb)))
                _register_name = str(spec.get('filename') or '').split('?', 1)[0].lower()
                _register_mime = str(spec.get('mime') or '').split(';', 1)[0].strip().lower()
                if (_register_name.endswith('.mp4')
                        or _register_mime in ('video/mp4', 'application/mp4')):
                    register_timeout = max(80.0, register_timeout)
                result = tg_stream_service.register_with_service(spec, preferred_port=self.proxy_port, timeout=register_timeout)
            except Exception:
                fflog_exc(1)
                result = {'ok': False, 'error': 'stream_service import/register failed'}
            try:
                elapsed = max(0.001, time.time() - register_started)
                cached = int(result.get('cached') or 0)
                rate = float(cached) / (1024.0 * 1024.0) / elapsed
                self._diag('[telegram] stream startup; ok=%s cached=%s elapsed=%.2fs avg=%.2fMiB/s backend=%s' % (
                    bool(result.get('ok')), cached, elapsed, rate, result.get('crypto_backend') or 'unknown'))
            except Exception:
                pass

            if result.get('ok') and result.get('url'):
                fflog('[tg-service] resolved service url token=%s file=%r size=%s cached=%s' % (
                    _token_tag(result.get('token') or ''), data.get('filename') or '', int(spec.get('size') or 0), int(result.get('cached') or 0)), 1)
                # 2.41.45 native-crypto branch: when Telethon has a native
                # crypto backend, use normal seekable HTTP Range again. MP4/MKV
                # players need truthful seek support for tail metadata. If we fell
                # back to pure Python pyaes, refuse instead of clogging Kodi.
                _backend = str(result.get('crypto_backend') or '').lower()
                if _backend in ('pyaes', 'unknown', ''):
                    try:
                        control.infoDialog(L(33077, 'Telegram: fast cryptography is unavailable. Streaming requires tgcrypto_ctypes or libssl.'), heading='Telegram', icon='WARNING', time=7000, sound=False)
                    except Exception:
                        pass
                    return None
                _u = result.get('url')
                return _u

            err = result.get('error') or 'nieznany błąd serwisu Telegram'
            try:
                fflog('[tg-service] register failed err=%r cached=%s' % (err, result.get('cached')), 1)
                control.infoDialog(L(33078, 'Telegram: the service did not return the first bytes or the streaming backend refused to start. Check the log.'), heading='Telegram', icon='WARNING', time=6000, sound=False)
            except Exception:
                pass
            return None
        except Exception:
            fflog_exc(1)
            return None

    # ------------------------------------------------------------------ #
    # Public t.me/s search                                                 #
    # ------------------------------------------------------------------ #

    def _sources_public_web(self, data):
        out = []
        queries = self._build_queries(data)
        chats = self._public_chats()
        if not chats:
            fflog('[telegram] no public @channels for t.me/s fallback', 1)
            return out

        for chat in chats:
            found_for_chat = 0
            for q in queries:
                if found_for_chat >= 5:
                    break
                html, page_url = self._fetch_public_page(chat, q)
                if not html:
                    continue
                messages = self._parse_public_messages(html, chat, page_url)
                for msg in messages:
                    if found_for_chat >= 5:
                        break
                    if not self._message_matches(msg, data):
                        continue
                    public_size = self._size_value_bytes(msg.get('size'))
                    if public_size and public_size < self._effective_min_file_size(data):
                        continue
                    src = msg.get('video_url') or ''
                    if not src:
                        continue
                    token = self._pack({
                        'mode': 'public_web',
                        'url': src,
                        'referer': msg.get('message_url') or page_url,
                        'chat': chat,
                        'message_id': msg.get('message_id'),
                        'title': msg.get('text') or data.get('title'),
                    })
                    quality = self._quality_from_text(' '.join([msg.get('text') or '', src]))
                    info = self._info_from_message(msg, chat)
                    out.append({
                        'provider': 'telegram',
                        'source': self._display_chat_title(msg.get('chat') or chat),
                        'quality': quality,
                        'language': 'pl',
                        'url': token,
                        'info': info,
                        'direct': True,
                        'debridonly': False,
                        'filename': msg.get('filename') or '',
                        'premium': False,
                        'telegram_chat_id': str(chat or ''),
                        'telegram_message_id': str(msg.get('message_id') or ''),
                    })
                    found_for_chat += 1
        return out

    def _fetch_public_page(self, chat, query=''):
        try:
            base = f'https://t.me/s/{chat}'
            if query:
                url = base + '?q=' + quote(query)
            else:
                url = base
            fflog(f'[telegram] GET {url}', 1)
            r = self._get_session().get(url, headers=self.headers, timeout=18)
            if r.status_code >= 400:
                fflog(f'[telegram] public page status={r.status_code} chat={chat}', 1)
                return '', url
            text = r.text or ''
            if 'tgme_channel_history' not in text and 'tgme_widget_message' not in text:
                fflog(f'[telegram] no public messages in {chat}', 1)
            return text, url
        except Exception:
            fflog_exc(1)
            return '', ''

    def _parse_public_messages(self, html, chat, page_url):
        messages = []
        try:
            blocks = re.split(r'(?=<div class="tgme_widget_message[^>]*\bdata-post=)', html or '')
            for block in blocks:
                if 'tgme_widget_message' not in block:
                    continue
                post = self._first_match(block, r'data-post="([^"]+)"')
                msg_id = ''
                if post and '/' in post:
                    try:
                        msg_id = post.rsplit('/', 1)[1]
                    except Exception:
                        pass
                message_url = f'https://t.me/{post}' if post else page_url
                text = self._clean_html(self._first_match(block, r'<div class="tgme_widget_message_text[^>]*>(.*?)</div>'))
                if not text:
                    text = self._clean_html(self._first_match(block, r'<div class="tgme_widget_message_caption[^>]*>(.*?)</div>'))
                filename = self._clean_html(self._first_match(block, r'<div class="tgme_widget_message_document_title[^>]*>(.*?)</div>'))
                size = self._clean_html(self._first_match(block, r'<div class="tgme_widget_message_document_extra[^>]*>(.*?)</div>'))
                video_url = self._extract_media_url(block)
                messages.append({
                    'chat': chat,
                    'message_id': msg_id,
                    'message_url': message_url,
                    'text': ' '.join(x for x in (filename, text) if x).strip(),
                    'filename': filename,
                    'size': size,
                    'video_url': video_url,
                })
        except Exception:
            fflog_exc(1)
        return messages

    def _extract_media_url(self, block):
        try:
            candidates = []
            for attr in ('data-src', 'src', 'href', 'data-video'):
                for val in re.findall(attr + r'="([^"]+)"', block or '', re.I):
                    val = unescape(val).replace('\\/', '/').strip()
                    if val.startswith('//'):
                        val = 'https:' + val
                    if not val.startswith('http'):
                        continue
                    if self._looks_like_media_url(val):
                        candidates.append(val)
            for val in re.findall(r'https?://[^\s"\']+', block or '', re.I):
                val = unescape(val).replace('\\/', '/').strip().rstrip('),;')
                if self._looks_like_media_url(val):
                    candidates.append(val)
            for u in candidates:
                if re.search(r'\.(?:mp4|mkv|avi|mov)(?:\?|$)', u, re.I):
                    return u
            for u in candidates:
                if 'cdn-telegram' in u or '/file/' in u:
                    return u
        except Exception:
            fflog_exc(1)
        return ''

    def _looks_like_media_url(self, url):
        u = (url or '').lower()
        if not u.startswith('http'):
            return False
        if re.search(r'\.(?:jpg|jpeg|png|webp|gif)(?:\?|$)', u):
            return False
        return bool(re.search(r'\.(?:mp4|mkv|avi|mov|m3u8)(?:\?|$)|cdn-telegram|/file/', u))

    # ------------------------------------------------------------------ #
    # Matching                                                            #
    # ------------------------------------------------------------------ #

    def _known_polish_title_variants(self, data):
        """Small local override list for titles whose PL name is often missing
        from the metadata passed to source scrapers.

        This is intentionally narrow: it only injects Polish titles that the user
        explicitly needs or that are very common in PL catalogues.  The normal
        metadata/aliases still drive the rest of the search.
        """
        out = []
        try:
            title = str((data or {}).get('title') or '').strip()
            local = str((data or {}).get('localtitle') or '').strip()
            aliases = []
            for item in ((data or {}).get('aliases') or []):
                if isinstance(item, dict):
                    value = (
                        item.get('title') or item.get('name') or item.get('value')
                        or item.get('originalname') or item.get('original_name') or ''
                    )
                else:
                    value = item
                value = str(value or '').strip()
                if value:
                    aliases.append(value)
            blob = ' '.join([title, local] + aliases).lower()
            imdb = str((data or {}).get('imdb') or '').strip().lower()

            def add(x):
                x = re.sub(r'\s+', ' ', str(x or '')).strip()
                if x and x not in out:
                    out.append(x)

            # FROM (tt9813792) is often passed to scrapers only as "FROM" plus
            # non-PL aliases, while Polish uploads use "Stamtąd".
            if imdb == 'tt9813792' or re.search(r'(^|\s)from($|\s)', blob):
                add('Stamtąd')
                add('Stamtad')

            # A few PL catalogue names that are also commonly missing/ambiguous
            # in upstream aliases.  Kept after metadata variants, not instead of them.
            if re.search(r'married\s+with\s+children|bundy|bundych', blob):
                add('Świat według Bundych')
                add('Swiat wedlug Bundych')
            if re.search(r'kiepskich|kiepscy|swiat\s+wedlug\s+kiepskich|świat\s+według\s+kiepskich', blob):
                add('Świat według Kiepskich')
                add('Swiat wedlug Kiepskich')

            # Szpital św. Anny bywa przekazywany przez metadata jako angielski
            # tytuł/original albo zwykły alias bez kodu języka.  Nie dodajemy
            # osobnych zapytań Anny/św/sw; pełny tytuł daje dalej główne słowo
            # wyszukiwania: "Szpital".
            if re.search(r'szpital\s+(?:św|sw|święt|swiet).*anny|(?:saint|st\.?)\s+anne', blob, re.I):
                add('Szpital św. Anny')
                add('Szpital sw Anny')
        except Exception:
            pass
        return out

    def _has_strong_polish_marks(self, value):
        """True only for diacritics that are a strong PL signal.

        The letter 'ó' is intentionally excluded here: it is common in
        Portuguese/Spanish/Hungarian/etc. aliases, so it must not by itself
        promote an unknown bare alias to Polish.  Once a title is accepted
        as PL by metadata/localtitle, 'ó' is still preserved and normalized
        by the query builder, e.g. Zwierzogród -> Zwierzogrod.
        """
        try:
            return bool(re.search(r'[ąćęłńśżźĄĆĘŁŃŚŻŹ]', str(value or '')))
        except Exception:
            return False

    def _variant_lang_group(self, value, data=None):
        """Priority bucket for Telegram title variants.

        0 = Polish/local, 2 = German-looking, 1 = English/original fallback.
        Bare/unknown aliases are not used by _wanted_variants anymore, because
        they can be Portuguese/Turkish/Czech/etc. (Susto, Korkun, Mrak...).
        """
        try:
            v = str(value or '')
            vc = title_matcher.compact(v)
            local = str((data or {}).get('localtitle') or '') if data else ''
            title = str((data or {}).get('title') or '') if data else ''
            if local and vc == title_matcher.compact(local):
                return 0
            # Preserve explicit language/country metadata. Re-classifying an
            # accepted alias only by how its words "look" made names such as
            # German "Zoomania" fall into the EN bucket.
            for alias in ((data or {}).get('aliases') or []) if data else []:
                if not isinstance(alias, dict):
                    continue
                av = (
                    alias.get('title') or alias.get('name') or alias.get('value')
                    or alias.get('originalname') or alias.get('original_name')
                    or alias.get('originaltitle') or alias.get('original_title') or ''
                )
                if not av or vc != title_matcher.compact(av):
                    continue
                codes = ' '.join(
                    str(alias.get(key) or '').lower()
                    for key in ('lang', 'language', 'iso_639_1', 'country', 'region', 'iso_3166_1', 'locale')
                )
                if re.search(r'(^|[^a-z])(pl|pol|polish|polska|polski)([^a-z]|$)', codes):
                    return 0
                if re.search(r'(^|[^a-z])(de|deu|ger|german|deutsch)([^a-z]|$)', codes):
                    return 2
                if re.search(r'(^|[^a-z])(en|eng|english|us|usa|gb|uk|original|orig)([^a-z]|$)', codes):
                    return 1
            if self._has_strong_polish_marks(v):
                return 0
            if vc in ('stamtad', 'swiatwedlugbundych', 'swiatwedlugkiepskich'):
                return 0
            if self._looks_german_title(v):
                return 2
            if title and vc == title_matcher.compact(title):
                return 1
            if not local and title and vc == title_matcher.compact(title):
                return 1
            return 1
        except Exception:
            return 1

    def _wanted_variants(self, data, max_items=24):
        """Return only PL/DE/EN title variants used for Telegram.

        Current rule agreed with the user:
          Polish title -> Polish title without diacritics (added by query builder)
          -> German title -> German without diacritics -> English/original title.

        Important: do NOT use generic unknown aliases.  Metadata providers can
        pass aliases from many countries as plain strings (for example Susto,
        Korkun, Mrak, Origem).  Those are now ignored unless the alias metadata
        explicitly marks the title as PL/DE/EN.  A word is never rejected just
        because it looks short or generic if it belongs to an accepted title
        variant; Ted, From, Film, He, etc. remain valid when they are really in
        the PL/DE/EN title.
        """
        try:
            data = data or {}
            title = data.get('title') or data.get('localtitle') or ''
            local = data.get('localtitle') or ''
            aliases = data.get('aliases') or []
            known_pl = self._known_polish_title_variants(data)

            buckets = {0: [], 2: [], 1: []}  # PL/local, DE, EN/original

            def add_bucket(group, v):
                v = re.sub(r'\s+', ' ', str(v or '')).strip()
                if not v:
                    return
                if v not in buckets.setdefault(group, []):
                    buckets[group].append(v)

            def alias_text_and_codes(a):
                av = a
                codes = []
                try:
                    if isinstance(a, dict):
                        av = (
                            a.get('title') or a.get('name') or a.get('value')
                            or a.get('originalname') or a.get('original_name')
                            or a.get('originaltitle') or a.get('original_title') or ''
                        )
                        for k in ('lang', 'language', 'iso_639_1', 'country', 'region', 'iso_3166_1', 'locale'):
                            val = a.get(k)
                            if val:
                                codes.append(str(val).lower())
                    else:
                        # Plain string aliases have no language metadata.  Keep
                        # the text only for obvious PL/DE detection below.  This
                        # restores cases like "Szpital św. Anny" passed as a
                        # bare alias, without re-enabling random EN/foreign aliases
                        # such as Susto/Korkun/Mrak.
                        av = a
                except Exception:
                    av = a
                return re.sub(r'\s+', ' ', str(av or '')).strip(), codes

            def code_group(codes):
                joined = ' '.join(codes).lower()
                # language/country can arrive as pl, pl-PL, polish, DE, us, gb, etc.
                if re.search(r'(^|[^a-z])(pl|pol|polish|polska|polski)([^a-z]|$)', joined):
                    return 0
                if re.search(r'(^|[^a-z])(de|deu|ger|german|deutsch|niemcy|niemiecki)([^a-z]|$)', joined):
                    return 2
                if re.search(r'(^|[^a-z])(en|eng|english|us|usa|gb|uk|original|orig)([^a-z]|$)', joined):
                    return 1
                return None

            # Polish/local title first.  Known local fixes are only PL titles.
            for v in known_pl:
                add_bucket(0, v)
            add_bucket(0, local)

            # The title field is usually the original/English title, but in some
            # Kodi paths it can already be the localized PL display title.  If it
            # equals local or contains Polish letters, keep it in PL; if it looks
            # German, keep it as DE; otherwise treat it as English/original.
            if title:
                if local and title_matcher.compact(title) == title_matcher.compact(local):
                    add_bucket(0, title)
                elif self._has_strong_polish_marks(title):
                    add_bucket(0, title)
                elif self._looks_german_title(title):
                    add_bucket(2, title)
                else:
                    add_bucket(1, title)

            # Aliases: use explicit PL/DE/EN metadata.  For bare string aliases
            # keep only obvious Polish/German text, matching 2.41.88 behaviour.
            # Do not accept bare English/unknown aliases, because that was causing
            # Susto/Korkun/Mrak/Origem-style noise.
            for a in aliases:
                av, codes = alias_text_and_codes(a)
                group = code_group(codes)
                if av and group is None:
                    if self._has_strong_polish_marks(av):
                        group = 0
                    elif self._looks_german_title(av):
                        group = 2
                if av and group is not None:
                    add_bucket(group, av)

            ordered = []
            seen = set()
            for group in (0, 2, 1):
                for idx, v in enumerate(buckets.get(group, [])):
                    key = title_matcher.compact(v)
                    if not key or key in seen:
                        continue
                    seen.add(key)
                    ordered.append((group, idx, v))
            return [v for _, __, v in ordered[:max_items]] or [local or title]
        except Exception:
            return [data.get('localtitle') or data.get('title') or '']

    def _rank_title_variant(self, value, title, local, idx=0, data=None):
        # Kept for compatibility with older calls.  _wanted_variants now returns
        # already ordered PL -> DE -> EN variants.
        v = str(value or '').strip()
        group = self._variant_lang_group(v, data)
        base = {0: 0, 2: 1, 1: 2}.get(group, 3)
        return base + min(int(idx or 0), 50) / 100.0

    def _looks_german_title(self, value):
        v = (' ' + str(value or '').lower() + ' ')
        if re.search(r'[äöüß]', v):
            return True
        # Heuristic for title/localtitle only, not for generic aliases.  It helps
        # with German titles without diacritics, while aliases without language
        # metadata are ignored before this function is involved.
        return bool(re.search(r'\b(?:der|die|das|und|ein|eine|einer|eines|mit|nicht|deutsch|drachen|zaehmen|zähmen|koenig|könig|krieg|liebe|welt|herr|herren|dunkel|nacht|wunder|leben|tod|zeit|haus|mann|frau|kind|kinder)\b', v))

    def _looks_iberian_title(self, value):
        # Kept only for compatibility with older calls; no longer used to drop
        # title variants.
        return False

    def _looks_non_pl_en_de_title(self, value):
        # Do not drop real title variants by language.  A word is allowed if it
        # comes from a title/alias and is the longest word of that variant.
        return False

    def _ascii_fold(self, value):
        try:
            return unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode('ascii')
        except Exception:
            return str(value or '')

    def _search_phrase_variants(self, value):
        out = []
        try:
            base = re.sub(r'\s+', ' ', str(value or '')).strip()
            if not base:
                return out

            def add(x):
                x = str(x or '').strip(' ._-')
                x = re.sub(r'\s+', ' ', x)
                if x and x not in out:
                    out.append(x)

            def add_release_forms(x):
                x = re.sub(r'\s+', ' ', str(x or '')).strip()
                if not x:
                    return
                clean = re.sub(r'[^\wąćęłńóśżźÄÖÜäöüß]+', ' ', x, flags=re.I).strip()
                if clean:
                    add(clean)
                    # Telegram release names are commonly separated by dots or underscores.
                    add(re.sub(r'\s+', '.', clean).strip('.'))
                    add(re.sub(r'\s+', '_', clean).strip('_'))
                    add(re.sub(r'\s+', '-', clean).strip('-'))

            add(base)
            add(base.replace(':', ' '))
            add_release_forms(base)
            folded = self._ascii_fold(base)
            if folded and folded != base:
                add(folded)
                add_release_forms(folded)
            # Polish titles often alternate between pełna forma and abbreviation:
            # "świętej Anny" / "św. Anny" / "sw Anny".
            sw_forms = set()
            for x in (base, folded):
                if not x:
                    continue
                sw_forms.add(re.sub(r'(?i)\bśw\.?\b', 'św', x))
                sw_forms.add(re.sub(r'(?i)\bsw\.?\b', 'sw', x))
                sw_forms.add(re.sub(r'(?i)\bświęt(?:a|y|e|ej|ego|emu|ą)\b', 'św', x))
                sw_forms.add(re.sub(r'(?i)\bswiet(?:a|y|e|ej|ego|emu|a)\b', 'sw', x))
            for x in sw_forms:
                add(x)
                add_release_forms(x)
            # Shorter token query: do not remove stopwords.  If a word is
            # actually in the title, it may be the only/longest searchable token.
            toks = [t for t in re.split(r'\W+', folded or base, flags=re.I) if len(t) > 1]
            if len(toks) >= 2:
                short = ' '.join(toks[:5])
                add(short)
                add_release_forms(short)
        except Exception:
            pass
        return out

    def _build_queries(self, data):
        """Build a hybrid Telegram query plan from approved title variants.

        The longest real word remains the main recall strategy. For episodes we
        interleave exact title-word + SxxEyy/Exx queries before broad title-only
        searches so unrelated episodes cannot consume the per-chat limit first.
        Movies receive at most a few full-title helper queries after all broad
        PL/DE/EN words; full phrases never replace the proven word strategy.

        For every accepted title variant we still take the longest word actually
        present in that title. We do not use unknown/random foreign aliases.
        """
        variants = self._wanted_variants(data, max_items=18)
        queries = []

        def add(q):
            q = re.sub(r'[^0-9A-Za-ząćęłńóśżźĄĆĘŁŃÓŚŻŹÄÖÜäöüß]+', ' ', str(q or ''), flags=re.I)
            q = re.sub(r'\s+', ' ', q).strip()
            if q and q not in queries:
                queries.append(q)

        def best_word(value):
            raw = str(value or '')

            def _pick(text):
                words = re.findall(r'[0-9A-Za-ząćęłńóśżźĄĆĘŁŃÓŚŻŹÄÖÜäöüß]+', text, flags=re.I)
                # Do not remove stopwords.  If the word is in the title, it can be used.
                # Prefer non-year / non-pure-number words when possible, but allow
                # numeric titles like "1917" when there is nothing else.
                non_numeric = [w for w in words if not re.match(r'^\d+$', w)]
                long_enough = [w for w in non_numeric if len(self._ascii_fold(w)) >= 3]
                candidates = long_enough or non_numeric or words
                return candidates, words

            # Main title first: "Ne Zha 2: W krainie potworów" -> search "Zha"
            # before considering words from the subtitle.
            head = re.split(r'[:\-–—]', raw, 1)[0]
            candidates, words = _pick(head)
            # For titles like He-Man, the part before hyphen is only "He";
            # use the whole title so "Man" can win.
            if not candidates or max([len(self._ascii_fold(x)) for x in candidates] or [0]) < 3:
                candidates, words = _pick(raw)
            if not candidates:
                return ''
            candidates = sorted(candidates, key=lambda x: (len(self._ascii_fold(x)), len(x)), reverse=True)
            return candidates[0]

        grouped = {0: [], 1: [], 2: [], 3: []}
        for v in variants:
            try:
                group = self._variant_lang_group(v, data)
            except Exception:
                group = 1
            grouped.setdefault(group, []).append(v)

        base_by_group = {0: [], 2: [], 1: []}

        def add_base(group, q):
            q = re.sub(r'[^0-9A-Za-ząćęłńóśżźĄĆĘŁŃÓŚŻŹÄÖÜäöüß]+', ' ', str(q or ''), flags=re.I)
            q = re.sub(r'\s+', ' ', q).strip()
            if q and q not in base_by_group.setdefault(group, []):
                base_by_group[group].append(q)

        # PL first, then DE, then EN/original. No generic/unknown aliases.
        for group in (0, 2, 1):
            for v in grouped.get(group, []):
                word = best_word(v)
                if not word:
                    continue
                add_base(group, word)
                folded = self._ascii_fold(word)
                if folded and folded.lower() != word.lower():
                    add_base(group, folded)

        base_queries = []
        for group in (0, 2, 1):
            for q in base_by_group.get(group, []):
                if q not in base_queries:
                    base_queries.append(q)

        if data.get('kind') == 'series':
            try:
                s = int(data.get('season') or 1)
                e = int(data.get('episode') or 1)
                # Reserve at least one exact query for PL, DE and EN/original,
                # then fill one extra slot (often the no-diacritics PL form).
                exact_words = []
                for group in (0, 2, 1):
                    if base_by_group.get(group):
                        q = base_by_group[group][0]
                        if q not in exact_words:
                            exact_words.append(q)
                for q in base_queries:
                    if q not in exact_words:
                        exact_words.append(q)
                    if len(exact_words) >= 4:
                        break
                for q in exact_words:
                    add('%s S%02dE%02d' % (q, s, e))
                for q in exact_words[:2]:
                    add('%s E%02d' % (q, e))
            except Exception:
                pass
            for q in base_queries:
                add(q)
        else:
            # Longest-word queries stay first and therefore receive most of the
            # search budget. Add only a small full-title precision tail.
            for q in base_queries:
                add(q)
            phrase_count = 0
            for group in (0, 2, 1):
                for value in grouped.get(group, []):
                    phrase = re.sub(
                        r'[^0-9A-Za-ząćęłńóśżźĄĆĘŁŃÓŚŻŹÄÖÜäöüß]+',
                        ' ', str(value or ''), flags=re.I,
                    )
                    phrase = re.sub(r'\s+', ' ', phrase).strip()
                    if len(phrase.split()) < 2 or phrase in queries:
                        continue
                    add(phrase)
                    phrase_count += 1
                    if phrase_count >= 3:
                        break
                if phrase_count >= 3:
                    break

        return queries[:14]

    def _message_matches(self, msg, data):
        blob = ' '.join([msg.get('filename') or '', msg.get('text') or '', msg.get('message_url') or ''])
        try:
            if self._series_episode_conflict(blob, data):
                return False
        except Exception:
            pass
        norm_blob = title_matcher.normalize(blob)
        variants = self._wanted_variants(data, max_items=10)
        try:
            score = max(title_matcher.score(blob, v) for v in variants if v)
        except Exception:
            score = 0
        compact_blob = title_matcher.compact(blob)
        compact_hit = False
        for v in variants:
            cv = title_matcher.compact(v)
            if cv and len(cv) >= 3 and cv in compact_blob:
                compact_hit = True
                break
        # Do not require a perfect title-score match. If the real PL/DE title
        # word is present, allow it; the query builder and direct search already
        # chose that word intentionally.
        if score < 55 and not compact_hit:
            return False
        if data.get('kind') == 'movie':
            year = str(data.get('year') or '').strip()
            # Year is helpful, but not mandatory. Many valid Telegram filenames
            # and poster-context children do not include the year.  Reject only
            # when the message contains a different explicit 19xx/20xx year and
            # does not contain the requested year.
            if year:
                years_in_blob = re.findall(r'(?<!\d)(?:19|20)\d{2}(?!\d)', blob)
                if years_in_blob and year not in years_in_blob:
                    return False
        if data.get('kind') == 'series':
            s = int(data.get('season') or 1)
            e = int(data.get('episode') or 1)
            patterns = [
                rf'\bs0?{s}\s*e0?{e}\b',
                rf'\b0?{s}x0?{e}\b',
                rf'\b(?:ep|episode|odc(?:inek)?\.?)\s*0?{e}\b',
            ]
            if not any(re.search(p, norm_blob, re.I) for p in patterns):
                if score < 82:
                    return False
        return True

    def _language_from_text(self, text):
        """Best-effort PL/DE/EN tag for the Telegram picker.

        Unknown files keep the historical PL fallback so they are not hidden by
        language filters.  This affects presentation only; Telegram results remain
        deliberately broad and are never rejected by this guess.
        """
        value = re.sub(r'[_\.\-]+', ' ', str(text or '')).lower()
        if re.search(r'\b(?:multi|dual audio|multiaudio)\b', value):
            return 'multi'
        found = []
        patterns = (
            ('pl', r'\b(?:polish|polski|lektor(?: pl)?|dubbing(?: pl)?|napisy pl|plsub|pldub)\b'),
            ('de', r'\b(?:deutsch|german|gerdub|de dub|de sub|german dub|german sub)\b'),
            ('en', r'\b(?:english|eng dub|eng sub|en dub|en sub|original audio)\b'),
        )
        for code, pattern in patterns:
            if re.search(pattern, value, re.I):
                found.append(code)
        if len(set(found)) > 1:
            return 'multi'
        return found[0] if found else 'pl'

    def _quality_from_text(self, text):
        m = re.search(r'(?<!\d)(2160|1080|720|540|480|360)p?(?!\d)', text or '', re.I)
        if m:
            return m.group(1) + 'p'
        if re.search(r'\b(?:4k|uhd)\b', text or '', re.I):
            return '4K'
        return 'HD'

    def _display_chat_title(self, title):
        title = re.sub(r'\s+', ' ', str(title or '')).strip(' @|-')
        if not title:
            return 'Telegram'
        title = re.sub(r'(?i)^telegram\s*[-•|]*\s*', '', title).strip() or title
        return title[:42]

    def _media_info_from_text(self, text):
        text = re.sub(r'[_\.]+', ' ', str(text or ' '))
        up = text.upper()
        tags = []
        checks = [
            ('HDCAM', r'\bHD\s*CAM\b|\bHDCAM\b'),
            ('CAM', r'\bCAM\b'),
            ('WEB-DL', r'\bWEB[- ]?DL\b'),
            ('WEBRip', r'\bWEB[- ]?RIP\b'),
            ('BluRay', r'\bBLU[- ]?RAY\b|\bBDRIP\b|\bBRRIP\b'),
            ('HDTV', r'\bHDTV\b'),
            ('DVDRip', r'\bDVD[- ]?RIP\b'),
            ('HEVC', r'\b(?:HEVC|H\.?265|X\.?265)\b'),
            ('AVC', r'\b(?:AVC|H\.?264|X\.?264)\b'),
            ('EAC3', r'\bE[- ]?AC3\b|\bDDP?5\.?1\b'),
            ('AC3', r'\bAC3\b'),
            ('MD', r'\bMD\b'),
            ('LD', r'\bLD\b'),
            ('Lektor', r'\bLEKTOR\b'),
            ('Dubbing', r'\bDUBBING\b|\bDUB\b'),
            ('Napisy', r'\bNAPISY\b|\bSUB(?:S|TITLES)?\b|\bPLSUB\b|\bDESUB\b'),
        ]
        for label, pattern in checks:
            if re.search(pattern, up, re.I) and label.upper() not in [x.upper() for x in tags]:
                tags.append(label)
        return tags[:7]

    def _info_from_message(self, msg, chat):
        parts = []
        txt = ' '.join([msg.get('filename') or '', msg.get('text') or ''])
        # Usuń @kanał z info, bo kanał/grupa jest osobnym segmentem labela.
        txt_for_tags = re.sub(r'(?<![A-Za-z0-9_])@[A-Za-z0-9_]{3,64}', ' ', txt)
        tags = self._media_info_from_text(txt_for_tags)
        if tags:
            parts.append(' '.join(tags))
        if msg.get('size'):
            parts.append(msg.get('size'))
        fname = self._best_filename_label(msg)
        if fname:
            parts.append(fname)
        # Kadr+ składa listę jako: TG • source • quality • info, więc info
        # trzymamy w stałym układzie: jakość/kodek/audio • rozmiar • nazwa_pliku.
        return ' • '.join([p for p in parts if p])[:180]

    def _size_value_bytes(self, value):
        """Convert Telegram's numeric or human-readable file size to bytes."""
        try:
            if isinstance(value, (int, float)):
                return max(0, int(value))
            match = re.search(r'(\d+(?:[.,]\d+)?)\s*([KMGT]?B)\b', str(value or ''), re.I)
            if not match:
                return 0
            amount = float(match.group(1).replace(',', '.'))
            factor = {
                'B': 1,
                'KB': 1024,
                'MB': 1024 ** 2,
                'GB': 1024 ** 3,
                'TB': 1024 ** 4,
            }[match.group(2).upper()]
            return max(0, int(amount * factor))
        except Exception:
            return 0

    def _fmt_size(self, size):
        try:
            size = int(size or 0)
            if size >= 1024 ** 3:
                return '%.2f GB' % (size / float(1024 ** 3))
            if size >= 1024 ** 2:
                return '%.0f MB' % (size / float(1024 ** 2))
        except Exception:
            pass
        return ''

    # ------------------------------------------------------------------ #
    # Config/helpers                                                       #
    # ------------------------------------------------------------------ #

    def _configured(self):
        try:
            if self.use_dialogs and self._mtproto_ready():
                return True
            if self.chats:
                return True
            fflog('[telegram] provider włączony, ale brak loginu albo listy grup/kanałów', 1)
            return False
        except Exception:
            return False

    def _normalize_phone(self, value):
        value = str(value or '').strip()
        value = re.sub(r'[\s\-().]+', '', value)
        if value and not value.startswith('+'):
            # Telegram najlepiej przyjmuje format międzynarodowy. Dla Polski
            # typowy błąd to wpisanie 48... bez plusa.
            if value.startswith('00'):
                value = '+' + value[2:]
            else:
                value = '+' + value
        return value

    def _session_dir(self):
        path = os.path.join(control.dataPath, 'telegram')
        if not os.path.exists(path):
            try:
                control.makeDirs(path)
            except Exception:
                os.makedirs(path, exist_ok=True)
        return path

    def _session_base(self):
        return os.path.join(self._session_dir(), re.sub(r'[^A-Za-z0-9._-]+', '_', self.session_name or 'kadrplus_telegram'))

    def _session_path(self):
        try:
            return self._session_base()
        except Exception:
            return self.session_name or 'kadrplus_telegram'

    def _session_meta_path(self):
        return self._session_base() + '.kadrmeta.json'

    def _session_files(self):
        base = self._session_base()
        names = [base, base + '.session', base + '.session-journal', self._session_meta_path()]
        # SQLite can create extra temporary files.
        try:
            folder = os.path.dirname(base)
            prefix = os.path.basename(base)
            for name in os.listdir(folder):
                if name.startswith(prefix + '.session'):
                    names.append(os.path.join(folder, name))
        except Exception:
            pass
        out = []
        for n in names:
            if n and n not in out:
                out.append(n)
        return out

    def _delete_session_files(self):
        """Delete a saved session, retrying handles released by failed clients."""
        # Search metadata is account-specific. Clearing it is independent from
        # Telethon/QR/session transport and guarantees that a newly logged-in
        # account never inherits the previous account's cached dialog objects.
        _tg_clear_search_metadata_cache()
        try:
            remaining = list(self._session_files())
            for attempt in range(3):
                failed = []
                for path in remaining:
                    try:
                        if os.path.exists(path):
                            os.remove(path)
                            fflog(f'[telegram] usunięto starą sesję: {os.path.basename(path)}', 1)
                    except Exception:
                        failed.append(path)
                remaining = [path for path in failed if os.path.exists(path)]
                if not remaining:
                    return True
                try:
                    import gc
                    gc.collect()
                except Exception:
                    pass
                time.sleep(0.08 * (attempt + 1))
            if remaining:
                fflog('[telegram] nie można jeszcze usunąć pliku sesji: %s' % ', '.join(os.path.basename(path) for path in remaining), 1)
            return not remaining
        except Exception:
            fflog_exc(1)
            return False

    def _load_session_phone(self):
        try:
            path = self._session_meta_path()
            if not os.path.exists(path):
                return ''
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return self._normalize_phone(data.get('phone') or '')
        except Exception:
            return ''

    def _save_session_phone(self, phone):
        try:
            path = self._session_meta_path()
            with open(path, 'w', encoding='utf-8') as f:
                json.dump({'phone': self._normalize_phone(phone), 'saved': int(time.time())}, f)
        except Exception:
            pass

    def _forget_session_phone(self):
        try:
            path = self._session_meta_path()
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass

    def _prepare_session_for_phone(self, phone):
        try:
            saved = self._load_session_phone()
            if saved and saved != self._normalize_phone(phone):
                fflog(f'[telegram] numer zmieniony: {saved!r} -> {phone!r}; czyszczę sesję', 1)
                self._delete_session_files()
        except Exception:
            fflog_exc(1)

    def _ask_text(self, heading, hidden=False):
        try:
            kb = control.keyboard('', heading, hidden)
            kb.doModal()
            if kb.isConfirmed():
                return kb.getText()
        except Exception:
            fflog_exc(1)
        return ''

    def _public_chats(self):
        out = []
        for c in self.chats:
            ch = self._public_chat_name(c)
            if ch and ch not in out:
                out.append(ch)
        return out

    def _public_chat_name(self, value):
        value = (value or '').strip()
        if not value:
            return ''
        if value.startswith('-') or value.startswith('+') or 'joinchat' in value or '/+' in value:
            return ''
        value = value.replace('https://t.me/s/', '').replace('http://t.me/s/', '')
        value = value.replace('https://t.me/', '').replace('http://t.me/', '')
        value = value.lstrip('@').split('/', 1)[0].split('?', 1)[0].strip()
        if not re.match(r'^[A-Za-z0-9_]{3,64}$', value):
            return ''
        return value

    def _log_telethon_status(self):
        try:
            TelegramClient, _, _, _, _ = _tg_telethon_imports()
            if TelegramClient:
                if self._mtproto_ready():
                    fflog('[telegram] Telethon dostępny; sprawdź login / uprawnienia / wyniki w grupach', 1)
                else:
                    fflog('[telegram] Telethon dostępny, ale brak api_id/api_hash/phone w ustawieniach', 1)
            else:
                fflog('[telegram] Telethon niedostępny mimo vendora', 1)
        except Exception:
            pass

    def _get_session(self):
        if not self.session:
            self.session = requests.Session()
            self.session.headers.update(self.headers)
        return self.session

    def _first_match(self, text, pattern):
        m = re.search(pattern, text or '', re.I | re.S)
        return m.group(1) if m else ''

    def _clean_html(self, text):
        text = text or ''
        text = re.sub(r'<br\s*/?>', ' ', text, flags=re.I)
        text = re.sub(r'<[^>]+>', ' ', text)
        text = unescape(text)
        return re.sub(r'\s+', ' ', text).strip()

    def _setting_bool(self, value, default=False):
        if value is None or value == '':
            return bool(default)
        return str(value).strip().lower() in ('true', '1', 'yes', 'on')

    def _pack(self, data):
        raw = json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        return 'telegram:' + base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')

    def _unpack(self, token):
        token = str(token or '')
        if token.startswith('telegram:'):
            token = token.split(':', 1)[1]
        pad = '=' * (-len(token) % 4)
        return json.loads(base64.urlsafe_b64decode((token + pad).encode('ascii')).decode('utf-8'))
