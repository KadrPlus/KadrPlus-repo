# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""AnimeToast provider written for Kadr+ 2.0.

The adapter searches the public WordPress catalogue and resolves only the
requested episode.  Flat episode lists are treated as season 1 unless the page
itself explicitly identifies another season; Kadr+ never maps episode numbers
to a later season by guesswork.
"""

from __future__ import annotations

import json
import re
from urllib.parse import quote_plus, urlsplit

from lib.sources.de._kadr_de_common import (
    SiteClient, absolute_http, choose_candidate, clean_text, decode_ref,
    dedup_source_rows, encode_ref, german_fallback_titles, host_label, html_attr, quality_from,
    source_row, title_score, titles_from, year_of,
)

_REF = "kadr-animetoast:"
_BASE = "https://animetoast.cc"
_BASES = (_BASE, "https://www.animetoast.cc")


def _same_site(url, base):
    left = (urlsplit(str(url or "")).hostname or "").lower().lstrip("www.")
    right = (urlsplit(str(base or "")).hostname or "").lower().lstrip("www.")
    return bool(left and right and left == right)


def _catalog_entries(html, base):
    out, seen = [], set()
    # Search cards expose canonical article anchors with title=; use those
    # rather than every page-wide link.
    for tag in re.findall(r'<a\b[^>]*href\s*=\s*["\'][^"\']+["\'][^>]*>', str(html or ""), re.I):
        href = html_attr(tag, "href")
        title = clean_text(html_attr(tag, "title"))
        url = absolute_http(href, base)
        p = urlsplit(url)
        if not title or not url or not _same_site(url, base):
            continue
        slug = p.path.strip("/")
        if not slug or "/" in slug or slug.startswith(("a-z-index", "season-", "category", "genre")):
            continue
        if url in seen:
            continue
        seen.add(url)
        label = title
        lang = "ja" if re.search(r'\b(?:ger(?:man)?\s*sub|deutsch\s*sub)\b', label, re.I) else "de"
        info = "Napisy DE" if lang == "ja" else ("Dubbing" if re.search(r'\b(?:ger(?:man)?\s*dub|deutsch)\b', label, re.I) else "")
        # Presentation suffixes are not part of title matching.
        match_title = re.sub(r'(?:\s*[\[(\-–—|]\s*|\s+)(?:ger(?:man)?\s*)?(?:dub|sub)\s*[\])]?$' , "", label, flags=re.I).strip()
        out.append({"title": match_title or label, "url": url, "label": label, "language": lang, "info": info})
    return out


def _buttons(html, base):
    out = []
    for tag, inner in re.findall(r'(<a\b[^>]*class\s*=\s*["\'][^"\']*\bmultilink-btn\b[^"\']*["\'][^>]*>)(.*?)</a>', str(html or ""), re.I | re.S):
        url = absolute_http(html_attr(tag, "href"), base)
        label = clean_text(inner)
        if url:
            out.append({"url": url, "label": label})
    return out


def _episode_number(label):
    m = re.search(r'(?:\bEp(?:isode)?\.?\s*|\bFolge\s*|^)(\d{1,4})\b', clean_text(label), re.I)
    return int(m.group(1)) if m else 0


def _season_number(label):
    m = re.search(r'\bS(?:taffel|eason)?\s*0*(\d{1,2})\b|\b(?:Staffel|Season)\s*0*(\d{1,2})\b', clean_text(label), re.I)
    if not m:
        return 0
    return int(next(x for x in m.groups() if x))


def _page_season(html):
    text = clean_text(str(html or "")[:120000])
    nums = {int(x) for x in re.findall(r'\b(?:Staffel|Season)\s*0*(\d{1,2})\b', text, re.I)}
    return next(iter(nums)) if len(nums) == 1 else 0


def _embed_external(html, base):
    block_m = re.search(r'id\s*=\s*["\']player-embed["\'][^>]*>(.*?)(?:</div>|</section>)', str(html or ""), re.I | re.S)
    block = block_m.group(1) if block_m else str(html or "")
    for pattern in (
        r'<iframe\b[^>]*\bsrc\s*=\s*(["\'])(.*?)\1',
        r'<a\b[^>]*\bhref\s*=\s*(["\'])(.*?)\1',
    ):
        for _, raw in re.findall(pattern, block, re.I | re.S):
            url = absolute_http(raw, base)
            if not url:
                continue
            p = urlsplit(url)
            if p.hostname and not _same_site(url, base):
                return url
    return ""


def _ajax_meta(html):
    nonce = ""
    m = re.search(r'iframe_loader\s*=\s*\{.*?["\']nonce["\']\s*:\s*["\']([^"\']+)', str(html or ""), re.I | re.S)
    if m:
        nonce = m.group(1)
    tm = re.search(r'class\s*=\s*["\']simple-iframe-player["\'][^>]*\bdata-title\s*=\s*["\']([^"\']+)', str(html or ""), re.I)
    title = clean_text(tm.group(1) if tm else "")
    servers = []
    sm = re.search(r'<select\b[^>]*class\s*=\s*["\'][^"\']*server-select[^"\']*["\'][^>]*>(.*?)</select>', str(html or ""), re.I | re.S)
    if sm:
        for value, label in re.findall(r'<option\b[^>]*value\s*=\s*["\']([^"\']+)["\'][^>]*>(.*?)</option>', sm.group(1), re.I | re.S):
            if value:
                servers.append((value, clean_text(label)))
    return nonce, title, servers[:8]


class source:
    has_sort_order = True
    priority = 2
    language = ["de", "ja"]

    def __init__(self):
        self.priority = 2
        self.language = ["de", "ja"]
        self.client = SiteClient("animetoast", _BASES)

    def _find(self, wanted, year=""):
        for query in wanted[:4]:
            html = self.client.get_text("/?s=" + quote_plus(query))
            items = _catalog_entries(html, self.client.base)
            ranked = []
            for item in items:
                score = max((title_score(item.get("title", ""), value) for value in wanted), default=0.0)
                if score >= 0.93:
                    ranked.append((score, item))
            ranked.sort(key=lambda pair: pair[0], reverse=True)
            for _, best in ranked[:6]:
                # Search cards usually do not carry a year.  Verify it from the
                # detail page only if the page explicitly exposes a four-digit
                # start/release year; otherwise do not invent one.  Check more
                # than one same-title card so remakes are not lost.
                if year:
                    detail = self.client.get_text(best["url"])
                    candidates = re.findall(r'(?:Season\s*Start|Start|Release|Jahr|Year)[^0-9]{0,40}((?:19|20)\d{2})', detail, re.I)
                    if candidates and year_of(year) not in set(candidates):
                        continue
                return best
        return None

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        wanted = titles_from(localtitle, title, aliases, ffitem=getattr(self, "ffitem", None), media_type="movie")
        item = self._find(wanted, year) if wanted else None
        if not item:
            fallback = german_fallback_titles(wanted, getattr(self, "ffitem", None), "movie")
            if fallback != wanted:
                item = self._find(fallback, year)
        if not item:
            return None
        return encode_ref(_REF, {"kind": "movie", "url": item["url"], "language": item["language"], "info": item["info"]})

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        wanted = titles_from(localtvshowtitle, tvshowtitle, aliases, ffitem=getattr(self, "ffitem", None), media_type="show")
        item = self._find(wanted, year) if wanted else None
        if not item:
            fallback = german_fallback_titles(wanted, getattr(self, "ffitem", None), "show")
            if fallback != wanted:
                item = self._find(fallback, year)
        if not item:
            return None
        return encode_ref(_REF, {"kind": "show", "url": item["url"], "language": item["language"], "info": item["info"]})

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        ref = decode_ref(_REF, url)
        if not ref or ref.get("kind") != "show":
            return None
        try:
            season_i, episode_i = int(season), int(episode)
        except Exception:
            return None
        if season_i <= 0 or episode_i <= 0:
            return None
        html = self.client.get_text(ref.get("url", ""))
        if not html:
            return None
        buttons = _buttons(html, self.client.base)
        # Some articles expose one button per season/range.  Follow only the
        # explicitly requested season, then locate the exact episode there.
        season_buttons = [b for b in buttons if _season_number(b["label"])]
        if season_buttons:
            picked = next((b for b in season_buttons if _season_number(b["label"]) == season_i), None)
            if not picked:
                return None
            sub_html = self.client.get_text(picked["url"], referer=ref.get("url", ""))
            ep_buttons = _buttons(sub_html, self.client.base)
            exact = next((b for b in ep_buttons if _episode_number(b["label"]) == episode_i), None)
            if exact:
                return encode_ref(_REF, {"kind": "episode", "mode": "button", "url": exact["url"], "language": ref.get("language", "de"), "info": ref.get("info", "")})
            return None

        # Flat list: use it only for S1 unless the page explicitly identifies a
        # single other season.  This prevents S02E01 -> first S1 episode errors.
        declared = _page_season(html)
        if season_i != (declared or 1):
            return None
        exact = next((b for b in buttons if _episode_number(b["label"]) == episode_i), None)
        if exact:
            return encode_ref(_REF, {"kind": "episode", "mode": "button", "url": exact["url"], "language": ref.get("language", "de"), "info": ref.get("info", "")})

        nonce, ajax_title, servers = _ajax_meta(html)
        if nonce and ajax_title and servers:
            return encode_ref(_REF, {
                "kind": "episode", "mode": "ajax", "url": ref.get("url", ""),
                "nonce": nonce, "ajax_title": ajax_title, "episode": episode_i,
                "servers": servers, "language": ref.get("language", "de"), "info": ref.get("info", ""),
            })
        return None

    def _resolve_button(self, page_url):
        html = self.client.get_text(page_url)
        external = _embed_external(html, self.client.base)
        if external:
            return external
        # One internal trampoline is common; follow it only inside AnimeToast.
        m = re.search(r'id\s*=\s*["\']player-embed["\'][^>]*>.*?(?:href|src)\s*=\s*(["\'])(.*?)\1', html, re.I | re.S)
        if m:
            inner = absolute_http(m.group(2), self.client.base)
            if inner and _same_site(inner, self.client.base) and inner != page_url:
                return _embed_external(self.client.get_text(inner, referer=page_url), self.client.base)
        return ""

    def _ajax_sources(self, ref):
        out = []
        for server, label in ref.get("servers", [])[:8]:
            response = self.client.post_text(
                "/wp-admin/admin-ajax.php",
                data={
                    "action": "get_episode_data", "title": ref.get("ajax_title", ""),
                    "server": server, "nonce": ref.get("nonce", ""), "episode": str(ref.get("episode") or ""),
                },
                headers={"Content-Type": "application/x-www-form-urlencoded", "X-Requested-With": "XMLHttpRequest"},
                referer=ref.get("url", ""),
            )
            try:
                payload = json.loads(response)
            except Exception:
                payload = None
            data = payload.get("data") if isinstance(payload, dict) and payload.get("success") else None
            raw = data.get("url") if isinstance(data, dict) else ""
            url = absolute_http(raw, self.client.base)
            if url and not _same_site(url, self.client.base):
                out.append({"url": url, "name": label or host_label(url), "quality": quality_from(label)})
        return out

    def sources(self, url, hostDict, hostprDict, **kwargs):
        ref = decode_ref(_REF, url)
        if not ref or ref.get("kind") not in ("movie", "episode"):
            return []
        raw = []
        if ref.get("kind") == "movie":
            html = self.client.get_text(ref.get("url", ""))
            for button in _buttons(html, self.client.base)[:8]:
                resolved = self._resolve_button(button["url"])
                if resolved:
                    raw.append({"url": resolved, "name": host_label(resolved), "quality": quality_from(button["label"])})
            if not raw:
                direct = _embed_external(html, self.client.base)
                if direct:
                    raw.append({"url": direct, "name": host_label(direct), "quality": "HD"})
        elif ref.get("mode") == "button":
            resolved = self._resolve_button(ref.get("url", ""))
            if resolved:
                raw.append({"url": resolved, "name": host_label(resolved), "quality": "HD"})
        elif ref.get("mode") == "ajax":
            raw = self._ajax_sources(ref)

        rows = []
        language = ref.get("language") or "de"
        info = ref.get("info") or ("Napisy DE" if language == "ja" else "")
        for item in raw:
            row = source_row(item.get("url"), hostDict, hostprDict, name=item.get("name", ""), quality=item.get("quality", "HD"), language=language, info=info)
            if row:
                rows.append(row)
        return dedup_source_rows(rows)

    def resolve(self, url):
        return url
