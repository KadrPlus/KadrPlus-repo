# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""Vavoo source adapter written for Kadr+ 2.0.

The adapter follows the public JSON requests made by the vavoo.to web client.
It contains no copied add-on code, embedded application token, persistent
hardware/device identity or disabled TLS verification.

Kadr+ keeps the existing mediahubmx-source flow as the primary path.  When the
selected Vavoo entry is not already a direct media URL, resolve() may ask the
MediaHub resolver for a fresh direct URL.  If that resolver requires a Vavoo
application signature, Kadr+ creates an ephemeral in-memory identifier only for
that Kodi process; it is never written to disk and contains no real device
metadata.  Resolver task requests are sandboxed to public HTTP(S) endpoints.
"""

from __future__ import annotations

import base64
import ipaddress
import json
import re
import socket
import time
import uuid
from urllib.parse import urljoin, urlsplit

from lib.ff import requests, source_utils
from lib.ff.log_utils import fflog, fflog_exc


_API_URL = "https://vavoo.to/mediahubmx-source.json"
_RESOLVE_URL = "https://vavoo.to/mediahubmx-resolve.json"
_PING_URL = "https://www.vavoo.tv/api/app/ping"
_REF_PREFIX = "kadr-vavoo:"
_CLIENT_VERSION = "3.1.0"
_APP_VERSION = "4.2.2"
_APP_PACKAGE = "tv.vavoo.app"
_SIGNATURE_TTL = 600.0
_RESOLVE_MAX_STEPS = 5
_RESOLVE_TOTAL_SECONDS = 35.0
_TASK_MAX_BYTES = 2 * 1024 * 1024
_TASK_MAX_REDIRECTS = 3
_DIRECT_EXTENSIONS = (".m3u8", ".mpd", ".mp4", ".webm", ".ts")
_QUALITY_ORDER = {"4K": 0, "1440p": 1, "1080p": 2, "720p": 3, "HD": 4, "SD": 5}
_BLOCKED_TASK_HEADERS = frozenset({
    "host",
    "content-length",
    "transfer-encoding",
    "connection",
    "proxy-authorization",
    "proxy-authenticate",
    "proxy-connection",
    "forwarded",
    "x-forwarded-for",
    "x-forwarded-host",
    "x-forwarded-proto",
    "x-real-ip",
})


def _positive_int(value):
    try:
        value = int(value)
        return value if value > 0 else None
    except (TypeError, ValueError):
        return None


def _encode_ref(data):
    raw = json.dumps(data, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return _REF_PREFIX + base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _decode_ref(value):
    value = str(value or "")
    if not value.startswith(_REF_PREFIX):
        # Read a cached reference created by Kadr+ 2.0.58, then immediately
        # convert it to the new self-contained format on the next method call.
        legacy = re.fullmatch(r"(movie|series):(\d+)(?::(\d+):(\d+))?", value)
        if not legacy:
            return None
        result = {"type": legacy.group(1), "tmdb_id": int(legacy.group(2))}
        if result["type"] == "series" and legacy.group(3) and legacy.group(4):
            result.update({"season": int(legacy.group(3)), "episode": int(legacy.group(4))})
        return result
    try:
        token = value[len(_REF_PREFIX):]
        token += "=" * (-len(token) % 4)
        result = json.loads(base64.urlsafe_b64decode(token.encode("ascii")).decode("utf-8"))
        kind = result.get("type")
        tmdb_id = _positive_int(result.get("tmdb_id"))
        if kind not in ("movie", "series") or not tmdb_id:
            return None
        clean = {"type": kind, "tmdb_id": tmdb_id}
        if kind == "series":
            season = _positive_int(result.get("season"))
            episode = _positive_int(result.get("episode"))
            if season:
                clean["season"] = season
            if episode:
                clean["episode"] = episode
        return clean
    except Exception:
        return None


def _quality(value):
    value = str(value or "").upper()
    if re.search(r"(?:2160|\b4K\b|\bUHD\b)", value):
        return "4K"
    if "1440" in value:
        return "1440p"
    if re.search(r"1080|\bFHD\b", value):
        return "1080p"
    if re.search(r"720|\bHD\b", value):
        return "720p"
    return "SD"


def _language_codes(value):
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, (tuple, list, set)):
        return set()
    result = set()
    for item in value:
        code = str(item or "").strip().lower().replace("_", "-").split("-", 1)[0]
        if code:
            result.add(code)
    return result


def _is_direct(item, link):
    mime = str(item.get("mimeType") or item.get("mime_type") or item.get("contentType") or "").lower()
    path = urlsplit(str(link or "").split("|", 1)[0]).path.lower()
    return (
        mime in (
            "application/vnd.apple.mpegurl",
            "application/x-mpegurl",
            "application/dash+xml",
            "video/mp4",
            "video/webm",
            "video/mp2t",
        )
        or path.endswith(_DIRECT_EXTENSIONS)
    )


def _diag(stage, message=""):
    """Privacy-safe Vavoo diagnostics, enabled only by the global diagnostics switch."""
    try:
        from lib.ff import diagnostics
        if not diagnostics.enabled():
            return
        diagnostics.log_event("vavoo", f"stage={stage}; {message}".rstrip("; "))
    except Exception:
        pass


def _public_ip(value):
    try:
        return ipaddress.ip_address(value).is_global
    except ValueError:
        return False


def _public_http_url(value, *, resolve_dns=True):
    """Return a parsed URL only for public HTTP(S) destinations.

    Resolver task requests are untrusted server instructions.  Blocking private,
    loopback, link-local and non-default-port destinations prevents them from
    becoming an SSRF bridge into the user's LAN or Kodi host.
    """
    try:
        parsed = urlsplit(str(value or "").strip())
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            return None
        if parsed.username is not None or parsed.password is not None:
            return None
        try:
            port = parsed.port
        except ValueError:
            return None
        if port not in (None, 80, 443):
            return None
        if parsed.scheme == "http" and port not in (None, 80):
            return None
        if parsed.scheme == "https" and port not in (None, 443):
            return None

        host = parsed.hostname.rstrip(".").lower()
        if (
            not host
            or host == "localhost"
            or host.endswith(".localhost")
            or host.endswith(".local")
            or host.endswith(".internal")
            or host.endswith(".home.arpa")
        ):
            return None

        try:
            literal_ip = ipaddress.ip_address(host)
        except ValueError:
            literal_ip = None
        if literal_ip is not None:
            return parsed if literal_ip.is_global else None

        if resolve_dns:
            try:
                answers = socket.getaddrinfo(host, port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)
            except OSError:
                return None
            ips = {entry[4][0].split("%", 1)[0] for entry in answers if entry and entry[4]}
            if not ips or not all(_public_ip(ip) for ip in ips):
                return None
        return parsed
    except Exception:
        return None


def _filtered_task_headers(value, scheme):
    if not isinstance(value, dict):
        return {}
    result = {}
    for key, raw_value in list(value.items())[:64]:
        key = str(key or "").strip()
        header = key.lower()
        if not key or header in _BLOCKED_TASK_HEADERS or header.startswith("proxy-"):
            continue
        text = str(raw_value or "")
        if "\r" in key or "\n" in key or "\r" in text or "\n" in text:
            continue
        if len(key) > 128 or len(text) > 8192:
            continue
        if scheme != "https" and header in ("authorization", "cookie"):
            continue
        result[key] = text
    return result


def _task_body(params):
    if not isinstance(params, dict):
        return None
    body = params.get("body")
    if body is None:
        body = params.get("data")
    if body is None:
        return None
    if isinstance(body, (dict, list)):
        try:
            body = json.dumps(body, separators=(",", ":"))
        except Exception:
            return None
    if not isinstance(body, (str, bytes, bytearray)):
        body = str(body)
    raw = body.encode("utf-8") if isinstance(body, str) else bytes(body)
    return raw if len(raw) <= 512 * 1024 else None


def _resolved_media_url(data):
    """Extract only a clearly playable public media URL from resolver output."""
    item = None
    if isinstance(data, list) and data and isinstance(data[0], dict):
        item = data[0]
    elif isinstance(data, dict) and data.get("kind") != "taskRequest":
        if isinstance(data.get("data"), dict) and data["data"].get("url"):
            item = data["data"]
        elif data.get("url"):
            item = data
    if not isinstance(item, dict):
        return ""
    link = str(item.get("url") or "").strip()
    if not link or _public_http_url(link.split("|", 1)[0]) is None:
        return ""
    return link if _is_direct(item, link) else ""


class source:
    has_sort_order = True
    priority = 2
    language = ["de"]

    def __init__(self):
        self.priority = 2
        self.language = ["de"]
        self.session = None
        self._resolve_session = None
        self._task_session = None
        self._response_cache = {}
        self._ephemeral_device_id = ""
        self._signature = ""
        self._signature_time = 0.0
        self.headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/140.0.0.0 Safari/537.36"
            ),
            "Accept": "application/json",
            "Content-Type": "application/json; charset=utf-8",
            "Origin": "https://vavoo.to",
            "Referer": "https://vavoo.to/",
        }

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        tmdb_id = self._movie_tmdb_id()
        if not tmdb_id:
            fflog("[vavoo] missing movie tmdb_id", 1)
            return None
        return _encode_ref({"type": "movie", "tmdb_id": tmdb_id})

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        tmdb_id = self._show_tmdb_id()
        if not tmdb_id:
            fflog("[vavoo] missing series tmdb_id", 1)
            return None
        return _encode_ref({"type": "series", "tmdb_id": tmdb_id})

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        item = _decode_ref(url)
        season = _positive_int(season)
        episode = _positive_int(episode)
        if not item or item["type"] != "series" or not season or not episode:
            return None
        item.update({"season": season, "episode": episode})
        return _encode_ref(item)

    def sources(self, url, hostDict, hostprDict):
        item = _decode_ref(url)
        if not item:
            return []
        try:
            raw = self._fetch(item)
            result, seen = [], set()
            for entry in raw:
                if not isinstance(entry, dict):
                    continue
                if entry.get("type") not in (None, "url"):
                    continue

                link = str(entry.get("url") or "").strip()
                parsed = urlsplit(link)
                if parsed.scheme not in ("http", "https") or not parsed.hostname or link in seen:
                    continue
                languages = _language_codes(entry.get("languages"))
                if languages and "de" not in languages:
                    continue
                seen.add(link)

                valid, hoster = source_utils.is_host_valid(link, hostDict)
                if not valid:
                    valid, hoster = source_utils.is_host_valid(link, hostprDict)
                if not hoster:
                    hoster = parsed.hostname
                    if hoster.startswith("www."):
                        hoster = hoster[4:]

                tag = str(entry.get("tag") or "").strip()
                server_name = str(entry.get("name") or "").strip()
                quality = _quality(" ".join((tag, server_name, link)))
                details = ["Dubbing DE"]
                if server_name:
                    details.append(server_name)
                if tag and tag.lower() not in server_name.lower():
                    details.append(tag)

                result.append({
                    "source": hoster,
                    "quality": quality,
                    "language": "de",
                    "url": link,
                    "info": " | ".join(details),
                    "direct": _is_direct(entry, link),
                    "debridonly": False,
                })

            result.sort(key=lambda item: _QUALITY_ORDER.get(item["quality"], 99))
            fflog(f"[vavoo] sources={len(result)}", 1)
            return result
        except Exception:
            fflog_exc()
            return []

    def resolve(self, url, **kwargs):
        original = str(url or "").strip()
        if not original:
            return None
        # Preserve the historical fast path for already-direct Vavoo entries.
        if _is_direct({}, original):
            return original
        try:
            resolved = self._resolve_mediahub(original)
            if resolved:
                _diag("resolve", "mediahub=ok")
                return resolved
            _diag("resolve", "mediahub=fallback-original")
        except Exception:
            _diag("resolve", "mediahub=exception")
        # Additive fallback only: ordinary Kadr+/ResolveURL handling remains
        # available whenever MediaHub cannot produce a clearly direct URL.
        return original

    def _movie_tmdb_id(self):
        return _positive_int(getattr(getattr(self, "ffitem", None), "tmdb_id", None))

    def _show_tmdb_id(self):
        ffitem = getattr(self, "ffitem", None)
        show_item = getattr(ffitem, "show_item", None)
        return _positive_int(getattr(show_item, "tmdb_id", None)) or _positive_int(
            getattr(ffitem, "tmdb_id", None)
        )

    def _payload(self, item):
        payload = {
            "language": "de",
            "region": "DE",
            "type": item["type"],
            "ids": {"tmdb_id": item["tmdb_id"]},
            "name": "",
        }
        if item["type"] == "series":
            season = _positive_int(item.get("season"))
            episode = _positive_int(item.get("episode"))
            if not season or not episode:
                return None
            payload["episode"] = {
                "ids": {},
                "season": season,
                "episode": episode,
            }
        return payload

    def _fetch(self, item):
        payload = self._payload(item)
        if not payload:
            return []
        cache_key = json.dumps(payload, separators=(",", ":"), sort_keys=True)
        if cache_key in self._response_cache:
            return self._response_cache[cache_key]

        self._init_session()
        response = self.session.post(
            _API_URL,
            json=payload,
            headers=self.headers,
            timeout=(8, 30),
            allow_redirects=True,
        )
        if response.status_code != 200:
            fflog(f"[vavoo] HTTP {response.status_code}", 1)
            return []
        data = response.json()
        if isinstance(data, dict) and data.get("error"):
            fflog(f"[vavoo] API error: {data.get('error')}", 1)
            return []
        if not isinstance(data, list):
            return []
        self._response_cache[cache_key] = data
        return data

    def _resolve_payload(self, **extra):
        payload = {
            "language": "de",
            "region": "DE",
            "clientVersion": _CLIENT_VERSION,
        }
        payload.update(extra)
        return payload

    def _resolve_headers(self, signature=""):
        headers = {
            "User-Agent": "MediaHubMX/2",
            "Accept": "application/json",
            "Accept-Language": "de-DE,de;q=0.9,en;q=0.5",
            "Accept-Encoding": "gzip, deflate",
            "Content-Type": "application/json; charset=utf-8",
        }
        if signature:
            headers["mediahubmx-signature"] = signature
        return headers

    def _post_resolve(self, payload, signature=""):
        self._init_resolve_session()
        try:
            response = self._resolve_session.post(
                _RESOLVE_URL,
                json=payload,
                headers=self._resolve_headers(signature),
                timeout=(5, 12),
                allow_redirects=False,
            )
            status = int(getattr(response, "status_code", 0) or 0)
            if status != 200:
                return None, status
            try:
                return response.json(), status
            except Exception:
                return None, status
        except Exception:
            return None, 0

    @staticmethod
    def _signature_needed(data, status):
        if status in (401, 403):
            return True
        if not isinstance(data, dict):
            return False
        message = " ".join(str(data.get(key) or "") for key in ("error", "message", "detail")).lower()
        return "signature" in message or "unauthor" in message or "forbidden" in message

    def _ephemeral_signature(self, force=False):
        now = time.monotonic()
        if not force and self._signature and now - self._signature_time < _SIGNATURE_TTL:
            return self._signature
        if not self._ephemeral_device_id:
            # Deliberately process-local only: no file, Android ID, MAC, serial,
            # hardware model or other stable fingerprint is used.
            self._ephemeral_device_id = str(uuid.uuid4())

        stamp = int(time.time() * 1000)
        payload = {
            "reason": "app-focus",
            "locale": "de",
            "theme": "dark",
            "metadata": {
                "device": {"type": "desktop", "uniqueId": self._ephemeral_device_id},
                "os": {"name": "linux", "version": "generic", "abis": ["x64"], "host": "kadr"},
                "app": {"platform": "electron"},
                "version": {
                    "package": _APP_PACKAGE,
                    "binary": _APP_VERSION,
                    "js": _APP_VERSION,
                },
            },
            "appFocusTime": 0,
            "playerActive": False,
            "playDuration": 0,
            "devMode": False,
            "hasAddon": True,
            "castConnected": False,
            "package": _APP_PACKAGE,
            "version": _APP_VERSION,
            "process": "app",
            "firstAppStart": stamp,
            "lastAppStart": stamp,
            "ipLocation": None,
            "adblockEnabled": True,
            "proxy": {"supported": ["ss"], "engine": "Mu", "enabled": False, "autoServer": True},
            "iap": {"supported": False},
        }
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) vavoo/4.2.2 Chrome/146.0.0.0 "
                "Electron/41.1.0 Safari/537.36"
            ),
            "Accept": "*/*",
            "Accept-Language": "de-DE,de;q=0.9,en;q=0.5",
            "Content-Type": "application/json",
            "Origin": "https://vavoo.to",
            "Referer": "https://vavoo.to/",
        }
        self._init_resolve_session()
        try:
            response = self._resolve_session.post(
                _PING_URL,
                json=payload,
                headers=headers,
                timeout=(5, 10),
                allow_redirects=False,
            )
            if response.status_code != 200:
                _diag("signature", f"status={response.status_code}")
                return ""
            data = response.json()
            signature = str(data.get("addonSig") or "") if isinstance(data, dict) else ""
            if not signature or len(signature) > 4096:
                return ""
            self._signature = signature
            self._signature_time = time.monotonic()
            _diag("signature", "result=ok; identity=ephemeral-memory-only")
            return signature
        except Exception:
            _diag("signature", "result=error")
            return ""

    def _resolve_mediahub(self, stream_url):
        if _public_http_url(stream_url.split("|", 1)[0]) is None:
            return ""
        deadline = time.monotonic() + _RESOLVE_TOTAL_SECONDS
        signature = ""
        payload = self._resolve_payload(url=stream_url)
        data, status = self._post_resolve(payload, signature)

        if self._signature_needed(data, status):
            signature = self._ephemeral_signature()
            if not signature:
                return ""
            data, status = self._post_resolve(payload, signature)

        for step in range(_RESOLVE_MAX_STEPS):
            if time.monotonic() >= deadline:
                _diag("resolve", f"step={step}; result=deadline")
                return ""
            resolved = _resolved_media_url(data)
            if resolved:
                return resolved
            if not (isinstance(data, dict) and data.get("kind") == "taskRequest"):
                return ""

            task_id = str(data.get("id") or "")
            task_data = data.get("data") if isinstance(data.get("data"), dict) else {}
            if not task_id or not task_data:
                return ""
            task_result = self._perform_task(task_data, deadline)
            if not task_result:
                return ""
            payload = self._resolve_payload(
                kind="taskResponse",
                id=task_id,
                data=task_result,
            )
            data, status = self._post_resolve(payload, signature)
            if self._signature_needed(data, status):
                # At most one refresh in an active resolve chain.
                signature = self._ephemeral_signature(force=True)
                if not signature:
                    return ""
                data, status = self._post_resolve(payload, signature)
        return ""

    def _perform_task(self, task_data, deadline):
        fetch_url = str(task_data.get("url") or "").strip()
        params = task_data.get("params") if isinstance(task_data.get("params"), dict) else {}
        method = str(params.get("method") or "GET").upper()
        if method not in ("GET", "POST"):
            _diag("task", "result=blocked-method")
            return {"error": "unsupported task method"}

        current = fetch_url
        has_body = "body" in params or "data" in params
        body = _task_body(params) if method == "POST" else None
        if method == "POST" and has_body and body is None:
            _diag("task", "result=blocked-body")
            return {"error": "invalid or oversized task body"}
        self._init_task_session()
        for redirect_count in range(_TASK_MAX_REDIRECTS + 1):
            if time.monotonic() >= deadline:
                return {"error": "task deadline exceeded"}
            parsed = _public_http_url(current)
            if parsed is None:
                _diag("task", "result=blocked-url")
                return {"error": "blocked task destination"}
            headers = _filtered_task_headers(params.get("headers"), parsed.scheme)
            response = None
            try:
                response = self._task_session.request(
                    method,
                    current,
                    headers=headers,
                    data=body,
                    timeout=(5, 10),
                    allow_redirects=False,
                    stream=True,
                )
                status = int(response.status_code)
                if status in (301, 302, 303, 307, 308):
                    location = str(response.headers.get("Location") or "").strip()
                    if not location or redirect_count >= _TASK_MAX_REDIRECTS:
                        return {"error": "task redirect rejected"}
                    current = urljoin(current, location)
                    if status == 303 or (status in (301, 302) and method == "POST"):
                        method, body = "GET", None
                    continue

                chunks = []
                total = 0
                for chunk in response.iter_content(chunk_size=65536):
                    if not chunk:
                        continue
                    total += len(chunk)
                    if total > _TASK_MAX_BYTES:
                        _diag("task", "result=body-too-large")
                        return {"error": "task response too large"}
                    chunks.append(chunk)
                raw = b"".join(chunks)
                encoding = getattr(response, "encoding", None) or "utf-8"
                try:
                    text = raw.decode(encoding, "replace")
                except (LookupError, TypeError):
                    text = raw.decode("utf-8", "replace")
                _diag("task", f"result=ok; status={status}; redirects={redirect_count}")
                return {"text": text, "status": status}
            except Exception:
                _diag("task", "result=request-error")
                return {"error": "task request failed"}
            finally:
                try:
                    if response is not None:
                        response.close()
                except Exception:
                    pass
        return {"error": "task redirect rejected"}

    def _init_session(self):
        if self.session is None:
            self.session = requests.Session(cache=False)
            self.session.headers.update(self.headers)

    def _init_resolve_session(self):
        if self._resolve_session is None:
            self._resolve_session = requests.Session(cache=False)

    def _init_task_session(self):
        if self._task_session is None:
            self._task_session = requests.Session(cache=False)
            # Task requests must never inherit cookies collected from source or
            # signature endpoints.
            try:
                self._task_session.cookies.clear()
            except Exception:
                pass
