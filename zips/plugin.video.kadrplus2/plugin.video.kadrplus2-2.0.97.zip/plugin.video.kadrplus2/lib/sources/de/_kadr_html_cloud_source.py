# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""Base class for Kadr+ HTML catalogues backed by external hoster/player pages."""

from __future__ import annotations

from urllib.parse import urlsplit

from lib.sources.de._kadr_cloud_common import collect_page_streams
from lib.sources.de._kadr_de_common import (
    register,
    SiteClient, diag, choose_candidate, choose_series_candidate, clean_text, decode_ref, dedup_source_rows,
    encode_ref, german_fallback_titles, source_row, titles_from, year_of,
)


class HtmlCloudSource:
    has_sort_order = True
    priority = 2
    language = ["de"]
    provider_name = "htmlcloud"
    base_urls = ()
    ref_prefix = "kadr-htmlcloud:"

    def __init__(self):
        self.priority = 2
        self.language = ["de"]
        self.client = SiteClient(self.provider_name, self.base_urls)

    def _search_items(self, query):
        raise NotImplementedError

    def _find(self, wanted, year="", *, season=0, expect_series=None):
        attempts = 0
        total_items = 0
        for query in wanted[:4]:
            attempts += 1
            items = self._search_items(query)
            total_items += len(items)
            diag(self.provider_name, 'search', 'attempt=%d items=%d season=%d' % (attempts, len(items), int(season or 0)))
            if season:
                matching = [x for x in items if int(x.get("season") or 0) in (0, int(season))]
                if matching:
                    items = matching
            if expect_series is not None:
                typed = [x for x in items if x.get("is_series") is not None and bool(x.get("is_series")) == bool(expect_series)]
                if typed:
                    items = typed
            best = (choose_series_candidate(items, wanted, year, min_score=0.93, season=season)
                    if season else choose_candidate(items, wanted, year, min_score=0.93, season=season))
            if best:
                diag(self.provider_name, 'search-match', 'attempt=%d total_items=%d season=%d' % (attempts, total_items, int(season or 0)))
                return best
        diag(self.provider_name, 'search-empty', 'attempts=%d total_items=%d season=%d' % (attempts, total_items, int(season or 0)))
        return None

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        wanted = titles_from(localtitle, title, aliases, ffitem=getattr(self, "ffitem", None), media_type="movie")
        item = self._find(wanted, year, expect_series=False) if wanted else None
        if not item:
            # Some catalogues do not mark media type in their search cards.
            item = self._find(wanted, year, expect_series=None) if wanted else None
        if not item:
            fallback = german_fallback_titles(wanted, getattr(self, "ffitem", None), "movie")
            if fallback:
                item = self._find(fallback, year, expect_series=False)
                if not item:
                    item = self._find(fallback, year, expect_series=None)
        if not item:
            return None
        return encode_ref(self.ref_prefix, {
            "kind": "movie", "url": item.get("url", ""),
            "year": year_of(item.get("year") or year),
        })

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        wanted = titles_from(localtvshowtitle, tvshowtitle, aliases, ffitem=getattr(self, "ffitem", None), media_type="show")
        if not wanted:
            return None
        # Search again in episode() with the actual season so a catalogue that
        # stores one page per Staffel cannot lock us to the wrong season here.
        return encode_ref(self.ref_prefix, {
            "kind": "show", "titles": wanted, "year": year_of(year),
        })

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        ref = decode_ref(self.ref_prefix, url)
        if not ref or ref.get("kind") != "show":
            return None
        try:
            s, e = int(season), int(episode)
        except Exception:
            return None
        if s <= 0 or e <= 0:
            return None
        wanted = [clean_text(x) for x in ref.get("titles", []) if clean_text(x)]
        item = self._find(wanted, ref.get("year", ""), season=s, expect_series=True)
        if not item:
            item = self._find(wanted, ref.get("year", ""), season=s, expect_series=None)
        if not item:
            fallback = german_fallback_titles(wanted, getattr(self, "ffitem", None), "show")
            if fallback != wanted:
                item = self._find(fallback, ref.get("year", ""), season=s, expect_series=True)
                if not item:
                    item = self._find(fallback, ref.get("year", ""), season=s, expect_series=None)
        if not item:
            return None
        if item.get("season") and int(item["season"]) != s:
            return None
        return encode_ref(self.ref_prefix, {
            "kind": "episode", "url": item.get("url", ""), "season": s, "episode": e,
        })

    def sources(self, url, hostDict, hostprDict, **kwargs):
        ref = decode_ref(self.ref_prefix, url)
        if not ref or ref.get("kind") not in ("movie", "episode") or not ref.get("url"):
            return []
        raw = collect_page_streams(
            self.client, ref["url"],
            season=int(ref.get("season") or 0), episode=int(ref.get("episode") or 0),
        )
        diag(self.provider_name, 'sources', 'kind=%s season=%d episode=%d raw=%d' % (
            ref.get('kind'), int(ref.get('season') or 0), int(ref.get('episode') or 0), len(raw),
        ))
        rows = []
        rejected_hosts = set()
        for item in raw:
            row = source_row(
                item.get("url"), hostDict, hostprDict,
                name=item.get("name", ""), quality=item.get("quality", "HD"),
                language="de", info=item.get("info", ""),
            )
            if row:
                rows.append(row)
            else:
                host = (urlsplit(str(item.get("url") or "")).hostname or "").lower()
                if host:
                    rejected_hosts.add(host)
        if raw and not rows and rejected_hosts:
            # Hostname only: enough to identify a missing resolver without
            # exposing embed tokens, paths or query parameters in diagnostics.
            diag(self.provider_name, 'source-filter', 'rejected_hosts=%s' % ','.join(sorted(rejected_hosts)[:8]))
        return dedup_source_rows(rows)

    def resolve(self, url):
        return url
