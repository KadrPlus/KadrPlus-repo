# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""Shared Kadr+ implementation for small German JSON catalogue providers."""

from __future__ import annotations

import re
import time
from urllib.parse import quote, urlsplit

from lib.sources.de._kadr_de_common import (
    register,
    SiteClient, choose_candidate, choose_series_candidate, clean_text, decode_ref, dedup_source_rows,
    diag, encode_ref, german_fallback_titles, host_label, normalize_title, quality_from, source_row,
    titles_from, year_of,
)


_SEASON_SUFFIX_RE = re.compile(r"\s*[-–—:]?\s*(?:staffel|season)\s*0*(\d+)\b.*$", re.I)


class JsonCatalogSource:
    has_sort_order = True
    priority = 2
    language = ["de"]
    provider_name = "jsoncatalog"
    base_urls = ()
    ref_prefix = "kadr-json:"
    search_params = ("keyword", "search")
    search_path_template = ""
    catalog_path = ""
    catalog_year_path_template = ""
    catalog_max_bytes = 32 * 1024 * 1024
    request_headers = None
    max_query_transport_failures = 1

    def __init__(self):
        self.priority = 2
        self.language = ["de"]
        self.client = SiteClient(self.provider_name, self.base_urls, headers=self.request_headers)
        self._catalog_items = None
        self._catalog_index = None
        self._catalog_compact_index = None
        self._year_catalog_cache = {}
        self._catalog_failed = False
        self._search_failed = False
        self._query_transport_failures = 0

    @staticmethod
    def _candidate_title(item):
        title = clean_text((item or {}).get("title") or (item or {}).get("name"))
        return _SEASON_SUFFIX_RE.sub("", title).strip()

    @staticmethod
    def _candidate_season(item):
        try:
            value = int((item or {}).get("s") or (item or {}).get("season") or 0)
        except Exception:
            value = 0
        if value:
            return value
        m = _SEASON_SUFFIX_RE.search(clean_text((item or {}).get("title") or ""))
        return int(m.group(1)) if m else 0

    def _items_from_payload(self, payload):
        if not isinstance(payload, dict):
            return []
        movies = payload.get("movies")
        if not isinstance(movies, list):
            return []
        results = []
        seen = set()
        for raw in movies:
            if not isinstance(raw, dict):
                continue
            mid = str(raw.get("_id") or raw.get("id") or "").strip()
            if not mid or mid in seen:
                continue
            seen.add(mid)
            item = dict(raw)
            item["_id"] = mid
            item["title"] = self._candidate_title(raw)
            item["season"] = self._candidate_season(raw)
            results.append(item)
        return results

    def _filter_media(self, items, *, season=0, movie=True):
        out = []
        for item in items or ():
            cand_season = self._candidate_season(item)
            if season:
                if cand_season and cand_season != int(season):
                    continue
            elif movie and cand_season:
                continue
            out.append(item)
        return out

    @staticmethod
    def _compact_key(value):
        return normalize_title(value).replace(" ", "")

    def _build_catalog_index(self):
        """Build O(1)-style lookup maps once for KKiste's client-side catalogue.

        The public frontend/global-search flow downloads the whole catalogue and
        filters locally.  Running SequenceMatcher across ~40k rows for every
        alias is unnecessarily expensive on Android.  Kadr+ instead indexes the
        same normalized title once, then runs the existing strict matcher only
        on the tiny candidate bucket.
        """
        if self._catalog_index is not None and self._catalog_compact_index is not None:
            return
        started = time.perf_counter()
        exact = {}
        compact = {}
        for item in self._catalog_items or ():
            title = self._candidate_title(item)
            key = normalize_title(title)
            if not key:
                continue
            exact.setdefault(key, []).append(item)
            # A compact secondary key is only useful for acronym-like titles
            # whose punctuation splits letters (S.W.A.T. -> s w a t).  Avoid a
            # second 40k-key map for ordinary multi-word titles.
            tokens = key.split()
            if any(len(token) == 1 for token in tokens):
                ckey = key.replace(" ", "")
                if ckey:
                    compact.setdefault(ckey, []).append(item)
        self._catalog_index = exact
        self._catalog_compact_index = compact
        diag(
            self.provider_name, "search-index",
            "items=%d exact_keys=%d compact_keys=%d elapsed_ms=%d" % (
                len(self._catalog_items or ()), len(exact), len(compact),
                int((time.perf_counter() - started) * 1000),
            ),
        )

    def _catalog_candidates(self, query):
        """Return only exact-normalized catalogue buckets for a query.

        Punctuation/apostrophe/umlaut/year/season presentation differences are
        already normalized by ``normalize_title``.  Compact lookup additionally
        covers forms such as ``S.W.A.T.`` vs ``SWAT``.  No fuzzy full-catalogue
        scan is performed here; ``choose_candidate`` remains the final strict
        title/year/season authority.
        """
        qnorm = normalize_title(query)
        if not qnorm:
            return []
        self._build_catalog_index()
        out = []
        seen = set()
        for item in (self._catalog_index or {}).get(qnorm, ()):
            mid = str(item.get("_id") or "")
            if mid and mid not in seen:
                seen.add(mid)
                out.append(item)
        ckey = qnorm.replace(" ", "")
        if ckey and (len(qnorm.split()) == 1 or any(len(token) == 1 for token in qnorm.split())):
            for item in (self._catalog_compact_index or {}).get(ckey, ()):
                mid = str(item.get("_id") or "")
                if mid and mid not in seen:
                    seen.add(mid)
                    out.append(item)
        diag(self.provider_name, "search-lookup", "query_key_len=%d candidates=%d" % (len(qnorm), len(out)))
        return out

    def _query(self, query, *, season=0, movie=True):
        media_type = "tvseries" if season else ("movies" if movie else "tvseries")

        # KKiste's current public flow loads the JSON catalogue once and does
        # the title search client-side.  Cache it for this provider instance so
        # aliases do not repeat a large request.
        if self.catalog_path:
            if self._catalog_failed:
                return None
            if self._catalog_items is None:
                payload = self.client.get_json(self.catalog_path, max_bytes=self.catalog_max_bytes)
                if payload is None:
                    self._catalog_failed = True
                    self._search_failed = True
                    diag(self.provider_name, "search-abort", "catalog request failed")
                    return None
                self._catalog_items = self._items_from_payload(payload)
                diag(self.provider_name, "search-catalog", "items=%d" % len(self._catalog_items))
            items = self._catalog_candidates(query)
            return self._filter_media(items, season=season, movie=movie)

        # For endpoint-backed search, use the provider's current URL shape when
        # supplied.  A transport failure aborts further aliases; otherwise one
        # dead request could consume the whole global provider budget.
        for param in self.search_params:
            if self.search_path_template:
                path = self.search_path_template.format(
                    query=quote(str(query or "")), param=param, media_type=media_type,
                )
            else:
                path = "/data/browse/?lang=2&type=%s&order_by=new&page=1&%s=%s" % (
                    media_type, param, quote(str(query or "")),
                )
            payload = self.client.get_json(path)
            if payload is None:
                self._query_transport_failures += 1
                limit = max(1, int(self.max_query_transport_failures or 1))
                if self._query_transport_failures >= limit:
                    self._search_failed = True
                    diag(self.provider_name, "search-abort", "query transport failures=%d" % self._query_transport_failures)
                    return None
                diag(self.provider_name, "search-retry", "query transport failures=%d" % self._query_transport_failures)
                return []
            self._query_transport_failures = 0
            results = self._filter_media(self._items_from_payload(payload), season=season, movie=movie)
            if results:
                return results
        return []

    def _year_catalog(self, wanted_year, *, season=0, movie=True):
        """Fetch KKiste's bounded server-side year slice.

        A *valid* response for the exact requested year is authoritative: if
        the wanted title is absent from that slice, Kadr+ returns no result
        instead of downloading and indexing the ~40k full catalogue.  The full
        catalogue is kept only as a resilience fallback when the year slice
        cannot be trusted technically (request failure / malformed payload) or
        when Kadr does not know a year at all.
        """
        if not self.catalog_year_path_template or not wanted_year:
            return None
        media_type = "tvseries" if season else ("movies" if movie else "tvseries")
        cache_key = (media_type, str(wanted_year))
        if cache_key in self._year_catalog_cache:
            return self._year_catalog_cache[cache_key]
        path = self.catalog_year_path_template.format(
            media_type=media_type, year=quote(str(wanted_year)),
        )
        started = time.perf_counter()
        payload = self.client.get_json(path, max_bytes=min(self.catalog_max_bytes, 8 * 1024 * 1024))
        if payload is None:
            self._year_catalog_cache[cache_key] = None
            diag(self.provider_name, "search-year-catalog", "year=%s request-failed; fallback=full" % wanted_year)
            return None
        # Distinguish a valid empty year result from a broken/changed API
        # response.  Only the latter may fall back to the full catalogue.
        if not isinstance(payload, dict) or not isinstance(payload.get("movies"), list):
            self._year_catalog_cache[cache_key] = None
            diag(self.provider_name, "search-year-catalog", "year=%s malformed-payload; fallback=full" % wanted_year)
            return None
        items = self._filter_media(self._items_from_payload(payload), season=season, movie=movie)
        self._year_catalog_cache[cache_key] = items
        diag(
            self.provider_name, "search-year-catalog",
            "year=%s items=%d elapsed_ms=%d authoritative=1" % (
                wanted_year, len(items), int((time.perf_counter() - started) * 1000),
            ),
        )
        return items

    def _strict_best(self, items, wanted_titles, wanted_year, *, season=0):
        if season:
            best = choose_series_candidate(items, wanted_titles, wanted_year, min_score=0.93, season=season)
        else:
            best = choose_candidate(items, wanted_titles, wanted_year, min_score=0.93, season=season)
        if best and season and self._candidate_season(best) not in (0, int(season)):
            return None
        return best

    def _lookup(self, wanted_titles, year="", *, season=0, movie=True):
        wanted_year = year_of(year)

        # KKiste exposes a real server-side year filter.  When the exact year is
        # known and the endpoint returns a structurally valid response, that
        # slice is authoritative: title present -> verify and use it; title
        # absent -> empty.  Do not waste tens of seconds downloading/indexing
        # unrelated years.
        use_year_slice = bool(self.catalog_year_path_template and wanted_year)
        if use_year_slice:
            scoped_items = self._year_catalog(wanted_year, season=season, movie=movie)
            if scoped_items is not None:
                for query in wanted_titles[:4]:
                    qnorm = normalize_title(query)
                    if not qnorm:
                        continue
                    # The year slice is small, so a direct exact-normalized scan
                    # is cheaper than constructing the full catalogue index.
                    candidates = []
                    qcompact = qnorm.replace(" ", "")
                    for item in scoped_items:
                        key = item.get("_kadr_norm_title")
                        if key is None:
                            key = normalize_title(self._candidate_title(item))
                            item["_kadr_norm_title"] = key
                        if key == qnorm:
                            candidates.append(item)
                            continue
                        if qcompact and (len(qnorm.split()) == 1 or any(len(token) == 1 for token in qnorm.split())):
                            if key.replace(" ", "") == qcompact:
                                candidates.append(item)
                    if not candidates:
                        continue
                    best = self._strict_best(candidates, wanted_titles, wanted_year, season=season)
                    if best:
                        diag(self.provider_name, "match", "title/year/season verified via authoritative year slice")
                        return best
                diag(self.provider_name, "search-year-miss", "year=%s authoritative=1; fallback=none" % wanted_year)
                return None

        # Resilience fallback only: no usable year is known, or the year-slice
        # request failed / returned a malformed structure.  In those cases the
        # old full catalogue is still safer than silently losing a valid source.
        for query in wanted_titles[:4]:
            items = self._query(query, season=season, movie=movie)
            if items is None:
                return None
            best = self._strict_best(items, wanted_titles, wanted_year, season=season)
            if best:
                diag(self.provider_name, "match", "title/year/season verified")
                return best
        return None

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        wanted = titles_from(localtitle, title, aliases, ffitem=getattr(self, "ffitem", None), media_type="movie")
        if not wanted:
            return None
        item = self._lookup(wanted, year, movie=True)
        if self._search_failed:
            return None
        if not item:
            fallback = german_fallback_titles(wanted, getattr(self, "ffitem", None), "movie")
            if fallback != wanted:
                item = self._lookup(fallback, year, movie=True)
        if not item:
            return None
        return encode_ref(self.ref_prefix, {
            "kind": "movie", "id": item["_id"], "title": item.get("title", ""),
            "year": year_of(item.get("year") or year),
        })

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        wanted = titles_from(localtvshowtitle, tvshowtitle, aliases, ffitem=getattr(self, "ffitem", None), media_type="show")
        if not wanted:
            return None
        # Resolve the concrete season only in episode(), where Kadr supplies it.
        return encode_ref(self.ref_prefix, {
            "kind": "show", "titles": wanted, "year": year_of(year),
        })

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        ref = decode_ref(self.ref_prefix, url)
        if not ref or ref.get("kind") != "show":
            return None
        try:
            season_i, episode_i = int(season), int(episode)
        except Exception:
            return None
        if season_i <= 0 or episode_i <= 0:
            return None
        wanted = [clean_text(x) for x in ref.get("titles", []) if clean_text(x)]
        item = self._lookup(wanted, ref.get("year", ""), season=season_i, movie=False)
        if self._search_failed:
            return None
        if not item:
            fallback = german_fallback_titles(wanted, getattr(self, "ffitem", None), "show")
            if fallback != wanted:
                item = self._lookup(fallback, ref.get("year", ""), season=season_i, movie=False)
        if not item:
            return None
        return encode_ref(self.ref_prefix, {
            "kind": "episode", "id": item["_id"], "season": season_i,
            "episode": episode_i, "title": item.get("title", ""),
        })

    @staticmethod
    def _quality_rank(value):
        return {
            "4K": 60, "1440p": 50, "1080p": 40, "720p": 30,
            "HD": 25, "480p": 20, "SD": 15, "CAM": 10,
        }.get(str(value or ""), 0)

    @staticmethod
    def _stream_quality(item):
        """Return the provider-facing normalized quality bucket.

        KKiste/Movie2k expose release labels rather than a guaranteed numeric
        resolution.  Keep Kadr+'s established normalization, but preserve an
        explicit SD marker so SD and generic HD rows are not collapsed into
        the same host/quality bucket.
        """
        raw = clean_text((item or {}).get("release") or (item or {}).get("quality") or "")
        if re.search(r"\bSD\b", raw, re.I):
            return "SD"
        return quality_from(raw)

    @staticmethod
    def _freshness_key(item, position=0):
        """Comparable freshness key for a watch-stream row.

        The current KKiste/Movie2k watch schema exposes ``added`` on stream
        rows and current clients sort it descending.  Prefer that explicit
        field.  Numeric values are compared numerically; textual values keep
        the descending lexicographic ordering used by current clients of this
        API.  If ``added`` is absent, retain API order deterministically
        instead of inventing freshness from URL/quality.
        """
        value = (item or {}).get("added")
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return (2, float(value), -int(position))
        text = clean_text(value)
        if text:
            try:
                return (2, float(text), -int(position))
            except Exception:
                return (1, text, -int(position))
        return (0, 0, -int(position))

    def _watch(self, ref):
        payload = self.client.get_json("/data/watch/?_id=" + quote(str(ref.get("id") or "")))
        if not isinstance(payload, dict):
            return []
        raw_streams = payload.get("streams")
        if not isinstance(raw_streams, list):
            return []
        kind = ref.get("kind")
        episode = int(ref.get("episode") or 0)
        eligible = 0
        with_added = 0
        best_by_host_quality = {}
        for position, item in enumerate(raw_streams):
            if not isinstance(item, dict) or item.get("deleted"):
                continue
            has_ep = item.get("e") not in (None, "")
            if kind == "episode":
                try:
                    if not has_ep or int(item.get("e")) != episode:
                        continue
                except Exception:
                    continue
            elif has_ep:
                continue
            raw_url = str(item.get("stream") or item.get("url") or "").strip()
            if raw_url.startswith("//"):
                raw_url = "https:" + raw_url
            parts = urlsplit(raw_url)
            if parts.scheme not in ("http", "https") or not parts.hostname:
                continue
            eligible += 1
            if clean_text(item.get("added")):
                with_added += 1
            quality = self._stream_quality(item)
            candidate = {
                "url": raw_url,
                "name": host_label(raw_url, self.provider_name),
                "quality": quality,
                "info": clean_text(item.get("release") or ""),
                "language": "de",
                "_freshness": self._freshness_key(item, position),
            }
            # The watch endpoint can expose many historical mirrors for one
            # hoster.  Keep exactly one newest row for every normalized
            # quality of every exact hostname, using the API's explicit
            # ``added`` field as freshness.  When ``added`` is absent for a
            # legacy row, stable API order is the conservative fallback.
            key = (parts.hostname.lower().rstrip("."), quality)
            previous = best_by_host_quality.get(key)
            if previous is None or candidate["_freshness"] > previous["_freshness"]:
                best_by_host_quality[key] = candidate
        out = list(best_by_host_quality.values())
        for row in out:
            row.pop("_freshness", None)
        out.sort(key=lambda row: (-self._quality_rank(row.get("quality")), row.get("name", "").lower(), row.get("url", "")))
        diag(
            self.provider_name, "watch",
            "raw=%d eligible=%d with_added=%d unique_host_quality=%d"
            % (len(raw_streams), eligible, with_added, len(out)),
        )
        return out

    def sources(self, url, hostDict, hostprDict, **kwargs):
        ref = decode_ref(self.ref_prefix, url)
        if not ref or ref.get("kind") not in ("movie", "episode") or not ref.get("id"):
            return []
        rows = []
        for item in self._watch(ref):
            row = source_row(
                item.get("url"), hostDict, hostprDict,
                name=item.get("name", ""), quality=item.get("quality", "HD"),
                language=item.get("language", "de"), info=item.get("info", ""),
            )
            if row:
                rows.append(row)
        return dedup_source_rows(rows)

    def resolve(self, url):
        return url
