# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""KinoFun (kinoger.fun) provider written for Kadr+ 2.0."""

from lib.sources.de._kadr_dle_matrix import DLEMatrixSource


class source(DLEMatrixSource):
    provider_name = "kinofun"
    base_urls = ("https://kinoger.fun", "https://www.kinoger.fun")
    ref_prefix = "kadr-kinofun:"
    # Live Sep-2026 site uses the plain DLE GET first.  Keep the older
    # titleonly=3 variants as bounded compatibility fallbacks, then the shared
    # POST fallback.  This mirrors behaviour, not external implementation code.
    get_search_templates = (
        "/?do=search&subaction=search&story={q}",
        "/?do=search&subaction=search&titleonly=3&story={q}&x=0&y=0&submit=submit",
        "?do=search&subaction=search&titleonly=3&story={q}&x=0&y=0&submit=submit",
    )
    post_search = True
