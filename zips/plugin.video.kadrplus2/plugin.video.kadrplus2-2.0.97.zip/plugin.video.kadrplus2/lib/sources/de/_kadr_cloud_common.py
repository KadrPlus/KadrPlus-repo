# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""Kadr+-local helpers for German pages using external hoster/player iframes."""

from __future__ import annotations

import re
from urllib.parse import urlsplit

from lib.sources.de._kadr_de_common import (
    register,
    TrustedHttpsClient, absolute_http, clean_text, extract_data_links,
    extract_iframes, host_label, html_attr, meinecloud_episode_links,
    quality_from, strip_comments,
)


_MINE_HOST = "meinecloud.click"


def _is_same_host(url, base):
    return (urlsplit(url).hostname or "").lower() == (urlsplit(base).hostname or "").lower()


def _external_items_from_html(html, base, *, block_only=False):
    out = []
    for item in extract_data_links(html, base=base):
        p = urlsplit(item.get("url") or "")
        if not p.hostname:
            continue
        host = p.hostname.lower()
        if host == (urlsplit(base).hostname or "").lower():
            # Internal /vod or redirect placeholders are not a source.
            continue
        if "youtube" in host or host == "youtu.be":
            continue
        out.append(item)
    return out


def _episode_block(html, season, episode):
    patterns = (
        r'<li\b[^>]*id\s*=\s*["\']serie-%d_%d["\'][^>]*>(.*?)(?=<li\b[^>]*id\s*=\s*["\']serie-\d+_\d+["\']|$)' % (season, episode),
        r'id\s*=\s*["\']serie-%d_%d["\'](.*?)(?=id\s*=\s*["\']serie-\d+_\d+["\']|$)' % (season, episode),
    )
    for pattern in patterns:
        m = re.search(pattern, str(html or ""), re.I | re.S)
        if m:
            return m.group(1)
    # Some FHD pages group episode rows inside a season accordion as xN Episode.
    sm = re.search(r'#se-ac-%d(.*?)(?=#se-ac-\d|$)' % season, str(html or ""), re.I | re.S)
    if sm:
        em = re.search(r'\bx0*%d\s*Episode\b(.*?)(?=<br|\bx\d+\s*Episode|$)' % episode, sm.group(1), re.I | re.S)
        if em:
            return em.group(1)
    return ""


def _parse_mine_html(html, *, season=0, episode=0):
    if season and episode:
        return meinecloud_episode_links(html, season, episode)
    return _external_items_from_html(html, "https://meinecloud.click/")


def collect_page_streams(site_client, page_url, *, season=0, episode=0, max_internal=3):
    """Extract hoster URLs without fetching arbitrary third-party hosts.

    Movies may use page-wide provider-declared hosters.  Episodes are stricter:
    a third-party hoster is accepted only from the exact requested S/E block,
    or from an exact S/E row inside the trusted MeineCloud player.  If the page
    cannot prove the requested episode, returning no source is safer than
    playing a neighbouring episode.
    """
    html = site_client.get_text(page_url)
    if not html:
        return []
    base = site_client.base
    mine = TrustedHttpsClient(site_client.provider, (_MINE_HOST,))
    out, seen = [], set()

    def add(item):
        url = str((item or {}).get("url") or "").strip()
        if not url or url in seen:
            return
        seen.add(url)
        out.append(item)

    def consume_movie(fragment, referer, depth=0):
        target = str(fragment or "")
        for item in _external_items_from_html(target, base):
            p = urlsplit(item.get("url") or "")
            if (p.hostname or "").lower() == _MINE_HOST:
                mine_html = mine.get_text(item["url"], referer=referer)
                for nested in _parse_mine_html(mine_html):
                    add(nested)
            elif site_client.allowed_url(item.get("url")) and depth < max_internal:
                internal = site_client.get_text(item["url"], referer=referer)
                if internal:
                    consume_movie(internal, item["url"], depth + 1)
            else:
                add(item)
        for iframe in extract_iframes(target, base)[:8]:
            p = urlsplit(iframe)
            host = (p.hostname or "").lower()
            if not host or "youtube" in host or host == "youtu.be":
                continue
            if host == _MINE_HOST:
                mine_html = mine.get_text(iframe, referer=referer)
                for nested in _parse_mine_html(mine_html):
                    add(nested)
            elif site_client.allowed_url(iframe) and depth < max_internal:
                internal = site_client.get_text(iframe, referer=referer)
                if internal:
                    consume_movie(internal, iframe, depth + 1)
            else:
                add({"url": iframe, "name": host_label(iframe), "quality": quality_from(target), "info": ""})

    def consume_episode(fragment, referer, depth=0):
        fragment = str(fragment or "")
        block = _episode_block(fragment, int(season), int(episode))
        if block:
            # Only this exact S/E block may directly yield external hosters.
            for item in _external_items_from_html(block, base):
                p = urlsplit(item.get("url") or "")
                host = (p.hostname or "").lower()
                if host == _MINE_HOST:
                    mine_html = mine.get_text(item["url"], referer=referer)
                    for nested in _parse_mine_html(mine_html, season=season, episode=episode):
                        add(nested)
                elif site_client.allowed_url(item.get("url")) and depth < max_internal:
                    internal = site_client.get_text(item["url"], referer=referer)
                    if internal:
                        consume_episode(internal, item["url"], depth + 1)
                else:
                    add(item)
            for iframe in extract_iframes(block, base)[:8]:
                p = urlsplit(iframe)
                host = (p.hostname or "").lower()
                if not host or "youtube" in host or host == "youtu.be":
                    continue
                if host == _MINE_HOST:
                    mine_html = mine.get_text(iframe, referer=referer)
                    for nested in _parse_mine_html(mine_html, season=season, episode=episode):
                        add(nested)
                elif site_client.allowed_url(iframe) and depth < max_internal:
                    internal = site_client.get_text(iframe, referer=referer)
                    if internal:
                        consume_episode(internal, iframe, depth + 1)
                else:
                    add({"url": iframe, "name": host_label(iframe), "quality": quality_from(block), "info": ""})
            if out:
                return

        # No proven exact block: page-wide external data-link/iframe rows are
        # deliberately ignored.  A provider-declared MeineCloud serial player
        # is the only external fallback because we can re-validate exact S/E in
        # its structured episode rows.
        for raw in re.findall(r'(?:(?:src|href|data-link)\s*=\s*["\'])([^"\']*meinecloud\.click/[^"\']+)', fragment, re.I):
            mine_url = absolute_http(raw, "https://meinecloud.click/")
            if not mine.allowed_url(mine_url):
                continue
            mine_html = mine.get_text(mine_url, referer=referer)
            for nested in _parse_mine_html(mine_html, season=season, episode=episode):
                add(nested)
            if out:
                return

        # Same-provider internal wrappers may lead to a page that has an exact
        # S/E block.  Following those remains bounded and allowlisted.
        if depth < max_internal:
            for iframe in extract_iframes(fragment, base)[:8]:
                if not site_client.allowed_url(iframe):
                    continue
                internal = site_client.get_text(iframe, referer=referer)
                if internal:
                    consume_episode(internal, iframe, depth + 1)
                if out:
                    return

    cleaned = strip_comments(html)
    if season and episode:
        consume_episode(cleaned, page_url)
    else:
        consume_movie(cleaned, page_url)
    return out

