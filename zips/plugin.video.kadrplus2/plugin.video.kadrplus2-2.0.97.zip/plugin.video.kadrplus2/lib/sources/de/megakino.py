# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""
    Scraper dla MegaKino
    
    Cloudflare blokuje GET /films/ i /serials/ dla requests.
    Obejście: POST /engine/ajax/controller.php z mod=showfull&id=NEWS_ID
    lub POST /index.php?do=cat z newsid — DLE wewnętrzne endpointy
    które nie przechodzą przez CF routing.
    
    ID tytułu pobieramy z wyników wyszukiwania POST /index.php (działa).
"""
import re
import time
from html import unescape
from urllib.parse import urlencode, quote_plus, unquote_plus, urljoin, urlsplit

from lib.ff import control, source_utils, cleantitle, title_matcher
from lib.ff.log_utils import fflog, fflog_exc
from lib.sources.de._kadr_de_common import titles_from as _de_titles_from


def _diag(stage, message=''):
    """Privacy-safe MegaKino trace, only when Kadr+ diagnostics is enabled."""
    try:
        from lib.ff import diagnostics
        if not diagnostics.enabled():
            return
        diagnostics.log_event('megakino-search', f'stage={stage}; {message}'.rstrip('; '))
    except Exception:
        pass


_OFFICIAL_BASE = 'https://megakino19.com'
_DEFAULT_MIRRORS = (
    'https://megakino18.com',
)
_PREVIOUS_DEFAULT_MIRRORS = {
    'https://megakino18.com',
    'https://megakino17.com',
    'https://megakino16.com',
    'https://megakino15.com',
}
# Exact defaults shipped by older Kadr+ builds.  Only these are migrated; a
# genuinely custom address entered by the user is never overwritten.
_LEGACY_PRIMARY_DEFAULTS = {
    'https://megakino10.com',
}
_LEGACY_MIRROR_DEFAULTS = {
    'https://megakino9.com',
    'https://megakino8.com',
    'https://megakino5.org',
    'https://megakino4.to',
}
_REMOTE_DOMAIN_URL = 'https://raw.githubusercontent.com/mr-evil1/megakino/main/megakino-url.json'
_REMOTE_DOMAIN_TTL = 6 * 3600
_REMOTE_DOMAIN_FAILURE_TTL = 5 * 60
# MegaKino has historically rotated between a small set of numbered hostnames.
# A remotely suggested domain is accepted only when it is HTTPS and matches this
# narrow family; arbitrary hosts from the JSON can never become an origin.
_MEGAKINO_ROTATING_HOST_RE = re.compile(
    r'^megakino\d+\.(?:com|to|ws|org|co|live|video)$', re.I
)
_LAST_WORKING_BASE = ''
_REMOTE_DOMAIN_CACHE = ''
_REMOTE_DOMAIN_CACHE_TS = 0.0


class source:
    has_sort_order = True
    priority = 2
    language = ['de']

    def __init__(self):
        self.priority  = 1
        self.language  = ['de']
        configured_base = self._normalize_base(control.setting('megakino.base'))
        # Kadr+ 2.0.93 hotfix: MegaKino rotates numbered .com domains roughly
        # weekly.  Migrate only the old Kadr+ default, not arbitrary user URLs.
        if configured_base in _LEGACY_PRIMARY_DEFAULTS:
            configured_base = _OFFICIAL_BASE
            try:
                control.setSetting('megakino.base', _OFFICIAL_BASE)
            except Exception:
                pass
        self._primary_base = configured_base or _OFFICIAL_BASE
        self._auto_mirrors = self._setting_bool(control.setting('megakino.auto_mirrors'), default=True)
        mirror_setting = control.setting('megakino.mirrors')
        configured_mirrors = {
            self._normalize_base(value)
            for value in re.split(r'[\s,;]+', str(mirror_setting or ''))
            if self._normalize_base(value)
        }
        if (
            not str(mirror_setting or '').strip()
            or configured_mirrors == _LEGACY_MIRROR_DEFAULTS
            or configured_mirrors == _PREVIOUS_DEFAULT_MIRRORS
        ):
            mirror_setting = ','.join(_DEFAULT_MIRRORS)
            if configured_mirrors in (_LEGACY_MIRROR_DEFAULTS, _PREVIOUS_DEFAULT_MIRRORS):
                try:
                    control.setSetting('megakino.mirrors', mirror_setting)
                except Exception:
                    pass
        self._mirror_bases = []
        for value in re.split(r'[\s,;]+', str(mirror_setting or '')):
            base = self._normalize_base(value)
            if base and base not in self._mirror_bases:
                self._mirror_bases.append(base)
        self.base_link = self._primary_base
        # Be conservative with redirects and absolute links returned by search:
        # only the configured domain and the explicitly verified MegaKino family
        # may become a new active origin.
        allowed_bases = [self._primary_base, *self._mirror_bases, *_DEFAULT_MIRRORS, _OFFICIAL_BASE]
        self._allowed_hosts = {
            self._host_key(urlsplit(base).hostname) for base in allowed_bases if base
        }
        self._allowed_hosts.discard('')
        self.headers   = {
            'User-Agent':    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0',
            'Accept':        'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'de-DE,de;q=0.9,en;q=0.3',
        }
        self.session   = None
        self._cache    = {}
        self._domain_transport_failed = False
        self._yg_token_primed = False

    # ------------------------------------------------------------------

    @staticmethod
    def _setting_bool(value, default=False):
        if value is None or value == '':
            return bool(default)
        return str(value).strip().lower() in ('true', '1', 'yes', 'on')

    @staticmethod
    def _host_key(host):
        host = str(host or '').strip().lower().rstrip('.')
        return host[4:] if host.startswith('www.') else host

    @staticmethod
    def _normalize_base(value):
        value = str(value or '').strip().rstrip('/')
        if not value:
            return ''
        if '://' not in value:
            value = 'https://' + value
        try:
            parsed = urlsplit(value)
            if parsed.scheme.lower() not in ('http', 'https') or not parsed.hostname:
                return ''
            if parsed.username or parsed.password:
                return ''
            host = parsed.hostname.lower().rstrip('.')
            port = (':%s' % parsed.port) if parsed.port else ''
            return '%s://%s%s' % (parsed.scheme.lower(), host, port)
        except Exception:
            return ''

    def _base_from_url(self, url):
        try:
            parsed = urlsplit(str(url or '').replace('\\/', '/'))
            if parsed.scheme.lower() not in ('http', 'https') or not parsed.hostname:
                return ''
            if parsed.username or parsed.password:
                return ''
            host = self._host_key(parsed.hostname)
            # The official site rotates through a narrowly-defined MegaKino
            # hostname family. Accept only that family (or explicitly configured
            # hosts), so redirects cannot move the provider to an unrelated site.
            if host not in self._allowed_hosts and not _MEGAKINO_ROTATING_HOST_RE.fullmatch(host):
                return ''
            if _MEGAKINO_ROTATING_HOST_RE.fullmatch(host):
                self._allowed_hosts.add(host)
            port = (':%s' % parsed.port) if parsed.port else ''
            return '%s://%s%s' % (parsed.scheme.lower(), parsed.hostname.lower(), port)
        except Exception:
            return ''

    def _switch_base(self, base):
        base = self._normalize_base(base)
        if not base or base == self.base_link:
            return self.base_link
        old_session = self.session
        self.base_link = base
        self.session = None
        self._yg_token_primed = False
        if old_session:
            try:
                old_session.close()
            except Exception:
                pass
        return self.base_link

    def _adopt_response_base(self, url):
        """Adopt a verified redirect target without discarding its live session."""
        base = self._base_from_url(url)
        if base and base != self.base_link:
            fflog(f'[megakino] verified redirect: {self.base_link} -> {base}', 1)
            self.base_link = base
        return self.base_link

    def _sync_base_from_url(self, url):
        base = self._base_from_url(str(url or '').split('|KADR|', 1)[0])
        if base:
            self._switch_base(base)
            return True
        return False

    def _candidate_bases(self):
        values = [self._primary_base]
        if self._auto_mirrors:
            if _LAST_WORKING_BASE:
                values.append(_LAST_WORKING_BASE)
            values.extend(self._mirror_bases)
        result = []
        for value in values:
            base = self._normalize_base(value)
            if not base or base in result:
                continue
            if self._host_key(urlsplit(base).hostname) not in self._allowed_hosts:
                continue
            result.append(base)
        return result or [self._primary_base]

    def _remote_domain_base(self):
        """Last-resort current-domain hint from the standalone MegaKino add-on.

        This is deliberately *not* a primary discovery mechanism. Kadr+ first
        tries its configured/known domains. The remote hint is fetched only if
        every known origin failed at the transport layer. The response is never
        trusted blindly: TLS verification stays enabled and only a strict
        ``megakinoNN.<known-tld>`` HTTPS hostname is accepted.
        """
        global _REMOTE_DOMAIN_CACHE, _REMOTE_DOMAIN_CACHE_TS
        now = time.time()
        ttl = _REMOTE_DOMAIN_TTL if _REMOTE_DOMAIN_CACHE else _REMOTE_DOMAIN_FAILURE_TTL
        if _REMOTE_DOMAIN_CACHE_TS and (now - _REMOTE_DOMAIN_CACHE_TS) < ttl:
            if _REMOTE_DOMAIN_CACHE:
                self._allowed_hosts.add(self._host_key(urlsplit(_REMOTE_DOMAIN_CACHE).hostname))
            return _REMOTE_DOMAIN_CACHE

        base = ''
        try:
            # Use the normal requests package here instead of the MegaKino
            # session: that session intentionally carries site-specific cookie
            # behaviour and currently disables certificate verification. The
            # GitHub control-plane request must keep normal TLS verification.
            import requests as _safe_requests
            response = _safe_requests.get(
                _REMOTE_DOMAIN_URL,
                headers={
                    'User-Agent': self.headers.get('User-Agent', 'Mozilla/5.0'),
                    'Accept': 'application/json',
                },
                timeout=(2, 4),
            )
            if response.status_code == 200:
                data = response.json() or {}
                value = str(data.get('url') or '').strip()
                if value and '://' not in value:
                    value = 'https://' + value
                parsed = urlsplit(value)
                host = self._host_key(parsed.hostname)
                safe_shape = (
                    parsed.scheme.lower() == 'https'
                    and bool(host)
                    and not parsed.username
                    and not parsed.password
                    and parsed.port in (None, 443)
                    and parsed.path in ('', '/')
                    and not parsed.query
                    and not parsed.fragment
                )
                if safe_shape and _MEGAKINO_ROTATING_HOST_RE.fullmatch(host):
                    base = 'https://' + parsed.hostname.lower().rstrip('.')
                    self._allowed_hosts.add(host)
                    _diag('remote-domain', f'result=accepted; host={host}')
                else:
                    _diag('remote-domain', 'result=rejected')
            else:
                _diag('remote-domain', f'result=http-error; status={response.status_code}')
        except Exception:
            _diag('remote-domain', 'result=transport-error')

        _REMOTE_DOMAIN_CACHE = base
        _REMOTE_DOMAIN_CACHE_TS = now
        return base

    def _activate_base(self, base):
        self._switch_base(base)
        self._domain_transport_failed = False
        self._init_session()
        return self.base_link

    def _remember_working_base(self, url=''):
        global _LAST_WORKING_BASE
        if url:
            self._sync_base_from_url(url)
        if self._host_key(urlsplit(self.base_link).hostname) in self._allowed_hosts:
            _LAST_WORKING_BASE = self.base_link

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        fflog(f'[megakino] film: {title=}  {year=}  {imdb=}', 1)
        year_alt = kwargs.get('year_alt')
        if year_alt: year = (year, year_alt)
        url = self._search(title, localtitle, aliases, year, 'film')
        fflog(f'[megakino] film url: {url}', 1)
        return url

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        fflog(f'[megakino] serial: {tvshowtitle=}  {year=}', 1)
        year_alt = kwargs.get('year_alt')
        if year_alt: year = (year, year_alt)
        url = self._search(tvshowtitle, localtvshowtitle, aliases, year, 'serial')
        if url:
            # Kadr+ 2.40.48: Megakino ma często osobne strony dla sezonów
            # (np. Cobra Kai - Staffel 2), więc przechowujemy dane serialu,
            # żeby episode() mogło znaleźć właściwą stronę sezonu.
            meta = []
            de_titles = _de_titles_from(localtvshowtitle, tvshowtitle, aliases, limit=10, ffitem=getattr(self, "ffitem", None), media_type="show")
            if de_titles:
                # Keep the strongest German title and also the original title
                # (the helper keeps original last) for later season lookups.
                meta.append('show=' + quote_plus(str(de_titles[0])))
                second = de_titles[-1] if len(de_titles) > 1 else ''
                if second and second != de_titles[0]:
                    meta.append('local=' + quote_plus(str(second)))
            if year: meta.append('year=' + quote_plus(str(year)))
            if meta:
                url = url + '|KADR|' + '|'.join(meta)
        fflog(f'[megakino] serial url: {url}', 1)
        return url

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        fflog(f'[megakino] episode {url=}  {season=}  {episode=}', 1)
        if not url: return None
        base_url, meta = self._split_meta(url)
        try:
            # episode() can run in a fresh provider instance. Restore the exact
            # verified mirror embedded in the URL before making season requests.
            self._sync_base_from_url(base_url)
            self._init_session()
            # Megakino publikuje wiele seriali jako oddzielne wpisy sezonów.
            # Dla S02E02 szukamy więc najpierw strony typu "Cobra Kai Staffel 2",
            # zamiast używać ogólnego wpisu serialu, gdzie ep2 może oznaczać zły sezon.
            show = meta.get('show') or meta.get('local') or ''
            local = meta.get('local') or show
            year = meta.get('year') or None
            season_url = self._search_season_page(show, local, year, int(season), base_url)
            if season_url:
                base_url = season_url
        except Exception:
            fflog_exc()
        return f'{base_url}#S{season}E{episode}'

    def sources(self, url, hostDict, hostprDict):
        result = []
        fflog(f'[megakino] sources {url=}', 1)
        if not url: return result
        try:
            season = episode = None
            url, _meta = self._split_meta(url)
            self._sync_base_from_url(url)
            self._init_session()
            m = re.search(r'#S(\d+)E(\d+)$', url)
            if m:
                season  = int(m.group(1))
                episode = int(m.group(2))
                url     = url[:m.start()]

            # ID z URL: Megakino używa różnych kategorii:
            # /serials/92-cobra-kai.html, ale sezony są często pod /drama/4005-cobra-kai-staffel-1.html
            # albo /action/4373-cobra-kai-staffel-6.html. Dlatego nie ograniczamy się do films/serials.
            id_m = re.search(r'/(?:[a-z0-9_-]+)/(\d+)-', url, re.I)
            if not id_m:
                fflog(f'[megakino] nie mozna wyciagnac ID z {url}', 1)
                return result
            news_id = id_m.group(1)
            fflog(f'[megakino] news_id={news_id}  season={season}  episode={episode}', 1)

            html = self._fetch_by_id(news_id, url)
            if not html:
                return result

            fflog(f'[megakino] html len={len(html)}', 1)
            links = self._extract_links(html, season, episode, news_id=news_id, referer=url)
            fflog(f'[megakino] linków: {len(links)}', 1)

            for item in links:
                link = item.get('url', '')
                if not link: continue
                valid, hoster = source_utils.is_host_valid(link, hostDict)
                if not valid:
                    valid, hoster = source_utils.is_host_valid(link, hostprDict)
                if not valid:
                    from urllib.parse import urlsplit
                    hoster = urlsplit(link).hostname or link
                result.append({
                    'source': hoster, 'quality': item.get('quality', 'HD'),
                    'language': 'de', 'url': link,
                    'info': item.get('info', ''), 'direct': False, 'debridonly': False,
                })
        except Exception:
            fflog_exc()
        fflog(f'[megakino] zwracam {len(result)} zrodel', 1)
        return result

    def resolve(self, url):
        return url

    # ------------------------------------------------------------------

    def _is_valid_detail_html(self, html, news_id=None, original_url=None):
        # Kadr+ 2.40.55: walidacja strony szczegółów MegaKino.
        try:
            if not html or len(html) < 500:
                return False
            low = html.lower()
            if any(x in low[:5000] for x in ('seite nicht gefunden', 'not found')):
                return False
            if news_id and (str(news_id) in low or ('newsid=%s' % news_id) in low):
                return True
            if original_url:
                m = re.search(r'/(\d+)-([^/]+?)\.html', original_url, re.I)
                if m:
                    slug = m.group(2).replace('-', ' ').lower()
                    words = [w for w in re.split(r'\W+', slug) if len(w) > 2]
                    if words and sum(1 for w in words[:6] if w in low) >= max(1, min(3, len(words))):
                        return True
            if self._has_content(html):
                return True
            if re.search(r'<h[12][^>]*>\s*[^<]{2,160}', html, re.I):
                return True
        except Exception:
            pass
        return False

    def _normalize_hoster_url(self, url):
        try:
            url = (url or '').strip()
            if not url:
                return ''
            url = url.replace('\\/', '/')
            if url.startswith('//'):
                url = 'https:' + url
            if url.startswith('/'):
                return ''
            if not url.startswith('http'):
                return ''
            bad_hosts = ('megakino', 'youtube.com', 'youtu.be', 'schema.org', 'example.', 'cvt-', 'google', 'facebook', 'twitter')
            if any(x in url.lower() for x in bad_hosts):
                return ''
            return url
        except Exception:
            return ''


    def _strip_html(self, text):
        try:
            text = re.sub(r'<[^>]+>', ' ', text or '')
            text = unescape(text)
            text = re.sub(r'\s+', ' ', text).strip()
            return text
        except Exception:
            return text or ''

    def _resolve_internal_value(self, value, referer=None):
        """
        Megakino sometimes stores hoster options as an internal AJAX/relative URL.
        Resolve it once and extract external hoster links from the returned HTML/JSON.
        """
        links = []
        seen = set()
        try:
            value = (value or '').strip().replace('\\/', '/')
            if not value:
                return links
            if value.startswith('//'):
                value = 'https:' + value
            if value.startswith('/'):
                value = self.base_link + value
            if not value.startswith('http'):
                # Some DLE snippets store path without leading slash.
                if value.startswith('engine/') or value.startswith('index.php'):
                    value = self.base_link + '/' + value
                else:
                    return links
            if 'megakino' not in value:
                self._add_hoster_link(links, seen, value)
                return links
            headers = dict(self.headers)
            headers['Referer'] = referer or self.base_link + '/'
            headers['X-Requested-With'] = 'XMLHttpRequest'
            r = self.session.get(value, headers=headers, timeout=(8, 12), allow_redirects=True)
            txt = r.text or ''
            fflog(f'[megakino] internal hoster GET status={r.status_code} len={len(txt)} url={value[:80]}', 1)
            # JSON / HTML / JS values
            for m in re.finditer(r"https?:\\?/\\?/[^'\"<>\\s]+", txt, re.I):
                self._add_hoster_link(links, seen, m.group(0))
            for m in re.finditer(r"(?:url|link|file|src|iframe)\s*[:=]\s*['\"]([^'\"]+)['\"]", txt, re.I):
                self._add_hoster_link(links, seen, m.group(1))
            for m in re.finditer(r"(?:data-url|data-link|data-src|href|src)=['\"]([^'\"]+)['\"]", txt, re.I):
                self._add_hoster_link(links, seen, m.group(1))
        except Exception:
            fflog_exc()
        return links

    def _add_hoster_link(self, links, seen, url, label='Hoster'):
        url = self._normalize_hoster_url(url)
        if not url or url in seen:
            return
        seen.add(url)
        try:
            host_m = re.search(r'https?://(?:www\.)?([^/]+)', url, re.I)
            host = host_m.group(1).split('.')[0].capitalize() if host_m else label
        except Exception:
            host = label or 'Hoster'
        links.append({'url': url, 'quality': self._quality((label or '') + ' ' + url), 'info': f'DE | {host}'})
        fflog(f'[megakino]   host link: {host} {url[:70]}', 1)

    def _links_from_episode_context(self, html, ep_id, seen):
        links = []
        try:
            if not html or not ep_id:
                return links
            positions = [m.start() for m in re.finditer(re.escape(str(ep_id)), html, re.I)]
            if not positions:
                return links
            for pos in positions[:4]:
                block = html[max(0, pos - 5000):pos + 12000]
                for sm in re.finditer(r'<select[^>]*>(.*?)</select>', block, re.S|re.I):
                    links.extend(self._options_from_block(sm.group(1), seen))
                for m in re.finditer(r"(?:data-url|data-link|data-src|href|src)=['\"](https?://[^'\"]+)['\"]", block, re.I):
                    self._add_hoster_link(links, seen, m.group(1))
                for m in re.finditer(r"https?://[^'\"<>\s]+", block, re.I):
                    self._add_hoster_link(links, seen, m.group(0))
            return links
        except Exception:
            fflog_exc()
            return links

    def _all_hoster_links(self, html, seen):
        links = []
        try:
            if not html:
                return links
            for sm in re.finditer(r'<select[^>]*>(.*?)</select>', html, re.S|re.I):
                links.extend(self._options_from_block(sm.group(1), seen))
            for m in re.finditer(r"(?:data-url|data-link|data-src|href|src)=['\"](https?://[^'\"]+)['\"]", html, re.I):
                self._add_hoster_link(links, seen, m.group(1))
            for m in re.finditer(r"https?://[^'\"<>\s]+", html, re.I):
                self._add_hoster_link(links, seen, m.group(0))
        except Exception:
            fflog_exc()
        return links

    # ------------------------------------------------------------------

    def _fetch_by_id(self, news_id, original_url):
        """
        Próbuje pobrać HTML strony tytułu kilkoma metodami — od najmniej
        do najbardziej kosztownej. Cloudflare chroni GET /films/ i /serials/
        ale DLE ma endpointy AJAX które mogą nie być objęte CF.
        """
        # Metoda 1: GET konkretnej strony szczegółów. To jest najpewniejsze dla bieżącej domeny.
        html = self._try_direct_get(original_url, news_id=news_id)
        if html and len(html) > 1000 and self._is_valid_detail_html(html, news_id, original_url) and self._has_content(html):
            fflog('[megakino] metoda 1 (direct detail GET) OK', 1)
            return html

        # Metoda 2: DLE controller AJAX showfull
        html = self._try_ajax_showfull(news_id)
        if html and len(html) > 1000 and self._has_content(html):
            fflog('[megakino] metoda 2 (ajax showfull) OK', 1)
            return html

        # Metoda 3: GET przez /index.php?newsid=ID (DLE shortlink)
        html = self._try_newsid(news_id)
        if html and len(html) > 1000 and self._has_content(html):
            fflog('[megakino] metoda 3 (newsid) OK', 1)
            return html

        fflog(f'[megakino] wszystkie metody zawiodly dla id={news_id}', 1)
        return None

    def _has_content(self, html):
        # Sprawdza czy HTML wygląda jak strona tytułu z odtwarzaczami/odcinkami.
        if not html:
            return False
        h = html.lower()
        if 'mr-select' in h or 'se-select' in h or 'episode' in h:
            return True
        if any(x in h for x in ('voe.sx', 'veev.to', 'vidmoly', 'dood.', 'vidsonic', 'vidara', 'filemoon', 'streamtape')):
            return True
        if re.search(r'<iframe[^>]+(?:data-src|src)=["\']https?://', html, re.I):
            return True
        if re.search(r'(?:data-url|data-link|href|src)=["\']https?://', html, re.I):
            return True
        return False

    def _try_ajax_showfull(self, news_id):
        """POST /engine/ajax/controller.php?mod=showfull — DLE internal"""
        try:
            url = self.base_link + '/engine/ajax/controller.php'
            data = urlencode({'mod': 'showfull', 'id': news_id})
            headers = dict(self.headers)
            headers['Content-Type'] = 'application/x-www-form-urlencoded'
            headers['X-Requested-With'] = 'XMLHttpRequest'
            headers['Referer'] = self.base_link + '/'
            fflog(f'[megakino] ajax showfull id={news_id}', 1)
            r = self.session.post(url, data=data, headers=headers, timeout=(5, 10))
            fflog(f'[megakino] ajax showfull status={r.status_code} len={len(r.text)}', 1)
            if r.status_code == 200:
                return r.text
        except Exception:
            fflog_exc()
        return None

    def _try_direct_get(self, url, news_id=None):
        """GET z krokiem weryfikacji yg_token (jak fetch w JS)"""
        cache_key = f'get:{url}'
        if cache_key in self._cache:
            return self._cache[cache_key]
        try:
            headers = dict(self.headers)
            headers['Referer'] = self.base_link + '/'
            # Krok 1: weryfikacja - jak JS fetch("/index.php?yg=token", {credentials:"include"})
            # fetch używa XHR headers, nie nawigacyjnych
            verify_headers = dict(self.headers)
            verify_headers['Referer'] = url  # Referer = strona którą chcemy otworzyć
            verify_headers['X-Requested-With'] = 'XMLHttpRequest'
            fflog('[megakino] yg token verify', 1)
            rv = self.session.get(self.base_link + '/index.php?yg=token',
                                  headers=verify_headers, timeout=(5, 8))
            fflog(f'[megakino] yg verify status={rv.status_code}', 1)
            # Pobierz nowy yg_token z odpowiedzi jeśli serwer go odświeżył
            new_yg = rv.cookies.get('yg_token')
            if new_yg:
                self.session.cookies.set('yg_token', new_yg)
                fflog('[megakino] otrzymano nowy yg_token', 1)
            # Krok 2: GET strony tytułu z Referer = strona główna
            fflog(f'[megakino] direct GET {url}', 1)
            r = self.session.get(url, headers=headers, timeout=(5, 10), allow_redirects=True)
            fflog(f'[megakino] direct GET status={r.status_code} len={len(r.text)} final={r.url}', 1)
            if len(r.text) < 500:
                fflog(f'[megakino] body: {repr(r.text[:300])}', 1)
            # Jeżeli serwer zrzucił nas na kategorię/listę, nie akceptuj tego jako strony tytułu.
            try:
                if news_id and ('/%s-' % news_id) not in r.url:
                    if not self._is_valid_detail_html(r.text, news_id, url):
                        fflog(f'[megakino] direct GET rejected: final URL/page mismatch for id={news_id}', 1)
                        return None
            except Exception:
                pass
            self._cache[cache_key] = r.text
            return r.text
        except Exception:
            fflog_exc()
        return None

    def _try_newsid(self, news_id):
        """GET /index.php?newsid=ID — DLE shortlink redirect"""
        try:
            url = f'{self.base_link}/index.php?newsid={news_id}'
            headers = dict(self.headers)
            headers['Referer'] = self.base_link + '/'
            fflog(f'[megakino] newsid GET {url}', 1)
            r = self.session.get(url, headers=headers, timeout=(5, 12),
                                 allow_redirects=True)
            fflog(f'[megakino] newsid status={r.status_code} len={len(r.text)} final={r.url}', 1)
            if r.status_code == 200:
                return r.text
        except Exception:
            fflog_exc()
        return None

    # ------------------------------------------------------------------

    def _search(self, title, localtitle, aliases, year, content):
        try:
            year_int = year_alt_int = None
            if isinstance(year, (tuple, list)):
                try: year_int     = int(year[0])
                except: pass
                try: year_alt_int = int(year[1])
                except: pass
            else:
                try: year_int = int(year)
                except: pass

            # MegaKino is a DE provider: query only German-region titles plus
            # the explicit original title.  The API-local title is normally
            # Polish and must never consume a MegaKino search slot.
            base_titles = _de_titles_from(localtitle, title, aliases, limit=10, ffitem=getattr(self, "ffitem", None), media_type=("show" if content == "serial" else "movie"))
            if not base_titles:
                return None
            # Megakino = serwis DE. W praktyce filmy są w wielu kategoriach,
            # a seriale/sezony często mają osobne wpisy typu "Cobra Kai - Staffel 2".
            # Szukamy kilkoma wariantami i dopiero potem wybieramy najlepszy wynik globalnie.
            # Kadr+ 2.0.93: try the strongest variant of each title/alias
            # before spending requests on punctuation alternatives of the same
            # name. This keeps German + original-title coverage while
            # bounding the worst-case latency on empty searches.
            variant_groups = [
                self._mk_query_variants(_bt, season=None, content=content)
                for _bt in base_titles
                if _bt
            ]
            titles = []
            max_variants = max((len(group) for group in variant_groups), default=0)
            for variant_index in range(max_variants):
                for group in variant_groups:
                    if variant_index >= len(group):
                        continue
                    _q = group[variant_index]
                    if _q and _q not in titles:
                        titles.append(_q)

            attempted = set()
            all_known_origins_failed = True
            for domain_index, candidate in enumerate(self._candidate_bases()):
                active = self._activate_base(candidate)
                # A historical address can redirect to a newer verified mirror.
                # Do not repeat the same origin later in the fallback list.
                if active in attempted:
                    continue
                attempted.add(active)
                fflog(f'[megakino] search domain {domain_index + 1}: {active}', 1)
                # Primary domain gets the strongest four title/alias variants;
                # mirrors get one. Together with the early exact-match exit
                # below this avoids multiplying a slow/empty request across
                # every punctuation variant.
                query_limit = 4 if domain_index == 0 else 1
                match = self._search_active_base(
                    titles, year_int, year_alt_int, content, query_limit=query_limit
                )
                if match:
                    self._remember_working_base(match)
                    fflog(f'[megakino] working domain: {self.base_link}', 1)
                    return match

                # Mirrors are transport fallbacks, not separate catalogues.
                # If the current origin answered normally but no verified title
                # matched, repeating the same search against old numbered domains
                # only adds several seconds (they currently redirect to the same
                # active MegaKino catalogue). Try another mirror only when the
                # current domain was actually unreachable at the transport layer.
                if not self._domain_transport_failed:
                    all_known_origins_failed = False
                    _diag('domain', 'result=reachable-no-match; stop-mirrors=1')
                    break

            # Standalone MegaKino publishes a tiny JSON with its current domain.
            # Use that trick only after every Kadr+-known origin was unreachable.
            # This avoids an extra GitHub request on normal searches and makes a
            # stale/compromised hint unable to override a healthy configured site.
            if self._auto_mirrors and all_known_origins_failed:
                remote_base = self._remote_domain_base()
                if remote_base and remote_base not in attempted:
                    active = self._activate_base(remote_base)
                    if active not in attempted:
                        attempted.add(active)
                        _diag('domain', 'stage=remote-fallback; attempt=1')
                        match = self._search_active_base(
                            titles, year_int, year_alt_int, content, query_limit=4
                        )
                        if match:
                            self._remember_working_base(match)
                            fflog(f'[megakino] working domain: {self.base_link}', 1)
                            return match
                        _diag(
                            'domain',
                            'stage=remote-fallback; result='
                            + ('transport-error' if self._domain_transport_failed else 'reachable-no-match'),
                        )
        except Exception:
            fflog_exc()
        return None

    def _search_active_base(self, titles, year_int, year_alt_int, content, query_limit=12):
        all_results = []
        seen_urls = set()
        limited_titles = titles[:max(1, int(query_limit or 1))]
        for query_index, title in enumerate(limited_titles, 1):
            started = time.monotonic()
            html = self._post_search(title)
            if not html:
                _diag(
                    'query',
                    f'index={query_index}/{len(limited_titles)}; results=0; '
                    f'elapsed={time.monotonic() - started:.2f}s',
                )
                if self._domain_transport_failed:
                    fflog(f'[megakino] domain unreachable, switching after {self.base_link}', 1)
                    break
                continue
            results = self._parse_results(html, content)
            fflog(f'[megakino] wynikow ({content}) na {self.base_link}: {len(results)} dla {title!r}', 1)
            for result in results:
                url = result.get('url')
                if url and url not in seen_urls:
                    seen_urls.add(url)
                    all_results.append(result)

            # Do not keep issuing search requests after we already have a
            # verified title/year match. _best_match performs the existing
            # detail-page verification, so this improves latency without
            # weakening MegaKino's wrong-title protection.
            match = self._best_match(
                results, titles, year_int, year_alt_int, content
            )
            _diag(
                'query',
                f'index={query_index}/{len(limited_titles)}; results={len(results)}; '
                f'total={len(all_results)}; match={int(bool(match))}; '
                f'elapsed={time.monotonic() - started:.2f}s',
            )
            if match:
                return match

        return self._best_match(all_results, titles, year_int, year_alt_int, content)

    def _split_meta(self, url):
        meta = {}
        if not url or '|KADR|' not in url:
            return url, meta
        base, tail = url.split('|KADR|', 1)
        for part in tail.split('|'):
            if '=' in part:
                k, v = part.split('=', 1)
                try:
                    meta[k] = unquote_plus(v)
                except Exception:
                    meta[k] = v
        return base, meta

    def _strip_season_title(self, text):
        """Return title without MegaKino season markers like 'Staffel 1', '1 Staffel', 'S01'."""
        text = unescape(str(text or ''))
        text = re.sub(r'\b(staffel|season)\D*\d+\b|\b\d+\D*(staffel|season)\b|\bs\d{1,2}\b', ' ', text, flags=re.I)
        text = re.sub(r'\s+', ' ', text).strip(' -:/|\t\r\n')
        return text

    def _strict_show_match(self, candidate, show, local=None):
        """
        Conservative match for TV season pages.
        Important for franchises with the same base name, e.g. Dexter (2006) vs
        Dexter: New Blood / Dexter: Original Sin / Dexter: Wiedererwachen.
        """
        wanted = title_matcher.title_variants(show, local, None, max_items=6)
        cand_raw = self._strip_season_title(candidate)
        cand_norm = title_matcher.normalize(cand_raw)
        if not cand_norm:
            return False
        for w in wanted:
            wn = title_matcher.normalize(self._strip_season_title(w))
            if not wn:
                continue
            if cand_norm == wn or title_matcher.compact(cand_norm) == title_matcher.compact(wn):
                return True
            wt = title_matcher.tokens(wn)
            ct = title_matcher.tokens(cand_norm)
            # One-word shows are especially dangerous: "Dexter" must not match
            # "Dexter Wiedererwachen", "Dexter New Blood" or "Dexter Original Sin".
            if len(wt) <= 1:
                continue
            if title_matcher.score(cand_norm, wn) >= 88:
                return True
            if set(wt) and len(set(wt) & set(ct)) >= max(2, len(set(wt)) * 2 // 3):
                return True
        return False

    def _is_exact_season_title(self, title, show, local, season):
        try:
            if not title:
                return False
            if not self._season_token_match(title, season):
                return False
            return self._strict_show_match(title, show, local) or self._strict_show_match((title or '').replace('-', ' '), show, local)
        except Exception:
            return False

    def _season_exact_score(self, title, slug, url, show, local, season, wanted):
        try:
            title = title or ''
            slug = (slug or '').replace('-', ' ')
            hay = '%s %s %s' % (title, slug, url or '')
            if not self._season_token_match(hay, season):
                return -999
            if not (self._strict_show_match(title, show, local) or self._strict_show_match(slug, show, local)):
                return -999
            base_score = max(title_matcher.score(self._strip_season_title(title), w) for w in wanted) if wanted else 0
            slug_score = max(title_matcher.score(self._strip_season_title(slug), w) for w in wanted) if wanted else 0
            score = max(base_score, slug_score)
            if re.search(r'\b(staffel|season)\D*%d\b|\b%d\D*(staffel|season)\b|\bs%02d\b|\bs%d\b' % (int(season), int(season), int(season), int(season)), hay, re.I):
                score += 30
            clean_title = self._strip_season_title(title).lower()
            clean_wanted = [self._strip_season_title(w).lower() for w in wanted]
            if clean_title in clean_wanted:
                score += 35
            # Prefer real season pages over generic franchise/spinoff pages.
            if re.search(r':|new blood|original sin|wiedererwachen|resurrection', title + ' ' + slug, re.I):
                score -= 80
            score -= min(len(url or ''), 160) // 25
            return score
        except Exception:
            return -999

    def _detail_year_ok(self, result, year, year_alt=None):
        if not year:
            return True
        try:
            y = int(year)
        except Exception:
            y = None
        try:
            ya = int(year_alt) if year_alt else None
        except Exception:
            ya = None
        ry = result.get('year') if isinstance(result, dict) else None
        if ry and y and (abs(int(ry) - y) <= 1 or (ya and int(ry) == ya)):
            return True
        # Search snippets are sometimes wrong/incomplete; verify detail page before rejecting.
        try:
            html = self._fetch_by_id(result.get('id') or '', result.get('url') or '')
            years = self._detail_years(html, result.get('slug') or '')
            if not years:
                return True
            return any((y and abs(int(v) - y) <= 1) or (ya and int(v) == ya) for v in years)
        except Exception:
            return bool(not ry)

    def _season_token_match(self, text, season):
        text = (text or '').lower()
        try:
            s = int(season)
        except Exception:
            return False
        pats = [
            r'\bstaffel\D*%d\b' % s,
            r'\bseason\D*%d\b' % s,
            r'\b%d\D*staffel\b' % s,
            r'\b%d\D*season\b' % s,
            r'\bs%02d\b' % s,
            r'\bs%d\b' % s,
            r'staffel-%d' % s,
            r'season-%d' % s,
        ]
        return any(re.search(p, text, re.I) for p in pats)

    def _base_title_match(self, candidate, show):
        cand = re.sub(r'\b(staffel|season)\D*\d+\b|\b\d+\D*(staffel|season)\b|\bs\d{1,2}\b', ' ', str(candidate or ''), flags=re.I)
        sh = re.sub(r'\b(staffel|season)\D*\d+\b|\b\d+\D*(staffel|season)\b|\bs\d{1,2}\b', ' ', str(show or ''), flags=re.I)
        if title_matcher.matches(cand, sh, threshold=78):
            return True
        cn = cleantitle.normalize(cleantitle.getsearch(cand))
        sn = cleantitle.normalize(cleantitle.getsearch(sh))
        if not cn or not sn:
            return False
        if cn == sn:
            return True
        # Avoid franchise false positives: Dexter != Dexter Wiedererwachen/New Blood.
        if len(sn.split()) <= 1 and cn != sn:
            return False
        if sn in cn or cn in sn:
            return True
        sw = set(sn.split())
        cw = set(cn.split())
        return bool(sw) and len(sw & cw) >= max(1, len(sw) * 2 // 3)

    def _mk_query_variants(self, text, season=None, content=None):
        """Kadr+ 2.40.61: MegaKino query variants learned from matrix tests."""
        out, seen = [], set()
        def add(v):
            v = re.sub(r'\s+', ' ', str(v or '')).strip(' -:/|\t\r\n')
            if not v:
                return
            key = cleantitle.normalize(cleantitle.getsearch(v))
            if key and key not in seen:
                seen.add(key)
                out.append(v)
        base = str(text or '')
        simplified = re.sub(r'[:|/]+', ' ', base)
        simplified = re.sub(r'\s*-\s*', ' ', simplified)
        simplified = re.sub(r'\s+', ' ', simplified).strip()
        hyphen = re.sub(r'[:|/]+', ' - ', base)
        hyphen = re.sub(r'\s+', ' ', hyphen).strip()
        for b in (simplified, hyphen, base):
            if season:
                try:
                    s = int(season)
                except Exception:
                    s = season
                add(f'{b} {s} Staffel')
                add(f'{b} - {s} Staffel')
                add(f'{b} Staffel {s}')
                add(f'{b} - Staffel {s}')
                add(f'Staffel {s} {b}')
                add(f'{b} Season {s}')
                try:
                    add(f'{b} S{int(s):02d}')
                except Exception:
                    pass
            add(b)
        return out

    def _search_season_page(self, show, local, year, season, fallback_url):
        if not show and not local:
            return None
        queries = []
        # Kadr+ 2.40.88: exact season queries first, then broader variants.
        # MegaKino exposes classic Dexter as separate season pages like
        # "Dexter - Staffel 2", but the snippet year can be wrong.  Do not reject
        # exact title+season pages only because the search-card year is odd.
        for base in [show, local]:
            if not base:
                continue
            base = re.sub(r'\s+', ' ', str(base)).strip()
            try:
                s_num = int(season)
            except Exception:
                s_num = season
            priority = [
                f'{base} Staffel {s_num}',
                f'{base} - Staffel {s_num}',
                f'{base} {s_num} Staffel',
                f'{base} - {s_num} Staffel',
                f'{base} S{int(s_num):02d}' if str(s_num).isdigit() else '',
            ]
            for q in priority + self._mk_query_variants(base, season=season, content='serial'):
                if q and q not in queries:
                    queries.append(q)
        wanted = title_matcher.title_variants(show, local, None, max_items=6)
        best = None
        best_score = -999
        for q_index, q in enumerate(queries[:10]):
            html = self._post_search(q)
            if not html:
                continue
            results = self._parse_results(html, 'serial')
            fflog(f'[megakino] season-search {q!r}: {len(results)} wynikow', 1)
            for r in results:
                title = r.get('title') or ''
                url = r.get('url') or ''
                slug = (r.get('slug') or '').replace('-', ' ')
                score = self._season_exact_score(title, slug, url, show, local, season, wanted)
                if score <= -900:
                    fflog(f'[megakino] season reject title/season/franchise: {title!r} -> {url}', 1)
                    continue

                # Kadr+ 2.40.89: MegaKino search cards can have a wrong or noisy year
                # for real season pages.  Treat an exact base-title + season match in
                # title/slug/url as authoritative.  This is important for Dexter classic
                # seasons, where cards like "Dexter - Staffel 2" may show odd years but
                # the URL/slug is still the correct season page.
                exact_slug = (
                    self._season_token_match(' '.join([slug, url]), season)
                    and (self._strict_show_match(slug, show, local) or self._strict_show_match(title, show, local))
                )
                exact = score >= 95 or exact_slug or self._is_exact_season_title(title, show, local, season)
                if not exact and not self._detail_year_ok(r, year, None):
                    fflog(f'[megakino] season reject year: {title!r} year={r.get("year")} wanted={year} -> {url}', 1)
                    continue

                if score > best_score:
                    best_score = score
                    best = r

                # Early return for a clean exact season hit from a specific query.
                # Avoids scanning many fallback queries and prevents later generic
                # "Dexter" results from replacing "Dexter - Staffel 2".
                if exact and q_index <= 4:
                    fflog(f'[megakino] season page exact early score={score}: {title!r} -> {url}', 1)
                    return url
        if best and best_score >= 80:
            fflog(f'[megakino] season page strict match score={best_score}: {best.get("title")!r} -> {best.get("url")}', 1)
            return best.get('url')
        try:
            if fallback_url and self._season_token_match(fallback_url, season):
                return fallback_url
        except Exception:
            pass
        return None

    def _post_search(self, title):
        # Cache must be domain-specific. The old provider reused a result from a
        # failed/obsolete domain after switching the base address.
        ck = f'search:{self.base_link.lower()}:{title}'
        if ck in self._cache:
            return self._cache[ck]

        from urllib.parse import quote
        self._init_session()
        headers = dict(self.headers)
        headers['Referer'] = self.base_link + '/'

        # Current MegaKino/xStream search uses the normal DLE root query. The
        # previous Kadr+ implementation tried several obsolete AJAX/GET forms
        # first, each with long timeouts. On an empty title this could spend
        # 20+ seconds before reaching the working URL.
        search_url = (
            self.base_link + '/?story=' + quote(str(title or ''))
            + '&do=search&subaction=search'
        )

        # Real-device diagnostics showed that an unprimed search can spend ~8 s
        # returning only the tiny yg challenge page, while the token endpoint
        # itself answers in a fraction of a second. Prime exactly once per live
        # session/domain; this replaces that slow challenge round-trip rather
        # than reintroducing the old multi-request pre-warm.
        if not self._yg_token_primed:
            self._refresh_yg_token(search_url)

        def _get(url, label, *, retry_token=True):
            started = time.monotonic()
            try:
                response = self.session.get(
                    url, headers=headers, timeout=(3, 7), allow_redirects=True
                )
                self._adopt_response_base(getattr(response, 'url', ''))
                text = response.text or ''
                challenge = 'yg=token' in text
                _diag(
                    'request',
                    f'method={label}; status={response.status_code}; bytes={len(text)}; '
                    f'challenge={int(challenge)}; elapsed={time.monotonic() - started:.2f}s',
                )
                if challenge:
                    if retry_token and self._refresh_yg_token(url):
                        return _get(url, label + '-retry', retry_token=False)
                    # A challenge page is not a search result. Let the classic
                    # POST/mirror fallback take over if token refresh failed or
                    # the retry was challenged again.
                    return None, True
                if response.status_code < 400 and text:
                    return text, True
                return None, True
            except Exception:
                _diag('request', f'method={label}; result=transport-error; elapsed={time.monotonic() - started:.2f}s')
                return None, False

        html, got_response = _get(search_url, 'dle-get')
        if html is not None:
            self._cache[ck] = html
            return html

        # Compatibility fallback for mirrors that still accept the classic DLE
        # POST. Only use it when the root search was unavailable/invalid; do not
        # fan out across unrelated query syntaxes after a valid empty result.
        h = dict(headers)
        h['Content-Type'] = 'application/x-www-form-urlencoded'
        started = time.monotonic()
        try:
            response = self.session.post(
                self.base_link + '/index.php',
                data=urlencode({'do': 'search', 'subaction': 'search', 'story': title}),
                headers=h, timeout=(3, 7), allow_redirects=True,
            )
            self._adopt_response_base(getattr(response, 'url', ''))
            text = response.text or ''
            challenge = 'yg=token' in text
            _diag(
                'request',
                f'method=dle-post; status={response.status_code}; bytes={len(text)}; '
                f'challenge={int(challenge)}; elapsed={time.monotonic() - started:.2f}s',
            )
            if challenge and self._refresh_yg_token(self.base_link + '/index.php'):
                response = self.session.post(
                    self.base_link + '/index.php',
                    data=urlencode({'do': 'search', 'subaction': 'search', 'story': title}),
                    headers=h, timeout=(3, 7), allow_redirects=True,
                )
                self._adopt_response_base(getattr(response, 'url', ''))
                text = response.text or ''
            if response.status_code < 400 and text:
                self._cache[ck] = text
                return text
            got_response = True
        except Exception:
            _diag('request', f'method=dle-post; result=transport-error; elapsed={time.monotonic() - started:.2f}s')

        if not got_response:
            self._domain_transport_failed = True
        self._cache[ck] = None
        return None

    def _parse_results(self, html, content):
        """
        Megakino nie trzyma wszystkich filmów pod /films/ i seriali pod /serials/.
        W praktyce wyniki/sezony leżą często w kategoriach typu /drama/4005-cobra-kai-staffel-1.html
        albo /action/4373-cobra-kai-staffel-6.html. Parsujemy więc wszystkie linki DLE z ID,
        a potem filtrujemy po tytule/roku/sezonie.
        """
        results = []
        seen    = set()
        pat = re.compile(
            r'href=["\'](?P<full>(?:https?://[^/"\']+)?'
            r'(?P<path>/(?!page/|index\.php|engine/|xfsearch/|tags/|uploads/|templates/)'
            r'[a-z0-9_-]+/(?P<id>\d+)-(?P<slug>[^"\']+?)\.html))["\']',
            re.I,
        )
        document = (html or '').replace('\\/', '/')
        for m in pat.finditer(document):
            raw, path, nid, slug = m.group('full'), m.group('path'), m.group('id'), m.group('slug')
            if raw.lower().startswith(('http://', 'https://')):
                origin = self._base_from_url(raw)
                if not origin:
                    continue
            else:
                origin = self.base_link
            result_url = origin + path
            if result_url in seen:
                continue
            seen.add(result_url)

            # Read metadata only from the current anchor.  Looking hundreds of
            # characters around the match mixed adjacent DLE cards: a nearby
            # "Staffel 1" title could make an ordinary movie look like a season
            # page and remove it from the results entirely.
            anchor_start = document.rfind('<a', max(0, m.start() - 1000), m.start() + 1)
            if anchor_start < 0:
                anchor_start = m.start()
            tag_end = document.find('>', m.end())
            if tag_end < 0 or tag_end - anchor_start > 1600:
                tag_end = m.end()
            anchor_end = document.find('</a>', tag_end)
            if anchor_end < 0 or anchor_end - anchor_start > 2500:
                anchor_end = tag_end
            else:
                anchor_end += 4
            anchor = document[anchor_start:anchor_end]
            opening_tag = document[anchor_start:tag_end + 1]

            title_m = re.search(r'title=["\']([^"\']{3,})["\']', opening_tag, re.I)
            alt_m = re.search(r'alt=["\']([^"\']{3,})["\']', anchor, re.I)
            text_m = re.search(r'>\s*([^<>]{3,120}?)\s*</a>', anchor, re.S | re.I)
            title = (alt_m.group(1) if alt_m else (title_m.group(1) if title_m else (text_m.group(1) if text_m else slug.replace('-', ' '))))
            title = re.sub(r'\s+', ' ', title).strip()
            year_m = re.search(r'\b(19|20)\d{2}\b', ' '.join((anchor, title, slug)))
            year   = int(year_m.group()) if year_m else None
            lower_hay = (slug + ' ' + title + ' ' + path).lower()
            is_season_page = bool(re.search(r'\b(staffel|season)\D*\d+\b|\bs\d{1,2}\b', lower_hay, re.I))
            if content == 'film' and is_season_page:
                # Nie zwracaj stron sezonów jako filmy.
                continue
            results.append({
                'url': result_url,
                'id': nid,
                'title': title,
                'slug': slug,
                'year': year,
                'season_page': is_season_page,
                'category': path.strip('/').split('/')[0]
            })
            fflog(f'[megakino]   wynik: {title!r} ({year}) id={nid} path={path}', 1)

        # JSON/AJAX fallback: DLE search can return snippets with escaped slashes or JSON fields.
        json_pat = re.compile(r'["\'](?:url|link|href)["\']\s*:\s*["\']([^"\']+?/(\d+)-([^"\']+?)\.html)["\']', re.I)
        for m in json_pat.finditer((html or '').replace('\\/', '/')):
            path, nid, slug = m.group(1), m.group(2), m.group(3)
            path = path.replace('\\/', '/')
            if path.startswith('http'):
                origin = self._base_from_url(path)
                if not origin:
                    continue
                parsed_path = urlsplit(path).path
                path_part = parsed_path if parsed_path.startswith('/') else '/' + parsed_path
                url = origin + path_part
            else:
                path_part = path if path.startswith('/') else '/' + path
                url = self.base_link + path_part
            if url in seen:
                continue
            seen.add(url)
            title = slug.replace('-', ' ')
            lower_hay = (slug + ' ' + title + ' ' + path_part).lower()
            is_season_page = bool(re.search(r'\b(staffel|season)\D*\d+\b|\bs\d{1,2}\b', lower_hay, re.I))
            if content == 'film' and is_season_page:
                continue
            results.append({'url': url, 'id': nid, 'title': title, 'slug': slug, 'year': None,
                            'season_page': is_season_page, 'category': path_part.strip('/').split('/')[0]})
        return results

    def _detail_years(self, html, slug=''):
        years = set()
        sample = (slug or '') + ' ' + (html or '')[:3500]
        for y in re.findall(r'\b((?:19|20)\d{2})\b', sample):
            try:
                yi = int(y)
                if 1900 <= yi <= 2035:
                    years.add(yi)
            except Exception:
                pass
        return years

    def _verify_result_page(self, r, wanted_titles, year=None, year_alt=None, content='film'):
        try:
            url = r.get('url')
            if not url:
                return False
            html = self._fetch_by_id(r.get('id') or '', url)
            if not html:
                return False
            title = r.get('title') or r.get('slug', '').replace('-', ' ')
            # Detal ma czasem lepszy tytuł w h1/title niż wynik wyszukiwania.
            m = re.search(r'<h[12][^>]*>\s*([^<]{2,140})', html, re.I)
            if m:
                title = re.sub(r'\s+', ' ', m.group(1)).strip()
            if not title_matcher.matches_any(title, wanted_titles, threshold=78) and not title_matcher.matches_any(r.get('slug','').replace('-', ' '), wanted_titles, threshold=78):
                return False
            if content == 'film' and r.get('season_page'):
                return False
            if year:
                years = self._detail_years(html, r.get('slug') or '')
                if years and not any(abs(y - int(year)) <= 1 or (year_alt and y == int(year_alt)) for y in years):
                    # Megakino także potrafi mieć kategorie/strony bez jednoznacznego roku; jeśli jest rok ewidentnie zły, odrzuć.
                    return False
            return True
        except Exception:
            return False

    def _best_match(self, results, wanted_titles, year, year_alt, content='film'):
        if not results:
            return None
        if isinstance(wanted_titles, str):
            wanted_titles = [wanted_titles]
        scored = []
        for r in results:
            title = r.get('title') or ''
            slug_title = (r.get('slug') or '').replace('-', ' ')
            title_score = max(title_matcher.score(title, w) for w in wanted_titles) if wanted_titles else 0
            slug_score  = max(title_matcher.score(slug_title, w) for w in wanted_titles) if wanted_titles else 0
            ts = max(title_score, slug_score)
            if ts < 76:
                continue
            ry = r.get('year')
            yr = (18 if ry and year and ry in (year, year_alt)
                  else 8 if ry and year and abs(ry-year) <= 1
                  else -35 if ry and year and abs(ry-year) > 1 else 0)
            season_bonus = 0
            if content == 'serial':
                season_bonus = 12 if r.get('season_page') else 0
                if r.get('category') in ('serials','drama','action','adventure','science-fiction','crime','fantasy','comedy','horror','thriller'):
                    season_bonus += 2
            elif r.get('season_page'):
                season_bonus = -60
            total = ts + yr + season_bonus
            scored.append((total, r['url'], title, ry, r))
            fflog(f'[megakino]   score={total} title_score={ts} {title!r} ({ry}) -> {r["url"]}', 1)
        if not scored:
            return None
        scored.sort(key=lambda x: x[0], reverse=True)
        if scored[0][0] < 82:
            return None

        # Weryfikuj top kandydatów stroną szczegółów, bo Megakino miesza filmy i sezony w kategoriach.
        for total, url, title, ry, r in scored[:5]:
            if self._verify_result_page(r, wanted_titles, year, year_alt, content):
                fflog(f'[megakino] detail verify OK score={total} {title!r} -> {url}', 1)
                return url

        fflog(f'[megakino] detail verify fallback score={scored[0][0]} -> {scored[0][1]}', 1)
        return scored[0][1]

    def _extract_links(self, html, season=None, episode=None, news_id=None, referer=None):
        links = []
        seen  = set()
        if season is not None and episode is not None:
            # Kadr+ 2.40.57:
            # For TV episodes return only hosters tied to the selected episode id.
            # Do not scan the whole season page, because that can return hosters from a wrong episode.
            season_block = self._season_block(html, int(season)) or html
            ep_id = self._find_ep_id(season_block, int(episode))
            fflog(f'[megakino] ep_id={ep_id} dla S{season}E{episode} (strict episode block)', 1)
            if ep_id:
                links = self._links_from_select(season_block, ep_id, seen)
                if not links:
                    # Kadr+ 2.40.62:
                    # Nie używamy szerokiego strict-container fallbacku dla seriali.
                    # Na MegaKino lista odcinków i domyślny player potrafią być blisko siebie w HTML;
                    # dla S01E10 mogło to złapać hostery z domyślnego S01E01.
                    # Źródła bierzemy tylko z dokładnego selecta epX albo z endpointów AJAX powiązanych z epX.
                    links = self._links_from_episode_ajax(html, news_id, season, episode, ep_id, referer, seen)
            if not links:
                fflog(f'[megakino] brak hosterow dla konkretnego odcinka S{season}E{episode}; nie zwracam hosterow z calego sezonu', 1)
        else:
            # Movies: full-page hoster scan is fine.
            for m in re.finditer(
                r'<select[^>]+class=["\'][^"\']*mr-select[^"\']*["\'][^>]*>(.*?)</select>',
                html, re.S|re.I
            ):
                links += self._options_from_block(m.group(1), seen)
            if not links:
                for m in re.finditer(
                    r'<iframe[^>]+(?:data-src|src)=["\'](\s*https?://[^"\']+)["\']',
                    html, re.I
                ):
                    url = m.group(1).strip()
                    if 'youtube.com' in url or 'megakino' in url:
                        continue
                    if url in seen:
                        continue
                    seen.add(url)
                    host_m = re.search(r'https?://(?:www\.)?([^/]+)', url)
                    label = host_m.group(1).split('.')[0].capitalize() if host_m else 'Hoster'
                    links.append({'url': url, 'quality': self._quality(url), 'info': f'DE | {label}'})
                    fflog(f'[megakino]   iframe link: {label} {url[:60]}', 1)
            if not links:
                links = self._all_hoster_links(html, seen)
        return links

    def _season_block(self, html, season):
        """
        Kadr+ 2.40.52: wycina fragment HTML właściwy dla sezonu.
        Megakino ma strony sezonowe, ale część HTML/AJAX nadal zawiera wiele list
        odcinków. Jeśli metoda nie znajdzie jednoznacznego bloku, zwraca cały HTML,
        żeby istniejący fallback mógł dalej znaleźć ep_id.
        """
        try:
            if not html or not season:
                return None
            s = int(season)
            # Najpierw szukamy nagłówka/zakładki Staffel/Season/Sxx i bierzemy zakres do kolejnego sezonu.
            token = r'(?:Staffel|Season)\s*%d|S%02d\b|S%d\b' % (s, s, s)
            starts = []
            for m in re.finditer(token, html, re.I):
                starts.append(m.start())
            if starts:
                start = starts[0]
                next_pat = r'(?:Staffel|Season)\s*%d|S%02d\b|S%d\b' % (s + 1, s + 1, s + 1)
                n = re.search(next_pat, html[start + 1:], re.I)
                end = start + 1 + n.start() if n else len(html)
                block = html[max(0, start - 3000):end]
                if 'ep' in block.lower() or 'mr-select' in block.lower() or 'se-select' in block.lower():
                    return block
            # Na sezonowej stronie typu cobra-kai-staffel-2.html cały dokument jest już właściwym sezonem.
            if self._season_token_match(html[:8000], s) or self._season_token_match(html, s):
                return html
            # Jeżeli URL/tytuł strony nie niesie sezonu, ale HTML zawiera wybór odcinków,
            # zostawiamy istniejący fallback na cały HTML.
            if 'se-select' in html or 'mr-select' in html:
                return html
        except Exception:
            pass
        return None

    def _find_ep_id(self, html, episode):
        try:
            e = int(episode)
            se = re.search(
                r'<select[^>]+class=["\'][^"\']*se-select[^"\']*["\'][^>]*>(.*?)</select>',
                html, re.S|re.I
            )
            if se:
                opts = []
                for m in re.finditer(r'<option([^>]*)>(.*?)</option>', se.group(1), re.S|re.I):
                    attrs, label_html = m.group(1), m.group(2)
                    vm = re.search(r'value=["\']([^"\']+)["\']', attrs, re.I)
                    if not vm:
                        continue
                    value = vm.group(1).strip()
                    label = self._strip_html(label_html)
                    hay = ' '.join([value, label]).lower()
                    # Covers: ep6, ep06, Episode 6, Folge 6, 6. Requiem, 6 Requiem.
                    pats = [
                        r'\bep0?%d\b' % e,
                        r'\bepisode\s*0?%d\b' % e,
                        r'\bfolge\s*0?%d\b' % e,
                        r'(^|\D)0?%d(\D|$)' % e,
                    ]
                    opts.append(value)
                    if any(re.search(p, hay, re.I) for p in pats):
                        return value
                if 0 < e <= len(opts):
                    return opts[e-1]
        except Exception:
            fflog_exc()
        return f'ep{episode}'


    def _links_from_episode_ajax(self, html, news_id, season, episode, ep_id, referer, seen):
        """
        Kadr+ 2.40.60: exact-episode fallback for MegaKino.

        The older working parser could find a hoster select by exact id/value like
        `ep6` in the full detail HTML.  The later strict season-block code was safer
        against wrong-episode links, but when the hoster select was outside the clipped
        block it ended with 0 links, and 2.40.59 additionally missed this method.

        This fallback is still strict: it only accepts links tied to the exact episode
        identifier (`ep6`, etc.), then tries one-hop internal Megakino AJAX/player
        values. It does not return hosters from the whole season page.
        """
        links = []
        try:
            if not html or not ep_id:
                return links

            # 1) Restore the old successful path: exact <select id="epX"> from full HTML.
            try:
                links = self._links_from_select(html, ep_id, seen)
                if links:
                    fflog(f'[megakino] exact full-page select {ep_id}: {len(links)} linkow', 1)
                    return links
            except Exception:
                fflog_exc()

            sid = str(ep_id)
            sid_re = re.escape(sid)

            # 2) Look for episode-specific wrappers/buttons containing internal player data.
            patterns = [
                r'(<[^>]+(?:id|data-id|data-episode|data-ep|value|href)=["\'][^"\']*%s[^"\']*["\'][^>]*>)' % sid_re,
                r'(<option[^>]+value=["\']%s["\'][^>]*>.*?</option>)' % sid_re,
            ]
            positions = []
            for pat in patterns:
                for m in re.finditer(pat, html, re.S | re.I):
                    positions.append(m.start())
            # also check raw ep id positions, but keep this limited.
            for m in re.finditer(r'\b%s\b' % sid_re, html, re.I):
                positions.append(m.start())

            uniq = []
            for pos in sorted(set(positions)):
                if not uniq or abs(pos - uniq[-1]) > 200:
                    uniq.append(pos)

            for pos in uniq[:10]:
                start = max(0, pos - 2500)
                end = min(len(html), pos + 12000)
                # Stop at next episode marker if it is close, so we do not bleed into another ep.
                try:
                    em = re.search(r'ep0?(\d+)', sid, re.I)
                    if em:
                        nxt = 'ep%d' % (int(em.group(1)) + 1)
                        nm = re.search(re.escape(nxt), html[pos + 1:pos + 16000], re.I)
                        if nm:
                            end = min(end, pos + 1 + nm.start())
                except Exception:
                    pass
                block = html[start:end]

                # First parse any selects in this exact neighbourhood.
                for sm in re.finditer(r'<select[^>]*>(.*?)</select>', block, re.S | re.I):
                    links.extend(self._options_from_block(sm.group(1), seen))
                    if links:
                        fflog(f'[megakino] exact episode neighbourhood select {ep_id}: {len(links)} linkow', 1)
                        return links

                # Then resolve only values/links attached to this neighbourhood.
                values = []
                attr_pat = r'(?:data-url|data-link|data-src|data-file|data-href|href|src)=(["\'])(.*?)\1'
                for m in re.finditer(attr_pat, block, re.I):
                    val = (m.group(2) or '').strip()
                    if val and not val.startswith('#') and not val.lower().startswith('javascript'):
                        values.append(val)
                js_pat = r'(?:url|link|file|src|iframe|player|load)\s*[:=]\s*(["\'])(.*?)\1'
                for m in re.finditer(js_pat, block, re.I):
                    val = (m.group(2) or '').strip()
                    if val:
                        values.append(val)

                for val in values[:12]:
                    if val.startswith('http') and 'megakino' not in val:
                        self._add_hoster_link(links, seen, val)
                    else:
                        for it in self._resolve_internal_value(val, referer=referer):
                            u = it.get('url')
                            if u and u not in seen:
                                seen.add(u)
                                links.append(it)
                    if links:
                        fflog(f'[megakino] exact episode ajax/internal {ep_id}: {len(links)} linkow', 1)
                        return links

            # 3) Last exact DLE-style attempts.  Keep them bounded and episode-specific.
            if news_id:
                endpoint_payloads = [
                    ('/engine/ajax/controller.php', {'mod': 'showfull', 'id': str(news_id), 'episode': str(episode), 'season': str(season), 'ep': sid}),
                    ('/engine/ajax/controller.php?mod=showfull', {'id': str(news_id), 'episode': str(episode), 'season': str(season), 'ep': sid}),
                    ('/engine/ajax/play.php', {'news_id': str(news_id), 'id': str(news_id), 'episode': str(episode), 'season': str(season), 'ep': sid}),
                    ('/index.php?do=ajax', {'news_id': str(news_id), 'id': str(news_id), 'episode': str(episode), 'season': str(season), 'ep': sid}),
                ]
                headers = dict(self.headers)
                headers['Referer'] = referer or self.base_link + '/'
                headers['X-Requested-With'] = 'XMLHttpRequest'
                headers['Content-Type'] = 'application/x-www-form-urlencoded'
                for path, data in endpoint_payloads:
                    try:
                        url = self.base_link + path
                        r = self.session.post(url, data=urlencode(data), headers=headers, timeout=(6, 10))
                        body = r.text or ''
                        fflog(f'[megakino] ajax fallback {path} status={r.status_code} len={len(body)}', 1)
                        if r.status_code not in (200, 204) or len(body) < 5:
                            continue
                        # Only accept response if it mentions selected ep/news or contains direct hoster links.
                        if sid not in body and str(news_id) not in body and not re.search(r'https?:\\?/\\?/[^\'"<>\\s]+', body, re.I):
                            continue
                        for m in re.finditer(r'(?:data-url|data-link|data-src|data-file|href|src)=(["\'])(.*?)\1', body, re.I):
                            val = (m.group(2) or '').strip()
                            if val.startswith('http') and 'megakino' not in val:
                                self._add_hoster_link(links, seen, val)
                            else:
                                for it in self._resolve_internal_value(val, referer=referer):
                                    u = it.get('url')
                                    if u and u not in seen:
                                        seen.add(u)
                                        links.append(it)
                        for m in re.finditer(r'https?:\\?/\\?/[^\'"<>\\s]+', body, re.I):
                            self._add_hoster_link(links, seen, m.group(0))
                        if links:
                            fflog(f'[megakino] ajax fallback returned {len(links)} linkow', 1)
                            return links
                    except Exception:
                        fflog_exc()
        except Exception:
            fflog_exc()
        return links

    def _links_from_strict_episode_container(self, html, ep_id, seen):
        """
        Kadr+ 2.40.58: strict per-episode hoster extraction.
        MegaKino sometimes stores the selected episode value (e.g. ep6) in a tab/button,
        and the hoster select/list is in the nearest following container rather than in a
        select with id/name=ep6.  This scans only small containers around that exact ep_id,
        so it does not accidentally return hosters from the whole season.
        """
        links = []
        try:
            if not html or not ep_id:
                return links
            sid = str(ep_id)
            sid_re = re.escape(sid)
            positions = []
            patterns = [
                r'(?:id|data-id|data-episode|data-ep|value|href)=["\'][^"\']*%s[^"\']*["\']' % sid_re,
                r'\b%s\b' % sid_re,
            ]
            for pat in patterns:
                for m in re.finditer(pat, html, re.I):
                    positions.append(m.start())
            uniq = []
            for pos in sorted(positions):
                if not uniq or abs(pos - uniq[-1]) > 150:
                    uniq.append(pos)
            for pos in uniq[:8]:
                start = max(0, pos - 2500)
                end = min(len(html), pos + 10000)
                try:
                    mcur = re.search(r'ep0?(\d+)', sid, re.I)
                    if mcur:
                        nxt = 'ep%d' % (int(mcur.group(1)) + 1)
                        n = re.search(re.escape(nxt), html[pos + 1:pos + 16000], re.I)
                        if n:
                            end = min(end, pos + 1 + n.start())
                except Exception:
                    pass
                block = html[start:end]
                for sm in re.finditer(r'<select[^>]*>(.*?)</select>', block, re.S | re.I):
                    links.extend(self._options_from_block(sm.group(1), seen))
                    if links:
                        return links
                for m in re.finditer(r'(?:data-url|data-link|data-src|data-file|href|src)=["\']([^"\']+)["\']', block, re.I):
                    val = (m.group(1) or '').strip()
                    if not val or val.startswith('#') or val.startswith('javascript'):
                        continue
                    if val.startswith('http') and 'megakino' not in val:
                        self._add_hoster_link(links, seen, val)
                    else:
                        for it in self._resolve_internal_value(val):
                            u = it.get('url')
                            if u and u not in seen:
                                seen.add(u)
                                links.append(it)
                    if links:
                        return links
                for m in re.finditer(r'(?:url|link|file|src|iframe)\s*[:=]\s*["\']([^"\']+)["\']', block, re.I):
                    val = (m.group(1) or '').strip()
                    if not val:
                        continue
                    if val.startswith('http') and 'megakino' not in val:
                        self._add_hoster_link(links, seen, val)
                    else:
                        for it in self._resolve_internal_value(val):
                            u = it.get('url')
                            if u and u not in seen:
                                seen.add(u)
                                links.append(it)
                    if links:
                        return links
                for m in re.finditer(r'https?://[^\'"<>\s]+', block, re.I):
                    val = m.group(0)
                    if 'megakino' in val or 'youtube.com' in val or 'google' in val:
                        continue
                    self._add_hoster_link(links, seen, val)
                    if links:
                        return links
        except Exception:
            fflog_exc()
        return links

    def _links_from_select(self, html, select_id, seen):
        if not select_id:
            return []
        links = []
        sid = str(select_id)
        sid_re = re.escape(sid)
        # Kadr+ 2.40.62: accept only hoster selects explicitly bound to this episode id.
        # A nearby generic select may be the default player for episode 1; that caused S01E10 -> S01E01.
        select_patterns = [
            rf'<select(?P<attrs>[^>]+(?:id|name|data-id|data-episode|data-ep)=["\']{sid_re}["\'][^>]*)>(?P<body>.*?)</select>',
            rf'<select(?P<attrs>[^>]+data-target=["\'][^"\']*{sid_re}[^"\']*["\'][^>]*)>(?P<body>.*?)</select>',
        ]
        for pat in select_patterns:
            for m in re.finditer(pat, html, re.S|re.I):
                attrs = m.group('attrs') or ''
                body = m.group('body') or ''
                # Skip the episode selector itself (options ep1/ep2/ep10...), parse only hoster selects.
                if 'se-select' in attrs.lower():
                    continue
                body_lower = body.lower()
                if re.search(r'<option[^>]+value=["\']ep\d+["\']', body_lower, re.I):
                    continue
                links.extend(self._options_from_block(body, seen))
                if links:
                    return links
        return links

    def _options_from_block(self, block, seen):
        links = []
        for m in re.finditer(r'<option([^>]*)>(.*?)</option>', block or '', re.S|re.I):
            attrs, label_html = m.group(1), m.group(2)
            vm = re.search(r'value=["\']([^"\']+)["\']', attrs, re.I)
            if not vm:
                continue
            url, label = vm.group(1).strip(), self._strip_html(label_html)
            if not url or url in seen:
                continue
            if url.startswith('http') and 'megakino' not in url:
                seen.add(url)
                links.append({'url': url, 'quality': self._quality(label+url), 'info': f'DE | {label or "Hoster"}'})
                fflog(f'[megakino]   link: {label} {url[:60]}', 1)
            else:
                # Relative/internal Megakino value -> resolve one hop to external hosters.
                for it in self._resolve_internal_value(url):
                    if it.get('url') not in seen:
                        seen.add(it.get('url'))
                        links.append(it)
        return links

    def _quality(self, t):
        t = t.lower()
        if '4k' in t or '2160' in t: return '4K'
        if '1080' in t: return '1080p'
        if '720' in t:  return '720p'
        return 'HD'

    def _init_session(self):
        if not self.session:
            # Do not pre-warm MegaKino with three network calls. On a slow or
            # rotated domain that consumed almost the whole provider timeout
            # before the actual search even started. The current DLE site can
            # establish cookies on the search request itself; yg_token is
            # refreshed lazily only when the site explicitly asks for it.
            import requests
            import urllib3
            urllib3.disable_warnings()
            self.session = requests.Session()
            self.session.verify = False
            self.session.headers.update(self.headers)

    def _refresh_yg_token(self, referer=''):
        try:
            headers = dict(self.headers)
            headers['Accept'] = '*/*'
            headers['Referer'] = referer or (self.base_link + '/')
            headers['X-Requested-With'] = 'XMLHttpRequest'
            started = time.monotonic()
            response = self.session.get(
                self.base_link + '/index.php?yg=token',
                headers=headers, timeout=(2, 3), allow_redirects=True,
            )
            self._adopt_response_base(getattr(response, 'url', ''))
            ok = response.status_code < 400
            if ok:
                self._yg_token_primed = True
            _diag('token', f'status={response.status_code}; elapsed={time.monotonic() - started:.2f}s')
            return ok
        except Exception:
            _diag('token', 'result=transport-error')
            return False
