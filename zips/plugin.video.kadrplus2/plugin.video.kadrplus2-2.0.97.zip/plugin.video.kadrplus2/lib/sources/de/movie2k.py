# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""Movie2k provider for Kadr+ 2.0, implemented against its public JSON catalogue."""

from lib.sources.de._kadr_json_catalog import JsonCatalogSource


class source(JsonCatalogSource):
    provider_name = "movie2k"
    base_urls = ("https://movie2k.ch",)
    ref_prefix = "kadr-movie2k:"
    search_params = ("keyword",)
    search_path_template = "/data/browse/?lang=2&keyword={query}&page=1&limit=0"
    max_query_transport_failures = 2
    request_headers = {
        "Origin": "https://movie2k.ch/",
        "Referer": "https://movie2k.ch/",
    }
