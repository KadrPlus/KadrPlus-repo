# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""Shared, project-local helpers for Kadr+ German providers.

This support module contains only generic plumbing written for Kadr+:
conservative title matching, short opaque refs, verified site requests with
redirect validation, and conversion to Kadr source rows.  Its inert register()
hook tells Kadr+'s source scanner that this module exports no provider.
"""

from __future__ import annotations

import ast
import base64
import json
import re
import threading
import unicodedata
from difflib import SequenceMatcher
from html import unescape
from urllib.parse import quote, urljoin, urlsplit, urlunsplit

from lib.ff import requests, source_utils



def register(sources, group=""):
    """Mark this support module as intentionally provider-less."""
    return None


_YEAR_RE = re.compile(r"(?<!\d)((?:19|20)\d{2})(?!\d)")
_EP_RE = re.compile(r"\bS0*(\d{1,2})\s*E0*(\d{1,3})\b", re.I)
_DIRECT_EXTENSIONS = (".m3u8", ".mpd", ".mp4", ".webm", ".ts", ".m4v")
_HOP_HEADERS = {
    "connection", "proxy-connection", "keep-alive", "proxy-authenticate",
    "proxy-authorization", "te", "trailers", "transfer-encoding", "upgrade",
}


def diag(provider, stage, message=""):
    """Privacy-safe diagnostics; no detailed provider trace unless enabled."""
    try:
        from lib.ff import diagnostics
        if diagnostics.enabled():
            diagnostics.log_event(
                str(provider or "provider"),
                ("stage=%s; %s" % (stage, message)).rstrip("; "),
            )
    except Exception:
        pass


def year_of(value):
    m = _YEAR_RE.search(str(value or ""))
    return m.group(1) if m else ""


def clean_text(value):
    value = unescape(str(value or ""))
    value = re.sub(r"<[^>]+>", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def normalize_title(value):
    value = clean_text(value).replace("ß", "ss")
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    value = value.lower().replace("’", "").replace("'", "")
    # Site labels frequently append presentation markers that are not part of
    # the actual title.  Remove only explicit, bounded markers.
    value = re.sub(r"\s*[\[(](?:ger(?:man)?\s*)?(?:dub|sub)[\])]\s*$", " ", value, flags=re.I)
    value = re.sub(r"\s*[-–—|]\s*(?:ger(?:man)?\s*)?(?:dub|sub)\s*$", " ", value, flags=re.I)
    # DLE/catalogue cards often render a season suffix with an en dash, but
    # ASCII folding above removes that dash.  Make the separator optional so
    # both "Reacher - Staffel 4" and "Reacher Staffel 4" normalize to the show
    # title without weakening the numeric season boundary.
    value = re.sub(r"\s*(?:[-|]\s*)?(?:staffel|season)\s*\d+\b.*$", " ", value, flags=re.I)
    value = re.sub(r"\s+(?:stream|online\s+stream|der\s+film)\s*$", " ", value, flags=re.I)
    value = re.sub(r"\s*\((?:19|20)\d{2}\)\s*$", " ", value)
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def compact_title(value):
    return normalize_title(value).replace(" ", "")


def title_score(candidate, wanted):
    """Conservative similarity: no automatic high score for mere substring."""
    left = normalize_title(candidate)
    right = normalize_title(wanted)
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0
    # Combine ordered character similarity and token coverage.  Short/generic
    # fragments cannot pass merely because they occur inside a longer title.
    seq = SequenceMatcher(None, left, right).ratio()
    lt, rt = set(left.split()), set(right.split())
    union = lt | rt
    jac = (len(lt & rt) / float(len(union))) if union else 0.0
    coverage = min(len(left), len(right)) / float(max(len(left), len(right)))
    score = (0.58 * seq) + (0.32 * jac) + (0.10 * coverage)
    compact_seq = SequenceMatcher(None, left.replace(" ", ""), right.replace(" ", "")).ratio()
    if compact_seq >= 0.94 and coverage >= 0.85:
        score = max(score, compact_seq * 0.99)
    # Minor singular/plural/punctuation variations can still be close, but a
    # candidate missing a substantial prefix/subtitle should remain below the
    # acceptance threshold.
    return max(0.0, min(score, 0.999))


_DE_ALIAS_CACHE = {}
_DE_ALIAS_LOCK = threading.Lock()
_DE_ALIAS_CACHE_MAX = 128


def _ffitem_tmdb_id(ffitem, media_type):
    """Return the relevant TMDb id without assuming a concrete FFItem shape."""
    candidates = []
    try:
        if media_type == "show":
            show_item = getattr(ffitem, "show_item", None)
            if show_item:
                candidates.append(show_item)
    except Exception:
        pass
    if ffitem is not None:
        candidates.append(ffitem)
    for item in candidates:
        try:
            ref = getattr(item, "ref", None)
            value = int(getattr(ref, "tmdb_id", 0) or 0)
            if value > 0:
                return value
        except Exception:
            pass
        try:
            ids = getattr(item, "ids", None) or {}
            value = int(ids.get("tmdb") or 0)
            if value > 0:
                return value
        except Exception:
            pass
    return 0


def _existing_german_aliases(ffitem, media_type):
    out = []
    candidates = []
    try:
        if media_type == "show":
            show_item = getattr(ffitem, "show_item", None)
            if show_item:
                candidates.append(show_item)
    except Exception:
        pass
    if ffitem is not None:
        candidates.append(ffitem)
    for item in candidates:
        try:
            aliases = getattr(item, "aliases_info", ()) or ()
        except Exception:
            aliases = ()
        for alias in aliases:
            try:
                country = str(getattr(alias, "country", "") or "").lower()
                value = getattr(alias, "title", "")
            except Exception:
                if isinstance(alias, dict):
                    country = str(alias.get("country") or "").lower()
                    value = alias.get("title") or alias.get("name") or ""
                else:
                    continue
            if country in ("de", "deu", "germany"):
                value = clean_text(value)
                if value:
                    out.append(value)
    return out


def _fetch_german_tmdb_aliases(media_type, tmdb_id):
    """Fetch TMDb's German primary title + DE/AT/CH alternative titles.

    Kadr's ordinary alias list follows the UI locale (normally PL) plus EN, so
    it can legitimately omit the title a German catalogue actually indexes.
    One bounded TMDb detail request in ``de-DE`` with ``alternative_titles``
    appended gives us both the translated German title and the regional alias
    set.  Results are cached across all DE provider threads.
    """
    if media_type not in ("movie", "show") or not tmdb_id:
        return []
    key = (media_type, int(tmdb_id))
    with _DE_ALIAS_LOCK:
        if key in _DE_ALIAS_CACHE:
            return list(_DE_ALIAS_CACHE[key])
        values = []
        try:
            from lib.ff.info import ffinfo
            ctype = "movie" if media_type == "movie" else "tv"
            data = ffinfo.tmdb.get(
                "%s/%s" % (ctype, int(tmdb_id)),
                lang="de-DE",
                append_to_response=("alternative_titles",),
                request_timeout=2.0,
                attempts=1,
            ) or {}
            ranked = []
            if isinstance(data, dict):
                primary = clean_text(data.get("title") or data.get("name"))
                if primary:
                    ranked.append((0, primary))
                alt = data.get("alternative_titles") or {}
                if isinstance(alt, dict):
                    rows = alt.get("results", alt.get("titles", ())) or ()
                else:
                    rows = ()
                for row in rows:
                    if not isinstance(row, dict):
                        continue
                    country = str(row.get("iso_3166_1") or row.get("country") or "").upper()
                    if country not in ("DE", "AT", "CH"):
                        continue
                    title = clean_text(row.get("title") or row.get("name"))
                    if title:
                        ranked.append((1 if country == "DE" else 2, title))
            # Compatibility fallback if a TMDb client/proxy omits appended data.
            if not ranked:
                rows = ffinfo.tmdb.aliases(
                    media_type, int(tmdb_id), request_timeout=2.0, attempts=1,
                ) or ()
                for row in rows:
                    if not isinstance(row, dict):
                        continue
                    country = str(row.get("iso_3166_1") or row.get("country") or "").upper()
                    if country not in ("DE", "AT", "CH"):
                        continue
                    title = clean_text(row.get("title") or row.get("name"))
                    if title:
                        ranked.append((1 if country == "DE" else 2, title))
            seen = set()
            for _, title in sorted(ranked, key=lambda it: it[0]):
                norm = normalize_title(title)
                if norm and norm not in seen:
                    seen.add(norm)
                    values.append(title)
        except Exception:
            values = []
        if len(_DE_ALIAS_CACHE) >= _DE_ALIAS_CACHE_MAX:
            try:
                _DE_ALIAS_CACHE.pop(next(iter(_DE_ALIAS_CACHE)))
            except Exception:
                _DE_ALIAS_CACHE.clear()
        _DE_ALIAS_CACHE[key] = tuple(values[:6])
        return list(_DE_ALIAS_CACHE[key])


def german_fallback_titles(wanted, ffitem=None, media_type="movie", limit=4):
    """Return only *new* German aliases for a second-chance search.

    Callers invoke this only after the normal German/original search produced no
    decisive match.  Returning only aliases not already tried avoids repeating
    the same site queries after the TMDb fallback.
    """
    tried = {normalize_title(x) for x in (wanted or ()) if normalize_title(x)}
    german = _existing_german_aliases(ffitem, media_type)
    if not german:
        german = _fetch_german_tmdb_aliases(media_type, _ffitem_tmdb_id(ffitem, media_type))
    out, seen = [], set(tried)
    for value in german:
        value = clean_text(value)
        key = normalize_title(value)
        if value and key and key not in seen:
            seen.add(key)
            out.append(value)
        if len(out) >= max(1, int(limit or 1)):
            break
    return out


_GERMAN_TITLE_COUNTRIES = frozenset((
    "de", "deu", "germany", "at", "aut", "austria",
    "ch", "che", "switzerland",
))
_ORIGINAL_TITLE_COUNTRIES = frozenset(("original", "orig"))


def _ffitem_original_title(ffitem, media_type="movie"):
    candidates = []
    try:
        if media_type == "show":
            show_item = getattr(ffitem, "show_item", None)
            if show_item:
                candidates.append(show_item)
    except Exception:
        pass
    if ffitem is not None:
        candidates.append(ffitem)
    for item in candidates:
        try:
            vtag = getattr(item, "vtag", None)
            if vtag is not None:
                value = clean_text(vtag.getOriginalTitle())
                if value:
                    return value
        except Exception:
            pass
    return ""


def titles_from(localtitle, title, aliases, limit=6, *, ffitem=None, media_type="movie"):
    """Build the DE-provider query pool: German-region titles, then original.

    ``localtitle`` is the UI/API-locale title (normally Polish) and is never
    trusted on its own.  It may re-enter only when the same normalized value is
    independently confirmed as a German/AT/CH alias.  This preserves legitimate
    overlaps such as a title that happens to be identical in Polish and German
    without sending Polish-only names to German providers.

    The ordinary ``aliases`` list is often populated only for the UI locale +
    English, so DE aliases can be absent even though TMDb knows them.  When an
    FFItem/TMDb id is available we therefore merge Kadr+'s cached DE/AT/CH TMDb
    aliases *before* the first site query.  The fetch is shared/cached across
    provider threads and bounded by the existing 2 s / 1-attempt transport.

    Untagged or unrelated-country aliases are not blindly searched.  They are
    accepted only when their normalized value is corroborated by the known
    German-region set.  One slot is reserved for the explicit/original title so
    a long alias list cannot crowd it out.
    """
    max_items = max(1, int(limit or 1))
    seen = set()
    german = []

    def add(bucket, value):
        value = clean_text(value)
        key = normalize_title(value)
        if value and key and key not in seen:
            seen.add(key)
            bucket.append(value)
            return key
        return ""

    if isinstance(aliases, dict):
        alias_values = list(aliases.values())
    else:
        alias_values = list(aliases or ())

    # 1) Explicitly tagged German-region aliases already present in FFItem.
    known_german = []
    for alias in alias_values:
        if not isinstance(alias, dict):
            continue
        country = str(alias.get("country") or "").strip().lower()
        if country in _GERMAN_TITLE_COUNTRIES:
            value = alias.get("title") or alias.get("originalname") or alias.get("name")
            value = clean_text(value)
            if value:
                known_german.append(value)

    # 2) Merge German aliases known by the FFItem and TMDb.  This is important
    # because the normal Kadr alias locale is usually PL+EN and may omit DE.
    if ffitem is not None:
        for value in _existing_german_aliases(ffitem, media_type):
            if clean_text(value):
                known_german.append(value)
        tmdb_id = _ffitem_tmdb_id(ffitem, media_type)
        if tmdb_id:
            for value in _fetch_german_tmdb_aliases(media_type, tmdb_id):
                if clean_text(value):
                    known_german.append(value)

    # Preserve order but dedupe the independently confirmed DE set.
    confirmed_de_keys = set()
    confirmed_de_values = []
    for value in known_german:
        key = normalize_title(value)
        if value and key and key not in confirmed_de_keys:
            confirmed_de_keys.add(key)
            confirmed_de_values.append(value)

    for value in confirmed_de_values:
        add(german, value)

    # If localtitle happens to be the same title in German, keep it.  The
    # corroboration rule prevents a Polish-only localtitle from leaking in.
    local_key = normalize_title(localtitle)
    if local_key and local_key in confirmed_de_keys:
        add(german, localtitle)

    # Keep malformed/untagged aliases only when TMDb/FFItem independently says
    # the same lexical title is German.  This recovers useful aliases without
    # reopening the broad PL/other-language fan-out that caused regressions.
    for alias in alias_values:
        if isinstance(alias, dict):
            value = alias.get("title") or alias.get("originalname") or alias.get("name")
        else:
            value = alias
        key = normalize_title(value)
        if key and key in confirmed_de_keys:
            add(german, value)

    # Original title: prefer the explicit source-pipeline marker, then the
    # FFItem's original title, and only then the generic ``title`` fallback.
    original = ""
    for alias in alias_values:
        if not isinstance(alias, dict):
            continue
        country = str(alias.get("country") or "").strip().lower()
        if country in _ORIGINAL_TITLE_COUNTRIES:
            original = clean_text(
                alias.get("originalname") or alias.get("original_title")
                or alias.get("title") or alias.get("name")
            )
            if original:
                break
    if not original:
        original = _ffitem_original_title(ffitem, media_type)
    if not original:
        original = clean_text(title)

    original_key = normalize_title(original)
    original_is_new = bool(original and original_key and original_key not in seen)
    if original_is_new:
        if max_items == 1:
            return [german[0] if german else original]
        out = german[: max_items - 1]
        out.append(original)
        return out
    return german[:max_items]


def choose_candidate(items, wanted_titles, wanted_year="", *, min_score=0.92, year_required_when_present=True,
                     season=0):
    """Return the best item only if title and available metadata are decisive."""
    wanted_year = year_of(wanted_year)
    best = None
    best_score = -1.0
    for item in items or ():
        if not isinstance(item, dict):
            continue
        candidate = clean_text(item.get("title") or item.get("name"))
        if not candidate:
            continue
        score = max((title_score(candidate, wanted) for wanted in wanted_titles or ()), default=0.0)
        if score < min_score:
            continue
        item_year = year_of(item.get("year") or item.get("date") or item.get("release"))
        if wanted_year and item_year:
            if item_year != wanted_year:
                continue
            score += 0.08
        elif wanted_year and year_required_when_present and item.get("year_mismatch"):
            continue
        if season:
            try:
                cand_season = int(item.get("season") or 0)
            except Exception:
                cand_season = 0
            if cand_season and cand_season != int(season):
                continue
            if cand_season == int(season):
                score += 0.05
        if score > best_score:
            best_score, best = score, item
    return best


def choose_series_candidate(items, wanted_titles, wanted_year="", *, season=0, min_score=0.93):
    """Choose a series result without confusing show year with season year.

    First use normal strict title/year/season matching.  Some catalogues label a
    Staffel page with that season's release year rather than the show's premiere
    year.  If strict matching finds nothing, allow a year-mismatching candidate
    only when there is exactly one very strong title+season candidate.  Multiple
    plausible remakes remain unresolved instead of being guessed.
    """
    strict = choose_candidate(items, wanted_titles, wanted_year, min_score=min_score, season=season)
    if strict:
        return strict
    candidates = []
    for item in items or ():
        if not isinstance(item, dict):
            continue
        title = item.get("title") or item.get("name") or ""
        score = max((title_score(title, wanted) for wanted in wanted_titles or ()), default=0.0)
        if score < max(0.96, min_score):
            continue
        try:
            cand_season = int(item.get("season") or 0)
        except Exception:
            cand_season = 0
        if season and cand_season not in (0, int(season)):
            continue
        candidates.append(item)
    if len(candidates) == 1:
        return candidates[0]
    return None


def quality_from(value, default="HD"):
    raw = str(value or "").upper()
    if re.search(r"(?:2160|\b4K\b|\bUHD\b)", raw):
        return "4K"
    if "1440" in raw:
        return "1440p"
    if re.search(r"(?:1080|\bFHD\b|\bHD\+\b)", raw):
        return "1080p"
    if re.search(r"(?:720|\bHD\b)", raw):
        return "720p"
    if "480" in raw:
        return "480p"
    if re.search(r"\b(?:CAM|TELESYNC|TS)\b", raw):
        return "CAM"
    return default


def host_label(url, fallback="Hoster"):
    host = (urlsplit(str(url or "")).hostname or "").lower().lstrip("www.")
    return host.split(".", 1)[0].replace("-", " ").title() if host else fallback


def is_direct_media(url):
    path = (urlsplit(str(url or "")).path or "").lower()
    return path.endswith(_DIRECT_EXTENSIONS)


def resolveurl_recognizes(url):
    try:
        import resolveurl
        item = resolveurl.HostedMediaFile(url=url, include_disabled=True, include_universal=False)
        return bool(item and item.valid_url())
    except Exception:
        return False


def source_row(url, host_dict, premium_dict, *, name="", quality="HD", language="de", info=""):
    """Convert an external host URL to Kadr's provider dictionary conservatively."""
    url = unescape(str(url or "")).strip()
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https") or not parts.hostname:
        return None
    if "youtube." in parts.hostname.lower() or parts.hostname.lower() == "youtu.be":
        return None
    direct = is_direct_media(url)
    valid, host = source_utils.is_host_valid(url, host_dict)
    if not valid:
        valid, host = source_utils.is_host_valid(url, premium_dict)
    if not valid and not direct and not resolveurl_recognizes(url):
        return None
    host = host if valid else (name or host_label(url))
    return {
        "source": host or name or host_label(url),
        "quality": quality or "HD",
        "language": language or "de",
        "url": url,
        "info": clean_text(info),
        "direct": bool(direct),
        "debridonly": False,
    }


def dedup_source_rows(rows):
    out, seen = [], set()
    for row in rows or ():
        if not row:
            continue
        key = (str(row.get("url") or "").split("|", 1)[0], row.get("language"), row.get("quality"))
        if key in seen:
            continue
        seen.add(key)
        out.append(row)
    return out


def encode_ref(prefix, data):
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return prefix + base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def decode_ref(prefix, value):
    value = str(value or "")
    if not value.startswith(prefix):
        return None
    try:
        token = value[len(prefix):]
        token += "=" * (-len(token) % 4)
        data = json.loads(base64.urlsafe_b64decode(token.encode("ascii")).decode("utf-8"))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def safe_literal_matrix(raw):
    """Parse a bounded Python/JS-like nested string list without eval()."""
    raw = str(raw or "").strip()
    if len(raw) > 512 * 1024:
        return None
    try:
        value = ast.literal_eval(raw)
    except Exception:
        return None
    if not isinstance(value, (list, tuple)):
        return None
    return value


def extract_season_episode(label):
    m = _EP_RE.search(clean_text(label))
    return (int(m.group(1)), int(m.group(2))) if m else (0, 0)


def strip_comments(html):
    return re.sub(r"<!--.*?-->", "", str(html or ""), flags=re.S)


def html_attr(tag, name):
    m = re.search(r"\b%s\s*=\s*([\"'])(.*?)\1" % re.escape(name), str(tag or ""), re.I | re.S)
    return unescape(m.group(2).strip()) if m else ""


def absolute_http(value, base):
    value = unescape(str(value or "")).strip()
    if not value or value.startswith(("javascript:", "data:", "file:", "plugin:")):
        return ""
    result = urljoin(str(base or "").rstrip("/") + "/", value)
    p = urlsplit(result)
    if p.scheme not in ("http", "https") or not p.hostname:
        return ""
    return result


def sanitize_outbound_headers(headers):
    result = {}
    for key, value in (headers or {}).items():
        lk = str(key).lower()
        if lk in _HOP_HEADERS or lk in ("host", "content-length"):
            continue
        result[str(key)] = str(value)
    return result


class SiteClient:
    """HTTPS-only site client with known-host redirect/fallback validation."""

    def __init__(self, provider, bases, *, timeout=(6, 12), headers=None, max_redirects=3):
        self.provider = str(provider)
        normalized = []
        for base in bases:
            p = urlsplit(str(base or "").strip())
            if p.scheme != "https" or not p.hostname:
                continue
            value = urlunsplit(("https", p.netloc, "", "", "")).rstrip("/")
            if value not in normalized:
                normalized.append(value)
        if not normalized:
            raise ValueError("SiteClient needs at least one HTTPS base")
        self.bases = tuple(normalized)
        self.allowed_hosts = frozenset((urlsplit(x).hostname or "").lower().rstrip(".") for x in self.bases)
        self.base = self.bases[0]
        self.timeout = timeout
        self.max_redirects = max(0, int(max_redirects))
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
            ),
            "Accept-Language": "de-DE,de;q=0.9,en;q=0.5",
        })
        if headers:
            self.session.headers.update(sanitize_outbound_headers(headers))

    def allowed_url(self, url):
        p = urlsplit(str(url or ""))
        try:
            port = p.port
        except ValueError:
            return False
        return (
            p.scheme == "https"
            and bool(p.hostname)
            and not p.username and not p.password
            and (port in (None, 443))
            and p.hostname.lower().rstrip(".") in self.allowed_hosts
        )

    def _candidate_urls(self, value):
        value = str(value or "").strip()
        if value.startswith("http://"):
            return []
        if value.startswith("https://"):
            p = urlsplit(value)
            if not self.allowed_url(value):
                return []
            path_q = urlunsplit(("", "", p.path or "/", p.query, p.fragment))
            result = [value]
            for base in (self.base,) + self.bases:
                alt = urljoin(base + "/", path_q.lstrip("/"))
                if alt not in result:
                    result.append(alt)
            return result
        path = value if value.startswith("/") else "/" + value
        result = []
        for base in (self.base,) + self.bases:
            url = urljoin(base + "/", path.lstrip("/"))
            if url not in result:
                result.append(url)
        return result

    def request(self, method, value, *, data=None, json_data=None, params=None, headers=None, referer=None,
                accept_status=(200,), max_bytes=4 * 1024 * 1024):
        method = str(method or "GET").upper()
        if method not in ("GET", "POST"):
            return None
        last_error = ""
        for start in self._candidate_urls(value):
            url = start
            current_method = method
            current_data = data
            current_json = json_data
            for redirect_no in range(self.max_redirects + 1):
                if not self.allowed_url(url):
                    diag(self.provider, "redirect-reject", "foreign/insecure target")
                    break
                req_headers = sanitize_outbound_headers(headers)
                if referer:
                    ref = absolute_http(referer, self.base)
                    if ref and self.allowed_url(ref):
                        req_headers["Referer"] = ref
                try:
                    response = self.session.request(
                        current_method,
                        url,
                        params=params if redirect_no == 0 else None,
                        data=current_data,
                        json=current_json,
                        headers=req_headers or None,
                        timeout=self.timeout,
                        allow_redirects=False,
                    )
                except Exception as exc:
                    last_error = type(exc).__name__
                    break
                if response.status_code in (301, 302, 303, 307, 308):
                    location = response.headers.get("Location") or ""
                    target = urljoin(url, location)
                    if not self.allowed_url(target):
                        diag(self.provider, "redirect-reject", "foreign/insecure target")
                        break
                    url = target
                    if response.status_code == 303 or (response.status_code in (301, 302) and current_method == "POST"):
                        current_method, current_data, current_json = "GET", None, None
                    continue
                if response.status_code not in tuple(accept_status or (200,)):
                    last_error = "http-%d" % int(response.status_code)
                    break
                try:
                    content = response.content
                except Exception:
                    content = b""
                if max_bytes and len(content) > int(max_bytes):
                    last_error = "body-too-large"
                    break
                final_url = str(getattr(response, "url", url) or url)
                if not self.allowed_url(final_url):
                    last_error = "final-url-rejected"
                    break
                p = urlsplit(final_url)
                self.base = urlunsplit(("https", p.netloc, "", "", "")).rstrip("/")
                return response
        if last_error:
            diag(self.provider, "request-fail", last_error)
        return None

    def get_text(self, value, **kwargs):
        response = self.request("GET", value, **kwargs)
        return str(getattr(response, "text", "") or "") if response is not None else ""

    def post_text(self, value, **kwargs):
        response = self.request("POST", value, **kwargs)
        return str(getattr(response, "text", "") or "") if response is not None else ""

    def get_json(self, value, **kwargs):
        response = self.request("GET", value, **kwargs)
        if response is None:
            return None
        try:
            data = response.json()
        except Exception:
            try:
                data = json.loads(response.text)
            except Exception:
                return None
        return data


class TrustedHttpsClient:
    """Fetch only a small exact set of secondary HTTPS player hosts."""

    def __init__(self, provider, hosts, *, timeout=(6, 12), max_redirects=2):
        self.provider = str(provider)
        self.hosts = frozenset(str(x).lower().rstrip(".") for x in hosts if x)
        self.timeout = timeout
        self.max_redirects = max_redirects
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
            ),
            "Accept-Language": "de-DE,de;q=0.9,en;q=0.5",
        })

    def allowed_url(self, url):
        p = urlsplit(str(url or ""))
        try:
            port = p.port
        except ValueError:
            return False
        return (
            p.scheme == "https" and bool(p.hostname) and not p.username and not p.password
            and port in (None, 443) and p.hostname.lower().rstrip(".") in self.hosts
        )

    def get_text(self, url, *, referer="", max_bytes=4 * 1024 * 1024):
        if not self.allowed_url(url):
            return ""
        current = str(url)
        for _ in range(self.max_redirects + 1):
            headers = {}
            if referer and urlsplit(referer).scheme == "https":
                headers["Referer"] = referer
            try:
                r = self.session.get(current, headers=headers or None, timeout=self.timeout, allow_redirects=False)
            except Exception:
                return ""
            if r.status_code in (301, 302, 303, 307, 308):
                target = urljoin(current, r.headers.get("Location") or "")
                if not self.allowed_url(target):
                    return ""
                current = target
                continue
            if r.status_code != 200:
                return ""
            try:
                content = r.content
            except Exception:
                content = b""
            if max_bytes and len(content) > int(max_bytes):
                return ""
            return str(r.text or "")
        return ""


def _decode_player_link(value, base=""):
    """Normalize a player URL or a bounded base64-encoded absolute URL.

    MeineCloud/DEVIDEOSRC currently stores some ``data-link`` values as
    base64.  Decode data only (never code), accept only http(s)/protocol-relative
    URLs, and keep the existing URL validation path for everything else.
    """
    value = unescape(str(value or "")).strip()
    if not value:
        return ""
    if value.startswith(("http://", "https://", "//", "/")):
        return absolute_http(value, base)
    if len(value) > 8192 or not re.match(r"^[A-Za-z0-9_+/=-]+$", value):
        return absolute_http(value, base)
    token = value.encode("ascii", "ignore")
    token += b"=" * (-len(token) % 4)
    decoded = ""
    for decoder in (base64.b64decode, base64.urlsafe_b64decode):
        try:
            raw = decoder(token)
            if len(raw) > 8192:
                continue
            candidate = raw.decode("utf-8", "strict").strip()
            if candidate.startswith(("http://", "https://", "//")):
                decoded = candidate
                break
        except Exception:
            continue
    return absolute_http(decoded, base) if decoded else absolute_http(value, base)


def extract_data_links(html, *, base="", skip_hosts=(), info=""):
    """Extract external data-link hosters without requesting them."""
    out, seen = [], set()
    for raw in re.findall(r"\bdata-link\s*=\s*([\"'])(.*?)\1", str(html or ""), re.I | re.S):
        value = raw[1]
        url = _decode_player_link(value, base)
        p = urlsplit(url)
        if not url or not p.hostname:
            continue
        host = p.hostname.lower()
        if any(host == x or host.endswith("." + x) for x in skip_hosts):
            continue
        if url in seen:
            continue
        seen.add(url)
        out.append({"url": url, "name": host_label(url), "quality": quality_from(info), "info": info})
    return out


def extract_iframes(html, base=""):
    out, seen = [], set()
    for tag in re.findall(r"<iframe\b[^>]*>", strip_comments(html), re.I | re.S):
        raw = html_attr(tag, "src") or html_attr(tag, "data-src")
        url = absolute_http(raw, base)
        if url and url not in seen:
            seen.add(url)
            out.append(url)
    return out


def meinecloud_episode_links(html, season, episode):
    """Extract exact S/E data-link rows from common MeineCloud serial markup."""
    out, seen = [], set()
    for tag in re.findall(r"<div\b[^>]*class\s*=\s*([\"'])[^\"']*\b_ep\b[^\"']*\1[^>]*>", str(html or ""), re.I):
        # This regex variant cannot retain the full tag because of backrefs;
        # fallback loop below does the actual extraction.
        pass
    for tag in re.findall(r"<div\b[^>]*class\s*=\s*[\"'][^\"']*\b_ep\b[^\"']*[\"'][^>]*>", str(html or ""), re.I):
        label = html_attr(tag, "data-label")
        s, e = extract_season_episode(label)
        if s != int(season) or e != int(episode):
            continue
        url = _decode_player_link(html_attr(tag, "data-link"), "https://meinecloud.click/")
        if url and url not in seen:
            seen.add(url)
            out.append({"url": url, "name": host_label(url), "quality": quality_from(label), "info": label})
    return out


def js_matrix_streams(html, season, episode, *, base=""):
    """Read DLE player matrices and select exactly one requested S/E cell."""
    out, seen = [], set()
    season_i = max(1, int(season or 1)) - 1
    episode_i = max(1, int(episode or 1)) - 1
    matrices = re.findall(r"\.show\([^,]+,(\[\[.*?\]\])", str(html or ""), re.S)
    qualities = re.findall(r"title\s*=\s*[\"']Stream\.([^\"']+)", str(html or ""), re.I)
    for idx, raw in enumerate(matrices):
        value = safe_literal_matrix(raw)
        try:
            cell = value[season_i][episode_i]
        except Exception:
            continue
        url = absolute_http(cell, base)
        if not url or url in seen:
            continue
        seen.add(url)
        label = qualities[idx] if idx < len(qualities) else ""
        out.append({"url": url, "name": host_label(url), "quality": quality_from(label), "info": label})
    return out
