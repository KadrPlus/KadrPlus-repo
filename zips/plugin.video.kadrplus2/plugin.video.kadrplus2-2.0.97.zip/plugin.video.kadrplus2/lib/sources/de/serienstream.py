# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""SerienStream source adapter for Kadr+ 2.0.

SerienStream is a TV-series catalogue available through several equivalent
front doors.  Kadr+ searches the site's public series-search endpoint, builds
the requested season/episode URL and keeps every language/hoster combination
as a separate source.  Redirect tokens are deliberately not cached: the
provider page is fetched again at playback time and the selected variant is
resolved with a fresh session.

The raw-IP mirror is HTTP-only.  Kadr+ uses it only for public catalogue/page
requests and never transmits credentials through it.
"""

from __future__ import annotations

import base64
import json
import re
import time
import unicodedata
from difflib import SequenceMatcher
from html import unescape
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit

from lib.ff import requests
from lib.ff.settings import settings
from lib.ff.log_utils import fflog, fflog_exc
from lib.sources.de._kadr_de_common import titles_from as _de_titles_from


_BASE_URLS = (
    "https://serienstream.to",
    "http://186.2.175.5",
    "https://serienstream.cx",
)
_BASE_HOSTS = frozenset((urlsplit(value).hostname or "").lower() for value in _BASE_URLS)
_REF_PREFIX = "kadr-serienstream:"
_YEAR_RE = re.compile(r"(?<!\d)((?:19|20)\d{2})(?!\d)")
_SERIES_PATH_RE = re.compile(r"^/serie/(?:stream/)?[^/?#]+/?$", re.IGNORECASE)
_EPISODE_PATH_RE = re.compile(
    r"^/serie/(?:stream/)?[^/?#]+/staffel-(\d+)/episode-(\d+)/?$",
    re.IGNORECASE,
)
_REDIRECT_PATH_RE = re.compile(r"^/(?:redirect/\d+|r(?:\?|$))", re.IGNORECASE)
_DIRECT_EXT_RE = re.compile(r"\.(?:m3u8|mpd|mp4|webm|ts)(?:$|[?#])", re.IGNORECASE)


def _diag(stage, message=""):
    try:
        from lib.ff import diagnostics
        if not diagnostics.enabled():
            return
        diagnostics.log_event(
            "serienstream", ("stage=%s; %s" % (stage, message)).rstrip("; ")
        )
    except Exception:
        pass


def _attrs(values):
    return {str(key).lower(): (value or "") for key, value in values}


def _normalize_title(value):
    value = str(value or "").replace("ß", "ss")
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    value = re.sub(r"[^a-z0-9]+", " ", value.lower())
    return re.sub(r"\s+", " ", value).strip()


def _title_score(candidate, wanted):
    """Return a conservative title similarity score.

    SerienStream's search endpoint can return broad suggestions.  A short
    fragment such as ``High School`` must not be accepted for a longer title
    such as ``ONE: High School Heroes`` just because it is a substring.
    Standalone years are ignored here because year matching is handled
    separately by ``tvshow()``.
    """
    left = _normalize_title(candidate)
    right = _normalize_title(wanted)
    if not left or not right:
        return 0.0

    def without_years(value):
        return " ".join(
            token for token in value.split()
            if not re.fullmatch(r"(?:19|20)\d{2}", token)
        ).strip()

    left = without_years(left)
    right = without_years(right)
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0

    # Punctuation can split the same lexical title differently (Grey's/Greys,
    # S.H.I.E.L.D./SHIELD).  If removing separators makes both forms exactly
    # equal, treat them as the same title instead of penalising punctuation.
    if left.replace(" ", "") == right.replace(" ", ""):
        return 1.0

    ratio = SequenceMatcher(None, left, right).ratio()
    if left in right or right in left:
        shorter = left.split() if len(left.split()) <= len(right.split()) else right.split()
        longer = right.split() if len(left.split()) <= len(right.split()) else left.split()
        coverage = float(len(shorter)) / float(max(1, len(longer)))
        # A partial substring may still be useful when it covers almost the
        # whole title, but generic halves/thirds are false-positive magnets.
        if coverage < 0.80:
            return min(ratio, 0.77)
    return ratio


def _broad_match_prefilter(candidate, wanted):
    """Cheap, permissive gate before expensive SequenceMatcher.

    This helper is deliberately broader than ``_title_score``: it may let a
    few false candidates through, but it must not throw away legitimate title
    variants.  The conservative matcher and year check remain the final
    authority.  This keeps the 10k+ catalogue fallback fast without trading
    away recall for punctuation, apostrophes or small spelling differences.
    """
    left = _normalize_title(candidate)
    right = _normalize_title(wanted)
    if not left or not right:
        return False

    def clean_tokens(value):
        return [
            token for token in value.split()
            if not re.fullmatch(r"(?:19|20)\d{2}", token)
        ]

    lt = clean_tokens(left)
    rt = clean_tokens(right)
    if not lt or not rt:
        return False
    if lt == rt:
        return True

    # Punctuation can split one lexical token into several pieces, e.g.
    # Grey's/Greys or S.H.I.E.L.D./SHIELD.  Compact equality is therefore a
    # very strong and cheap signal before token comparisons.
    compact_left = "".join(lt)
    compact_right = "".join(rt)
    if compact_left == compact_right:
        return True

    # Very short/single-token titles (24, CIA, Dark, etc.) need a small typo
    # allowance, but there is no reason to compare them with the whole index.
    if len(lt) == 1 or len(rt) == 1:
        a = compact_left
        b = compact_right
        if not a or not b or a[0] != b[0]:
            return False
        max_len = max(len(a), len(b))
        return abs(len(a) - len(b)) <= max(2, int(max_len * 0.35))

    left_set = set(lt)
    right_set = set(rt)
    common = left_set & right_set
    if common:
        # Ordinary title variants usually retain at least half of the words.
        longer = max(len(left_set), len(right_set))
        if float(len(common)) / float(max(1, longer)) >= 0.40:
            return True

        # One distinctive shared word is enough to justify the *real* matcher
        # when the title lengths are close.  False positives are harmless here
        # because _title_score() still has to pass afterwards.
        strong = any(len(token) >= 5 for token in common)
        if strong and abs(len(lt) - len(rt)) <= 2:
            return True

    # Final typo/punctuation safety net using character trigrams.  This is much
    # cheaper than SequenceMatcher and prevents the prefilter itself from
    # becoming a source of false negatives.
    def trigrams(value):
        value = " ".join(value.split())
        if len(value) < 3:
            return {value} if value else set()
        return {value[index:index + 3] for index in range(len(value) - 2)}

    length_ratio = float(min(len(compact_left), len(compact_right))) / float(
        max(1, max(len(compact_left), len(compact_right)))
    )
    if length_ratio < 0.55:
        return False
    left_tri = trigrams(compact_left)
    right_tri = trigrams(compact_right)
    union = left_tri | right_tri
    if not union:
        return False
    return float(len(left_tri & right_tri)) / float(len(union)) >= 0.28


def _unique_titles(localtitle, title, aliases, ffitem=None):
    return _de_titles_from(localtitle, title, aliases, limit=10, ffitem=ffitem, media_type="show")


def _year(value):
    match = _YEAR_RE.search(str(value or ""))
    return match.group(1) if match else ""


def _catalog_bucket(value):
    """Return the SerienStream alphabet bucket for a raw title."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    first = raw[0].upper()
    # The site groups punctuation, numbers *and* non A-Z initials (e.g. Ö)
    # together under 0-9/#.  Mirror that ordering exactly.
    return first if "A" <= first <= "Z" else "0-9"


def _title_sort_key(value):
    value = _normalize_title(value)
    return " ".join(
        token for token in value.split()
        if not re.fullmatch(r"(?:19|20)\d{2}", token)
    ).strip()


def _slugify_title(value):
    """Build a conservative SerienStream-style slug from a visible title."""
    value = str(value or "").strip()
    if not value:
        return ""
    # German slugs commonly spell umlauts as ae/oe/ue rather than dropping the
    # dots through generic ASCII normalisation.  Other accents still fall back
    # to NFKD transliteration.
    value = (
        value.replace("Ä", "Ae").replace("Ö", "Oe").replace("Ü", "Ue")
        .replace("ä", "ae").replace("ö", "oe").replace("ü", "ue")
        .replace("ß", "ss")
    )
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    value = re.sub(r"[^A-Za-z0-9]+", "-", value).strip("-").lower()
    return re.sub(r"-+", "-", value)


def _slug_candidates(value, wanted_year=""):
    """Return exact-path guesses only; fuzzy matching never happens here."""
    slug = _slugify_title(value)
    if not slug:
        return []
    result = []

    def add(candidate):
        candidate = str(candidate or "").strip("-")
        if candidate and candidate not in result:
            result.append(candidate)

    add(slug)
    year = _year(value) or _year(wanted_year)
    if year:
        without_year = re.sub(r"(?:^|-)" + re.escape(year) + r"(?:-|$)", "-", slug).strip("-")
        add(without_year)
        if without_year:
            add("%s-%s" % (without_year, year))
    return result


def _base_key(base):
    base = str(base or "").strip().rstrip("/")
    return base if base in _BASE_URLS else ""


def _series_path(value):
    """Return a safe canonical show path, accepting old and new site layouts."""
    value = unescape(str(value or "")).strip()
    if not value:
        return ""
    parsed = urlsplit(value)
    if parsed.scheme or parsed.netloc:
        if parsed.scheme not in ("http", "https") or (parsed.hostname or "").lower() not in _BASE_HOSTS:
            return ""
        path = parsed.path
    else:
        path = value.split("?", 1)[0].split("#", 1)[0]
    if not path.startswith("/"):
        path = "/" + path
    # A search result can occasionally already include season/episode suffixes.
    path = re.sub(r"/staffel-\d+(?:/episode-\d+)?/?$", "", path, flags=re.IGNORECASE)
    path = path.rstrip("/")
    return path if _SERIES_PATH_RE.match(path + "/") else ""


def _episode_path(show_path, season, episode):
    show_path = _series_path(show_path)
    if not show_path:
        return ""
    try:
        season = int(season)
        episode = int(episode)
    except (TypeError, ValueError):
        return ""
    if season < 0 or episode < 0:
        return ""
    # SerienStream uses season 0 for specials on some shows, so keep it valid.
    return "%s/staffel-%d/episode-%d" % (show_path, season, episode)


def _safe_episode_path(value):
    value = str(value or "").split("?", 1)[0].split("#", 1)[0]
    if not value.startswith("/"):
        value = "/" + value
    return value.rstrip("/") if _EPISODE_PATH_RE.match(value) else ""


def _encode_ref(kind, **values):
    data = {"kind": kind}
    data.update(values)
    raw = json.dumps(data, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return _REF_PREFIX + base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _decode_ref(value):
    value = str(value or "")
    if not value.startswith(_REF_PREFIX):
        return None
    try:
        token = value[len(_REF_PREFIX):]
        token += "=" * (-len(token) % 4)
        data = json.loads(base64.urlsafe_b64decode(token.encode("ascii")).decode("utf-8"))
        kind = str(data.get("kind") or "")
        base = _base_key(data.get("base"))
        if kind == "show":
            path = _series_path(data.get("path"))
            if not path:
                return None
            return {
                "kind": kind,
                "base": base,
                "path": path,
                "title": str(data.get("title") or "")[:180],
                "year": str(data.get("year") or "")[:8],
            }
        if kind == "episode":
            path = _safe_episode_path(data.get("path"))
            if not path:
                return None
            return {
                "kind": kind,
                "base": base,
                "path": path,
                "hoster": str(data.get("hoster") or "")[:80],
                "lang_key": str(data.get("lang_key") or "")[:12],
                "lang_label": str(data.get("lang_label") or "")[:100],
                "slot": max(0, int(data.get("slot") or 0)),
            }
    except Exception:
        return None
    return None


def _is_external_http(url):
    parsed = urlsplit(str(url or ""))
    return (
        parsed.scheme in ("http", "https")
        and bool(parsed.hostname)
        and (parsed.hostname or "").lower() not in _BASE_HOSTS
    )


def _relative_site_link(value):
    """Normalize only safe SerienStream redirect links; leave hosters external."""
    value = unescape(str(value or "")).strip()
    if not value:
        return ""
    if _is_external_http(value):
        return value
    parsed = urlsplit(value)
    if parsed.scheme or parsed.netloc:
        if parsed.scheme not in ("http", "https") or (parsed.hostname or "").lower() not in _BASE_HOSTS:
            return ""
        path_query = parsed.path + (("?" + parsed.query) if parsed.query else "")
    else:
        path_query = value
    if not path_query.startswith("/"):
        path_query = "/" + path_query
    return path_query if _REDIRECT_PATH_RE.match(path_query) else ""


def _quality(value):
    text = str(value or "").upper()
    if re.search(r"(?:2160|\b4K\b|\bUHD\b)", text):
        return "4K"
    if "1440" in text:
        return "1440p"
    if re.search(r"1080|\bFHD\b", text):
        return "1080p"
    if re.search(r"720|\bHD\b", text):
        return "720p"
    if re.search(r"\bCAM\b|TELESYNC|\bTS\b", text):
        return "CAM"
    return "HD"


def _display_metadata(value, quality):
    """Keep useful source details without duplicating the quality column."""
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    patterns = {
        "4K": r"(?i)(?<!\w)(?:2160p?|4k|uhd)(?!\w)",
        "1440p": r"(?i)(?<!\w)1440p?(?!\w)",
        "1080p": r"(?i)(?<!\w)(?:1080p?|fhd)(?!\w)",
        "720p": r"(?i)(?<!\w)720p?(?!\w)",
        "CAM": r"(?i)(?<!\w)(?:cam|telesync|ts)(?!\w)",
    }
    pattern = patterns.get(str(quality or ""))
    if pattern:
        text = re.sub(pattern, " ", text)
    text = re.sub(r"\s+", " ", text).strip(" -|/\t")
    return text


def _language_bucket(label="", key="", hint=""):
    raw = re.sub(r"\s+", " ", unescape(str(label or ""))).strip()
    hint = unescape(str(hint or ""))
    norm = _normalize_title("%s %s" % (raw, hint))

    aliases = (
        (("deutsch", "german", "deu"), "de", "Deutsch"),
        (("englisch", "english", "eng"), "en", "English"),
        (("polnisch", "polish", "polski"), "pl", "Polski"),
        (("franzosisch", "french", "francais"), "fr", "Français"),
        (("italienisch", "italian", "italiano"), "it", "Italiano"),
        (("spanisch", "spanish", "espanol"), "es", "Español"),
        (("portugiesisch", "portuguese", "portugues"), "pt", "Português"),
        (("koreanisch", "korean"), "ko", "Korean"),
        (("japanisch", "japanese"), "ja", "Japanese"),
        (("russisch", "russian"), "ru", "Russian"),
        (("turkisch", "turkish", "turkce"), "tr", "Türkçe"),
    )

    # Explicit subtitles are not an audio language.  If the asset name also
    # tells us the source audio (e.g. english-german.svg), preserve that.
    subtitles_de = any(token in norm for token in ("untertitel deutsch", "german sub", "ger sub", "germansub"))
    if subtitles_de:
        first = _normalize_title(hint).split(" ")
        if "english" in first or "englisch" in first:
            return "en", "English", "Napisy DE"
        if "japanese" in first or "japanisch" in first:
            return "ja", "Japanese", "Napisy DE"
        return "multi", raw or "Original", "Napisy DE"

    for names, bucket, display in aliases:
        if any(re.search(r"(?:^|\s)%s(?:$|\s)" % re.escape(name), norm) for name in names):
            return bucket, display, ""

    # Stable keys used by SerienStream's current UI.
    key = str(key or "").strip()
    if key == "1":
        return "de", "Deutsch", ""
    if key == "2":
        return "en", "English", ""
    if key == "3":
        return "multi", raw or "Original", "Napisy DE"
    return "multi", raw or "Unknown", ""


class _SearchHTMLParser(HTMLParser):
    """Fallback parser for /search results if the JSON endpoint is unavailable."""

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.items = []
        self._seen = set()
        self._anchor = None

    def handle_starttag(self, tag, attrs):
        if tag.lower() != "a":
            return
        data = _attrs(attrs)
        path = _series_path(data.get("href"))
        if not path:
            return
        self._anchor = {
            "path": path,
            "parts": [],
            "title": data.get("title", ""),
        }

    def handle_data(self, data):
        if self._anchor is not None:
            self._anchor["parts"].append(data)

    def handle_endtag(self, tag):
        if tag.lower() != "a" or self._anchor is None:
            return
        item = self._anchor
        self._anchor = None
        if item["path"] in self._seen:
            return
        title = re.sub(r"\s+", " ", item.get("title") or "").strip()
        if not title:
            title = re.sub(r"\s+", " ", " ".join(item["parts"])).strip()
        if not title:
            return
        self._seen.add(item["path"])
        self.items.append({"name": title, "link": item["path"]})


class _ShowPageParser(HTMLParser):
    """Read the canonical show identity from a SerienStream series page."""

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.title = ""
        self.year = ""
        self.imdb = ""
        self._in_h1 = False
        self._h1_parts = []
        self._after_h1 = False
        self._after_parts = []

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        data = _attrs(attrs)
        if tag == "h1" and not self.title:
            self._in_h1 = True
            self._h1_parts = []
        if tag == "a":
            href = str(data.get("href") or "")
            match = re.search(r"imdb\.com/title/(tt\d+)", href, re.IGNORECASE)
            if match and not self.imdb:
                self.imdb = match.group(1).lower()

    def handle_data(self, data):
        if self._in_h1:
            self._h1_parts.append(data)
        elif self._after_h1 and len(self._after_parts) < 30:
            self._after_parts.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == "h1" and self._in_h1:
            self._in_h1 = False
            self.title = re.sub(r"\s+", " ", " ".join(self._h1_parts)).strip()
            self._after_h1 = bool(self.title)

    def finish(self):
        if not self.year and self._after_parts:
            self.year = _year(" ".join(self._after_parts))
        return self


class _LoginFormParser(HTMLParser):
    """Extract the current login form without assuming a fixed CSRF field name."""

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.forms = []
        self._form = None

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        data = _attrs(attrs)
        if tag == "form":
            if self._form is None:
                self._form = {
                    "action": data.get("action", ""),
                    "method": data.get("method", "post").lower(),
                    "fields": {},
                    "email_name": "",
                    "password_name": "",
                }
            return
        if tag != "input" or self._form is None:
            return
        name = str(data.get("name") or "").strip()
        if not name:
            return
        input_type = str(data.get("type") or "text").strip().lower()
        value = str(data.get("value") or "")
        # Preserve hidden/default values (CSRF, remember flags, etc.).
        if input_type not in ("password", "email"):
            self._form["fields"][name] = value
        lower_name = name.casefold()
        if input_type == "email" or lower_name in ("email", "e-mail", "login", "username", "user"):
            self._form["email_name"] = name
        if input_type == "password" or "password" in lower_name or lower_name == "pass":
            self._form["password_name"] = name

    def handle_endtag(self, tag):
        if tag.lower() != "form" or self._form is None:
            return
        form = self._form
        self._form = None
        if form.get("password_name"):
            self.forms.append(form)

    def best(self):
        return self.forms[0] if self.forms else None


class _EpisodePageParser(HTMLParser):
    """Parse both current and legacy SerienStream provider-list layouts."""

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.items = []
        self.languages = {}
        self._container = None
        self._container_tag = ""
        self._container_depth = 0
        self._host_parts = None

    @staticmethod
    def _language_label(data):
        return (
            data.get("data-language-label")
            or data.get("data-lang-label")
            or data.get("title")
            or data.get("alt")
            or ""
        )

    def _append_current(self, data):
        play_url = _relative_site_link(data.get("data-play-url"))
        if not play_url:
            return
        key = data.get("data-language-id") or data.get("data-lang-key") or ""
        label = self._language_label(data) or self.languages.get(str(key), {}).get("label", "")
        self.items.append({
            "link": play_url,
            "hoster": data.get("data-provider-name") or data.get("aria-label") or data.get("title") or "SerienStream",
            "lang_key": str(key),
            "lang_label": label,
            "lang_hint": self.languages.get(str(key), {}).get("hint", ""),
            "text": data.get("data-quality") or "",
        })

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        data = _attrs(attrs)
        classes = set(data.get("class", "").split())

        # Current layout: a provider button carries everything in data-* attrs.
        if data.get("data-play-url"):
            self._append_current(data)

        # Language flags used by the legacy provider list and still present in
        # some current pages/fallback templates.
        lang_key = data.get("data-lang-key") or data.get("data-language-id")
        if tag == "img" and lang_key:
            label = self._language_label(data)
            hint = "%s %s" % (data.get("src", ""), data.get("alt", ""))
            self.languages[str(lang_key)] = {"label": label, "hint": hint}

        if self._container is not None:
            if tag == self._container_tag:
                self._container_depth += 1
            if tag == "a":
                href = _relative_site_link(data.get("href"))
                if href and not self._container.get("link"):
                    self._container["link"] = href
            if tag == "h4" or "hoster-name" in classes or "provider-name" in classes:
                self._host_parts = []
            return

        # Legacy layout: <li data-lang-key data-link-target> ... <h4>VOE.
        has_lang = bool(data.get("data-lang-key") or data.get("data-language-id"))
        candidate_link = (
            _relative_site_link(data.get("data-link-target"))
            or _relative_site_link(data.get("data-play-url"))
        )
        if not candidate_link and data.get("data-link-id"):
            candidate_link = _relative_site_link("/redirect/%s" % data.get("data-link-id"))

        if has_lang and tag in ("li", "button", "div") and (
            candidate_link
            or "link-box" in classes
            or any(name.startswith("episodeLink") for name in classes)
        ):
            key = data.get("data-lang-key") or data.get("data-language-id") or ""
            self._container = {
                "link": candidate_link,
                "hoster": data.get("data-provider-name") or data.get("aria-label") or "",
                "lang_key": str(key),
                "lang_label": self._language_label(data),
                "lang_hint": self.languages.get(str(key), {}).get("hint", ""),
                "text_parts": [],
            }
            self._container_tag = tag
            self._container_depth = 1

    def handle_data(self, data):
        if self._host_parts is not None:
            self._host_parts.append(data)
        if self._container is not None:
            self._container["text_parts"].append(data)

    def handle_endtag(self, tag):
        tag = tag.lower()
        if self._host_parts is not None and tag in ("h4", "span", "div"):
            hoster = re.sub(r"\s+", " ", " ".join(self._host_parts)).strip()
            if self._container is not None and hoster:
                self._container["hoster"] = hoster
            self._host_parts = None

        if self._container is None or tag != self._container_tag:
            return
        self._container_depth -= 1
        if self._container_depth > 0:
            return
        item = self._container
        self._container = None
        self._container_tag = ""
        if not item.get("link"):
            return
        key = str(item.get("lang_key") or "")
        if not item.get("lang_label"):
            item["lang_label"] = self.languages.get(key, {}).get("label", "")
        if not item.get("lang_hint"):
            item["lang_hint"] = self.languages.get(key, {}).get("hint", "")
        item["text"] = re.sub(r"\s+", " ", " ".join(item.pop("text_parts", []))).strip()
        item["hoster"] = re.sub(r"\s+", " ", str(item.get("hoster") or "SerienStream")).strip()
        self.items.append(item)


def _parse_episode_sources(html):
    parser = _EpisodePageParser()
    parser.feed(str(html or ""))
    parser.close()

    result = []
    seen = set()
    for item in parser.items:
        link = _relative_site_link(item.get("link"))
        if not link:
            continue
        hoster = re.sub(r"\s+", " ", str(item.get("hoster") or "SerienStream")).strip()
        lang_key = str(item.get("lang_key") or "")
        lang_label = re.sub(r"\s+", " ", str(item.get("lang_label") or "")).strip()
        marker = (link, hoster.casefold(), lang_key, lang_label.casefold())
        if marker in seen:
            continue
        seen.add(marker)
        item["link"] = link
        item["hoster"] = hoster
        item["lang_key"] = lang_key
        item["lang_label"] = lang_label
        result.append(item)
    return result


def _external_redirect_target(response, request_url=''):
    """Return a hoster URL exposed by HTTP, meta-refresh or simple JS redirect.

    SerienStream has used both ordinary HTTP redirects and small intermediate
    pages.  Only URLs that leave the known SerienStream frontends are accepted;
    unrelated relative links/assets can never escape through this helper.
    """
    candidates = []

    def add(value, base=''):
        value = unescape(str(value or '')).strip().strip('"\' ')
        if not value:
            return
        absolute = urljoin(base or request_url or '', value)
        if _is_external_http(absolute) and absolute not in candidates:
            candidates.append(absolute)

    add(getattr(response, 'url', ''), request_url)
    headers = getattr(response, 'headers', {}) or {}
    add(headers.get('Location', ''), request_url)
    for previous in getattr(response, 'history', ()) or ():
        prev_url = str(getattr(previous, 'url', '') or request_url)
        add((getattr(previous, 'headers', {}) or {}).get('Location', ''), prev_url)

    text = unescape(str(getattr(response, 'text', '') or ''))
    patterns = (
        r'(?is)<meta[^>]+http-equiv=["\']?refresh["\']?[^>]+content=["\'][^"\']*?url\s*=\s*([^"\'>;]+)',
        r'(?is)<meta[^>]+content=["\'][^"\']*?url\s*=\s*([^"\'>;]+)["\'][^>]+http-equiv=["\']?refresh',
        r'(?is)(?:window\.)?location(?:\.href)?\s*=\s*["\']([^"\']+)',
        r'(?is)(?:window\.)?location\.replace\(\s*["\']([^"\']+)',
        r'(?is)<iframe[^>]+src=["\']([^"\']+)',
    )
    for pattern in patterns:
        for match in re.findall(pattern, text):
            add(match, request_url)

    return candidates[0] if candidates else ''


class source:
    has_sort_order = True
    priority = 2
    language = ["de"]

    def __init__(self):
        self.priority = 2
        self.language = ["de"]
        self.base_link = _BASE_URLS[0]
        self._active_base = self.base_link
        self.headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
            ),
            "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
            "Accept-Language": "de-DE,de;q=0.9,en;q=0.6",
        }
        self._search_cache = {}
        self._catalog_page_cache = {}
        self._index_cache = None

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        titles = _unique_titles(localtvshowtitle, tvshowtitle, aliases, getattr(self, "ffitem", None))
        wanted_year = _year(year or kwargs.get("year_alt"))
        if not titles:
            return None
        try:
            candidate_map = {}

            def collect(items, used_base, min_score=0.84, broad=False):
                for item in items or ():
                    path = _series_path(item.get("link") or item.get("url") or item.get("slug"))
                    name = str(item.get("name") or item.get("title") or "").strip()
                    if not path or not name:
                        continue
                    if broad and not any(_broad_match_prefilter(name, wanted) for wanted in titles):
                        continue
                    key = path.casefold()
                    title_score = max(_title_score(name, wanted) for wanted in titles)
                    if title_score < min_score:
                        continue
                    item_year = _year(
                        item.get("productionYear")
                        or item.get("production_year")
                        or item.get("year")
                        or name
                        or path
                    )
                    if not item_year:
                        item_year = _year(path)
                    if wanted_year and item_year and item_year != wanted_year:
                        continue
                    score = title_score + (0.18 if wanted_year and item_year == wanted_year else 0.0)
                    row = (score, path, name, item_year, used_base, title_score)
                    previous = candidate_map.get(key)
                    if previous is None or row[0] > previous[0]:
                        candidate_map[key] = row

            # 1) Exact-slug probes are the fastest safe path for ordinary
            # titles and aliases.  Every hit is verified against the returned
            # page title/year/IMDb before it can be accepted.  This handles
            # translated metadata such as Ród smoka -> House of the Dragon
            # without any hard-coded title exceptions.
            queries = titles[:4]
            direct = self._probe_direct_titles(titles, wanted_year, imdb)
            if direct:
                direct_base = _base_key(direct.get("base")) or self._active_base
                _diag(
                    "tvshow",
                    "matched=true; via=direct; year=%s; base=%s" % (
                        direct.get("year") or "?",
                        urlsplit(direct_base).hostname or "?",
                    ),
                )
                return _encode_ref(
                    "show", base=direct_base, path=direct.get("link"),
                    title=direct.get("name"), year=direct.get("year"),
                )

            # 2) Keep the lightweight AJAX autocomplete as a bonus when it is
            # healthy.  A failure/empty result never proves that a title is
            # absent and therefore never suppresses the complete catalogue.
            ajax_valid = False
            if queries:
                primary_items, used_base, valid_response = self._search(queries[0])
                ajax_valid = bool(valid_response)
                collect(primary_items, used_base, min_score=0.88)

            # 3) Accuracy-first fallback: SerienStream itself recommends the
            # complete alphabet/all-series catalogue as the safest search.
            # Download it once and compare *all* known aliases locally.  The
            # cheap prefilter keeps CPU cost low, but it can never accept a
            # result by itself; the conservative title/year matcher remains
            # authoritative.
            best_now = max((row[0] for row in candidate_map.values()), default=-1.0)
            if best_now < 0.98:
                index_items, index_base, index_valid = self._search_index()
                if index_valid:
                    match_started = time.monotonic()
                    before = len(candidate_map)
                    collect(index_items, index_base, min_score=0.88, broad=True)
                    _diag(
                        "index-match",
                        "entries=%d; accepted=%d; ajax=%s; elapsed=%.2fs" % (
                            len(index_items),
                            max(0, len(candidate_map) - before),
                            "valid" if ajax_valid else "invalid",
                            time.monotonic() - match_started,
                        ),
                    )

            # Fuzzy catalogue hits are verified against the actual series page
            # before they are allowed to become sources.  Exact direct hits
            # have already passed this same verification step.
            if candidate_map:
                verified = {}
                for row in sorted(candidate_map.values(), key=lambda value: value[0], reverse=True)[:12]:
                    score, path, name, item_year, used_base, title_score = row
                    if title_score >= 0.999:
                        # Exact visible-title matches are already deterministic;
                        # only fetch the show page when year/IMDb can disambiguate
                        # same-named productions.
                        if not wanted_year and not imdb:
                            verified[path.casefold()] = row
                            continue
                    checked = self._probe_show_path(
                        path, titles, wanted_year=wanted_year, expected_imdb=imdb, preferred=used_base
                    )
                    if not checked:
                        continue
                    checked_year = checked.get("year") or item_year
                    checked_score = max(_title_score(checked.get("name"), wanted) for wanted in titles)
                    total = checked_score + (0.18 if wanted_year and checked_year == wanted_year else 0.0)
                    verified[path.casefold()] = (
                        total, checked.get("link") or path, checked.get("name") or name,
                        checked_year, checked.get("base") or used_base, checked_score,
                    )
                candidate_map = verified

            candidates = sorted(candidate_map.values(), key=lambda row: row[0], reverse=True)
            if not candidates:
                _diag("tvshow", "matched=false; queries=%d" % min(len(titles), 4))
                return None
            score, path, name, item_year, used_base, title_score = candidates[0]
            if title_score < 0.88:
                _diag("tvshow", "matched=false; best=%.2f" % title_score)
                return None
            if wanted_year and item_year and item_year != wanted_year:
                _diag("tvshow", "matched=false; year-mismatch")
                return None
            base = _base_key(used_base) or self._active_base
            _diag("tvshow", "matched=true; year=%s; base=%s" % (item_year or "?", urlsplit(base).hostname or "?"))
            return _encode_ref("show", base=base, path=path, title=name, year=item_year)
        except Exception as exc:
            self._kadr_last_error = "%s: %s" % (type(exc).__name__, exc)
            fflog_exc()
            return None

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        ref = _decode_ref(url)
        if not ref or ref.get("kind") != "show":
            return None
        path = _episode_path(ref.get("path"), season, episode)
        if not path:
            return None
        return _encode_ref(
            "episode",
            base=ref.get("base") or self._active_base,
            path=path,
            hoster="",
            lang_key="",
            lang_label="",
            slot=0,
        )

    def sources(self, url, hostDict, hostprDict):
        ref = _decode_ref(url)
        if not ref or ref.get("kind") != "episode":
            return []
        try:
            html, used_base = self._fetch_page(ref["path"], preferred=ref.get("base"))
            if not html:
                _diag("sources", "page=empty")
                return []
            variants = _parse_episode_sources(html)
            result = []
            counts = {}
            for item in variants:
                hoster = item.get("hoster") or "SerienStream"
                lang_key = str(item.get("lang_key") or "")
                lang_label = str(item.get("lang_label") or "")
                bucket, display, subtitle = _language_bucket(
                    lang_label, lang_key, item.get("lang_hint")
                )
                group = (hoster.casefold(), lang_key, lang_label.casefold())
                slot = counts.get(group, 0)
                counts[group] = slot + 1

                quality = _quality("%s %s" % (item.get("text") or "", item.get("link") or ""))
                details = ["Audio: %s" % display]
                if subtitle:
                    details.append(subtitle)
                text = _display_metadata(item.get("text"), quality)
                # Avoid echoing the hoster/language twice when it is the only
                # visible text inside a legacy card.
                if text and _normalize_title(text) not in (
                    _normalize_title(hoster), _normalize_title(lang_label)
                ):
                    details.append(text)

                result.append({
                    "source": hoster,
                    "quality": quality,
                    "language": bucket,
                    "url": _encode_ref(
                        "episode",
                        base=used_base,
                        path=ref["path"],
                        hoster=hoster,
                        lang_key=lang_key,
                        lang_label=lang_label,
                        slot=slot,
                    ),
                    "info": " | ".join(details),
                    "direct": False,
                    "debridonly": False,
                })

            _diag(
                "sources",
                "variants=%d; languages=%s; base=%s" % (
                    len(result),
                    ",".join(sorted(set(str(item.get("language") or "") for item in result))) or "none",
                    urlsplit(used_base).hostname or "?",
                ),
            )
            return result
        except Exception as exc:
            self._kadr_last_error = "%s: %s" % (type(exc).__name__, exc)
            fflog_exc()
            return []

    def resolve(self, url):
        ref = _decode_ref(url)
        if not ref or ref.get("kind") != "episode" or not ref.get("hoster"):
            return None
        try:
            bases = self._ordered_bases(ref.get("base"))

            # Current SerienStream exposes provider buttons publicly.  Login is
            # optional (account/history), so entered credentials must never turn
            # a working public redirect into a dead source.  Always try exactly
            # the public browser flow first, including the raw HTTP mirror.
            for base in bases:
                try:
                    session = self._new_session(base)
                    target = self._resolve_on_base(session, base, ref, auth_label="public")
                    if target:
                        return target
                except Exception as exc:
                    _diag(
                        "resolve-attempt",
                        "via=%s; auth=public; error=%s" % (
                            urlsplit(base).hostname or "?", type(exc).__name__,
                        ),
                    )

            # Optional compatibility fallback for accounts/older frontends.
            # Credentials are restricted to HTTPS and failure never prevents
            # the already-attempted public flow.
            user, password = self._credentials()
            if user and password:
                for base in bases:
                    parts = urlsplit(base)
                    if parts.scheme.lower() != "https":
                        continue
                    try:
                        session = self._new_session(base)
                        if not self._login_session(session, base):
                            continue
                        target = self._resolve_on_base(session, base, ref, auth_label="account")
                        if target:
                            return target
                    except Exception as exc:
                        _diag(
                            "resolve-attempt",
                            "via=%s; auth=account; error=%s" % (
                                parts.hostname or "?", type(exc).__name__,
                            ),
                        )

            _diag(
                "resolve",
                "hoster=%s; result=empty; public=yes; auth-fallback=%s" % (
                    ref.get("hoster") or "?",
                    "yes" if (user and password) else "no",
                ),
            )
            return None
        except Exception as exc:
            self._kadr_last_error = "%s: %s" % (type(exc).__name__, exc)
            fflog_exc()
            return None

    def _resolve_on_base(self, session, base, ref, auth_label="public"):
        """Resolve one selected language/hoster variant in one browser session."""
        page_url = base.rstrip("/") + ref["path"]
        page = session.get(page_url, timeout=(3, 8), allow_redirects=True)
        if getattr(page, "status_code", 500) >= 400:
            return None
        variants = _parse_episode_sources(page.text)
        item = self._find_variant(variants, ref)
        if not item:
            return None
        target = _relative_site_link(item.get("link"))
        if not target:
            return None
        if _is_external_http(target):
            _diag(
                "resolve",
                "hoster=%s; result=external-direct; via=%s; auth=%s" % (
                    ref.get("hoster") or "?",
                    urlsplit(base).hostname or "?",
                    auth_label,
                ),
            )
            return target

        target_url = urljoin(base.rstrip("/") + "/", target)
        response = session.get(
            target_url,
            headers={
                "Referer": page_url,
                "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
                "Upgrade-Insecure-Requests": "1",
            },
            timeout=(3, 10),
            allow_redirects=True,
        )
        final_url = _external_redirect_target(response, target_url)
        if not final_url:
            return None
        _diag(
            "resolve",
            "hoster=%s; result=ok; via=%s; auth=%s" % (
                ref.get("hoster") or "?",
                urlsplit(base).hostname or "?",
                auth_label,
            ),
        )
        return final_url

    def _ordered_bases(self, preferred=""):
        result = []
        preferred = _base_key(preferred)
        for base in (preferred, self._active_base) + _BASE_URLS:
            base = _base_key(base)
            if base and base not in result:
                result.append(base)
        return result

    def _new_session(self, base=""):
        session = requests.Session()
        session.headers.update(self.headers)
        if base:
            session.headers["Referer"] = base.rstrip("/") + "/"
        return session

    @staticmethod
    def _credentials():
        return (
            settings.getString("serienstream.user").strip(),
            settings.getString("serienstream.pass"),
        )

    def _login_session(self, session, base, referer=""):
        """Optional account fallback for legacy/front-end specific redirects.

        The current site does not require an account for normal playback, but
        keeping a conservative login fallback costs little and helps older
        mirrors.  Hidden form fields are preserved so CSRF changes do not break
        the request.  Credentials are never sent over plain HTTP or off-site.
        """
        user, password = self._credentials()
        if not user or not password:
            return False
        parsed = urlsplit(str(base or ""))
        if parsed.scheme.lower() != "https" or not parsed.hostname:
            return False
        base = base.rstrip("/")
        login_url = base + "/login"
        try:
            login_page = session.get(
                login_url,
                headers={"Referer": referer or (base + "/")},
                timeout=(3, 8),
                allow_redirects=True,
            )
            if getattr(login_page, "status_code", 500) >= 400:
                _diag("auth", "result=login-page-failed; base=%s" % (parsed.hostname or "?"))
                return False

            parser = _LoginFormParser()
            parser.feed(str(getattr(login_page, "text", "") or ""))
            parser.close()
            form = parser.best() or {
                "action": "/login",
                "method": "post",
                "fields": {},
                "email_name": "email",
                "password_name": "password",
            }
            action = urljoin(login_url, form.get("action") or "/login")
            action_parts = urlsplit(action)
            if (
                action_parts.scheme.lower() != "https"
                or (action_parts.hostname or "").lower() != parsed.hostname.lower()
                or (action_parts.hostname or "").lower() not in _BASE_HOSTS
            ):
                _diag("auth", "result=unsafe-action; base=%s" % (parsed.hostname or "?"))
                return False

            data = dict(form.get("fields") or {})
            data[form.get("email_name") or "email"] = user
            data[form.get("password_name") or "password"] = password
            # Older SerienStream forms used this name; harmless if ignored by
            # a newer backend and useful when an older mirror is active.
            data.setdefault("autoLogin", "on")

            response = session.post(
                action,
                data=data,
                headers={"Origin": base, "Referer": login_url},
                timeout=(3, 8),
                allow_redirects=True,
            )
            if getattr(response, "status_code", 500) >= 400:
                _diag("auth", "result=failed; base=%s; status=%s" % (
                    parsed.hostname or "?", getattr(response, "status_code", "?"),
                ))
                return False

            # Do not mistake a 200 login page containing an error for success.
            account = session.get(
                base + "/account",
                headers={"Referer": str(getattr(response, "url", "") or login_url)},
                timeout=(3, 8),
                allow_redirects=True,
            )
            account_url = str(getattr(account, "url", "") or "")
            account_text = str(getattr(account, "text", "") or "").casefold()
            account_path = urlsplit(account_url).path.rstrip("/").casefold()
            ok = (
                getattr(account, "status_code", 500) < 400
                and account_path not in ("/login", "")
                and (
                    "logout" in account_text
                    or "abmelden" in account_text
                    or account_path.startswith("/account")
                )
            )
            _diag(
                "auth",
                "result=%s; base=%s; cookies=%d" % (
                    "ok" if ok else "failed",
                    parsed.hostname or "?",
                    len(getattr(session, "cookies", ()) or ()),
                ),
            )
            return bool(ok)
        except Exception as exc:
            _diag("auth", "result=error; base=%s; error=%s" % (
                parsed.hostname or "?", type(exc).__name__,
            ))
            return False

    @staticmethod
    def _json_search_payload(payload):
        """Return (is_real_search_response, items).

        Do not treat an arbitrary JSON error/challenge object as a valid empty
        catalogue result; doing so would prevent trying the working mirror.
        """
        if isinstance(payload, list):
            return True, [item for item in payload if isinstance(item, dict)]
        if isinstance(payload, dict):
            for key in ("data", "results", "items", "series"):
                if key not in payload:
                    continue
                value = payload.get(key)
                if isinstance(value, list):
                    return True, [item for item in value if isinstance(item, dict)]
                return False, []
            if any(key in payload for key in ("name", "title", "link", "url")):
                return True, [payload]
        return False, []

    def _search(self, query):
        key = _normalize_title(query)
        if key in self._search_cache:
            return self._search_cache[key]

        # The ajax autocomplete is useful when healthy but has historically
        # been intermittent.  Give the main frontend one short attempt.  If it
        # times out or no longer returns the expected JSON, fall back to the
        # authoritative /serien catalogue instead of repeating long waits on
        # equivalent mirrors.
        bases = self._ordered_bases()
        base = bases[0] if bases else self.base_link
        session = self._new_session(base)
        started = time.monotonic()
        try:
            response = session.get(
                base + "/ajax/seriesSearch",
                params={"keyword": query},
                headers={"Accept": "application/json, text/plain, */*", "X-Requested-With": "XMLHttpRequest"},
                timeout=(2.5, 3.5),
            )
            status = getattr(response, "status_code", 500)
            if status < 400:
                try:
                    payload = response.json()
                except Exception:
                    payload = None
                valid_payload, items = self._json_search_payload(payload)
                _diag(
                    "ajax",
                    "status=%s; valid=%s; items=%d; elapsed=%.2fs" % (
                        status, "yes" if valid_payload else "no", len(items),
                        time.monotonic() - started,
                    ),
                )
                if valid_payload:
                    self._active_base = base
                    result = (items, base, True)
                    self._search_cache[key] = result
                    return result
            else:
                _diag(
                    "ajax",
                    "status=%s; valid=no; elapsed=%.2fs" % (
                        status, time.monotonic() - started,
                    ),
                )
        except Exception as exc:
            _diag(
                "ajax",
                "error=%s; elapsed=%.2fs" % (
                    type(exc).__name__, time.monotonic() - started,
                ),
            )

        result = ([], "", False)
        self._search_cache[key] = result
        return result

    def _probe_show_path(self, path, titles, wanted_year="", expected_imdb="", preferred="", all_bases=True):
        """Verify one concrete SerienStream show page before accepting it.

        The page title remains the main identity check.  When SerienStream also
        exposes a year or IMDb id, those are used as strong disambiguators.
        This makes exact-slug acceleration safe and also validates fuzzy
        catalogue fallback candidates before they can produce sources.
        """
        path = _series_path(path)
        if not path:
            return None
        expected_imdb = str(expected_imdb or "").strip().lower()
        if expected_imdb and not expected_imdb.startswith("tt"):
            expected_imdb = ""

        bases = self._ordered_bases(preferred)
        if not all_bases:
            bases = bases[:1]
        for base in bases:
            try:
                session = self._new_session(base)
                response = session.get(base.rstrip("/") + path, timeout=(2.5, 5.0), allow_redirects=True)
                if getattr(response, "status_code", 500) >= 400:
                    continue
                final_path = _series_path(getattr(response, "url", ""))
                if not final_path:
                    continue
                parser = _ShowPageParser()
                parser.feed(str(getattr(response, "text", "") or ""))
                parser.close()
                parser.finish()
                if not parser.title:
                    continue
                score = max((_title_score(parser.title, wanted) for wanted in titles), default=0.0)
                if score < 0.88:
                    continue
                if wanted_year and parser.year and parser.year != wanted_year:
                    continue
                if expected_imdb and parser.imdb and parser.imdb != expected_imdb:
                    continue
                self._active_base = base
                return {
                    "name": parser.title,
                    "link": final_path,
                    "year": parser.year,
                    "imdb": parser.imdb,
                    "score": score,
                    "base": base,
                }
            except Exception:
                continue
        return None

    def _probe_direct_titles(self, titles, wanted_year="", expected_imdb=""):
        """Try exact URL slugs for the best-known title aliases first.

        This is an accelerator only.  Failure never means that a title is
        absent; the authoritative full catalogue fallback still runs next.
        """
        started = time.monotonic()
        attempts = 0
        seen_paths = set()
        primary = []
        secondary = []
        # Four high-priority aliases cover German-region/original alternatives
        # without turning missing titles into a long chain of 404 requests.
        # Try the plain slug of every accepted DE/original title before
        # optional year-suffixed variants.
        for title in list(titles or ())[:4]:
            slugs = _slug_candidates(title, wanted_year)
            if slugs:
                primary.append(slugs[0])
                secondary.extend(slugs[1:])
        for slug in primary + secondary:
            path = "/serie/%s" % slug
            key = path.casefold()
            if key in seen_paths:
                continue
            seen_paths.add(key)
            attempts += 1
            item = self._probe_show_path(
                path, titles, wanted_year=wanted_year, expected_imdb=expected_imdb,
                all_bases=False,
            )
            if item:
                _diag(
                    "direct",
                    "attempts=%d; matched=yes; elapsed=%.2fs" % (
                        attempts, time.monotonic() - started,
                    ),
                )
                return item
        _diag(
            "direct",
            "attempts=%d; matched=no; elapsed=%.2fs" % (
                attempts, time.monotonic() - started,
            ),
        )
        return None

    def _catalog_page(self, bucket, page):
        key = (str(bucket or ""), int(page or 1))
        if key in self._catalog_page_cache:
            return self._catalog_page_cache[key]

        bases = self._ordered_bases()
        base = bases[0] if bases else self.base_link
        session = self._new_session(base)
        try:
            url = "%s/katalog/%s" % (base, bucket)
            params = {"page": int(page)} if int(page) > 1 else None
            response = session.get(url, params=params, timeout=(2.5, 4.5))
            if getattr(response, "status_code", 500) >= 400:
                result = ([], base, False)
            else:
                parser = _SearchHTMLParser()
                parser.feed(response.text or "")
                parser.close()
                result = (parser.items, base, bool(parser.items))
        except Exception:
            result = ([], base, False)
        self._catalog_page_cache[key] = result
        return result

    def _search_catalogue(self, query):
        """Search only the alphabetic slice that can contain ``query``.

        Pages are alphabetically ordered by SerienStream.  We walk forward
        until the wanted title's sort position is reached, then stop.  This is
        typically a handful of small pages rather than one 10k-entry document.
        The real title/year matcher still decides whether anything is accepted.
        """
        bucket = _catalog_bucket(query)
        wanted = _title_sort_key(query)
        if not bucket or not wanted:
            return [], "", False

        started = time.monotonic()
        candidates = []
        valid_any = False
        used_base = ""
        seen_paths = set()
        crossed = False
        pages_used = 0

        # Safety ceiling only; normal buckets stop much earlier once their
        # alphabetical position has been reached.
        for page in range(1, 21):
            items, base, valid = self._catalog_page(bucket, page)
            if not valid:
                if page == 1:
                    _diag(
                        "catalog",
                        "bucket=%s; valid=no; elapsed=%.2fs" % (
                            bucket, time.monotonic() - started,
                        ),
                    )
                    return [], base, False
                break
            valid_any = True
            used_base = base or used_base
            pages_used = page
            if not items:
                break

            page_keys = []
            for item in items:
                name = str(item.get("name") or item.get("title") or "").strip()
                path = _series_path(item.get("link") or item.get("url") or item.get("slug"))
                if not name or not path:
                    continue
                page_keys.append(_title_sort_key(name))
                if path.casefold() in seen_paths:
                    continue
                if _broad_match_prefilter(name, query):
                    seen_paths.add(path.casefold())
                    candidates.append(item)

            page_keys = [value for value in page_keys if value]
            if not page_keys:
                continue
            last_key = page_keys[-1]
            if last_key >= wanted:
                # The catalogue is alphabetically ordered.  Once this page has
                # reached/passed the wanted sort position there is no reason to
                # download later pages; any plausible candidate is already in
                # the collected slice.
                crossed = True
                break

        _diag(
            "catalog",
            "bucket=%s; pages=%d; candidates=%d; valid=%s; elapsed=%.2fs" % (
                bucket,
                pages_used,
                len(candidates),
                "yes" if valid_any else "no",
                time.monotonic() - started,
            ),
        )
        return candidates, used_base, valid_any

    def _search_index(self):
        if self._index_cache is not None:
            return self._index_cache

        # /serien is the current public complete catalogue.  It is more stable
        # than the old /search page and gives us one local list to match against
        # every title alias when ajax suggestions are incomplete.
        for base in self._ordered_bases():
            session = self._new_session(base)
            try:
                response = session.get(base + "/serien", timeout=(3, 8))
                if getattr(response, "status_code", 500) >= 400:
                    continue
                parser = _SearchHTMLParser()
                parser.feed(response.text or "")
                parser.close()
                if not parser.items:
                    continue
                self._active_base = base
                self._index_cache = (parser.items, base, True)
                _diag("index", "entries=%d; base=%s" % (
                    len(parser.items), urlsplit(base).hostname or "?"
                ))
                return self._index_cache
            except Exception:
                continue

        self._index_cache = ([], "", False)
        return self._index_cache

    def _fetch_page(self, path, preferred=""):
        path = _safe_episode_path(path)
        if not path:
            return "", ""
        for base in self._ordered_bases(preferred):
            try:
                session = self._new_session(base)
                response = session.get(base + path, timeout=(3, 8), allow_redirects=True)
                if getattr(response, "status_code", 500) >= 400:
                    continue
                html = response.text or ""
                # A DNS-block/interstitial page can return HTTP 200.  Only
                # accept a page that actually contains provider metadata.
                if not _parse_episode_sources(html):
                    continue
                self._active_base = base
                return html, base
            except Exception:
                continue
        return "", ""

    @staticmethod
    def _find_variant(items, ref):
        wanted_hoster = str(ref.get("hoster") or "").casefold()
        wanted_key = str(ref.get("lang_key") or "")
        wanted_label = _normalize_title(ref.get("lang_label"))
        candidates = []
        for item in items:
            if str(item.get("hoster") or "").casefold() != wanted_hoster:
                continue
            item_key = str(item.get("lang_key") or "")
            item_label = _normalize_title(item.get("lang_label"))
            if wanted_key and item_key and item_key != wanted_key:
                continue
            if wanted_label and item_label and item_label != wanted_label:
                continue
            candidates.append(item)
        slot = max(0, int(ref.get("slot") or 0))
        if slot < len(candidates):
            return candidates[slot]
        return candidates[0] if candidates else None
