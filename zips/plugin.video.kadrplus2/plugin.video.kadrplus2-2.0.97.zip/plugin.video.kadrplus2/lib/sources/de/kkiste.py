# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""KKiste provider for Kadr+ 2.0, implemented against its public JSON catalogue."""

from lib.sources.de._kadr_json_catalog import JsonCatalogSource


class source(JsonCatalogSource):
    provider_name = "kkiste"
    base_urls = ("https://kkiste.eu",)
    ref_prefix = "kadr-kkiste:"
    catalog_path = "/data/browse/?lang=2&order_by=new&page=1&limit=0"
    catalog_year_path_template = (
        "/data/browse/?lang=2&type={media_type}&order_by=new&year={year}&page=1&limit=0"
    )
    request_headers = {
        "Origin": "https://kkiste.eu/",
        "Referer": "https://kkiste.eu/",
    }
