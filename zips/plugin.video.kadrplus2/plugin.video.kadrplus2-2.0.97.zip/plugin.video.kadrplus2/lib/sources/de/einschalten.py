# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""Einschalten.in source adapter for Kadr+ 2.0.

The site exposes a small JSON API used by its own public web frontend.  Kadr+
uses that API for movie search and obtains the current watch URL only after a
strict title/year match.
"""

from __future__ import annotations

import base64
import json
import re
import unicodedata
from difflib import SequenceMatcher
from urllib.parse import urlsplit

from lib.ff import requests, source_utils
from lib.ff.log_utils import fflog, fflog_exc
from lib.sources.de._kadr_de_common import titles_from as _de_titles_from


_BASE_URL = "https://einschalten.in"
_REF_PREFIX = "kadr-einschalten:"
_YEAR_RE = re.compile(r"(?<!\d)((?:19|20)\d{2})(?!\d)")


def _diag(stage, message=""):
    try:
        from lib.ff import diagnostics
        if not diagnostics.enabled():
            return
        diagnostics.log_event("einschalten", ("stage=%s; %s" % (stage, message)).rstrip("; "))
    except Exception:
        pass


def _normalize_title(value):
    value = str(value or "").replace("ß", "ss")
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    value = re.sub(r"[^a-z0-9]+", " ", value.lower())
    return re.sub(r"\s+", " ", value).strip()


def _title_score(candidate, wanted):
    left = _normalize_title(candidate)
    right = _normalize_title(wanted)
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0
    if left in right or right in left:
        return 0.90
    return SequenceMatcher(None, left, right).ratio()


def _unique_titles(localtitle, title, aliases, ffitem=None):
    return _de_titles_from(localtitle, title, aliases, limit=10, ffitem=ffitem, media_type="movie")


def _year(value):
    match = _YEAR_RE.search(str(value or ""))
    return match.group(1) if match else ""


def _quality(value):
    value = str(value or "").upper()
    if re.search(r"(?:2160|\b4K\b|\bUHD\b)", value):
        return "4K"
    if "1440" in value:
        return "1440p"
    if re.search(r"1080|\bFHD\b", value):
        return "1080p"
    if re.search(r"720|\bHD\b", value):
        return "720p"
    if re.search(r"\bCAM\b|TELESYNC|\bTS\b", value):
        return "CAM"
    return "SD"


def _display_metadata(value, quality):
    """Keep release/source details, but do not repeat the left quality badge."""
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    patterns = {
        "4K": r"(?i)(?<!\w)(?:2160p?|4k|uhd)(?!\w)",
        "1440p": r"(?i)(?<!\w)1440p?(?!\w)",
        "1080p": r"(?i)(?<!\w)(?:1080p?|fhd)(?!\w)",
        "720p": r"(?i)(?<!\w)720p?(?!\w)",
        "CAM": r"(?i)(?<!\w)(?:cam|telesync|ts)(?!\w)",
    }
    pattern = patterns.get(str(quality or ""))
    if pattern:
        text = re.sub(pattern, " ", text)
    text = re.sub(r"\s+", " ", text).strip(" -|/\t")
    return text


def _is_direct(url):
    path = urlsplit(str(url or "")).path.lower()
    return path.endswith((".m3u8", ".mpd", ".mp4", ".webm", ".ts"))


def _encode_ref(movie_id, title="", year=""):
    data = {
        "id": int(movie_id),
        "title": str(title or "")[:180],
        "year": str(year or "")[:4],
    }
    raw = json.dumps(data, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return _REF_PREFIX + base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _decode_ref(value):
    value = str(value or "")
    if not value.startswith(_REF_PREFIX):
        return None
    try:
        token = value[len(_REF_PREFIX):]
        token += "=" * (-len(token) % 4)
        data = json.loads(base64.urlsafe_b64decode(token.encode("ascii")).decode("utf-8"))
        movie_id = int(data.get("id") or 0)
        if movie_id <= 0:
            return None
        return {
            "id": movie_id,
            "title": str(data.get("title") or ""),
            "year": str(data.get("year") or ""),
        }
    except Exception:
        return None


def _resolveurl_recognizes(url):
    try:
        import resolveurl
        item = resolveurl.HostedMediaFile(
            url=url, include_disabled=True, include_universal=False
        )
        return bool(item and item.valid_url())
    except Exception:
        return False



def _payload_items(payload, keys=()):
    """Normalize the few JSON envelope shapes used by the web frontend."""
    if isinstance(payload, list):
        return payload
    if not isinstance(payload, dict):
        return []
    for key in keys:
        value = payload.get(key)
        if isinstance(value, list):
            return value
        if isinstance(value, dict):
            return [value]
    # A watch endpoint may itself return one stream object.
    if any(key in payload for key in ("streamUrl", "stream_url", "url", "link")):
        return [payload]
    return []


def _movie_id(item):
    if not isinstance(item, dict):
        return 0
    for key in ("id", "movieId", "movie_id", "tmdbId", "tmdb_id"):
        try:
            value = int(item.get(key) or 0)
        except (TypeError, ValueError):
            value = 0
        if value > 0:
            return value
    return 0


class source:
    has_sort_order = True
    priority = 2
    language = ["de"]

    def __init__(self):
        self.priority = 2
        self.language = ["de"]
        self.base_link = _BASE_URL
        self.session = requests.Session()
        self.headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
            ),
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "de-DE,de;q=0.9,en;q=0.4",
            "Referer": _BASE_URL + "/",
            "Origin": _BASE_URL,
        }
        self.session.headers.update(self.headers)
        self._search_cache = {}

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        titles = _unique_titles(localtitle, title, aliases, getattr(self, "ffitem", None))
        wanted_year = _year(year or kwargs.get("year_alt"))
        if not titles:
            return None
        try:
            best = None
            best_score = -1.0
            seen_ids = set()
            for query in titles[:4]:
                for item in self._search(query):
                    if not isinstance(item, dict):
                        continue
                    movie_id = _movie_id(item)
                    if movie_id <= 0 or movie_id in seen_ids:
                        continue
                    seen_ids.add(movie_id)
                    item_title = str(item.get("title") or item.get("name") or "").strip()
                    if not item_title:
                        continue
                    score = max(_title_score(item_title, wanted) for wanted in titles)
                    item_year = _year(
                        item.get("releaseDate")
                        or item.get("release_date")
                        or item.get("releaseYear")
                        or item.get("release_year")
                        or item.get("year")
                    )
                    if wanted_year and item_year:
                        score += 0.20 if item_year == wanted_year else -0.35
                    if score > best_score:
                        best_score = score
                        best = (movie_id, item_title, item_year)

                # Exact title + year is decisive; avoid unnecessary aliases.
                if best and best_score >= 1.15:
                    break

            # Require a strong title match.  With no year from the API an exact
            # title is still acceptable; a conflicting year is heavily penalized.
            if not best or best_score < 0.78:
                _diag("movie", "matched=false; queries=%d" % min(len(titles), 4))
                return None
            movie_id, item_title, item_year = best
            _diag("movie", "matched=true; id=%d; year=%s" % (movie_id, item_year or "?"))
            return _encode_ref(movie_id, item_title, item_year)
        except Exception as exc:
            self._kadr_last_error = "%s: %s" % (type(exc).__name__, exc)
            fflog_exc()
            return None

    def sources(self, url, hostDict, hostprDict):
        ref = _decode_ref(url)
        if not ref:
            return []
        try:
            response = self.session.get(
                "%s/api/movies/%d/watch" % (self.base_link, ref["id"]),
                timeout=(3, 8),
            )
            response.raise_for_status()
            payload = response.json()
            entries = _payload_items(payload, ("data", "streams", "sources", "items", "results"))
            result = []
            seen = set()
            for entry in entries:
                if not isinstance(entry, dict):
                    continue
                link = str(
                    entry.get("streamUrl")
                    or entry.get("stream_url")
                    or entry.get("url")
                    or entry.get("link")
                    or ""
                ).strip()
                parsed = urlsplit(link)
                if parsed.scheme not in ("http", "https") or not parsed.hostname or link in seen:
                    continue
                seen.add(link)
                direct = _is_direct(link)
                valid, hoster = source_utils.is_host_valid(link, hostDict)
                if not valid:
                    valid, hoster = source_utils.is_host_valid(link, hostprDict)
                if not valid and not direct and not _resolveurl_recognizes(link):
                    fflog("[einschalten] skip unsupported host: %s" % link, 1)
                    continue
                if not hoster:
                    hoster = parsed.hostname or "Einschalten"
                    if hoster.startswith("www."):
                        hoster = hoster[4:]

                release = re.sub(
                    r"\s+", " ", str(
                        entry.get("releaseName")
                        or entry.get("release_name")
                        or entry.get("name")
                        or ""
                    )
                ).strip()
                quality = _quality("%s %s" % (release, link))
                # The watch API proves the source/language, but not whether the
                # German track is dubbing, lector or subtitles.  Do not invent a
                # translation type; the left DE badge already communicates it.
                details = []
                display_release = _display_metadata(release, quality)
                if display_release:
                    details.append(display_release)
                result.append({
                    "source": hoster,
                    "quality": quality,
                    "language": "de",
                    "url": link,
                    "info": " | ".join(details),
                    "direct": direct,
                    "debridonly": False,
                })

            _diag("sources", "id=%d; count=%d" % (ref["id"], len(result)))
            return result
        except Exception as exc:
            self._kadr_last_error = "%s: %s" % (type(exc).__name__, exc)
            fflog_exc()
            return []

    def resolve(self, url):
        return url

    def _search(self, query):
        key = _normalize_title(query)
        if key in self._search_cache:
            return self._search_cache[key]
        response = self.session.post(
            self.base_link + "/api/search",
            json={"pageNumber": "0", "pageSize": "32", "query": query},
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            timeout=(3, 8),
        )
        response.raise_for_status()
        payload = response.json()
        data = _payload_items(payload, ("data", "results", "items", "movies", "content"))
        _diag("search", "query-len=%d; candidates=%d" % (len(str(query or "")), len(data)))
        self._search_cache[key] = data
        return data
