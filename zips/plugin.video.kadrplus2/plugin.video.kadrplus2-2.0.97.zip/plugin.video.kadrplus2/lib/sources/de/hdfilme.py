# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""HD Filme provider written independently for Kadr+ 2.0."""

from __future__ import annotations

import re
from urllib.parse import urlsplit

from lib.sources.de._kadr_de_common import absolute_http, clean_text, year_of
from lib.sources.de._kadr_html_cloud_source import HtmlCloudSource


class source(HtmlCloudSource):
    provider_name = "hdfilme"
    base_urls = ("https://hd-filme.lol", "https://www.hd-filme.lol", "https://hdfilme1.co", "https://www.hdfilme1.co")
    ref_prefix = "kadr-hdfilme:"

    def _search_items(self, query):
        home = self.client.get_text("/")
        hm = re.search(r"dle_login_hash\s*=\s*['\"]([a-f0-9]+)['\"]", home, re.I)
        if not hm:
            return []
        html = self.client.post_text(
            "/engine/ajax/controller.php?mod=search",
            data={"query": str(query or ""), "user_hash": hm.group(1)},
            headers={"Content-Type": "application/x-www-form-urlencoded", "X-Requested-With": "XMLHttpRequest"},
            referer=self.client.base + "/",
        )
        out, seen = [], set()
        pattern = re.compile(
            r'<a\b[^>]*href\s*=\s*["\']([^"\']+)["\'][^>]*>\s*'
            r'<span\b[^>]*class\s*=\s*["\'][^"\']*searchheading[^"\']*["\'][^>]*>(.*?)</span>'
            r'\s*<span[^>]*>(.*?)</span>',
            re.I | re.S,
        )
        for href, title_html, meta_html in pattern.findall(html):
            url = absolute_http(href, self.client.base)
            if not url or not self.client.allowed_url(url) or url in seen:
                continue
            seen.add(url)
            title = clean_text(title_html)
            meta = clean_text(meta_html)
            title = re.sub(r'\s+stream\s*$', "", title, flags=re.I).strip()
            sm = re.search(r'\b(?:Staffel|Season)\s*0*(\d+)', title, re.I)
            out.append({
                "title": title,
                "year": year_of(meta),
                "season": int(sm.group(1)) if sm else 0,
                "url": url,
                "is_series": bool(sm),
            })
        return out
