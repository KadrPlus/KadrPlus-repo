# -*- coding: utf-8 -*-
"""
FanFilm - source: MovieBox (api3.aoneroom.com)
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>

Real backend behind the MovieBox app. Every request needs signed headers:
  - x-client-token: "{ts},{md5(reversed(str(ts)))}"
  - x-tr-signature: "{ts}|2|{base64(HMAC-MD5(secret, canonical))}"
  - Bearer token from one GET to /tab/ranking-list, read out of its `x-user`
    response header (JSON with a "token" field), not the body.

subjectType: 1 = movie, 2 = one season of a show (each its own subject, e.g.
"Breaking Bad S1".."S5"). play-info takes se=/ep= on that subjectId directly.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import re
import secrets
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from typing import ClassVar, List, Optional, TYPE_CHECKING
from urllib.parse import urlparse, parse_qs, urljoin

from lib.ff import cache, cleantitle, control, requests, source_utils
from lib.ff.item import FFItem
from lib.ff.source_utils import append_headers, convert_size, quality_from_resolution, search_queries, year_matches
from lib.ff.log_utils import fflog, fflog_exc
from lib.service.client import service_client


def _diag(stage: str, message: str = '') -> None:
    """Privacy-safe MovieBox trace, only when Kadr+ diagnostics is enabled."""
    try:
        from lib.ff import diagnostics
        if not diagnostics.enabled():
            return
        diagnostics.log_event('moviebox-language', f'stage={stage}; {message}'.rstrip('; '))
    except Exception:
        pass


if TYPE_CHECKING:
    from lib.sources import SourceItem, SourceTitleAlias

_BASE = 'https://api3.aoneroom.com'
_SEARCH_PATH = '/wefeed-mobile-bff/subject-api/search/v2'
_PLAYINFO_PATH = '/wefeed-mobile-bff/subject-api/play-info'
_DETAIL_PATH = '/wefeed-mobile-bff/subject-api/get'
_CAPTIONS_PATH = '/wefeed-mobile-bff/subject-api/get-stream-captions'
_PING_URL = _BASE + '/wefeed-mobile-bff/tab/ranking-list?tabId=0&categoryType=4516404531735022304&page=1&perPage=1'

_PKG = 'com.community.oneroom'
_VERSION_NAME = '3.0.13.0325.03'
_VERSION_CODE = 50020088
_UA = f'{_PKG}/{_VERSION_CODE} (Linux; U; Android 13; en_US; sdk_gphone64_x86_64; Build/TQ3A.230901.001; Cronet/145.0.7582.0)'

# Double base64 in the app: decoding the constant once more gives the real HMAC key.
_SECRET_DEFAULT = base64.b64decode(base64.b64decode('NzZpUmwwN3MweFNOOWpxbUVXQXQ3OUVCSlp1bElRSXNWNjRGWnIyTw=='))

# subjectType=2 can be one season ("Breaking Bad S5") or a range ("Reacher S1-S4").
_SEASON_RANGE_RE = re.compile(r'\bS(\d+)(?:-S?(\d+))?\s*$', re.I)
# Trailing "[English]"/"[Multi Audio]"-style annotation some entries carry.
_BRACKET_SUFFIX_RE = re.compile(r'\s*\[[^\]]*\]\s*$')

_SCHEME = 'moviebox:'

_session = requests.Session()

_device_id_cache: Optional[str] = None
_token_cache: dict[str, tuple[str, float]] = {}
_token_cache_lock = threading.Lock()
_BEARER_TTL = 20 * 86400  # JWT itself is valid ~90d - refresh well before that


def _device_id() -> str:
    """Stable per-install random id, persisted so it doesn't change every process."""
    global _device_id_cache
    if _device_id_cache:
        return _device_id_cache
    row = cache.cache_get('moviebox_device_id', control.providercacheFile)
    if row and row.get('value'):
        _device_id_cache = row['value']
        return _device_id_cache
    _device_id_cache = secrets.token_hex(16)
    cache.cache_insert('moviebox_device_id', _device_id_cache, control.providercacheFile)
    return _device_id_cache


def _md5_hex(data: bytes) -> str:
    return hashlib.md5(data).hexdigest()


def _x_client_token(ts: int) -> str:
    timestamp = str(ts)
    return f'{timestamp},{_md5_hex(timestamp[::-1].encode())}'


def _canonical_string(method: str, accept: str, content_type: str, url: str, body: Optional[str], ts: int) -> str:
    parsed = urlparse(url)
    path = parsed.path or ''
    query_params = parse_qs(parsed.query)
    query = '&'.join('&'.join(f'{key}={value}' for value in query_params[key]) for key in sorted(query_params))
    canonical_url = f'{path}?{query}' if query else path
    if body:
        body_bytes = body.encode('utf-8')
        body_hash = _md5_hex(body_bytes[:0x19000])
        body_length = str(len(body_bytes))
    else:
        body_hash = ''
        body_length = ''
    return '\n'.join([method.upper(), accept or '', content_type or '', body_length, str(ts), body_hash, canonical_url])


def _x_tr_signature(method: str, accept: str, content_type: str, url: str, body: Optional[str], ts: int) -> str:
    canonical = _canonical_string(method, accept, content_type, url, body, ts)
    signature = hmac.new(_SECRET_DEFAULT, canonical.encode('utf-8'), hashlib.md5).digest()
    return f'{ts}|2|{base64.b64encode(signature).decode()}'


def _client_info(minimal: bool = False) -> str:
    """Fake Android device fingerprint the app sends on every request."""
    device_id = _device_id()
    if minimal:
        # The bootstrap ping (fetching the anonymous bearer token) uses a shorter payload.
        payload = {
            'package_name': _PKG, 'version_name': _VERSION_NAME, 'version_code': _VERSION_CODE,
            'os': 'android', 'os_version': '13', 'device_id': device_id,
            'install_store': 'ps', 'system_language': 'en', 'net': 'NETWORK_WIFI',
            'region': 'US', 'timezone': 'Asia/Calcutta', 'sp_code': '',
        }
    else:
        payload = {
            'package_name': _PKG, 'version_name': _VERSION_NAME, 'version_code': _VERSION_CODE,
            'os': 'android', 'os_version': '13', 'install_ch': 'ps', 'device_id': device_id,
            'install_store': 'ps', 'gaid': '1b2212c1-dadf-43c3-a0c8-bd6ce48ae22d',
            'brand': 'google', 'model': 'sdk_gphone64_x86_64', 'system_language': 'en',
            'net': 'NETWORK_WIFI', 'region': 'US', 'timezone': 'Asia/Calcutta', 'sp_code': '',
            'X-Play-Mode': '1', 'X-Idle-Data': '1', 'X-Family-Mode': '0', 'X-Content-Mode': '0',
        }
    return json.dumps(payload)


def _signed_headers(method: str, url: str, body: Optional[str], *, token: Optional[str] = None, minimal_client_info: bool = False) -> dict[str, str]:
    ts = int(time.time() * 1000)
    accept = 'application/json'
    content_type = 'application/json' if method == 'GET' else 'application/json; charset=utf-8'
    headers = {
        'user-agent': _UA,
        'accept': accept,
        'content-type': content_type,
        'connection': 'keep-alive',
        'x-client-token': _x_client_token(ts),
        'x-tr-signature': _x_tr_signature(method, accept, content_type, url, body, ts),
        'x-client-info': _client_info(minimal=minimal_client_info),
        'x-client-status': '0',
    }
    if token:
        headers['authorization'] = f'Bearer {token}'
    return headers


def _fetch_bearer_token() -> Optional[str]:
    """Mint a fresh anonymous bearer token - it rides back in the `x-user` response header."""
    try:
        headers = _signed_headers('GET', _PING_URL, None, minimal_client_info=True)
        resp = _session.get(_PING_URL, headers=headers, timeout=12)
        x_user = resp.headers.get('x-user') or resp.headers.get('X-User')
        if not x_user:
            return None
        return json.loads(x_user).get('token')
    except Exception:
        fflog_exc()
        return None


def _bearer_token(force: bool = False) -> Optional[str]:
    if not force:
        cached = _token_cache.get('bearer')
        if cached and (time.time() - cached[1]) < _BEARER_TTL:
            return cached[0]
    with _token_cache_lock:
        if not force:
            cached = _token_cache.get('bearer')
            if cached and (time.time() - cached[1]) < _BEARER_TTL:
                return cached[0]
            row = cache.cache_get('moviebox_bearer', control.providercacheFile)
            if row and row.get('value') and (time.time() - row.get('date', 0)) < _BEARER_TTL:
                _token_cache['bearer'] = (row['value'], row['date'])
                return row['value']
        token = _fetch_bearer_token()
        if token:
            now = time.time()
            _token_cache['bearer'] = (token, now)
            cache.cache_insert('moviebox_bearer', token, control.providercacheFile)
        return token


def _api_request(method: str, url: str, body: Optional[str] = None, *, timeout: int = 15) -> Optional[dict]:
    """Signed GET/POST against the MovieBox API. Retries once with a fresh token on 401."""
    for retry in (False, True):
        token = _bearer_token(force=retry)
        headers = _signed_headers(method, url, body, token=token)
        try:
            if method == 'GET':
                resp = _session.get(url, headers=headers, timeout=timeout)
            else:
                resp = _session.post(url, data=body.encode('utf-8') if body else None, headers=headers, timeout=timeout)
        except Exception:
            fflog_exc()
            return None
        if resp.status_code == 401 and not retry:
            continue
        if resp.status_code != 200:
            return None
        try:
            data = resp.json()
        except Exception:
            return None
        if data.get('code') not in (0, None):
            return None
        return data.get('data')
    return None


def _search(query: str) -> list[dict]:
    url = _BASE + _SEARCH_PATH
    body = json.dumps({'page': 1, 'perPage': 20, 'keyword': query})
    data = _api_request('POST', url, body)
    if not data:
        return []
    subjects: list[dict] = []
    for block in data.get('results') or []:
        subjects.extend(block.get('subjects') or [])
    return subjects


_detail_cache: dict[str, dict] = {}
_detail_cache_lock = threading.Lock()

# MovieBox catalogues more audio languages than Kadr+'s source-list buckets used
# by this provider.  PL/DE/EN are exposed directly; any other single language
# (Korean, Japanese, Hindi, etc.) is deliberately classified as MULTI/other
# instead of being falsely labelled as English.
_LANG_PATTERNS = {
    'pl': (r'\bpolish\b', r'\bpolski\b', r'\bpolska\b', r'\bpl\s*(?:dub|audio)\b', r'\bpol\b'),
    'de': (r'\bgerman\b', r'\bdeutsch\b', r'\bdeutschland\b', r'\bde\s*(?:dub|audio)\b', r'\bger\b'),
    'en': (r'\benglish\b', r'\beng\b', r'\ben\s*(?:dub|audio)\b'),
}
_OTHER_LANGS = {
    'korean': 'Korean', 'korea': 'Korean', 'kor': 'Korean',
    'japanese': 'Japanese', 'japan': 'Japanese', 'jpn': 'Japanese',
    'hindi': 'Hindi', 'tamil': 'Tamil', 'telugu': 'Telugu',
    'spanish': 'Spanish', 'french': 'French', 'italian': 'Italian',
    'portuguese': 'Portuguese', 'russian': 'Russian', 'ukrainian': 'Ukrainian',
    'turkish': 'Turkish', 'thai': 'Thai', 'indonesian': 'Indonesian',
    'chinese': 'Chinese', 'mandarin': 'Mandarin', 'cantonese': 'Cantonese',
}
_MULTI_PATTERNS = (
    r'\bmulti(?:[ -]?audio)?\b', r'\bdual[ -]?audio\b', r'\bmulti(?:ple)?\s+languages?\b',
)
_LANGUAGE_FIELD_RE = re.compile(r'(?:^|_)(?:audio|lang|language|dub)(?:$|_)|(?:audio|lang|language|dub)', re.I)
_RESOURCE_ID_KEYS = ('resourceId', 'resourceID', 'resource_id')


def _language_from_text(value: object) -> tuple[Optional[str], str]:
    """Map an explicit MovieBox audio-language label to a Kadr+ bucket.

    Returns (None, '') when the text carries no language evidence.  Unknown but
    recognised languages are returned as ('multi', '<Language>') so they never
    masquerade as English.
    """
    if value is None:
        return None, ''
    text = str(value).strip()
    if not text:
        return None, ''
    low = re.sub(r'[_./+\-]+', ' ', text.lower()).strip()
    exact_codes = {
        'pl': ('pl', ''), 'pol': ('pl', ''), 'polish': ('pl', ''),
        'de': ('de', ''), 'ger': ('de', ''), 'deu': ('de', ''), 'german': ('de', ''),
        'en': ('en', ''), 'eng': ('en', ''), 'english': ('en', ''),
        'ko': ('multi', 'Korean'), 'kor': ('multi', 'Korean'), 'korean': ('multi', 'Korean'),
    }
    if low in exact_codes:
        return exact_codes[low]
    if any(re.search(pattern, low, re.I) for pattern in _MULTI_PATTERNS):
        return 'multi', 'Multi'

    found: list[tuple[str, str]] = []
    for code, patterns in _LANG_PATTERNS.items():
        if any(re.search(pattern, low, re.I) for pattern in patterns):
            found.append((code, {'pl': 'Polish', 'de': 'German', 'en': 'English'}[code]))
    for token, label in _OTHER_LANGS.items():
        if re.search(r'\b%s\b' % re.escape(token), low, re.I):
            found.append(('multi', label))

    # De-duplicate while retaining labels for diagnostics/source info.
    unique_codes = []
    unique_labels = []
    for code, label in found:
        if code not in unique_codes:
            unique_codes.append(code)
        if label not in unique_labels:
            unique_labels.append(label)
    if not unique_codes:
        return None, ''
    if len(unique_codes) > 1 or ('multi' in unique_codes and len(unique_labels) > 1):
        return 'multi', 'Multi'
    code = unique_codes[0]
    if code == 'multi':
        return 'multi', unique_labels[0] if len(unique_labels) == 1 else 'Multi'
    return code, ''


def _subject_language_hint(subject: object) -> tuple[Optional[str], str]:
    """Return only explicit catalogue *audio/dub* metadata for one subject.

    A generic ``language``/``lang`` field can describe the title's original
    production language rather than the selected MovieBox stream. Using it as
    audio evidence would mislabel e.g. a Polish production with a German dub.
    """
    if not isinstance(subject, dict):
        return None, ''

    values = []
    keys = (
        'audioLanguage', 'audio_language', 'audioLanguages', 'audio_languages',
        'dub', 'dubbing', 'dubLanguage', 'dub_language',
        'dubLanguages', 'dub_languages', 'voiceLanguage', 'voice_language',
    )
    for key in keys:
        value = subject.get(key)
        if value in (None, '', [], {}):
            continue
        if isinstance(value, dict):
            for subkey in ('name', 'label', 'title', 'code', 'language', 'lang'):
                subvalue = value.get(subkey)
                if subvalue not in (None, ''):
                    values.append(subvalue)
        elif isinstance(value, (list, tuple, set)):
            for item in value:
                if isinstance(item, dict):
                    for subkey in ('name', 'label', 'title', 'code', 'language', 'lang'):
                        subvalue = item.get(subkey)
                        if subvalue not in (None, ''):
                            values.append(subvalue)
                elif item not in (None, ''):
                    values.append(item)
        else:
            values.append(value)

    found = []
    for value in values:
        lang, info = _language_from_text(value)
        if lang and (lang, info) not in found:
            found.append((lang, info))
    if not found:
        return None, ''

    codes = {lang for lang, _ in found}
    if len(codes) > 1:
        return 'multi', 'Multi'
    lang = found[0][0]
    if lang != 'multi':
        return lang, ''
    labels = {info for _, info in found if info and info != 'Multi'}
    if len(labels) == 1:
        return 'multi', next(iter(labels))
    return 'multi', 'Multi'


def _mapping_language(mapping: object) -> tuple[Optional[str], str]:
    if not isinstance(mapping, dict):
        return None, ''
    candidates = []
    for key, value in mapping.items():
        if isinstance(value, (str, int, float)) and (
            _LANGUAGE_FIELD_RE.search(str(key)) or str(key).lower() in ('label', 'name')
        ):
            candidates.append(value)
    found = []
    for value in candidates:
        lang, info = _language_from_text(value)
        if lang:
            found.append((lang, info))
    if not found:
        return None, ''
    codes = {lang for lang, _ in found}
    if len(codes) > 1 or 'multi' in codes and len(found) > 1:
        return 'multi', 'Multi'
    return found[0]


def _resource_id(mapping: object) -> str:
    if not isinstance(mapping, dict):
        return ''
    for key in _RESOURCE_ID_KEYS:
        value = mapping.get(key)
        if value not in (None, ''):
            return str(value)
    resource = mapping.get('resource')
    if isinstance(resource, dict):
        for key in ('id', *_RESOURCE_ID_KEYS):
            value = resource.get(key)
            if value not in (None, ''):
                return str(value)
    return ''


def _resource_detectors(payload: object) -> list[dict]:
    """Find MovieBox resourceDetectors without treating subtitle metadata as audio."""
    if isinstance(payload, dict):
        value = payload.get('resourceDetectors')
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]
        for key, child in payload.items():
            if 'caption' in str(key).lower() or 'subtitle' in str(key).lower():
                continue
            found = _resource_detectors(child)
            if found:
                return found
    elif isinstance(payload, list):
        for child in payload:
            found = _resource_detectors(child)
            if found:
                return found
    return []


def _detector_language_map(payload: object) -> tuple[dict[str, tuple[str, str]], list[tuple[str, str]]]:
    by_resource: dict[str, tuple[str, str]] = {}
    all_languages: list[tuple[str, str]] = []
    for detector in _resource_detectors(payload):
        lang, info = _mapping_language(detector)
        if not lang:
            # Some API revisions keep the readable label under title/description.
            for key in ('title', 'description', 'displayName', 'resourceName'):
                lang, info = _language_from_text(detector.get(key))
                if lang:
                    break
        if not lang:
            continue
        rid = _resource_id(detector)
        if rid:
            by_resource[rid] = (lang, info)
        if (lang, info) not in all_languages:
            all_languages.append((lang, info))
    return by_resource, all_languages


def _detector_variants(payload: object) -> list[tuple[str, str, str]]:
    """Return (resource_id, language_bucket, label) for selectable audio dubs.

    MovieBox's detail endpoint describes *available* dubbed resources.  They are
    alternatives, not audio tracks bundled in one stream.  Treating the whole
    list as one source was the reason a Polish-only playback was shown as MULTI.
    """
    variants: list[tuple[str, str, str]] = []
    seen: set[str] = set()
    for detector in _resource_detectors(payload):
        rid = _resource_id(detector)
        if not rid or rid in seen:
            continue
        lang, info = _mapping_language(detector)
        if not lang:
            for key in ('name', 'title', 'description', 'displayName', 'resourceName'):
                raw = detector.get(key)
                lang, info = _language_from_text(raw)
                if lang:
                    break
        if not lang:
            # A named dub that is outside the PL/DE/EN dictionary is still a
            # real single-language variant. Expose it in Kadr+'s MULTI/other
            # bucket rather than pretending it is English.
            raw = str(detector.get('name') or detector.get('title') or '').strip()
            cleaned = re.sub(r'\b(?:dub(?:bed)?|audio|language)\b', ' ', raw, flags=re.I)
            cleaned = re.sub(r'\s+', ' ', cleaned).strip(' -_/')
            if cleaned and len(cleaned) <= 40:
                lang, info = 'multi', cleaned
        if not lang:
            continue
        seen.add(rid)
        variants.append((rid, lang, info))

    priority = {'pl': 0, 'de': 1, 'en': 2, 'multi': 3}
    variants.sort(key=lambda item: (priority.get(item[1], 9), item[2].casefold(), item[0]))
    return variants


def _aggregate_languages(values: list[tuple[str, str]]) -> tuple[Optional[str], str]:
    values = [(lang, info) for lang, info in values if lang]
    if not values:
        return None, ''
    codes = {lang for lang, _ in values}
    if len(codes) > 1:
        return 'multi', 'Multi'
    lang = values[0][0]
    if lang != 'multi':
        return lang, ''
    labels = {info for _, info in values if info and info != 'Multi'}
    if len(labels) == 1:
        return 'multi', next(iter(labels))
    return 'multi', 'Multi' if len(values) > 1 else values[0][1]


def _fetch_detail(subject_id: str) -> dict:
    if not subject_id:
        return {}
    with _detail_cache_lock:
        cached = _detail_cache.get(subject_id)
        if cached is not None:
            return cached
    detail_url = f'{_BASE}{_DETAIL_PATH}?subjectId={subject_id}'
    data = _api_request('GET', detail_url, timeout=8) or {}
    with _detail_cache_lock:
        _detail_cache[subject_id] = data
    return data


def _detect_stream_language(
    stream: dict,
    play_data: dict,
    detector_map: dict[str, tuple[str, str]],
    detector_languages: list[tuple[str, str]],
    hint: str = '',
    catalog_language: Optional[str] = None,
    catalog_language_info: str = '',
) -> tuple[str, str]:
    # 1) Best evidence: the actual stream object.
    lang, info = _mapping_language(stream)
    if lang:
        return lang, info

    # 2) Match the stream/play-info resource id to the detail endpoint's dub map.
    for obj in (stream, play_data):
        rid = _resource_id(obj)
        if rid and rid in detector_map:
            return detector_map[rid]

    # Do NOT aggregate every resourceDetector here. They are alternative dubs,
    # not multiple audio tracks bundled in one stream.

    # 3) Newer MovieBox clusters sometimes omit resourceDetectors entirely.
    # Use catalogue metadata only when it explicitly describes audio/dubbing;
    # never promote a generic original-production language to stream language.
    if catalog_language:
        return catalog_language, catalog_language_info

    # 4) Search titles can additionally carry [English]/[Polish]/[Multi Audio].
    lang, info = _language_from_text(hint)
    if lang:
        return lang, info

    # Never guess English. MovieBox also serves Korean/original-language audio.
    return 'multi', ''


_caption_cache: dict[tuple[str, str], list[dict]] = {}
_caption_cache_lock = threading.Lock()


def _fetch_captions(subject_id: str, stream_id: str) -> list[dict]:
    """extCaptions for one stream - cached so sources() and resolve() share it."""
    key = (subject_id, stream_id)
    with _caption_cache_lock:
        cached = _caption_cache.get(key)
        if cached is not None:
            return cached
    cap_url = f'{_BASE}{_CAPTIONS_PATH}?subjectId={subject_id}&streamId={stream_id}'
    data = _api_request('GET', cap_url)
    captions = (data or {}).get('extCaptions') or []
    with _caption_cache_lock:
        _caption_cache[key] = captions
    return captions


def _season_range_from_title(title: str) -> tuple[str, int, int]:
    """Strip trailing 'S<n>'/'S<n>-S<m>' + brackets -> (base_title, first, last).
    No marker -> (title, 1, 1)."""
    working = title
    for _ in range(2):  # bracket can come before or after the season marker
        match = _BRACKET_SUFFIX_RE.search(working)
        if not match:
            break
        working = working[:match.start()]
    match = _SEASON_RANGE_RE.search(working)
    if not match:
        return working.strip(), 1, 1
    first = int(match.group(1))
    last = int(match.group(2)) if match.group(2) else first
    return working[:match.start()].strip(), first, last


# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    ffitem: FFItem

    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['pl', 'de', 'en', 'multi']

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> Optional[str]:
        subject = self._find_subject(title, localtitle, year, want_season=False)
        if not subject:
            return None
        language, language_info = _subject_language_hint(subject)
        return json.dumps({
            'id': subject['subjectId'],
            'hint': subject.get('title', ''),
            'language': language or '',
            'language_info': language_info,
        })

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list[SourceTitleAlias], year: str) -> Optional[str]:
        # Season search needs a season number we don't have yet - defer to episode().
        return json.dumps({'title': tvshowtitle, 'localtitle': localtvshowtitle, 'year': year})

    def episode(self, url: Optional[str], imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> Optional[str]:
        if not url:
            return None
        try:
            show = json.loads(url)
        except Exception:
            return None
        subject = self._find_subject(show.get('title', ''), show.get('localtitle', ''), show.get('year', ''), want_season=True, season=int(season))
        if not subject:
            return None
        language, language_info = _subject_language_hint(subject)
        return json.dumps({
            'id': subject['subjectId'],
            'season': int(season),
            'episode': int(episode),
            'hint': subject.get('title', ''),
            'language': language or '',
            'language_info': language_info,
        })

    def sources(self, url: Optional[str], hostDict: List[str], hostprDict: List[str]) -> 'List[SourceItem]':
        results: List[SourceItem] = []
        if not url:
            return results
        try:
            info = json.loads(url)
        except Exception:
            return results
        subject_id = info.get('id')
        if not subject_id:
            return results

        season, episode = info.get('season'), info.get('episode')
        hint = str(info.get('hint') or '')
        catalog_language = str(info.get('language') or '').strip().lower() or None
        catalog_language_info = str(info.get('language_info') or '').strip()

        def _play_url(resource_id: str = '') -> str:
            value = f'{_BASE}{_PLAYINFO_PATH}?subjectId={subject_id}'
            if season and episode:
                value += f'&se={season}&ep={episode}'
            if resource_id:
                value += f'&resourceId={resource_id}'
            return value

        # First fetch the normal response. It remains the compatibility fallback
        # for titles that do not expose resourceDetectors.
        default_data = _api_request('GET', _play_url())
        if not default_data:
            return results

        detail = _fetch_detail(str(subject_id))
        detector_map, detector_languages = _detector_language_map(detail or default_data)

        # Search metadata is carried into the episode/movie token. If an older
        # token lacks it, try the detail/play-info payload before falling back.
        if not catalog_language:
            catalog_language, catalog_language_info = _subject_language_hint(detail)
        if not catalog_language:
            catalog_language, catalog_language_info = _subject_language_hint(default_data)
        if not catalog_language:
            # Do not promote TMDB/Kadr+'s *original production language* to an
            # audio-track label. A Polish production can be served by MovieBox
            # with a German dub (and vice versa), so that metadata is not proof
            # of the selected stream's language. Keep it only as diagnostic
            # context and fall back to Kadr+'s MULTI/other bucket when MovieBox
            # itself exposes no usable audio/dub metadata.
            try:
                original_languages = [
                    str(code or '').strip().lower()
                    for code in self.ffitem.vtag.getLanguageCodes()
                    if str(code or '').strip()
                ]
            except Exception:
                original_languages = []
            _diag(
                'catalog-fallback',
                'result=unknown; original=' + (','.join(original_languages) if original_languages else 'unknown'),
            )
        _diag('catalog', f'language={catalog_language or "unknown"}')

        variants = _detector_variants(detail)
        if not variants:
            variants = _detector_variants(default_data)

        _diag('detectors', f'count={len(variants)}')

        seen_sources: set[tuple[str, str, str]] = set()

        def _append_streams(play_data: dict, language_override: Optional[str] = None, language_info_override: str = '') -> int:
            added = 0
            streams = play_data.get('streams') or play_data.get('streamList') or []
            for stream in streams:
                file_url = stream.get('url')
                if not file_url:
                    continue
                heights = [int(height_str) for height_str in re.findall(r'\d+', str(stream.get('resolutions') or ''))]
                height = max(heights, default=0)
                quality = quality_from_resolution(height=height)
                sign_cookie = stream.get('signCookie') or ''
                if sign_cookie:
                    file_url += append_headers({'Cookie': sign_cookie})
                stream_id = str(stream.get('id', ''))
                locator = f'{_SCHEME}{subject_id}:{stream_id}:{file_url}'
                language, language_info = (language_override, language_info_override) if language_override else _detect_stream_language(
                    stream, play_data, detector_map, detector_languages, hint,
                    catalog_language, catalog_language_info,
                )
                language = language or 'multi'
                dedupe_key = (locator, language, quality)
                if dedupe_key in seen_sources:
                    continue
                seen_sources.add(dedupe_key)

                captions = _fetch_captions(str(subject_id), stream_id) if stream_id else []
                has_pl_sub = any((caption.get('lan') or '').lower() == 'pl' for caption in captions)
                codec = stream.get('codecName', '') or ''
                info_parts = [part for part in (codec, language_info) if part]
                results.append({
                    'source': 'MovieBox',
                    'quality': quality,
                    'language': language,
                    'url': locator,
                    'info': ' | '.join(info_parts),
                    'info2': 'NAPISY' if has_pl_sub else '',
                    'size': convert_size(int(stream['size'])) if stream.get('size') else '',
                    'filename': '',
                    'direct': True,
                    'debridonly': False,
                })
                added += 1
            return added

        variant_added = 0
        # A single detector is the only available dub, so the default play-info
        # is already unambiguous and no extra request is needed.
        if len(variants) == 1:
            _, language, language_info = variants[0]
            variant_added = _append_streams(default_data, language, language_info)
            if variant_added:
                _diag('variant', f'language={language}; streams={variant_added}; mode=single')
        else:
            # Multiple resourceDetectors are alternative dubs. Ask play-info for
            # each resourceId so a Polish dub is labelled PL, an English dub EN,
            # etc. Cap the fan-out to keep source search responsive.
            for resource_id, language, language_info in variants[:6]:
                play_data = _api_request('GET', _play_url(resource_id), timeout=8)
                if not play_data:
                    continue
                added = _append_streams(play_data, language, language_info)
                variant_added += added
                if added:
                    _diag('variant', f'language={language}; streams={added}; mode=resource')

        if not variant_added:
            # Old/partial API response: keep playback working, but never derive
            # MULTI merely from the list of alternative detector languages.
            _append_streams(default_data)

        _diag('result', f'sources={len(results)}')
        fflog(f'sources: {len(results)}')
        return results

    def resolve(self, url: str) -> Optional[str]:
        if not url.startswith(_SCHEME):
            return url
        try:
            _, subject_id, stream_id, cdn_url = url.split(':', 3)
        except ValueError:
            return None
        self._attach_captions(subject_id, stream_id)
        # 'isa+' makes player.py parse the |Cookie=... suffix into ISA headers;
        # DRMFF's dict path does url.split('|')[-1] instead, which breaks here.
        if '.mpd' in cdn_url.split('|', 1)[0]:
            return f'isa+{cdn_url}'
        return cdn_url

    # ── helpers ────────────────────────────────────────────────────────────

    def _find_subject(self, title: str, localtitle: str, year: str, want_season: bool, season: int = 1) -> Optional[dict]:
        want_type = 2 if want_season else 1
        for query in search_queries(title, localtitle):
            fflog(f'query: {query!r}')
            target = cleantitle.get(query)
            for subject in _search(query):
                if subject.get('subjectType') != want_type:
                    continue
                base_title, season_first, season_last = _season_range_from_title(subject.get('title', ''))
                if cleantitle.get(base_title) != target:
                    continue
                if want_season and not (season_first <= season <= season_last):
                    continue
                if not want_season and year:
                    release_year = (subject.get('releaseDate') or '')[:4]
                    if release_year and not year_matches(release_year, int(year)):
                        continue
                fflog(f"matched {subject.get('title')!r} -> subjectId={subject.get('subjectId')}")
                return subject
        fflog(f'no match for {title!r}')
        return None

    def _attach_captions(self, subject_id: str, stream_id: str) -> None:
        if not stream_id:
            return
        captions = _fetch_captions(subject_id, stream_id)
        if not captions:
            return
        try:
            # Register all subtitles in one request. set_media_files() replaces
            # the service-side media map, so registering every caption from
            # parallel threads used to leave only the last file available.
            workers = max(1, min(8, len(captions)))
            with ThreadPoolExecutor(max_workers=workers) as pool:
                downloaded = [item for item in pool.map(self._download_caption, captions) if item]
            if not downloaded:
                return
            media_files = {key: text for key, text in downloaded}
            service_client.set_media_files(media_files)
            media_base = urljoin(service_client.url, '/media')
            subtitle_urls = [media_base + key for key, _ in downloaded]
            control.window().setProperty('source.subtitles', json.dumps(subtitle_urls))
            fflog(f'{len(subtitle_urls)} subtitle(s) passed to player')
            _diag('subtitles', f'count={len(subtitle_urls)}')
        except Exception:
            fflog_exc()

    @staticmethod
    def _download_caption(caption: dict) -> Optional[tuple[str, str]]:
        """Download one caption and return a safe local service key + text."""
        file_url = caption.get('url')
        if not file_url:
            return None
        try:
            resp = _session.get(file_url, timeout=15)
            if resp.status_code != 200:
                return None
            raw_ext = file_url.split('?', 1)[0].rsplit('.', 1)[-1].lower()
            ext = raw_ext if raw_ext in ('srt', 'vtt', 'ass', 'ssa') else 'srt'
            lan = re.sub(r'[^a-z0-9_-]+', '_', str(caption.get('lan') or 'und').lower())[:24] or 'und'
            caption_id = re.sub(r'[^a-zA-Z0-9_-]+', '_', str(caption.get('id') or '')).strip('_')[:64]
            if not caption_id:
                caption_id = hashlib.sha256(file_url.encode('utf-8')).hexdigest()[:16]
            key = f'/moviebox_sub_{caption_id}.{lan}.{ext}'
            return key, resp.text
        except Exception:
            fflog_exc()
            return None
