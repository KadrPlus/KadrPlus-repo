"""
    Kadr+ 2.0 Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import annotations
import sty  # XXX XXX XXX

# from pathlib import Path
# import re
import json
# from enum import Enum
from time import monotonic
from weakref import WeakSet
from itertools import chain
from urllib.parse import urlsplit
# from pprint import pformat  # DEV LOGS
from typing import Optional, Union, Any, Tuple, List, Dict, Set, Callable, Sequence, Iterable, overload, TYPE_CHECKING
from typing_extensions import cast
from attrs import define, frozen, Factory, field

import xbmc
from xbmc import getInfoLabel, getCondVisibility, Player as XbmcPlayer, PlayList as XbmcPlayList
from xbmcgui import ListItem
from random import randint

# Some consts.
from const import const, MediaWatchedMode
from ..indexers.core import Indexer
from ..main import reset

from ..defs import MediaRef, RefType, MediaType, MainMediaType, FFRef
from ..ff import cache, control
from ..ff.threads import Thread, Event, Queue
from ..ff.trakt import trakt, ScrobbleAction
from ..ff.settings import settings, advanced_settings
from ..ff.db import state
from ..ff.db.playback import MediaPlayInfo, get_playback_item, update_track_watched_item
from ..ff.item import FFItem, FFItemDict
from ..ff.info import ffinfo
from ..ff.calendar import utc_timestamp
from ..ff.tricks import suppress, str_removeprefix
from ..ff.kotools import xsleep, get_player_item, stop_playing, KodiLibraryType, KodiRpc
from ..ff.kodidb import KodiVideoDB, KodiVideoInfo, video_db, load_strm_file
from ..ff.log_utils import fflog, fflog_exc
from ..ff.types import Params
from ..indexers.defs import VideoIds
from .exc import ExitBaseException, KodiExit
from .misc import VolatileFfid, PluginRequestInfo, TreeFolderInfo, FFState, update_playback_db_by_kodi_info
from ..indexers.lists import ListsInfo
from ..ff.debug.timing import logtime  # XXX DEBUG
from .http_server import HttpProxy
from .web_server import WebServer
from .tracking import TrackingService, tracking_service
from .tracking.trakt import TraktSync, TraktSender
from ..kolang import L
if TYPE_CHECKING:
    from .misc import LibraryAutoAddSource
    from .reload import ReloadMonitor
    from .library import Library, Batch
    from ..ff.types import JsonData
    from ..api.trakt import PlayContentType, HistoryContentType, Ids as TraktIds

# start sync on addon start (default: True), False for dev/testing (CLI)
START_SYNC_ON_START = True
# hack, for state in service mode
state.SERVICE = True
# reset some stuff on script relaod
reset()
#: skip blank
OMIT_FILE = 'tt430.mp4'


# FF plugin path
plugin_id: str = control.plugin_id
plugin_url: str = control.plugin_url


def _normalize_kodi_eof(*, kodi_ended: bool, stop_progress: float,
                        watched_threshold: float, progress_known: bool,
                        telegram_eof: Optional[bool],
                        seek_unvalidated: bool = False) -> tuple[bool, str]:
    """Separate a completed play from a genuinely interrupted stream.

    ``stream_reached_eof()`` only tells us whether Telegram happened to fetch
    the physical last byte of the container.  With FFmpeg Direct/HTTP Range a
    perfectly valid MP4 playback can finish without ever requesting that byte,
    so a negative Telegram EOF must not override Kodi's real end notification
    once playback is already in the watched region.
    """
    progress = max(0.0, min(100.0, float(stop_progress or 0)))
    threshold = max(0.0, min(100.0, float(watched_threshold or 0)))

    # Some inputstreams can close the player with end=False after the last frame.
    # A sampled position essentially at 100% is strong enough to treat that as a
    # completed play.
    if progress_known and progress >= 99.5:
        return True, ''

    # A seek notification alone is not proof that playback resumed at the target.
    # Keep an immediate failed seek interrupted even if the transport reports EOF.
    if seek_unvalidated:
        return False, 'seek-not-validated'

    if not kodi_ended:
        return False, ''

    # Kodi explicitly says the playable item reached its end.  Honour that only
    # in the configured watched region.  The physical Telegram
    # EOF is deliberately secondary because MP4 index/trailer bytes need not be
    # read during normal playback.
    if progress_known:
        if progress < threshold:
            return False, 'below-watched-threshold-%.1f' % threshold
        return True, ''

    # If no trustworthy player progress survived OnStop, retain the conservative
    # physical-EOF fallback rather than guessing that a transport error finished.
    if telegram_eof is False:
        return False, 'telegram-file-incomplete'
    return True, ''


@define
class MediaNotifInfo:
    #: Real media type (movie or episode).
    type: RefType
    #: Video FFID.
    ffid: int
    #: Movie or episode IDs for query old FF links in kodi db.
    item: FFItem
    #: Movie or episode Kodi DB video info.
    kodi_info: KodiVideoInfo
    #: Trakt playback (event if not trakt credentials, will be ignored in this case)
    playback: MediaPlayInfo
    #: Denormalized ref.
    de_ref: MediaRef

    @property
    def ref(self) -> MediaRef:
        """Movie or episode ref (normalized)."""
        return self.item.ref

    @property
    def denormalized_ref(self) -> MediaRef:
        """Movie or episode ref (denormalized)."""
        return MediaRef(self.type, self.ffid)

    @property
    def history_type(self) -> HistoryContentType:
        """Movie or episode ref (normalized)."""
        # hack: movie -> movies, episode -> episodes
        return cast(HistoryContentType, f'{self.type}s')

    @property
    def ids(self) -> TraktIds:
        """Returns item ids. Convert type only, data already are OK."""
        if TYPE_CHECKING:
            return cast(TraktIds, self.item.ids)
        return self.item.ids


@frozen(kw_only=True)
class SeekInfo:
    """Seek delta and target time from xbmc.Player.OnSeek notification."""
    # Signed seek delta (negative when seeking backwards).
    offset: float
    # Absolute playback time after the seek.
    time: float
    # Playing speed factor.
    speed: float = 1

    @property
    def progress(self) -> float:  # 0 .. 100
        return 100 * self.offset / self.time if self.time > 0 else 0

    def progress_for_time(self, time: float) -> float:  # 0 .. 100
        # Kodi's player.seekoffset is a signed delta, not a position.  The
        # absolute position after seek lives in player.time.
        return 100 * self.time / time if time > 0 else 0


@frozen(kw_only=True)
class AddToLibraryRequest:
    """Info for adding to library request."""
    items: Sequence[FFRef]
    name: str
    sync: bool | None = None
    quiet: bool = False
    reload_after: bool = True   # False for intermediate chunks — skip UpdateLibrary
    dedup: set[MediaRef] | None = None


@define
class Work:
    name: str
    func: Callable[..., None]
    interval: int = 0
    thread: Optional[Thread] = None
    break_event: Event = Factory(Event)

    def force_call(self):
        """Force re-call cyclic function now."""
        self.break_event.set()


@define
class Works:
    #: Jobs (DB requests).
    jobs: Work | None = None
    #: Trakt sync thread object.
    trakt_sync: TraktSync | None = None
    #: All events (shared with HTTP server).
    events: Dict[str, Event] = Factory(dict)
    #: Volatile FFID.
    volatile_ffid: VolatileFfid = Factory(VolatileFfid)
    #: Folder info and history.
    folder: PluginRequestInfo = Factory(PluginRequestInfo)
    #: HTTP proxy (service) server.
    http: HttpProxy | None = None
    #: WEB server.
    web: WebServer | None = None
    #: General state virtual DB.
    state: FFState = Factory(FFState)
    #: Tracking services (trakt, ...).
    tracking_service: TrackingService = tracking_service
    #: Library service (adding items in the background).
    library: Library | None = None
    #: Library service (adding items in the background).
    library_jobs: Queue[AddToLibraryRequest] = field(factory=Queue)
    #: Methods to library auto add.
    library_auto_add: dict[LibraryAutoAddSource, Callable[[], None]] = field(factory=dict)

    def reset(self):
        """Destroy all cyclic workers."""
        if self.jobs:
            self.jobs.break_event.set()
        if self.trakt_sync:
            self.trakt_sync.stop()
        if self.http:
            self.http.stop()
        if self.web:
            self.web.stop()
        if self.library:
            self.library.stop()
        self.jobs = None
        self.trakt_sync = None
        self.events.clear()
        self.volatile_ffid = VolatileFfid()
        self.folder = PluginRequestInfo()
        self.http = None
        self.web = None
        self.state = FFState()
        self.tracking_service = TrackingService()
        self.library = None
        self.library_jobs = Queue()
        self.library_auto_add.clear()



# All cyclic workers.
works = Works()

# Base events.
works.events['folder'] = Event()
works.events['folder'].set()  # ready by default


def hash_bar(text: Optional[str] = None, *, stack_depth: int = 1) -> None:
    """Log ##### bar with text in the center."""
    width = 63
    if text is None:
        fflog("#" * width, stack_depth=stack_depth+1)
    else:
        text = f" {text} "
        fflog(f"{text:#^{width}}", stack_depth=stack_depth+1)


def hash_box(lines: List[str], *, ff: bool = False, stack_depth: int = 1) -> None:
    """Log text in ##### box. If `ff` is True, log "FANFILM" in header. """
    hash_bar("FANFILM" if ff else None, stack_depth=stack_depth+1)
    for line in lines:
        hash_bar(line, stack_depth=stack_depth+1)
    hash_bar(None, stack_depth=stack_depth+1)


def hash_bar_next(settting_name: str, title: str = '', stack_depth: int = 1) -> None:
    """Log update info, plus next in H hours."""
    hours = settings.getInt(settting_name)
    hash_bar(f"{title or settting_name} UPDATE - NEXT ON {hours} HOURS", stack_depth=stack_depth+1)


def cyclic_call(interval: Union[int, Tuple[int, int]], func: Callable[..., None], *args: Any, **kwargs) -> Optional[Work]:
    def calling():
        interval = first_interval
        try:
            while not monitor.abortRequested():
                if const.debug.autoreload:
                    from .reload import ReloadMonitor
                    if ReloadMonitor.reloading:
                        break
                xsleep(interval, cancel_event=work.break_event)
                settings.delete()
                func(*args, **kwargs)
                interval = next_interval
                if not interval:
                    return
        except ExitBaseException:
            return
        except Exception:
            fflog_exc()
            raise

    if not interval:
        return None
    if isinstance(interval, Sequence):
        first_interval, next_interval = interval
    else:
        first_interval = next_interval = interval
    thread = Thread(target=calling)
    thread.name = f'{thread.name}: {func.__qualname__}'
    work = Work(thread=thread, func=func, name=func.__qualname__, interval=next_interval)
    thread.start()
    threads.add(thread)
    return work


@define
class SkipUpdate:
    """Info what to skip."""
    #: skip is valid until `timestamp'
    timestamp: float = 0
    #: Parent ref of skipped media.
    parent: Optional[MediaRef] = None
    #: Parent ref of skipped media.
    refs: Set[MediaRef] = Factory(set)
    #: Is playcount incremented?
    playcount: bool = False

    def __bool__(self) -> bool:
        return bool(self.refs)


class FFMonitor(xbmc.Monitor):
    """FF monitor."""

    VTYPES: Dict[str, RefType] = {
        'tvshow': 'show',
    }

    def __init__(self, *, selfcheck: bool = True):
        super().__init__()
        self.selfcheck: bool = bool(selfcheck)
        self._indexer: Optional[Indexer] = None
        self.reload_monitor: Optional['ReloadMonitor'] = None
        self.kodidb: KodiVideoDB = video_db
        #: Plugin needs refresh (run update)
        self.need_refresh: bool = False
        #: Plugin needs refresh (run update) - for sure.
        self.force_refresh: bool = False
        #: True if working, else exit from monitor loop.
        self.working: bool = True
        #: Player state dict.
        self.player_info: Dict[str, Any] = {}
        #: Playing now media denormalized reference (FFID).
        self.playing_media_de_ref: Optional[MediaRef] = None
        #: Full ff-item of playing media
        self.playing_ffitem: Optional[FFItem] = None
        #: All  itms needed to support playing media progress.
        self.playing_items: Optional[FFItemDict] = None
        #: What to skip and when.
        self.skip_updates: SkipUpdate = SkipUpdate()
        #: Current playing Kodi ListItem. Set on OnPlay, remove after OnStop.
        self.playing_item: Optional[ListItem] = None
        #: Last progress read while Kodi still had an active player.  Player.OnStop
        #: arrives after the player can already be closed, so getTime()/getTotalTime()
        #: is no longer reliable there.  Keep this only in memory; it is refreshed
        #: every service tick and on pause/resume/seek.
        self.last_live_progress: Optional[float] = None
        #: EOF snapshot taken if the fast orphan-stop runs before Player.OnStop.
        self.last_telegram_eof: Optional[bool] = None
        #: A seek target is not treated as actually watched until Kodi's live
        #: playback clock advances after the seek.  This prevents a failed seek
        #: straight to the end from turning into a watched item.
        self.seek_pending_validation: bool = False
        self.seek_target_time: Optional[float] = None
        self.seek_target_progress: Optional[float] = None
        self.seek_validation_position: Optional[float] = None
        self.seek_pre_progress: Optional[float] = None
        #: True, if library is scanning.
        self.lib_scanning: bool = False
        #: JsonRPC client for Kodi RPC calls.
        self.rpc = KodiRpc()

        # XXX
        self._cnt = 0

    def run(self) -> None:
        while self.working and not self.abortRequested():
            # fflog(f'FFMonitor.run... ans={service.ans}')
            # state.add_job('plugin', 'dupa', ('blada', 'ciemna'), sender='service')
            interval = self._monitor_check_interval()
            if self.waitForAbort(interval):
                break
            # Sample progress while the player is still alive. Kodi may close the
            # player before delivering Player.OnStop, which makes a late getTime()
            # raise and previously lost the resume point on a plain Stop.
            self._sample_live_playback_progress()
            # Kodi can spend tens of seconds shutting a stalled HTTP stream down
            # before Player.OnStop arrives. As soon as its player is actually gone,
            # stop only the matching local Telegram job so it cannot keep pulling
            # hundreds of MiB in the background while the UI waits to return.
            self._stop_orphaned_telegram_stream()
            if self.selfcheck and self.reload_monitor:
                self.reload_monitor.check()  # raises ReloadExit on any change
        raise KodiExit()

    def _monitor_check_interval(self) -> float:
        """Poll active Kadr+ playback at half-second cadence.

        The service normally sleeps for three seconds.  That is too coarse for a
        seek followed by Stop a couple of seconds later: the whole validated
        playback window can otherwise fall between two service ticks.  While a
        Kadr+ video is active, lightweight player-time sampling therefore runs at
        0.5 s; idle Kodi keeps the established cadence.  Telegram also benefits
        from the same interval for prompt Range cancellation.
        """
        try:
            interval = max(0.1, float(const.tune.service.check_interval))
        except (TypeError, ValueError):
            interval = 3.0
        if self.player_info.get('playing.video', False):
            return min(interval, 0.5)
        return interval

    @property
    def indexer(self) -> Indexer:
        if self._indexer is None:
            self._indexer = Indexer()
        return self._indexer

        # --- start from beginning (old code) ---
        # Info.OnChanged          None
        # Player.OnPlay           {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnAVChange       {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnSeek           {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1,
        #                             'seekoffset': {'hours': 0, 'milliseconds': 0, 'minutes': 10, 'seconds': 0},
        #                             'time': {'hours': 0, 'milliseconds': 470, 'minutes': 10, 'seconds': 5}}}
        # <FF enter>
        # VideoLibrary.OnUpdate  {'item': {'id': 170244501, 'type': 'movie'}}
        # VideoLibrary.OnUpdate  {'id': 170244501, 'type': 'movie'}
        # Player.OnStop          {'end': False, 'item': {'id': 170244501, 'type': 'movie'}}

        # --- resume (kodi) ---
        # <ff enter>             action=play&imdb=tt17024450&tmdb=926393
        # Playlist.OnAdd         {'item': {'id': 170244501, 'type': 'movie'}, 'playlistid': 1, 'position': 0}
        # <ff exit>
        # Info.OnChanged         None
        # Player.OnPlay          {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnAVChange      {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnSeek          {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1,
        #                            'seekoffset': {'hours': 0, 'milliseconds': 0, 'minutes': 10, 'seconds': 0},
        #                            'time': {'hours': 0, 'milliseconds': 149, 'minutes': 32, 'seconds': 18}}}
        # VideoLibrary.OnUpdate  {'item': {'id': 170244501, 'type': 'movie'}}
        # VideoLibrary.OnUpdate  {'id': 170244501, 'type': 'movie'}
        # Player.OnStop          {'end': False, 'item': {'id': 170244501, 'type': 'movie'}}
        # <ff enter>             action=movies&url=tmdb_popular

        # --- to the end (no user action at all)
        # ...
        # <ff enter>             action=movies&url=tmdb_popular
        # VideoLibrary.OnUpdate  {'item': {'id': 170244501, 'type': 'movie'}, 'playcount': 2}
        # VideoLibrary.OnUpdate  {'id': 170244501, 'type': 'movie'}
        # Player.OnStop         {'end': True, 'item': {'id': 170244501, 'type': 'movie'}}

        # --- cancel sources ---
        # Player.OnStop          {'end': True, 'item': {'id': 170244501, 'type': 'movie'}}
        # Info.OnChanged         None
        # Player.OnPlay          {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}

        # --- pure video file ---
        # Playlist.OnAdd'        {'item': {'title': 'Watch True Lies (1994) Full Movie Online Free  Movie  TV Online HD Quality.mp4',
        #                         'type': 'movie'}, 'playlistid': 1, 'position': 0}
        # Player.OnPlay          {'item': {'title': 'Watch True Lies (1994) Full Movie Online Free  Movie  TV Online HD Quality.mp4',
        #                         'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnAVChange x2, Player.OnAVStart ...
        # VideoLibrary.OnUpdate  {'id': -1, 'type': ''}
        # Player.OnStop          {'end': True, 'item': {'title': 'smediaPL--Most nad Sundem S02E07 Lektor PL.[CDA:12827975cd].mp4', 'type': 'movie'}}

        # --- set as watched ---
        # VideoLibrary.OnUpdate  {'item': {'id': 182713481, 'type': 'episode'}, 'playcount': 1}

        # --- set as unwatched ---
        # VideoLibrary.OnUpdate  {'item': {'id': 182713481, 'type': 'episode'}, 'playcount': 0}

        # --- reset progress  ---
        # VideoLibrary.OnUpdate  ...

        # --- others ---
        # System_OnSleep         None
        # System_OnWake          None

        # --- widget ---
        # Player.OnPlay          {'item': {'type': 'unknown'}, 'player': {'playerid': -1, 'speed': 1}}

        # ---
        # Info.OnChanged    - called on CGUIInfoManager::SetCurrentItem, when ListItem info changed?

        # Logika
        # ------
        # przed  Trakt | 0 ½ | 0 e | 0 ½ | 0 e | 1 ½ | 1 e | 1 ½ | 1 e |
        #         Kodi | 0 ½ | 0 e | 1 ½ | 1 e | 0 ½ | 0 e | 1 ½ | 1 e |
        #       folder | 0         | 1         | 1         | 1         |
        # -------------+-----+-----+-----+-----+-----+-----+-----+-----+
        # po   db Kodi | 0 D | 1 _ | 0 D | 1 _ | 0 D | 1 _ | 2 D | 2 _ |
        #        Trakt | 0 D | 1 _ | 1 D | 1 _ | 1 _ | 1 _ | 1 D | 1 _ |

    def onScanStarted(self, library: str) -> None:
        """The video or music library scan has been started, called by Kodi."""
        lib = cast(KodiLibraryType, library)
        if lib == 'video':
            self.lib_scanning = True

    def onScanFinished(self, library: str) -> None:
        """The video or music library has been scanned, called by Kodi."""
        lib = cast(KodiLibraryType, library)
        if lib == 'video':
            self.lib_scanning = False

    # @suppress(Exception, log_traceback=True)
    def onNotification(self, sender: str, method: str, data: str) -> None:
        """Notification, called by Kodi."""
        self._cnt += 1
        cnt = self._cnt
        if sender == 'xbmc' and method == 'VideoLibrary.OnUpdate' and data and json.loads(data).get('transaction') is True:
            fflog(f'--- [{cnt:2d} / enter / exit : mass library update')
            return
        fflog(f'--- [{cnt:2d} / enter]')
        self.player_info = state.get_all(module='player')
        if const.debug.service_notifications:
            from .dev import spy
            spy.onNotification(sender, method, data)

        # works.events['folder'].clear()
        # fflog('[FOLDER] hold')
        _PLR = '\n'.join(f'  {k!r}: {v!r}' for k, v in self.player_info.items())
        fflog.debug(f' >> player_info = {{\n{_PLR}\n  }}')

        # skip updates no longer valid
        if self.skip_updates.parent and self.skip_updates.timestamp < monotonic():
            self.skip_updates.parent = None
            self.skip_updates.refs.clear()
            self.skip_updates.timestamp = 0

        # XXX DEBUG
        fflog(f'[SERVICE][PLAYING] {xbmc.Player().isPlaying()=}')
        if xbmc.Player().isPlaying():
            fflog(f'[SERVICE][PLAYING] {xbmc.Player().getPlayingFile()=}')

        try:
            if sender == plugin_id:
                self.handle_fanfilm(method, data)
            else:
                self.handle_notification(sender, method, data)
            fflog(f'--- [{cnt:2d} / exit]')
        except Exception:
            fflog_exc()
        except BaseException:
            fflog_exc()
            raise
        finally:
            # self.folder_ready()
            try:
                fflog(f'--- [{cnt:2d} / fin] folder_ready={works.events["folder"].is_set()}')
            except KeyError:
                fflog('works.events["folder"] MISSING !!!')

    def handle_fanfilm(self, method: str, data_str: str) -> None:
        """Handle Kadr+ 2.0 specific notifications."""
        method = str_removeprefix(method, 'Other.')
        data: JsonData = json.loads(data_str or '{}') or {}
        mid = data.get(KodiRpc.MESSAGE_ID_NAME, 0)

        if method == 'ServicePing':
            self.rpc.notify('ServicePong', data, id=mid, action='response')

    def handle_notification(self, sender: str, method: str, data_str: str) -> None:
        data: JsonData = json.loads(data_str or '{}') or {}
        # rx = re.compile(r'\W+')
        # notif: str = f'{rx.sub("_", sender)}__{rx.sub("_", method)}'
        notif = f'{sender}.{method}'

        def playing_empty() -> bool:
            """True if empty file is really playing."""
            player = XbmcPlayer()
            return player.isPlaying() and bool(path := player.getPlayingFile()) and OMIT_FILE in path

        # kodi playing ListItem.
        def dump_item(it: Optional[ListItem]) -> None:
            if it is None:
                fflog(f'[SERVICE] {notif} playing_item: None')
                return
            v = it.getVideoInfoTag()
            imdb = v.getIMDBNumber() or v.getUniqueID('imdb')
            tmdb = v.getUniqueID('tmdb')
            resume = f'{v.getResumeTime()} / {v.getResumeTimeTotal()}'
            fflog(f'[SERVICE] {notif} playing_item: {v.getIMDBNumber()=}, {imdb=}, {tmdb=}, {v.getDbId()=}, {v.getEpisode()=}, {it.getLabel()=}, {it.getPath()=}, {resume=}')
        #
        if notif in ('xbmc.Player.OnPlay', 'xbmc.Player.OnResume', 'xbmc.Playlist.OnAdd'):
            self.playing_item = get_player_item()
        dump_item(get_player_item())

        # guess, what happened
        should_playing: bool = self.player_info.get('playing.video', False)
        is_playing_now: bool = getCondVisibility('Player.Playing')
        try:
            if self.player_info.get('playing.empty') or playing_empty():
                self.handle_skip_playing(notif, data)
            elif self.player_info.get('playing.run'):
                self.handle_ff_play(notif, data)
            elif notif == 'xbmc.VideoLibrary.OnUpdate' and not data.get('added') and not is_playing_now and not should_playing:
                self.handle_library_watched(notif, data)
            elif (notif == 'xbmc.VideoLibrary.OnUpdate' and not self.player_info.get('state')
                  and isinstance((dbid := data.get('id')), int) and dbid > 0 and dbid not in VideoIds.KODI_DBID):
                self.handle_watched(notif, data)
            else:
                self.handle_other(notif, data)
        finally:
            # clear current playing item
            if notif == 'xbmc.Player.OnStop' or (notif == 'xbmc.Playlist.OnClear' and not is_playing_now):
                self.playing_item = None

    def handle_skip_playing(self, notif: str, data: JsonData) -> None:
        """Handle skip FF play (close sources window)."""
        fflog(f'[SERVICE][FFSKIP] {notif}')
        if notif == 'xbmc.Player.OnPlay':
            control.close_busy_dialog()
            stop_playing()
            self.set_state('state', 'canceling')
        elif notif == 'xbmc.Player.OnStop':
            self.clear_player_state('canceling')
            self.set_state('state', '')
        elif notif == 'xbmc.VideoLibrary.OnUpdate':
            # If video was playing... we need to finish previous video state.
            if self.player_info.get('playing.media.ref'):
                self.next_play(data=data)

    def handle_ff_play(self, notif: str, data: JsonData) -> None:
        """Handle FF3 playing (library too), all with plugin://plugin.videofanfilm[3]/..."""
        fflog(f'[SERVICE][FFPLAY] {notif}')
        if notif == 'xbmc.Player.OnPlay':
            # A new playback must never inherit the previous item's in-memory
            # fallback progress.
            self.last_live_progress = None
            self.last_telegram_eof = None
            self._reset_seek_validation()
            # Kodi may close the plugin's native busy window while accepting
            # the resolved URL. Reassert the exact playback owner here and keep
            # it until real audio/video starts, not merely until OnPlay.
            playback_session_id = str(
                self.player_info.get('playing.media.playback_session_id')
                or self.player_info.get('media.playback_session_id')
                or ''
            )
            if playback_session_id:
                control.busy_dialog(
                    True,
                    owner=playback_session_id,
                    owner_timeout=180.0,
                )
            # control.close_busy_dialog()  -- to early, the video could start a few seconds
            if info := self.item_info(data):
                # Kodi does not reliably expose play_count for plugin:// or local
                # HTTP streams (Telegram included).  Preserve the authoritative
                # Kadr+ playback DB count as the baseline, otherwise a second full
                # watch can look like the first one again and fail to increment
                # plays / first_time semantics.
                initial_play_count = max(
                    int(info.playback.play_count or 0),
                    int(info.kodi_info.play_count or 0),
                )
                self.set_state((
                    ('playing.progress', info.kodi_info.percent),
                    ('playing.play_count', initial_play_count),
                ))
            else:
                self.set_state((
                    ('playing.progress', 0),
                    ('playing.play_count', 0),
                ))
        elif notif == 'xbmc.Player.OnAVStart':
            playback_session_id = str(
                self.player_info.get('playing.media.playback_session_id')
                or self.player_info.get('media.playback_session_id')
                or ''
            )
            if playback_session_id:
                control.close_busy_dialog(owner=playback_session_id)
            else:
                control.close_busy_dialog()
            try:
                from ..ff import diagnostics
                diagnostics.log_event('playback', 'event=av-start; result=playing')
            except Exception:
                pass
            info = self.item_info(data)
            live_progress = self._read_live_player_progress()
            if live_progress is not None:
                self.last_live_progress = live_progress
            av_start_progress = self.current_player_progress(default=0)
            resume_mode = str(self.player_info.get('media.resume_mode') or 'auto')

            # Kodi may retain the start offset selected for the outer
            # plugin:// item even though the final resolved ListItem explicitly
            # says "from beginning".  Verify the live player at AVStart and make
            # the Kadr+ decision authoritative.  A normal AVStart can already be
            # a few seconds into playback while this service reads metadata, so
            # only treat a position beyond 15 seconds as a stale resume point.
            if resume_mode == 'beginning' and not bool(self.player_info.get('media.resume_applied', False)):
                self.set_state('media.resume_applied', True)
                beginning_result = 'native'
                beginning_position = 0.0
                beginning_total = 0.0
                try:
                    kodi_player = XbmcPlayer()
                    beginning_position = max(0.0, float(kodi_player.getTime() or 0.0))
                    beginning_total = max(0.0, float(kodi_player.getTotalTime() or 0.0))
                    if beginning_position > 15.0:
                        kodi_player.seekTime(0.0)
                        beginning_result = 'seek-zero'
                    live_progress = 0.0
                    self.last_live_progress = 0.0
                    av_start_progress = 0.0
                except Exception as exc:
                    beginning_result = 'failed-%s' % type(exc).__name__
                try:
                    from ..ff import diagnostics
                    diagnostics.log_event(
                        'playback',
                        'event=resume-apply; mode=beginning; result=%s; position=%.1f; total=%.1f'
                        % (beginning_result, beginning_position, beginning_total),
                        level=xbmc.LOGWARNING if beginning_result.startswith('failed-') else xbmc.LOGINFO,
                    )
                except Exception:
                    pass
            if info is None:
                self._notify_trakt_playback_event(
                    'start', 0.0 if resume_mode == 'beginning' else av_start_progress
                )
            else:
                # Do not report a stale saved resume point when Kodi is actually
                # playing from the beginning.  player.py records the explicit
                # resume choice made before the final ListItem is resolved.
                stored_progress = max(
                    float(info.playback.progress or 0),
                    float(info.kodi_info.percent or 0),
                )
                if resume_mode == 'beginning':
                    start_progress = 0.0
                elif resume_mode == 'resume':
                    requested_progress = max(
                        0.0,
                        min(99.9, float(self.player_info.get('media.resume_percent') or stored_progress or 0.0)),
                    )
                    requested_seconds = max(
                        0.0,
                        float(self.player_info.get('media.resume_seconds') or 0.0),
                    )
                    seek_applied = bool(self.player_info.get('media.resume_applied', False))
                    if not seek_applied and (requested_progress > 0.0 or requested_seconds > 0.0):
                        already_positioned = bool(
                            live_progress is not None
                            and abs(float(live_progress) - requested_progress) <= 1.0
                        )
                        # ResumePoint metadata on a resolved plugin ListItem is not
                        # honoured consistently for localhost HTTP streams.  Apply
                        # the user's decision to the live Kodi player once, at the
                        # AV-start boundary where duration and seeking are valid.
                        self.set_state('media.resume_applied', True)
                        target_seconds = requested_seconds
                        try:
                            total_seconds = float(XbmcPlayer().getTotalTime() or 0.0)
                        except Exception:
                            total_seconds = 0.0
                        if total_seconds > 0.0 and requested_progress > 0.0:
                            target_seconds = total_seconds * requested_progress / 100.0
                        if total_seconds > 1.0:
                            target_seconds = min(target_seconds, max(0.0, total_seconds - 1.0))
                        try:
                            if target_seconds > 0.0 and not already_positioned:
                                XbmcPlayer().seekTime(target_seconds)
                            try:
                                from ..ff import diagnostics
                                diagnostics.log_event(
                                    'playback',
                                    'event=resume-apply; result=%s; percent=%.1f; seconds=%.1f; total=%.1f'
                                    % ('native' if already_positioned else 'seek', requested_progress,
                                       target_seconds, total_seconds),
                                )
                            except Exception:
                                pass
                        except Exception as exc:
                            fflog.warning('[SERVICE] resume seek failed: %r' % (exc,))
                            try:
                                from ..ff import diagnostics
                                diagnostics.log_event(
                                    'playback',
                                    'event=resume-apply; result=failed; error=%s' % type(exc).__name__,
                                    level=xbmc.LOGWARNING,
                                )
                            except Exception:
                                pass
                            requested_progress = live_progress if live_progress is not None else 0.0
                    start_progress = requested_progress
                else:
                    start_progress = live_progress if live_progress is not None else stored_progress
                start_progress = max(0.0, min(100.0, float(start_progress or 0)))
                av_start_progress = start_progress
                self.send_playing_state(info=info, start_progress=start_progress)
            self.set_state((
                ('playing.video', True),
                ('playing.progress', av_start_progress),
                ('playing.paused', False),
                ('playing.path', getInfoLabel('Player.FilenameAndPath')),
                ('playing.last', None),
                ('playing.next', None),
                *((f'playing.{k}', v) for k, v in self.player_info.items() if k.startswith('media.')),  # copy media.* to playing.media.*
                ('state', 'playing'),
            ))
            if info and info.type == 'episode' and not getInfoLabel('Player.FilenameAndPath').lower().endswith('.strm') and (media_ref := self.player_info.get('media.ref')):
                from ..ff.upnext import signal_upnext
                signal_upnext(current_item=info.item, ref=media_ref)
        elif notif == 'xbmc.Player.OnPause':
            info = self.item_info(data)
            self._sample_live_playback_progress()
            progress = self.current_player_progress(default=info.kodi_info.percent if info is not None else 0)
            if not self.seek_pending_validation:
                self.last_live_progress = progress
            if info is not None:
                info.playback.progress = progress
                self.scrobble(info, 'pause', progress)
            else:
                self._notify_trakt_playback_event('pause', progress)
            self.set_state((
                ('playing.paused', True),
                ('playing.pause_progress', progress),
            ))
        elif notif == 'xbmc.Player.OnResume':
            info = self.item_info(data)
            self._sample_live_playback_progress()
            progress = self.current_player_progress(default=info.kodi_info.percent if info is not None else 0)
            if not self.seek_pending_validation:
                self.last_live_progress = progress
            if info is not None:
                info.playback.progress = progress
                # Resume is a real Trakt scrobble start, but present it to the
                # user as a resume rather than another initial start.
                self.scrobble(info, 'start', progress, notify_event='resume')
            else:
                self._notify_trakt_playback_event('resume', progress)
            self.set_state('playing.paused', False)
        elif notif == 'xbmc.VideoLibrary.OnUpdate':
            # If video should be playing...
            if self.player_info.get('playing.video'):
                if XbmcPlayer().isPlaying():
                    # Still playing buf video is changed (more items on playlist, upnext etc...).
                    if (old_path := self.player_info.get('playing.path')) and old_path != (new_path := getInfoLabel('Player.FilenameAndPath')):
                        self.next_play(data=data)
                else:
                    # FF video should be playing but player has stop. It's playing finish labeled as "state = played".
                    self.set_state('state', 'played')
        elif notif == 'xbmc.Player.OnStop':
            is_playing: bool = self.player_info.get('playing.video', False)
            playback_session_id = str(
                self.player_info.get('playing.media.playback_session_id')
                or self.player_info.get('media.playback_session_id')
                or ''
            )
            playing_path = str(self.player_info.get('playing.path') or '')
            telegram_path = self._telegram_stream_path(playing_path)
            # Read this before stopping the localhost job.  It remains a useful
            # conservative fallback when player progress is unavailable, but it
            # is not a media-completion flag: FFmpeg Range playback may finish an
            # MP4 without fetching the physical last byte of the container.
            telegram_eof = (
                self._telegram_stream_reached_eof(telegram_path)
                if telegram_path else None
            )
            if telegram_eof is None and telegram_path:
                telegram_eof = self.last_telegram_eof
            kodi_ended = bool(data.get('end', False))
            # OnStop is commonly delivered after Kodi has already destroyed the
            # player. Try a live read once, then fall back to the last sample taken
            # while playback was active. Do this before clearing any player state.
            fallback_default = self.last_live_progress
            if fallback_default is None:
                fallback_default = float(self.player_info.get('playing.progress') or 0)
            stop_progress = self._best_stop_progress(default=fallback_default) if is_playing else 0.0
            # A Player.OnSeek notification reports the requested target immediately,
            # even if decoding never resumes there.  Until the playback clock has
            # advanced after that seek, use the last genuinely played position for
            # watched/resume decisions.  Near-100% remains a valid completion signal.
            seek_unvalidated = bool(self.seek_pending_validation)
            seek_pre_progress = self.seek_pre_progress
            effective_stop_progress = stop_progress
            if seek_unvalidated and stop_progress < 99.5 and seek_pre_progress is not None:
                effective_stop_progress = max(0.0, min(100.0, float(seek_pre_progress)))
            info = self.item_info(data) if is_playing else None
            if telegram_path:
                self._stop_telegram_stream_for_path(
                    telegram_path, reason='player-stop'
                )

            # Kodi's end=True says the playable item reached its end.  For HTTP
            # Range MP4 the Telegram job does not need to fetch the physical last
            # byte, so combine Kodi's end flag with the sampled watched threshold.
            # A failed seek below true completion still stays interrupted.
            try:
                watched_threshold = float(advanced_settings.get(
                    'video', 'playcountminimumpercent', default=const.media.progress.as_watched
                ))
            except (TypeError, ValueError):
                watched_threshold = float(const.media.progress.as_watched)
            ended, eof_suppression = _normalize_kodi_eof(
                kodi_ended=kodi_ended,
                stop_progress=effective_stop_progress,
                watched_threshold=watched_threshold,
                progress_known=bool(is_playing and (self.last_live_progress is not None or seek_pre_progress is not None)),
                telegram_eof=telegram_eof if telegram_path else None,
                seek_unvalidated=seek_unvalidated and stop_progress < 99.5,
            )
            if eof_suppression:
                try:
                    from ..ff import diagnostics
                    diagnostics.log_event(
                        'playback',
                        'event=eof-suppressed; progress=%.1f; reason=%s; '
                        'telegram-eof=%s; result=interrupted'
                        % (stop_progress, eof_suppression, telegram_eof),
                        level=xbmc.LOGWARNING,
                    )
                except Exception:
                    pass

            if not is_playing:
                # if the video didn't start at all (there was no Player.OnAVStart)
                if playback_session_id:
                    control.close_busy_dialog(owner=playback_session_id)
                else:
                    control.close_busy_dialog()
            self.clear_player_state()
            if is_playing:
                try:
                    from ..ff import diagnostics
                    diagnostics.log_event(
                        'playback',
                        'event=stop; started=true; kodi-ended=%s; ended=%s; '
                        'progress=%.1f; effective-progress=%.1f; seek-unvalidated=%s; telegram-eof=%s'
                        % (kodi_ended, ended, stop_progress, effective_stop_progress, seek_unvalidated, telegram_eof),
                    )
                except Exception:
                    pass
                if info is not None:
                    self.send_played_state(
                        info=info, ended=ended, stop_progress=effective_stop_progress,
                        playback_session_id=playback_session_id,
                        # Kodi can increment its transient playcount after a cURL/
                        # demuxer EOF.  For localhost Telegram the normalized
                        # ``ended`` decision above remains authoritative; do not
                        # add a second Kodi-playcount completion path here.
                        allow_kodi_playcount_completion=not bool(telegram_path),
                    )
                else:
                    session_completed = bool(ended or effective_stop_progress >= watched_threshold)
                    self._notify_trakt_playback_event(
                        'finish' if session_completed else 'stop',
                        100 if session_completed else effective_stop_progress,
                    )
                    self._publish_playback_result(
                        'completed' if session_completed else 'interrupted',
                        100 if session_completed else effective_stop_progress,
                        playback_session_id=playback_session_id,
                    )
            else:
                # A concrete session that failed before AVStart is still an
                # authoritative interrupted result for navigation.  Publishing
                # it prevents any fallback to a historical watched row.
                self._publish_playback_result(
                    'interrupted', 0.0,
                    playback_session_id=playback_session_id,
                )
                try:
                    from ..ff import diagnostics
                    diagnostics.log_event('playback', 'event=stop; started=false; result=failed-before-av-start', level=xbmc.LOGWARNING)
                except Exception:
                    pass
                fflog('[SERVICE] playing failed (no Player.OnAVStart)')
            self.set_state('state', '')
            self.folder_ready()
        elif notif == 'xbmc.Player.OnSeek':
            info = self.item_info(data)
            seek = self.seek_info(data)
            # Pass the absolute seek target to the Telegram HTTP service.
            # Kodi/FFmpeg can issue several MP4/index Range probes before it asks
            # for the actual media bytes. The target is only a conservative probe
            # classifier; HTTP byte ranges themselves remain authoritative.
            seek_target_progress = None
            if seek is not None and info is not None:
                try:
                    seek_duration = max(
                        info.item.duration or 0,
                        info.playback.duration or 0,
                        info.kodi_info.total_s,
                        seek.time,
                    )
                    if seek_duration > 0:
                        seek_target_progress = max(
                            0.0, min(100.0, 100.0 * float(seek.time) / float(seek_duration))
                        )
                except Exception:
                    seek_target_progress = None
            self._begin_seek_validation(seek=seek, target_progress=seek_target_progress)
            self._mark_telegram_seek_for_path(
                self._telegram_stream_path(str(self.player_info.get('playing.path') or '')),
                reason='player-seek',
                target_progress=seek_target_progress,
            )
            fflog(f'[SERVICE] {info=}')
            self.send_playing_state(info=info, seek=seek)
        else:
            fflog(f'[SERVICE] unsupported play event, {notif=}, {data=}')

    def next_play(self, *, data: JsonData) -> bool:
        """Handle next play. Still playing buf video is changed (more items on playlist, upnext etc...)."""
        item: Dict[str, Any] = data.get('item', data)
        vtype: str = item.get('type', '')
        dbid: int = item.get('id', 0)
        old_path = self.player_info.get('playing.path')
        new_path = getInfoLabel('Player.FilenameAndPath')
        if vtype in ('movie', 'episode') and old_path and old_path != new_path:
            playing_dbid: int = int(getInfoLabel('VideoPlayer.DBID') or 0)
            new_url: str = ''
            if new_path.lower().endswith('.strm'):
                try:
                    new_url = load_strm_file(new_path)
                except (OSError, RuntimeError):
                    pass
            fflog(f'[SERVICE][NEXT] Playing {vtype} video changed from {old_path!r} to {new_path!r} ({new_url!r}), dbid {dbid} → {playing_dbid}')
            self.set_state((
                ('playing.path', new_path),
                ('playing.last', {
                    'dbid': dbid,
                    'ref': self.player_info.get('playing.media.ref'),
                    'tmdb': self.player_info.get('playing.media.tmdb'),
                    'imdb': self.player_info.get('playing.media.imdb'),
                }),
                ('playing.next', {
                    'dbid': playing_dbid,
                    'ref': None,
                    'tmdb': getInfoLabel('VideoPlayer.UniqueID(tmdb)'),
                    'imdb': getInfoLabel('VideoPlayer.UniqueID(imdb)'),
                }),
                ('state', 'play next'),
            ))
            info = self.item_info(data, player_info_prefix='playing.media')
            fflog(f'[SERVICE][NEXT] {info=}')
            self.send_played_state(info=info)
        return False

    def handle_watched(self, notif: str, data: JsonData) -> None:
        fflog(f'[SERVICE][WATCHED] {notif}')
        if notif == 'xbmc.VideoLibrary.OnUpdate':
            old_state = self.player_info.get('state')
            try:
                self.set_state('state', 'watching')
                # direct FF item set (un)watched
                if (li := get_player_item()) and (ref := MediaRef.from_slash_string(li.getVideoInfoTag().getUniqueID('ffref'))):
                    pass
                # FFID is set as DBID (and it is not internal kodi DBID), we can recover what ref is used.
                elif (vtype := data.get('type')) and isinstance((dbid := data.get('id')), int) and dbid > 0 and dbid not in VideoIds.KODI_DBID:
                    # TODO: implement it?
                    # should not hit here, shound call handle_library_watched()
                    fflog(f'[SERVICE] set (un)watch from OnUpdate DBID {vtype=}, {dbid=}  [NOT IMPLEMENTED]')
                    ...
                    return
                else:
                    fflog('[SERVICE] unsupported xbmc.VideoLibrary.OnUpdate')
                    return
                if info := self.item_info(data, ref=ref):
                    if self.skip_updates and info.ref in self.skip_updates.refs and bool(info.playback.play_count) == self.skip_updates.playcount:
                        fflog(f'[SERVICE] skip update {info.ref} because {self.skip_updates.parent}')
                        return

                    kodi_playcount = data.get('playcount')
                    fflog(f'{sty.fg.green}[SERVICE]{sty.rs.all}: {ref=}, {kodi_playcount=}, {info.kodi_info.play_count=}  ~~~')
                    if kodi_playcount is None:
                        kodi_playcount = info.kodi_info.play_count
            finally:
                self.set_state('state', old_state)

    def handle_library_watched(self, notif: str, data: JsonData) -> None:
        """On set (un)watched on library item. Support ff-links and alien links. Also called for FF3 if FAKE_DBID."""
        fflog(f'[SERVICE][LIBRARY] {notif}')
        if notif == 'xbmc.VideoLibrary.OnUpdate':
            item: Dict[str, Any] = data.get('item', data)
            vtype: str = item.get('type', '')
            dbid: int = item.get('id', 0)
            fflog(f'[SERVICE] Look watched for {vtype=}, {dbid=}')
            if dbid in VideoIds.KODI_DBID and vtype in ('movie', 'episode'):  # this is the library
                if kodi_vid_info := video_db.get_play_by_kodi_id(vtype, dbid):
                    if self.is_ff_link(kodi_vid_info.fname):
                        fflog(f'[SERVICE] Found watched {kodi_vid_info=}')
                        update_playback_db_by_kodi_info(kodi_vid_info)
                    elif self.is_alien_enabled(kodi_vid_info.fname):
                        if info := self.item_info(data, kodi_vid_info=kodi_vid_info):
                            # TODO: handle alien library videos
                            fflog(f'[SERVICE] library set (un)watch from OnUpdate DBID {vtype=}, {dbid=}  [NOT IMPLEMENTED]')
                            ...
            elif dbid > 0 and const.core.media_watched_mode is MediaWatchedMode.FAKE_DBID:
                # TODO: handle old (dbid) watch detector (is this necessary?)
                ...

    def handle_other(self, notif: str, data: JsonData) -> None:
        """Handle all other events (non-FF3)."""
        fflog(f'[SERVICE][OTHER] event {notif}: {data=}')
        if notif in ('xbmc.Player.OnAVStart', 'xbmc.Player.OnSeek', 'xbmc.Player.OnStop'):
            self.handle_alien(notif, data)

    def handle_alien(self, notif: str, data: JsonData) -> None:
        """Handle alien events (kodi and other plugins video events)."""
        path = getInfoLabel('Player.FilenameAndPath') or getInfoLabel('ListItem.FilenameAndPath')
        if self.is_alien_enabled(path):
            imdb = getInfoLabel('VideoPlayer.IMDBNumber') or getInfoLabel('ListItem.IMDBNumber')
            dbid = getInfoLabel('VideoPlayer.DBID') or getInfoLabel('ListItem.DBID')
            progress = getInfoLabel('Player.Progress') or getInfoLabel('ListItem.PercentPlayed')
            info = self.item_info(data)
            url = urlsplit(path)
            if url.scheme == 'plugin':
                fflog(f'[SERVICE][ALIEN] found {notif} event for alien plugin {url.hostname!r}, {imdb=}, {dbid=}, {progress=}, {info=}')
            else:
                fflog(f'[SERVICE][ALIEN] found {notif} event for alien scheme {url.scheme!r}, {imdb=}, {dbid=}, {progress=}, {info=}')
            # --- handle alien notifications
            return  # TODO:  implement it

    def is_ff_link(self, path: str) -> bool:
        """Return True if FF link."""
        if '://' not in path and path.lower().endswith('.strm'):
            path = load_strm_file(path)
        return path.startswith(plugin_url)

    def is_alien_enabled(self, path: str) -> bool:
        """Return True if support path is enabled (local or alien plugins)."""
        url = urlsplit(path)
        sync = const.trakt.sync.alien.scheme.get(url.scheme or 'file', const.trakt.sync.alien.default)
        if url.scheme == 'plugin':
            if url.hostname == plugin_id:  # this is not an alient, this is the FF3
                return True
            sync = const.trakt.sync.alien.plugins.get(url.hostname or '', sync)
        return sync

    def item_info(self,
                  data: JsonData,
                  *,
                  player_info_prefix: str = 'media',
                  ref: Optional[MediaRef] = None,
                  kodi_vid_info: Optional[KodiVideoInfo] = None,
                  ) -> Optional[MediaNotifInfo]:
        """Returns full video info, based on state[player], kodi db, trakt db, notification json."""
        ffitem: Optional[FFItem] = None
        pb: Optional[MediaPlayInfo] = None

        item: Dict[str, Any] = data.get('item', data)
        de_ref = MediaRef(item.get('type', ''), item.get('id', 0))
        log_msg = ''
        # if (itype := item.get('type')) and (iid := item.get('id')):
        #     de_ref = MediaRef(itype, iid)
        if ref is not None:
            log_msg = 'with given ref'
        elif ref := self.player_info.get(f'{player_info_prefix}.ref'):
            log_msg = 'from "media.ref"'
        elif (li := get_player_item()) and (ref := MediaRef.from_slash_string(li.getVideoInfoTag().getUniqueID('ffref'))):
            log_msg = 'from "ffref"'
        else:
            fflog(f'[SERVICE] the is no REF at all, {item=}')
            return None
        # find more info
        ffitem = ffinfo.find_item(ref, progress=ffinfo.Progress.NO)
        fflog(f'[SERVICE] item info {log_msg}: {ref=}, {ffitem=}')
        # info from kodi MyVideos DB for VideoLibrary (DBID)
        if kodi_vid_info is None and de_ref.type in ('movie', 'episode') and de_ref.ffid in VideoIds.KODI_DBID:
            kodi_vid_info = video_db.get_play_by_kodi_id(de_ref.type, de_ref.ffid)
        # info from kodi MyVideos DB
        if kodi_vid_info is None and (media_url := self.player_info.get(f'{player_info_prefix}.url')):
            kodi_vid_info = video_db.get_play_by_url(media_url)
            if ffitem is None and kodi_vid_info is not None and kodi_vid_info.ref:
                ffitem = ffinfo.find_item(kodi_vid_info.ref, progress=ffinfo.Progress.NO)
                if ffitem:
                    fflog(f'[SERVICE] recovered from kodi db: {ffitem=}')
        if kodi_vid_info is None:
            kodi_vid_info = KodiVideoInfo(ref=ref)  # empty video info (no progress)
        if ffitem is None:
            fflog(f'[SERVICE] no ffitem, {ref=}, {item=}')
            return None
        # direct trakt playback
        if (pb := get_playback_item(ref)) is None:
            pb = MediaPlayInfo.from_ffitem(ffitem)
            if not kodi_vid_info.fake:
                pb.play_count = kodi_vid_info.play_count
                pb.progress = kodi_vid_info.percent
        # super info object
        return MediaNotifInfo(type=item.get('type', ref.real_type), ffid=ref.ffid,
                              item=ffitem, kodi_info=kodi_vid_info, playback=pb, de_ref=de_ref)

    def seek_info(self, data: JsonData) -> Optional[SeekInfo]:
        """Returns seek info (percent progress)."""
        def get_time(d: JsonData) -> Optional[float]:
            try:
                h, m, s, x = d['hours'], d['minutes'], d['seconds'], d.get('milliseconds', 0)
            except KeyError:
                return None
            return h * 3600 + m * 60 + s + x / 1000

        if player_data := data.get('player', {}):
            offset = get_time(player_data.get('seekoffset', {}))
            time = get_time(player_data.get('time', {}))
            speed = player_data.get('speed', 1)
            if offset is not None and time is not None:
                return SeekInfo(offset=offset, time=time, speed=speed)
        return None

    def clear_player_state(self, state: str = 'stopping'):
        self.last_live_progress = None
        self._reset_seek_validation()
        self.set_state((
            ('playing.empty', False),
            ('playing.run', False),
            ('playing.video', False),
            ('playing.paused', False),
            ('playing.pause_progress', None),
            ('playing.path', ''),
            ('playing.last', None),
            ('playing.next', None),
            *((k, None) for k in self.player_info if k.startswith('playing.media.')),  # clear playing.media.*
            ('cancel_mode', None),
            ('state', state),
        ))

    @staticmethod
    def _read_live_player_position() -> Optional[Tuple[float, float, float]]:
        """Return ``(progress, position_s, total_s)`` while Kodi owns a video player."""
        try:
            player = XbmcPlayer()
            if not player.isPlayingVideo():
                return None
            total = float(player.getTotalTime() or 0)
            position = max(0.0, float(player.getTime() or 0))
            if total > 0:
                progress = max(0.0, min(100.0, 100.0 * position / total))
                return progress, position, total
        except Exception:
            pass
        return None

    @classmethod
    def _read_live_player_progress(cls) -> Optional[float]:
        """Return live Kodi progress, or None when the player is already gone."""
        state = cls._read_live_player_position()
        return state[0] if state is not None else None

    @classmethod
    def current_player_progress(cls, *, default: float = 0.0) -> float:
        """Read live player progress, falling back to synchronized metadata."""
        progress = cls._read_live_player_progress()
        if progress is not None:
            return progress
        return max(0.0, min(100.0, float(default or 0)))

    def _reset_seek_validation(self) -> None:
        self.seek_pending_validation = False
        self.seek_target_time = None
        self.seek_target_progress = None
        self.seek_validation_position = None
        self.seek_pre_progress = None

    def _begin_seek_validation(self, *, seek: Optional[SeekInfo], target_progress: Optional[float]) -> None:
        """Remember a seek until Kodi proves that playback really continued there."""
        self.seek_pending_validation = bool(seek is not None)
        self.seek_target_time = float(seek.time) if seek is not None else None
        self.seek_target_progress = target_progress
        self.seek_validation_position = None
        self.seek_pre_progress = self.last_live_progress

    def _update_seek_validation(self, *, progress: float, position: float, total: float) -> bool:
        """Validate a seek after at least two seconds of real playback-clock advance."""
        if not self.seek_pending_validation:
            return True
        if progress >= 99.5:
            self.seek_pending_validation = False
            self.seek_validation_position = position
            return True

        if self.seek_validation_position is None:
            target = self.seek_target_time
            # Wait until Kodi has actually landed around the requested position.
            # FFmpeg can start from a nearby keyframe, hence a modest tolerance.
            if target is not None and abs(position - target) > 15.0:
                return False
            self.seek_validation_position = position
            return False

        if position - self.seek_validation_position >= 2.0:
            self.seek_pending_validation = False
            self.seek_validation_position = position
            try:
                from ..ff import diagnostics
                diagnostics.log_event(
                    'playback',
                    'event=seek-validated; progress=%.1f; position=%.1f; result=playing'
                    % (progress, position),
                )
            except Exception:
                pass
            return True
        return False

    def _sample_live_playback_progress(self) -> None:
        """Keep an in-memory Stop fallback while Kodi's player is still alive."""
        if not self.player_info.get('playing.video', False):
            return
        state = self._read_live_player_position()
        if state is None:
            return
        progress, position, total = state
        if self._update_seek_validation(progress=progress, position=position, total=total):
            self.last_live_progress = progress

    @staticmethod
    def _stop_telegram_stream_for_path(path: str, *, reason: str = '') -> bool:
        """Stop only the Telegram job represented by a local stream URL."""
        if not path:
            return False
        try:
            from resources.lib import tg_stream_service
            return bool(tg_stream_service.stop_stream_url(path, reason=reason))
        except Exception:
            return False

    @staticmethod
    def _telegram_stream_reached_eof(path: str) -> Optional[bool]:
        """Return exact local Telegram EOF state without mutating the job."""
        if not path:
            return None
        try:
            from resources.lib import tg_stream_service
            return tg_stream_service.stream_reached_eof(path)
        except Exception:
            return None

    @staticmethod
    def _mark_telegram_seek_for_path(path: str, *, reason: str = 'player-seek',
                                      target_progress: Optional[float] = None) -> bool:
        """Tell the Telegram service where Kodi intends to seek in time."""
        if not path:
            return False
        try:
            from resources.lib import tg_stream_service
            return bool(tg_stream_service.mark_stream_seek(
                path, reason=reason, target_progress=target_progress,
            ))
        except Exception:
            return False

    def _telegram_stream_path(self, fallback: str = '') -> str:
        """Return the exact localhost Telegram URL hidden behind plugin://play."""
        return str(
            self.player_info.get('playing.media.telegram_stream_url')
            or self.player_info.get('media.telegram_stream_url')
            or fallback
            or ''
        )

    def _stop_orphaned_telegram_stream(self) -> None:
        """Abort Telegram download once Kodi no longer owns an active player."""
        if not self.player_info.get('playing.video', False):
            return
        if self.player_info.get('playing.paused', False):
            return
        path = self._telegram_stream_path(str(self.player_info.get('playing.path') or ''))
        if not path:
            return
        try:
            if XbmcPlayer().isPlaying():
                return
        except Exception:
            # If Kodi cannot answer because its player is already gone, this is
            # exactly the state in which the local Telegram transfer should stop.
            pass
        self.last_telegram_eof = self._telegram_stream_reached_eof(path)
        self._stop_telegram_stream_for_path(path, reason='player-gone')

    def _best_stop_progress(self, *, default: float = 0.0) -> float:
        """Prefer a live OnStop read, then the last pre-Stop sample."""
        progress = self._read_live_player_progress()
        if progress is not None:
            return progress
        if self.last_live_progress is not None:
            return max(0.0, min(100.0, float(self.last_live_progress)))
        return max(0.0, min(100.0, float(default or 0)))

    def _publish_playback_result(
            self, result: str, progress: float, *,
            ref: Optional[MediaRef] = None,
            playback_session_id: str = '') -> None:
        """Publish the result of the current playback session to the source route.

        ``play_count`` is historical watched state and cannot tell whether the
        *current* viewing was completed when an already-watched episode is replayed.
        This state is reset by player.py before every play and written only after
        the local playback DB has been committed.
        """
        if result not in ('completed', 'interrupted'):
            return
        ref = ref or self.player_info.get('playing.media.ref') or self.player_info.get('media.ref')
        playback_session_id = str(
            playback_session_id
            or self.player_info.get('playing.media.playback_session_id')
            or self.player_info.get('media.playback_session_id')
            or ''
        )
        safe_progress = max(0.0, min(100.0, float(progress or 0.0)))
        self.set_state((
            ('media.playback_result', result),
            ('media.playback_result_progress', safe_progress),
            ('media.playback_result_ref', str(ref or '')),
            ('media.playback_result_session_id', playback_session_id),
        ))
        try:
            from ..ff import diagnostics
            diagnostics.log_event(
                'playback',
                'event=session-result; result=%s; progress=%.1f; ref=%s; session=%s'
                % (result, safe_progress, str(ref or ''), playback_session_id or 'legacy'),
            )
        except Exception:
            pass

    def send_playing_state(self, *, info: Optional[MediaNotifInfo], seek: Optional[SeekInfo] = None,
                           start_progress: Optional[float] = None) -> None:
        """Send current playing state (scrobble: start)."""
        fflog(f'[SERVICE] playing state {info=}, {seek=}')
        if info is None:
            fflog.warning('[SERVICE] can NOT set playing state, there is no info')
            return
        # Seek playing video, just update "play srobble" progress (from seek notification).
        if seek:
            # player.seekoffset is only the signed jump delta.  player.time is
            # the absolute target position after seek and must drive progress.
            time = max(info.item.duration or 0, info.playback.duration or 0, info.kodi_info.total_s, seek.time)
            progress = max(0.0, min(100.0, float(seek.progress_for_time(time) or 0)))
            # Do not overwrite last_live_progress here: OnSeek is only a request.
            # The service sampler promotes it after the playback clock advances.
            info.playback.progress = progress
            self.scrobble(info, 'start', progress=progress, notify=False)
        # Just playing (start or resume), update "play srobble" video progress (from trakt, db or kodi).
        else:
            if start_progress is None:
                start_progress = self.current_player_progress(default=info.kodi_info.percent)
            start_progress = max(0.0, min(100.0, float(start_progress or 0)))
            self.last_live_progress = start_progress
            # Keep the local resume state consistent with what Kodi actually
            # started.  In particular, Start from beginning must clear the stale
            # 82% resume value before the first Trakt start scrobble.
            info.playback.progress = start_progress
            self.scrobble(info, 'start', progress=start_progress)

    def send_played_state(self, *, info: Optional[MediaNotifInfo], ended: bool = False,
                          stop_progress: Optional[float] = None,
                          allow_kodi_playcount_completion: bool = True,
                          playback_session_id: str = '') -> None:
        """Send played state when playback stops (scrobble: pause/stop)."""
        fflog(f'[SERVICE] played state {info=}')
        if info is None:
            fflog.warning('[SERVICE] can NOT set played state, there is no info')
            return
        old_play_count = self.player_info.get('playing.play_count') or 0
        if stop_progress is None:
            stop_progress = self.current_player_progress(default=info.kodi_info.percent)
        stop_progress = max(0.0, min(100.0, float(stop_progress or 0)))
        if not stop_progress:
            stop_progress = max(0.0, min(100.0, float(info.kodi_info.percent or 0)))
        try:
            watched_threshold = float(advanced_settings.get(
                'video', 'playcountminimumpercent', default=const.media.progress.as_watched
            ))
        except (TypeError, ValueError):
            watched_threshold = float(const.media.progress.as_watched)

        # Healthy natural end: clear resume and mark watched locally BEFORE
        # sending the Trakt stop.  A plugin/local HTTP stream is not a Kodi
        # library file, so Kodi often leaves kodi_info.play_count at 0 even
        # after a real EOF.  play_count is the authoritative watched flag in
        # Kadr+, therefore preserving max(..., 0) left fully watched episodes
        # visually unwatched.  Keep an existing higher count, but guarantee at
        # least one play and record when the healthy finish happened.
        # Premature HTTP/Telegram EOF is normalized to ended=False by
        # handle_ff_play before we get here and never reaches this branch.
        if ended:
            info.playback.play_count = max(
                1,
                int(old_play_count or 0) + 1,
                int(info.playback.play_count or 0),
                int(info.kodi_info.play_count or 0),
            )
            info.playback.last_watched_at = int(utc_timestamp())
            info.playback.clear_progress()
            self.scrobble(
                info, 'stop', 100, notify_event='finish', notification_progress=100,
                session_result='completed', session_progress=100,
                playback_session_id=playback_session_id,
            )
            self.just_watched(info, first_time=not old_play_count)
            return

        # A normal user Stop in the watched region is also a completed watch.
        # Failed seeks do not get here with their requested target: OnStop uses
        # the last validated pre-seek position until playback has really advanced.
        if stop_progress >= watched_threshold:
            info.playback.play_count = max(
                1,
                int(old_play_count or 0) + 1,
                int(info.playback.play_count or 0),
                int(info.kodi_info.play_count or 0),
            )
            info.playback.last_watched_at = int(utc_timestamp())
            info.playback.clear_progress()
            self.scrobble(
                info, 'stop', 100, notify_event='finish', notification_progress=100,
                session_result='completed', session_progress=100,
                playback_session_id=playback_session_id,
            )
            self.just_watched(info, first_time=not old_play_count)
            return

        # Kodi may have committed a play-count update before OnStop. Honour it
        # only when the sampled player position is also in the watched region;
        # this prevents a broken HTTP EOF at a few percent from becoming watched.
        if (allow_kodi_playcount_completion
                and info.kodi_info.play_count == old_play_count + 1
                and stop_progress >= watched_threshold):
            info.playback.play_count = info.kodi_info.play_count
            info.playback.clear_progress()
            self.scrobble(
                info, 'stop', 100, notify_event='finish', notification_progress=100,
                session_result='completed', session_progress=100,
                playback_session_id=playback_session_id,
            )
            self.just_watched(info, first_time=not old_play_count)
            return

        # User Stop/interrupted stream. Persist the sampled position BEFORE the
        # scrobble helper updates the local playback DB. The old last branch sent
        # a Trakt pause but forgot this assignment, so there was nothing to resume.
        progress = stop_progress or info.kodi_info.percent or 0
        progress = max(0.0, min(100.0, float(progress or 0)))
        if 0 < progress < 100:
            info.playback.progress = progress
            # Keep the latest partial viewing distinct from historical watched
            # state.  This is what lets an already-watched title be resumed when
            # the user starts a rewatch and stops halfway.
            info.playback.paused_at = int(utc_timestamp())
        self.scrobble(
            info, 'pause', progress, notify_event='stop', notification_progress=progress,
            session_result='interrupted', session_progress=progress,
            playback_session_id=playback_session_id,
        )

    @overload
    def set_state(self, key: str, value: Any) -> None: ...

    @overload
    def set_state(self, values: Iterable[Tuple[str, Any]], /) -> None: ...

    def set_state(self, key: Any, value: Any = None) -> None:
        """Set player state."""
        if isinstance(key, str):
            fflog(f'[SERVICE] set state {(key, value)}')
            self.player_info[key] = value
            state.set(key, value, module='player')
        else:
            values = tuple(key)  # multiset
            fflog(f'[SERVICE] set state {values}')
            self.player_info.update(values)
            state.multi_set(values, module='player')

    def folder_ready(self):
        """Mark folder as ready to show."""
        # if works.events['folder'].is_set():
        #     fflog('[FOLDER] already ready')
        works.events['folder'].set()

    @logtime
    def update_db(self, video: MediaNotifInfo) -> bool:
        """Set playback in DB and mark folder ready."""
        if result := update_track_watched_item(video.playback, info=self.playing_items):
            if trakt.credentials():
                trakt.updated()
            # stored = get_playback_item(video.ref)  # DEBUG only
            # fflog(f'{video.playback.progress}%, x{video.playback.play_count}, {result=}, {video.playback=}, {video.playback._db_values=}, {stored=}')
            fflog(f'{video.playback.progress}%, x{video.playback.play_count}, {result=}, {video.playback=}, {video.playback._db_values=}')
            # self.need_refresh = True  # only for make sure (trakt should have the same data as DB have)
        else:
            result = False
        self.folder_ready()
        return result

    def _notify_trakt_playback_event(self, event: str, progress: float = 0.0) -> None:
        """Show playback feedback independently from the Trakt HTTP response.

        The notification setting is still the existing Trakt notification option,
        but a temporary Trakt API failure must not make Kodi playback events appear
        random to the user.
        """
        try:
            if not settings.getBool('trakt.sync_notification'):
                return
            if not trakt.credentials():
                return
            rounded = max(0, min(100, int(round(float(progress or 0)))))
            if event == 'resume':
                message = L(33159, 'Playback resumed ({progress}%)').format(progress=rounded)
            elif event == 'stop':
                message = L(33160, 'Playback stopped ({progress}%)').format(progress=rounded)
            elif event == 'finish':
                message = L(33161, 'Playback finished ({progress}%)').format(progress=rounded)
            elif event == 'pause':
                message = L(32959, 'Playback paused ({progress}%)').format(progress=rounded)
            elif event == 'start':
                message = L(32958, 'Playback started ({progress}%)').format(progress=rounded)
            else:
                message = L(32960, 'Marked as watched')
            control.infoDialog(
                message,
                heading='Kadr+ 2.0 - Trakt.tv',
                icon='',
                time=3000,
                sound=False,
            )
        except Exception:
            fflog_exc(1)

    def scrobble(self, info: MediaNotifInfo, action: ScrobbleAction, progress: Optional[float] = None,
                 *, notify: bool = True, notify_event: Optional[str] = None,
                 notification_progress: Optional[float] = None,
                 session_result: Optional[str] = None,
                 session_progress: Optional[float] = None,
                 playback_session_id: str = '') -> None:
        """Set Trakt scrobble and optionally show a plain Kodi notification."""
        if progress is None:
            progress = info.kodi_info.percent
        progress = progress or 0
        # The Kodi event already happened: show its feedback first.  Previously
        # the popup was still behind a synchronous local DB update, so a Stop
        # notification could be delayed/disappear while the player window closed.
        if notify:
            shown_progress = progress if notification_progress is None else notification_progress
            self._notify_trakt_playback_event(notify_event or action, shown_progress)
        # Persist locally next, before contacting Trakt.
        self.update_db(info)
        # Navigation must depend on this playback session, not on historical
        # play_count. Publish only after the local watched/resume row is durable,
        # but before a potentially slow Trakt HTTP request.
        if session_result:
            self._publish_playback_result(
                session_result,
                progress if session_progress is None else session_progress,
                ref=info.ref,
                playback_session_id=playback_session_id,
            )
        # Finally send to Trakt. The popup above is intentionally independent from
        # both local DB work and this HTTP result.
        sent_to_trakt = False
        has_credentials = bool(info and trakt.credentials())
        if has_credentials:
            try:
                sent_to_trakt = trakt.scrobble_ref(action, info.ref, progress, db_save=False)  # DB is updated already
            except Exception:
                sent_to_trakt = False
                fflog_exc(1)
        try:
            from ..ff import diagnostics
            diagnostics.log_event(
                'trakt-scrobble',
                'action=%s; progress=%.1f; result=%s' % (
                    action, float(progress or 0),
                    'ok' if sent_to_trakt else ('failed' if has_credentials else 'no-credentials'),
                ),
                level=xbmc.LOGINFO if sent_to_trakt else xbmc.LOGWARNING,
            )
        except Exception:
            pass
        if const.debug.tty:
            fflog(f'[SERVICE] scrobble: {sty.fg.cyan} {action} {progress:.1f}% {sty.rs.all}')
        else:
            fflog(f'[SERVICE] scrobble: {action} {progress:.1f}%')
        self.folder_ready()

    def set_watched(self, video: MediaNotifInfo, play_count: int) -> None:
        """Set trakt watched plays. NOT USED ANYMORE."""
        fflog.error('[SERVICE] set_watched is DEPRECATED !!!')
        if video:
            if play_count:
                # first, set in DB
                video.playback.clear_progress()
                video.playback.play_count = play_count
                self.update_db(video)
                # next, send to trakt
                if trakt.credentials():
                    if video.playback.progress:
                        trakt.scrobble_ref('stop', video.ref, 100, db_save=False)  # DB is updated already
                    else:
                        trakt.add_history_ref(video.ref, db_save=False)  # DB is updated already
            else:
                # first, set in DB
                video.playback.clear_progress()
                video.playback.play_count = 0
                self.update_db(video)
                # next, send to trakt
                if trakt.credentials():
                    if video.playback.progress:
                        trakt.scrobble_ref('pause', video.ref, 0, db_save=False)  # DB is updated already
                    trakt.remove_history_ref(video.ref, db_save=False)  # DB is updated already
            if const.debug.tty:
                fflog(f'[SERVICE] plays: {sty.fg.cyan} set {play_count or 0} {sty.rs.all}')
            else:
                fflog(f'[SERVICE] plays:  set {play_count or 0}')
            # self.need_refresh = True
        # else:
        #     self.folder_ready()

    def onSettingsChanged(self):
        fflog('[SERVICE]')
        old_otp_code = settings.getString('netmirror.otp_code').strip()
        L.reset()
        settings.reset()  # force recreate settings proxy
        try:
            from ..ff.trakt_keys import prepare
            prepare()
        except Exception:
            fflog.warning('Trakt key storage unavailable')
        ffinfo.reset()
        # Redeem a code entered in Kodi settings immediately; it is valid only
        # for a short time and must not wait for the next source search.
        new_otp_code = settings.getString('netmirror.otp_code').strip()
        if new_otp_code and new_otp_code != old_otp_code:
            from ..sources.xx.netmirror import source as NetMirrorSource
            NetMirrorSource.prefetch_otp_token()
        # detect library settings change and start thread if needed
        library_enabled = settings.getBool('enable_library')
        if library_enabled and works.library is None:
            from .library import Library  # noqa: F811
            works.library = Library()
            works.library.start()
        elif not library_enabled and works.library is not None:
            library, works.library = works.library, None
            library.stop()

    def just_watched(self, video: MediaNotifInfo, *, first_time: bool) -> None:
        """Handle watch video finished."""
        fflog(f'[SERVICE] just watched: {video.ref}, first time: {first_time}')
        if const.ratings.every_watched or first_time:
            ffitem = video.item
            main_type = video.ref.type
            if main_type in ('movie', 'show') and settings.getBool(f'rate_after_watch.{main_type}'):
                from ..ff.ratings import rate_media
                if main_type == 'movie':
                    rate_media(video.item, action='watched_movie')
                else:
                    for mode in const.ratings.watched_show_mode:
                        if mode == 'show':
                            ref = ffitem.show_item or video.ref.show_ref
                        elif mode == 'season':
                            ref = ffitem.season_item or video.ref.season_ref
                        elif mode == 'episode':
                            ref = ffitem
                        elif mode == 'show_finished':
                            ref = ffitem.show_item or video.ref.show_ref
                            if ref is None or (it := ffinfo.find_item(ref, progress=ffinfo.Progress.BASIC)) is None:
                                continue
                            if it.progress is None or it.progress.play_count < 1:
                                continue
                            ref = it
                        elif mode == 'season_finished':
                            ref = ffitem.season_item or video.ref.season_ref
                            if ref is None or (it := ffinfo.find_item(ref, progress=ffinfo.Progress.BASIC)) is None:
                                continue
                            if it.progress is None or it.progress.play_count < 1:
                                continue
                            ref = it
                        else:
                            fflog(f'[SERVICE] unsupported watched show rating mode: {mode!r}')
                            continue
                        assert ref is not None
                        rate_media(ref, action='watched_episode', if_not_rated=not const.ratings.every_watched)


def cacheCleanSourcesList():
    cache.cache_clear_sources()
    hash_bar("Sources list has been cleaned")


def service_jobs():
    for job in state.jobs('service'):
        if job.command == 'trakt.sync':
            if works.trakt_sync:
                works.trakt_sync.sync_start()
            else:
                fflog('[WARNING] cyclic trakt_playback_sync() is NOT running, force sync directly')
        elif job.command in ('refresh', 'update'):
            # push job to plugin
            state.add_job('plugin', job.command, args=job.args, sender=job.sender)


def process_library_batches():
    """Process library batches for adding to library."""
    fflog(f'Add to library worker ({"up" if works.library else "passive"})')
    while not monitor.abortRequested():
        try:
            req = works.library_jobs.get()
        except ExitBaseException:
            break
        except ShutDown:
            break
        fflog(f'Process add to library chunk: {req.name!r} ({len(req.items)})')
        if works.library is None:
            fflog(f'[LIBRARY] library is disabled, skip processing batch {req.name!r}')
        else:
            works.library.add(req.items, name=req.name, quiet=req.quiet, sync=req.sync, dedup=req.dedup)
        works.library_jobs.task_done()
        xsleep(const.library.service.chunk_sleep)


def add_to_library(name: str, items: Iterable[FFRef], *, quiet: bool = False) -> None:
    """Add library batch for processing. Split into chunks."""
    if works.library is None:
        return
    items = tuple(items)
    if not items:
        return
    chunk_size = const.library.service.chunk_size
    if not chunk_size:
        chunk_size = len(items)
    fflog(f'Add to library request: {name!r} {len(items)} items in {(len(items) + chunk_size - 1) // chunk_size} chunks')
    # Shared by every chunk below - dedupes the actual disk write (see LibTools.add()) when the
    # same movie/show ends up in this call more than once (e.g. present on 2+ synced lists),
    # without affecting the TMDB skeleton-fetch pacing, which stays per-chunk as before.
    dedup: set[MediaRef] = set()
    for offset in range(0, len(items), chunk_size):
        last = offset + chunk_size >= len(items)
        if last:
            req = AddToLibraryRequest(items=items[offset:], name=name, quiet=quiet, dedup=dedup)
        else:
            req = AddToLibraryRequest(items=items[offset : offset + chunk_size], name=f'{name} ({offset // chunk_size + 1})', quiet=True, sync=False, dedup=dedup)
        works.library_jobs.put_nowait(req)


def telegram_stream_service_manager() -> None:
    """Keep the local Telegram Range server alive while the provider is enabled."""
    from resources.lib import tg_stream_service

    running = False
    try:
        while not monitor.abortRequested():
            try:
                enabled = control.setting('provider.telegram').lower() == 'true'
                # Current MTProto playback always uses the persistent local Range
                # service.  Keep it on whenever Telegram is on and let the OS pick
                # a free localhost port; user-selected fixed ports can collide and
                # disabling the service makes Telegram playback impossible.
                should_run = enabled
                if should_run and not running:
                    port = tg_stream_service.start_service(preferred_port=0, monitor=monitor)
                    running = bool(port)
                    if running:
                        fflog(f'[TELEGRAM] Range stream service started on 127.0.0.1:{port}')
                    else:
                        fflog('[TELEGRAM] Range stream service failed to start')
                elif not should_run and running:
                    tg_stream_service.stop_service()
                    running = False
                    fflog('[TELEGRAM] Range stream service stopped (provider disabled)')
            except Exception:
                fflog_exc()
            if monitor.waitForAbort(4.0):
                break
    finally:
        try:
            tg_stream_service.stop_service()
        except Exception:
            fflog_exc()


def startup():
    """Initialize all startup and cyclic stuff."""
    from ..ff.control import pretty_log_info
    from ..ff.requests import cleanup_netcache

    def start_cyclic_task(func: Callable, *, setting_interval: str, setting_on_start: Optional[str] = None, title: str = '') -> None:
        hours = settings.getInt(setting_interval)
        startup = setting_on_start and settings.getBool(setting_on_start)

        if hours > 0 and startup:
            hash_box([
                f"STARTING {title} SCHEDULING",
                f"SCHEDULED TIME FRAME {hours} HOURS",
            ])

        timeout = 3600 * hours

        if startup:
            # timeout = (randint(60, 120), timeout)
            timeout = (10, timeout)  # XXX
        cyclic_call(timeout, func)

    def version_tuple(value: str) -> tuple[int, ...]:
        """Convert a dotted Kadr+ version to a comparable integer tuple."""
        try:
            return tuple(int(part) for part in value.split('.'))
        except (AttributeError, TypeError, ValueError):
            return ()

    try:
        AddonVersion = control.addon(control.plugin_id).getAddonInfo("version")
        AddonOldVersion = settings.getString("addon.version")
        current_version = version_tuple(AddonVersion)
        old_version = version_tuple(AddonOldVersion)
        if AddonOldVersion != AddonVersion:
            cache.cache_clear_all()
            hash_bar("KADR+ NOWA INSTALACJA LUB AKTUALIZACJA")
        if AddonOldVersion == '2.0.20' and current_version >= (2, 0, 21):
            # 2.0.20 shipped temporary conservative defaults which disabled the
            # German/English providers and gave Telegram much less search time
            # than the proven Kadr+ configuration. Only replace those exact old
            # defaults, preserving values the user actually customised.
            string_defaults = {
                'providers.lang': ('Polish', 'Polish+German+English'),
                'lang.pl.color.identify2': ('FF40C4FF', 'FFFF4040'),
                'telegram.color.identify2': ('FF00C8B4', 'FF2196F3'),
            }
            for setting_id, (old_value, new_value) in string_defaults.items():
                if settings.getString(setting_id) == old_value:
                    settings.setString(setting_id, new_value)
            if not settings.getString('lang.multi.color.identify2'):
                settings.setString('lang.multi.color.identify2', 'FF00C853')

            int_defaults = {
                'scrapers.timeout.1': (30, 100),
                'telegram.dialog_limit': (1000, 500),
                'telegram.max_results': (500, 200),
                'telegram.max_per_chat': (100, 20),
                'telegram.quick_budget_pct': (45, 50),
                'telegram.topic_budget': (7, 12),
                'telegram.dialog_fallback_budget': (5, 10),
                'telegram.context_headers': (24, 32),
                'telegram.context_budget': (8, 18),
            }
            for setting_id, (old_value, new_value) in int_defaults.items():
                if settings.getInt(setting_id) == old_value:
                    settings.setInt(setting_id, new_value)
            # Selecting a source must never silently continue through the next
            # links after the user stops or cancels playback.
            settings.setBool('auto.select.next.item.to.play', False)
        if old_version and old_version < (2, 0, 22) <= current_version:
            # Update only known retired MegaKino defaults. A custom mirror set
            # by the user is deliberately preserved.
            megakino_base = settings.getString('megakino.base').strip().rstrip('/').lower()
            retired_megakino = {
                'https://megakino.to',
                'https://megakino3.org',
                'https://megakino4.to',
                'https://megakino1.watch',
                'https://megakino2.watch',
            }
            if megakino_base in retired_megakino:
                settings.setString('megakino.base', 'https://megakino10.com')
        if old_version and old_version < (2, 0, 30) <= current_version:
            # Version 2.0.29 declared only modes 1 and 2, but shipped an
            # impossible default value 0. Preserve every valid user choice.
            if settings.getInt('ekinopremium.premium_mode') == 0:
                settings.setInt('ekinopremium.premium_mode', 1)
        settings.setString("addon.version", AddonVersion)
        pretty_log_info()
    except Exception:
        hash_box([
            "RAPORT WERSJI KADR+",
            "BŁĄD ODCZYTU LUB MIGRACJI WERSJI KADR+"
        ], ff=True)

    def sync_lists_lib() -> None:
        """Sync arbitrary user-picked lists (any service: trakt/tmdb/mdblist/own/imdb) to the library.

        Selection is picked via Tools > Library > "Select lists to sync" (see lib.ff.lists
        pickable_lists()/save_selected_list_tokens()) and read back via selected_list_tokens().
        Each token has the shape `service:section:list`, matching cdefs.ListTarget.
        """
        if not works.library:
            return
        from ..ff.lists import selected_list_tokens, list_target_items
        tokens = selected_list_tokens()
        if not tokens:
            return
        if settings.getBool('library.service.notification'):
            # a manual "Update selected lists" click is otherwise a silent fire-and-forget
            # HTTP call - give some immediate confirmation that it actually started.
            from ..ff.control import infoDialog, addonName
            infoDialog(L(30652, 'Sync started...'), addonName())
        from cdefs import ListTarget
        from ..indexers.lists import ListsInfo
        # public=True: allows a public-only imdb.user config (no private at-main cookie) to still count.
        lists_info = ListsInfo(public=True)
        sources: list[Iterable[FFRef]] = []
        for tok in tokens:
            service, _, rest = tok.partition(':')
            section, _, list_id = rest.partition(':')
            if not lists_info.enabled(service):
                # e.g. user picked 3 trakt lists, then revoked trakt auth - skip quietly instead
                # of hammering the API with calls that would just fail every sync cycle.
                fflog(f'[LIB] Service {service!r} is no longer authorized, skipping list {tok!r}.')
                continue
            target = ListTarget(service=service, section=section, list=list_id)  # type: ignore[arg-type]
            try:
                items = list_target_items(target)
                if items is not None:
                    items = list(items)  # Keep lazy/network errors inside this list's guard.
            except Exception:
                # one bad/misconfigured source must not kill the whole sync (or, if triggered
                # from the cyclic scheduler, the background thread for the rest of the session)
                fflog_exc()
                fflog(f'[LIB] Failed to read list {target!r}, skipping.')
                continue
            if items is None:
                continue
            # materialize + log per-source count now (add_to_library() would materialize it
            # anyway) - with 5 services x several list types, knowing which one returned what
            # is far more useful for debugging than only the combined total at the end.
            items = list(items)
            fflog(f'[LIB] List {target!r} -> {len(items)} item(s).')
            if items:
                sources.append(items)
        if sources:
            try:
                add_to_library('auto lists', chain(*sources))
            except Exception:
                # belt-and-suspenders: a lazily-evaluated source could still fail only once
                # consumed here, well past the per-source try/except above.
                fflog_exc()
                fflog('[LIB] add_to_library("auto lists") failed.')

    works.library_auto_add = {
        'lists': sync_lists_lib,
        # Keep old bookmarked tool routes usable after the library UI migration.
        **{name: sync_lists_lib for name in ('trakt', 'tmdb', 'imdb', 'mdblist', 'own')},
    }

    if START_SYNC_ON_START:
        # Migrate the legacy schedule before reading the new timer settings.
        from ..ff.lists import selected_list_tokens
        selected_list_tokens()
        start_cyclic_task(sync_lists_lib, setting_interval='schedListsTime', setting_on_start='autoListsOnStart', title='auto lists')

        # Clean cached sources list
        cyclic_call(900, cacheCleanSourcesList)

        # netcache cleanup expired entries
        if const.core.netcache.cleanup.interval:
            cyclic_call(const.core.netcache.cleanup.interval, cleanup_netcache)

    if START_SYNC_ON_START:
        assert works.trakt_sync
        works.events['trakt'] = works.trakt_sync.synced
        works.trakt_sync.start()
        threads.add(works.trakt_sync)
        threads.add(th := Thread(target=process_library_batches, name='library-batches', daemon=True))
        th.start()

    works.jobs = cyclic_call(const.tune.service.job_list_sleep, service_jobs)

    # Persistent local HTTP Range server used by Telegram video playback.
    threads.add(th := Thread(target=telegram_stream_service_manager, name='telegram-stream-service', daemon=True))
    th.start()

    # monitor started, notify all (FF plugin)
    monitor.rpc.notify('ServiceUp', id=KodiRpc.BROADCAST)


def run(reload_monitor: Optional['ReloadMonitor'] = None) -> None:
    """Run service module."""
    monitor.reload_monitor = reload_monitor

    # 2.0.92 performed the one-time key reset. From 2.0.93 startup only
    # imports any plaintext legacy/user values into encrypted storage.
    try:
        from ..ff.trakt_keys import prepare
        prepare()
    except Exception:
        fflog.warning('Trakt key storage unavailable')

    try:
        # Trakt sync thread.
        works.trakt_sync = TraktSync()

        if START_SYNC_ON_START:
            # Tracking services (trakt sender).
            works.tracking_service.append(TraktSender())
            works.tracking_service.start()

            # Library service (adding items in the background). Start only if enabled. Settings are monitored.
            if settings.getBool('enable_library') and works.library is None:
                from .library import Library  # noqa: F811
                works.library = Library()
                works.library.start()

        proxy.start()
        if works.web:
            works.web.start()
    except Exception:
        fflog_exc()
    try:
        fflog('[FF] ### Service start-up')
        startup()
        fflog('[FF] ### Service monitor run')
        monitor.run()
    finally:
        fflog('[FF] ### Service going to stop')
        try:
            stop(join=False)
        except Exception:
            fflog_exc()


def join_threds() -> None:
    """Join all threads."""
    for th in threads:
        th.join()
    threads.clear()


def stop(*, join: bool = True) -> None:
    """Stop all services."""
    from ..ff.kotools import destroy_xmonitor
    monitor.working = False
    # fflog('[FF] stopping::1 (trakt_sync)')
    if works.trakt_sync:
        works.trakt_sync.stop()
    # fflog('[FF] stopping::2 (tracking_service)')
    if works.tracking_service is not None:
        works.tracking_service.stop()
    # fflog('[FF] stopping::3 (library)')
    if works.library is not None:
        works.library.stop()
        works.library = None
    # fflog('[FF] stopping::4 (web)')
    if works.web:
        works.web.stop()
        works.web = None
    # Stop Telegram Range service before joining worker threads.
    try:
        from resources.lib import tg_stream_service
        tg_stream_service.stop_service()
    except Exception:
        fflog_exc()
    # fflog('[FF] stopping::5 (http)')
    proxy.stop()
    # fflog('[FF] stopping::6 (join threads)')
    if join:
        join_threds()
    works.reset()
    # fflog('[FF] stopping::7 (monitor)')
    destroy_xmonitor()
    fflog('[FF] ### Service stopped')
    from threading import enumerate as thread_enumerate
    fflog(f'Active service threads: {thread_enumerate()}')  # debug


if const.tune.service.startup_delay:
    fflog(f'[SERVICE] ----- start delay ({const.tune.service.startup_delay:.1f}s) -----')
    _start_monitor = xbmc.Monitor()
    _start_monitor.waitForAbort(const.tune.service.startup_delay)
    del _start_monitor

fflog('[SERVICE] ----- start service -----')

# Trakt.tv withou auto-auth, to avoid dialog popups on kodi start.
trakt.auto_auth = False

# All thread
threads = WeakSet()

# Uruchamianie serwera HTTP
proxy = works.http = HttpProxy(works=works)
# Uruchamianie serwera web
works.web = WebServer(works=works)

# Główny monitor
monitor = FFMonitor()
works.state.monitor = monitor  # istniejący monitor, aby nie tworzyć go za każdym razem
