from __future__ import annotations


# TODO:  move to lib/ff/...

class ListsInfo:
    """Simple class to check if "my lists" are enabled. If public=True, not extra auth is required."""

    def __init__(self, *, public: bool = False) -> None:
        self.public = public

    def enabled(self, name: str | None = None) -> bool:
        """Return True if any of list list service is enabled or given list is enabled."""
        if name:
            return getattr(self, f'{name.lower()}_enabled', lambda: False)()
        return self.trakt_enabled() or self.tmdb_enabled() or self.imdb_enabled() or self.own_enabled()

    def trakt_enabled(self) -> bool:
        from ...ff.trakt import trakt
        return bool(trakt.credentials())

    def tmdb_enabled(self) -> bool:
        from ...ff.tmdb import tmdb
        return bool(tmdb.credentials())

    def imdb_enabled(self) -> bool:
        from ...ff.settings import settings
        if bool(settings.getString('imdb.at-main')):  # private and public access
            return True
        if not self.public:
            return False
        return bool(settings.getString('imdb.user'))  # public only access

    def mdblist_enabled(self, *, premium: bool | None = None) -> bool:
        from const import const
        from ...ff.settings import settings
        if const.indexer.mdblist.enabled and (const.dev.mdblist.api_key or settings.getString('mdblist.api_key')):
            if premium is not None:
                from .mdblist import mdblist
                return mdblist.is_premium() == premium
            return True
        return False

    def justwatch_enabled(self) -> bool:
        from const import const
        return bool(const.indexer.justwatch.enabled)

    def own_enabled(self) -> bool:
        from const import const
        return bool(const.indexer.own.enabled)
