"""
Kadr+ 2.0 Add-on

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


from __future__ import annotations
from typing import Any, Optional, List, Union, Dict, TypedDict, Iterator, Sequence, Iterable, ClassVar, cast
from typing_extensions import Protocol, Pattern, NotRequired, Literal, overload
import re
from functools import lru_cache

import xml.etree.ElementTree as ET
from contextlib import contextmanager
from attrs import frozen, evolve
from xbmcvfs import translatePath, mkdirs, File, makeLegalFilename, listdir, exists as vfs_exists
from xbmc import executebuiltin
from xbmcgui import Dialog
from datetime import datetime, timedelta

from .anypath import APath
from .item import FFItem
from .log_utils import fflog, fflog_exc
from .settings import settings
from .routing import url_for
from .info import ffinfo
from .kotools import KodiRpc
from ..defs import MediaRef, FFRef
from ..indexers.navigator import play
from ..kolang import L
from const import const, StrmFilename
from cdefs import InfoDetails


class InLibDict(TypedDict):
    file: str
    season: int
    episode: int
    streamdetails: NotRequired[dict[str, Any]]  # Optional, only if include_streamdetails is True


class KodiWritableFile(Protocol):
    def write(self, buffer: Union[str,  bytes,  bytearray]) -> bool: ...
    def close(self) -> None: ...


class DummyFile:

    def write(self, buffer: Union[str,  bytes,  bytearray]) -> bool:
        return True

    def close(self) -> None:
        pass


@frozen(kw_only=True)
class TitleFormat:
    # mode: StrmFilename
    title: str
    sep: str = ' '


@frozen(kw_only=True)
class FileTarget:
    path: APath
    mode: StrmFilename
    titles: Dict[StrmFilename, TitleFormat]


_RX_BORDER_REMOVE: Pattern[str] = re.compile(r'_(?:(?=\s)|$)')
_RX_SAFE_LEGAL: Pattern[str] = re.compile(r'''[_:*?!'"<>|/\\]+''')
_RX_SAFE_REMOVE: Pattern[str] = re.compile(r'[^\w\s]|_')
_RX_MULIT_SPACE: Pattern[str] = re.compile(r'\s+')


def make_legal_fname(fname: str) -> str:
    """Fix kodi function, remove trailing /."""
    # makeLegalFilename keeps '/' as valid folder separator, remove it from title (e.g. "Re/Member") to avoid creating fake subdirs
    fname = fname.replace('/', '_').replace('\\', '_')
    prefix = APath('/x')  # kodi skips first path segment
    fname = makeLegalFilename(str(prefix / fname))
    fname = fname[len(str(prefix))+1:]  # remove fake prefix '/x'
    if const.library.safe_filename:
        fname = _RX_SAFE_LEGAL.sub('_', fname)
    fname = re.sub(r'_+', '_', fname)  # remove multiple underscores
    fname = _RX_BORDER_REMOVE.sub('', fname)
    fname = fname.rstrip('/')
    return fname


def exists(path: Union[APath, str]) -> Optional[APath]:
    """Return name of the existing file if any has the same or a similar name. Otherwise None."""
    path = APath(path)
    path, fname = path.parent, _RX_MULIT_SPACE.sub(' ', _RX_SAFE_REMOVE.sub(' ', path.name.lower()))
    for fs in listdir(path):
        for f in fs:
            if fname == _RX_MULIT_SPACE.sub(' ', _RX_SAFE_REMOVE.sub(' ', f.lower())):
                return path / f
    return None


class LibTools:
    """Base class for library tools"""

    _DEBUG_FOLDER: ClassVar[Optional[str]] = None
    _DRY_RUN: ClassVar[bool] = False
    #: Counters for the "Added: N movie(s), M episode(s)" summary log - reset at the start of add().
    _added_movies: int = 0
    _added_episodes: int = 0

    # EN locales
    EN_LOCALES: ClassVar[Sequence[str]] = ('en-US', 'en-GB', 'en')

    _RX_FNAME: ClassVar[Pattern[str]] = re.compile(r'[^\w\-]')
    _RX_WINDEVICE: ClassVar[Pattern[str]] = re.compile(r'\b(CON|PRN|AUX|NUL|COM\d+|LPT\d+)\.', flags=re.IGNORECASE)

    @property
    def movies_dir(self) -> APath:
        if self._DEBUG_FOLDER:
            return APath(self._DEBUG_FOLDER) / 'Movies'
        return APath(translatePath(settings.getString('library.movie')))

    @property
    def tv_dir(self) -> APath:
        if self._DEBUG_FOLDER:
            return APath(self._DEBUG_FOLDER) / 'TVShows'
        return APath(translatePath(settings.getString('library.tv')))

    def item_en_title(self, item: FFItem) -> str:
        """Return main English title of movie or show."""
        vtag = item.vtag
        if item.ref.season:  # season or episode
            if title := vtag.getEnglishTvShowTitle() or vtag.getTVShowTitle():
                return title
        return vtag.getEnglishTitle() or vtag.getTitle()

    def item_title(self, item: FFItem) -> str:
        """Return main local title of movie or show."""
        vtag = item.vtag
        if item.ref.season:  # season or episode
            if title := vtag.getTVShowTitle():
                return title
        return vtag.getTitle()

    def old_legal_filename(self, fname: str, *, sep: str = '.') -> str:
        fname = self._RX_FNAME.sub(sep, fname.strip()).strip()
        fname = _RX_BORDER_REMOVE.sub('', fname)
        fname = self._RX_WINDEVICE.sub(r'\1', fname)
        try:
            return make_legal_fname(fname)
        except RuntimeError:
            return fname

    def item_path_and_title(self, item: FFItem) -> FileTarget:
        """Return absolute path to item folder, item title (with year) and all old title formats."""
        path = self.tv_dir if item.ref.type == 'show' else self.movies_dir
        suffix = f' ({item.year})' if item.year else ''
        lang = const.library.title_language
        if not lang or lang in self.EN_LOCALES:
            title = self.item_en_title(item)
        else:
            # custom folder language
            en_title = self.item_en_title(item)
            en_path = path / f'{make_legal_fname(en_title)}{suffix}'
            if exists(en_path):
                # English folder exists, ues it to avoid duplication
                title = en_title
            else:
                # there is no English folder, specifed language could be used
                title = self.item_title(item)
        full_title = make_legal_fname(f'{title}{suffix}')

        # Episodes only need SxxEyy to scrape (see Kodi docs), so skip repeating the title there -
        # shorter path, and sidesteps title-related illegal-character issues on strict targets
        # (e.g. network shares). Movies keep the configured format.
        mode = StrmFilename.BARE if item.ref.type == 'show' else const.library.strm_filename
        return FileTarget(path=path / full_title, mode=mode, titles={
            StrmFilename.DOT: TitleFormat(title=self.old_legal_filename(title), sep='.'),
            StrmFilename.LOW_LINE: TitleFormat(title=self.old_legal_filename(title, sep='_'), sep='.'),
            StrmFilename.TITLE: TitleFormat(title=make_legal_fname(title), sep=' '),
            StrmFilename.TITLE_YEAR: TitleFormat(title=full_title, sep=' '),
            StrmFilename.BARE: TitleFormat(title='', sep=''),
        })

    @overload
    def check_in_library(self, *, tmdb: int | str | None = None, imdb: str | None = None, year: Optional[int] = None, all_episodes: Literal[True],
                         season: Optional[int] = None, episode: Optional[int] = None, include_streamdetails: bool = False) -> Optional[List[InLibDict]]: ...

    @overload
    def check_in_library(self, *, tmdb: int | str | None = None, imdb: str | None = None, year: Optional[int] = None, all_episodes: Literal[False] = False,
                         season: Optional[int] = None, episode: Optional[int] = None, include_streamdetails: Literal[True]) -> Optional[InLibDict]: ...

    @overload
    def check_in_library(self, *, tmdb: int | str | None = None, imdb: str | None = None, year: Optional[int] = None, all_episodes: Literal[False] = False,
                         season: Optional[int] = None, episode: Optional[int] = None, include_streamdetails: Literal[False] = False) -> Optional[str]: ...

    # TODO: rewrite this functon
    @lru_cache(maxsize=1000)
    def check_in_library(
        self,
        *,
        tmdb: int | str | None = None,
        imdb: str | None = None,
        year: Optional[int] = None,
        all_episodes: bool = False,
        season: Optional[int] = None,
        episode: Optional[int] = None,
        include_streamdetails: bool = False,
    ) -> Optional[Union[str, InLibDict, List[InLibDict]]]:
        rpc_client = KodiRpc()

        def match_id(data: dict[str, Any]) -> bool:
            uniqueid = data.get('uniqueid', {})
            if tmdb and uniqueid.get('tmdb') == tmdb:
                return True
            if imdb and uniqueid.get('tmdb') == imdb:
                return True
            return False

        def find_tvshow() -> Optional[dict]:
            try:
                tvshows = rpc_client.rpc_list(
                    'VideoLibrary.GetTVShows',
                    params={'filter': {'field': 'year', 'operator': 'is', 'value': str(year)}},
                    fields=['uniqueid', 'title', 'originaltitle', 'file']
                )
                return next((s for s in tvshows if match_id(s)), None)
            except Exception:
                fflog_exc()
                return None

        def get_episodes(tvshow_id: int, filter_params: Optional[dict] = None, include_streamdetails: bool = False) -> list[InLibDict]:
            try:
                return cast(List[InLibDict], rpc_client.rpc_list(
                    'VideoLibrary.GetEpisodes',
                    params={'tvshowid': tvshow_id, **({'filter': filter_params} if filter_params else {})},
                    fields=['file', 'season', 'episode'] + (['streamdetails'] if include_streamdetails else [])
                ))
            except Exception:
                fflog_exc()
                return []

        if not imdb and not tmdb:
            fflog.error('Either imdb or tmdb must be provided')
            raise ValueError('Either imdb or tmdb must be provided')
        if tmdb is not None:
            tmdb = str(tmdb)

        if all_episodes:
            tvshow = find_tvshow()
            if tvshow:
                # fflog(f'Found show: {tvshow.get("title") or tvshow.get("originaltitle")} (tvshowid: {tvshow["tvshowid"]})')
                episodes_in_library = get_episodes(tvshow['tvshowid'], include_streamdetails=include_streamdetails)
                return [ep for ep in episodes_in_library]
            # fflog(f'Show with ID: {tmdb}/{imdb} not found in library.')
            return None

        elif season is not None and episode is not None:
            tvshow = find_tvshow()
            if tvshow:
                filter_params = {
                    'and': [
                        {'field': 'season', 'operator': 'is', 'value': season},
                        {'field': 'episode', 'operator': 'is', 'value': episode}
                    ]
                }
                episodes_in_library = get_episodes(tvshow['tvshowid'], filter_params, include_streamdetails=include_streamdetails)
                if episodes_in_library:
                    return episodes_in_library[0] if include_streamdetails else episodes_in_library[0]['file']
                # fflog(f'Episode S{season}E{episode} not found.')
            # else:
                # fflog(f'Show with ID: {tmdb}/{imdb} not found.')
            return None

        else:
            try:
                movies = rpc_client.rpc_list(
                    'VideoLibrary.GetMovies',
                    params={'filter': {'field': 'year', 'operator': 'is', 'value': str(year)}},
                    fields=['uniqueid', 'title', 'originaltitle', 'file'] + (['streamdetails'] if include_streamdetails else [])
                )
                for movie in movies:
                    if match_id(movie):
                        # fflog(f'Found movie: {movie.get("title") or movie.get("originaltitle")}')
                        return movie if include_streamdetails else movie['file']
                # fflog(f'Movie with ID: {tmdb}/{imdb} not found.')
            except Exception:
                fflog(f'ERROR: Failed to check movie in library for {tmdb}/{imdb}.')
            return None

    def clear_cache(self):
        try:
            # spodziewam się tu wyjątku zawsze (rysson)
            self.check_in_library.cache_clear()
        except Exception:
            fflog_exc()

    @contextmanager
    def write(self, path: APath) -> Iterator[KodiWritableFile]:
        """Just fill the file with its content"""
        if exists(path):
            # fflog(f'Dummy open path {path} : {path.exists()}')
            yield DummyFile()
        elif self._DRY_RUN:
            print(f'DRY: write file {path}')
            yield DummyFile()
        else:
            # fflog(f'Try to open path {path} : {path.exists()}')
            with File(path, 'w') as file:
                # fflog(f'Open path {path} : {path.exists()} – {file}')
                yield file

    def mkdirs(self, path: APath) -> Optional[APath]:
        """Create directories like APath.mkdir(parents=True, exist_ok=True)."""
        if old := exists(path):
            return old
        if self._DRY_RUN:
            print(f'DRY: mkdir {path}')
            return path
        if mkdirs(path):
            return path
        # xbmcvfs.mkdirs() can report False even though the directory was actually created (seen
        # live: fresh, previously-empty library folders still got a False here) - before calling
        # this a real failure, check the real (non-fuzzy) VFS existence, trailing slash required
        # for a directory check.
        if vfs_exists(f'{path}/'):
            return path
        return None

    def write_nfo(self, path: str, item: FFItem) -> None:
        """Write nfo info in base XML format
            TODO: Add more tags if neccessary
        """
        # root element
        media_tag = ET.Element(str(item.type))
        # child title elem
        title = ET.SubElement(media_tag, "title")
        title.text = item.title
        # child unique id elem
        uniqueid = ET.SubElement(media_tag, "uniqueid")
        uniqueid.set("type", "tmdb")
        uniqueid.set("default", "true")
        uniqueid.text = str(item.ffid)
        # create an ETree from root
        tree = ET.ElementTree(media_tag)
        ET.indent(tree, space="\t", level=0)
        # write to file
        if self._DRY_RUN:
            print(f'DRY: write nfo  {path}')
        else:
            tree.write(path, encoding="UTF-8", xml_declaration=True, method="xml")

    @contextmanager
    def open_title(self, target: FileTarget, fname_format: str) -> Iterator[tuple[APath, KodiWritableFile]]:
        """Open file to write with title or old_titles if detected. Yields (resolved path, file)."""
        path = target.path
        for mode, tit in target.titles.items():
            if mode != target.mode and (old := exists(path / fname_format.format(title=tit.title, sep=tit.sep))):
                # another format detected, switch the format
                path = old
                break
        else:
            fmt = target.titles[target.mode]
            path = path / fname_format.format(title=fmt.title, sep=fmt.sep)
        if self._DRY_RUN:
            print(f'DRY: write title {path}')
            yield path, DummyFile()
        else:
            with self.write(path) as file:
                yield path, file

    def _add_movie(self, item: FFItem, *, reload: bool = True) -> None:
        """Add single movie to the library."""
        ref = item.ref

        target = self.item_path_and_title(item)
        imdb_id = item.vtag.getIMDBNumber()
        year = item.vtag.getYear()
        if settings.getBool('library.check'):
            if self.check_in_library(tmdb=item.video_ids.tmdb, imdb=imdb_id, year=year):
                return

        if (old := self.mkdirs(target.path)) is not None:
            target = evolve(target, path=old)
        else:
            fflog(f'ERROR: Failed to create movie folder {target.path!r} for {imdb_id}. Aborting.')
            return
        # prepare strm file
        with self.open_title(target, '{title}.strm') as (strm_path, f):
            ok: bool = f.write(str(url_for(play, ref=MediaRef('movie', ref.ffid))))
        if not ok:
            raise OSError('Could not write movie STRM file')
        if not isinstance(f, DummyFile):
            self._added_movies += 1
        # prepare nfo file
        with self.write(target.path / 'movie.nfo') as f:
            f.write(ffinfo.web_url(ref))
        # update kodi library
        if reload:
            executebuiltin('UpdateLibrary(video)', True)

    def _should_write_episode(self, ep: FFItem, existing_episodes: Optional[List[InLibDict]]) -> bool:
        """Determine if an episode should be written to the library."""
        if settings.getBool('library.check') and existing_episodes is not None:
            for existing in existing_episodes:
                if existing.get('season') == ep.season and existing.get('episode') == ep.episode:
                    return False  # Episode already exists, do not write

        include_unknown = settings.getBool('library.include_unknown')
        days_delay = settings.getInt('library.days_delay')
        cutoff_date = datetime.now() - timedelta(days=days_delay)

        if not (include_unknown or ep.aired_before(cutoff_date)):
            return False  # Conditions for writing are not met

        return True  # Episode should be written

    def _write_episode(self, ep: FFItem, *, target: FileTarget, existing_episodes: Optional[List[InLibDict]]) -> None:
        """Write single episode."""
        if not self._should_write_episode(ep, existing_episodes):
            return  # Episode should not be written

        with self.open_title(target, f'{{title}}{{sep}}S{ep.season:02d}E{ep.episode:02d}.strm') as (strm_path, f):
            ok: bool = f.write(str(url_for(play, ref=MediaRef('show', ep.ref.ffid, season=ep.ref.season, episode=ep.ref.episode))))
        if ok and not isinstance(f, DummyFile):
            self._added_episodes += 1
        elif not ok:
            raise OSError('Could not write episode STRM file')

    def _write_season(self, sz: FFItem, *, target: FileTarget, flat: bool, existing_episodes: Optional[List[InLibDict]]) -> None:
        """Write single season."""
        # Check if any episode in this season needs to be written
        episodes_to_write = [ep for ep in sz.episode_iter() if self._should_write_episode(ep, existing_episodes)]

        if not episodes_to_write:
            return  # No episodes to write, so skip creating the season folder

        season_path = target.path if flat else target.path / f'Season {sz.season}'
        if self.mkdirs(season_path) is None:
            fflog(f'ERROR: Failed to create season folder {season_path!r}. Skipping Season {sz.season}.')
            return
        # check style of first episode (with or without year) - optamlize, to avoid checking for each episode
        for mode, tit in target.titles.items():
            if mode != target.mode and exists(season_path / f'{tit.title}{tit.sep}S{sz.season:02d}E01.strm'):
                # another format detected, switch the format (and udpate season path)
                target = evolve(target, mode=mode, path=season_path)
                break
        else:
            # no other format detectef, use prefered one (and udpate season path)
            if target.path != season_path:
                target = evolve(target, path=season_path)
        # iterate over episodes
        for ep in episodes_to_write:  # Iterate only over episodes that need to be written
            self._write_episode(ep, target=target, existing_episodes=existing_episodes)

    def _add_show(self, item: FFItem, *, reload: bool = True) -> None:
        """Add single show (with all episodes) to the library."""
        show_item = item if item.ref.is_show else item.show_item
        if show_item is None:
            fflog(f'ERROR: Missing show_item for {item.ref!r}.')
            return
        target = self.item_path_and_title(show_item)
        existing_episodes = None
        imdb_id = show_item.vtag.getIMDBNumber()
        year = int(show_item.vtag.getYear())

        if settings.getBool('library.check'):
            result = self.check_in_library(tmdb=item.video_ids.tmdb, imdb=imdb_id, year=year, all_episodes=True)
            if isinstance(result, list):
                existing_episodes: Optional[List[InLibDict]] = result
            else:
                existing_episodes = None

        # Determine if any episodes need to be written for the entire show
        any_episode_to_write = False
        if item.ref.is_show:
            for sz in item.season_iter():
                for ep in sz.episode_iter():
                    if self._should_write_episode(ep, existing_episodes):
                        any_episode_to_write = True
                        break
                if any_episode_to_write:
                    break
        elif item.ref.is_season:
            for ep in item.episode_iter():
                if self._should_write_episode(ep, existing_episodes):
                    any_episode_to_write = True
                    break
        elif item.ref.is_episode:
            if self._should_write_episode(item, existing_episodes):
                any_episode_to_write = True

        if not any_episode_to_write:
            return  # No episodes to write, so skip creating the show folder

        if (old := self.mkdirs(target.path)) is not None:
            target = evolve(target, path=old)
        else:
            fflog(f'ERROR: Failed to create show folder {target.path!r} for {imdb_id}. Aborting.')
            return

        if const.library.flat_show_folder:
            flat = True
        else:
            # detect if any *.strm exists in the show folder
            flat = bool(next(iter(target.path.glob('*.strm')), None))
        # write strm file(s)
        if item.ref.is_show:
            # iterate over seasons
            for sz in item.season_iter():
                self._write_season(sz, target=target, flat=flat, existing_episodes=existing_episodes)
        elif item.ref.is_season:
            # write single season
            self._write_season(item, target=target, flat=flat, existing_episodes=existing_episodes)
        elif item.ref.is_episode:
            # create season path and write single epsiode
            if flat:
                season_target = target
            else:
                season_target = evolve(target, path=target.path / f'Season {item.season}')
            if self.mkdirs(season_target.path) is None:
                fflog(f'ERROR: Failed to create season folder {season_target.path!r}. Aborting.')
                return
            self._write_episode(item, target=season_target, existing_episodes=existing_episodes)
        else:
            fflog(f'ERROR: Unknown ref type {item.ref!r}.')
        # prepare nfo file
        with self.write(target.path / 'tvshow.nfo') as f:
            f.write(ffinfo.web_url(show_item.ref))
        # update kodi library
        if reload:
            executebuiltin("UpdateLibrary(video)", True)

    def add(self, items: FFRef | Iterable[FFRef], *, reload: bool = True, dedup: set[MediaRef] | None = None) -> None:
        """
        Add item or items (normalized with TMDB id). Get skeleton data.

        :param dedup: shared across chunked calls covering one logical sync run (see
            lib.service.main.add_to_library()). Only guards the disk write below - every item
            still goes through the skeleton fetch above, which is what actually resolves an
            IMDb-only ref to its real (comparable) TMDB id in the first place.
        """
        if isinstance(items, (MediaRef, FFItem)):
            items = [items]
        # precheck and filter only movies and shows
        items = [it for it in items if it is not None and it.type in ('movie', 'show')]
        if not items:
            return
        fflog(f'Library folders: movies={self.movies_dir!r}, tv={self.tv_dir!r}')
        self._added_movies = 0
        self._added_episodes = 0
        # get base EN info
        for item in ffinfo.get_en_skel_items(items, locale=const.library.title_language):
            if self._DRY_RUN:
                print(f'ADD: {item}')
            if dedup is not None:
                if item.ref in dedup:
                    fflog(f'Skipping {item.ref!r} - already written earlier in this sync run.')
                    continue
            try:
                if item.ref.is_movie:
                    self._add_movie(item, reload=reload)
                elif item.ref.type == 'show':
                    self._add_show(item, reload=reload)
                else:
                    continue
            except Exception:
                fflog_exc()
                continue  # A failed file must not drop all the remaining items.
            if dedup is not None:
                dedup.add(item.ref)
        source = 'sync' if dedup is not None else 'manual'
        fflog(f'Added: {self._added_movies} movie(s), {self._added_episodes} episode(s) ({source}).')
        if settings.getBool('library.check'):
            self.clear_cache()

    def add_single(self, item: Union[MediaRef, FFItem], *, reload: bool = True) -> None:
        if isinstance(item, MediaRef):
            if found := ffinfo.find_item(item, progress=ffinfo.Progress.NO, details=const.library.info_details, crew_limit=0):
                item = found
            else:
                return
        if item.ref.is_movie:
            self._add_movie(item, reload=reload)
        elif item.ref.type == 'show':  # show, season, episode
            self._add_show(item, reload=reload)
        else:
            fflog(f'ERROR: Unsupported type {item.ref!r}.')
        if settings.getBool('library.check'):
            self.clear_cache()

    def add_multiple(self, items) -> None:
        """Add multiple media items to library"""
        raise NotImplementedError('\nNOT implemented yet\n')

        heading = L(30124, 'Add to library')
        choices = Dialog().multiselect(heading, [item for item in items if item])
        if choices:
            for idx in choices:
                ffitem = items[idx]
                # make sure ffitem and ffid exist
                if ffitem:
                    ffid = ffitem.ffid
                    if ffid:
                        self.add_single(ffid, ffitem, reload=False)

            # update kodi library
            executebuiltin("UpdateLibrary(video)", True)


library = LibTools()


if __name__ == '__main__':
    from .cmdline import DebugArgumentParser, parse_ref
    from cdefs import constdef
    from ..service.client import service_client

    p = DebugArgumentParser(dest='cmd')
    p.add_argument('--media-dir', help='override media folder')
    p.add_argument('--service', action='store_true', help='start service')
    p.add_argument('--no-service', action='store_false', dest='service', help='skip service (default)')
    p.add_argument('--dry-run', action='store_true', help='dry run, do not write anything')
    with p.with_subparser('add') as pp:
        # pp.add_argument('ref', type=parse_ref, help='ref to media')
        pp.add_argument('ref', nargs='+', type=parse_ref, help='media ref')
    args = p.parse_args()
    # print(args); exit()

    if args.dry_run:
        LibTools._DRY_RUN = True
    if args.service:
        pass
        # service = start_service()
    else:
        constdef._locked = False  # type: ignore
        const.tune.service.http_server.try_count = 1
        constdef._locked = True  # type: ignore
        service = None
        service_client.__class__.LOG_EXCEPTION = False
    if args.media_dir:
        LibTools._DEBUG_FOLDER = args.media_dir
    # if args.cmd == 'add':
    #     library.add_single(args.ref, reload=False)
    if args.cmd == 'add':
        library.add(args.ref, reload=False)
