# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""Spanish source display rules shared by the source list and Kodi window.

No site requests or source modifications happen here. This deliberately does not
recognize Telegram, German, Polish or generic sources as Spanish.
"""

SPANISH_PROVIDERS = frozenset((
    'pelispedia', 'verpeliculasonline', 'cinecalidad',
    'gnulalife', 'pelisforte', 'rtvcplay', 'artees', 'homecine', 'peliplayhd',
))
DEFAULT_SPANISH_ACCENT = 'FFFF4FA3'
_OLD_SPANISH_DEFAULT = 'FF9C6BFF'

def is_spanish_provider(provider, telegram_aggregate=False):
    return not telegram_aggregate and str(provider or '').strip().lower() in SPANISH_PROVIDERS


def spanish_accent(raw=None):
    """Use the ES accent setting, upgrading only the old shipped violet default.

    Accept an ARGB/RGB hex value chosen by the user. Do not force a palette
    over custom colors; the previous implementation ignored this setting.
    """
    value = str(raw or '').strip().lstrip('#').upper()
    if value == _OLD_SPANISH_DEFAULT or not value:
        return DEFAULT_SPANISH_ACCENT
    if len(value) == 6 and all(ch in '0123456789ABCDEF' for ch in value):
        value = 'FF' + value
    if len(value) != 8 or any(ch not in '0123456789ABCDEF' for ch in value):
        return DEFAULT_SPANISH_ACCENT
    return value


def search_language_bucket(raw, provider="", telegram_aggregate=False):
    """Group Castellano, Latino and VOSE as ES in progress summaries."""
    language = str(raw or '').lower().strip()
    if is_spanish_provider(provider, telegram_aggregate):
        return 'ES'
    if language in ('es', 'lat', 'vose'):
        return 'ES'
    return language.upper() if language else 'EN'
