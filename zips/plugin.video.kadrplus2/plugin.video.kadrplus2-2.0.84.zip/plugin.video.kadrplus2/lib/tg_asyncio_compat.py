# -*- coding: utf-8 -*-
"""Asyncio compatibility helpers for Telegram inside Kodi.

Android/Linux keep the existing per-thread asyncio behaviour.  Windows is
intentionally isolated: Telegram work is handed off by telegram.py to a normal
``threading.Thread`` and that thread owns an explicit ``SelectorEventLoop``.
No global Windows asyncio policy is replaced, so Kodi's CPythonInvoker thread
and other add-ons are left untouched.
"""
from __future__ import annotations

import asyncio
import contextlib
import os
import sys
import threading


def is_windows():
    return os.name == 'nt' or sys.platform.lower().startswith('win')


def is_android():
    if is_windows():
        return False
    if sys.platform.lower().startswith('android'):
        return True
    if os.environ.get('ANDROID_ROOT') or os.environ.get('ANDROID_DATA'):
        return True
    return False


def prepare_policy(logger=None):
    """Kept for API compatibility; do not alter Kodi's global asyncio policy."""
    return False


def bind_event_loop(loop):
    """Bind a loop to the current *normal Python thread*.

    Windows Telegram operations are moved to a dedicated threading.Thread
    before this function is called, so there is no need to fight Kodi's native
    CPythonInvoker/DummyThread policy storage.
    """
    if loop is None or loop.is_closed():
        raise RuntimeError('cannot bind a missing or closed event loop')
    asyncio.set_event_loop(loop)
    return loop


def new_event_loop(logger=None):
    """Create a local loop without changing process-wide policy."""
    if is_windows():
        selector_cls = getattr(asyncio, 'SelectorEventLoop', None)
        if selector_cls is None:
            raise RuntimeError('SelectorEventLoop is unavailable on Windows')
        loop = selector_cls()
        bind_event_loop(loop)
        if logger:
            try:
                logger('[telegram] Windows worker: utworzono lokalny SelectorEventLoop')
            except Exception:
                pass
        return loop

    # Preserve the older Android/Linux behaviour. Kodi builds can occasionally
    # expose a cleared/custom event-loop policy, so retain the established
    # Selector/default-policy fallbacks on those platforms.
    try:
        loop = asyncio.new_event_loop()
    except Exception as first_error:
        selector_cls = getattr(asyncio, 'SelectorEventLoop', None)
        if selector_cls is None:
            raise
        try:
            loop = selector_cls()
        except Exception:
            policy_cls = getattr(asyncio, 'DefaultEventLoopPolicy', None)
            if policy_cls is None:
                raise first_error
            asyncio.set_event_loop_policy(policy_cls())
            loop = asyncio.new_event_loop()
    try:
        asyncio.set_event_loop(loop)
    except Exception:
        pass
    return loop


def get_or_create_event_loop(cache=None, logger=None):
    """Return a per-thread loop; Windows always creates an explicit Selector."""
    tid = threading.get_ident()
    if cache is not None:
        try:
            cached = cache.get(tid)
            if cached is not None and not cached.is_closed():
                try:
                    asyncio.set_event_loop(cached)
                except Exception:
                    pass
                return cached
        except Exception:
            try:
                cache.pop(tid, None)
            except Exception:
                pass

    try:
        loop = asyncio.get_running_loop()
        if loop is not None and not loop.is_closed():
            if cache is not None:
                cache[tid] = loop
            return loop
    except Exception:
        pass

    if not is_windows():
        try:
            loop = asyncio.get_event_loop()
            if loop is not None and not loop.is_closed():
                if cache is not None:
                    cache[tid] = loop
                return loop
        except Exception as exc:
            if logger:
                try:
                    logger('[telegram] brak pętli w wątku Kodi; tworzę lokalną: %r' % (exc,))
                except Exception:
                    pass

    # On Windows deliberately skip asyncio.get_event_loop()/new_event_loop(),
    # since the process default can be Proactor and Python 3.8 may call
    # signal.set_wakeup_fd from Kodi's non-main callback thread.
    loop = new_event_loop(logger=logger)
    if cache is not None:
        cache[tid] = loop
    return loop


@contextlib.contextmanager
def construction_loop(loop):
    """Expose ``loop`` while Telethon 1.x creates asyncio primitives."""
    bind_event_loop(loop)
    events_mod = getattr(asyncio, 'events', None)
    get_running = getattr(events_mod, '_get_running_loop', None)
    set_running = getattr(events_mod, '_set_running_loop', None)
    changed = False
    previous = None
    try:
        if callable(get_running) and callable(set_running):
            previous = get_running()
            if previous is None:
                set_running(loop)
                changed = True
        yield loop
    finally:
        if changed:
            try:
                set_running(previous)
            except Exception:
                pass
