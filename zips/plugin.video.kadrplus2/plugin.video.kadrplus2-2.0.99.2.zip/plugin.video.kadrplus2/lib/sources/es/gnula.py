# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""GnulaHD (ww3.gnulahd.nu) movie/TV provider for Kadr+ 2.0.

The current site exposes search cards, exact ``SxE`` episode labels and player
metadata in the ``_gd`` / ``_gnpv_ep_langs`` JSON variables.  Player language
labels are kept separate (LAT / CAST / SUB); unknown labels are rejected.
"""

from __future__ import annotations

import json
import re
from html import unescape
from urllib.parse import quote_plus, urlsplit

from lib.sources.es._kadr_es_common import (
    absolute_site_url,
    choose_candidate,
    clean_text,
    decode_ref,
    dedup_source_rows,
    diag,
    encode_ref,
    language_code,
    language_info,
    quality_from,
    site_client,
    source_row,
    titles_from,
    year_of,
)


_BASE = "https://ww3.gnulahd.nu"
_REF = "kadr-gnula:"
_ATTR_RE = re.compile(r'''\b([\w:-]+)\s*=\s*["']([^"']*)["']''', re.I)
_THEYTUBE_TOKEN = "eece56848d3929ee78f5fe8e3a62de2d"


def _attrs(text):
    return {m.group(1).lower(): unescape(m.group(2)) for m in _ATTR_RE.finditer(text or "")}


def _class_text(html, tag, token):
    match = re.search(
        r"<%s\b[^>]*class=[\"'][^\"']*\b%s\b[^\"']*[\"'][^>]*>([\s\S]*?)</%s>"
        % (re.escape(tag), re.escape(token), re.escape(tag)),
        html or "",
        re.I,
    )
    return clean_text(match.group(1)) if match else ""


def _parse_search(html, base):
    out = []
    # Current layout (verified by maintained CloudStream implementations).
    card_re = re.compile(
        r'''<a\b([^>]*class=["'][^"']*\bgnrd-card\b[^"']*["'][^>]*)>([\s\S]*?)</a>''',
        re.I,
    )
    for match in card_re.finditer(html or ""):
        attrs = _attrs(match.group(1))
        body = match.group(2)
        url = absolute_site_url(attrs.get("href"), base)
        title = _class_text(body, "span", "gnrd-card-title")
        if not url or not title:
            continue
        badge = _class_text(body, "span", "gnrd-type-badge").lower()
        path = (urlsplit(url).path or "").lower()
        if "pelicula" in badge or "/pelicula/" in path:
            kind = "movie"
        elif any(x in badge for x in ("serie", "anime")) or any(x in path for x in ("/serie/", "/anime/")):
            kind = "show"
        else:
            continue
        out.append({"title": title, "url": url, "year": year_of(body), "kind": kind})
    if out:
        return out
    # Compatible fallback for the immediately preceding Gnula layout.
    for match in re.finditer(r'''<article\b[^>]*class=["'][^"']*\bbs\b[^"']*["'][^>]*>([\s\S]*?)</article>''', html or "", re.I):
        body = match.group(1)
        link = re.search(r'''<a\b[^>]*href=["']([^"']+)["'][^>]*title=["']([^"']+)["']''', body, re.I)
        if not link:
            continue
        url = absolute_site_url(link.group(1), base)
        type_text = _class_text(body, "div", "typez").lower()
        kind = "movie" if "pelicula" in type_text or "película" in type_text else "show"
        out.append({"title": clean_text(link.group(2)), "url": url, "year": year_of(body), "kind": kind})
    return out


def _extract_balanced_array(text, start):
    pos = (text or "").find("[", max(0, int(start)))
    if pos < 0:
        return ""
    depth = 0
    quote = ""
    escaped = False
    for index in range(pos, len(text)):
        ch = text[index]
        if quote:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = ""
            continue
        if ch in ("'", '"'):
            quote = ch
        elif ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
            if depth == 0:
                return text[pos:index + 1]
    return ""


def _player_groups(html):
    for marker in ("_gnpv_ep_langs", "_gd"):
        match = re.search(r"(?:var\s+)?%s\s*=" % re.escape(marker), html or "", re.I)
        if not match:
            continue
        raw = _extract_balanced_array(html, match.end())
        if not raw:
            continue
        try:
            data = json.loads(raw)
            if isinstance(data, list):
                return data
        except Exception:
            continue
    return []


def _episode_links(html, base):
    out = []
    # Current and previous layouts both use one anchor per episode.
    for match in re.finditer(r'''<a\b([^>]*)>([\s\S]*?)</a>''', html or "", re.I):
        attrs = _attrs(match.group(1))
        body = match.group(2)
        class_value = attrs.get("class", "")
        if "gnrd-epc" not in class_value and "epl-num" not in body and "gnrd-epc-n" not in body:
            continue
        label = _class_text(body, "span", "gnrd-epc-n") or _class_text(body, "div", "epl-num")
        nums = re.match(r"^0*(\d+)\s*x\s*0*(\d+)$", label, re.I)
        url = absolute_site_url(attrs.get("href"), base)
        if nums and url:
            out.append((int(nums.group(1)), int(nums.group(2)), url))
    return out


class source:
    priority = 1
    language = ["es"]
    domains = ["ww3.gnulahd.nu", "gnulahd.nu"]

    def __init__(self):
        self.client = site_client("gnula", (_BASE,))

    def _find(self, wanted, year, kind):
        for title in (wanted or ())[:3]:
            html = self.client.get_text("/?s=" + quote_plus(title))
            if not html:
                continue
            items = _parse_search(html, self.client.base)
            diag("gnula", "search", "kind=%s query=%s rows=%d" % (kind, clean_text(title)[:40], len(items)))
            item = choose_candidate(items, wanted, year, min_score=0.93, expected_kind=kind)
            if item:
                return item
        return None

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        wanted = titles_from(localtitle, title, aliases, limit=3, ffitem=getattr(self, "ffitem", None), media_type="movie")
        item = self._find(wanted, year, "movie") if wanted else None
        if not item:
            return None
        return encode_ref(_REF, {"kind": "movie", "url": item["url"], "year": year_of(item.get("year") or year)})

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        wanted = titles_from(localtvshowtitle, tvshowtitle, aliases, limit=3, ffitem=getattr(self, "ffitem", None), media_type="show")
        item = self._find(wanted, year, "show") if wanted else None
        if not item:
            return None
        return encode_ref(_REF, {"kind": "show", "url": item["url"], "year": year_of(item.get("year") or year)})

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        ref = decode_ref(_REF, url)
        if not ref or ref.get("kind") != "show":
            return None
        try:
            wanted_s, wanted_e = int(season), int(episode)
        except Exception:
            return None
        if wanted_s <= 0 or wanted_e <= 0:
            return None
        detail_url = str(ref.get("url") or "")
        html = self.client.get_text(detail_url)
        if not html:
            return None
        exact = {ep_url for ep_s, ep_e, ep_url in _episode_links(html, self.client.base) if ep_s == wanted_s and ep_e == wanted_e}
        if len(exact) != 1:
            diag("gnula", "episode", "s=%d e=%d matches=%d" % (wanted_s, wanted_e, len(exact)))
            return None
        return encode_ref(_REF, {"kind": "episode", "url": next(iter(exact)), "season": wanted_s, "episode": wanted_e})

    def _resolve_theytube(self, url, referer):
        host = (urlsplit(url).hostname or "").lower()
        if "they.tube" not in host:
            return url
        match = re.search(r'''the(?:y)?\.tube/(?:e/)?([A-Za-z0-9_-]+)''', url, re.I)
        if not match:
            return ""
        data = self.client.get_json(
            "/panel/the-tube-resolve.php",
            params={"code": match.group(1), "t": _THEYTUBE_TOKEN},
            referer=referer,
        )
        master = str((data or {}).get("master") or "").strip() if isinstance(data, dict) else ""
        return master if master.startswith("https://") else ""

    def sources(self, url, hostDict, hostprDict, **kwargs):
        ref = decode_ref(_REF, url)
        if not ref or ref.get("kind") not in ("movie", "episode"):
            return []
        detail_url = str(ref.get("url") or "")
        html = self.client.get_text(detail_url)
        if not html:
            return []
        groups = _player_groups(html)
        rows = []
        unknown_lang = 0
        for group in groups:
            if not isinstance(group, dict):
                continue
            label = group.get("label") or group.get("video_language") or group.get("language") or ""
            lang = language_code(label)
            if not lang:
                unknown_lang += 1
                continue
            servers = group.get("servers") or group.get("sortedEmbeds") or group.get("embeds") or ()
            for server in servers or ():
                if not isinstance(server, dict):
                    continue
                src = unescape(str(server.get("src") or server.get("url") or server.get("link") or "")).replace("\\/", "/").strip()
                if src.startswith("//"):
                    src = "https:" + src
                if not src.startswith("https://"):
                    continue
                src = self._resolve_theytube(src, detail_url)
                if not src:
                    continue
                row = source_row(
                    src,
                    hostDict,
                    hostprDict,
                    quality=quality_from(server.get("quality") or server.get("label") or "", default="HD"),
                    language=lang,
                    info=language_info(lang),
                )
                if row:
                    rows.append(row)
        diag("gnula", "sources", "groups=%d rows=%d unknown_lang=%d" % (len(groups), len(rows), unknown_lang))
        return dedup_source_rows(rows)

    def resolve(self, url):
        return url
