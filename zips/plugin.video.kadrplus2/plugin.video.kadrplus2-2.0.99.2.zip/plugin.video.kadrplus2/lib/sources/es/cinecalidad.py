# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""CineCalidad (cinecalidad.vg) movie provider for Kadr+ 2.0.

The current site exposes its watch targets as base64-encoded ``data-src``
values.  Some decode directly to a hoster; others point at one short
CineCalidad intermediate page which contains the real iframe/link.  This
provider intentionally ignores downloads/torrents and uses only the site's
Latino watch path.
"""

from __future__ import annotations

import base64
import binascii
import re
from html import unescape
from urllib.parse import quote_plus, unquote, urlsplit

from lib.sources.es._kadr_es_common import (
    absolute_site_url,
    choose_candidate,
    clean_text,
    decode_ref,
    dedup_source_rows,
    diag,
    encode_ref,
    quality_from,
    site_client,
    source_row,
    titles_from,
    year_of,
)


_BASE = "https://www.cinecalidad.vg"
_REF = "kadr-cinecalidad:"
_ARTICLE_RE = re.compile(r"<article\b[\s\S]*?</article>", re.I)
_ATTR_RE = re.compile(r'''\b([\w:-]+)\s*=\s*["']([^"']*)["']''', re.I)


def _attrs(text):
    return {m.group(1).lower(): unescape(m.group(2)) for m in _ATTR_RE.finditer(text or "")}


def _first_attr(html, tag, attr):
    for match in re.finditer(r"<%s\b([^>]*)>" % re.escape(tag), html or "", re.I):
        value = _attrs(match.group(1)).get(attr.lower())
        if value:
            return value
    return ""


def _class_text(html, tag, token):
    match = re.search(
        r"<%s\b[^>]*class=[\"'][^\"']*\b%s\b[^\"']*[\"'][^>]*>([\s\S]*?)</%s>"
        % (re.escape(tag), re.escape(token), re.escape(tag)),
        html or "",
        re.I,
    )
    return clean_text(match.group(1)) if match else ""


def _parse_search(html, base):
    out = []
    for match in _ARTICLE_RE.finditer(html or ""):
        article = match.group(0)
        href = _first_attr(article, "a", "href")
        url = absolute_site_url(href, base)
        if not url or "/pelicula/" not in (urlsplit(url).path or "").lower():
            continue
        title = _class_text(article, "h2", "title")
        if not title:
            h2 = re.search(r"<h2\b[^>]*>([\s\S]*?)</h2>", article, re.I)
            title = clean_text(h2.group(1)) if h2 else ""
        if not title:
            image = re.search(r'''<img\b[^>]*\balt=["']([^"']+)["']''', article, re.I)
            title = clean_text(image.group(1)) if image else ""
        if not title:
            continue
        title_year = re.match(r"^(.*?)\s*\(((?:19|20)\d{2})\)\s*$", title)
        year = year_of(article)
        if title_year:
            title = clean_text(title_year.group(1))
            year = title_year.group(2)
        out.append({"title": title, "url": url, "year": year, "kind": "movie"})
    return out


def _decode_player_value(value):
    value = unescape(str(value or "")).strip()
    if not value:
        return ""
    if value.startswith("https://"):
        return value
    if value.startswith("http://"):
        return ""
    try:
        raw = value.encode("ascii")
        raw += b"=" * (-len(raw) % 4)
        decoded = base64.b64decode(raw, validate=True).decode("utf-8", errors="strict").strip()
    except (ValueError, UnicodeError, binascii.Error):
        return ""
    return unescape(decoded).strip() if decoded.startswith("https://") else ""


def _final_from_intermediate(html, referer):
    patterns = (
        r'''<iframe\b[^>]*\bsrc=["']([^"']+)["']''',
        r'''<a\b[^>]*\bid=["']btn_enlace["'][^>]*\bhref=["']([^"']+)["']''',
        r'''id=["']btn_enlace["'][^>]*>[\s\S]*?href=["']([^"']+)["']''',
        r'''<a\b[^>]*id=["']some_link["'][^>]*\bvalue=["']([^"']+)["']''',
        r'''window\.location\.href\s*=\s*["']([^"']+)["']''',
    )
    for pattern in patterns:
        match = re.search(pattern, html or "", re.I)
        if match:
            return absolute_site_url(match.group(1), referer)
    return ""


def _unwrap_protect(url):
    parts = urlsplit(str(url or ""))
    if parts.path not in ("/protect/v.php", "/protect/v2.php"):
        return url
    match = re.search(r"(?:^|&)i=([^&]+)", parts.query or "")
    token = unquote(match.group(1)) if match else ""
    decoded = _decode_player_value(token)
    return decoded or ""


class source:
    priority = 1
    language = ["es"]
    domains = ["cinecalidad.vg", "www.cinecalidad.vg"]

    def __init__(self):
        self.client = site_client("cinecalidad", (_BASE,))

    def _find(self, wanted, year):
        for title in (wanted or ())[:3]:
            html = self.client.get_text("/?s=" + quote_plus(title))
            if not html:
                continue
            items = _parse_search(html, self.client.base)
            diag("cinecalidad", "search", "query=%s rows=%d" % (clean_text(title)[:40], len(items)))
            item = choose_candidate(items, wanted, year, min_score=0.93, expected_kind="movie")
            if item:
                return item
        return None

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        wanted = titles_from(localtitle, title, aliases, limit=3, ffitem=getattr(self, "ffitem", None), media_type="movie")
        item = self._find(wanted, year) if wanted else None
        if not item:
            return None
        return encode_ref(_REF, {"kind": "movie", "url": item["url"], "year": year_of(item.get("year") or year)})

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        return None

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        return None

    def _resolve_player_value(self, value, detail_url):
        target = _decode_player_value(value)
        if not target:
            return ""
        target = _unwrap_protect(target)
        if not target:
            return ""
        host = (urlsplit(target).hostname or "").lower()
        if host not in ("cinecalidad.vg", "www.cinecalidad.vg"):
            return target if target.startswith("https://") else ""
        intermediate = self.client.get_text(target, referer=detail_url)
        if not intermediate:
            return ""
        final = _final_from_intermediate(intermediate, target)
        final = _unwrap_protect(final)
        return final if final.startswith("https://") else ""

    def sources(self, url, hostDict, hostprDict, **kwargs):
        ref = decode_ref(_REF, url)
        if not ref or ref.get("kind") != "movie":
            return []
        detail_url = str(ref.get("url") or "")
        html = self.client.get_text(detail_url)
        if not html:
            return []
        rows = []
        seen_tokens = set()
        # Current watch options are anchors/buttons with a base64 data-src.  A
        # bounded global fallback is deliberate because the surrounding markup
        # has changed while the data-src contract remained stable.
        options = list(re.finditer(
            r'''\b(?:data-src|data-lmt)=["']([^"']+)["'][^>]*>[\s\S]{0,800}?(?:data-option[^>]*>)?([^<]{0,80})</a>''',
            html,
            re.I,
        ))
        values = []
        for match in options:
            values.append((match.group(1), clean_text(match.group(2))))
        if not values:
            for match in re.finditer(r'''\b(?:data-src|data-lmt)=["']([^"']+)["']''', html, re.I):
                values.append((match.group(1), ""))
        for token, label in values:
            token = str(token or "").strip()
            if not token or token in seen_tokens:
                continue
            seen_tokens.add(token)
            folded = clean_text(label).lower()
            if folded in ("trailer", "youtube"):
                continue
            final = self._resolve_player_value(token, detail_url)
            if not final:
                continue
            row = source_row(
                final,
                hostDict,
                hostprDict,
                quality=quality_from(label, default="HD"),
                language="lat",
                info="Latino",
            )
            if row:
                rows.append(row)
        diag("cinecalidad", "sources", "values=%d rows=%d" % (len(values), len(rows)))
        return dedup_source_rows(rows)

    def resolve(self, url):
        return url
