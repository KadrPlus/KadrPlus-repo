# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""Shared helpers for Kadr+ Spanish providers.

Spain/Castellano is the primary Spanish variant. Latino and VOSE stay distinct
at source-row level. Title expansion is bounded: confirmed Spain aliases/TMDb
es-ES first, then one original-title fallback.
"""

from __future__ import annotations

import re
import threading
import unicodedata
from difflib import SequenceMatcher
from html import unescape
from urllib.parse import urljoin, urlsplit

from lib.sources.de._kadr_de_common import (
    SiteClient,
    clean_text,
    decode_ref,
    dedup_source_rows,
    diag,
    encode_ref,
    quality_from,
    source_row,
)


def register(sources, group=""):
    """Support module only; do not expose it as a provider."""
    return None


_YEAR_RE = re.compile(r"(?<!\d)((?:19|20)\d{2})(?!\d)")
_ES_COUNTRIES = frozenset(("es", "esp", "spain", "españa", "espana"))
_ORIGINAL_COUNTRIES = frozenset(("original", "orig"))
_ES_ALIAS_CACHE = {}
_ES_ALIAS_LOCK = threading.Lock()
_ES_ALIAS_CACHE_MAX = 128


def year_of(value):
    match = _YEAR_RE.search(str(value or ""))
    return match.group(1) if match else ""


def normalize_title(value):
    value = clean_text(value)
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    value = value.lower().replace("’", "").replace("'", "")
    value = re.sub(r"\s*\((?:19|20)\d{2}\)\s*$", " ", value)
    value = re.sub(r"\s+(?:online|pelicula\s+completa|serie\s+online)\s*$", " ", value, flags=re.I)
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def title_score(candidate, wanted):
    left = normalize_title(candidate)
    right = normalize_title(wanted)
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0
    seq = SequenceMatcher(None, left, right).ratio()
    lt, rt = set(left.split()), set(right.split())
    union = lt | rt
    jac = (len(lt & rt) / float(len(union))) if union else 0.0
    coverage = min(len(left), len(right)) / float(max(len(left), len(right)))
    compact = SequenceMatcher(None, left.replace(" ", ""), right.replace(" ", "")).ratio()
    score = (0.58 * seq) + (0.32 * jac) + (0.10 * coverage)
    if compact >= 0.94 and coverage >= 0.85:
        score = max(score, compact * 0.99)
    return max(0.0, min(score, 0.999))


def choose_candidate(items, wanted_titles, wanted_year="", *, min_score=0.93, expected_kind=""):
    wanted_year = year_of(wanted_year)
    best = None
    best_score = -1.0
    for item in items or ():
        if not isinstance(item, dict):
            continue
        if expected_kind and item.get("kind") and item.get("kind") != expected_kind:
            continue
        candidate = clean_text(item.get("title") or item.get("name"))
        if not candidate:
            continue
        score = max((title_score(candidate, wanted) for wanted in wanted_titles or ()), default=0.0)
        if score < min_score:
            continue
        item_year = year_of(item.get("year") or item.get("date"))
        if wanted_year and item_year:
            if item_year != wanted_year:
                continue
            score += 0.08
        if score > best_score:
            best_score, best = score, item
    return best


def _ffitem_tmdb_id(ffitem, media_type):
    candidates = []
    try:
        if media_type == "show":
            show_item = getattr(ffitem, "show_item", None)
            if show_item:
                candidates.append(show_item)
    except Exception:
        pass
    if ffitem is not None:
        candidates.append(ffitem)
    for item in candidates:
        try:
            ref = getattr(item, "ref", None)
            value = int(getattr(ref, "tmdb_id", 0) or 0)
            if value > 0:
                return value
        except Exception:
            pass
        try:
            ids = getattr(item, "ids", None) or {}
            value = int(ids.get("tmdb") or 0)
            if value > 0:
                return value
        except Exception:
            pass
    return 0


def _ffitem_original_title(ffitem, media_type):
    candidates = []
    try:
        if media_type == "show":
            show_item = getattr(ffitem, "show_item", None)
            if show_item:
                candidates.append(show_item)
    except Exception:
        pass
    if ffitem is not None:
        candidates.append(ffitem)
    for item in candidates:
        try:
            vtag = getattr(item, "vtag", None)
            if vtag is not None:
                value = clean_text(vtag.getOriginalTitle())
                if value:
                    return value
        except Exception:
            pass
    return ""


def _existing_spain_aliases(ffitem, media_type):
    out = []
    candidates = []
    try:
        if media_type == "show":
            show_item = getattr(ffitem, "show_item", None)
            if show_item:
                candidates.append(show_item)
    except Exception:
        pass
    if ffitem is not None:
        candidates.append(ffitem)
    for item in candidates:
        try:
            aliases = getattr(item, "aliases_info", ()) or ()
        except Exception:
            aliases = ()
        for alias in aliases:
            try:
                country = str(getattr(alias, "country", "") or "").strip().lower()
                value = getattr(alias, "title", "")
            except Exception:
                if isinstance(alias, dict):
                    country = str(alias.get("country") or "").strip().lower()
                    value = alias.get("title") or alias.get("name") or ""
                else:
                    continue
            if country in _ES_COUNTRIES:
                value = clean_text(value)
                if value:
                    out.append(value)
    return out


def _fetch_spain_tmdb_titles(media_type, tmdb_id):
    if media_type not in ("movie", "show") or not tmdb_id:
        return []
    key = (media_type, int(tmdb_id))
    with _ES_ALIAS_LOCK:
        if key in _ES_ALIAS_CACHE:
            return list(_ES_ALIAS_CACHE[key])
        values = []
        try:
            from lib.ff.info import ffinfo
            ctype = "movie" if media_type == "movie" else "tv"
            data = ffinfo.tmdb.get(
                "%s/%s" % (ctype, int(tmdb_id)),
                lang="es-ES",
                append_to_response=("alternative_titles",),
                request_timeout=2.0,
                attempts=1,
            ) or {}
            ranked = []
            if isinstance(data, dict):
                primary = clean_text(data.get("title") or data.get("name"))
                if primary:
                    ranked.append(primary)
                alt = data.get("alternative_titles") or {}
                rows = alt.get("results", alt.get("titles", ())) if isinstance(alt, dict) else ()
                for row in rows or ():
                    if not isinstance(row, dict):
                        continue
                    country = str(row.get("iso_3166_1") or row.get("country") or "").upper()
                    if country != "ES":
                        continue
                    value = clean_text(row.get("title") or row.get("name"))
                    if value:
                        ranked.append(value)
            # Compatibility fallback if a TMDb client/proxy omits the
            # appended alternative_titles block. Keep it bounded like DE.
            if not ranked:
                rows = ffinfo.tmdb.aliases(
                    media_type, int(tmdb_id), request_timeout=2.0, attempts=1,
                ) or ()
                for row in rows:
                    if not isinstance(row, dict):
                        continue
                    country = str(row.get("iso_3166_1") or row.get("country") or "").upper()
                    if country != "ES":
                        continue
                    value = clean_text(row.get("title") or row.get("name"))
                    if value:
                        ranked.append(value)
            seen = set()
            for value in ranked:
                n = normalize_title(value)
                if n and n not in seen:
                    seen.add(n)
                    values.append(value)
        except Exception:
            values = []
        if len(_ES_ALIAS_CACHE) >= _ES_ALIAS_CACHE_MAX:
            try:
                _ES_ALIAS_CACHE.pop(next(iter(_ES_ALIAS_CACHE)))
            except Exception:
                _ES_ALIAS_CACHE.clear()
        _ES_ALIAS_CACHE[key] = tuple(values[:6])
        return list(_ES_ALIAS_CACHE[key])


def titles_from(localtitle, title, aliases, limit=5, *, ffitem=None, media_type="movie"):
    """Return bounded Spain-title pool, then one original-title fallback."""
    max_items = max(1, int(limit or 1))
    alias_values = list(aliases.values()) if isinstance(aliases, dict) else list(aliases or ())
    confirmed = []
    for alias in alias_values:
        if not isinstance(alias, dict):
            continue
        country = str(alias.get("country") or "").strip().lower()
        if country in _ES_COUNTRIES:
            value = clean_text(alias.get("title") or alias.get("name") or alias.get("originalname"))
            if value:
                confirmed.append(value)
    if ffitem is not None:
        confirmed.extend(_existing_spain_aliases(ffitem, media_type))
        tmdb_id = _ffitem_tmdb_id(ffitem, media_type)
        if tmdb_id:
            confirmed.extend(_fetch_spain_tmdb_titles(media_type, tmdb_id))

    out, seen = [], set()
    confirmed_keys = set()
    for value in confirmed:
        n = normalize_title(value)
        if n:
            confirmed_keys.add(n)
        if value and n and n not in seen:
            seen.add(n)
            out.append(value)
            if len(out) >= max_items:
                return out

    local_key = normalize_title(localtitle)
    if local_key and local_key in confirmed_keys and local_key not in seen:
        seen.add(local_key)
        out.append(clean_text(localtitle))

    original = ""
    for alias in alias_values:
        if not isinstance(alias, dict):
            continue
        country = str(alias.get("country") or "").strip().lower()
        if country in _ORIGINAL_COUNTRIES:
            original = clean_text(alias.get("originalname") or alias.get("original_title") or alias.get("title") or alias.get("name"))
            if original:
                break
    if not original:
        original = _ffitem_original_title(ffitem, media_type)
    if not original:
        original = clean_text(title)
    n = normalize_title(original)
    if original and n and n not in seen:
        if len(out) >= max_items:
            out = out[: max_items - 1]
        out.append(original)
    return out[:max_items]


def language_code(value):
    raw = clean_text(value).lower()
    folded = unicodedata.normalize("NFKD", raw).encode("ascii", "ignore").decode("ascii")
    token = re.sub(r"[^a-z0-9]+", " ", folded).strip()
    # Current ES sites often expose compact player labels (LAT / CAST / SUB /
    # ESP) instead of full words.  Accept only exact compact tokens so a
    # substring in an unrelated server name cannot silently become a language.
    if token in ("sub", "vose") or any(mark in folded for mark in ("subtit", "vose", "sub esp", "espanol sub")):
        return "vose"
    if token in ("lat", "latino", "latam") or any(mark in folded for mark in ("latino", "latam", "espanol latino")):
        return "lat"
    if token in ("cast", "castellano", "esp", "es") or any(mark in folded for mark in ("castellano", "espanol espana", "espanol", "spain", " esp ")):
        return "es"
    if token in ("en", "eng", "english", "ingles") or any(mark in folded for mark in ("ingles", "english")):
        return "en"
    return ""


def language_info(code):
    return {"es": "Castellano", "lat": "Latino", "vose": "VOSE", "en": "English"}.get(code, "")


def absolute_site_url(value, base):
    value = unescape(str(value or "")).strip()
    if not value or value == "#":
        return ""
    result = urljoin(base.rstrip("/") + "/", value)
    parts = urlsplit(result)
    return result if parts.scheme == "https" and parts.hostname else ""


def site_client(provider, bases):
    return SiteClient(
        provider,
        bases,
        timeout=(5, 12),
        headers={"Accept-Language": "es-ES,es;q=0.9,en;q=0.5"},
        max_redirects=3,
    )
