# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""VerPeliculasOnline movie provider for Kadr+ 2.0.

Current public pages expose Castellano/Latino/Subtitulado player options.  The
site uses the DooPlayer AJAX contract; downloads/torrents are deliberately not
returned by this provider.
"""

from __future__ import annotations

import json
import re
from html import unescape
from urllib.parse import quote_plus, urlsplit

from lib.sources.es._kadr_es_common import (
    absolute_site_url,
    choose_candidate,
    clean_text,
    decode_ref,
    dedup_source_rows,
    diag,
    encode_ref,
    language_code,
    language_info,
    quality_from,
    site_client,
    source_row,
    titles_from,
    year_of,
)


_BASES = ("https://verpeliculasonline.org", "https://ver-peliculas-online.org")
_REF = "kadr-verpelis:"
_ARTICLE_RE = re.compile(r"<article\b[\s\S]*?</article>", re.I)
_ATTR_RE = re.compile(r'''\b([\w:-]+)\s*=\s*["']([^"']*)["']''', re.I)


def _attrs(text):
    return {m.group(1).lower(): unescape(m.group(2)) for m in _ATTR_RE.finditer(text or "")}


def _first_attr(html, tag, attr):
    for match in re.finditer(r"<%s\b([^>]*)>" % re.escape(tag), html or "", re.I):
        value = _attrs(match.group(1)).get(attr.lower())
        if value:
            return value
    return ""


def _tag_text(html, tag, class_token=""):
    if class_token:
        pattern = re.compile(
            r"<%s\b[^>]*class=[\"'][^\"']*\b%s\b[^\"']*[\"'][^>]*>([\s\S]*?)</%s>"
            % (re.escape(tag), re.escape(class_token), re.escape(tag)),
            re.I,
        )
    else:
        pattern = re.compile(r"<%s\b[^>]*>([\s\S]*?)</%s>" % (re.escape(tag), re.escape(tag)), re.I)
    match = pattern.search(html or "")
    return clean_text(match.group(1)) if match else ""


def _parse_search(html, base):
    out = []
    for match in _ARTICLE_RE.finditer(html or ""):
        article = match.group(0)
        href = _first_attr(article, "a", "href")
        url = absolute_site_url(href, base)
        if not url or "/pelicula/" not in (urlsplit(url).path or "").lower():
            continue
        title = ""
        img_match = re.search(r'''<img\b[^>]*\balt=["']([^"']+)["']''', article, re.I)
        if img_match:
            title = clean_text(img_match.group(1))
        if not title:
            title = _tag_text(article, "h3", "title") or _tag_text(article, "h2", "entry-title")
        if not title:
            continue
        year = year_of(article)
        quality = _tag_text(article, "span", "quality")
        out.append({"title": title, "url": url, "year": year, "quality": quality, "kind": "movie"})
    return out


def _decode_ajax_payload(text):
    text = str(text or "").strip()
    if not text:
        return ""
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            value = data.get("embed_url") or data.get("url") or ""
            return unescape(str(value)).replace("\\/", "/").strip()
    except Exception:
        pass
    match = re.search(r'''["']embed_url["']\s*:\s*["']([^"']+)["']''', text, re.I)
    return unescape(match.group(1)).replace("\\/", "/").strip() if match else ""


def _normalize_known_alias(url):
    """Map the site's current opuxa alias to the resolver's canonical Netu/Waaw host."""
    url = str(url or "").strip()
    return url.replace("https://opuxa.lat/", "https://waaw.to/").replace("https://www.opuxa.lat/", "https://waaw.to/")


class source:
    priority = 1
    language = ["es"]
    domains = ["verpeliculasonline.org", "ver-peliculas-online.org"]

    def __init__(self):
        self.client = site_client("verpeliculasonline", _BASES)

    def _find(self, wanted, year):
        for title in (wanted or ())[:5]:
            html = self.client.get_text("/?s=" + quote_plus(title))
            if not html:
                continue
            items = _parse_search(html, self.client.base)
            diag("verpeliculasonline", "search", "query=%s rows=%d" % (clean_text(title)[:40], len(items)))
            item = choose_candidate(items, wanted, year, min_score=0.93, expected_kind="movie")
            if item:
                return item
        return None

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        wanted = titles_from(localtitle, title, aliases, limit=3, ffitem=getattr(self, "ffitem", None), media_type="movie")
        item = self._find(wanted, year) if wanted else None
        if not item:
            return None
        return encode_ref(_REF, {"kind": "movie", "url": item["url"], "quality": item.get("quality") or "HD", "year": year_of(item.get("year") or year)})

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        return None

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        return None

    def sources(self, url, hostDict, hostprDict, **kwargs):
        ref = decode_ref(_REF, url)
        if not ref or ref.get("kind") != "movie":
            return []
        detail_url = str(ref.get("url") or "")
        html = self.client.get_text(detail_url)
        if not html:
            return []
        quality_match = re.search(r'''<span\b[^>]*class=["'][^"']*\bquality\b[^"']*["'][^>]*>([\s\S]*?)</span>''', html, re.I)
        quality = quality_from(clean_text(quality_match.group(1)) if quality_match else ref.get("quality") or "HD", default="HD")
        rows = []
        options = [m.group(0) for m in re.finditer(
            r'''<li\b[^>]*id=["']player-option-[^"']+["'][^>]*>[\s\S]*?</li>''',
            html,
            re.I,
        )]
        for option in options:
            start_tag = re.search(r"<li\b([^>]*)>", option, re.I)
            attrs = _attrs(start_tag.group(1) if start_tag else "")
            dtype = attrs.get("data-type", "")
            post = attrs.get("data-post", "")
            nume = attrs.get("data-nume", "")
            if not dtype or not post or not nume or nume.lower() == "trailer":
                # data-* can be on a nested span/button; parse the whole option.
                dtype_m = re.search(r'''\bdata-type=["']([^"']+)["']''', option, re.I)
                post_m = re.search(r'''\bdata-post=["']([^"']+)["']''', option, re.I)
                nume_m = re.search(r'''\bdata-nume=["']([^"']+)["']''', option, re.I)
                dtype = dtype or (dtype_m.group(1) if dtype_m else "")
                post = post or (post_m.group(1) if post_m else "")
                nume = nume or (nume_m.group(1) if nume_m else "")
            if not dtype or not post or not nume or nume.lower() == "trailer":
                continue
            lang = language_code(option)
            if not lang:
                continue
            payload = self.client.post_text(
                "/wp-admin/admin-ajax.php",
                data={"action": "doo_player_ajax", "post": post, "nume": nume, "type": dtype},
                referer=detail_url,
            )
            embed = _normalize_known_alias(_decode_ajax_payload(payload))
            if not embed.startswith("https://"):
                continue
            row = source_row(
                embed,
                hostDict,
                hostprDict,
                quality=quality,
                language=lang,
                info=language_info(lang),
            )
            if row:
                rows.append(row)
        diag("verpeliculasonline", "sources", "options=%d rows=%d" % (len(options), len(rows)))
        return dedup_source_rows(rows)

    def resolve(self, url):
        return url
