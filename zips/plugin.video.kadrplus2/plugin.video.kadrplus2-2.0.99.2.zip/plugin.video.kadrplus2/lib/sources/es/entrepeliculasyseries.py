# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""EntrePeliculasySeries provider for Kadr+ 2.0.

The current site routes playback through ``/vidurl/`` pages.  Those pages
publish a small SHA-256 proof-of-work challenge and an AES-256-CBC encrypted
``dataLink`` array.  The implementation below follows that public contract,
keeps PoW bounded and returns only HTTPS hosters recognised by Kadr/ResolveURL.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
import re
import threading
from html import unescape
from urllib.parse import quote_plus, urlsplit

from lib.sources.es._kadr_es_common import (
    absolute_site_url,
    choose_candidate,
    clean_text,
    decode_ref,
    dedup_source_rows,
    diag,
    encode_ref,
    language_code,
    language_info,
    quality_from,
    site_client,
    source_row,
    titles_from,
    year_of,
)


_BASE = "https://entrepeliculasyseries.nz"
_REF = "kadr-entrepeliculas:"
_ARTICLE_RE = re.compile(r"<article\b[\s\S]*?</article>", re.I)
_POW_CACHE = {}
_POW_LOCK = threading.Lock()
_POW_CACHE_MAX = 64


def _parse_search(html, base):
    out = []
    for match in _ARTICLE_RE.finditer(html or ""):
        article = match.group(0)
        href_m = re.search(r'''href=["']([^"']+/(?:pelicula|serie)/[^"']+)["']''', article, re.I)
        if not href_m:
            continue
        url = absolute_site_url(href_m.group(1), base)
        path = (urlsplit(url).path or "").lower()
        kind = "movie" if "/pelicula/" in path else ("show" if "/serie/" in path else "")
        if not kind:
            continue
        title_m = re.search(r'''<img\b[^>]*\balt=["']([^"']+)["']''', article, re.I)
        if not title_m:
            title_m = re.search(r'''<h2\b[^>]*class=["'][^"']*\btitle\b[^"']*["'][^>]*>([\s\S]*?)</h2>''', article, re.I)
        title = clean_text(title_m.group(1)) if title_m else ""
        title = re.sub(r"^Ver\s+", "", title, flags=re.I)
        title = re.sub(r"\s*-\s*(?:Película|Serie)\s+completa.*$", "", title, flags=re.I)
        title = re.sub(r"\s+online\s+en\s+HD.*$", "", title, flags=re.I)
        title = re.sub(r"\s*\((?:19|20)\d{2}\)\s*$", "", title).strip()
        if not title:
            continue
        year_m = re.search(r'''<span\b[^>]*class=["'][^"']*\btag\b[^"']*["'][^>]*>\s*((?:19|20)\d{2})\s*</span>''', article, re.I)
        out.append({"title": title, "url": url, "year": year_m.group(1) if year_m else year_of(article), "kind": kind})
    return out


def _extract_iframe_vidurl(html, base):
    match = re.search(r'''<iframe\b[^>]*\bsrc=["']([^"']*/vidurl/[^"']+)["']''', html or "", re.I)
    if not match:
        return ""
    url = absolute_site_url(match.group(1), base)
    if not url:
        return ""
    path = urlsplit(url).path or ""
    return path if path.startswith("/vidurl/") else ""


def _episode_url(html, base, season, episode):
    # Current series page: season-tab-N -> season-N block -> episode-card links.
    tabs = {}
    for match in re.finditer(r'''id=["']season-tab-(\d+)["'][^>]*>\s*Temporada\s*(\d+)\s*</button>''', html or "", re.I):
        tabs[int(match.group(2))] = match.group(1)
    index = tabs.get(int(season))
    if index is None:
        return ""
    start_m = re.search(r'''id=["']season-%s["']''' % re.escape(str(index)), html or "", re.I)
    if not start_m:
        return ""
    starts = [m.start() for m in re.finditer(r'''id=["']season-\d+["']''', html or "", re.I) if m.start() > start_m.start()]
    end = starts[0] if starts else min(len(html or ""), start_m.start() + 120000)
    block = (html or "")[start_m.start():end]
    candidates = []
    card_starts = [m.start() for m in re.finditer(
        r'''<div\b[^>]*class=["'][^"']*\bepisode-card\b[^"']*["'][^>]*>''',
        block,
        re.I,
    )]
    for pos, card_start in enumerate(card_starts):
        card_end = card_starts[pos + 1] if pos + 1 < len(card_starts) else len(block)
        body = block[card_start:card_end]
        href = re.search(r'''href=["']([^"']+)["']''', body, re.I)
        label = re.search(r'''(?:Episodio|Episode)\s*0*(\d+)''', clean_text(body), re.I)
        if href and label and int(label.group(1)) == int(episode):
            url = absolute_site_url(href.group(1), base)
            if url:
                candidates.append(url)
    unique = list(dict.fromkeys(candidates))
    return unique[0] if len(unique) == 1 else ""


def _balanced_array(text, start):
    pos = (text or "").find("[", max(0, int(start)))
    if pos < 0:
        return ""
    depth = 0
    quote = ""
    escaped = False
    for index in range(pos, len(text)):
        ch = text[index]
        if quote:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = ""
            continue
        if ch in ("'", '"'):
            quote = ch
        elif ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
            if depth == 0:
                return text[pos:index + 1]
    return ""


def _vidurl_payload(html):
    challenge = re.search(r'''const\s+POW_CHALLENGE\s*=\s*["']([^"']+)["']''', html or "", re.I)
    difficulty = re.search(r'''const\s+POW_DIFFICULTY\s*=\s*(\d+)''', html or "", re.I)
    salt = re.search(r'''const\s+POW_SALT\s*=\s*["']([^"']+)["']''', html or "", re.I)
    data_start = re.search(r'''(?:const|let)\s+dataLink\s*=''', html or "", re.I)
    if not challenge or not difficulty or not salt or not data_start:
        return None
    raw = _balanced_array(html, data_start.end())
    if not raw:
        return None
    try:
        data = json.loads(raw)
    except Exception:
        return None
    if not isinstance(data, list):
        return None
    return challenge.group(1), int(difficulty.group(1)), salt.group(1), data


def _solve_pow(challenge, difficulty, salt):
    if difficulty < 1 or difficulty > 4:
        return None
    key = (challenge, int(difficulty), salt)
    with _POW_LOCK:
        cached = _POW_CACHE.get(key)
        if cached:
            return cached
    prefix = "0" * int(difficulty)
    # Difficulty 3 is the observed site value (~4k iterations).  One million
    # is a hard safety ceiling so this provider cannot monopolise a Kodi box.
    for nonce in range(1000001):
        digest = hashlib.sha256((challenge + str(nonce)).encode("utf-8")).hexdigest()
        if digest.startswith(prefix):
            aes_key = hashlib.sha256((challenge + str(nonce) + salt).encode("utf-8")).digest()
            with _POW_LOCK:
                if len(_POW_CACHE) >= _POW_CACHE_MAX:
                    try:
                        _POW_CACHE.pop(next(iter(_POW_CACHE)))
                    except Exception:
                        _POW_CACHE.clear()
                _POW_CACHE[key] = aes_key
            return aes_key
    return None


def _aes_decrypt(value, key):
    try:
        raw = base64.b64decode(str(value or ""), validate=True)
    except (ValueError, binascii.Error):
        return ""
    if len(raw) < 32 or (len(raw) - 16) % 16:
        return ""
    try:
        from resolveurl.lib.pyaes.aes import AESModeOfOperationCBC
        from resolveurl.lib.pyaes.util import strip_PKCS7_padding
        iv, ciphertext = raw[:16], raw[16:]
        cbc = AESModeOfOperationCBC(key, iv)
        plain = b"".join(cbc.decrypt(ciphertext[i:i + 16]) for i in range(0, len(ciphertext), 16))
        plain = strip_PKCS7_padding(plain)
        return plain.decode("utf-8", errors="strict").strip()
    except Exception:
        return ""


def _valid_imdb(value):
    value = str(value or "").strip()
    return value if re.match(r"^tt\d{5,12}$", value) else ""


class source:
    priority = 1
    language = ["es"]
    domains = ["entrepeliculasyseries.nz"]

    def __init__(self):
        self.client = site_client("entrepeliculasyseries", (_BASE,))

    def _find(self, wanted, year, kind):
        for title in (wanted or ())[:3]:
            html = self.client.get_text("/search?s=" + quote_plus(title))
            if not html:
                continue
            items = _parse_search(html, self.client.base)
            diag("entrepeliculasyseries", "search", "kind=%s query=%s rows=%d" % (kind, clean_text(title)[:40], len(items)))
            item = choose_candidate(items, wanted, year, min_score=0.93, expected_kind=kind)
            if item:
                return item
        return None

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        imdb_id = _valid_imdb(imdb)
        if imdb_id:
            return encode_ref(_REF, {"kind": "movie", "vidurl": "/vidurl/%s/" % imdb_id, "year": year_of(year)})
        wanted = titles_from(localtitle, title, aliases, limit=3, ffitem=getattr(self, "ffitem", None), media_type="movie")
        item = self._find(wanted, year, "movie") if wanted else None
        if not item:
            return None
        return encode_ref(_REF, {"kind": "movie", "url": item["url"], "year": year_of(item.get("year") or year)})

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        wanted = titles_from(localtvshowtitle, tvshowtitle, aliases, limit=3, ffitem=getattr(self, "ffitem", None), media_type="show")
        item = self._find(wanted, year, "show") if wanted else None
        imdb_id = _valid_imdb(imdb)
        if not item and not imdb_id:
            return None
        return encode_ref(_REF, {"kind": "show", "url": (item or {}).get("url") or "", "imdb": imdb_id, "year": year_of((item or {}).get("year") or year)})

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        ref = decode_ref(_REF, url)
        if not ref or ref.get("kind") != "show":
            return None
        try:
            wanted_s, wanted_e = int(season), int(episode)
        except Exception:
            return None
        if wanted_s <= 0 or wanted_e <= 0:
            return None
        vidurl = ""
        detail_url = str(ref.get("url") or "")
        if detail_url:
            html = self.client.get_text(detail_url)
            if html:
                ep_url = _episode_url(html, self.client.base, wanted_s, wanted_e)
                if ep_url:
                    ep_html = self.client.get_text(ep_url, referer=detail_url)
                    if ep_html:
                        vidurl = _extract_iframe_vidurl(ep_html, ep_url)
        if not vidurl:
            imdb_id = _valid_imdb(ref.get("imdb") or imdb)
            if not imdb_id:
                return None
            vidurl = "/vidurl/%s-%dx%02d/" % (imdb_id, wanted_s, wanted_e)
        return encode_ref(_REF, {"kind": "episode", "vidurl": vidurl, "season": wanted_s, "episode": wanted_e})

    def _fetch_vidurl_exact(self, path, referer=""):
        response = self.client.request("GET", path, referer=referer or self.client.base)
        if response is None:
            return ""
        final_path = (urlsplit(str(getattr(response, "url", "") or "")).path or "").rstrip("/")
        wanted_path = (urlsplit(path).path or path).rstrip("/")
        if final_path != wanted_path:
            diag("entrepeliculasyseries", "vidurl-retarget", "rejected")
            return ""
        return str(getattr(response, "text", "") or "")

    def sources(self, url, hostDict, hostprDict, **kwargs):
        ref = decode_ref(_REF, url)
        if not ref or ref.get("kind") not in ("movie", "episode"):
            return []
        vidurl = str(ref.get("vidurl") or "")
        if not vidurl and ref.get("kind") == "movie" and ref.get("url"):
            detail = self.client.get_text(str(ref.get("url")))
            vidurl = _extract_iframe_vidurl(detail, str(ref.get("url"))) if detail else ""
        if not vidurl:
            return []
        html = self._fetch_vidurl_exact(vidurl)
        payload = _vidurl_payload(html)
        if not payload:
            return []
        challenge, difficulty, salt, data_link = payload
        aes_key = _solve_pow(challenge, difficulty, salt)
        if not aes_key:
            diag("entrepeliculasyseries", "pow", "difficulty=%d failed" % int(difficulty))
            return []
        rows = []
        unknown_lang = 0
        decrypted = 0
        for block in data_link:
            if not isinstance(block, dict):
                continue
            raw_lang = block.get("video_language") or block.get("label") or block.get("language") or ""
            lang = language_code(raw_lang)
            if not lang:
                unknown_lang += 1
                continue
            embeds = block.get("sortedEmbeds") or block.get("embeds") or block.get("servers") or ()
            for embed in embeds or ():
                if not isinstance(embed, dict):
                    continue
                if str(embed.get("type") or "video").lower() != "video":
                    continue
                encrypted = str(embed.get("link") or embed.get("url") or "").strip()
                if not encrypted:
                    continue
                final = unescape(_aes_decrypt(encrypted, aes_key)).replace("\\/", "/").strip()
                if not final.startswith("https://"):
                    continue
                decrypted += 1
                row = source_row(
                    final,
                    hostDict,
                    hostprDict,
                    quality=quality_from(embed.get("quality") or embed.get("servername") or "", default="HD"),
                    language=lang,
                    info=language_info(lang),
                )
                if row:
                    rows.append(row)
        diag("entrepeliculasyseries", "sources", "difficulty=%d decrypted=%d rows=%d unknown_lang=%d" % (difficulty, decrypted, len(rows), unknown_lang))
        return dedup_source_rows(rows)

    def resolve(self, url):
        return url
