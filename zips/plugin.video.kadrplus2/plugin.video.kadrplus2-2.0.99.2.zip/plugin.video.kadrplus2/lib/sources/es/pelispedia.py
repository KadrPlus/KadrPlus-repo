# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""PelisPedia (pelispedia.is) source provider for Kadr+ 2.0.

The implementation follows the current public site contract verified in 2026:
WordPress search, season AJAX (action_select_season) and the trembed/player
iframe chain.  Audio variants are kept separate: Castellano, Latino and VOSE.
"""

from __future__ import annotations

import re
from html import unescape
from urllib.parse import quote_plus, urlsplit

from lib.sources.es._kadr_es_common import (
    absolute_site_url,
    choose_candidate,
    clean_text,
    decode_ref,
    dedup_source_rows,
    diag,
    encode_ref,
    language_code,
    language_info,
    quality_from,
    site_client,
    source_row,
    titles_from,
    year_of,
)


_BASE = "https://pelispedia.is"
_REF = "kadr-pelispedia:"
_ARTICLE_RE = re.compile(r"<article\b[\s\S]*?</article>", re.I)
_ATTR_RE = re.compile(r'''\b([\w:-]+)\s*=\s*["']([^"']*)["']''', re.I)
_EP_URL_RE = re.compile(r"temporada-(\d+)-capitulo-(\d+)", re.I)


def _attrs(tag):
    return {m.group(1).lower(): unescape(m.group(2)) for m in _ATTR_RE.finditer(tag or "")}


def _first_attr(html, tag_name, attr_name, *, class_token=""):
    for match in re.finditer(r"<%s\b([^>]*)>" % re.escape(tag_name), html or "", re.I):
        attrs = _attrs(match.group(1))
        if class_token and class_token.lower() not in attrs.get("class", "").lower().split():
            continue
        value = attrs.get(attr_name.lower(), "")
        if value:
            return value
    return ""


def _text_for_class(html, tag_name, token):
    pattern = re.compile(
        r"<%s\b[^>]*class=[\"'][^\"']*\b%s\b[^\"']*[\"'][^>]*>([\s\S]*?)</%s>"
        % (re.escape(tag_name), re.escape(token), re.escape(tag_name)),
        re.I,
    )
    match = pattern.search(html or "")
    return clean_text(match.group(1)) if match else ""


def _parse_search(html, base):
    items = []
    for article_match in _ARTICLE_RE.finditer(html or ""):
        article = article_match.group(0)
        title = _text_for_class(article, "h2", "entry-title")
        if not title:
            title = clean_text(re.search(r"<h2\b[^>]*>([\s\S]*?)</h2>", article, re.I).group(1)) if re.search(r"<h2\b[^>]*>([\s\S]*?)</h2>", article, re.I) else ""
        href = _first_attr(article, "a", "href", class_token="lnk-blk") or _first_attr(article, "a", "href")
        url = absolute_site_url(href, base)
        if not title or not url:
            continue
        path = (urlsplit(url).path or "").lower()
        kind = "movie" if "/pelicula/" in path else ("show" if "/serie/" in path else "")
        if not kind:
            continue
        year = _text_for_class(article, "span", "year") or year_of(article)
        quality = _text_for_class(article, "span", "Qlty") or _text_for_class(article, "span", "quality")
        items.append({"title": title, "url": url, "year": year, "quality": quality, "kind": kind})
    return items


def _button_info(html):
    out = {}
    for match in re.finditer(r'''<a\b[^>]*href=["']#([^"']+)["'][^>]*>([\s\S]*?)</a>''', html or "", re.I):
        inner = match.group(2)
        lang_match = re.search(
            r'''<span\b[^>]*class=["'][^"']*\bserver\b[^"']*["'][^>]*>\s*-?\s*([^<]+?)\s*</span>''',
            inner,
            re.I,
        )
        label = clean_text(lang_match.group(1)) if lang_match else clean_text(inner)
        out[match.group(1)] = label
    return out


def _option_blocks(html):
    # Current site uses compact divs such as id="options-0" with one iframe.
    blocks = []
    starts = list(re.finditer(r'''<div\b[^>]*\bid=["']((?:options?|video|opt)-\d+)["'][^>]*>''', html or "", re.I))
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else min(len(html or ""), match.end() + 12000)
        blocks.append((match.group(1), (html or "")[match.end():end]))
    return blocks


def _iframe_src(html):
    match = re.search(r'''<iframe\b[^>]*\bdata-src=["']([^"']+)["']''', html or "", re.I)
    if not match:
        match = re.search(r'''<iframe\b[^>]*\bsrc=["']([^"']+)["']''', html or "", re.I)
    return unescape(match.group(1)).strip() if match else ""


class source:
    priority = 1
    language = ["es"]
    domains = ["pelispedia.is"]

    def __init__(self):
        self.client = site_client("pelispedia", (_BASE,))

    def _search(self, wanted, year, kind):
        for title in (wanted or ())[:5]:
            html = self.client.get_text("/?s=" + quote_plus(title))
            if not html:
                continue
            items = _parse_search(html, self.client.base)
            diag("pelispedia", "search", "kind=%s query=%s rows=%d" % (kind, clean_text(title)[:40], len(items)))
            candidate = choose_candidate(items, wanted, year, min_score=0.93, expected_kind=kind)
            if candidate:
                return candidate
        return None

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        wanted = titles_from(localtitle, title, aliases, limit=3, ffitem=getattr(self, "ffitem", None), media_type="movie")
        item = self._search(wanted, year, "movie") if wanted else None
        if not item:
            return None
        return encode_ref(_REF, {"kind": "movie", "url": item["url"], "quality": item.get("quality") or "HD", "year": year_of(item.get("year") or year)})

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        wanted = titles_from(localtvshowtitle, tvshowtitle, aliases, limit=3, ffitem=getattr(self, "ffitem", None), media_type="show")
        item = self._search(wanted, year, "show") if wanted else None
        if not item:
            return None
        return encode_ref(_REF, {"kind": "show", "url": item["url"], "quality": item.get("quality") or "HD", "year": year_of(item.get("year") or year)})

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        ref = decode_ref(_REF, url)
        if not ref or ref.get("kind") != "show":
            return None
        try:
            wanted_s, wanted_e = int(season), int(episode)
        except Exception:
            return None
        if wanted_s <= 0 or wanted_e <= 0:
            return None
        detail_url = str(ref.get("url") or "")
        html = self.client.get_text(detail_url)
        if not html:
            return None

        post_id = ""
        for match in re.finditer(r"<a\b([^>]*)>", html, re.I):
            attrs = _attrs(match.group(1))
            try:
                season_no = int(attrs.get("data-season") or 0)
            except Exception:
                season_no = 0
            if season_no == wanted_s and attrs.get("data-post"):
                post_id = attrs["data-post"]
                break
        if not post_id:
            diag("pelispedia", "episode", "season-not-found s=%d" % wanted_s)
            return None

        season_html = self.client.post_text(
            "/wp-admin/admin-ajax.php",
            data={"action": "action_select_season", "season": str(wanted_s), "post": post_id},
            referer=detail_url,
        )
        if not season_html:
            return None
        matches = []
        for article_match in _ARTICLE_RE.finditer(season_html):
            article = article_match.group(0)
            href = _first_attr(article, "a", "href", class_token="lnk-blk") or _first_attr(article, "a", "href")
            episode_url = absolute_site_url(href, self.client.base)
            if not episode_url:
                continue
            ep_match = _EP_URL_RE.search(episode_url)
            ep_s = ep_e = 0
            if ep_match:
                ep_s, ep_e = int(ep_match.group(1)), int(ep_match.group(2))
            if not ep_e:
                label = _text_for_class(article, "span", "num-epi")
                nums = re.findall(r"\d+", label)
                if nums:
                    ep_e = int(nums[-1])
                    ep_s = wanted_s
            if ep_s == wanted_s and ep_e == wanted_e:
                matches.append(episode_url)
        if len(set(matches)) != 1:
            diag("pelispedia", "episode", "s=%d e=%d matches=%d" % (wanted_s, wanted_e, len(set(matches))))
            return None
        return encode_ref(_REF, {"kind": "episode", "url": matches[0], "quality": ref.get("quality") or "HD", "season": wanted_s, "episode": wanted_e})

    def _resolve_trembed(self, value, referer):
        url = absolute_site_url(value, self.client.base)
        if not url:
            return ""
        host = (urlsplit(url).hostname or "").lower()
        if host != "pelispedia.is" and not host.endswith(".pelispedia.is"):
            return url if url.startswith("https://") else ""
        html = self.client.get_text(url, referer=referer)
        if not html:
            return ""
        # The current intermediate page wraps the real host in div.Video iframe.
        video_match = re.search(r'''<div\b[^>]*class=["'][^"']*\bVideo\b[^"']*["'][^>]*>([\s\S]*?)</div>''', html, re.I)
        final = _iframe_src(video_match.group(1) if video_match else html)
        final_url = absolute_site_url(final, url)
        if not final_url:
            return ""
        final_host = (urlsplit(final_url).hostname or "").lower()
        if final_host == "pelispedia.is" or final_host.endswith(".pelispedia.is"):
            nested = self.client.get_text(final_url, referer=url)
            final2 = _iframe_src(nested)
            if final2:
                final_url = absolute_site_url(final2, final_url)
        return final_url if final_url.startswith("https://") else ""

    def sources(self, url, hostDict, hostprDict, **kwargs):
        ref = decode_ref(_REF, url)
        if not ref or ref.get("kind") not in ("movie", "episode"):
            return []
        detail_url = str(ref.get("url") or "")
        html = self.client.get_text(detail_url)
        if not html:
            return []
        labels = _button_info(html)
        quality_label = _text_for_class(html, "span", "Qlty") or _text_for_class(html, "span", "quality") or ref.get("quality") or "HD"
        quality = quality_from(quality_label, default="HD")
        rows = []
        blocks = _option_blocks(html)
        if not blocks:
            # Bounded fallback for pages where the player divs are not siblings.
            blocks = [("options-%d" % i, m.group(0)) for i, m in enumerate(re.finditer(r"<iframe\b[^>]*(?:data-src|src)=[\"'][^\"']+[\"'][^>]*>", html, re.I))]
        rejected_language = 0
        for option_id, block in blocks:
            src = _iframe_src(block)
            if not src:
                continue
            label = labels.get(option_id, "")
            lang = language_code(label)
            if not lang:
                rejected_language += 1
                continue
            final_url = self._resolve_trembed(src, detail_url)
            if not final_url:
                continue
            row = source_row(
                final_url,
                hostDict,
                hostprDict,
                quality=quality,
                language=lang,
                info=language_info(lang),
            )
            if row:
                rows.append(row)
        diag("pelispedia", "sources", "kind=%s blocks=%d rows=%d unknown_lang=%d" % (ref.get("kind"), len(blocks), len(rows), rejected_language))
        return dedup_source_rows(rows)

    def resolve(self, url):
        return url
