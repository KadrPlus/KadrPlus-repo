# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""Shared Kadr+ implementation for DLE-like pages with S/E player matrices."""

from __future__ import annotations

import re
from urllib.parse import quote, urlsplit

from lib.sources.de._kadr_cloud_common import devideosrc_streams
from lib.sources.de._kadr_de_common import (
    register,
    SiteClient, diag, absolute_http, choose_candidate, choose_series_candidate, clean_text, decode_ref,
    dedup_source_rows, encode_ref, extract_data_links, host_label,
    german_fallback_titles, js_matrix_streams, normalize_title, quality_from, source_row, titles_from,
    year_of,
)


_SEASON_RE = re.compile(r"\b(?:Staffel|Season|S)\s*0*(\d{1,2})\b", re.I)
_SEASON_SUFFIX_RE = re.compile(r"\s*[-–—:]?\s*(?:Staffel|Season|S)\s*0*\d{1,2}\b.*$", re.I)


def _allowed_detail(url, base):
    p, b = urlsplit(url), urlsplit(base)
    return (p.scheme == "https" and (p.hostname or "").lower().lstrip("www.") == (b.hostname or "").lower().lstrip("www.") and p.path.lower().endswith(".html"))


def parse_search_blocks(html, base):
    """Collect likely content cards without trusting broad page-wide anchors."""
    html = str(html or "")
    chunks = []
    for marker in (
        r'(?=<div\b[^>]*class=["\'][^"\']*\btitlecontrol\b)',
        r'(?=<(?:div|article)\b[^>]*class=["\'][^"\']*\bshort\b)',
        r'(?=<div\b[^>]*class=["\'][^"\']*\btitle\b)',
    ):
        parts = re.split(marker, html, flags=re.I)
        if len(parts) > 1:
            chunks.extend(parts[1:])
    out, seen = [], set()

    # Current KinoFun DLE search pages expose the actual content name in
    # ``div.title > div.begin > a``. Parse that verified structure explicitly
    # before the generic overlapping-card walker, so navigation/poster anchors
    # cannot win merely because they appear first in the HTML.
    direct_patterns = (
        r'<div\b[^>]*class=["\'][^"\']*\btitle\b[^"\']*["\'][^>]*>\s*'
        r'<div\b[^>]*class=["\'][^"\']*\bbegin\b[^"\']*["\'][^>]*>.*?'
        r'<a\b[^>]*href=(?P<q>["\'])(?P<href>.*?)(?P=q)[^>]*>(?P<title>[^<]+)</a>',
        r'<div\b[^>]*class=["\'][^"\']*\bbegin\b[^"\']*["\'][^>]*>.*?'
        r'<a\b[^>]*href=(?P<q>["\'])(?P<href>.*?)(?P=q)[^>]*>(?P<title>[^<]+)</a>',
    )
    for pattern in direct_patterns:
        for m in re.finditer(pattern, html, re.I | re.S):
            detail = absolute_http(m.group('href'), base)
            title = clean_text(m.group('title'))
            if not _allowed_detail(detail, base) or not title or detail in seen:
                continue
            # Keep the metadata window bounded to this DLE card.
            tail = html[m.end():m.end() + 5000]
            stop = re.search(r'<div\b[^>]*class=["\'][^"\']*(?:\btitlecontrol\b|\bshort\b|\btitle\b)[^"\']*["\']', tail, re.I)
            card = html[m.start():m.end()] + (tail[:stop.start()] if stop else tail)
            ym = re.search(r'\(((?:19|20)\d{2})\)\s*$', title)
            year = ym.group(1) if ym else ''
            if ym:
                title = re.sub(r'\s*\((?:19|20)\d{2}\)\s*$', '', title).strip()
            sm = _SEASON_RE.search(title + ' ' + clean_text(card[:2200]))
            season = int(sm.group(1)) if sm else 0
            if season:
                title = _SEASON_SUFFIX_RE.sub('', title).strip(' -–—:')
            seen.add(detail)
            out.append({
                'title': title,
                'year': year,
                'season': season,
                'url': detail,
                'is_series': True if (season or re.search(r'\b(?:Serie|Serien|Staffel)\b', clean_text(card[:2600]), re.I)) else None,
            })

    for chunk in chunks:
        chunk = chunk[:16000]
        anchors = re.findall(r'<a\b[^>]*href\s*=\s*(["\'])(.*?)\1[^>]*>(.*?)</a>', chunk, re.I | re.S)
        detail = title = ""
        for _, href, body in anchors:
            url = absolute_http(href, base)
            if not _allowed_detail(url, base):
                continue
            text = clean_text(body)
            # Navigation/thumb links may be empty; prefer the first textual
            # content anchor, then fall back to title= attribute below.
            if text:
                detail, title = url, text
                break
            if not detail:
                detail = url
        if not detail:
            continue
        if not title:
            # Try title attribute from the matching anchor/card.
            tm = re.search(r'<a\b[^>]*href\s*=\s*["\']%s["\'][^>]*\btitle\s*=\s*["\']([^"\']+)' % re.escape(detail), chunk, re.I)
            title = clean_text(tm.group(1) if tm else "")
        if not title:
            # DLE cards often put the content name in a begin/title div.
            tm = re.search(r'class\s*=\s*["\'][^"\']*(?:begin|title)[^"\']*["\'][^>]*>.*?<a\b[^>]*>(.*?)</a>', chunk, re.I | re.S)
            title = clean_text(tm.group(1) if tm else "")
        if not title or detail in seen:
            continue
        seen.add(detail)
        ym = re.search(r'\(((?:19|20)\d{2})\)\s*$', title)
        year = ym.group(1) if ym else ""
        if ym:
            title = re.sub(r'\s*\((?:19|20)\d{2}\)\s*$', "", title).strip()
        sm = _SEASON_RE.search(title + " " + clean_text(chunk[:1200]))
        season = int(sm.group(1)) if sm else 0
        # Staffel pages often use e.g. "Reacher - Staffel 4 (2026)" while
        # Kadr's show metadata correctly carries the series premiere year
        # (2022).  Keep season as structured metadata and compare only the show
        # title itself.
        if season:
            title = _SEASON_SUFFIX_RE.sub("", title).strip(" -–—:")
        out.append({
            "title": title,
            "year": year,
            "season": season,
            "url": detail,
            "is_series": True if (season or re.search(r'\b(?:Serie|Serien|Staffel)\b', clean_text(chunk[:1600]), re.I)) else None,
        })
    # De-duplicate titles/urls produced by overlapping block strategies.
    uniq = []
    seen = set()
    for item in out:
        key = item["url"]
        if key in seen:
            continue
        seen.add(key)
        uniq.append(item)
    return uniq


def _page_declares_season(html, season):
    """Return True only when the detail page itself names the requested season.

    KinoFun season-detail pages can use a *relative* internal episode index
    (for example a Staffel-4 page with ``serie-1_1``).  Never reinterpret that
    index unless the page title/heading explicitly proves which Staffel we are
    on; this keeps the exact-S/E safety rule intact.
    """
    raw = str(html or "")
    candidates = []
    for pat in (
        r'<meta\b[^>]*(?:property|name)\s*=\s*["\'](?:og:title|twitter:title)["\'][^>]*content\s*=\s*(["\'])(.*?)\1',
        r'<title\b[^>]*>(.*?)</title>',
        r'<h1\b[^>]*>(.*?)</h1>',
        r'<div\b[^>]*class\s*=\s*["\'][^"\']*(?:titlecontrol|\btitle\b)[^"\']*["\'][^>]*>(.*?)</div>',
    ):
        for m in re.finditer(pat, raw, re.I | re.S):
            value = m.group(2) if m.lastindex and m.lastindex >= 2 else m.group(1)
            text = clean_text(value)
            if text:
                candidates.append(text)
            if len(candidates) >= 12:
                break
        if len(candidates) >= 12:
            break
    requested = int(season or 0)
    for text in candidates:
        m = _SEASON_RE.search(text)
        if m and int(m.group(1)) == requested:
            return True
    return False


def episode_block(html, season, episode):
    raw = str(html or "")
    pattern = r'<li\b[^>]*id\s*=\s*["\']serie-%d_%d["\'][^>]*>(.*?)(?=<li\b[^>]*id\s*=\s*["\']serie-\d+_\d+["\']|$)' % (int(season), int(episode))
    m = re.search(pattern, raw, re.I | re.S)
    if m:
        return m.group(1)

    # Live-verified KinoGer/KinoFun markup sometimes numbers the only season on
    # a Staffel-N detail page as ``serie-1_E``.  Accept a relative season index
    # only when the page heading explicitly confirms the requested Staffel and
    # the page contains exactly one internal season prefix.
    if _page_declares_season(raw, season):
        prefixes = set(int(x) for x in re.findall(r'id\s*=\s*["\']serie-(\d+)_\d+["\']', raw, re.I))
        if len(prefixes) == 1:
            rel = next(iter(prefixes))
            pattern = r'<li\b[^>]*id\s*=\s*["\']serie-%d_%d["\'][^>]*>(.*?)(?=<li\b[^>]*id\s*=\s*["\']serie-\d+_\d+["\']|$)' % (rel, int(episode))
            m = re.search(pattern, raw, re.I | re.S)
            if m:
                return m.group(1)
    return ""


def streams_from_page(html, base, season=0, episode=0):
    if season and episode:
        block = episode_block(html, season, episode)
        if block:
            found = extract_data_links(block, base=base, skip_hosts=(urlsplit(base).hostname or "", "meinecloud.click"))
            if found:
                return found
        found = js_matrix_streams(html, season, episode, base=base)
        if found:
            return found
        # The same season-relative quirk can apply to the JS matrix: on a
        # detail page that explicitly says Staffel N, the first matrix row is
        # that Staffel rather than global Staffel 1.
        if _page_declares_season(html, season):
            return js_matrix_streams(html, 1, episode, base=base)
        return []
    # Movies: prefer ordinary data-link rows.  The live KinoFun player can also
    # expose movie hosters through the same ``.show(..., [[...]])`` matrix used
    # by series; for a movie the first cell is the only valid one.  Keep this a
    # miss-only fallback so existing direct links are unchanged.
    found = extract_data_links(html, base=base, skip_hosts=(urlsplit(base).hostname or "", "meinecloud.click"))
    if found:
        return found
    return js_matrix_streams(html, 1, 1, base=base)


class DLEMatrixSource:
    has_sort_order = True
    priority = 2
    language = ["de"]
    provider_name = "dlematrix"
    base_urls = ()
    ref_prefix = "kadr-dle:"
    get_search_templates = ()
    post_search = False
    request_headers = None

    def __init__(self):
        self.priority = 2
        self.language = ["de"]
        self.client = SiteClient(self.provider_name, self.base_urls, headers=self.request_headers)

    def _search_html(self, query):
        encoded = quote(str(query or ""))
        for template in self.get_search_templates:
            html = self.client.get_text(template.format(q=encoded))
            if parse_search_blocks(html, self.client.base):
                return html
        if self.post_search:
            html = self.client.post_text("/", data={
                "do": "search", "subaction": "search", "story": str(query or ""),
                "titleonly": "3", "submit": "submit",
            })
            if html:
                return html
        return ""

    def _find(self, wanted, year="", *, season=0, expect_series=None):
        attempts = 0
        total_items = 0
        for query in wanted[:4]:
            attempts += 1
            html = self._search_html(query)
            items = parse_search_blocks(html, self.client.base)
            total_items += len(items)
            diag(self.provider_name, 'search', 'attempt=%d items=%d season=%d' % (attempts, len(items), int(season or 0)))
            if season:
                matching_season = [x for x in items if int(x.get("season") or 0) in (0, int(season))]
                if matching_season:
                    items = matching_season
            if expect_series is not None:
                typed = [x for x in items if x.get("is_series") is not None and bool(x.get("is_series")) == bool(expect_series)]
                if typed:
                    items = typed
            best = (choose_series_candidate(items, wanted, year, min_score=0.93, season=season)
                    if season else choose_candidate(items, wanted, year, min_score=0.93, season=season))
            if best:
                diag(self.provider_name, 'search-match', 'attempt=%d total_items=%d season=%d' % (attempts, total_items, int(season or 0)))
                return best
        diag(self.provider_name, 'search-empty', 'attempts=%d total_items=%d season=%d' % (attempts, total_items, int(season or 0)))
        return None

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        wanted = titles_from(localtitle, title, aliases, ffitem=getattr(self, "ffitem", None), media_type="movie")
        item = self._find(wanted, year, expect_series=False) if wanted else None
        if not item:
            fallback = german_fallback_titles(wanted, getattr(self, "ffitem", None), "movie")
            if fallback != wanted:
                item = self._find(fallback, year, expect_series=False)
        if not item:
            return None
        return encode_ref(self.ref_prefix, {"kind": "movie", "url": item["url"], "year": year_of(item.get("year") or year)})

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        wanted = titles_from(localtvshowtitle, tvshowtitle, aliases, ffitem=getattr(self, "ffitem", None), media_type="show")
        if not wanted:
            return None
        return encode_ref(self.ref_prefix, {"kind": "show", "titles": wanted, "year": year_of(year)})

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        ref = decode_ref(self.ref_prefix, url)
        if not ref or ref.get("kind") != "show":
            return None
        try:
            s, e = int(season), int(episode)
        except Exception:
            return None
        if s <= 0 or e <= 0:
            return None
        wanted = [clean_text(x) for x in ref.get("titles", []) if clean_text(x)]
        item = self._find(wanted, ref.get("year", ""), season=s, expect_series=True)
        if not item:
            # Some pages carry all seasons but search cards have no series
            # marker.  Accept only the same strong title/year match.
            item = self._find(wanted, ref.get("year", ""), season=s, expect_series=None)
        if not item:
            fallback = german_fallback_titles(wanted, getattr(self, "ffitem", None), "show")
            if fallback != wanted:
                item = self._find(fallback, ref.get("year", ""), season=s, expect_series=True)
                if not item:
                    item = self._find(fallback, ref.get("year", ""), season=s, expect_series=None)
        if not item:
            return None
        if item.get("season") and int(item["season"]) != s:
            return None
        return encode_ref(self.ref_prefix, {"kind": "episode", "url": item["url"], "season": s, "episode": e})

    def sources(self, url, hostDict, hostprDict, **kwargs):
        ref = decode_ref(self.ref_prefix, url)
        if not ref or ref.get("kind") not in ("movie", "episode"):
            return []
        html = self.client.get_text(ref.get("url", ""))
        raw = streams_from_page(html, self.client.base, int(ref.get("season") or 0), int(ref.get("episode") or 0))
        diag(self.provider_name, 'sources', 'kind=%s season=%d episode=%d raw=%d' % (
            ref.get('kind'), int(ref.get('season') or 0), int(ref.get('episode') or 0), len(raw),
        ))
        expanded = []
        for item in raw:
            host = (urlsplit(str(item.get("url") or "")).hostname or "").lower()
            if host in ("devideosrc.co", "www.devideosrc.co"):
                expanded.extend(devideosrc_streams(
                    self.provider_name, item.get("url"), referer=ref.get("url", ""),
                    season=int(ref.get("season") or 0), episode=int(ref.get("episode") or 0),
                    quality=item.get("quality", "HD"), info=item.get("info", ""),
                ))
            else:
                expanded.append(item)
        raw = expanded
        rows = []
        rejected_hosts = set()
        for item in raw:
            row = source_row(item.get("url"), hostDict, hostprDict, name=item.get("name", ""), quality=item.get("quality", "HD"), language="de", info=item.get("info", ""))
            if row:
                rows.append(row)
            else:
                host = (urlsplit(str(item.get("url") or "")).hostname or "").lower()
                if host:
                    rejected_hosts.add(host)
        if raw and not rows and rejected_hosts:
            diag(self.provider_name, 'source-filter', 'rejected_hosts=%s' % ','.join(sorted(rejected_hosts)[:8]))
        return dedup_source_rows(rows)

    def resolve(self, url):
        return url
