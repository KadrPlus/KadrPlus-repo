# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""KinoGer/KinoFun provider written for Kadr+ 2.0."""

from lib.sources.de._kadr_dle_matrix import DLEMatrixSource


class source(DLEMatrixSource):
    provider_name = "kinofun"
    # Current 2026-10 frontend.  Older HTTPS domains stay as bounded fallbacks
    # only; redirect validation remains strict inside this allowlist.
    base_urls = (
        "https://kinoger.ch", "https://www.kinoger.ch",
        "https://kinoger.com", "https://www.kinoger.com",
        "https://kinoger.to", "https://www.kinoger.to",
        "https://kinoger.fun", "https://www.kinoger.fun",
    )
    ref_prefix = "kadr-kinofun:"
    # The current site intentionally treats a full browser UA as bot traffic.
    # This short UA is the exact compatibility behaviour used by the current
    # working frontend implementation; no CF/TLS checks are bypassed.
    request_headers = {"User-Agent": "Mozilla/5.0"}
    get_search_templates = (
        "/?do=search&subaction=search&titleonly=3&story={q}&x=0&y=0&submit=submit",
        "/?do=search&subaction=search&story={q}",
    )
    post_search = True
