# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""Movie2k provider for Kadr+ 2.0, implemented against its public JSON catalogue."""

from lib.sources.de._kadr_json_catalog import JsonCatalogSource


class source(JsonCatalogSource):
    provider_name = "movie2k"
    base_urls = ("https://movie2k.ch",)
    ref_prefix = "kadr-movie2k:"
    search_params = ("keyword",)
    # Match the current frontend/API request shape.  ``limit=0`` asked the
    # backend for an unbounded result set and could time out even for a narrow
    # keyword search; the current working frontend uses the first 20 ranked
    # matches.
    search_path_template = (
        "/data/browse/?lang=2&keyword={query}&year=&networks=&rating=&votes="
        "&genre=&country=&cast=&directors=&type=&order_by=&page=1&limit=20"
    )
    max_query_transport_failures = 2
    request_headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) "
            "Gecko/20100101 Firefox/138.0"
        ),
        "Accept": "text/html",
        "Referer": "https://movie2k.ch/",
    }
