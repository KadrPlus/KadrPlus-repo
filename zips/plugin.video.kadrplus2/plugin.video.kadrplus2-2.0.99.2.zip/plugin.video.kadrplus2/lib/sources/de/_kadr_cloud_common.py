# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""Kadr+-local helpers for German pages using external hoster/player iframes."""

from __future__ import annotations

import re
import threading
import time
from urllib.parse import urlsplit

from lib.sources.de._kadr_de_common import (
    register,
    TrustedHttpsClient, absolute_http, clean_text, diag, extract_data_links,
    extract_iframes, host_label, html_attr, meinecloud_episode_links,
    quality_from, strip_comments,
)


_MINE_HOST = "meinecloud.click"
_DEVIDEOSRC_HOSTS = ("devideosrc.co", "www.devideosrc.co")


def _is_same_host(url, base):
    return (urlsplit(url).hostname or "").lower() == (urlsplit(base).hostname or "").lower()


def _external_items_from_html(html, base, *, block_only=False):
    out = []
    for item in extract_data_links(html, base=base):
        p = urlsplit(item.get("url") or "")
        if not p.hostname:
            continue
        host = p.hostname.lower()
        if host == (urlsplit(base).hostname or "").lower():
            # Internal /vod or redirect placeholders are not a source.
            continue
        if "youtube" in host or host == "youtu.be":
            continue
        out.append(item)
    return out


def _episode_block(html, season, episode):
    patterns = (
        r'<li\b[^>]*id\s*=\s*["\']serie-%d_%d["\'][^>]*>(.*?)(?=<li\b[^>]*id\s*=\s*["\']serie-\d+_\d+["\']|$)' % (season, episode),
        r'id\s*=\s*["\']serie-%d_%d["\'](.*?)(?=id\s*=\s*["\']serie-\d+_\d+["\']|$)' % (season, episode),
    )
    for pattern in patterns:
        m = re.search(pattern, str(html or ""), re.I | re.S)
        if m:
            return m.group(1)
    # Some FHD pages group episode rows inside a season accordion as xN Episode.
    sm = re.search(r'#se-ac-%d(.*?)(?=#se-ac-\d|$)' % season, str(html or ""), re.I | re.S)
    if sm:
        em = re.search(r'\bx0*%d\s*Episode\b(.*?)(?=<br|\bx\d+\s*Episode|$)' % episode, sm.group(1), re.I | re.S)
        if em:
            return em.group(1)
    return ""


_DVS_BASE = "https://devideosrc.co"
_DVS_TOKEN_RE = re.compile(r'''token:\s*["']([^"']+)["']''', re.I)
_DVS_ID_RE = re.compile(r"^(?:tt\d{3,20}|\d{1,20})$", re.I)
_DVS_PAGE_ATTEMPTS = 3
_DVS_CACHE_TTL = 45.0
_DVS_CACHE = {}
_DVS_LOCKS = {}
_DVS_GUARD = threading.Lock()


def _devideosrc_players_from_html(html):
    """Return trusted DEVIDEOSRC player wrappers declared by a detail page.

    Besides literal iframe URLs, current DLE frontends may build the serial
    iframe in JavaScript (``.../serial/`` + ``var imdb``).  Detect only that
    verified pattern and an IMDb/numeric identifier already present in the
    same page; never synthesize an ID from the catalogue title.
    """
    raw = str(html or "")
    out, seen = [], set()

    def add(url):
        url = str(url or "").strip().replace("\\/", "/")
        kind, ident = _devideosrc_identity(url)
        if not kind or not ident:
            return
        canonical = "%s/%s/%s" % (_DVS_BASE, kind, ident)
        if canonical not in seen:
            seen.add(canonical)
            out.append(canonical)

    # Literal default/custom players.  Query strings are irrelevant because
    # Kadr resolves the signed API itself.
    for m in re.finditer(
        r'https://(?:www\.)?devideosrc\.co/(?:custom/)?(?:movie|serial)/(?:tt\d{3,20}|\d{1,20})(?:/\d+/\d+)?',
        raw, re.I,
    ):
        add(m.group(0))

    # Current series pages often set iframe.src from ``var imdb`` rather than
    # putting a complete URL in the HTML attribute.  Require the serial route
    # literal and a bounded identifier assignment in the same document.
    if re.search(r'devideosrc\.co/serial/["\']?\s*[+]', raw, re.I) or re.search(r'devideosrc\.co/serial/["\']', raw, re.I):
        ids = []
        for pat in (
            r'\b(?:var|let|const)\s+(?:imdb|id)\s*=\s*(["\'])(tt\d{3,20}|\d{1,20})\1',
            r'devideosrc\.co/embed/download/(tt\d{3,20}|\d{1,20})',
        ):
            for m in re.finditer(pat, raw, re.I):
                ident = m.group(2) if m.lastindex and m.lastindex >= 2 else m.group(1)
                if ident not in ids:
                    ids.append(ident)
        for ident in ids[:4]:
            add("%s/serial/%s" % (_DVS_BASE, ident))
    return out


def _devideosrc_identity(url):
    """Return ``(kind, imdb)`` for a trusted current/legacy player URL."""
    p = urlsplit(str(url or ""))
    host = (p.hostname or "").lower().rstrip(".")
    if p.scheme != "https" or host not in _DEVIDEOSRC_HOSTS:
        return "", ""
    parts = [x for x in (p.path or "").split("/") if x]
    kind = ident = ""
    if len(parts) >= 2 and parts[0].lower() in ("movie", "serial"):
        kind, ident = parts[0].lower(), parts[1]
    elif len(parts) >= 3 and parts[0].lower() == "custom" and parts[1].lower() in ("movie", "serial"):
        kind, ident = parts[1].lower(), parts[2]
    if not _DVS_ID_RE.match(ident or ""):
        return "", ""
    return kind, ident.lower()


def _uncached_player_url(url):
    sep = "&" if "?" in str(url or "") else "?"
    return "%s%sr=%d" % (str(url or ""), sep, time.monotonic_ns())


def _devideosrc_page(client, page_url, *, referer=""):
    """Load a player page past the edge cache; retry only an explicit 429."""
    for attempt in range(_DVS_PAGE_ATTEMPTS):
        response = client.request(
            "GET", _uncached_player_url(page_url), referer=referer,
            accept_status=(200, 429), max_bytes=2 * 1024 * 1024,
        )
        if response is None:
            return ""
        if int(getattr(response, "status_code", 0) or 0) == 200:
            return str(getattr(response, "text", "") or "")
        if attempt + 1 < _DVS_PAGE_ATTEMPTS:
            time.sleep(2.0 * (attempt + 1))
    return ""


def _devideosrc_post(client, endpoint, page_url, body):
    endpoint = str(endpoint or "").strip()
    if not endpoint.startswith("https://"):
        endpoint = _DVS_BASE + "/" + endpoint.lstrip("/")
    if not client.allowed_url(endpoint):
        return None
    data = client.post_json(
        endpoint,
        json_data=body,
        referer=page_url,
        headers={
            "Origin": _DVS_BASE,
            "Accept": "application/json",
            "Content-Type": "application/json",
        },
        accept_status=(200, 404),
        max_bytes=2 * 1024 * 1024,
    )
    return data if isinstance(data, dict) else None


def _devideosrc_source_rows(sources):
    """Normalize API ``sources`` without resolving/fetching third-party hosts."""
    ranked = []
    for idx, src in enumerate(sources if isinstance(sources, list) else ()):
        if not isinstance(src, dict):
            continue
        url = str(src.get("url") or "").strip()
        if url.startswith("//"):
            url = "https:" + url
        p = urlsplit(url)
        host = (p.hostname or "").lower().rstrip(".")
        if p.scheme != "https" or not host or host in _DEVIDEOSRC_HOSTS or host == _MINE_HOST:
            continue
        try:
            rank = int(src.get("rank"))
        except Exception:
            rank = 999
        ranked.append((rank, idx, {
            "url": url,
            "name": clean_text(src.get("name")) or host_label(url),
            "quality": quality_from(src.get("quality") or src.get("name") or ""),
            "info": "",
        }))
    ranked.sort(key=lambda x: (x[0], x[1]))
    out, seen = [], set()
    for _, _, row in ranked:
        if row["url"] in seen:
            continue
        seen.add(row["url"])
        out.append(row)
    return out


def _devideosrc_tv_rows(payload, season, episode):
    tv = payload.get("tv") if isinstance(payload, dict) else None
    seasons = tv.get("seasons") if isinstance(tv, dict) else None
    if not isinstance(seasons, list):
        return []
    wanted_s, wanted_e = int(season), int(episode)
    for season_row in seasons:
        if not isinstance(season_row, dict):
            continue
        try:
            sn = int(season_row.get("season_number"))
        except Exception:
            continue
        if sn != wanted_s:
            continue
        for ep in season_row.get("episodes") or ():
            if not isinstance(ep, dict):
                continue
            try:
                en = int(ep.get("episode_number"))
            except Exception:
                continue
            if en != wanted_e:
                continue
            rows = _devideosrc_source_rows(ep.get("sources"))
            if rows:
                return rows
            # Some builds expose the first active hoster as ``url`` in the TV
            # index. Accept only an external HTTPS URL from the exact S/E row.
            one = ep.get("url")
            if one:
                return _devideosrc_source_rows([{"url": one, "name": ep.get("name") or ""}])
            return []
    return []


def _attr_anywhere(html, name, default=""):
    m = re.search(r'\b%s\s*=\s*(["\'])(.*?)\1' % re.escape(name), str(html or ""), re.I | re.S)
    return clean_text(m.group(2)) if m else default


def _devideosrc_movie(client, imdb, *, referer=""):
    page_url = "%s/movie/%s" % (_DVS_BASE, imdb)
    html = _devideosrc_page(client, page_url, referer=referer)
    token = _DVS_TOKEN_RE.search(html or "")
    if not token:
        return []
    payload = _devideosrc_post(client, "/api/embed-links", page_url, {
        "type": "movie", "id": imdb, "token": token.group(1),
    })
    if not payload or payload.get("ok") is False:
        return []
    return _devideosrc_source_rows(payload.get("sources"))


def _devideosrc_episode(client, imdb, season, episode, *, referer=""):
    s, e = int(season), int(episode)
    # Current 01.10.2026 player uses /serial/<id>/<S>/<E>. Keep the documented
    # /custom/serial variant as a bounded compatibility fallback only when the
    # first exact page does not expose a resolve token.
    for page_url in (
        "%s/serial/%s/%d/%d" % (_DVS_BASE, imdb, s, e),
        "%s/custom/serial/%s/%d/%d" % (_DVS_BASE, imdb, s, e),
    ):
        html = _devideosrc_page(client, page_url, referer=referer)
        if not html:
            continue
        token = _attr_anywhere(html, "data-resolve-token")
        if not token:
            continue
        endpoint = _attr_anywhere(html, "data-resolve-endpoint", "/api/resolve")
        body = {
            "type": _attr_anywhere(html, "data-type", "tv"),
            "id": _attr_anywhere(html, "data-id", imdb),
            "season": _attr_anywhere(html, "data-season", str(s)),
            "episode": _attr_anywhere(html, "data-episode", str(e)),
            "mode": _attr_anywhere(html, "data-mode", "custom"),
            "token": token,
        }
        # Never let page attributes silently retarget another title/episode.
        if str(body["id"]).lower() != imdb.lower():
            continue
        try:
            if int(body["season"]) != s or int(body["episode"]) != e:
                continue
        except Exception:
            continue
        payload = _devideosrc_post(client, endpoint, page_url, body)
        if payload and payload.get("ok") is not False:
            rows = _devideosrc_source_rows(payload.get("sources"))
            if rows:
                return rows

    # Structured generic-TV fallback: still filter the returned tree to the
    # exact requested S/E before exposing any hoster.
    page_url = "%s/serial/%s" % (_DVS_BASE, imdb)
    html = _devideosrc_page(client, page_url, referer=referer)
    token = _DVS_TOKEN_RE.search(html or "")
    if not token:
        return []
    payload = _devideosrc_post(client, "/api/embed-links", page_url, {
        "type": "tv", "id": imdb, "token": token.group(1),
    })
    if not payload or payload.get("ok") is False:
        return []
    return _devideosrc_tv_rows(payload, s, e)


def _devideosrc_fetch(provider, player_url, *, referer="", season=0, episode=0):
    kind, imdb = _devideosrc_identity(player_url)
    if not kind or not imdb:
        return []
    client = TrustedHttpsClient(provider, _DEVIDEOSRC_HOSTS)
    if season and episode:
        return _devideosrc_episode(client, imdb, int(season), int(episode), referer=referer)
    if kind == "movie":
        return _devideosrc_movie(client, imdb, referer=referer)
    # A few catalogue pages historically used a serial wrapper for a movie.
    # Only fall back to the movie player when the serial page proves there is
    # no signed TV token; never flatten a real TV payload into a movie result.
    serial_url = "%s/serial/%s" % (_DVS_BASE, imdb)
    html = _devideosrc_page(client, serial_url, referer=referer)
    if _DVS_TOKEN_RE.search(html or ""):
        return []
    return _devideosrc_movie(client, imdb, referer=referer)


def devideosrc_streams(provider, player_url, *, referer="", season=0, episode=0, quality="HD", info=""):
    """Expand DEVIDEOSRC through its signed JSON API, preserving strict S/E."""
    kind, imdb = _devideosrc_identity(player_url)
    if not kind or not imdb:
        return []
    key = (kind, imdb, int(season or 0), int(episode or 0))
    with _DVS_GUARD:
        lock = _DVS_LOCKS.get(key)
        if lock is None:
            lock = threading.Lock()
            _DVS_LOCKS[key] = lock
    with lock:
        now = time.monotonic()
        cached = _DVS_CACHE.get(key)
        if cached and now - cached[0] <= _DVS_CACHE_TTL:
            rows = [dict(x) for x in cached[1]]
        else:
            rows = _devideosrc_fetch(
                provider, player_url, referer=referer,
                season=int(season or 0), episode=int(episode or 0),
            )
            _DVS_CACHE[key] = (time.monotonic(), tuple(dict(x) for x in rows))
        if len(_DVS_CACHE) > 96:
            oldest = sorted(_DVS_CACHE.items(), key=lambda it: it[1][0])[:24]
            for old_key, _ in oldest:
                _DVS_CACHE.pop(old_key, None)
    for row in rows:
        if quality and (not row.get("quality") or row.get("quality") == "HD"):
            row["quality"] = quality
        if info and not row.get("info"):
            row["info"] = info
    diag(provider, "devideosrc", "status=%s sources=%d exact_episode=%s" % (
        "ok" if rows else "empty", len(rows), bool(season and episode),
    ))
    return rows

def _parse_mine_html(html, *, season=0, episode=0):
    if season and episode:
        rows = meinecloud_episode_links(html, season, episode)
        if rows:
            return rows
        # Current MeineCloud pages may delegate the whole serial player to
        # DEVIDEOSRC.  Returning only that trusted wrapper is safe because the
        # caller converts it to DEVIDEOSRC's exact S/E route before expansion.
        candidates = _external_items_from_html(html, "https://meinecloud.click/")
        for iframe in extract_iframes(html, "https://meinecloud.click/"):
            candidates.append({"url": iframe, "name": host_label(iframe), "quality": quality_from(html), "info": ""})
        return [x for x in candidates if (urlsplit(str(x.get("url") or "")).hostname or "").lower() in _DEVIDEOSRC_HOSTS]
    rows = _external_items_from_html(html, "https://meinecloud.click/")
    seen = {str(x.get("url") or "") for x in rows}
    for iframe in extract_iframes(html, "https://meinecloud.click/"):
        host = (urlsplit(iframe).hostname or "").lower()
        if not host or host == _MINE_HOST or "youtube" in host or host == "youtu.be" or iframe in seen:
            continue
        seen.add(iframe)
        rows.append({"url": iframe, "name": host_label(iframe), "quality": quality_from(html), "info": ""})
    return rows


def collect_page_streams(site_client, page_url, *, season=0, episode=0, max_internal=3):
    """Extract hoster URLs without fetching arbitrary third-party hosts.

    Movies may use page-wide provider-declared hosters.  Episodes are stricter:
    a third-party hoster is accepted only from the exact requested S/E block,
    or from an exact S/E row inside the trusted MeineCloud player.  If the page
    cannot prove the requested episode, returning no source is safer than
    playing a neighbouring episode.
    """
    html = site_client.get_text(page_url)
    if not html:
        return []
    base = site_client.base
    mine = TrustedHttpsClient(site_client.provider, (_MINE_HOST,))
    out, seen = [], set()

    def add(item, referer=""):
        url = str((item or {}).get("url") or "").strip()
        if not url or url in seen:
            return
        host = (urlsplit(url).hostname or "").lower()
        if host in _DEVIDEOSRC_HOSTS:
            # Mark the wrapper seen even when the trusted player temporarily
            # has no live hoster, so the same page cannot trigger duplicate
            # network expansions through data-link + iframe variants.
            seen.add(url)
            for nested in devideosrc_streams(
                site_client.provider, url, referer=referer, season=season, episode=episode,
                quality=(item or {}).get("quality", "HD"), info=(item or {}).get("info", ""),
            ):
                add(nested, referer)
            return
        seen.add(url)
        out.append(item)

    def consume_movie(fragment, referer, depth=0):
        target = str(fragment or "")
        for item in _external_items_from_html(target, base):
            p = urlsplit(item.get("url") or "")
            if (p.hostname or "").lower() == _MINE_HOST:
                mine_html = mine.get_text(item["url"], referer=referer)
                for nested in _parse_mine_html(mine_html):
                    add(nested, item["url"])
            elif site_client.allowed_url(item.get("url")) and depth < max_internal:
                internal = site_client.get_text(item["url"], referer=referer)
                if internal:
                    consume_movie(internal, item["url"], depth + 1)
            else:
                add(item, referer)
        # Current DLE sites may create the DEVIDEOSRC iframe via JavaScript
        # instead of a literal ``src`` attribute.
        for player in _devideosrc_players_from_html(target):
            add({"url": player, "name": "DEVIDEOSRC", "quality": quality_from(target), "info": ""}, referer)
        for iframe in extract_iframes(target, base)[:8]:
            p = urlsplit(iframe)
            host = (p.hostname or "").lower()
            if not host or "youtube" in host or host == "youtu.be":
                continue
            if host == _MINE_HOST:
                mine_html = mine.get_text(iframe, referer=referer)
                for nested in _parse_mine_html(mine_html):
                    add(nested, iframe)
            elif site_client.allowed_url(iframe) and depth < max_internal:
                internal = site_client.get_text(iframe, referer=referer)
                if internal:
                    consume_movie(internal, iframe, depth + 1)
            else:
                add({"url": iframe, "name": host_label(iframe), "quality": quality_from(target), "info": ""}, referer)

    def consume_episode(fragment, referer, depth=0):
        fragment = str(fragment or "")
        block = _episode_block(fragment, int(season), int(episode))
        if block:
            # Only this exact S/E block may directly yield external hosters.
            for item in _external_items_from_html(block, base):
                p = urlsplit(item.get("url") or "")
                host = (p.hostname or "").lower()
                if host == _MINE_HOST:
                    mine_html = mine.get_text(item["url"], referer=referer)
                    for nested in _parse_mine_html(mine_html, season=season, episode=episode):
                        add(nested, item["url"])
                elif site_client.allowed_url(item.get("url")) and depth < max_internal:
                    internal = site_client.get_text(item["url"], referer=referer)
                    if internal:
                        consume_episode(internal, item["url"], depth + 1)
                else:
                    add(item, referer)
            for iframe in extract_iframes(block, base)[:8]:
                p = urlsplit(iframe)
                host = (p.hostname or "").lower()
                if not host or "youtube" in host or host == "youtu.be":
                    continue
                if host == _MINE_HOST:
                    mine_html = mine.get_text(iframe, referer=referer)
                    for nested in _parse_mine_html(mine_html, season=season, episode=episode):
                        add(nested, iframe)
                elif site_client.allowed_url(iframe) and depth < max_internal:
                    internal = site_client.get_text(iframe, referer=referer)
                    if internal:
                        consume_episode(internal, iframe, depth + 1)
                else:
                    add({"url": iframe, "name": host_label(iframe), "quality": quality_from(block), "info": ""}, referer)
            if out:
                return

        # No proven exact block: page-wide external data-link/iframe rows are
        # deliberately ignored.  A provider-declared MeineCloud serial player
        # is the only external fallback because we can re-validate exact S/E in
        # its structured episode rows.
        for raw in re.findall(r'(?:(?:src|href|data-link)\s*=\s*["\'])([^"\']*meinecloud\.click/[^"\']+)', fragment, re.I):
            mine_url = absolute_http(raw, "https://meinecloud.click/")
            if not mine.allowed_url(mine_url):
                continue
            mine_html = mine.get_text(mine_url, referer=referer)
            for nested in _parse_mine_html(mine_html, season=season, episode=episode):
                add(nested, mine_url)
            if out:
                return

        # A generic DEVIDEOSRC serial wrapper is also safe as an episode
        # fallback because ``add`` re-resolves it through the signed API and
        # filters the response to the exact requested S/E.
        ds_candidates = _external_items_from_html(fragment, base)
        for player in _devideosrc_players_from_html(fragment):
            ds_candidates.append({"url": player, "name": "DEVIDEOSRC", "quality": quality_from(fragment), "info": ""})
        for iframe in extract_iframes(fragment, base)[:8]:
            ds_candidates.append({"url": iframe, "name": host_label(iframe), "quality": quality_from(fragment), "info": ""})
        for item in ds_candidates:
            host = (urlsplit(str(item.get("url") or "")).hostname or "").lower()
            if host not in _DEVIDEOSRC_HOSTS:
                continue
            add(item, referer)
            if out:
                return

        # Same-provider internal wrappers may lead to a page that has an exact
        # S/E block.  Following those remains bounded and allowlisted.
        if depth < max_internal:
            for iframe in extract_iframes(fragment, base)[:8]:
                if not site_client.allowed_url(iframe):
                    continue
                internal = site_client.get_text(iframe, referer=referer)
                if internal:
                    consume_episode(internal, iframe, depth + 1)
                if out:
                    return

    cleaned = strip_comments(html)
    if season and episode:
        consume_episode(cleaned, page_url)
    else:
        consume_movie(cleaned, page_url)
    return out

