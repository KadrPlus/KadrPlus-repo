# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""StreamCloud catalogue provider written independently for Kadr+ 2.0."""

from __future__ import annotations

import re
from urllib.parse import quote, unquote, urlsplit

from lib.sources.de._kadr_de_common import absolute_http, clean_text, diag, year_of
from lib.sources.de._kadr_html_cloud_source import HtmlCloudSource


_GENERIC_LABELS = {"stream", "ansehen", "play", "mehr", "stream now", "details"}


def _is_js_shell(html):
    raw = str(html or "")
    low = raw.lower()
    if not raw.strip():
        return False
    if "you need to enable javascript" in low or "enable javascript to run this app" in low:
        return True
    # Generic SPA shell: script/root scaffolding but none of the catalogue
    # structures used by the server-rendered StreamCloud frontend.
    has_app_shell = bool(re.search(r'<div\b[^>]*id\s*=\s*["\'](?:root|app)["\']', raw, re.I))
    has_catalogue = bool(re.search(r'\bf_title\b|/\d+-[^/]+\.html|class\s*=\s*["\'][^"\']*\bitem\b', raw, re.I))
    return has_app_shell and not has_catalogue


def _slug_title(path):
    slug = unquote(str(path or "").rsplit("/", 1)[-1])
    slug = re.sub(r"\.html$", "", slug, flags=re.I)
    slug = re.sub(r"^\d+-", "", slug)
    # Current StreamCloud content URLs use e.g.
    # ``42055-vaiana-streaming-stream-deutsch.html`` and
    # ``31575-reacher-stream-deutsch.html``.  Strip only a trailing site marker.
    slug = re.sub(r"-(?:streaming(?:-stream)?|stream)(?:-(?:deutsch|german|online|kostenlos))*$", "", slug, flags=re.I)
    return clean_text(slug.replace("-", " "))


class source(HtmlCloudSource):
    provider_name = "streamcloud"
    # Current 2026-10 server-rendered frontend first.  ``.plus`` is the current
    # fallback; older HTTPS mirrors stay bounded fallbacks.  ``.my`` is
    # deliberately absent because it no longer belongs to this catalogue.
    base_urls = (
        "https://streamcloud.download", "https://www.streamcloud.download",
        "https://streamcloud.plus", "https://www.streamcloud.plus",
        "https://streamcloud.forum", "https://www.streamcloud.forum",
        "https://streamcloud.date", "https://www.streamcloud.date",
    )
    ref_prefix = "kadr-streamcloud:"

    def _parse_items(self, html):
        html = str(html or "")
        out, seen = [], set()

        # Known DLE card markup used by this catalogue family.
        chunks = re.split(r'(?=<div\b[^>]*class\s*=\s*["\'][^"\']*\bitem\b)', html, flags=re.I)
        for chunk in chunks[1:]:
            chunk = chunk[:16000]
            href_m = re.search(r'<a\b[^>]*href\s*=\s*["\']([^"\']+)', chunk, re.I)
            if not href_m:
                continue
            url = absolute_http(href_m.group(1), self.client.base)
            if not url or not self.client.allowed_url(url) or url in seen:
                continue
            title_m = re.search(r'class\s*=\s*["\'][^"\']*f_title[^"\']*["\'][^>]*>.*?<a\b[^>]*>(.*?)</a>', chunk, re.I | re.S)
            thumb_m = re.search(r'class\s*=\s*["\'][^"\']*thumb[^"\']*["\'][^>]*\btitle\s*=\s*(["\'])(.*?)\1', chunk, re.I | re.S)
            title = clean_text(title_m.group(1) if title_m else (thumb_m.group(2) if thumb_m else ""))
            if not title:
                continue
            seen.add(url)
            year_m = re.search(r'class\s*=\s*["\'][^"\']*f_year[^"\']*["\'][^>]*>.*?((?:19|20)\d{2})', chunk, re.I | re.S)
            sm = re.search(r'\b(?:Staffel|Season)\s*0*(\d+)', title + " " + clean_text(chunk[:1200]), re.I)
            out.append({
                "title": re.sub(r'\s*\((?:19|20)\d{2}\)\s*$', '', title).strip(),
                "year": year_m.group(1) if year_m else year_of(title),
                "season": int(sm.group(1)) if sm else 0,
                "url": url,
                "is_series": True if (sm or re.search(r'\bSerien?\b', clean_text(chunk[:1500]), re.I)) else None,
            })
        if out:
            return out

        # Layout-tolerant fallback: accept only canonical numeric detail URLs on
        # the same HTTPS origin.  Title is taken from textual/alt metadata and,
        # only as a last resort, from the deterministic content slug.
        for m in re.finditer(r'<a\b([^>]*)href\s*=\s*["\']([^"\']+)["\']([^>]*)>(.*?)</a>', html, re.I | re.S):
            url = absolute_http(m.group(2), self.client.base)
            p = urlsplit(url)
            if (not url or not self.client.allowed_url(url) or url in seen
                    or not re.search(r'/\d+-[^/]+\.html$', p.path, re.I)):
                continue
            attrs = (m.group(1) or "") + " " + (m.group(3) or "")
            body = m.group(4) or ""
            title = clean_text(body)
            if not title or title.lower() in _GENERIC_LABELS:
                am = re.search(r'<img\b[^>]*\balt\s*=\s*(["\'])(.*?)\1', body, re.I | re.S)
                title = clean_text(am.group(2) if am else "")
            if not title or title.lower() in _GENERIC_LABELS:
                tm = re.search(r'\btitle\s*=\s*(["\'])(.*?)\1', attrs, re.I | re.S)
                title = clean_text(tm.group(2) if tm else "")
            if not title or title.lower() in _GENERIC_LABELS:
                title = _slug_title(p.path)
            if not title:
                continue
            left, right = max(0, m.start() - 1200), min(len(html), m.end() + 1800)
            card = html[left:right]
            local = m.start() - left
            hits = [(abs(y.start() - local), y.group(1)) for y in re.finditer(r'(?<!\d)((?:19|20)\d{2})(?!\d)', clean_text(card))]
            year = min(hits)[1] if hits else year_of(title)
            sm = re.search(r'\b(?:Staffel|Season)\s*0*(\d+)', title + " " + clean_text(card), re.I)
            seen.add(url)
            out.append({
                "title": re.sub(r'\s*\((?:19|20)\d{2}\)\s*$', '', title).strip(),
                "year": year,
                "season": int(sm.group(1)) if sm else 0,
                "url": url,
                "is_series": True if (sm or re.search(r'\bSerien?\b', clean_text(card), re.I)) else None,
            })
        return out

    def _search_items(self, query):
        encoded = quote(str(query or ""))
        # Current frontend search.  Keep the older /streamcloud/ variants as
        # bounded fallbacks only when the primary DLE response is unavailable.
        for path in (
            "/?do=search&subaction=search&story=" + encoded,
            "/index.php?do=search&subaction=search&story=" + encoded,
            "/streamcloud/?do=search&subaction=search&story=" + encoded,
            "/streamcloud/index.php?do=search&subaction=search&story=" + encoded,
        ):
            html = self.client.get_text(path)
            if _is_js_shell(html):
                diag(self.provider_name, "search-shell", "javascript-only frontend")
                continue
            items = self._parse_items(html)
            if items:
                return items
        # Older mirrors exposed a bounded home index at /streamcloud/.  Keep it
        # only as a last discovery fallback; no category/page crawl.
        html = self.client.get_text("/streamcloud/")
        if not _is_js_shell(html):
            items = self._parse_items(html)
            if items:
                diag(self.provider_name, "catalog-fallback", "page=streamcloud-home items=%d" % len(items))
                return items
        return []
