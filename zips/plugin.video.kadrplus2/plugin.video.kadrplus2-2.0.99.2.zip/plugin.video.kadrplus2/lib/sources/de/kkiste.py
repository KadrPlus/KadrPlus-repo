# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""KKiste provider for the current HTTPS DLE frontend."""

from lib.sources.de._kadr_dle_matrix import DLEMatrixSource


class source(DLEMatrixSource):
    provider_name = "kkiste"
    base_urls = (
        "https://kkiste-io.ink", "https://www.kkiste-io.ink",
    )
    ref_prefix = "kadr-kkiste:"
    get_search_templates = (
        "/index.php?do=search&subaction=search&story={q}",
        "/?do=search&subaction=search&story={q}",
    )
    post_search = True
