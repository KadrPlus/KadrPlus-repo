# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""TopStreamFilm provider written independently for Kadr+ 2.0."""

from __future__ import annotations

import re
from urllib.parse import quote, unquote, urlsplit

from lib.sources.de._kadr_de_common import absolute_http, clean_text, normalize_title, year_of
from lib.sources.de._kadr_html_cloud_source import HtmlCloudSource


_GENERIC_LABELS = {"stream", "ansehen", "play", "mehr", "details", "stream now"}


def _slug_title(path):
    slug = unquote(str(path or "").rsplit("/", 1)[-1])
    slug = re.sub(r"\.html$", "", slug, flags=re.I)
    slug = re.sub(r"^\d+-", "", slug)
    slug = re.sub(r"-(?:streaming(?:-online)?|stream(?:-online)?|online|kostenlos)(?:-.*)?$", "", slug, flags=re.I)
    return clean_text(slug.replace("-", " "))


class source(HtmlCloudSource):
    provider_name = "topstreamfilm"
    base_urls = (
        "https://topstreamfilm.best", "https://www.topstreamfilm.best",
        "https://topstreamfilm.live", "https://www.topstreamfilm.live",
    )
    ref_prefix = "kadr-topstreamfilm:"

    def _parse_fallback_items(self, html):
        html = str(html or "")
        out, seen = [], set()
        for m in re.finditer(r'<a\b([^>]*)href\s*=\s*["\']([^"\']+)["\']([^>]*)>(.*?)</a>', html, re.I | re.S):
            url = absolute_http(m.group(2), self.client.base)
            p = urlsplit(url)
            if (not url or not self.client.allowed_url(url) or url in seen
                    or not p.path.lower().startswith("/kostenlos/")
                    or not p.path.lower().endswith(".html")):
                continue
            attrs = (m.group(1) or "") + " " + (m.group(3) or "")
            body = m.group(4) or ""
            tm = re.search(r'\btitle\s*=\s*(["\'])(.*?)\1', attrs, re.I | re.S)
            title = clean_text(body)
            if not title or title.lower() in _GENERIC_LABELS:
                im = re.search(r'<img\b[^>]*\b(?:alt|title)\s*=\s*(["\'])(.*?)\1', body, re.I | re.S)
                title = clean_text(im.group(2) if im else "")
            if not title or title.lower() in _GENERIC_LABELS:
                title = clean_text(tm.group(2) if tm else "")
            if not title or title.lower() in _GENERIC_LABELS:
                title = _slug_title(p.path)
            if not title:
                continue
            suffix_year = re.search(r'[-–—]\s*Der\s+Film\s+((?:19|20)\d{2})\s*$', title, re.I)
            title_year = suffix_year.group(1) if suffix_year else ""
            left = max(0, m.start() - 1200)
            right = min(len(html), m.end() + 2600)
            card = html[left:right]
            title = re.sub(r'\s*[-–—]\s*Der\s+Film(?:\s+(?:19|20)\d{2})?\s*$', "", title, flags=re.I).strip()
            local = m.start() - left
            year_hits = [(abs(y.start() - local), y.group(1)) for y in re.finditer(r'(?<!\d)((?:19|20)\d{2})(?!\d)', clean_text(card))]
            nearest_year = min(year_hits)[1] if year_hits else ""
            sm = re.search(r'\b(?:Staffel|Season)\s*0*(\d+)', title + " " + clean_text(card), re.I)
            path = p.path.lower()
            if sm or "/serien/" in path or "/serie/" in path:
                media_type = True
            elif re.search(r'\b(?:Serie|Serien|Staffel)\b', clean_text(card), re.I):
                media_type = True
            else:
                # The site labels real TV shows as "Der Film" too; unknown is
                # safer than forcing movie based on presentation text.
                media_type = None
            seen.add(url)
            out.append({
                "title": title,
                "year": title_year or nearest_year or year_of(title),
                "season": int(sm.group(1)) if sm else 0,
                "url": url,
                "is_series": media_type,
            })
        return out

    def _parse_article_items(self, html):
        """Parse the current WordPress-like ``article.TPost`` search grid."""
        out, seen = [], set()
        chunks = re.split(
            r'(?=<article\b[^>]*class\s*=\s*["\'][^"\']*\bTPost\b)',
            str(html or ""), flags=re.I,
        )
        for chunk in chunks[1:]:
            chunk = chunk[:18000]
            href_m = re.search(r'<a\b[^>]*href\s*=\s*(["\'])(.*?)\1', chunk, re.I | re.S)
            title_m = re.search(r'<h[1-4]\b[^>]*class\s*=\s*(["\'])[^"\']*\bTitle\b[^"\']*\1[^>]*>(.*?)</h[1-4]>', chunk, re.I | re.S)
            if not href_m or not title_m:
                continue
            url = absolute_http(href_m.group(2), self.client.base)
            p = urlsplit(url)
            if (not url or not self.client.allowed_url(url) or url in seen
                    or not p.path.lower().startswith("/kostenlos/")
                    or not p.path.lower().endswith(".html")):
                continue
            title = clean_text(title_m.group(2))
            if not title:
                continue
            suffix_year = re.search(r'[-–—]\s*Der\s+Film\s+((?:19|20)\d{2})\s*$', title, re.I)
            title_year = suffix_year.group(1) if suffix_year else ""
            title = re.sub(r'\s*[-–—]\s*Der\s+Film(?:\s+(?:19|20)\d{2})?\s*$', "", title, flags=re.I).strip()
            ym = re.search(r'(?<!\d)((?:19|20)\d{2})(?!\d)', clean_text(chunk[:4500]))
            sm = re.search(r'\b(?:Staffel|Season)\s*0*(\d+)', title + " " + clean_text(chunk[:1800]), re.I)
            seen.add(url)
            out.append({
                "title": title,
                "year": title_year or (ym.group(1) if ym else year_of(title)),
                "season": int(sm.group(1)) if sm else 0,
                "url": url,
                # The live site labels many real TV shows as "Der Film"; keep
                # type unknown unless explicit series evidence is present.
                "is_series": True if sm else None,
            })
        return out

    def _parse_tpost_items(self, html):
        out, seen = [], set()
        chunks = re.split(r'(?=<(?:article|li|div)\b[^>]*class\s*=\s*["\'][^"\']*\bTPostMv)', str(html or ""), flags=re.I)
        for chunk in chunks[1:]:
            chunk = chunk[:18000]
            href_m = re.search(r'<a\b[^>]*href\s*=\s*["\']([^"\']+)', chunk, re.I)
            title_m = re.search(r'class\s*=\s*["\'][^"\']*\bTitle\b[^"\']*["\'][^>]*>(.*?)</', chunk, re.I | re.S)
            if not href_m or not title_m:
                continue
            url = absolute_http(href_m.group(1), self.client.base)
            if not url or not self.client.allowed_url(url) or url in seen:
                continue
            title = clean_text(title_m.group(1))
            if not title:
                continue
            suffix_year = re.search(r'[-–—]\s*Der\s+Film\s+((?:19|20)\d{2})\s*$', title, re.I)
            title_year = suffix_year.group(1) if suffix_year else ""
            title = re.sub(r'\s*[-–—]\s*Der\s+Film(?:\s+(?:19|20)\d{2})?\s*$', "", title, flags=re.I).strip()
            seen.add(url)
            ym = re.search(r'class\s*=\s*["\'][^"\']*\bYear\b[^"\']*["\'][^>]*>\s*((?:19|20)\d{2})', chunk, re.I)
            sm = re.search(r'\b(?:Staffel|Season)\s*0*(\d+)', title + " " + clean_text(chunk[:1400]), re.I)
            path = urlsplit(url).path.lower()
            is_series = True if ("/serien/" in path or "/serie/" in path or bool(sm)) else None
            out.append({
                "title": title,
                "year": title_year or (ym.group(1) if ym else year_of(title)),
                "season": int(sm.group(1)) if sm else 0,
                "url": url,
                "is_series": is_series,
            })
        return out

    def _search_items(self, query):
        query = str(query or "").strip()
        encoded = quote(query)
        qnorm = normalize_title(query)

        def parse(html):
            return self._parse_tpost_items(html) or self._parse_article_items(html) or self._parse_fallback_items(html)

        # Current 2026-10 DLE endpoint.  Always try it before the WordPress-like
        # ``?s=`` route: the latter can return a generic 25-card grid unrelated
        # to the query and previously prevented the real search from running.
        for path in (
            "/index.php?do=search&subaction=search&story=%s" % encoded,
            "/?do=search&subaction=search&story=%s" % encoded,
            "/?story=%s&do=search&subaction=search" % encoded,
        ):
            html = self.client.get_text(path)
            if not html:
                continue
            items = parse(html)
            if items:
                return items

        html = self.client.post_text("/", data={
            "do": "search", "subaction": "search", "story": query,
        })
        items = parse(html) if html else []
        if items:
            return items

        # Compatibility fallback only.  Accept it as a search result set only
        # if at least one title is lexically plausible for the actual query.
        html = self.client.get_text("/?s=%s" % encoded)
        wp_items = parse(html) if html else []
        if wp_items:
            plausible = []
            for item in wp_items:
                tnorm = normalize_title(item.get("title") or "")
                if qnorm and tnorm and (qnorm in tnorm or tnorm in qnorm):
                    plausible.append(item)
            if plausible:
                return wp_items

        # One bounded home-page fallback for a title that happens to be fresh;
        # no category/page crawl.
        home = parse(self.client.get_text("/"))
        if not home:
            return []
        return [item for item in home if (
            qnorm and normalize_title(item.get("title") or "") and
            (qnorm in normalize_title(item.get("title") or "") or
             normalize_title(item.get("title") or "") in qnorm)
        )]
