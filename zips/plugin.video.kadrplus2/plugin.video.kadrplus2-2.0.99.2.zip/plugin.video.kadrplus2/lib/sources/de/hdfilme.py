# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""HD Filme provider written independently for Kadr+ 2.0."""

from __future__ import annotations

import re
from urllib.parse import quote, unquote, urlsplit

from lib.sources.de._kadr_de_common import absolute_http, clean_text, year_of
from lib.sources.de._kadr_html_cloud_source import HtmlCloudSource


class source(HtmlCloudSource):
    provider_name = "hdfilme"
    base_urls = (
        # Current 2026-10 origin first; older HTTPS frontends remain bounded
        # fallbacks so a temporary migration does not require a code release.
        "https://hdfilme.ceo", "https://www.hdfilme.ceo",
        "https://hdfilme.cafe", "https://www.hdfilme.cafe",
        "https://hdfilme.to", "https://www.hdfilme.to",
        "https://hd-filme.lol", "https://www.hd-filme.lol",
        "https://hdfilme1.co", "https://www.hdfilme1.co",
    )
    ref_prefix = "kadr-hdfilme:"

    def _parse_current_cards(self, html):
        """Parse the current ``div.item.relative`` DLE result cards."""
        raw = str(html or "")
        starts = [m.start() for m in re.finditer(
            r'<div\b[^>]*class\s*=\s*["\'][^"\']*\bitem\b[^"\']*\brelative\b', raw, re.I,
        )]
        out, seen = [], set()
        for idx, start in enumerate(starts):
            end = starts[idx + 1] if idx + 1 < len(starts) else min(len(raw), start + 18000)
            card = raw[start:end]
            anchors = re.findall(r'<a\b([^>]*)href\s*=\s*["\']([^"\']+)["\']([^>]*)>(.*?)</a>', card, re.I | re.S)
            detail = title = ""
            for left, href, right, body in anchors:
                url = absolute_http(href, self.client.base)
                p = urlsplit(url)
                if (not url or not self.client.allowed_url(url)
                        or not re.search(r'^/filme1/\d+-.+\.html$', p.path, re.I)):
                    continue
                attrs = (left or "") + " " + (right or "")
                tm = re.search(r'\btitle\s*=\s*(["\'])(.*?)\1', attrs, re.I | re.S)
                text = clean_text(body)
                candidate = clean_text(tm.group(2) if tm else "") or text
                if candidate:
                    detail, title = url, candidate
                    break
                if not detail:
                    detail = url
            if not detail or detail in seen:
                continue
            if not title:
                p = urlsplit(detail)
                slug = unquote(p.path.rsplit("/", 1)[-1])
                slug = re.sub(r'^\d+-|\.html$', "", slug, flags=re.I)
                slug = re.sub(r'-stream(?:ing)?(?:-online)?$', "", slug, flags=re.I)
                title = clean_text(slug.replace("-", " "))
            title = re.sub(r'\s+hdfilme(?:\s+stream(?:\s+online)?)?\s*$', "", title, flags=re.I).strip()
            if not title:
                continue
            ym = re.search(r'<span\b[^>]*>\s*((?:19|20)\d{2})\s*</span>', card, re.I)
            sm = re.search(r'\b(?:Staffel|Season)\s*0*(\d+)', title + " " + clean_text(card[:5000]), re.I)
            seen.add(detail)
            out.append({
                "title": re.sub(r'\s*\((?:19|20)\d{2}\)\s*$', "", title).strip(),
                "year": ym.group(1) if ym else year_of(title),
                "season": int(sm.group(1)) if sm else 0,
                "url": detail,
                "is_series": True if (sm or re.search(r'\bSerien?\b', clean_text(card[:5000]), re.I)) else None,
            })
        return out

    def _parse_search_items(self, html):
        current = self._parse_current_cards(html)
        if current:
            return current

        out, seen = [], set()
        pattern = re.compile(
            r'<a\b[^>]*href\s*=\s*["\']([^"\']+)["\'][^>]*>\s*'
            r'<span\b[^>]*class\s*=\s*["\'][^"\']*searchheading[^"\']*["\'][^>]*>(.*?)</span>'
            r'\s*<span[^>]*>(.*?)</span>',
            re.I | re.S,
        )
        for href, title_html, meta_html in pattern.findall(str(html or "")):
            url = absolute_http(href, self.client.base)
            if not url or not self.client.allowed_url(url) or url in seen:
                continue
            title = re.sub(r'\s+stream\s*$', "", clean_text(title_html), flags=re.I).strip()
            if not title:
                continue
            seen.add(url)
            meta = clean_text(meta_html)
            sm = re.search(r'\b(?:Staffel|Season)\s*0*(\d+)', title + " " + meta, re.I)
            out.append({
                "title": title,
                "year": year_of(meta),
                "season": int(sm.group(1)) if sm else 0,
                "url": url,
                "is_series": True if (sm or re.search(r'\bSerien?\b', meta, re.I)) else None,
            })
        if out:
            return out

        # Compatibility parser for older layouts.  Restrict candidates to the
        # canonical numeric detail path so menus/tags can never become media.
        raw = str(html or "")
        for m in re.finditer(r'<a\b([^>]*)href\s*=\s*["\']([^"\']+)["\']([^>]*)>(.*?)</a>', raw, re.I | re.S):
            url = absolute_http(m.group(2), self.client.base)
            p = urlsplit(url)
            if (not url or not self.client.allowed_url(url) or url in seen
                    or not re.search(r'^/filme1/\d+-.+\.html$', p.path, re.I)):
                continue
            attrs = (m.group(1) or "") + " " + (m.group(3) or "")
            body = m.group(4) or ""
            im = re.search(r'<img\b[^>]*\b(?:alt|title)\s*=\s*(["\'])(.*?)\1', body, re.I | re.S)
            tm = re.search(r'\btitle\s*=\s*(["\'])(.*?)\1', attrs, re.I | re.S)
            text = clean_text(body)
            title = clean_text(im.group(2) if im else "") or clean_text(tm.group(2) if tm else "")
            if not title and text and len(text) <= 180:
                title = text
            if not title:
                slug = unquote(p.path.rsplit("/", 1)[-1])
                slug = re.sub(r'^\d+-|\.html$', "", slug, flags=re.I)
                slug = re.sub(r'-stream(?:ing)?(?:-online)?$', "", slug, flags=re.I)
                title = clean_text(slug.replace("-", " "))
            title = re.sub(r'\s+hdfilme(?:\s+stream(?:\s+online)?)?\s*$', "", title, flags=re.I).strip()
            if not title:
                continue
            left, right = max(0, m.start() - 900), min(len(raw), m.end() + 1600)
            card = raw[left:right]
            meta = clean_text(card)
            ym = re.search(r'(?<!\d)((?:19|20)\d{2})(?!\d)', meta)
            sm = re.search(r'\b(?:Staffel|Season)\s*0*(\d+)', title + " " + meta, re.I)
            seen.add(url)
            out.append({
                "title": re.sub(r'\s*\((?:19|20)\d{2}\)\s*$', "", title).strip(),
                "year": ym.group(1) if ym else year_of(title),
                "season": int(sm.group(1)) if sm else 0,
                "url": url,
                "is_series": True if (sm or re.search(r'\bSerien?\b', meta, re.I)) else None,
            })
        return out

    def _search_items(self, query):
        query = str(query or "").strip()
        encoded = quote(query)

        # Current DLE endpoint first.  This avoids treating the site's generic
        # home grid as if it were a search result set.
        for path in (
            "/?story=%s&do=search&subaction=search" % encoded,
            "/?do=search&subaction=search&story=" + encoded,
            "/index.php?do=search&subaction=search&story=" + encoded,
        ):
            items = self._parse_search_items(self.client.get_text(path))
            if items:
                return items

        # Older frontend fallback: use its own hash-backed AJAX endpoint only
        # when native DLE search produced no parseable result.
        home = self.client.get_text("/")
        hm = re.search(r"dle_login_hash\s*=\s*['\"]([a-f0-9]+)['\"]", home, re.I)
        if hm:
            html = self.client.post_text(
                "/engine/ajax/controller.php?mod=search",
                data={"query": query, "user_hash": hm.group(1)},
                headers={"Content-Type": "application/x-www-form-urlencoded", "X-Requested-With": "XMLHttpRequest"},
                referer=self.client.base + "/",
            )
            items = self._parse_search_items(html)
            if items:
                return items

        # One bounded home fallback only; no catalogue/page crawl.
        return self._parse_search_items(home)
