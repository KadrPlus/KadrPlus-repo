# -*- coding: utf-8 -*-
"""
FanFilm - źródło: Videasy (backendowe serwery przez player.videasy.to)
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>

Każdy serwer Videasy (Yoru/Breach/…) zwraca payload zaszyfrowany strumieniem
wyliczanym z jednorazowego `seed` (GET /seed?mediaId=<tmdb>) i TMDB id -
deszyfrowanie lokalne, port funkcji z chunka playera; enc-dec.app tylko jako
zapas, gdy Videasy zmieni algorytm.
"""

from __future__ import annotations

import base64
import json
import threading
from typing import ClassVar, Dict, List, Optional, TYPE_CHECKING
from urllib.parse import urlencode, parse_qs, quote

from lib.ff import requests
from lib.ff.source_utils import get_quality, append_headers, probe_m3u8_quality, enc_dec_result
from lib.ff.log_utils import fflog, fflog_exc

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.sources import SourceItem, SourceTitleAlias


_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
       '(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36')
# Videasy has rotated its domain before (videasy.net -> videasy.to); change
# it here only if it happens again.
_PLAYER_BASE = 'https://player.videasy.to'
# the player moved its source API off api.videasy.to (no longer resolves) -
# grep the player's lazy "sources-with-title" chunk for the new host
_API_BASE = 'https://api.speedracelight.com'
_HEADERS: Dict[str, str] = {
    'User-Agent': _UA,
    'Accept': 'application/json, text/plain, */*',
    'Origin': _PLAYER_BASE,
    'Referer': f'{_PLAYER_BASE}/',
}
_STREAM_HEADERS: Dict[str, str] = {
    'Referer': f'{_PLAYER_BASE}/',
    'Origin': _PLAYER_BASE,
    'User-Agent': _UA,
}
# only the player's original-audio servers; Killjoy/Fade/Omen/Raze are DE/HI/ES/PT dubs
_SERVERS: Dict[str, str] = {
    'Yoru':   f'{_API_BASE}/cdn/sources-with-title',
    'Cypher': f'{_API_BASE}/downloader2/sources-with-title',
    'Breach': f'{_API_BASE}/m4uhd/sources-with-title',
    'Neon':   f'{_API_BASE}/vsrc/sources-with-title',
    'Vyse':   f'{_API_BASE}/hdmovie/sources-with-title',
}
# hdmovie returns both dubs at once, labelled by language in the quality field
_QUALITY_FILTER: Dict[str, str] = {'Vyse': 'English'}
_SCHEME = 'videasy://'


# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['en']

    ffitem: 'FFItem'

    def __init__(self) -> None:
        self.session = requests.Session()
        self.session.headers.update(_HEADERS)

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str,
              aliases: 'list[SourceTitleAlias]', year: str) -> Optional[str]:
        tmdb = str(self.ffitem.tmdb_id or '')
        if not tmdb or not title:
            return None
        return self._encode(type='movie', tmdb=tmdb, imdb=imdb or '',
                       title=title, year=str(year or ''))

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str,
               aliases: 'list[SourceTitleAlias]', year: str) -> Optional[str]:
        # for episodes ffitem.tmdb_id is the episode id; show-level id lives on show_item
        show_item = getattr(self.ffitem, 'show_item', None)
        tmdb = str((show_item.tmdb_id if show_item else None) or self.ffitem.tmdb_id or '')
        if not tmdb or not tvshowtitle:
            return None
        return self._encode(type='tv', tmdb=tmdb, imdb=imdb or '',
                       title=tvshowtitle, year=str(year or ''))

    def episode(self, url: Optional[str], imdb: str, tvdb: str, title: str,
                premiered: str, season: str, episode: str) -> Optional[str]:
        if not url:
            return None
        return f'{url}&s={int(season)}&e={int(episode)}'

    def sources(self, url: Optional[str], hostDict: List[str],
                hostprDict: List[str]) -> 'List[SourceItem]':
        if not url:
            return []
        params = self._decode(url)
        if not params or not params.get('title'):
            return []

        seed = self._fetch_seed(params.get('tmdb', ''))
        if not seed:
            return []

        results: List[dict] = []
        lock = threading.Lock()

        threads = [threading.Thread(target=self._fetch_server,
                                    args=(n, u, params, seed, results, lock),
                                    daemon=True)
                   for n, u in _SERVERS.items()]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=15)

        unique = self._dedupe(results)
        fflog(f'found {len(unique)} streams across {len(_SERVERS)} servers')
        return unique

    def resolve(self, url: str) -> Optional[str]:
        return url

    # ── helpers ────────────────────────────────────────────────────────────

    @staticmethod
    def _encode(**kwargs: str) -> str:
        return _SCHEME + urlencode({k: v for k, v in kwargs.items() if v is not None})

    @staticmethod
    def _decode(url: str) -> Dict[str, str]:
        if not url.startswith(_SCHEME):
            return {}
        qs = url[len(_SCHEME):]
        parsed = parse_qs(qs, keep_blank_values=True)
        return {k: v[0] for k, v in parsed.items()}

    def _fetch_seed(self, tmdb: str) -> str | None:
        """One-shot decryption seed; valid ~30s, bound to this TMDB id."""
        if not tmdb:
            return None
        try:
            resp = self.session.get(f'{_API_BASE}/seed', params={'mediaId': tmdb}, timeout=10)
            if resp.ok:
                return resp.json().get('seed') or None
            fflog(f'seed failed: {resp.status_code}')
        except Exception:
            fflog_exc()
        return None

    def _fetch_server(self, name: str, server_url: str, params: Dict[str, str], seed: str,
                      out: List[dict], lock: threading.Lock) -> None:
        """Hit one Videasy backend, decrypt, append SourceItems to `out`."""
        try:
            q: Dict[str, str] = {
                # the player pre-encodes the title and its HTTP client encodes it again
                'title': quote(params['title']),
                'mediaType': params.get('type', 'movie'),
                'year': params.get('year', ''),
                'tmdbId': params.get('tmdb', ''),
                'imdbId': params.get('imdb', ''),
            }
            if params.get('type') == 'tv':
                q['seasonId'] = params.get('s', '')
                q['episodeId'] = params.get('e', '')
            q['enc'] = '2'
            q['seed'] = seed
            r = self.session.get(server_url, params=q, timeout=10)
            if not r.ok:
                return
            text = r.text or ''
            if len(text) < 20 or text.lstrip().startswith('<!'):
                return
            data = _decrypt(text, seed, params.get('tmdb', ''))
            if data is None:
                # keystream rotated - enc-dec.app tracks the player and may already know the new one
                data = enc_dec_result('dec-videasy', json_body={'text': text, 'id': params.get('tmdb', ''), 'seed': seed})
            if not isinstance(data, dict):
                return
            wanted_label = _QUALITY_FILTER.get(name)
            for s in data.get('sources') or []:
                su = s.get('url')
                if not su:
                    continue
                if wanted_label and s.get('quality') != wanted_label:
                    continue
                quality = get_quality(str(s.get('quality') or ''))
                if '.m3u8' in su:
                    probed = probe_m3u8_quality(su, _STREAM_HEADERS)
                    if probed:
                        quality = probed
                final = f'{su}{append_headers(_STREAM_HEADERS)}'
                if '.m3u8' in su or '.mpd' in su:
                    final = f'isa+{final}'
                with lock:
                    out.append({
                        'source': f'VIDEASY {name}',
                        'quality': quality,
                        'language': 'en',
                        'url': final,
                        'direct': True,
                        'debridonly': False,
                    })
        except Exception:
            fflog_exc()

    @staticmethod
    def _dedupe(items: List[dict]) -> List[dict]:
        """Drop entries with the same base URL (header tail ignored)."""
        seen: set = set()
        out: List[dict] = []
        for it in items:
            base = it['url'].split('|', 1)[0]
            if base in seen:
                continue
            seen.add(base)
            out.append(it)
        return out


# ─── payload decryption ─────────────────────────────────────────────────────────
# 32-bit port of the player's keystream (chunk 8351, fn `y`): the payload is
# base64url(XOR(b'mvm1' + json, keystream(seed, tmdb_id))).

_MASK = 0xFFFFFFFF
_GOLDEN = 0x9E3779B9
_TABLE_SIZE = 61
_MAGIC = b'mvm1'


def _fmix32(value: int) -> int:
    """MurmurHash3 32-bit finalizer (the player's `w`)."""
    value &= _MASK
    value ^= value >> 16
    value = (value * 0x85EBCA6B) & _MASK
    value ^= value >> 13
    value = (value * 0xC2B2AE35) & _MASK
    return (value ^ (value >> 16)) & _MASK


def _rotl32(value: int, shift: int) -> int:
    """32-bit rotate left (the player's `v`)."""
    value &= _MASK
    shift &= 31
    return value if not shift else ((value << shift) | (value >> (32 - shift))) & _MASK


def _fnv1a(text: str) -> int:
    """FNV-1a hash of the seed, finalized with _fmix32."""
    value = 0x811C9DC5
    for char in text:
        value = ((value ^ ord(char)) * 0x01000193) & _MASK
    return _fmix32(value)


def _keystream(seed: str, media_id: str, length: int) -> bytes:
    """Generate `length` XOR key bytes for one seed/TMDB id pair."""
    # the JS table is a sparse Array(61): a missing slot reads as 0 and also
    # switches the AND term off, hence the dict instead of a list
    table: dict[int, int] = {}
    state = _fmix32(_fnv1a(seed) ^ _fmix32((int(media_id) & _MASK) ^ _GOLDEN))
    for round_no in range(8):
        slot = state % _TABLE_SIZE
        state = _rotl32(state + _GOLDEN, 7 + (round_no & 7))
        table[slot] = state ^ _fmix32(state)
        state = _fmix32(state + slot)
    state = _fmix32(0xA5A5A5A5 ^ state)

    out = bytearray()
    counter = 0
    while len(out) < length:
        slot = state % _TABLE_SIZE
        mixed = table.get(slot, 0) ^ ((_GOLDEN * (counter + 1)) & _MASK)
        word = (state ^ mixed) | ((state & mixed) if slot in table else 0)
        word = _rotl32(word + state, slot) ^ _rotl32(state, slot * 7)
        state = _fmix32(word + _GOLDEN)
        table[slot] = state
        counter += 1
        out += state.to_bytes(4, 'little')
    return bytes(out[:length])


def _decrypt(text: str, seed: str, media_id: str) -> dict | None:
    """Decode a sources-with-title payload, or None when the seed/algorithm doesn't match."""
    try:
        text = text.strip()
        raw = base64.urlsafe_b64decode(text + '=' * (-len(text) % 4))
        plain = bytes(cipher ^ key for cipher, key in zip(raw, _keystream(seed, media_id, len(raw))))
        if not plain.startswith(_MAGIC):
            fflog('decrypt failed: bad seed or payload')
            return None
        return json.loads(plain[len(_MAGIC):].decode('utf-8'))
    except Exception:
        fflog_exc()
        return None


if __name__ == '__main__':
    try:
        from lib.ff.cmdline import DebugArgumentParser as ArgumentParser
    except ImportError:
        from argparse import ArgumentParser
    parser = ArgumentParser(description='Test Videasy source provider')
    parser.add_argument('tmdb_id', help='TMDB ID')
    parser.add_argument('--title', required=True)
    parser.add_argument('--year', default='')
    parser.add_argument('--imdb', default='')
    parser.add_argument('--type', default='movie', choices=['movie', 'tv'])
    parser.add_argument('--season', type=int, default=None)
    parser.add_argument('--episode', type=int, default=None)
    args = parser.parse_args()
    src = source()
    url = source._encode(type=args.type, tmdb=args.tmdb_id, imdb=args.imdb,
                  title=args.title, year=args.year)
    if args.type == 'tv':
        url = f'{url}&s={args.season}&e={args.episode}'
    try:
        from pprint import pprint
        pprint(src.sources(url, [], []))
    except Exception as e:
        print(f'Error: {e}')
