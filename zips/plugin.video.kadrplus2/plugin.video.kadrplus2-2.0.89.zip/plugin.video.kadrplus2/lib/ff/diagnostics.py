"""Optional, privacy-safe diagnostics for Kadr+ 2.0.

The feature is deliberately dormant unless the user enables
``diagnostics.enabled``. Detailed records go only to Kodi's standard
``kodi.log``. Credentials, source URLs, local paths and searched media titles
are redacted.
"""

from __future__ import annotations

from http.client import HTTPConnection
import json
from pathlib import Path
import platform
import re
from typing import Any, Mapping
from urllib.parse import urlsplit

import xbmc
from xbmcaddon import Addon

from . import control
from .db import state
from .settings import settings
from ..kolang import L
from const import StateMode


_ALLOWED_PROVIDER_STATUSES = frozenset({
    'running', 'ok', 'empty', 'error', 'cancelled', 'timeout', 'unknown',
})
_URL_RE = re.compile(
    r'(?i)(?:[a-z][a-z0-9+.-]*://|magnet:\?)[^\s\]})>,\'"]+'
)
_SECRET_RE = re.compile(
    r'(?i)\b(token|authorization|cookie|api[_-]?key|secret|password|session)'
    r'\b\s*[:=]\s*[^\s,;]+'
)
_PATH_RE = re.compile(
    r'(?i)(?:[a-z]:\\[^\s,;]+|/(?:[^/\s,;]+/)+[^/\s,;]*)'
)
_CONTROL_RE = re.compile(r'[\x00-\x1f\x7f]+')
_QUERY_LINE_RE = re.compile(r'(?i)\b(?:zapytania|queries used)\s*:.*$')
_QUICK_QUERY_RE = re.compile(r'(?i)(\bquick query)\s+.+?\s+(\bend\b)')
_QUERY_VALUE_RE = re.compile(
    r'(?i)\bqueries=(?!\d+\b).*?(?=\s+[a-z_]+\s*=|[;]|$)'
)
_PRIVATE_NAME_RE = re.compile(
    r'(?i)\b(chat|title)\s*=\s*.*?(?=\s+[a-z_]+\s*=|[;,]|$)'
)
_PRIVATE_ID_RE = re.compile(
    r'(?i)\b(header_id|video_msg|msg|gid|chat_id|peer_id|id)\s*=\s*[^\s,;]+'
)


_LEGACY_DIAGNOSTIC_LOG_NAME = 'kadrplus_diagnostics.log'


def remove_legacy_log() -> None:
    """Remove the retired standalone diagnostics file, if it still exists."""
    try:
        (Path(control.dataPath) / _LEGACY_DIAGNOSTIC_LOG_NAME).unlink(missing_ok=True)
    except Exception:
        # A stale diagnostic file must never affect service startup.
        pass


def describe_url(value: Any) -> str:
    """Describe a URL/token without writing paths, queries, tokens or headers."""
    try:
        text = str(value or '').strip()
        if not text:
            return 'empty'
        if text.startswith('kisskh:'):
            return 'scheme=kisskh token=redacted'
        if text.startswith('stack://'):
            return f'scheme=stack parts={text.count(" , ") + 1}'
        if text.startswith('DRMFF|'):
            return 'scheme=DRMFF descriptor=redacted'
        parsed = urlsplit(text.split('|', 1)[0])
        scheme = (parsed.scheme or 'relative').lower()
        host = (parsed.hostname or '').lower()
        if scheme == 'plugin' and not host:
            host = (parsed.netloc or '').lower()
        suffix = Path(parsed.path or '').suffix.lower()[:12]
        bits = [f'scheme={scheme}']
        if host:
            bits.append(f'host={host[:120]}')
        if suffix:
            bits.append(f'ext={suffix}')
        return ' '.join(bits)
    except Exception:
        return 'unparseable'


def _source_get(source: Any, key: str, default: Any = '') -> Any:
    try:
        if hasattr(source, 'get'):
            return source.get(key, default)
        return getattr(source, key, default)
    except Exception:
        return default


def log_source_event(stage: str, source: Any, url: Any = None, *, detail: str = '', level: int = xbmc.LOGINFO) -> None:
    """Write a safe source-click/resolve stage for every provider."""
    if not enabled():
        return
    provider = _safe_provider_name(_source_get(source, 'provider', 'unknown'))
    hosting = _safe_provider_name(_source_get(source, 'hosting', 'unknown'))
    direct = bool(_source_get(source, 'direct', False))
    local = bool(_source_get(source, 'local', False))
    debrid = bool(_source_get(source, 'debrid', ''))
    msg = (
        f'stage={stage}; provider={provider}; hosting={hosting}; '
        f'direct={direct}; local={local}; debrid={debrid}; url={describe_url(url)}'
    )
    if detail:
        msg += f'; {detail}'
    log_event('source-resolve', msg, level=level)


def enabled() -> bool:
    """Return whether the optional diagnostic mode is enabled."""
    try:
        return settings.getBool('diagnostics.enabled')
    except Exception:
        return False


def _sanitize_text(value: Any, *, limit: int) -> str:
    text = str(value or '')
    text = _CONTROL_RE.sub(' ', text)
    text = _URL_RE.sub('<url>', text)
    text = _SECRET_RE.sub(lambda match: f'{match.group(1)}=<hidden>', text)
    text = _PATH_RE.sub('<path>', text)
    text = _QUERY_LINE_RE.sub('queries: <hidden>', text)
    text = _QUICK_QUERY_RE.sub(r'\1 <hidden> \2', text)
    text = _QUERY_VALUE_RE.sub('queries=<hidden>', text)
    text = _PRIVATE_NAME_RE.sub(lambda match: f'{match.group(1)}=<hidden>', text)
    text = _PRIVATE_ID_RE.sub(lambda match: f'{match.group(1)}=<id>', text)
    return ' '.join(text.split())[:limit]


def sanitize_error(value: Any) -> str:
    """Return a compact error description stripped of private values."""
    return _sanitize_text(value, limit=180)


def sanitize_diagnostic(value: Any) -> str:
    """Return a detailed but privacy-safe diagnostic message."""
    return _sanitize_text(value, limit=700)


def log_event(component: str, message: Any, *, level: int = xbmc.LOGINFO) -> None:
    """Write one sanitized optional record to Kodi's standard log."""
    if not enabled():
        return
    try:
        safe_component = re.sub(
            r'[^A-Za-z0-9_.:-]+', '_', str(component or 'general')
        )[:60]
        safe_message = sanitize_diagnostic(message)
        if safe_message:
            xbmc.log(
                f'[KADR2-DIAG][{safe_component}] {safe_message}',
                level,
            )
    except Exception:
        # Diagnostics must never change normal add-on behaviour.
        pass


def _safe_provider_name(value: Any) -> str:
    return re.sub(r'[^A-Za-z0-9._ -]+', '_', str(value or 'unknown'))[:60]


def _status_counts(stats: Mapping[str, Mapping[str, Any]]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for stat in stats.values():
        status = str(stat.get('status') or 'unknown').lower()
        if status not in _ALLOWED_PROVIDER_STATUSES:
            status = 'unknown'
        counts[status] = counts.get(status, 0) + 1
    return counts


def record_source_search(
    stats: Mapping[str, Mapping[str, Any]],
    *,
    elapsed: float,
    raw_sources: int,
    visible_sources: int,
    total_providers: int,
    cancelled: bool,
) -> None:
    """Log and announce a sanitized source-search summary when enabled."""
    if not enabled():
        return

    safe_stats: dict[str, dict[str, Any]] = {}
    for name, stat in stats.items():
        status = str(stat.get('status') or 'unknown').lower()
        if status not in _ALLOWED_PROVIDER_STATUSES:
            status = 'unknown'
        safe_stats[_safe_provider_name(name)] = {
            'status': status,
            'elapsed': round(max(0.0, float(stat.get('elapsed') or 0)), 2),
            'count': max(0, int(stat.get('count') or 0)),
            'error': sanitize_error(stat.get('error')),
        }

    counts = _status_counts(safe_stats)
    done = sum(value for key, value in counts.items() if key not in {'running', 'timeout', 'cancelled'})
    elapsed = round(max(0.0, float(elapsed or 0)), 2)
    raw_sources = max(0, int(raw_sources or 0))
    visible_sources = max(0, int(visible_sources or 0))
    total_providers = max(0, int(total_providers or 0))

    log_event(
        'sources',
        f'completed; elapsed={elapsed:.2f}s; visible={visible_sources}; '
        f'raw={raw_sources}; providers={total_providers}; '
        f'cancelled={bool(cancelled)}; statuses={counts}',
    )
    for name, stat in sorted(
        safe_stats.items(),
        key=lambda item: (-float(item[1].get('elapsed') or 0), item[0].lower()),
    ):
        error = str(stat.get('error') or '')
        line = (
            f'status={stat["status"]}; '
            f'elapsed={float(stat["elapsed"]):.2f}s; results={int(stat["count"])}'
        )
        if error:
            line += f'; error={error}'
        log_event(
            f'provider:{name}',
            line,
            level=xbmc.LOGWARNING
            if error or stat['status'] in {'error', 'timeout'}
            else xbmc.LOGINFO,
        )

    timeouts = int(counts.get('timeout', 0))
    message = L(
        32970,
        'Sources: {sources} | providers: {done}/{total} | timeouts: {timeouts} | {seconds:.1f}s',
    ).format(
        sources=visible_sources,
        done=done,
        total=total_providers,
        timeouts=timeouts,
        seconds=elapsed,
    )
    control.infoDialog(message, heading=L(32964, 'Diagnostics'), time=5000)


def _local_port_open(port: int) -> bool:
    if not port:
        return False
    connection = None
    try:
        connection = HTTPConnection('127.0.0.1', int(port), timeout=0.5)
        connection.request('HEAD', '/ping')
        return connection.getresponse().status == 200
    except Exception:
        return False
    finally:
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass


def _telegram_service_running() -> bool:
    try:
        path = Path(control.dataPath) / 'telegram' / 'stream_service.json'
        data = json.loads(path.read_text(encoding='utf-8'))
        return _local_port_open(int(data.get('port') or 0))
    except Exception:
        return False


def _profile_writable() -> bool:
    """Test profile writes with a tiny temporary file and remove it immediately."""
    profile_dir = Path(control.dataPath)
    probe = profile_dir / '.kadrplus_write_test'
    try:
        profile_dir.mkdir(parents=True, exist_ok=True)
        probe.write_text('ok', encoding='ascii')
        return probe.read_text(encoding='ascii') == 'ok'
    except Exception:
        return False
    finally:
        try:
            probe.unlink(missing_ok=True)
        except Exception:
            pass


def _provider_counts() -> tuple[int, int]:
    try:
        provider_ids = sorted(
            name for name, definition in settings.definitions.items()
            if name.startswith('provider.') and definition.type == 'boolean'
        )
        return sum(1 for name in provider_ids if settings.getBool(name)), len(provider_ids)
    except Exception:
        return 0, 0


def system_report_text() -> str:
    """Build a credential-free report using local state and localhost checks."""
    if not enabled():
        return L(32968, 'Diagnostic mode is disabled.')

    addon = Addon()
    enabled_text = L(32974, 'Enabled')
    disabled_text = L(32975, 'Disabled')
    available_text = L(32976, 'Available')
    unavailable_text = L(32977, 'Unavailable')
    authorized_text = L(32978, 'Authorized')
    unauthorized_text = L(32979, 'Not authorized')
    yes_no = lambda value: enabled_text if value else disabled_text
    available = lambda value: available_text if value else unavailable_text
    authorized = lambda value: authorized_text if value else unauthorized_text

    try:
        service_running = bool(state.get(
            'url', module='service', mode=StateMode.DB, from_boot=True
        ))
    except Exception:
        service_running = False

    trakt_authorized = bool(settings.getString('trakt.token'))
    tmdb_authorized = bool(
        settings.getString('tmdb.sessionid') or settings.getString('tmdb.access_token')
    )
    telegram_enabled = settings.getBool('provider.telegram')
    telegram_session = (Path(control.dataPath) / 'telegram' / 'kadrplus_telegram.session').exists()
    telegram_streaming = _telegram_service_running()
    providers_enabled, providers_total = _provider_counts()
    profile_writable = _profile_writable()

    lines = [
        L(32971, 'Kadr+ system status'),
        '',
        f"Kadr+ 2.0: {addon.getAddonInfo('version')}",
        f"Kodi: {xbmc.getInfoLabel('System.BuildVersion') or '-'}",
        f"Kodi debug: {yes_no(xbmc.getCondVisibility('System.GetBool(debug.showloginfo)'))}",
        f"Python: {platform.python_version()} ({platform.system()} {platform.machine()})",
        '',
        f"{L(32989, 'Kodi service')}: {available(service_running)}",
        f"InputStream Adaptive: {available(xbmc.getCondVisibility('System.AddonIsEnabled(inputstream.adaptive)'))}",
        f"ResolveURL: {available(xbmc.getCondVisibility('System.AddonIsEnabled(script.module.resolveurl)'))}",
        f"Trakt: {authorized(trakt_authorized)}",
        f"TMDB: {authorized(tmdb_authorized)}",
        f"Telegram: {yes_no(telegram_enabled)}",
        f"Telegram session: {available(telegram_session)}",
        f"{L(32990, 'Telegram streaming service')}: {available(telegram_streaming)}",
        f"{L(32991, 'Profile storage')}: {L(32992, 'Writable') if profile_writable else L(32993, 'Read-only')}",
        f"{L(32984, 'Providers')}: {providers_enabled}/{providers_total}",
        '',
        L(32994, 'The report contains no tokens, passwords, cookies or source URLs.'),
    ]
    report = '\n'.join(lines)
    log_event(
        'system',
        f'version={addon.getAddonInfo("version")}; '
        f'service={service_running}; inputstream='
        f'{xbmc.getCondVisibility("System.AddonIsEnabled(inputstream.adaptive)")}; '
        f'trakt={trakt_authorized}; tmdb={tmdb_authorized}; '
        f'telegram={telegram_enabled}; tg_auth={telegram_session}; '
        f'tg_stream={telegram_streaming}; '
        f'providers={providers_enabled}/{providers_total}; '
        f'profile_writable={profile_writable}'
    )
    return report
