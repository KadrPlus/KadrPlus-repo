# -*- coding: utf-8 -*-
"""Persistent Telegram streaming service for Kadr+ 2.0.

Architecture used here is intentionally different from the old resolver proxy:
- Kodi's plugin invocation only registers a Telegram file and receives a local URL.
- This module runs from service.py, keeps one asyncio loop and one Telethon client.
- HTTP Range requests are served from a growing local cache; sparse tail/random
  probes are fetched by the same service client, not by new clients in request
  threads.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import os
import re
import socket
import sys
import time
import uuid
import threading
import queue
from urllib.parse import quote, unquote, urlparse

try:
    from ptw.debug import fflog, fflog_exc
except Exception:  # pragma: no cover - Kodi only
    def fflog(msg, level=1):
        try:
            print(msg)
        except Exception:
            pass
    def fflog_exc(level=1):
        import traceback
        traceback.print_exc()

try:
    from ptw.libraries import control
except Exception:  # pragma: no cover - unit checks outside Kodi
    control = None

try:
    from resources.lib import tg_ctypes_crypto
except Exception:
    tg_ctypes_crypto = None

_SERVICE = None
_SERVICE_LOCK = threading.RLock()

# Kodi 21/Android emits Player.OnSeek and the corresponding HTTP Range from
# different threads. A Range may lead OnSeek, but blocking every unknown Range
# for a one-second rendezvous is wrong: FFmpeg can open dozens of internal MP4
# ranges while resolving one seek. The 2026-08-14 device trace showed that exact
# one-second tax on every discontiguous range. Serve ranges immediately and keep
# only a non-blocking correlation window so a slightly-late OnSeek can promote
# the just-opened region in place.
_DIRECT_SEEK_PAIR_WINDOW = 1.5
_DIRECT_REGION_RECONNECT_SLOP = 2 * 1024 * 1024
_PROGRESSIVE_RANGE_SLOP = 2 * 1024 * 1024
# A direct/random FFmpeg range needs a fast first byte, not a second startup
# buffer. In the failing trace the first Range after a seek was an MP4/index
# range at 47.79 MiB while playback had jumped to 87.7%; forcing 10 MiB there
# spent 13.23 seconds buffering the wrong place. Fetch one legal 128 KiB Telegram
# block before exposing the 206, then continue with 512 KiB blocks and the shared
# three-RPC pipeline. The normal *initial playback* 10 MiB buffer is unchanged.
_DIRECT_READER_PRIME_BYTES = 128 * 1024
_DIRECT_FETCH_SEGMENT_BYTES = 512 * 1024
_DIRECT_READER_AHEAD_BYTES = _DIRECT_FETCH_SEGMENT_BYTES
# This is now only a safety deadline for the first direct block. Normal direct
# readiness should complete far sooner because it waits for 128 KiB, not 10 MiB.
_DIRECT_SEEK_READY_TIMEOUT = 14.0

def _token_tag(token):
    """Return a non-reversible correlation id instead of logging a stream token."""
    return hashlib.sha256(str(token).encode('utf-8')).hexdigest()[:8]


def _diag_stream(message):
    """Write Telegram transfer metrics only through Kadr+ diagnostics.

    The diagnostics module checks ``diagnostics.enabled`` itself and writes to
    Kodi's standard log. Keep the import lazy so diagnostics can never become a
    runtime dependency of playback.
    """
    try:
        from lib.ff import diagnostics
        diagnostics.log_event('telegram-stream', message)
    except Exception:
        # Diagnostics must never affect playback.
        pass


def _is_android():
    """Return True only on Kodi/Android; keep the proven Windows path intact."""
    try:
        return bool(control and control.condVisibility('System.Platform.Android'))
    except Exception:
        return bool(os.environ.get('ANDROID_ARGUMENT') or os.environ.get('ANDROID_ROOT'))


def _addon_path():
    try:
        return control.addonPath
    except Exception:
        # ``tg_stream_service.py`` lives in ``resources/lib``.  Two parent
        # levels are the add-on root; four escaped the package entirely and
        # made the bundled Telethon fallback impossible to locate.
        return os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))


def _data_path():
    try:
        path = control.dataPath
    except Exception:
        path = os.path.join('/tmp', 'kadrplus2')
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        pass
    return path


def _vendor_path():
    return os.path.join(_addon_path(), 'resources', 'lib', 'vendor', 'telegram')


def _ensure_vendor_path():
    vp = _vendor_path()
    if vp and vp not in sys.path:
        sys.path.insert(0, vp)


def _crypto_status():
    """Small production crypto status without old cryptg diagnostics."""
    info = {'telethon_backend': 'unknown'}
    try:
        _ensure_vendor_path()
        from telethon.crypto import aes
        info['telethon_backend'] = aes.crypto_backend()
    except Exception as exc:
        info['error'] = repr(exc)
    try:
        if tg_ctypes_crypto:
            st = tg_ctypes_crypto.status()
            info['tgcrypto_ctypes'] = bool(st.get('available'))
            info['tgcrypto_detail'] = st.get('detail') or ''
            info['tgcrypto_loaded_from'] = st.get('loaded_from') or ''
    except Exception as exc:
        info['tgcrypto_error'] = repr(exc)
    return info


def _cache_dir():
    path = os.path.join(_data_path(), 'telegram', 'service_stream_cache')
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        pass
    return path


def _cleanup_stream_cache(max_bytes=768 * 1024 * 1024, max_age=24 * 3600):
    """Keep Telegram stream cache bounded.

    The cache contains partial progressive downloads, not permanent movies.
    Older builds left those partial files behind after source tests/cancelled opens.
    """
    try:
        path = _cache_dir()
        now = time.time()
        files = []
        for name in os.listdir(path):
            fp = os.path.join(path, name)
            try:
                if not os.path.isfile(fp):
                    continue
                st = os.stat(fp)
                if max_age and now - st.st_mtime > max_age:
                    os.remove(fp)
                    continue
                files.append((st.st_mtime, st.st_size, fp))
            except Exception:
                pass
        total = sum(x[1] for x in files)
        if total > int(max_bytes or 0):
            for _mtime, _size, _fp in sorted(files):
                try:
                    os.remove(_fp)
                    total -= _size
                except Exception:
                    pass
                if total <= int(max_bytes or 0):
                    break
    except Exception:
        pass


def _state_dir():
    path = os.path.join(_data_path(), 'telegram')
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        pass
    return path


def status_path():
    return os.path.join(_state_dir(), 'stream_service.json')


def _safe_name(value, default='video.mp4'):
    try:
        name = os.path.basename(str(value or default).replace('\\', '/')) or default
        # Keep it header/URL friendly; the original name is not essential for Kodi.
        name = re.sub(r'[^A-Za-z0-9._ -]+', '_', name)
        name = re.sub(r'\s+', ' ', name).strip(' ._-') or default
        if '.' not in name:
            mime = ''
            name += '.mp4'
        return name[:160]
    except Exception:
        return default


def _content_disposition(filename):
    try:
        safe = _safe_name(filename)
        original = os.path.basename(str(filename or safe).replace('\\', '/')) or safe
        return "inline; filename=\"%s\"; filename*=UTF-8''%s" % (safe.replace('"', ''), quote(original.encode('utf-8')))
    except Exception:
        return 'inline; filename="video.mp4"'


def _read_status():
    try:
        with open(status_path(), 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_status(port):
    try:
        data = {'port': int(port or 0), 'pid': os.getpid(), 'time': int(time.time())}
        with open(status_path(), 'w', encoding='utf-8') as fh:
            json.dump(data, fh, separators=(',', ':'))
    except Exception:
        pass


def _json_response(handler, status, data):
    raw = json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    handler.send_response(status)
    handler.send_header('Content-Type', 'application/json; charset=utf-8')
    handler.send_header('Content-Length', str(len(raw)))
    handler.send_header('Connection', 'close')
    handler.end_headers()
    if getattr(handler, 'command', 'GET') != 'HEAD':
        handler.wfile.write(raw)


def _write_stream_body(handler, data, *, is_active=None, mode='stream'):
    """Send one HTTP body block without turning Kodi backpressure into EOF.

    Kodi deliberately stops reading localhost while its memory cache is full.
    A single blocking ``wfile.write`` then inherits the handler socket timeout;
    treating that timeout as a closed client truncates a response whose declared
    Content-Length is much larger, so CFileCache reports an artificial EOF.

    Use partial ``socket.send`` calls instead: a short timeout is only a chance
    to re-check Stop/seek cancellation.  No bytes are replayed after a timeout,
    and a real disconnect still terminates the reader promptly.
    """
    try:
        view = memoryview(data)
    except TypeError:
        view = memoryview(bytes(data or b''))
    if not view:
        return True

    connection = getattr(handler, 'connection', None)
    if connection is None:
        return False

    def active():
        if is_active is None:
            return True
        try:
            return bool(is_active())
        except Exception:
            return False

    try:
        # BaseHTTPRequestHandler uses an unbuffered writer, but flushing here
        # keeps this helper correct if that implementation detail ever changes.
        handler.wfile.flush()
    except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError):
        return False

    try:
        previous_timeout = connection.gettimeout()
    except Exception:
        previous_timeout = None

    sent = 0
    waiting_since = None
    waiting_logged = False
    try:
        try:
            connection.settimeout(0.50)
        except Exception:
            pass
        while sent < len(view):
            if not active():
                if waiting_since is not None:
                    waited = time.monotonic() - waiting_since
                    if waiting_logged or waited >= 2.0:
                        _diag_stream(
                            'stage=http-backpressure; mode=%s; result=cancelled; waited_s=%.2f' % (
                                mode, waited,
                            )
                        )
                return False
            try:
                written = connection.send(view[sent:])
                if not written:
                    return False
                sent += int(written)
                if waiting_since is not None:
                    waited = time.monotonic() - waiting_since
                    if waiting_logged or waited >= 2.0:
                        _diag_stream(
                            'stage=http-backpressure; mode=%s; result=recovered; waited_s=%.2f' % (
                                mode, waited,
                            )
                        )
                    waiting_since = None
                    waiting_logged = False
            except socket.timeout:
                if waiting_since is None:
                    waiting_since = time.monotonic()
                waited = time.monotonic() - waiting_since
                if waited >= 6.0 and not waiting_logged:
                    _diag_stream(
                        'stage=http-backpressure; mode=%s; result=waiting; waited_s=%.2f' % (
                            mode, waited,
                        )
                    )
                    waiting_logged = True
                continue
            except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError):
                return False
        return True
    finally:
        try:
            connection.settimeout(previous_timeout)
        except Exception:
            pass


def _parse_range(header, total):
    try:
        total = int(total or 0)
        if total <= 0:
            return 0, 0, False
        m = re.match(r'bytes=(\d*)-(\d*)', header or '')
        if not m:
            return 0, total - 1, False
        if m.group(1) == '' and m.group(2):
            n = int(m.group(2))
            start = max(0, total - n)
            end = total - 1
        else:
            start = int(m.group(1) or 0)
            end = int(m.group(2) or (total - 1))
        start = max(0, min(start, total - 1))
        end = max(start, min(end, total - 1))
        return start, end, True
    except Exception:
        total = int(total or 0)
        return 0, max(0, total - 1), False


def _prefer_progressive_range(start, cached, direct_active=False, allow_slop=True):
    """Keep a near-frontier refill on the existing progressive producer.

    In the Android trace the request at 49.47 MiB began while the progressive
    cache was roughly 48.5 MiB. It was ordinary sequential refill, but it waited
    for and consumed the Player.OnSeek marker, so the real seek target never got
    its generation. A two-MiB frontier is the same already-proven reconnect slop
    used by shared-region readers and is only active before a direct region owns
    Telegram bandwidth.
    """
    start = max(0, int(start or 0))
    cached = max(0, int(cached or 0))
    slop = _PROGRESSIVE_RANGE_SLOP if allow_slop and not direct_active else 0
    return start < max(16 * 1024 * 1024, cached + slop)


def _round_1024(value, up=False):
    value = int(value or 0)
    if up:
        return ((value + 1023) // 1024) * 1024
    return (value // 1024) * 1024


class _DirectRegion:
    """One shared post-seek cache owned by a playback generation.

    HTTP reconnects are readers, never download owners.  The Telegram producer
    survives a closed Kodi socket and exposes one contiguous region to every
    Range request until a real Player.OnSeek creates a new generation.
    """
    def __init__(self, job, generation, gate_event, start, end, reason='', prebuffer_target=0):
        self.job = job
        self.generation = int(generation or 0)
        self.gate_event = gate_event
        self.start = int(start or 0)
        self.end = int(end or 0)
        self.reason = str(reason or '')
        # Only the real Player.OnSeek leader owns a large readiness cushion.
        # Ordinary FFmpeg Range readers keep the lightweight one-segment prime.
        self.prebuffer_target = max(0, int(prebuffer_target or 0))
        # A promoted seek can land inside an existing region. Anchor its
        # readiness cushion at the actual seek Range, not at region.start.
        self.prebuffer_from = self.start
        self.created_at = time.monotonic()
        # Several discontiguous FFmpeg readers can be valid inside one player
        # seek (for example the real 56.88 -> 94.82 MiB sequence).  Give every
        # cache its own file; a generation-only name made the second reader
        # truncate bytes still owned by the first one.
        self.path = '%s.direct.%s.%s' % (
            job.cache_path, self.generation, uuid.uuid4().hex[:8],
        )
        self.lock = threading.RLock()
        self.event = threading.Event()
        self.stop = threading.Event()
        self.retired = threading.Event()
        self.cached_end = self.start
        self.done = False
        self.error = ''
        self.future = None
        self.readers = {}
        self.reader_seq = 0
        # Monotonic ownership stamp. Only the HTTP response that most recently
        # consumed (or explicitly waited for) bytes owns the three Telegram
        # request lanes. Backpressured/stale responses keep their cached bytes,
        # but cannot dilute the active playback range to one slow RPC.
        self.focus_seq = 0
        try:
            with open(self.path, 'wb'):
                pass
        except Exception:
            pass

    def request_stop(self):
        self.stop.set()
        self.event.set()
        try:
            if self.future is not None and not self.future.done():
                self.future.cancel()
        except Exception:
            pass

    def retire(self):
        """Cancel Telegram work but let an existing Kodi reader close naturally.

        Closing the previous response from Player.OnSeek made cURL reconnect the
        old byte range and prevented Kodi from opening the real seek target.
        Cancelling only the producer future stops its network work immediately
        without setting ``stop`` on the cache/HTTP response. Kodi can therefore
        abandon the old socket on its own, while all Telegram capacity moves to
        the new seek target.
        """
        self.retired.set()
        self.event.set()
        try:
            if self.future is not None and not self.future.done():
                self.future.cancel()
        except Exception:
            pass
        with self.lock:
            no_readers = not self.readers
        if no_readers:
            self.request_stop()

    def is_current(self):
        return bool(
            not self.stop.is_set()
            and not self.job.stop.is_set()
        )

    def accepts(self, offset, *, slop=_DIRECT_REGION_RECONNECT_SLOP):
        """Return whether ``offset`` is cached or near an active reader.

        Kodi can open the next Range before the current HTTP reader has moved
        the shared cache frontier. Treating that harmless overlap as a new seek
        rotated the region even though no Player.OnSeek had occurred.
        """
        offset = int(offset or 0)
        with self.lock:
            cached_end = int(self.cached_end or self.start)
            reader_end = max(self.readers.values(), default=self.start)
            active_end = max(cached_end, reader_end)
        return bool(
            self.is_current()
            and not self.retired.is_set()
            and self.start <= offset <= min(self.end, active_end + max(0, int(slop)))
        )

    def append(self, offset, data):
        data = bytes(data or b'')
        if not data or not self.is_current() or self.retired.is_set():
            return 0
        offset = int(offset or 0)
        with self.lock:
            if self.retired.is_set():
                return 0
            if offset < self.cached_end:
                overlap = self.cached_end - offset
                if overlap >= len(data):
                    return 0
                data = data[overlap:]
                offset = self.cached_end
            if offset != self.cached_end:
                raise RuntimeError('non-contiguous direct region write')
            with open(self.path, 'r+b') as fh:
                fh.seek(offset - self.start)
                fh.write(data)
                fh.flush()
            self.cached_end = offset + len(data)
        self.event.set()
        return len(data)

    def read(self, offset, size):
        try:
            offset = int(offset or 0)
            with self.lock:
                available = self.cached_end - offset
            if offset < self.start or available <= 0:
                return b''
            size = min(int(size or 0), available)
            if size <= 0:
                return b''
            with open(self.path, 'rb') as fh:
                fh.seek(offset - self.start)
                return fh.read(size)
        except Exception:
            return b''

    def wait_until(self, absolute_end, timeout):
        deadline = time.time() + max(0.0, float(timeout or 0.0))
        absolute_end = min(int(absolute_end or self.start), self.end + 1)
        while time.time() < deadline and self.is_current():
            with self.lock:
                if self.cached_end >= absolute_end:
                    return True
                if self.done or self.error:
                    return self.cached_end > self.start
            self.event.wait(0.20)
            self.event.clear()
        with self.lock:
            return self.cached_end >= absolute_end

    def attach_reader(self, offset):
        with self.lock:
            self.reader_seq += 1
            reader_id = self.reader_seq
            self.readers[reader_id] = int(offset or self.start)
        self.job.focus_direct_region(self)
        return reader_id

    def update_reader(self, reader_id, offset):
        needs_bytes = False
        with self.lock:
            if reader_id in self.readers:
                self.readers[reader_id] = int(offset or 0)
                needs_bytes = self.cached_end - int(offset or 0) <= _DIRECT_READER_AHEAD_BYTES
        # Refresh ownership only when this socket is actually consuming its
        # cushion. A socket blocked by Kodi backpressure never reaches here and
        # cannot steal bandwidth from the response the player is waiting for.
        if needs_bytes:
            self.job.focus_direct_region(self)

    def detach_reader(self, reader_id):
        with self.lock:
            self.readers.pop(reader_id, None)
            stop_retired = self.retired.is_set() and not self.readers
        self.job.wake_direct_regions()
        if stop_retired:
            self.request_stop()

    def download_ceiling(self, max_ahead):
        """Bound normal prefetch, but honour the real seek readiness gate.

        A normal FFmpeg reader is allowed only a small cushion beyond bytes that
        Kodi is actually consuming. The initial playback startup cushion belongs
        to the progressive cache; direct post-seek ranges intentionally stay
        lightweight because FFmpeg may probe several discontiguous MP4 areas
        before it reaches the actual media position.
        """
        with self.lock:
            if self.retired.is_set():
                return self.cached_end
            if not self.readers:
                return self.cached_end
            consumed = max(self.readers.values())
            ceiling = consumed + max(1, int(max_ahead or 0))
            if (self.prebuffer_target > 0
                    and self.gate_event is not None
                    and not self.gate_event.is_set()):
                ceiling = max(ceiling, self.prebuffer_from + self.prebuffer_target)
        return min(self.end + 1, ceiling)


class _StreamJob:
    def __init__(self, service, spec):
        self.service = service
        self.spec = spec or {}
        self.token = self.spec.get('token') or uuid.uuid4().hex
        self.spec['token'] = self.token
        self.total = int(self.spec.get('size') or 0)
        self.mime = self.spec.get('mime') or 'video/mp4'
        self.filename = self.spec.get('filename') or 'video.mp4'
        self.created = time.time()
        self.last_read = time.time()
        self.lock = threading.RLock()
        self.event = threading.Event()
        self.stop = threading.Event()
        self.done = False
        # error is diagnostic information about the last failed fetch. It must
        # not by itself terminate HTTP readers: transient Telegram timeouts are
        # retried by the progressive downloader. 'failed' is terminal.
        self.error = ''
        self.failed = False
        self.range_error = ''
        self.cached = 0
        # Timeout budget of the currently active progressive fetch.  HTTP
        # readers must never declare the cache stalled before the downloader's
        # own future has reached its deadline.
        self.fetch_result_timeout = 0.0
        self.cache_path = os.path.join(_cache_dir(), '%s_%s' % (self.token[:16], _safe_name(self.filename)))
        self.sparse = {}  # offset -> bytes for tail/random probes
        self.sparse_lock = threading.RLock()
        # While Kodi is reading a post-seek direct range, pause the background
        # progressive downloader so it does not compete with the active stream.
        # Kodi can open overlapping speculative Range connections; use a counter
        # so one older request cannot clear the flag while another is still live.
        self.direct_active = threading.Event()
        self.direct_lock = threading.RLock()
        self.direct_count = 0
        # HTTP-reader activity is separate from producer lifetime. Shared direct
        # region producers can remain parked with zero readers for reuse; using
        # their lifetime to pause the prefix downloader would stop progressive
        # caching forever after the first random probe.
        self.direct_reader_active = threading.Event()
        self.direct_reader_lock = threading.RLock()
        self.direct_reader_count = 0
        # A real seek permanently retires the sequential prefix producer. The
        # old localhost response may remain open until Kodi abandons it, but no
        # Telegram request from the previous playback position is allowed to
        # resume after the new range becomes temporarily idle.
        self.progressive_retired = threading.Event()
        # One shared async semaphore is created lazily on the service event loop.
        # Kodi/FFmpeg may open several overlapping Range requests after a seek;
        # each used to create its own 3-request Telegram pipeline, multiplying the
        # real in-flight count.  All direct/sparse ranges of one movie now share
        # one three-request ceiling.
        self.direct_fetch_semaphore = None
        # Direct ranges share one three-request Telegram ceiling.  They are
        # invalidated by *real player seek generation*, not by every HTTP Range
        # reconnect.  FFmpeg legitimately opens follow-up open-ended ranges while
        # reading one region; treating each reconnect as a new owner caused an
        # owner storm (50 ranges in the device log) and starved playback.
        # Buffer gating for Android direct/open-ended Range streams.  The first
        # direct range after registration and the first one after a real Kodi
        # Player.OnSeek should build the configured Telegram startup cushion.
        # Subsequent neighbouring HTTP range reconnects must NOT rebuild that
        # cushion; doing so caused the repeated 4 MiB pause/stall cycle seen in
        # the device log.
        self.direct_prebuffer_lock = threading.RLock()
        self.direct_prebuffer_generation = 0
        self.direct_prebuffer_event = threading.Event()
        self.direct_prebuffer_event.set()
        self.direct_prebuffer_leader = False
        self.direct_prebuffer_reason = ''
        # Player.OnSeek and its target HTTP Range have no fixed ordering on
        # Kodi/Android. The event pairs those two facts without invalidating the
        # response Kodi is still using to perform the seek.
        self.direct_seek_pending = False
        self.direct_seek_pending_at = 0.0
        self.direct_seek_reason = ''
        self.direct_seek_event = threading.Event()
        self.direct_unpaired_range_at = 0.0
        self.direct_unpaired_range_start = -1
        self.direct_range_open_lock = threading.RLock()
        self.direct_region_lock = threading.RLock()
        self.direct_region = None
        # ``direct_region`` remains the most recently selected region for
        # compatibility.  The list is authoritative because FFmpeg can read two
        # distant MP4 areas in an alternating pattern during one seek.
        self.direct_regions = []
        self.direct_region_paths = set()
        self.direct_focus_seq = 0
        self.connections_lock = threading.RLock()
        self.active_connections = set()
        self.start_thread = None
        if _is_android():
            self.request_direct_prebuffer('initial-range')

    def log(self, msg):
        try:
            fflog('[tg-service] [%s] %s' % (_token_tag(self.token), msg), 1)
        except Exception:
            pass

    def cleanup_cache_file(self):
        """Remove this job's partial cache when no worker is using it."""
        try:
            paths = {self.cache_path, *tuple(self.direct_region_paths)}
            for path in paths:
                if path and os.path.exists(path):
                    os.remove(path)
            return not any(path and os.path.exists(path) for path in paths)
        except Exception:
            # Windows can briefly keep an HTTP reader handle open.  The service
            # retirement worker retries later instead of deleting an active file.
            return False

    def start(self):
        if self.start_thread and self.start_thread.is_alive():
            return
        self.start_thread = threading.Thread(target=self._run_download, name='KadrPlusTGServiceDownload', daemon=True)
        self.start_thread.start()

    def request_stop(self):
        """Signal every layer of this job without waiting for Kodi OnStop."""
        self.stop.set()
        self.progressive_retired.set()
        self.event.set()
        self.direct_seek_event.set()
        with self.direct_region_lock:
            regions = list(self.direct_regions)
            if self.direct_region is not None and self.direct_region not in regions:
                regions.append(self.direct_region)
        for region in regions:
            region.request_stop()
        # Closing localhost sockets is the only reliable way to wake Kodi's
        # CFileCache immediately; an Event cannot interrupt a blocked socket write.
        with self.connections_lock:
            connections = tuple(self.active_connections)
        for connection in connections:
            try:
                connection.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                connection.close()
            except Exception:
                pass

    def register_connection(self, connection):
        with self.connections_lock:
            self.active_connections.add(connection)

    def unregister_connection(self, connection):
        with self.connections_lock:
            self.active_connections.discard(connection)

    def active_connection_count(self):
        with self.connections_lock:
            return len(self.active_connections)

    def direct_begin(self):
        with self.direct_lock:
            self.direct_count += 1
            self.direct_active.set()
            return self.direct_count

    def direct_end(self):
        with self.direct_lock:
            self.direct_count = max(0, self.direct_count - 1)
            if not self.direct_count:
                self.direct_active.clear()
            return self.direct_count

    def direct_reader_begin(self):
        with self.direct_reader_lock:
            self.direct_reader_count += 1
            self.direct_reader_active.set()
            return self.direct_reader_count

    def direct_reader_end(self):
        with self.direct_reader_lock:
            self.direct_reader_count = max(0, self.direct_reader_count - 1)
            if not self.direct_reader_count:
                self.direct_reader_active.clear()
                # Wake the progressive worker so it can resume immediately after
                # the last random/direct HTTP reader disappears.
                self.event.set()
            return self.direct_reader_count

    def wake_direct_regions(self):
        """Wake every producer after reader demand or ownership changes."""
        for region in self.direct_regions_snapshot():
            region.event.set()

    def focus_direct_region(self, region):
        """Record which HTTP reader most recently needed more bytes.

        Focus is a priority hint, not exclusive ownership.  FFmpeg can require
        two discontiguous MP4 ranges during one seek; starving either one makes
        cURL time out and turns a healthy stream into a false EOF.
        """
        if region is None or region.retired.is_set() or not region.is_current():
            return 0
        with self.direct_region_lock:
            self.direct_focus_seq += 1
            region.focus_seq = self.direct_focus_seq
            self.direct_region = region
            focus_seq = region.focus_seq
        self.wake_direct_regions()
        return focus_seq

    def direct_region_lane_quota(self, region):
        """Share the three Telegram RPC lanes without starving a required Range.

        While the real Player.OnSeek leader obtains its first legal direct block
        it gets all three lanes; parallel FFmpeg probes wait behind that short gate.
        Afterwards only regions whose readers are close to exhausting cached data
        compete. One hungry region gets 3 lanes, two get 2+1, and three get 1 each.
        This preserves throughput for the active reader without the former 3+0
        starvation that produced ``FillBuffer Timeout`` in the device log.
        """
        generation = int(self.direct_prebuffer_generation or 0)
        regions = [
            candidate for candidate in self.direct_regions_snapshot()
            if (candidate.generation == generation
                and not candidate.retired.is_set()
                and candidate.is_current())
        ]

        # A real seek is transactional: first create one useful cushion at the
        # target. Followers remain attached, but must not dilute those three RPCs
        # before the gate opens.
        gate = self.direct_prebuffer_event
        if gate is not None and not gate.is_set():
            primary = next((
                candidate for candidate in regions
                if candidate.gate_event is gate and candidate.prebuffer_target > 0
            ), None)
            if primary is not None:
                return 3 if primary is region else 0

        candidates = []
        for candidate in regions:
            with candidate.lock:
                if not candidate.readers or candidate.done or candidate.error:
                    continue
                consumed = max(candidate.readers.values())
                ahead = max(0, int(candidate.cached_end or candidate.start) - int(consumed or 0))
                if ahead <= _DIRECT_READER_AHEAD_BYTES:
                    candidates.append((candidate, ahead))
        if not candidates:
            return 0

        # The latest reader that actually ran out of cache is the primary demand.
        # Smaller ``ahead`` breaks ties deterministically without oscillating on
        # mere socket lifetime.
        candidates.sort(
            key=lambda item: (int(item[0].focus_seq or 0), -int(item[1] or 0)),
            reverse=True,
        )
        ordered = [candidate for candidate, _ahead in candidates]
        if region not in ordered:
            return 0
        if len(ordered) == 1:
            return 3
        if len(ordered) == 2:
            return 2 if ordered[0] is region else 1
        return 1 if region in ordered[:3] else 0

    def retire_progressive(self, reason='direct-range'):
        """Permanently cancel prefix fetching without closing its HTTP socket."""
        first = not self.progressive_retired.is_set()
        self.progressive_retired.set()
        self.event.set()
        if first:
            _diag_stream('stage=progressive-retire; reason=%s' % str(reason or ''))
        return first

    def retire_direct_regions(self, *, except_region=None):
        """Cancel every obsolete direct producer, preserving reader sockets."""
        retired = 0
        for region in self.direct_regions_snapshot():
            if region is except_region or region.retired.is_set():
                continue
            region.retire()
            retired += 1
        self.wake_direct_regions()
        return retired

    def cancel_direct_producers_for_pending_seek(self):
        """Stop old Telegram RPCs before the target Range identifies itself.

        Keep regions matchable for a neighbouring cURL reconnect so that such a
        reconnect cannot consume the pending OnSeek marker. The producer future
        is still cancelled immediately; once the non-contiguous target arrives,
        ``request_direct_prebuffer`` retires these caches definitively.
        """
        cancelled = 0
        for region in self.current_direct_regions():
            try:
                if region.future is not None and not region.future.done():
                    region.future.cancel()
                    cancelled += 1
            except Exception:
                pass
            region.event.set()
        return cancelled

    def request_direct_prebuffer(self, reason='seek'):
        """Arm one region-level direct-range prebuffer on Android.

        A new Event/generation prevents an old HTTP range from releasing a gate
        that belongs to a newer user seek.  Only one request becomes the leader;
        concurrent Kodi range probes wait for that gate instead of each building
        their own cushion and competing for Telegram bandwidth.
        """
        if not _is_android():
            return 0
        old_regions = []
        with self.direct_prebuffer_lock:
            self.direct_prebuffer_generation += 1
            self.direct_prebuffer_event = threading.Event()
            self.direct_prebuffer_leader = False
            self.direct_prebuffer_reason = str(reason or 'seek')
            self.direct_unpaired_range_at = 0.0
            self.direct_unpaired_range_start = -1
            generation = self.direct_prebuffer_generation
        with self.direct_region_lock:
            old_regions = list(self.direct_regions)
            if self.direct_region is not None and self.direct_region not in old_regions:
                old_regions.append(self.direct_region)
            self.direct_region = None
        for old_region in old_regions:
            if old_region.retired.is_set():
                continue
            # Keep the old HTTP response valid until Kodi closes it itself. Its
            # producer pauses, so all Telegram capacity is available to the new
            # target, but cURL does not mistake our generation change for EOF.
            old_region.retire()
        return generation

    def direct_regions_snapshot(self):
        """Return all known regions, including a legacy directly assigned one."""
        with self.direct_region_lock:
            regions = list(self.direct_regions)
            if self.direct_region is not None and self.direct_region not in regions:
                regions.append(self.direct_region)
            return regions

    def matching_direct_region(self, offset, generation=None):
        """Find the nearest cache that can serve ``offset`` immediately."""
        offset = int(offset or 0)
        if generation is None:
            generation = int(self.direct_prebuffer_generation or 0)
        matches = [
            region for region in self.direct_regions_snapshot()
            if region.generation == int(generation or 0)
            and not region.error
            and region.accepts(offset)
        ]
        if not matches:
            return None
        # Prefer the closest preceding region if two short reconnect windows
        # overlap.  This minimizes disk distance and cannot jump over a hole.
        return max(matches, key=lambda region: region.start)

    def current_direct_regions(self, generation=None):
        """Return live, non-retired regions of the requested player generation."""
        if generation is None:
            generation = int(self.direct_prebuffer_generation or 0)
        return [
            region for region in self.direct_regions_snapshot()
            if region.generation == int(generation or 0)
            and region.is_current()
            and not region.retired.is_set()
        ]

    def reached_media_eof(self):
        """Whether this job fetched the physical end of the Telegram file."""
        total = int(self.total or 0)
        if total <= 0:
            return False
        with self.lock:
            if int(self.cached or 0) >= total:
                return True
        generation = int(self.direct_prebuffer_generation or 0)
        # A fast orphan-stop may set job.stop shortly before Player.OnStop is
        # announced.  EOF is immutable, so inspect the latest generation even
        # after its sockets have been closed.
        for region in self.direct_regions_snapshot():
            if region.generation != generation:
                continue
            with region.lock:
                if region.end >= total - 1 and region.cached_end >= total:
                    return True
        return False

    def maybe_finish_direct_prebuffer_for_region(self, region, source='producer'):
        """Release a promoted seek gate when its region has enough bytes.

        A Range can arrive before Player.OnSeek. In that ordering the HTTP handler
        keeps local references to the *old* generation/gate, while
        promote_direct_region_for_seek() moves the live region to a new generation
        and a new gate. The old handler can never finish that new gate itself.

        Let the region/producer finish the CURRENT gate as soon as the configured
        first-byte cushion is physically present. This prevents one promoted Range
        from monopolising all three Telegram RPC lanes and starving FFmpeg's next
        MP4/index Range.
        """
        if region is None:
            return False
        try:
            with region.lock:
                generation = int(region.generation or 0)
                gate_event = region.gate_event
                target = max(0, int(region.prebuffer_target or 0))
                start = int(region.prebuffer_from or region.start)
                cached_end = int(region.cached_end or region.start)
            if gate_event is None or gate_event.is_set() or target <= 0:
                return False
            if cached_end - start < target:
                return False
            with self.direct_prebuffer_lock:
                if (generation != int(self.direct_prebuffer_generation or 0)
                        or gate_event is not self.direct_prebuffer_event
                        or gate_event.is_set()):
                    return False
            self.finish_direct_prebuffer(generation, gate_event)
            _diag_stream(
                'stage=direct-seek-gate-release; generation=%s; source=%s; '
                'start_mib=%.2f; buffered_mib=%.2f; target_mib=%.2f' % (
                    generation, str(source or ''),
                    float(start) / (1024.0 * 1024.0),
                    float(max(0, cached_end - start)) / (1024.0 * 1024.0),
                    float(target) / (1024.0 * 1024.0),
                )
            )
            return True
        except Exception:
            return False

    def promote_direct_region_for_seek(self, region, reason='player-seek', seek_start=None):
        """Promote an already-open Range into the one real seek generation.

        ``Player.OnSeek`` and its HTTP Range can arrive in either order.  If the
        target Range already belongs to an existing cache, reusing that cache is
        correct, but the *transaction* still has to change: a fresh gate must be
        armed and the configured seek cushion must be measured from the new Range
        offset.  Reusing the old (already-set) gate was the reason a promoted seek
        resumed after only 512 KiB and could stall immediately afterwards.
        """
        if region is None or region.retired.is_set() or not region.is_current():
            return 0
        reason = str(reason or 'player-seek')
        seek_start = int(region.start if seek_start is None else seek_start)
        seek_start = max(int(region.start), min(seek_start, int(region.end)))
        new_gate = threading.Event()
        seek_target = self.direct_reader_prime_bytes('leader', reason)
        with self.direct_prebuffer_lock:
            self.direct_prebuffer_generation += 1
            generation = self.direct_prebuffer_generation
            self.direct_prebuffer_event = new_gate
            # This method promotes a Range that is ALREADY open. Its HTTP
            # handler has therefore already passed claim_direct_prebuffer() under
            # the previous generation and cannot claim the new gate afterwards.
            # Mark the promoted region as the current leader here; otherwise the
            # next FFmpeg Range can incorrectly become leader while the promoted
            # handler still holds stale generation/gate locals.
            self.direct_prebuffer_leader = True
            self.direct_prebuffer_reason = reason
            self.direct_seek_pending = False
            self.direct_seek_pending_at = 0.0
            self.direct_seek_reason = ''
            self.direct_seek_event.clear()
            self.direct_unpaired_range_at = 0.0
            self.direct_unpaired_range_start = -1
            region.generation = generation
            region.gate_event = new_gate
            region.reason = reason
            region.prebuffer_from = seek_start
            region.prebuffer_target = max(int(region.prebuffer_target or 0), int(seek_target or 0))
        with self.direct_region_lock:
            self.direct_region = region
        self.retire_direct_regions(except_region=region)
        self.focus_direct_region(region)
        region.event.set()
        # If this Range was already buffered far enough before OnSeek arrived,
        # the new generation gate can be released immediately. Otherwise the
        # producer releases it after append() reaches the 128 KiB target.
        self.maybe_finish_direct_prebuffer_for_region(region, source='promotion')
        _diag_stream(
            'stage=direct-seek-promote; generation=%s; start_mib=%.2f; '
            'cached_mib=%.2f; target_mib=%.2f' % (
                generation,
                float(seek_start) / (1024.0 * 1024.0),
                float(max(0, int(region.cached_end or seek_start) - seek_start)) / (1024.0 * 1024.0),
                float(seek_target or 0) / (1024.0 * 1024.0),
            )
        )
        return generation

    def promote_newly_opened_pending_target(self, region):
        """Close the tiny Range-created/OnSeek-recorded ordering gap."""
        with self.direct_prebuffer_lock:
            if (not self.direct_seek_pending
                    or int(self.direct_unpaired_range_start) != int(region.start)):
                return 0
            reason = str(self.direct_seek_reason or 'player-seek')
        return self.promote_direct_region_for_seek(region, reason, seek_start=region.start)

    def mark_direct_seek(self, reason='player-seek', target_progress=None):
        """Record diagnostics only; HTTP Range is the sole seek authority.

        Kodi/FFmpeg owns time-to-byte mapping for MP4. Kadr+ must never shorten,
        remap or guess a byte range from playback percentage. The previous 1 MiB
        probe experiment changed the Content-Length of an open-ended resume
        response and therefore changed Kodi's perceived file length.
        """
        if not _is_android():
            return 'ignored', int(self.direct_prebuffer_generation or 0)
        self.event.set()
        return 'http-range-authoritative', int(self.direct_prebuffer_generation or 0)

    def _take_pending_direct_seek(self):
        """Atomically consume one seek notification.

        Kodi may report ``Player.OnSeek`` several seconds before FFmpeg opens
        the target HTTP Range (the Android trace shows 2.6 s).  The marker is
        tied to this stream job and is replaced by the next seek, so expiring it
        on a short wall-clock timer can only turn a valid seek into a false EOF.
        """
        with self.direct_prebuffer_lock:
            if not self.direct_seek_pending:
                return '', False
            reason = str(self.direct_seek_reason or 'player-seek')
            self.direct_seek_pending = False
            self.direct_seek_pending_at = 0.0
            self.direct_seek_reason = ''
            self.direct_seek_event.clear()
            return reason, False

    def synchronize_direct_range(self, start, timeout=0.0):
        """Pair a non-contiguous Range with Player.OnSeek without blocking.

        OnSeek-before-Range is deterministic: the pending notification is
        consumed by the next direct Range.  For Range-before-OnSeek we *do not*
        sleep here. FFmpeg opens many legitimate non-contiguous MP4 ranges during
        one seek and the old one-second rendezvous was added to every one of
        them. Instead the Range starts immediately and its offset/timestamp is
        remembered; a slightly-late OnSeek promotes that already-open region via
        ``mark_direct_seek`` / ``promote_newly_opened_pending_target``.
        """
        if not _is_android():
            return 'open', 0, 0.0, ''
        start = int(start or 0)

        region = self.matching_direct_region(start)

        # OnSeek-before-Range. The first new direct Range is part of that seek.
        reason, _stale = self._take_pending_direct_seek()
        if reason:
            if region is not None:
                generation = self.promote_direct_region_for_seek(
                    region, reason, seek_start=start,
                )
                return 'seek-reuse', generation, 0.0, reason
            generation = self.request_direct_prebuffer(reason)
            return 'seek', generation, 0.0, reason

        if region is not None:
            return 'reuse', int(region.generation or 0), 0.0, ''
        if self.stop.is_set():
            return 'stopped', int(self.direct_prebuffer_generation or 0), 0.0, ''

        generation = int(self.direct_prebuffer_generation or 0)
        # Non-blocking Range-before-OnSeek correlation. The region is created by
        # the caller immediately after this method returns. If OnSeek lands in
        # that tiny gap, promote_newly_opened_pending_target() closes the race.
        with self.direct_prebuffer_lock:
            self.direct_unpaired_range_at = time.monotonic()
            self.direct_unpaired_range_start = start

        if not self.current_direct_regions(generation):
            return 'initial', generation, 0.0, ''
        return 'parallel-range', generation, 0.0, 'ffmpeg-range'

    def claim_direct_prebuffer(self):
        if not _is_android():
            return 'open', 0, None, ''
        with self.direct_prebuffer_lock:
            generation = int(self.direct_prebuffer_generation or 0)
            event = self.direct_prebuffer_event
            reason = self.direct_prebuffer_reason
            if event.is_set():
                return 'open', generation, event, reason
            if not self.direct_prebuffer_leader:
                self.direct_prebuffer_leader = True
                return 'leader', generation, event, reason
            return 'follower', generation, event, reason

    def finish_direct_prebuffer(self, generation, event):
        try:
            if event is not None:
                event.set()
        finally:
            with self.direct_prebuffer_lock:
                if (generation == self.direct_prebuffer_generation
                        and event is self.direct_prebuffer_event):
                    self.direct_prebuffer_leader = False
            self.wake_direct_regions()

    def direct_prebuffer_is_current(self, generation, event):
        with self.direct_prebuffer_lock:
            return bool(generation == self.direct_prebuffer_generation
                        and event is self.direct_prebuffer_event)

    def direct_reader_prime_bytes(self, gate_role, reason):
        """Return the first-byte readiness target for Android direct ranges.

        The initial playback buffer is built by the progressive downloader and
        remains controlled by ``startup_buffer_mb``. A post-seek HTTP Range is
        different: the first Range can be MP4/index metadata rather than the
        eventual media byte position, so rebuilding the full startup buffer there
        blocks FFmpeg from discovering the real target. Every direct Range now
        waits only for one legal 128 KiB first block and then streams continuously.
        """
        return _DIRECT_READER_PRIME_BYTES

    def direct_reader_ahead_bytes(self):
        """Return the one-lane look-ahead unit for the active HTTP reader.

        ``startup_buffer_mb`` still controls the initial progressive startup
        cache. The direct owner multiplies this unit by its three-lane quota;
        stale/backpressured responses receive quota zero.
        """
        return _DIRECT_READER_AHEAD_BYTES

    def wait_future(self, fut, timeout, *, interrupt_event=None):
        """Wait for an asyncio future while remaining immediately stoppable.

        ``interrupt_event`` is used by the background progressive downloader:
        a real post-seek Range must be able to take bandwidth immediately rather
        than waiting up to 40-45 seconds for an old speculative prefix fetch.
        """
        from concurrent.futures import TimeoutError as FutureTimeoutError
        deadline = time.time() + max(0.0, float(timeout or 0.0))

        def interrupted():
            if not interrupt_event:
                return False
            events = interrupt_event if isinstance(interrupt_event, (tuple, list, set)) else (interrupt_event,)
            for event in events:
                try:
                    if event is not None and event.is_set():
                        return True
                except Exception:
                    continue
            return False

        while not self.stop.is_set() and not interrupted():
            remaining = deadline - time.time()
            if remaining <= 0:
                # Preserve Future.result() timeout semantics for existing callers.
                return fut.result(timeout=0)
            try:
                return fut.result(timeout=min(0.25, remaining))
            except FutureTimeoutError:
                if fut.done():
                    return fut.result()
                continue
        try:
            if fut is not None and not fut.done():
                fut.cancel()
        except Exception:
            pass
        return None

    def append_cached(self, offset, data):
        """Append one contiguous Telegram chunk and publish it immediately.

        fetch_range() can spend many seconds collecting a multi-MiB window.
        Waiting for the whole window before updating ``cached`` starves Kodi
        even though Telethon is already delivering 512 KiB chunks.  This sink
        makes each received chunk visible to HTTP readers as soon as it has
        been flushed to disk.
        """
        data = bytes(data or b'')
        if not data:
            return 0
        offset = int(offset or 0)
        with self.lock:
            cached = int(self.cached or 0)
            # A cancelled/late overlapping fetch must never duplicate bytes.
            if offset < cached:
                overlap = cached - offset
                if overlap >= len(data):
                    return 0
                data = data[overlap:]
                offset = cached
            if offset != cached:
                raise RuntimeError('non-contiguous Telegram cache write: offset=%s cached=%s' % (offset, cached))
            mode = 'r+b' if os.path.exists(self.cache_path) else 'wb'
            with open(self.cache_path, mode) as fh:
                fh.seek(offset)
                fh.write(data)
                fh.flush()
            self.cached = offset + len(data)
        self.event.set()
        return len(data)

    def _run_download(self):
        # The existing single-fetch path is kept for Windows/Linux, where it is
        # already field-tested.  Android/Kodi is the platform from the current
        # regression logs and benefits from a tiny in-flight pipeline: Telegram
        # file downloads are request/response based, and waiting for every block
        # before asking for the next one leaves the connection idle between RTTs.
        if _is_android():
            return self._run_download_android_pipeline()
        return self._run_download_sequential()

    def _run_download_sequential(self):
        try:
            try:
                # Create/truncate once. Individual Telethon chunks are appended
                # by append_cached() from the persistent asyncio loop.
                with open(self.cache_path, 'wb'):
                    pass
            except Exception:
                pass
            self.log('progressive download start size=%s file=%r mode=sequential' % (self.total, os.path.basename(self.cache_path)))
            pos = 0
            empty = 0
            diag_started = time.time()
            diag_last_time = diag_started
            diag_last_bytes = 0
            _diag_stream('stage=progressive-start; mode=sequential; total_mib=%.2f' % (
                float(self.total or 0) / (1024.0 * 1024.0)))
            while not self.stop.is_set():
                if self.total and pos >= self.total:
                    self.done = True
                    break
                if self.direct_active.is_set() and pos >= 16 * 1024 * 1024:
                    # A seek is being served directly from Telegram. Let that
                    # connection use the available bandwidth; keep the first
                    # 16 MiB cache for startup/probing only.
                    time.sleep(0.25)
                    continue
                # Preserve the established fetch windows.  fetch_range() publishes
                # every internal chunk through append_cached, so Kodi sees bytes
                # before the complete multi-MiB window finishes.
                if pos < 1024 * 1024:
                    want = 128 * 1024
                    call_timeout = 12.0
                    result_timeout = 16.0
                elif pos < 8 * 1024 * 1024:
                    want = 1024 * 1024
                    call_timeout = 18.0
                    result_timeout = 26.0
                else:
                    want = 4 * 1024 * 1024
                    call_timeout = 28.0
                    result_timeout = 45.0
                if self.total:
                    want = min(want, max(0, self.total - pos))
                self.fetch_result_timeout = float(result_timeout)
                fut = None
                before = int(self.cached or 0)
                try:
                    fut = self.service.submit_coro(
                        self.service.fetch_range(
                            self, pos, want, timeout=call_timeout,
                            on_chunk=self.append_cached,
                        )
                    )
                    data = self.wait_future(
                        fut, result_timeout,
                        interrupt_event=self.direct_active if pos >= 16 * 1024 * 1024 else None,
                    )
                    if data is None and self.stop.is_set():
                        break
                    if data is None and self.direct_active.is_set() and pos >= 16 * 1024 * 1024:
                        pos = max(pos, int(self.cached or 0))
                        continue
                except Exception as exc:
                    data = b''
                    self.error = repr(exc)
                    try:
                        if fut is not None and not fut.done():
                            fut.cancel()
                    except Exception:
                        pass
                after = int(self.cached or 0)
                if after <= before and not data:
                    empty += 1
                    if empty >= 3:
                        self.failed = True
                        self.log('progressive stalled pos=%s err=%r' % (pos, self.error))
                        break
                    time.sleep(0.35)
                    continue
                empty = 0
                self.error = ''
                pos = max(pos, after)
                if pos <= before and data:
                    self.append_cached(pos, data)
                    pos = int(self.cached or pos)
                diag_now = time.time()
                if diag_now - diag_last_time >= 8.0:
                    diag_delta = max(0, int(pos or 0) - int(diag_last_bytes or 0))
                    diag_span = max(0.001, diag_now - diag_last_time)
                    _diag_stream(
                        'stage=progressive-rate; mode=sequential; cached_mib=%.2f; speed_mib_s=%.2f' % (
                            float(pos or 0) / (1024.0 * 1024.0),
                            float(diag_delta) / (1024.0 * 1024.0) / diag_span,
                        )
                    )
                    diag_last_time = diag_now
                    diag_last_bytes = int(pos or 0)
                if pos >= 512 * 1024 * 1024 and time.time() - self.last_read > 90:
                    self.log('progressive idle stop cached=%s idle=%.1fs' % (pos, time.time() - self.last_read))
                    self.done = True
                    break
            try:
                self.event.set()
            except Exception:
                pass
            self.log('progressive download stop cached=%s done=%s err=%r mode=sequential' % (self.cached, self.done, self.error))
            diag_elapsed = max(0.001, time.time() - diag_started)
            _diag_stream(
                'stage=progressive-stop; mode=sequential; cached_mib=%.2f; avg_mib_s=%.2f; done=%s; failed=%s' % (
                    float(self.cached or 0) / (1024.0 * 1024.0),
                    float(self.cached or 0) / (1024.0 * 1024.0) / diag_elapsed,
                    bool(self.done), bool(self.failed),
                )
            )
        except Exception as exc:
            self.error = repr(exc)
            self.failed = True
            self.event.set()
            fflog_exc(1)

    def _run_download_android_pipeline(self):
        """Progressively cache Telegram media with a small ordered pipeline.

        The Android regression log shows the player consuming data faster than a
        single request-at-a-time downloader can refill the cache.  The older
        Kadr+ codebase already contained a bounded 2-3 worker prefix helper for
        this exact latency problem.  Here we keep only three 512 KiB parts
        in flight, use the same persistent service client, and *write strictly in
        offset order*.  No speculative byte can be exposed to Kodi before every
        preceding byte exists.
        """
        from concurrent.futures import TimeoutError as FutureTimeoutError

        segment = 512 * 1024
        max_inflight = 3
        result_timeout = 40.0
        call_timeout = 28.0
        self.fetch_result_timeout = result_timeout
        pending = {}
        pos = 0
        next_offset = 0
        no_progress_failures = 0
        started = time.time()
        last_rate_log = started
        last_rate_bytes = 0

        def _cancel_pending():
            for fut, _want, _started in list(pending.values()):
                try:
                    if fut is not None and not fut.done():
                        fut.cancel()
                except Exception:
                    pass
            pending.clear()

        def _schedule(offset, want):
            # Prefix, sparse probes and post-seek streaming share one per-file
            # ceiling.  Three pipelines of three requests each previously meant
            # up to nine competing Telegram RPCs for one movie.
            coro = self.service._fetch_direct_limited(
                self, offset, want,
                timeout=call_timeout,
                request_size_hint=segment,
            )
            fut = self.service.submit_coro(coro)
            pending[offset] = (fut, want, time.time())

        try:
            try:
                if os.path.exists(self.cache_path):
                    os.remove(self.cache_path)
            except Exception:
                pass
            self.log('progressive download start size=%s file=%r mode=android-pipeline inflight=%s part=%s' % (
                self.total, os.path.basename(self.cache_path), max_inflight, segment))
            _diag_stream(
                'stage=progressive-start; mode=android-pipeline; inflight=%s; part_kib=%s; total_mib=%.2f' % (
                    max_inflight, int(segment / 1024),
                    float(self.total or 0) / (1024.0 * 1024.0),
                )
            )

            with open(self.cache_path, 'ab') as fh:
                while (not self.stop.is_set()
                       and not self.progressive_retired.is_set()):
                    if self.total and pos >= self.total:
                        self.done = True
                        break

                    if self.direct_reader_active.is_set():
                        # Pause only for an HTTP Range that is actually being
                        # consumed. Player.OnSeek alone must not stop the prefix.
                        _cancel_pending()
                        next_offset = pos
                        _diag_stream(
                            'stage=progressive-pause; reason=direct-reader; cached_mib=%.2f' % (
                                float(pos) / (1024.0 * 1024.0)
                            )
                        )
                        while (self.direct_reader_active.is_set()
                               and not self.stop.is_set()
                               and not self.progressive_retired.is_set()):
                            self.event.wait(0.10)
                            self.event.clear()
                        if self.stop.is_set() or self.progressive_retired.is_set():
                            break
                        _diag_stream(
                            'stage=progressive-resume; reason=seek-owner-ended; cached_mib=%.2f' %
                            (float(pos) / (1024.0 * 1024.0))
                        )
                        continue

                    while len(pending) < max_inflight and (not self.total or next_offset < self.total):
                        want = segment
                        if self.total:
                            want = min(want, max(0, self.total - next_offset))
                        if want <= 0:
                            break
                        _schedule(next_offset, want)
                        next_offset += want

                    current = pending.get(pos)
                    if current is None:
                        # This only happens after a partial range; rebuild the
                        # queue from the exact contiguous cache boundary.
                        _cancel_pending()
                        next_offset = pos
                        time.sleep(0.02)
                        continue

                    fut, wanted, req_started = current
                    try:
                        data = self.wait_future(
                            fut, result_timeout,
                            interrupt_event=(self.progressive_retired, self.direct_reader_active),
                        )
                        if data is None and self.stop.is_set():
                            break
                        if data is None and self.progressive_retired.is_set():
                            _cancel_pending()
                            break
                        if data is None and self.direct_reader_active.is_set():
                            _cancel_pending()
                            next_offset = pos
                            continue
                    except FutureTimeoutError as exc:
                        data = b''
                        self.error = repr(exc)
                        try:
                            if not fut.done():
                                fut.cancel()
                        except Exception:
                            pass
                    except Exception as exc:
                        data = b''
                        self.error = repr(exc)

                    if not data:
                        pending.pop(pos, None)
                        no_progress_failures += 1
                        if no_progress_failures >= 3:
                            self.failed = True
                            self.log('progressive stalled pos=%s err=%r mode=android-pipeline' % (pos, self.error))
                            break
                        # A later range may already be complete, but exposing it
                        # would create a hole. Keep no speculative state across a
                        # failed leading segment; retry contiguously from pos.
                        _cancel_pending()
                        next_offset = pos
                        time.sleep(0.30)
                        continue

                    data = bytes(data)
                    if len(data) > wanted:
                        data = data[:wanted]
                    # Close the result/event race: OnSeek can arrive after
                    # wait_future returned but before this thread publishes the
                    # old-position block.
                    if self.progressive_retired.is_set():
                        _cancel_pending()
                        break
                    with self.lock:
                        if self.progressive_retired.is_set():
                            _cancel_pending()
                            break
                        fh.write(data)
                        fh.flush()
                        pos += len(data)
                        self.cached = pos
                    self.event.set()
                    pending.pop(pos - len(data), None)
                    no_progress_failures = 0
                    self.error = ''

                    # A short part means Telegram returned only a contiguous prefix.
                    # Cancel ranges scheduled beyond the gap and continue exactly
                    # from the newly published offset.
                    if len(data) < wanted:
                        _cancel_pending()
                        next_offset = pos

                    now = time.time()
                    if now - last_rate_log >= 8.0:
                        delta = pos - last_rate_bytes
                        span = max(0.001, now - last_rate_log)
                        mib_s = float(delta) / (1024.0 * 1024.0) / span
                        _diag_stream(
                            'stage=progressive-rate; mode=android-pipeline; cached_mib=%.2f; speed_mib_s=%.2f' % (
                                float(pos or 0) / (1024.0 * 1024.0), mib_s,
                            )
                        )
                        last_rate_log = now
                        last_rate_bytes = pos

                    if pos >= 512 * 1024 * 1024 and time.time() - self.last_read > 90:
                        self.log('progressive idle stop cached=%s idle=%.1fs' % (pos, time.time() - self.last_read))
                        self.done = True
                        break

            _cancel_pending()
            try:
                self.event.set()
            except Exception:
                pass
            elapsed = max(0.001, time.time() - started)
            avg = float(self.cached or 0) / (1024.0 * 1024.0) / elapsed
            self.log('progressive download stop cached=%s done=%s err=%r mode=android-pipeline avg=%.2fMiB/s' % (
                self.cached, self.done, self.error, avg))
            _diag_stream(
                'stage=progressive-stop; mode=android-pipeline; cached_mib=%.2f; avg_mib_s=%.2f; done=%s; failed=%s' % (
                    float(self.cached or 0) / (1024.0 * 1024.0), avg,
                    bool(self.done), bool(self.failed),
                )
            )
        except Exception as exc:
            _cancel_pending()
            self.error = repr(exc)
            self.failed = True
            self.event.set()
            fflog_exc(1)

    def wait_cached(self, pos, timeout=12.0, *, interrupt_event=None):
        """Wait for progressive cache, optionally abandoning it on a real seek.

        A Range can arrive a few hundred milliseconds before Player.OnSeek. In
        that race the old code entered the progressive-frontier wait for 24 s,
        even though OnSeek had already retired the prefix downloader. Kodi then
        hit its own cURL timeout before the direct seek producer was even started.
        """
        deadline = time.time() + float(timeout or 0)
        pos = int(pos or 0)
        while time.time() < deadline and not self.stop.is_set():
            if interrupt_event is not None and interrupt_event.is_set():
                return False
            with self.lock:
                if self.cached > pos:
                    return True
            if self.done or self.failed:
                return False
            self.event.wait(0.20)
            self.event.clear()
        if interrupt_event is not None and interrupt_event.is_set():
            return False
        with self.lock:
            return self.cached > pos

    def wait_startup(self, minimum=512 * 1024, timeout=12.0):
        return self.wait_cached(int(minimum or 1) - 1, timeout=timeout)

    def read_cached(self, start, size):
        try:
            with self.lock:
                cached = int(self.cached or 0)
            if cached <= start:
                return b''
            size = min(int(size or 0), cached - int(start or 0))
            if size <= 0:
                return b''
            with open(self.cache_path, 'rb') as fh:
                fh.seek(int(start or 0))
                return fh.read(size)
        except Exception:
            return b''

    def touch(self):
        self.last_read = time.time()


class TelegramStreamService:
    def __init__(self, preferred_port=0):
        _cleanup_stream_cache()
        self.preferred_port = int(preferred_port or 0)
        self.port = 0
        self.server = None
        self.server_thread = None
        self.loop = None
        self.loop_thread = None
        self.jobs = {}
        self.jobs_lock = threading.RLock()
        self.client = None
        self.client_key = None
        self.client_lock = None
        self.abort_monitor = None
        self.running = False

    def start(self, monitor=None):
        if self.running:
            return self.port
        self.abort_monitor = monitor
        _ensure_vendor_path()
        try:
            if tg_ctypes_crypto:
                tg_ctypes_crypto.try_load()
        except Exception:
            pass
        self._start_loop()
        self._start_http()
        self.running = True
        return self.port

    def _start_loop(self):
        ready = threading.Event()
        def runner():
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.loop)
            self.client_lock = asyncio.Lock()
            ready.set()
            self.loop.run_forever()
        self.loop_thread = threading.Thread(target=runner, name='KadrPlusTGAsyncLoop', daemon=True)
        self.loop_thread.start()
        ready.wait(5.0)

    def submit_coro(self, coro):
        if not self.loop:
            raise RuntimeError('telegram service loop not started')
        return asyncio.run_coroutine_threadsafe(coro, self.loop)

    def _start_http(self):
        import http.server
        import socketserver

        service = self

        class ThreadingServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
            daemon_threads = True
            allow_reuse_address = True

        class Handler(http.server.BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'
            server_version = 'KadrPlusTGService/1.0'

            def log_message(self, fmt, *args):
                try:
                    fflog('[tg-service-http] ' + (fmt % args), 0)
                except Exception:
                    pass

            def do_HEAD(self):
                self._dispatch(head_only=True)

            def do_GET(self):
                self._dispatch(head_only=False)

            def do_POST(self):
                self._dispatch(head_only=False)

            def _dispatch(self, head_only=False):
                try:
                    try:
                        # Bound control request reads and small header writes. The
                        # stream body has its own cancellation-aware backpressure
                        # loop, so a full Kodi cache never becomes a false EOF.
                        self.connection.settimeout(6)
                    except Exception:
                        pass
                    path = urlparse(self.path).path or ''
                    if path == '/ping':
                        return _json_response(self, 200, {'ok': True, 'port': service.port, 'jobs': len(service.jobs)})
                    if path == '/control/register' and self.command == 'POST':
                        length = int(self.headers.get('Content-Length') or 0)
                        raw = self.rfile.read(min(length, 512 * 1024)) if length else b'{}'
                        spec = json.loads(raw.decode('utf-8') or '{}')
                        result = service.register(spec)
                        status = 200 if result.get('ok') else 503
                        return _json_response(self, status, result)
                    m = re.match(r'^/stream/([A-Za-z0-9_-]{16,64})(?:/.*)?$', path)
                    if m:
                        token = m.group(1)
                        with service.jobs_lock:
                            job = service.jobs.get(token)
                        if job is not None:
                            job.register_connection(self.connection)
                        try:
                            return service.serve_stream(self, token, head_only=head_only)
                        finally:
                            if job is not None:
                                job.unregister_connection(self.connection)
                    self.send_error(404, 'not found')
                except Exception:
                    fflog_exc(1)
                    try:
                        self.send_error(500, 'telegram service error')
                    except Exception:
                        pass

        ports = []
        if 1024 < self.preferred_port < 65536:
            ports.append(self.preferred_port)
        ports.append(0)
        last = None
        for p in ports:
            try:
                self.server = ThreadingServer(('127.0.0.1', p), Handler)
                self.port = int(self.server.server_address[1])
                break
            except Exception as exc:
                last = exc
        if not self.server:
            raise RuntimeError('cannot start telegram service HTTP: %r' % (last,))
        self.server_thread = threading.Thread(target=self.server.serve_forever, name='KadrPlusTGServiceHTTP', daemon=True)
        self.server_thread.start()
        _write_status(self.port)
        fflog('[tg-service] started on 127.0.0.1:%s' % self.port, 1)

    async def ensure_client(self, spec):
        _ensure_vendor_path()
        from telethon import TelegramClient
        from telethon.sessions import StringSession
        async with (self.client_lock or asyncio.Lock()):
            api_id = int((spec or {}).get('api_id') or 0)
            api_hash = (spec or {}).get('api_hash') or ''
            session_string = (spec or {}).get('session_string') or ''
            if not (api_id and api_hash and session_string):
                raise RuntimeError('missing api/session for Telegram service')
            key = (api_id, api_hash, session_string[:32])
            if self.client and self.client_key == key:
                try:
                    if await self.client.is_user_authorized():
                        return self.client
                except Exception:
                    pass
            if self.client:
                try:
                    await self.client.disconnect()
                except Exception:
                    pass
                self.client = None
            # A single persistent client; no updates while streaming.
            # Telegram regularly closes an idle MTProto socket; Telethon then
            # reconnects automatically, but its ERROR log looked like a Kadr+
            # crash every ~60 seconds. Real register/stream failures are logged
            # explicitly below, so keep this internal reconnect logger quiet.
            telethon_logger = logging.getLogger('kadrplus.telegram.stream.telethon')
            telethon_logger.setLevel(logging.CRITICAL)
            self.client = TelegramClient(StringSession(session_string), api_id, api_hash,
                                         loop=self.loop, timeout=14, request_retries=1,
                                         connection_retries=3, retry_delay=0.7,
                                         auto_reconnect=True, receive_updates=False,
                                         flood_sleep_threshold=0, entity_cache_limit=256,
                                         base_logger=telethon_logger)
            await self.client.connect()
            if not await self.client.is_user_authorized():
                await self.client.disconnect()
                self.client = None
                raise RuntimeError('Telegram session is not authorised')
            self.client_key = key
            return self.client

    async def prepare_spec(self, spec):
        """Validate and enrich playback metadata before the player sees a URL.

        The source list sometimes carries a display-size or a corrupted tiny
        value in the packed token.  Kodi needs the real Telegram document size
        for HTTP Range, so refresh the message in the persistent Telegram loop
        before creating the stream job whenever the size/location looks wrong.
        """
        spec = dict(spec or {})
        await self.ensure_client(spec)
        size = int(spec.get('size') or 0)
        location = self._document_location_from_spec(spec)
        if (not location) or size < 1024 * 1024:
            await self._refresh_location(self.client, spec)
        size = int(spec.get('size') or 0)
        if size <= 0:
            raise RuntimeError('Telegram document size unavailable')
        if not self._document_location_from_spec(spec):
            raise RuntimeError('Telegram document location unavailable')
        return spec

    def register(self, spec):
        try:
            spec = dict(spec or {})
            # Resolve real document metadata first.  Do this before starting the
            # cache thread, otherwise a wrong tiny size (seen as size=16 in the
            # log) makes the streamer impossible for Kodi to open.
            try:
                spec = self.submit_coro(self.prepare_spec(spec)).result(timeout=24.0)
            except Exception as exc:
                return {'ok': False, 'error': 'Telegram metadata failed: %r' % (exc,), 'cached': 0}
            crypto_info = _crypto_status()
            try:
                fflog('[tg-crypto/register] backend=%s tgcrypto_ctypes=%s detail=%r' % (
                    crypto_info.get('telethon_backend'), crypto_info.get('tgcrypto_ctypes'),
                    crypto_info.get('tgcrypto_detail') or crypto_info.get('error') or ''), 1)
            except Exception:
                pass
            native_backend = (crypto_info.get('telethon_backend') or '').lower()
            fast_backends = ('tgcrypto_ctypes', 'libssl')
            if native_backend not in fast_backends:
                return {
                    'ok': False,
                    'error': 'Brak szybkiej natywnej kryptografii Telegram (tgcrypto_ctypes/libssl). PyCryptodome/pyaes są za wolne do streamingu na tym Androidzie.',
                    'cached': 0,
                    'crypto_backend': native_backend,
                    'crypto': crypto_info,
                    'last_error': crypto_info.get('tgcrypto_detail') or crypto_info.get('error') or ''
                }
            token = uuid.uuid4().hex
            spec['token'] = token
            job = _StreamJob(self, spec)
            with self.jobs_lock:
                # Stop old jobs to reduce disk/network/disk pressure. Keep only the current test/playback.
                for old_token, old_job in list(self.jobs.items()):
                    try:
                        old_job.request_stop()
                    except Exception:
                        pass
                    self._retire_job_async(old_token, old_job, reason='new-register')
                    self.jobs.pop(old_token, None)
                # Each old job removes its own files after workers/readers have
                # quiesced.  A global size cleanup here could delete a still-open
                # multi-hundred-MiB region between request_stop() and that worker's
                # final read, which turns a normal source change into premature EOF.
                self.jobs[token] = job
            job.start()
            # Kodi/FFmpeg does not only need the first few bytes.  In the log it
            # opened bytes=0- and then immediately bytes=393216-.  Returning the
            # URL with only 64 KiB made the second seek race the cache.  Wait for
            # a realistic first window, but do not fail if Telegram is slow and
            # we already have a smaller usable window.
            # Pipe mode does not require several MiB before giving Kodi the URL.
            # Long waits here were the visible "sprawdzanie linku" delay.
            # For fast native backends give Kodi a real startup window before it
            # asks FFmpeg to probe/seek. Slow fallbacks are already rejected above.
            # Give Kodi a larger cushion before playback. On large files the
            # bottleneck is no longer AES, but Telegram range throughput and
            # FFmpeg's probing/seek pattern.  A bigger initial cache greatly
            # reduces early underruns without changing the stream URL.
            try:
                startup_mb = max(1, min(16, int(spec.get('startup_buffer_mb') or 4)))
            except Exception:
                startup_mb = 4
            startup_min = startup_mb * 1024 * 1024 if native_backend in fast_backends else 128 * 1024
            startup_timeout = min(24.0, max(10.0, 8.0 + 2.0 * startup_mb)) if native_backend in fast_backends else 8.0
            job.log('startup target=%s MiB timeout=%.1fs' % (startup_mb, startup_timeout))
            startup_started = time.time()
            _diag_stream(
                'stage=startup; mode=%s; target_mib=%s; timeout_s=%.1f' % (
                    'android-pipeline' if _is_android() else 'sequential',
                    startup_mb, startup_timeout,
                )
            )
            ready = job.wait_startup(minimum=startup_min, timeout=startup_timeout)
            cached = int(job.cached or 0)
            startup_elapsed = max(0.001, time.time() - startup_started)
            _diag_stream(
                'stage=startup-result; mode=%s; ready=%s; cached_mib=%.2f; elapsed_s=%.2f; speed_mib_s=%.2f' % (
                    'android-pipeline' if _is_android() else 'sequential',
                    bool(ready),
                    float(cached) / (1024.0 * 1024.0),
                    startup_elapsed,
                    float(cached) / (1024.0 * 1024.0) / startup_elapsed,
                )
            )
            if native_backend in ('pyaes', 'unknown') and cached < 128 * 1024:
                job.request_stop()
                return {'ok': False, 'error': 'Brak szybkiej kryptografii Telegram (tgcrypto_ctypes/libssl); pyaes jest za wolny do streamingu na Androidzie', 'cached': cached, 'crypto_backend': native_backend, 'crypto': crypto_info, 'last_error': job.error}
            if cached <= 0:
                job.request_stop()
                return {'ok': False, 'error': 'Telegram service did not deliver first bytes', 'cached': cached, 'last_error': job.error}
            if not ready:
                if cached < 64 * 1024:
                    job.request_stop()
                    return {'ok': False, 'error': 'Telegram startup buffer too small', 'cached': cached, 'last_error': job.error}
                # Preserve the real behaviour of the field-tested .57 path:
                # even with a partial startup cache Kodi receives the normal
                # seekable URL.  A later .88 experiment activated ?pipe=1 here;
                # that disables Range/seek and changes FFmpeg/Kodi buffering.
                job.log('startup below target cached=%s; handing normal seekable URL' % cached)
            filename = _safe_name(job.filename)
            url = 'http://127.0.0.1:%d/stream/%s/%s' % (self.port, token, quote(filename))
            return {'ok': True, 'url': url, 'token': token, 'cached': cached, 'size': job.total, 'crypto_backend': native_backend, 'crypto': crypto_info}
        except Exception as exc:
            fflog_exc(1)
            return {'ok': False, 'error': repr(exc)}

    def _bounded_range(self, job, start, end, partial):
        # Kept for older callers, but normal playback must not shrink Kodi's
        # requested range. FFmpeg/Kodi uses HEAD + byte ranges to decide if it
        # can seek to MP4/MKV metadata. Returning a fake small 206 for a full
        # resource makes Kodi believe the resource is tiny and the demuxer fails.
        total = int(job.total or 0)
        start = int(start or 0)
        end = int(end if end is not None else max(0, total - 1))
        if total:
            start = max(0, min(start, total - 1))
            end = max(start, min(end, total - 1))
        return start, end, bool(partial)

    def _write_full_headers(self, handler, job, status=200, *, seekable=True):
        total = int(job.total or 0)
        handler.send_response(status)
        handler.send_header('Content-Type', job.mime or 'video/mp4')
        # Pipe fallback must not advertise byte seeking and then reject the
        # non-zero Range requests it invited. Normal mode remains seekable.
        handler.send_header('Accept-Ranges', 'bytes' if seekable else 'none')
        handler.send_header('Content-Disposition', _content_disposition(job.filename))
        if total:
            handler.send_header('Content-Length', str(total))
        handler.send_header('Connection', 'close')
        handler.close_connection = True
        handler.end_headers()


    def _write_headers(self, handler, status, job, start, end, partial):
        total = job.total
        length = max(0, int(end) - int(start) + 1) if total else 0
        handler.send_response(status)
        handler.send_header('Content-Type', job.mime or 'video/mp4')
        handler.send_header('Accept-Ranges', 'bytes')
        handler.send_header('Content-Disposition', _content_disposition(job.filename))
        if total:
            if partial:
                handler.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, total))
            handler.send_header('Content-Length', str(length))
        handler.send_header('Connection', 'close')
        handler.close_connection = True
        handler.end_headers()

    def _write_stopped_headers(self, handler):
        """Finish a request that raced with Stop without advertising a body.

        Returning an empty ``206`` after declaring the rest of a multi-gigabyte
        file makes Kodi/cURL retry and wait for its read timeout. A bodyless 410
        is terminal and is emitted only for an already-stopped Kadr+ stream job.
        """
        handler.close_connection = True
        try:
            handler.send_response(410)
            handler.send_header('Content-Length', '0')
            handler.send_header('Connection', 'close')
            handler.end_headers()
            return True
        except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError):
            # request_stop() may already have closed this exact socket. The next
            # cURL retry will receive the terminal response from serve_stream().
            return False

    def serve_stream(self, handler, token, head_only=False):
        with self.jobs_lock:
            job = self.jobs.get(token)
        if not job:
            handler.send_error(404, 'stream token not found')
            return
        if job.stop.is_set():
            self._write_stopped_headers(handler)
            return
        job.touch()
        total = int(job.total or 0)
        if total <= 0:
            handler.send_error(416, 'unknown file size')
            return

        raw_range = handler.headers.get('Range') or ''
        has_range = bool(raw_range)
        try:
            pipe_mode = 'pipe=1' in (urlparse(handler.path).query or '')
        except Exception:
            pipe_mode = False
        start, end, partial = _parse_range(raw_range, total)
        # IMPORTANT: do not bound/shrink normal HEAD/GET ranges. Kodi/FFmpeg
        # depends on truthful Content-Length and Content-Range to decide when to
        # probe the end of MP4/MKV files. Previous builds answered HEAD with
        # 206 and Content-Length=524288, which effectively told Kodi the whole
        # 1.6 GB file was a 512 KiB resource.
        try:
            fflog('[tg-service] [%s] HTTP %s range=%s-%s/%s cached=%s raw=%r has_range=%s' % (
                _token_tag(token), handler.command, start, end, total, job.cached, raw_range, has_range), 1)
        except Exception:
            pass

        # Kodi often sends HEAD without Range before opening the demuxer. This
        # MUST describe the full representation: 200 OK, full Content-Length,
        # Accept-Ranges, no Content-Range.
        if head_only:
            if pipe_mode:
                # Describe the pipe truthfully as a non-seekable full resource,
                # regardless of a speculative Range header on HEAD.
                self._write_full_headers(handler, job, 200, seekable=False)
                try:
                    fflog('[tg-service] [%s] HEAD pipe size=%s cached=%s' % (_token_tag(token), total, job.cached), 1)
                except Exception:
                    pass
                return
            if not has_range:
                self._write_full_headers(handler, job, 200)
                try:
                    fflog('[tg-service] [%s] HEAD full size=%s cached=%s' % (_token_tag(token), total, job.cached), 1)
                except Exception:
                    pass
                return
            self._write_headers(handler, 206, job, start, end, True)
            return

        # Non-seekable pipe mode: do not allow Kodi/FFmpeg to trigger random
        # tail probes. Serve a single growing stream from byte 0. This is the
        # only mode that avoids UI-clogging random Telegram range fetches on
        # slow Android/Python devices.
        if pipe_mode:
            if has_range and start > 0:
                try:
                    fflog('[tg-service] [%s] pipe ignoring non-zero range start=%s raw=%r' % (_token_tag(token), start, raw_range), 1)
                except Exception:
                    pass
                handler.send_error(416, 'non-seekable Telegram pipe')
                return
            if not job.wait_cached(0, timeout=12.0):
                handler.send_error(504, 'Telegram service did not return first byte')
                return
            self._write_full_headers(handler, job, 200, seekable=False)
            sent = self._send_from_progressive_cache(handler, job, 0, total - 1, wait_for_more=True)
            try:
                fflog('[tg-service] [%s] pipe stream sent=%s cached=%s err=%r' % (_token_tag(token), sent, job.cached, job.error), 1)
            except Exception:
                pass
            return

        # No Range GET: stream the full representation from byte 0.
        if not has_range:
            start, end, partial = 0, total - 1, False
            if not job.wait_cached(0, timeout=20.0):
                handler.send_error(504, 'Telegram service did not return first byte')
                return
            self._write_full_headers(handler, job, 200)
            sent = self._send_from_progressive_cache(handler, job, start, end, wait_for_more=True)
            try:
                fflog('[tg-service] [%s] full stream sent=%s cached=%s err=%r' % (_token_tag(token), sent, job.cached, job.error), 1)
            except Exception:
                pass
            return

        # Establish open-ended semantics before choosing a cache path. After a
        # high-position Player.OnSeek, FFmpeg may first issue many open-ended
        # MP4/index probes far away from the requested playback time. Classify
        # those *before* the progressive-frontier shortcut, otherwise the old
        # downloader keeps walking forward and competes with the seek.
        want = end - start + 1
        open_ended = False
        try:
            open_ended = bool(has_range and str(raw_range).strip().endswith('-') and end == total - 1)
        except Exception:
            open_ended = False
        tail_probe = bool(open_ended and want <= 16 * 1024 * 1024)
        if has_range and (start > 0 or open_ended):
            _diag_stream(
                'stage=http-range; start_mib=%.2f; end_mib=%.2f; total_mib=%.2f; '
                'open_ended=%s; tail=%s; cached_mib=%.2f' % (
                    float(start) / (1024.0 * 1024.0),
                    float(end) / (1024.0 * 1024.0),
                    float(total) / (1024.0 * 1024.0),
                    bool(open_ended), bool(tail_probe),
                    float(job.cached or 0) / (1024.0 * 1024.0),
                )
            )

        # Prefix/early ranges are streamed continuously from the progressive
        # cache. We honour the requested range in the headers, then feed bytes as
        # the Telegram worker appends them. This is HTTP-correct for Kodi.
        with job.lock:
            cached = int(job.cached or 0)

        direct_active = bool(job.direct_reader_active.is_set())
        if (not job.progressive_retired.is_set()
                and _prefer_progressive_range(
                    start, cached, direct_active, allow_slop=_is_android())):
            if cached <= start:
                _diag_stream(
                    'stage=progressive-frontier-range; start_mib=%.2f; cached_mib=%.2f; '
                    'gap_mib=%.2f; direct_active=%s' % (
                        float(start) / (1024.0 * 1024.0),
                        float(cached) / (1024.0 * 1024.0),
                        float(max(0, start - cached)) / (1024.0 * 1024.0),
                        direct_active,
                    )
                )
                job.wait_cached(
                    start, timeout=24.0,
                    interrupt_event=job.progressive_retired,
                )
                if job.progressive_retired.is_set():
                    _diag_stream(
                        'stage=progressive-frontier-interrupt; start_mib=%.2f; reason=seek-or-retire' %
                        (float(start) / (1024.0 * 1024.0))
                    )
            with job.lock:
                cached = int(job.cached or 0)
            # If the progressive prefix was explicitly retired while this
            # Range was waiting, fall through to the direct path rather than
            # serving a short stale prefix and then stalling.
            if not job.progressive_retired.is_set() and cached > start:
                self._write_headers(handler, 206, job, start, end, True)
                sent = self._send_from_progressive_cache(handler, job, start, end, wait_for_more=True)
                try:
                    fflog('[tg-service] [%s] progressive stream sent=%s range=%s-%s cached=%s err=%r' % (_token_tag(token), sent, start, end, job.cached, job.error), 1)
                except Exception:
                    pass
                return

        # Tail/random probe or a real post-seek stream.
        # Important discovery from 2.41.65: after a user seek Kodi may request an
        # open-ended range such as bytes=201520637-. Returning only an 8 MiB
        # sparse slice with Content-Range ending at 209909244 makes Kodi think it
        # reached EOF for that HTTP response, so playback stops shortly after the
        # seek.  For open-ended non-tail ranges we must stream the requested range
        # continuously from Telegram to EOF (or until Kodi closes the socket).
        if open_ended and not tail_probe:
            # The Android shared-region path waits for usable bytes before it
            # commits a 206 response. If Stop wins that race it can return a
            # truthful empty terminal response instead of a partial-file retry.
            if not _is_android():
                self._write_headers(handler, 206, job, start, end, True)
            sent = self._send_direct_telegram_range(handler, job, start, end)
            try:
                fflog('[tg-service] [%s] direct range stream sent=%s range=%s-%s cached=%s err=%r' % (_token_tag(token), sent, start, end, job.cached, job.error), 1)
            except Exception:
                pass
            return

        # Small tail probes and explicit bounded ranges can still be served as a
        # pre-fetched sparse block. For MP4 tail probes, send the whole small tail
        # to EOF so FFmpeg can find moov/index metadata.
        if not tail_probe and want > 8 * 1024 * 1024:
            want = 8 * 1024 * 1024
        fut = None
        try:
            fut = self.submit_coro(self._fetch_direct_limited(job, start, want, timeout=24.0))
            # Sparse/tail probes used to block this HTTP handler in
            # Future.result(timeout=36) even after Player Stop.  The main
            # progressive/direct workers were already immediately stoppable,
            # but this one outstanding probe kept Kodi's CFileCache/cURL alive
            # until its own timeout.  Use the job's existing interruptible wait
            # so request_stop() cancels this exact future within ~250 ms.
            data = job.wait_future(fut, 36.0)
            if data is None and job.stop.is_set():
                _diag_stream(
                    'stage=sparse-stop; start_mib=%.2f; reason=job-stop' %
                    (float(start) / (1024.0 * 1024.0))
                )
                return
            job.range_error = ''
        except Exception as exc:
            data = b''
            job.range_error = repr(exc)
            try:
                if fut is not None and not fut.done():
                    fut.cancel()
            except Exception:
                pass
            try:
                fflog('[tg-service] [%s] sparse range failed start=%s want=%s err=%r' % (
                    _token_tag(token), start, want, job.range_error), 1)
            except Exception:
                pass
        if data:
            real_end = start + len(data) - 1
            self._write_headers(handler, 206, job, start, real_end, True)
            if not _write_stream_body(
                    handler, data,
                    is_active=lambda: not job.stop.is_set(),
                    mode='sparse'):
                try:
                    fflog('[tg-service] [%s] sparse client closed/cancelled after bytes=%s' % (_token_tag(token), len(data)), 1)
                except Exception:
                    pass
            try:
                fflog('[tg-service] [%s] sparse sent=%s-%s bytes=%s wanted=%s-%s tail=%s' % (_token_tag(token), start, real_end, len(data), start, end, tail_probe), 1)
            except Exception:
                pass
            return
        handler.send_error(504, 'Telegram service did not return bytes')

    async def _fetch_direct_limited(self, job, offset, want, *, generation=None, gate_event=None,
                                    **kwargs):
        """Fetch one direct/sparse block under a per-job concurrency ceiling."""
        sem = getattr(job, 'direct_fetch_semaphore', None)
        if sem is None:
            # All service coroutines run on one asyncio loop, so lazy creation is
            # deterministic and binds the semaphore to the correct loop on Py3.8.
            sem = asyncio.Semaphore(3)
            job.direct_fetch_semaphore = sem
        async with sem:
            if job.stop.is_set():
                return b''
            if generation is not None and gate_event is not None:
                if not job.direct_prebuffer_is_current(generation, gate_event):
                    return b''
            data = await self.fetch_range(job, offset, want, **kwargs)
            return data

    def _get_or_create_direct_region(self, job, start, end, generation, gate_event, reason='',
                                     prebuffer_target=0):
        """Return a cache for one contiguous Android/FFmpeg byte area."""
        # A random/direct Range is not proof that the progressive prefix is
        # obsolete. FFmpeg can probe distant MP4/index areas during one seek and
        # then return to the existing prefix. Keep that cache alive; the prefix
        # worker is temporarily paused only while a direct HTTP reader is active.
        with job.direct_region_lock:
            region = job.matching_direct_region(start, generation)
            if region is not None:
                if prebuffer_target:
                    region.prebuffer_target = max(region.prebuffer_target, int(prebuffer_target))
                job.direct_region = region
                return region, False
            region = _DirectRegion(
                job, generation, gate_event, start, end, reason=reason,
                prebuffer_target=prebuffer_target,
            )
            job.direct_region = region
            job.direct_regions.append(region)
            job.direct_region_paths.add(region.path)
            job.direct_begin()
            try:
                region.future = self.submit_coro(self._produce_direct_region(job, region))
            except Exception:
                job.direct_end()
                region.request_stop()
                raise
            return region, True

    async def _produce_direct_region(self, job, region):
        """Fill the currently consumed region with a 3-part ordered pipeline.

        The real trace proved that one persistent request delivered only
        0.28 MiB/s for media requiring about 0.88 MiB/s. The already-proven
        progressive path reached 1.02-1.24 MiB/s with three 512 KiB requests.
        Reuse that exact bounded concurrency here. Only the range whose HTTP
        reader is consuming/waiting owns the lanes; every write remains strictly
        contiguous, so speculative completion can never expose a file hole.
        """
        segment = _DIRECT_FETCH_SEGMENT_BYTES
        first_segment = _DIRECT_READER_PRIME_BYTES
        pos = int(region.start)
        next_offset = pos
        pending = {}
        failures = 0
        started = time.time()

        async def cancel_pending():
            tasks = [entry[0] for entry in pending.values()]
            pending.clear()
            for task in tasks:
                try:
                    if not task.done():
                        task.cancel()
                except Exception:
                    pass
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)

        def schedule(offset):
            # Fast first byte for FFmpeg's random MP4 probes, then return to the
            # proven 512 KiB transfer unit for sustained throughput.
            block = first_segment if int(offset) == int(region.start) else segment
            want = min(block, max(0, region.end - offset + 1))
            if want <= 0:
                return 0
            generation = int(region.generation or 0)
            gate_event = region.gate_event
            task = asyncio.create_task(self._fetch_direct_limited(
                job, offset, want,
                generation=generation,
                gate_event=gate_event,
                timeout=28.0,
                request_size_hint=block,
            ))
            pending[offset] = (task, want, generation, gate_event)
            return want

        try:
            _diag_stream(
                'stage=region-producer-start; generation=%s; start_mib=%.2f; '
                'region_inflight=3; shared_limit=3; ahead_mib=%.2f' % (
                    region.generation,
                    float(region.start) / (1024.0 * 1024.0),
                    float(3 * job.direct_reader_ahead_bytes()) / (1024.0 * 1024.0),
                )
            )
            while (pos <= region.end and region.is_current()
                   and not region.retired.is_set()):
                quota = job.direct_region_lane_quota(region)
                if quota <= 0:
                    if pending:
                        await cancel_pending()
                        next_offset = pos
                    await asyncio.sleep(0.05)
                    continue

                ceiling = region.download_ceiling(
                    quota * job.direct_reader_ahead_bytes(),
                )
                if pos >= ceiling:
                    if pending:
                        await cancel_pending()
                        next_offset = pos
                    await asyncio.sleep(0.05)
                    continue

                # Do not cancel already-issued legal blocks merely because a
                # second required reader changed the fair-share quota from 3 to
                # 2/1. That cancellation churn was visible as very low post-seek
                # throughput. The producer simply stops scheduling new work until
                # the outstanding count falls under its current quota.

                while (len(pending) < quota and next_offset < ceiling
                       and next_offset <= region.end
                       and not region.retired.is_set()):
                    want = min(
                        segment,
                        ceiling - next_offset,
                        region.end - next_offset + 1,
                    )
                    if want <= 0:
                        break
                    scheduled = schedule(next_offset)
                    if not scheduled:
                        break
                    next_offset += scheduled

                current = pending.get(pos)
                if current is None:
                    await cancel_pending()
                    next_offset = pos
                    await asyncio.sleep(0.02)
                    continue

                task, wanted, scheduled_generation, _scheduled_gate = current
                data = None
                lost_focus = False
                try:
                    deadline = time.monotonic() + 32.0
                    while (not task.done() and not job.stop.is_set()
                           and not region.retired.is_set()
                           and time.monotonic() < deadline):
                        if job.direct_region_lane_quota(region) <= 0:
                            lost_focus = True
                            break
                        try:
                            data = await asyncio.wait_for(
                                asyncio.shield(task), timeout=0.10,
                            )
                            break
                        except asyncio.TimeoutError:
                            continue
                    if lost_focus or region.retired.is_set() or job.stop.is_set():
                        await cancel_pending()
                        next_offset = pos
                        continue
                    if data is None:
                        if task.done():
                            data = task.result()
                        else:
                            task.cancel()
                            data = b''
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    data = b''
                    job.range_error = repr(exc)

                pending.pop(pos, None)
                if not data:
                    # Promotion changes the generation underneath already
                    # queued tasks. That is cancellation, not a network failure.
                    if scheduled_generation != int(region.generation or 0):
                        await cancel_pending()
                        next_offset = pos
                        continue
                    failures += 1
                    await cancel_pending()
                    next_offset = pos
                    if failures >= 3:
                        raise RuntimeError(
                            'Telegram shared region stalled at offset %s: %s' % (
                                pos, job.range_error,
                            )
                        )
                    await asyncio.sleep(0.25)
                    continue

                failures = 0
                region.error = ''
                data = bytes(data)[:wanted]
                if region.retired.is_set():
                    break
                wrote = region.append(pos, data)
                if wrote <= 0:
                    break
                # Critical Range-before-OnSeek case: the HTTP handler that opened
                # this region still owns stale generation/gate locals. The producer
                # is the authoritative owner of the promoted region and must release
                # the current seek gate once the first legal block is present.
                job.maybe_finish_direct_prebuffer_for_region(region, source='producer')
                pos += wrote
                if wrote < wanted:
                    await cancel_pending()
                    next_offset = pos
            with region.lock:
                region.done = pos > region.end
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            region.error = repr(exc)
            job.range_error = region.error
        finally:
            await cancel_pending()
            region.event.set()
            job.finish_direct_prebuffer(region.generation, region.gate_event)
            job.direct_end()
            elapsed = max(0.001, time.time() - started)
            with region.lock:
                downloaded = max(0, region.cached_end - region.start)
            _diag_stream(
                'stage=region-producer-stop; generation=%s; cached_mib=%.2f; avg_mib_s=%.2f; '
                'done=%s; stopped=%s; error=%s' % (
                    region.generation,
                    float(downloaded) / (1024.0 * 1024.0),
                    float(downloaded) / (1024.0 * 1024.0) / elapsed,
                    bool(region.done), bool(region.stop.is_set() or job.stop.is_set()),
                    bool(region.error),
                )
            )

    def _send_shared_direct_region(self, handler, job, start, end):
        """Serve Android Range readers from the generation-owned shared cache."""
        start = int(start or 0)
        end = int(end or 0)
        # Serialize only synchronization and region creation. This closes the
        # small gap in which two HTTP handler threads could both observe no
        # current region and truncate the same generation cache path.
        with job.direct_range_open_lock:
            sync_result, sync_generation, sync_waited, sync_reason = job.synchronize_direct_range(start)
            if sync_result != 'stopped':
                gate_role, generation, gate_event, reason = job.claim_direct_prebuffer()
                target = job.direct_reader_prime_bytes(gate_role, reason)
                region, created = self._get_or_create_direct_region(
                    job, start, end, generation, gate_event, reason=reason,
                    prebuffer_target=target if gate_role == 'leader' else 0,
                )
                promoted_generation = job.promote_newly_opened_pending_target(region)
                if promoted_generation:
                    gate_role, generation, gate_event, reason = job.claim_direct_prebuffer()
                    target = job.direct_reader_prime_bytes(gate_role, reason)
                    if gate_role == 'leader':
                        region.prebuffer_from = start
                        region.prebuffer_target = max(region.prebuffer_target, int(target or 0))
        _diag_stream(
            'stage=direct-range-sync; result=%s; generation=%s; start_mib=%.2f; '
            'waited_s=%.2f; reason=%s' % (
                sync_result, sync_generation,
                float(start) / (1024.0 * 1024.0), sync_waited,
                str(sync_reason or ''),
            )
        )
        if sync_result == 'stopped':
            self._write_stopped_headers(handler)
            return 0
        # ``target`` was computed before region creation so its producer knows
        # the seek cushion ceiling from its very first scheduling iteration.
        ready_started = time.time()
        sent = 0
        pos = start
        reader_id = region.attach_reader(pos)
        job.direct_reader_begin()
        gate_finished = False
        try:
            # Every reader attaches to the same producer. Only the first one
            # creates Telegram work. Followers wait for that one generation gate,
            # then need only one available Telegram segment at their own offset.
            seek_gate = gate_role == 'leader' and str(reason or '') == 'player-seek'
            ready_timeout = _DIRECT_SEEK_READY_TIMEOUT if seek_gate else 24.0
            if gate_role == 'follower':
                # Followers wait only for the one generation gate. The leader
                # owns the seek cushion and releases it no later than the safe
                # HTTP-silence deadline below.
                gate_deadline = time.monotonic() + _DIRECT_SEEK_READY_TIMEOUT
                while (not gate_event.is_set() and region.is_current()
                       and not job.stop.is_set() and time.monotonic() < gate_deadline):
                    gate_event.wait(0.20)
            ready = region.wait_until(
                start + target,
                timeout=ready_timeout,
            )
            if not region.is_current() or job.stop.is_set():
                self._write_stopped_headers(handler)
                return 0

            with region.lock:
                buffered = max(0, region.cached_end - start)
                finished = bool(region.done or region.error)
            if buffered <= 0 and finished:
                handler.send_error(504, 'Telegram shared region did not return bytes')
                return 0
            if gate_role == 'leader':
                # Release the generation as soon as its one real startup cushion
                # is ready. Previously this happened only when the whole HTTP
                # reader ended, so every concurrent reader rebuilt the cushion.
                job.finish_direct_prebuffer(generation, gate_event)
                gate_finished = True
            _diag_stream(
                'stage=region-reader-ready; generation=%s; created=%s; ready=%s; '
                'start_mib=%.2f; target_mib=%.2f; buffered_mib=%.2f; elapsed_s=%.2f; wait_limit_s=%.1f' % (
                    generation, bool(created), bool(ready),
                    float(start) / (1024.0 * 1024.0),
                    float(target) / (1024.0 * 1024.0),
                    float(buffered) / (1024.0 * 1024.0),
                    time.time() - ready_started, ready_timeout,
                )
            )

            # Commit the large 206 only after bytes are available and Stop can no
            # longer win the header/body race seen in the device log.
            self._write_headers(handler, 206, job, start, end, True)
            last_progress = time.time()
            while pos <= end and region.is_current() and not job.stop.is_set():
                job.touch()
                data = region.read(pos, min(256 * 1024, end - pos + 1))
                if not data:
                    with region.lock:
                        finished = bool(region.done or region.error)
                    if finished:
                        break
                    # This socket has exhausted its cache and is the exact
                    # response Kodi is waiting for. Reclaim all three lanes;
                    # attached responses blocked on socket backpressure never
                    # execute this path.
                    job.focus_direct_region(region)
                    if time.time() - last_progress > 40.0:
                        job.range_error = 'shared direct region reader timeout'
                        break
                    region.event.wait(0.20)
                    region.event.clear()
                    continue
                if not _write_stream_body(
                        handler, data,
                        is_active=lambda: region.is_current() and not job.stop.is_set(),
                        mode='shared-region'):
                    # Do not cancel the producer. Kodi will reconnect and continue
                    # from this same region without downloading it again.
                    break
                pos += len(data)
                sent += len(data)
                region.update_reader(reader_id, pos)
                last_progress = time.time()
            return sent
        finally:
            region.detach_reader(reader_id)
            job.direct_reader_end()
            if gate_role == 'leader' and not gate_finished:
                job.finish_direct_prebuffer(generation, gate_event)
            _diag_stream(
                'stage=region-reader-stop; generation=%s; sent_mib=%.2f; current=%s; job_stop=%s' % (
                    generation, float(sent) / (1024.0 * 1024.0),
                    bool(region.is_current()), bool(job.stop.is_set()),
                )
            )

    def _send_direct_telegram_range(self, handler, job, start, end):
        if _is_android():
            return self._send_shared_direct_region(handler, job, start, end)
        return self._send_direct_telegram_range_legacy(handler, job, start, end)

    def _send_direct_telegram_range_legacy(self, handler, job, start, end):
        """Stream a post-seek open-ended HTTP Range directly from Telegram.

        Windows/Linux keep the field-tested single Telethon iterator. Android
        uses the same bounded 3 x 512 KiB ordered pipeline as the progressive
        cache, because the real device log showed that one request-at-a-time
        could not refill Kodi fast enough after a seek. Bytes are always queued
        and written in strict offset order.
        """
        start = int(start or 0)
        end = int(end or 0)
        stop_event = threading.Event()
        android = _is_android()
        queued_state = {'bytes': 0}
        prebuffer_ready = threading.Event()
        try:
            configured_mb = max(1, min(16, int(job.spec.get('startup_buffer_mb') or 4)))
        except Exception:
            configured_mb = 4

        # Buffer once per playback region, not once per HTTP Range connection.
        # Kodi/FFmpeg opens several overlapping ranges around the same MP4 area.
        # The previous build rebuilt a hard-coded 4 MiB cushion on *every* one,
        # which is exactly the repeated direct-start/direct-ready stall pattern
        # from the real Android log.  The first range after registration/OnSeek
        # now uses the user's existing startup-buffer setting; neighbouring range
        # reconnects stream immediately, matching the stable .57 behaviour.
        gate_role, gate_generation, gate_event, gate_reason = (
            job.claim_direct_prebuffer() if android else ('open', 0, None, '')
        )
        prebuffer_mb = configured_mb if android and gate_role == 'leader' else 0
        prebuffer_target = prebuffer_mb * 1024 * 1024
        segment_bytes = 512 * 1024
        queue_slots = max(24, ((prebuffer_target + segment_bytes - 1) // segment_bytes) + 8)
        q = queue.Queue(maxsize=queue_slots)
        prebuffer_timeout = min(24.0, max(10.0, 8.0 + 2.0 * configured_mb)) if android else 0.0
        direct_started = time.time()

        if android and gate_role == 'follower' and gate_event is not None:
            gate_wait_started = time.time()
            gate_deadline = gate_wait_started + prebuffer_timeout
            while (not gate_event.is_set() and not job.stop.is_set()
                   and job.direct_prebuffer_is_current(gate_generation, gate_event)
                   and time.time() < gate_deadline):
                gate_event.wait(0.20)
            # If a newer *real* seek armed a new generation while this old HTTP
            # probe was waiting, do not start stale Telegram work after the jump.
            if not job.direct_prebuffer_is_current(gate_generation, gate_event):
                _diag_stream(
                    'stage=direct-gate; role=follower; result=stale; reason=%s; elapsed_s=%.2f' % (
                        str(gate_reason or ''), time.time() - gate_wait_started,
                    )
                )
                return 0
            _diag_stream(
                'stage=direct-gate; role=follower; result=%s; reason=%s; elapsed_s=%.2f' % (
                    'ready' if gate_event.is_set() else 'timeout',
                    str(gate_reason or ''), time.time() - gate_wait_started,
                )
            )

        if job.stop.is_set():
            return 0

        def range_is_current():
            # Seek generations are Android-only.  Windows/Linux deliberately keep
            # the proven sequential direct path and have no Android gate event.
            return (not android) or job.direct_prebuffer_is_current(gate_generation, gate_event)

        # Once the region gate opens, FFmpeg may keep or open neighbouring Range
        # readers.  They may coexist under the shared 3-RPC semaphore.  A *real*
        # Player.OnSeek increments gate_generation and invalidates all readers from
        # the previous playback region at once.

        job.direct_begin()
        _diag_stream(
            'stage=direct-start; mode=%s; start_mib=%.2f; prebuffer_mib=%s; gate=%s; reason=%s; inflight=%s; generation=%s' % (
                'android-pipeline' if android else 'sequential',
                float(start) / (1024.0 * 1024.0),
                prebuffer_mb, gate_role, str(gate_reason or ''), 3 if android else 1, gate_generation,
            )
        )

        async def queue_put(item):
            while (not stop_event.is_set() and not job.stop.is_set()
                   and range_is_current()):
                try:
                    q.put_nowait(item)
                    if isinstance(item, (bytes, bytearray, memoryview)):
                        queued_state['bytes'] += len(item)
                        if not prebuffer_target or queued_state['bytes'] >= prebuffer_target:
                            prebuffer_ready.set()
                    else:
                        prebuffer_ready.set()
                    return True
                except queue.Full:
                    await asyncio.sleep(0.03)
            prebuffer_ready.set()
            return False

        async def producer_sequential():
            stream = None
            try:
                client = await self.ensure_client(job.spec)
                total = int(job.total or 0)
                location = self._document_location_from_spec(job.spec)
                if not location:
                    location = await self._refresh_location(client, job.spec)
                if not location:
                    raise RuntimeError('Telegram document location unavailable')
                dc_id = int(job.spec.get('doc_dc_id') or 0) or None
                msg_data = self._message_data_from_spec(job.spec)
                req = 512 * 1024
                if hasattr(client, '_iter_download'):
                    stream = client._iter_download(location, offset=start, request_size=req,
                                                   chunk_size=req, file_size=total or None,
                                                   dc_id=dc_id, msg_data=msg_data)
                else:
                    stream = client.iter_download(location, offset=start, request_size=req,
                                                  chunk_size=req, file_size=total or None,
                                                  dc_id=dc_id)
                pos = start
                while pos <= end and not stop_event.is_set() and not job.stop.is_set():
                    try:
                        chunk = await asyncio.wait_for(stream.__anext__(), timeout=28.0)
                    except StopAsyncIteration:
                        break
                    chunk = chunk.tobytes() if isinstance(chunk, memoryview) else bytes(chunk or b'')
                    if not chunk:
                        break
                    if pos + len(chunk) - 1 > end:
                        chunk = chunk[:max(0, end - pos + 1)]
                    if not chunk:
                        break
                    pos += len(chunk)
                    if not await queue_put(chunk):
                        break
                await queue_put(None)
            except Exception as exc:
                job.range_error = repr(exc)
                await queue_put(exc)
            finally:
                prebuffer_ready.set()
                try:
                    close = getattr(stream, 'close', None)
                    if close:
                        res = close()
                        if asyncio.iscoroutine(res):
                            await res
                except Exception:
                    pass

        async def producer_android():
            segment = 512 * 1024
            max_inflight = 3
            pending = {}
            pos = start
            next_offset = start
            failures = 0

            async def cancel_pending():
                tasks = [entry[0] for entry in pending.values()]
                pending.clear()
                for task in tasks:
                    try:
                        if not task.done():
                            task.cancel()
                    except Exception:
                        pass
                if tasks:
                    await asyncio.gather(*tasks, return_exceptions=True)

            def schedule(offset):
                want = min(segment, max(0, end - offset + 1))
                if want <= 0:
                    return 0
                task = asyncio.create_task(self._fetch_direct_limited(
                    job, offset, want, generation=gate_generation, gate_event=gate_event,
                    timeout=28.0, request_size_hint=segment
                ))
                pending[offset] = (task, want)
                return want

            try:
                while (pos <= end and not stop_event.is_set() and not job.stop.is_set()
                       and range_is_current()):
                    while (len(pending) < max_inflight and next_offset <= end
                           and range_is_current()):
                        want = schedule(next_offset)
                        if not want:
                            break
                        next_offset += want

                    current = pending.get(pos)
                    if current is None:
                        await cancel_pending()
                        next_offset = pos
                        await asyncio.sleep(0.02)
                        continue

                    task, wanted = current
                    if not range_is_current():
                        await cancel_pending()
                        break
                    try:
                        data = None
                        task_deadline = time.time() + 32.0
                        while (not task.done() and not job.stop.is_set()
                               and range_is_current()
                               and time.time() < task_deadline):
                            try:
                                data = await asyncio.wait_for(asyncio.shield(task), timeout=0.25)
                                break
                            except asyncio.TimeoutError:
                                continue
                        if data is None:
                            if task.done():
                                data = task.result()
                            else:
                                task.cancel()
                                data = b''
                    except Exception as exc:
                        data = b''
                        job.range_error = repr(exc)
                        try:
                            if not task.done():
                                task.cancel()
                        except Exception:
                            pass

                    pending.pop(pos, None)
                    if not data:
                        failures += 1
                        await cancel_pending()
                        next_offset = pos
                        if failures >= 3:
                            raise RuntimeError('Telegram direct range stalled at offset %s: %s' % (pos, job.range_error))
                        await asyncio.sleep(0.25)
                        continue

                    failures = 0
                    data = bytes(data)[:wanted]
                    if not data:
                        continue
                    if not await queue_put(data):
                        break
                    pos += len(data)
                    if len(data) < wanted:
                        # A partial leading block invalidates speculative ranges
                        # scheduled after its expected end. Rebuild without holes.
                        await cancel_pending()
                        next_offset = pos

                await cancel_pending()
                await queue_put(None)
            except Exception as exc:
                await cancel_pending()
                job.range_error = repr(exc)
                await queue_put(exc)
            finally:
                # If the HTTP consumer is cancelled (Stop/back), cancel every
                # speculative Telegram range as well.  Leaving these tasks alive
                # was another way the transfer could continue after playback.
                for task, _want in list(pending.values()):
                    try:
                        if not task.done():
                            task.cancel()
                    except Exception:
                        pass
                pending.clear()
                prebuffer_ready.set()

        fut = self.submit_coro(producer_android() if android else producer_sequential())
        sent = 0
        pos = start
        last_rate_time = time.time()
        last_rate_bytes = 0
        last_data = time.time()
        try:
            if android and prebuffer_target:
                # The configured value is the contract: hold this *new region*
                # until that cushion is ready (or until the bounded HTTP-safe
                # timeout is reached).  Subsequent ranges in the same region do
                # not pass this gate again.  The optional background dialog below
                # only mirrors queued_state; it never affects the gate itself.
                prebuffer_deadline = time.time() + prebuffer_timeout
                while (not prebuffer_ready.is_set() and not job.stop.is_set()
                       and range_is_current()
                       and time.time() < prebuffer_deadline):
                    prebuffer_ready.wait(0.20)
                if not range_is_current():
                    stop_event.set()
                job.finish_direct_prebuffer(gate_generation, gate_event)
                _diag_stream(
                    'stage=direct-ready; mode=android-pipeline; queued_mib=%.2f; target_mib=%s; reason=%s; elapsed_s=%.2f' % (
                        float(queued_state['bytes']) / (1024.0 * 1024.0),
                        prebuffer_mb, str(gate_reason or ''), time.time() - direct_started,
                    )
                )

            while (pos <= end and not job.stop.is_set()
                   and range_is_current()):
                job.touch()
                try:
                    item = q.get(timeout=0.50)
                except queue.Empty:
                    if stop_event.is_set() or job.stop.is_set():
                        break
                    if time.time() - last_data > 30.0:
                        try:
                            fflog('[tg-service] [%s] direct stream queue timeout sent=%s pos=%s err=%r' % (_token_tag(job.token), sent, pos, job.range_error), 1)
                        except Exception:
                            pass
                        break
                    continue
                if item is None:
                    break
                if isinstance(item, BaseException):
                    try:
                        fflog('[tg-service] [%s] direct stream producer error sent=%s pos=%s err=%r' % (_token_tag(job.token), sent, pos, item), 1)
                    except Exception:
                        pass
                    break
                data = item
                if not _write_stream_body(
                        handler, data,
                        is_active=lambda: not job.stop.is_set() and range_is_current(),
                        mode='direct-legacy'):
                    try:
                        fflog('[tg-service] [%s] direct stream client closed/cancelled sent=%s pos=%s' % (_token_tag(job.token), sent, pos), 1)
                    except Exception:
                        pass
                    return sent
                n = len(data)
                sent += n
                pos += n
                last_data = time.time()
                now = time.time()
                if now - last_rate_time >= 8.0:
                    delta = max(0, sent - last_rate_bytes)
                    span = max(0.001, now - last_rate_time)
                    _diag_stream(
                        'stage=direct-rate; mode=%s; sent_mib=%.2f; speed_mib_s=%.2f' % (
                            'android-pipeline' if android else 'sequential',
                            float(sent) / (1024.0 * 1024.0),
                            float(delta) / (1024.0 * 1024.0) / span,
                        )
                    )
                    last_rate_time = now
                    last_rate_bytes = sent
        finally:
            stop_event.set()
            if android and gate_role == 'leader':
                # Idempotent safety net: never strand followers if the leader
                # exits before reaching the normal direct-ready path.
                job.finish_direct_prebuffer(gate_generation, gate_event)
            job.direct_end()
            try:
                fut.cancel()
            except Exception:
                pass
            elapsed = max(0.001, time.time() - direct_started)
            _diag_stream(
                'stage=direct-stop; mode=%s; sent_mib=%.2f; avg_mib_s=%.2f; stopped=%s; stale_generation=%s; generation=%s' % (
                    'android-pipeline' if android else 'sequential',
                    float(sent) / (1024.0 * 1024.0),
                    float(sent) / (1024.0 * 1024.0) / elapsed,
                    bool(job.stop.is_set()),
                    bool(android and not range_is_current()),
                    gate_generation,
                )
            )
        return sent

    def _send_from_progressive_cache(self, handler, job, start, end, wait_for_more=True):
        pos = int(start or 0)
        end = int(end or 0)
        sent = 0
        last_progress = time.time()
        while pos <= end and not job.stop.is_set():
            job.touch()
            data = job.read_cached(pos, min(256 * 1024, end - pos + 1))
            if not data:
                if not wait_for_more or job.done or job.failed:
                    break
                # Keep the HTTP reader alive at least as long as the active
                # downloader future is allowed to run. The previous fixed 26 s
                # could close Kodi's response while the >=8 MiB downloader path
                # still legitimately had a 45 s result budget.
                stall_timeout = max(26.0, float(getattr(job, 'fetch_result_timeout', 0.0) or 0.0))
                if time.time() - last_progress > stall_timeout:
                    try:
                        fflog('[tg-service] [%s] cache wait timeout pos=%s cached=%s sent=%s limit=%.1fs' % (_token_tag(job.token), pos, job.cached, sent, stall_timeout), 1)
                    except Exception:
                        pass
                    break
                job.event.wait(0.20)
                job.event.clear()
                continue
            if not _write_stream_body(
                    handler, data,
                    is_active=lambda: not job.stop.is_set(),
                    mode='progressive-cache'):
                # Kodi may open/close several speculative HTTP connections while
                # probing MP4 metadata or after a seek. Do NOT stop the Telegram
                # downloader here; a single closed HTTP request is not a stream
                # cancellation.
                try:
                    fflog('[tg-service] [%s] client closed/cancelled after sent=%s; downloader remains alive' % (_token_tag(job.token), sent), 1)
                except Exception:
                    pass
                return sent
            n = len(data)
            pos += n
            sent += n
            last_progress = time.time()
        return sent

    def _document_location_from_spec(self, spec):
        try:
            from telethon.tl.types import InputDocumentFileLocation
            doc_id = int(spec.get('doc_id') or 0)
            doc_hash = int(spec.get('doc_access_hash') or 0)
            ref = spec.get('doc_file_reference') or ''
            if not (doc_id and doc_hash and ref):
                return None
            ref_bytes = base64.urlsafe_b64decode((str(ref) + '=' * (-len(str(ref)) % 4)).encode('ascii'))
            return InputDocumentFileLocation(doc_id, doc_hash, ref_bytes, '')
        except Exception:
            return None

    async def _refresh_location(self, client, spec):
        try:
            from telethon.tl.types import InputPeerChannel, InputPeerChat
            chat_id = int(spec.get('chat_id') or 0)
            access_hash = int(spec.get('access_hash') or 0)
            peer_type = (spec.get('peer_type') or '').lower()
            if peer_type in ('chat', 'group') and chat_id:
                entity = InputPeerChat(chat_id)
            elif chat_id and access_hash:
                entity = InputPeerChannel(chat_id, access_hash)
            else:
                entity = spec.get('chat_ref') or chat_id
            msg = await client.get_messages(entity, ids=int(spec.get('message_id') or 0))
            doc = getattr(getattr(msg, 'media', None), 'document', None)
            if not doc:
                return None
            spec['doc_id'] = str(getattr(doc, 'id', '') or '')
            spec['doc_access_hash'] = str(getattr(doc, 'access_hash', '') or '')
            ref_bytes = getattr(doc, 'file_reference', b'') or b''
            if ref_bytes:
                spec['doc_file_reference'] = base64.urlsafe_b64encode(ref_bytes).decode('ascii').rstrip('=')
            spec['doc_dc_id'] = str(getattr(doc, 'dc_id', '') or '')
            try:
                real_size = int(getattr(doc, 'size', 0) or 0)
                if real_size > 0:
                    spec['size'] = real_size
            except Exception:
                pass
            try:
                mime = getattr(doc, 'mime_type', '') or ''
                if mime:
                    spec['mime'] = mime
            except Exception:
                pass
            try:
                from telethon.tl.types import DocumentAttributeFilename
                for attr in getattr(doc, 'attributes', []) or []:
                    if isinstance(attr, DocumentAttributeFilename) and getattr(attr, 'file_name', None):
                        spec['filename'] = attr.file_name
                        break
            except Exception:
                pass
            return self._document_location_from_spec(spec)
        except Exception:
            fflog_exc(1)
            return None

    def _message_data_from_spec(self, spec):
        try:
            from telethon.tl.types import InputPeerChannel, InputPeerChat
            chat_id = int((spec or {}).get('chat_id') or 0)
            msg_id = int((spec or {}).get('message_id') or 0)
            if not (chat_id and msg_id):
                return None
            access_hash = int((spec or {}).get('access_hash') or 0)
            peer_type = ((spec or {}).get('peer_type') or '').lower()
            if peer_type in ('chat', 'group'):
                peer = InputPeerChat(chat_id)
            elif access_hash:
                peer = InputPeerChannel(chat_id, access_hash)
            else:
                peer = (spec or {}).get('chat_ref') or chat_id
            return (peer, msg_id)
        except Exception:
            return None

    async def fetch_range(self, job, offset, want, timeout=18.0, on_chunk=None, request_size_hint=None):
        """Fetch a contiguous Telegram byte range with Telethon's downloader.

        The previous service used a manual upload.getFile call with
        cdn_supported=False. Many large Telegram videos are served through the
        CDN path; Telethon's internal downloader already handles FileCdnRedirect,
        FileMigrate and file_reference refresh. Use that instead of reimplementing
        the raw file protocol.
        """
        client = await self.ensure_client(job.spec)
        offset = int(max(0, offset or 0))
        want = int(max(1, want or 0))
        total = int(job.total or 0)
        if total:
            want = min(want, max(0, total - offset))
        if want <= 0:
            return b''

        location = self._document_location_from_spec(job.spec)
        if not location:
            location = await self._refresh_location(client, job.spec)
        if not location:
            raise RuntimeError('Telegram document location unavailable')
        dc_id = int(job.spec.get('doc_dc_id') or 0) or None
        msg_data = self._message_data_from_spec(job.spec)

        # Small requests are good for the first byte, but sparse MP4 tail
        # probes must not be split into dozens of tiny Telegram requests.  With
        # tgcrypto_ctypes the decryption bottleneck is gone, so use larger pieces
        # for non-prefix/range fetches to reduce round-trip overhead.
        if request_size_hint:
            # Progressive Android pipeline uses aligned 512 KiB parts.  A hint
            # changes only request granularity; the legal-size guard below still
            # applies to short final parts and arbitrary sparse Kodi probes.
            req = int(request_size_hint)
        elif offset < 1024 * 1024 and want <= 512 * 1024:
            req = 128 * 1024
        elif want >= 1024 * 1024:
            # Telegram's practical request ceiling is 512 KiB.  Use it for
            # larger reads so a single downloader stream yields fewer chunks.
            req = 512 * 1024
        else:
            req = 256 * 1024
        # upload.getFile accepts only request limits which divide a 1 MiB
        # Telegram file block. An arbitrary Kodi probe such as 250000 bytes
        # must therefore not become 249856 (LIMIT_INVALID). Pick the largest
        # legal Telegram request size which does not exceed the preferred size.
        preferred_req = min(req, max(4096, want))
        req = 4096
        for legal_req in (512 * 1024, 256 * 1024, 128 * 1024,
                          64 * 1024, 32 * 1024, 16 * 1024,
                          8 * 1024, 4 * 1024):
            if legal_req <= preferred_req:
                req = legal_req
                break

        stream = None
        out = []
        got = 0
        try:
            if hasattr(client, '_iter_download'):
                stream = client._iter_download(location, offset=offset, request_size=req,
                                               chunk_size=req, file_size=total or None,
                                               dc_id=dc_id, msg_data=msg_data)
            else:
                stream = client.iter_download(location, offset=offset, request_size=req,
                                              chunk_size=req, file_size=total or None,
                                              dc_id=dc_id)
            while got < want:
                try:
                    chunk = await asyncio.wait_for(stream.__anext__(), timeout=float(timeout or 18.0))
                except StopAsyncIteration:
                    break
                except Exception as exc:
                    # Do not throw away bytes already received in this range just
                    # because the final Telethon chunk timed out/disconnected.
                    # Returning the contiguous prefix lets the progressive cache
                    # advance; the next call continues exactly at the new offset.
                    if got > 0:
                        try:
                            job.log('range partial return offset=%s got=%s want=%s err=%r' % (offset, got, want, exc))
                        except Exception:
                            pass
                        break
                    raise
                if isinstance(chunk, memoryview):
                    chunk = chunk.tobytes()
                else:
                    chunk = bytes(chunk or b'')
                if not chunk:
                    break
                need = want - got
                if len(chunk) > need:
                    chunk = chunk[:need]
                if on_chunk is not None:
                    # Publish this exact contiguous prefix before waiting for the
                    # next Telegram chunk. Existing sparse/direct callers pass no
                    # sink and retain their original behaviour.
                    on_chunk(offset + got, chunk)
                out.append(chunk)
                got += len(chunk)
                if got >= want:
                    break
            data = b''.join(out)
            if not data:
                raise RuntimeError('Telethon downloader returned no bytes')
            return data
        finally:
            try:
                close = getattr(stream, 'close', None)
                if close:
                    res = close()
                    if asyncio.iscoroutine(res):
                        await res
            except Exception:
                pass

    def _retire_job_async(self, token, job, reason=''):
        """Delete a stopped job/cache only after its workers have quiesced.

        Stop must return to Kodi immediately.  Cleanup therefore runs in a daemon
        thread, but it never removes the growing cache while the progressive
        worker or an active direct Range request can still be using it.  On
        Windows a short-lived open file handle is retried instead of leaked for
        the rest of the Kodi session.
        """
        if not job:
            return
        try:
            marker = getattr(job, '_cleanup_scheduled', None)
            if marker is None:
                marker = threading.Event()
                job._cleanup_scheduled = marker
            if marker.is_set():
                return
            marker.set()
        except Exception:
            pass

        def worker():
            deadline = time.time() + 60.0
            cleaned = False
            while time.time() < deadline:
                try:
                    start_thread = getattr(job, 'start_thread', None)
                    worker_alive = bool(start_thread and start_thread.is_alive())
                except Exception:
                    worker_alive = False
                try:
                    with job.direct_lock:
                        direct_active = int(job.direct_count or 0) > 0
                except Exception:
                    direct_active = False
                try:
                    connection_active = job.active_connection_count() > 0
                except Exception:
                    connection_active = False
                if not worker_alive and not direct_active and not connection_active:
                    # Give already-running HTTP handlers a tiny grace period to
                    # return from their final read after job.stop was signalled.
                    time.sleep(0.25)
                    if job.cleanup_cache_file():
                        cleaned = True
                        break
                time.sleep(0.20)
            try:
                with self.jobs_lock:
                    if self.jobs.get(token) is job:
                        self.jobs.pop(token, None)
            except Exception:
                pass
            if cleaned:
                _diag_stream(
                    'stage=cache-cleanup; reason=%s; result=ok' %
                    str(reason or 'player-stop').replace(';', '_')
                )
            else:
                # A still-open Windows handle is left for the existing bounded
                # service cache cleaner rather than risking deletion mid-read.
                _diag_stream(
                    'stage=cache-cleanup; reason=%s; result=deferred' %
                    str(reason or 'player-stop').replace(';', '_')
                )
                try:
                    _cleanup_stream_cache(max_bytes=768 * 1024 * 1024, max_age=24 * 3600)
                except Exception:
                    pass

        threading.Thread(
            target=worker, name='KadrPlusTGServiceCleanup', daemon=True
        ).start()

    def stop_job(self, token, reason=''):
        """Stop one registered stream without shutting the persistent service."""
        token = str(token or '')
        if not token:
            return False
        with self.jobs_lock:
            job = self.jobs.get(token)
        if not job:
            return False
        already = job.stop.is_set()
        job.request_stop()
        self._retire_job_async(token, job, reason=reason or 'player-stop')
        if not already:
            try:
                job.log('stop requested reason=%r cached=%s' % (reason or '', job.cached))
            except Exception:
                pass
            _diag_stream(
                'stage=stop-request; reason=%s; cached_mib=%.2f' % (
                    str(reason or 'player-stop').replace(';', '_'),
                    float(job.cached or 0) / (1024.0 * 1024.0),
                )
            )
        return True

    def stop_all(self):
        try:
            with self.jobs_lock:
                for job in self.jobs.values():
                    try:
                        job.request_stop()
                    except Exception:
                        pass
                    try:
                        job.cleanup_cache_file()
                    except Exception:
                        pass
                self.jobs.clear()
            _cleanup_stream_cache(max_bytes=256 * 1024 * 1024, max_age=0)
        except Exception:
            pass
        try:
            if self.server:
                self.server.shutdown()
        except Exception:
            pass
        try:
            if self.loop:
                async def _disc():
                    if self.client:
                        await self.client.disconnect()
                try:
                    self.submit_coro(_disc()).result(timeout=5.0)
                except Exception:
                    pass
                self.loop.call_soon_threadsafe(self.loop.stop)
        except Exception:
            pass


def start_service(preferred_port=0, monitor=None):
    global _SERVICE
    with _SERVICE_LOCK:
        if _SERVICE and _SERVICE.running:
            return _SERVICE.port
        _SERVICE = TelegramStreamService(preferred_port=preferred_port)
        return _SERVICE.start(monitor=monitor)


def ensure_service(preferred_port=0):
    return start_service(preferred_port=preferred_port, monitor=None)


def _stream_job_from_url(url):
    """Resolve one localhost /stream/<token>/ URL to the live service job."""
    service = _SERVICE
    if not service or not url:
        return service, '', None
    try:
        parsed = urlparse(str(url))
        if parsed.hostname not in ('127.0.0.1', 'localhost', '::1'):
            return service, '', None
        if parsed.port and int(parsed.port) != int(service.port or 0):
            return service, '', None
        parts = [unquote(part) for part in (parsed.path or '').split('/') if part]
        if len(parts) < 2 or parts[0] != 'stream':
            return service, '', None
        token = parts[1]
        with service.jobs_lock:
            return service, token, service.jobs.get(token)
    except Exception:
        return service, '', None


def stop_stream_url(url, reason='player-stop'):
    """Stop the registered job referenced by a Kadr+ local Telegram URL."""
    service, token, job = _stream_job_from_url(url)
    if not service or not token or not job:
        return False
    try:
        return bool(service.stop_job(token, reason=reason))
    except Exception:
        return False


def stream_reached_eof(url):
    """Return exact Telegram EOF state, or ``None`` if the job is unavailable."""
    service, token, job = _stream_job_from_url(url)
    if not service or not token or not job:
        return None
    try:
        return bool(job.reached_media_eof())
    except Exception:
        return None


def mark_stream_seek(url, reason='player-seek', target_progress=None):
    """Record Player.OnSeek for diagnostics; HTTP Range remains authoritative."""
    service, token, job = _stream_job_from_url(url)
    if not service or not token or not job or not _is_android():
        return False
    try:
        result, generation = job.mark_direct_seek(
            reason=reason or 'player-seek', target_progress=target_progress,
        )
        _diag_stream(
            'stage=direct-seek-notification; result=%s; reason=%s; generation=%s; target_progress=%s' % (
                result, str(reason or 'player-seek').replace(';', '_'), generation,
                ('%.1f' % float(target_progress)) if target_progress is not None else 'unknown',
            )
        )
        return result != 'ignored'
    except Exception:
        return False


def stop_service():
    global _SERVICE
    with _SERVICE_LOCK:
        if _SERVICE:
            try:
                _SERVICE.stop_all()
            except Exception:
                pass
            _SERVICE = None
        try:
            st = status_path()
            if os.path.exists(st):
                os.remove(st)
        except Exception:
            pass


def register_with_service(spec, preferred_port=0, timeout=35.0):
    """Client-side helper used by the source resolver.

    It talks to the persistent service if available. As a rescue path it may
    start the service inside the current interpreter, but normal operation should
    be service.py -> start_service().
    """
    try:
        import requests
        port = int((_read_status() or {}).get('port') or 0)
        if port:
            try:
                r = requests.get('http://127.0.0.1:%d/ping' % port, timeout=1.2)
                if r.status_code != 200:
                    port = 0
            except Exception:
                port = 0
        if not port:
            port = ensure_service(preferred_port=preferred_port)
            # Give HTTP thread a tiny moment to bind/write status.
            time.sleep(0.25)
        if not port:
            return {'ok': False, 'error': 'Telegram stream service is not running'}
        r = requests.post('http://127.0.0.1:%d/control/register' % port, data=json.dumps(spec or {}).encode('utf-8'),
                          headers={'Content-Type': 'application/json; charset=utf-8'}, timeout=float(timeout or 35.0))
        try:
            data = r.json()
        except Exception:
            data = {'ok': False, 'error': r.text[:300]}
        return data
    except Exception as exc:
        fflog_exc(1)
        return {'ok': False, 'error': repr(exc)}
