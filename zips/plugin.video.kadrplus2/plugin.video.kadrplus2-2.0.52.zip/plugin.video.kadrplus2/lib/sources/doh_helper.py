# -*- coding: utf-8 -*-
"""DoH and Firefox-like TLS transport used by the classic Kadr+ FilmPalast scraper.

Only DNS resolution of the TCP destination is replaced.  The URL, Host header
and TLS SNI keep the original FilmPalast hostname.
"""

import socket
import ssl
import threading

import requests
import requests.adapters
import urllib3


urllib3.disable_warnings()

_FIREFOX_CIPHERS = ':'.join([
    'TLS_AES_128_GCM_SHA256',
    'TLS_CHACHA20_POLY1305_SHA256',
    'TLS_AES_256_GCM_SHA384',
    'ECDHE-ECDSA-AES128-GCM-SHA256',
    'ECDHE-RSA-AES128-GCM-SHA256',
    'ECDHE-ECDSA-CHACHA20-POLY1305',
    'ECDHE-RSA-CHACHA20-POLY1305',
    'ECDHE-ECDSA-AES256-GCM-SHA384',
    'ECDHE-RSA-AES256-GCM-SHA384',
    'ECDHE-ECDSA-AES256-SHA',
    'ECDHE-ECDSA-AES128-SHA',
    'ECDHE-RSA-AES128-SHA',
    'ECDHE-RSA-AES256-SHA',
    'DHE-RSA-AES128-SHA',
    'DHE-RSA-AES256-SHA',
    'AES128-SHA',
    'AES256-SHA',
    'DES-CBC3-SHA',
])

_doh_cache = {}
_cache_lock = threading.Lock()
_socket_patch_lock = threading.RLock()


def doh_resolve(host):
    """Resolve a hostname through Cloudflare DNS-over-HTTPS."""
    parts = str(host or '').split('.')
    domain = '.'.join(parts[-2:]) if len(parts) >= 2 else str(host or '')
    if not domain:
        return None

    with _cache_lock:
        if domain in _doh_cache:
            return _doh_cache[domain]

    try:
        response = requests.get(
            'https://cloudflare-dns.com/dns-query',
            params={'name': domain, 'type': 'A'},
            headers={'accept': 'application/dns-json'},
            timeout=8,
            verify=False,
        )
        if response.status_code == 200:
            data = response.text
            index = data.find('"data":"')
            if index >= 0:
                ip = data[index + 8:data.find('"}', index)]
                if ip and ip.replace('.', '').isdigit():
                    with _cache_lock:
                        _doh_cache[domain] = ip
                    return ip
    except Exception:
        pass
    return None


def _make_firefox_ssl_context():
    try:
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        context.set_ciphers(_FIREFOX_CIPHERS)
        return context
    except Exception:
        return None


class _DoHMixin:
    def send(self, request, **kwargs):
        from urllib.parse import urlsplit

        host = urlsplit(request.url).hostname
        ip = doh_resolve(host) if host else None
        if not ip:
            return super().send(request, **kwargs)

        # getaddrinfo is process-global.  The classic implementation patched it
        # for the duration of send(); the lock makes that behavior thread-safe.
        with _socket_patch_lock:
            original = socket.getaddrinfo

            def patched(name, port, *args, **kw):
                if name == host:
                    return original(ip, port, *args, **kw)
                return original(name, port, *args, **kw)

            socket.getaddrinfo = patched
            try:
                return super().send(request, **kwargs)
            finally:
                socket.getaddrinfo = original


class _FirefoxHTTPSAdapter(_DoHMixin, requests.adapters.HTTPAdapter):
    def __init__(self, ssl_context=None, *args, **kwargs):
        self._ssl_context = ssl_context or _make_firefox_ssl_context()
        super().__init__(*args, **kwargs)

    def init_poolmanager(self, *args, **kwargs):
        if self._ssl_context:
            kwargs['ssl_context'] = self._ssl_context
        return super().init_poolmanager(*args, **kwargs)

    def proxy_manager_for(self, proxy, **kwargs):
        if self._ssl_context:
            kwargs['ssl_context'] = self._ssl_context
        return super().proxy_manager_for(proxy, **kwargs)


class _HTTPDoHAdapter(_DoHMixin, requests.adapters.HTTPAdapter):
    pass


def make_doh_session():
    """Return the same raw requests session strategy used by classic Kadr+."""
    session = requests.Session()
    session.mount('https://', _FirefoxHTTPSAdapter())
    session.mount('http://', _HTTPDoHAdapter())
    return session
