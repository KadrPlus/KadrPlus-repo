# -*- coding: utf-8 -*-
"""Kadr+ 2.0 – AIOStreams provider for the FanFilm 2026 source engine."""
from __future__ import annotations

import re
from typing import Any, ClassVar, Sequence
from urllib.parse import urlparse

from lib.ff import requests
from lib.ff.log_utils import fflog, fflog_exc
from lib.ff.settings import settings
from lib.ff import source_utils


class source:
    priority: ClassVar[int] = 1
    language: ClassVar[Sequence[str]] = ('pl', 'en', 'de', 'mul')
    has_sort_order: ClassVar[bool] = True
    has_color_identify2: ClassVar[bool] = True
    has_library_color_identify2: ClassVar[bool] = True
    use_premium_color: ClassVar[bool] = False

    _BAD_FILE = re.compile(
        r'\b(?:exe|zip|iso|mp3|rar|epub|wav|flac|trailer|tlr|soundtrack|sample)\b',
        re.IGNORECASE,
    )
    _SERVICE_SHORT = {
        'realdebrid': 'RD', 'alldebrid': 'AD', 'premiumize': 'PM',
        'debridlink': 'DL', 'torbox': 'TB', 'easydebrid': 'ED',
        'offcloud': 'OC', 'pikpak': 'PP',
    }

    def __init__(self) -> None:
        self.session: requests.Session | None = None
        self.base_url = ''
        self.username = ''
        self.password = ''

    def init(self) -> bool:
        if self.session is not None:
            return bool(self.base_url)
        try:
            instance = settings.getInt('aio.instance')
        except Exception:
            instance = 0
        try:
            self.base_url = settings.getString(f'aio.aio_url.{instance}').strip().rstrip('/')
            self.username = settings.getString(f'aio.username.{instance}').strip()
            self.password = settings.getString(f'aio.password.{instance}').strip()
        except Exception:
            fflog_exc()
            self.base_url = ''
        if not self.base_url:
            fflog('AIOStreams: brak skonfigurowanego adresu instancji')
            return False
        self.session = requests.Session()
        self.session.headers.update({'Accept': 'application/json', 'User-Agent': source_utils.DEFAULT_UA})
        fflog(f'AIOStreams: instancja {instance}, URL={self.base_url}')
        return True

    @staticmethod
    def _quality(value: Any, filename: str = '') -> str:
        text = f'{value or ""} {filename}'.lower()
        digits = ''.join(ch for ch in str(value or '') if ch.isdigit())
        try:
            height = int(digits)
        except ValueError:
            height = 0
        if height >= 2160 or re.search(r'\b(?:2160p?|4k|uhd)\b', text):
            return '4K'
        if height >= 1440:
            return '2K'
        if height >= 1080 or '1080' in text:
            return '1080p'
        if height >= 720 or '720' in text:
            return '720p'
        return 'SD'

    @staticmethod
    def _language(parsed: dict[str, Any], filename: str) -> tuple[str, str]:
        detected_lang, detected_info = source_utils.get_lang_by_type(filename)
        raw = parsed.get('languages') or []
        if isinstance(raw, str):
            raw = [raw]
        langs = {str(x).strip().lower() for x in raw if x}
        if langs & {'pl', 'pol', 'polish', 'polski'}:
            return 'pl', detected_info
        if langs & {'de', 'deu', 'ger', 'german', 'deutsch'}:
            return 'de', detected_info
        if len(langs) > 1 or langs & {'multi', 'mul'}:
            return 'mul', detected_info
        if detected_lang:
            return detected_lang, detected_info
        return 'en', detected_info

    @staticmethod
    def _size_text(size: Any) -> str:
        try:
            value = int(size or 0)
        except (TypeError, ValueError):
            return ''
        if value < 50 * 1024 * 1024:
            return ''
        return source_utils.convert_size(value)

    def _search(self, media_type: str, media_id: str) -> list[dict[str, Any]]:
        if not self.init() or self.session is None:
            return []
        try:
            timeout = max(5, min(settings.getInt('scrapers.timeout.1') or 15, 45))
            auth = (self.username, self.password) if self.username else None
            response = self.session.get(
                f'{self.base_url}/api/v1/search',
                params={'type': media_type, 'id': media_id},
                auth=auth,
                timeout=timeout,
                verify=False,
            )
            if not response.ok:
                fflog(f'AIOStreams: HTTP {response.status_code}')
                return []
            data = response.json()
            if not data.get('success'):
                error = data.get('error') or {}
                fflog(f'AIOStreams: błąd API: {error.get("message") or error}')
                return []
            results = (data.get('data') or {}).get('results') or []
            fflog(f'AIOStreams: znaleziono {len(results)} wyników')
            return [item for item in results if isinstance(item, dict)]
        except Exception:
            fflog_exc()
            return []

    def _to_sources(self, results: list[dict[str, Any]]) -> list[dict[str, Any]]:
        output: list[dict[str, Any]] = []
        try:
            max_sources = settings.getInt('aio.max_sources')
        except Exception:
            max_sources = 0
        trash_not_cached = settings.getBool('aio.trash_not_cached')
        show_indexer = settings.getBool('aio.display_addon_indexer')

        for item in results:
            if max_sources and len(output) >= max_sources:
                break
            try:
                item_type = str(item.get('type') or '').lower()
                if 'info' in item_type:
                    continue
                service = str(item.get('service') or '')
                if 'p2p' in item_type and not service:
                    continue
                url = str(item.get('url') or item.get('externalUrl') or '')
                if not url:
                    continue
                parsed = item.get('parsedFile') or {}
                if not isinstance(parsed, dict):
                    parsed = {}
                filename = str(item.get('filename') or parsed.get('title') or '')
                if self._BAD_FILE.search(filename.replace('_', ' ')):
                    continue
                size = self._size_text(item.get('size'))
                if not size:
                    continue
                quality = self._quality(parsed.get('resolution'), filename)
                language, lang_info = self._language(parsed, filename)
                cached = bool(item.get('cached'))
                service_key = service.lower().replace('-', '').replace('_', '')
                short = self._SERVICE_SHORT.get(service_key, service[:3].upper())
                indexer = str(item.get('addon') or item.get('indexer') or '')
                hosting = (indexer if show_indexer and indexer else short) or (urlparse(url).hostname or 'AIO')
                tags = [x for x in (lang_info, size) if x]
                state = ''
                if service:
                    state = f'{short} cached' if cached else short
                    if not cached and trash_not_cached:
                        state += ' (not cached)'
                if item_type == 'usenet':
                    state = f'{state} usenet'.strip()
                elif item_type == 'p2p':
                    state = f'{state} p2p'.strip()
                output.append({
                    'source': hosting.replace(' ', '_').replace('|', '_'),
                    'quality': quality,
                    'language': language,
                    'url': url,
                    'info': ' | '.join(tags),
                    'info2': state,
                    'size': size,
                    'filename': filename,
                    'direct': True,
                    'debridonly': False,
                    'on_account': bool(item.get('library')),
                    'premium': bool(service),
                })
            except Exception:
                fflog_exc()
        return output

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list, year: str, **kwargs):
        ids = getattr(self.ffitem, 'ids', {})
        return {'imdb': imdb or ids.get('imdb', ''), 'tmdb': str(ids.get('tmdb') or ''), 'type': 'movie'}

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list, year: str, **kwargs):
        ids = getattr(self.ffitem, 'ids', {})
        return {'imdb': imdb or ids.get('imdb', ''), 'tmdb': str(ids.get('tmdb') or ''), 'type': 'series'}

    def episode(self, url: dict | None, imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str):
        if not url:
            return None
        data = dict(url)
        data.update({'season': season, 'episode': episode})
        return data

    def sources(self, url: dict | None, hostDict: list[str], hostprDict: list[str], from_cache: bool = False):
        if not url:
            return []
        imdb = str(url.get('imdb') or '')
        tmdb = str(url.get('tmdb') or '')
        identifier = imdb if imdb not in {'', '0', '-', 'None'} else (f'tmdb:{tmdb}' if tmdb else '')
        if not identifier:
            return []
        if url.get('type') == 'series':
            identifier = f'{identifier}:{url.get("season")}:{url.get("episode")}'
        return self._to_sources(self._search(str(url.get('type') or 'movie'), identifier))

    def resolve(self, url: str, **kwargs) -> str:
        return url
