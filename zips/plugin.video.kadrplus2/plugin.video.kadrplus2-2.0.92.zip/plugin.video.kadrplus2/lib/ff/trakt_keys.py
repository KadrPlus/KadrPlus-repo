"""Profile-local Trakt application keys. Copyright (C) 2026 divoff — MIT.

AES-256-CTR with encrypt-then-MAC (HMAC-SHA256), random IVs and separate keys.
The profile key protects against accidental disclosure of settings/backup XML;
it cannot protect against someone who can read the entire Kodi profile.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
from pathlib import Path
from functools import lru_cache
from threading import RLock
from time import monotonic
import uuid

from xbmcaddon import Addon
from xbmcvfs import translatePath
from .profile_lock import profile_lock

MIGRATION = 'trakt-app-keys-reset-2026-09-v1'
FIELDS = ('trakt.client_key', 'trakt.secret_key')
_CACHE_SECONDS = 2.0
_cache_lock = RLock()
_cache_profile = None
_cache_until = 0.0
_cache_pair = ('', '')
_cache_error = None
_last_error_log = None


@lru_cache(maxsize=1)
def _profile():
    return Path(translatePath(Addon().getAddonInfo('profile')))


def _locked(profile):
    """Serialize the plugin and service interpreters on Android and Windows."""
    return profile_lock(profile, 'trakt_keys.lock')


def _atomic(path, data):
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        fd = os.open(str(temp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'wb') as out:
            out.write(data)
            out.flush()
            os.fsync(out.fileno())
        os.replace(str(temp), str(path))
    finally:
        if temp.exists():
            temp.unlink()


def _read(profile):
    path = profile / 'trakt_keys.json'
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding='utf-8'))
    if (not isinstance(data, dict) or (data and not isinstance(data.get('keys'), dict))
            or any(field not in FIELDS or not isinstance(value, str)
                   for field, value in data.get('keys', {}).items())):
        raise ValueError('Invalid Trakt key storage')
    return data


def _save(profile, data):
    _atomic(profile / 'trakt_keys.json', json.dumps(data, sort_keys=True).encode('utf-8'))


def _master(profile, *, create=False):
    path = profile / 'trakt_keys.key'
    if not path.exists() and create:
        if any(_read(profile).get('keys', {}).values()):
            raise OSError('Missing profile encryption key')
        _atomic(path, os.urandom(64))
    key = path.read_bytes()
    if len(key) != 64:
        raise ValueError('Invalid profile encryption key')
    return key


def _encrypt(value, field, key):
    if not value:
        return ''
    from pyaes.aes import AESModeOfOperationCTR, Counter
    iv = os.urandom(16)
    cipher = AESModeOfOperationCTR(key[:32], counter=Counter(int.from_bytes(iv, 'big')))
    payload = iv + cipher.encrypt(value.encode('utf-8'))
    mac = hmac.new(key[32:], b'kadr-trakt-v1\0' + field.encode('ascii') + payload, hashlib.sha256).digest()
    return 'v1:' + base64.b64encode(payload + mac).decode('ascii')


def _decrypt(value, field, key):
    if not value:
        return ''
    if not value.startswith('v1:'):
        raise ValueError('Unknown Trakt key format')
    raw = base64.b64decode(value[3:], validate=True)
    if len(raw) < 49:
        raise ValueError('Invalid encrypted Trakt key')
    payload, mac = raw[:-32], raw[-32:]
    expected = hmac.new(key[32:], b'kadr-trakt-v1\0' + field.encode('ascii') + payload, hashlib.sha256).digest()
    if not hmac.compare_digest(mac, expected):
        raise ValueError('Trakt key integrity check failed')
    from pyaes.aes import AESModeOfOperationCTR, Counter
    cipher = AESModeOfOperationCTR(key[:32], counter=Counter(int.from_bytes(payload[:16], 'big')))
    return cipher.decrypt(payload[16:]).decode('utf-8')


def _clear_oauth(addon):
    for field in ('trakt.token', 'trakt.internal'):
        if addon.getSetting(field):
            addon.setSetting(field, '')


def invalidate():
    """Forget decrypted app keys after edits; OAuth tokens are never cached here."""
    global _cache_until, _cache_error
    with _cache_lock:
        _cache_until = 0.0
        _cache_error = None


def report_error(exc):
    """Keep storage failures visible without developer logging or any secrets."""
    global _last_error_log
    now = monotonic()
    if _last_error_log is None or now - _last_error_log >= 30:
        from .log_utils import log
        log.warning(f'[TRAKT] Key storage unavailable ({type(exc).__name__})')
        _last_error_log = now


def migrate():
    """Clear old app keys once, before any request or new key entry.

    Marker lives in the profile, independently of addon.version and settings.xml.
    Do not silently overwrite damaged storage: that could trigger a second reset.
    """
    profile = _profile()
    with _locked(profile):
        data = _read(profile)
        addon = Addon()
        if data.get('migration') != MIGRATION:
            if data:
                raise ValueError('Unrecognized Trakt key migration state')
            for field in FIELDS + ('trakt.token', 'trakt.internal'):
                if addon.getSetting(field):
                    addon.setSetting(field, '')
                if addon.getSetting(field):
                    raise OSError('Could not clear legacy Trakt credentials')
            data = {'migration': MIGRATION, 'notice_pending': True, 'keys': {}}
            _save(profile, data)
        # A legacy settings restore/manual edit after migration must be encrypted,
        # never reset, including a manually entered former bundled key. Removal
        # of bundled defaults is a one-time migration, not a blacklist of values.
        # Store durably before removing the plaintext XML value.
        for field in FIELDS:
            value = addon.getSetting(field).strip()
            if value:
                previous = _decrypt(data['keys'].get(field, ''), field, _master(profile, create=True))
                if value != previous:
                    data['keys'][field] = _encrypt(value, field, _master(profile))
                    _save(profile, data)
                    _clear_oauth(addon)
                addon.setSetting(field, '')
    invalidate()
    return data


def credentials():
    """Read an atomic snapshot, with no disk writes/locks on ordinary API calls."""
    global _cache_profile, _cache_until, _cache_pair, _cache_error
    profile = _profile()
    with _cache_lock:
        if _cache_profile == profile and monotonic() < _cache_until:
            if _cache_error:
                raise ValueError('Trakt key storage unavailable')
            return _cache_pair
        try:
            data = _read(profile)
            # The slow path also accepts a restored legacy settings XML, even
            # when the background service has not received its callback yet.
            addon = Addon()
            legacy_values = any(addon.getSetting(field).strip() for field in FIELDS)
            if data.get('migration') != MIGRATION or legacy_values:
                data = migrate()
            values = data.get('keys', {})
            if any(values.values()):
                key = _master(profile)
                pair = tuple(_decrypt(values.get(field, ''), field, key) for field in FIELDS)
            else:
                pair = ('', '')
        except Exception:
            _cache_pair, _cache_error = ('', ''), True
            _cache_profile, _cache_until = profile, monotonic() + _CACHE_SECONDS
            raise
        _cache_pair, _cache_error = pair, None
        _cache_profile, _cache_until = profile, monotonic() + _CACHE_SECONDS
        return pair


def set_key(field, value):
    if field not in FIELDS:
        raise ValueError('Unknown Trakt key')
    value = value.strip()
    migrate()
    profile = _profile()
    with _locked(profile):
        data = _read(profile)
        key = _master(profile, create=True)
        if _decrypt(data['keys'].get(field, ''), field, key) == value:
            return
        data['keys'][field] = _encrypt(value, field, key)
        _save(profile, data)
        # OAuth tokens are tied to the old app pair; history/progress stay intact.
        _clear_oauth(Addon())
    invalidate()


def show_migration_notice():
    from xbmcgui import Dialog
    from ..kolang import L
    if not migrate().get('notice_pending'):
        return
    Dialog().ok('Kadr+ — Trakt.tv', L(33201,
        'Old Trakt application keys have been removed. '
        'To use Trakt.tv, enter your own Client ID and Client Secret in Settings → Accounts, keys and authorizations → Own API keys, then authorize again. '
        'Keys entered now will be encrypted and retained during future updates. '
        'New default keys will be added when Trakt reopens app registration for free accounts.'))
    profile = _profile()
    with _locked(profile):
        data = _read(profile)
        data['notice_pending'] = False
        _save(profile, data)


def edit_key(field):
    from xbmcgui import Dialog, INPUT_ALPHANUM, ALPHANUM_HIDE_INPUT
    from ..kolang import L
    try:
        migrate()
        heading = L(30201, 'Trakt Client ID') if field == FIELDS[0] else L(30202, 'Trakt Client Secret')
        value = Dialog().input(heading, type=INPUT_ALPHANUM, option=ALPHANUM_HIDE_INPUT)
        if not value:  # Cancel must never erase an existing key.
            return False
        set_key(field, value)
        pair = credentials()
    except Exception as exc:
        report_error(exc)
        Dialog().ok('Kadr+ — Trakt.tv', L(33206, 'Could not read or save Trakt keys. Check that the Kodi profile is writable and restore both key-storage files from a full profile backup if needed.'))
        return False
    if not all(pair):
        Dialog().ok('Kadr+ — Trakt.tv', L(33207, 'Key saved. Enter the other Trakt key to continue to account authorization.'))
        return False
    Dialog().notification('Kadr+ — Trakt.tv', L(33202, 'Key saved securely.'))
    # Saving the complete pair is an explicit setup action. Continue to the
    # normal device-code flow rather than leaving the account silently unsigned.
    return not bool(Addon().getSetting('trakt.token'))
