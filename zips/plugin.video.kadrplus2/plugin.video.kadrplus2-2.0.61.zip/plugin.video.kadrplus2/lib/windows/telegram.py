from __future__ import annotations

import re
from typing import Any, Sequence

from xbmcgui import ControlList, ListItem

from .base import BaseDialog, CANCEL_ACTIONS


class TelegramResultsDialog(BaseDialog[int]):
    """Wide, remote-friendly Telegram result picker owned by Kadr+.

    Kodi's built-in Dialog.select is sized by the active skin and was too narrow
    for filenames, language, quality, size, date and channel. A dedicated modal
    dialog also consumes Back itself, so that the action cannot leak to the
    underlying source window.
    """

    XML = 'TelegramResults.xml'
    ITEM_LIST = 5000
    CANCEL_BUTTON = 32
    _MARKUP = re.compile(
        r'\[(?:/?B|/?COLOR(?:\s+[^\]]+)?)\]',
        re.IGNORECASE,
    )

    def __init__(self, *args, rows: Sequence[tuple[str, Any]], **kwargs) -> None:
        super().__init__(*args)
        self.rows = list(rows)
        self.display_rows: list[tuple[int, str, Any, str, str]] = []

    @classmethod
    def _clean_group_header(cls, label: str) -> str:
        """Turn a long Telegram post caption into one compact group title."""
        value = cls._MARKUP.sub('', str(label or ''))
        value = re.sub(r'\s+', ' ', value).strip(' ._-')

        # Some channel captions put genres and technical metadata before the
        # actual ``GRUPA: title`` fragment. Prefer that explicit fragment.
        match = re.search(r'\bGRUPA\s*:\s*(.+)', value, re.IGNORECASE)
        if match:
            value = match.group(1).strip()

        # The remaining pipe-delimited fields are rating, runtime, genre etc.
        value = re.split(r'\s+(?:\||•)\s+', value, maxsplit=1)[0].strip()
        value = re.split(
            r'\b(?:GATUNEK|OCENA|CZAS|ROK|REŻYSERIA|REZYSERIA)\s*:',
            value,
            maxsplit=1,
            flags=re.IGNORECASE,
        )[0].strip(' ._-')
        if not value:
            value = 'Pliki z posta Telegrama'
        if len(value) > 78:
            value = value[:75].rstrip() + '...'
        return value

    @classmethod
    def prepare_rows(
        cls,
        rows: Sequence[tuple[str, Any]],
    ) -> list[tuple[int, str, Any, str, str]]:
        # Headers and "end of group" markers are decorations of neighbouring
        # files, not separate list entries.  Kodi list controls cannot mark
        # individual items as non-focusable, so keeping those markers as rows
        # made the remote land on text that could not be played.
        display: list[list[Any]] = []
        pending_header = ''
        for original_pos, (label, payload) in enumerate(rows):
            if payload is None:
                if 'KONIEC GRUPY' in label:
                    # A one-file group already has its green header attached
                    # to this row. Rendering a second caption below the same
                    # fixed-height item would overlap the focus card or shrink
                    # the playable row, so that redundant footer is omitted.
                    if display and not display[-1][3]:
                        display[-1][4] = cls._MARKUP.sub('', label)
                else:
                    pending_header = cls._clean_group_header(label)
                continue
            display.append([original_pos, label, payload, pending_header, ''])
            pending_header = ''
        return [
            (int(pos), str(label), payload, str(header), str(group_end))
            for pos, label, payload, header, group_end in display
        ]

    def on_init(self) -> None:
        self.display_rows = self.prepare_rows(self.rows)

        items = []
        for _original_pos, label, payload, header, group_end in self.display_rows:
            payload = payload if isinstance(payload, dict) else {}
            filename = self._MARKUP.sub(
                '',
                str(payload.get('filename') or payload.get('info2') or label or 'Plik Telegram'),
            ).strip()
            quality = str(payload.get('quality') or '').strip().upper()
            if not quality or quality == '0':
                quality = 'PLIK'
            language = str(payload.get('language') or '').strip().upper()
            size = str(payload.get('size') or '').strip()
            date = str(payload.get('telegram_date') or '').strip()
            source = str(payload.get('source') or 'Telegram').strip()

            details = ' • '.join(value for value in (language, size) if value)
            origin = ' • '.join(value for value in (date, source) if value)
            badge = ' • '.join(value for value in (quality, 'TELEGRAM') if value)

            item = ListItem(label=filename)
            item.setProperty('telegram.row_type', 'file')
            item.setProperty('telegram.group_header', header)
            item.setProperty('telegram.group_end', group_end)
            item.setProperty('telegram.quality', quality)
            item.setProperty('telegram.provider', 'TELEGRAM')
            item.setProperty('telegram.badge', badge)
            item.setProperty('telegram.filename', filename)
            item.setProperty('telegram.details', details)
            item.setProperty('telegram.origin', origin)
            items.append(item)

        self.setProperty('telegram.result_count', str(len(items)))
        widget = self.getControl(self.ITEM_LIST)
        if isinstance(widget, ControlList):
            widget.addItems(items)
            if items:
                widget.selectItem(0)
                self.setFocus(widget)
            else:
                self.setFocusId(self.CANCEL_BUTTON)

    def on_click(self, control_id: int) -> None:
        if control_id == self.CANCEL_BUTTON:
            self.close(-1)
            return
        if control_id != self.ITEM_LIST:
            return
        widget = self.getControl(self.ITEM_LIST)
        if not isinstance(widget, ControlList):
            return
        pos = widget.getSelectedPosition()
        if 0 <= pos < len(self.display_rows):
            self.close(self.display_rows[pos][0])

    def on_action(self, action) -> None:
        if action.getId() in CANCEL_ACTIONS:
            self.close(-1)
