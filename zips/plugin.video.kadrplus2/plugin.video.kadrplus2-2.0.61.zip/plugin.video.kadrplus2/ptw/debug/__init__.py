"""Compatibility logging API used by the migrated Telegram engine."""
from __future__ import annotations
import traceback
from lib.ff.log_utils import fflog as _fflog


def fflog(msg, level=None, fn=True, deep=1):
    try:
        _fflog(str(msg), stack_depth=max(1, int(deep or 1) + 1))
    except Exception:
        try:
            print(msg)
        except Exception:
            pass


def fflog_exc(level=None, msg=""):
    try:
        text = traceback.format_exc()
        if msg:
            text = f"{msg}\n{text}"
        _fflog(text, stack_depth=2)
    except Exception:
        traceback.print_exc()


def log_exception(*args, **kwargs):
    return fflog_exc(*args, **kwargs)
