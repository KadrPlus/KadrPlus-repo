"""Small compatibility facade over Kadr+ 2.0 control helpers."""
from __future__ import annotations
import os
import xbmcgui
from lib.ff import control as _c

addonPath = _c.addonPath
dataPath = _c.dataPath
addItems = _c.addItems
item = _c.item
directory = _c.directory
execute = _c.execute
sleep = _c.sleep
setting = _c.setting
setSetting = _c.setSetting
infoDialog = _c.infoDialog
yesnoDialog = _c.yesnoDialog
selectDialog = _c.selectDialog
keyboard = _c.keyboard
busy_dialog = _c.busy_dialog
close_busy_dialog = _c.close_busy_dialog
# Old Telegram code expects instances here, not factory functions.
dialog = xbmcgui.Dialog()
progressDialog = xbmcgui.DialogProgress()


def makeDirs(path):
    os.makedirs(path, exist_ok=True)
    return True
