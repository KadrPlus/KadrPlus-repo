"""Compatibility libraries for migrated Kadr+ components."""
