"""Compatibility namespace for migrated Kadr+ components."""
