# -*- coding: utf-8 -*-
"""ctypes AES-256-IGE backend for Kadr+ 2.0 Telegram.

Loads the plain Android shared library libtgcrypto_ige.so through ctypes.
"""
from __future__ import annotations

import ctypes
import glob
import os
import platform
import shutil
import struct
import sys
import tempfile

try:
    from ptw.debug import fflog
except Exception:  # pragma: no cover
    def fflog(msg, level=1):
        try:
            print(msg)
        except Exception:
            pass

_LIB = None
_LOADED_FROM = ''
_LOAD_ERROR = ''
_LOAD_ATTEMPTED = False


def _addon_path():
    try:
        from ptw.libraries import control
        return control.addonPath
    except Exception:
        return os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))


def _data_path():
    try:
        from ptw.libraries import control
        return control.dataPath
    except Exception:
        return os.path.join(tempfile.gettempdir(), 'kadrplus')


def _android_package_name_from_paths():
    for c in (_addon_path(), _data_path()):
        if not c:
            continue
        marker = '/Android/data/'
        if marker in c:
            rest = c.split(marker, 1)[1]
            pkg = rest.split('/files', 1)[0].split('/', 1)[0]
            if pkg:
                return pkg
    return 'org.xbmc.kodi'


def _vendor_base():
    return os.path.join(_addon_path(), 'resources', 'lib', 'vendor', 'tgcrypto_ctypes')


def _candidate_abi_names():
    machine = (platform.machine() or '').lower()
    try:
        bits = struct.calcsize('P') * 8
    except Exception:
        bits = 0
    names = []
    if bits == 32:
        names += ['android_arm', 'armeabi-v7a', 'armv7', 'arm']
    elif bits == 64:
        names += ['android_arm64', 'arm64-v8a', 'aarch64', 'arm64']
    if machine in ('armv8l', 'armv7l', 'armv7', 'arm'):
        names += ['android_arm', 'armeabi-v7a', 'armv7', 'arm']
    elif machine in ('aarch64', 'arm64'):
        names += ['android_arm64', 'arm64-v8a', 'aarch64', 'arm64']
    if machine:
        names.append(machine)
    names += ['android', 'all']
    out = []
    for n in names:
        if n and n not in out:
            out.append(n)
    return out


def _candidate_library_paths():
    base = _vendor_base()
    pats = []
    for abi in _candidate_abi_names():
        pats += [
            os.path.join(base, abi, 'libtgcrypto_ige.so'),
            os.path.join(base, abi, 'tgcrypto_ige.so'),
            os.path.join(base, abi, '*.so'),
        ]
    pats += [
        os.path.join(base, 'libtgcrypto_ige.so'),
        os.path.join(base, '*.so'),
    ]
    seen, out = set(), []
    for pat in pats:
        for f in glob.glob(pat):
            try:
                f = os.path.abspath(f)
            except Exception:
                pass
            if f in seen:
                continue
            seen.add(f)
            if os.path.isfile(f):
                out.append(f)
    return out


def _temp_dirs():
    # Prefer internal app dirs.  Android's linker accepts these for a plain
    # ctypes-loaded .so, while /storage/emulated/0 may be blocked by namespaces.
    pkg = _android_package_name_from_paths()
    dirs = []
    for d in (
        os.path.join('/data/user/0', pkg, 'code_cache', 'kadrplus_tgcrypto'),
        os.path.join('/data/user/0', pkg, 'cache', 'kadrplus_tgcrypto'),
        os.path.join('/data/user/0', pkg, 'files', 'kadrplus_tgcrypto'),
        os.path.join('/data/data', pkg, 'code_cache', 'kadrplus_tgcrypto'),
        os.path.join('/data/data', pkg, 'cache', 'kadrplus_tgcrypto'),
        os.path.join('/data/data', pkg, 'files', 'kadrplus_tgcrypto'),
        os.path.join('/data/user_de/0', pkg, 'code_cache', 'kadrplus_tgcrypto'),
        os.path.join('/data/user_de/0', pkg, 'cache', 'kadrplus_tgcrypto'),
        os.path.join(tempfile.gettempdir(), 'kadrplus_tgcrypto'),
        os.path.join(_data_path(), 'telegram', 'native_tmp_tgcrypto'),
    ):
        if d and d not in dirs:
            dirs.append(d)
    out = []
    for d in dirs:
        try:
            os.makedirs(d, exist_ok=True)
            try:
                os.chmod(d, 0o755)
            except Exception:
                pass
            probe = os.path.join(d, '.write_test')
            with open(probe, 'wb') as fh:
                fh.write(b'1')
            try:
                os.unlink(probe)
            except Exception:
                pass
            if d not in out:
                out.append(d)
        except Exception:
            continue
    return out or [tempfile.gettempdir()]


def _copy_targets(src):
    targets = []
    failures = []
    basename = os.path.basename(src) or 'libtgcrypto_ige.so'
    for d in _temp_dirs():
        for name in ('libtgcrypto_ige.so', basename):
            dst = os.path.join(d, name)
            if dst in targets:
                continue
            try:
                if os.path.abspath(src) != os.path.abspath(dst):
                    shutil.copyfile(src, dst)
                try:
                    os.chmod(dst, 0o755)
                except Exception as exc:
                    failures.append('chmod:%s:%r' % (dst, exc))
                targets.append(dst)
            except Exception as exc:
                failures.append('copy:%s->%s:%r' % (src, dst, exc))
    # Try original path last; useful on non-Android or permissive devices.
    if src not in targets:
        targets.append(src)
    return targets, failures


def _configure_lib(lib):
    lib.tg_aes_ige_version.argtypes = []
    lib.tg_aes_ige_version.restype = ctypes.c_uint32
    for fn in ('tg_aes_ige_decrypt', 'tg_aes_ige_encrypt'):
        f = getattr(lib, fn)
        f.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
        f.restype = ctypes.c_int
    return lib


def try_load(force=False):
    """Load libtgcrypto_ige.so. Returns (ok, detail)."""
    global _LIB, _LOADED_FROM, _LOAD_ERROR, _LOAD_ATTEMPTED
    if _LIB is not None and not force:
        return True, 'already loaded from %s' % _LOADED_FROM
    if _LOAD_ATTEMPTED and not force:
        return False, _LOAD_ERROR or 'previous load failed'
    _LOAD_ATTEMPTED = True
    if force:
        _LIB = None
        _LOADED_FROM = ''
        _LOAD_ERROR = ''

    candidates = _candidate_library_paths()
    if not candidates:
        _LOAD_ERROR = 'no libtgcrypto_ige.so candidates under %s' % _vendor_base()
        try:
            fflog('[tg-ctypes] %s' % _LOAD_ERROR, 1)
        except Exception:
            pass
        return False, _LOAD_ERROR

    errors = []
    for src in candidates:
        targets, copy_failures = _copy_targets(src)
        try:
            fflog('[tg-ctypes] try source=%s targets=%r copy_failures=%r' % (src, targets, copy_failures[:8]), 1)
        except Exception:
            pass
        for path in targets:
            try:
                lib = ctypes.CDLL(path)
                _configure_lib(lib)
                ver = lib.tg_aes_ige_version()
                _LIB = lib
                _LOADED_FROM = path
                _LOAD_ERROR = ''
                return True, 'loaded %s version=%s' % (path, ver)
            except Exception as exc:
                errors.append('%s -> %r' % (path, exc))
                continue
    _LOAD_ERROR = 'all load attempts failed: ' + ' ;; '.join(errors[-12:])
    return False, _LOAD_ERROR


def is_available():
    ok, _ = try_load()
    return bool(ok)


def status():
    ok, detail = try_load()
    return {
        'available': bool(ok),
        'detail': detail,
        'loaded_from': _LOADED_FROM,
        'candidates': _candidate_library_paths(),
        'abis': _candidate_abi_names(),
    }


def _call(which, data, key, iv):
    if len(data) % 16:
        raise ValueError('AES-IGE data length must be multiple of 16')
    if len(key) != 32:
        raise ValueError('AES-IGE key length must be 32 bytes')
    if len(iv) != 32:
        raise ValueError('AES-IGE iv length must be 32 bytes')
    ok, detail = try_load()
    if not ok or _LIB is None:
        raise RuntimeError('libtgcrypto_ige not available: %s' % detail)

    data_b = bytes(data)
    key_b = bytes(key)
    iv_b = bytes(iv)
    in_buf = ctypes.create_string_buffer(data_b, len(data_b))
    key_buf = ctypes.create_string_buffer(key_b, len(key_b))
    iv_buf = ctypes.create_string_buffer(iv_b, len(iv_b))
    out_buf = ctypes.create_string_buffer(len(data_b))
    fn = getattr(_LIB, which)
    ret = fn(
        ctypes.cast(in_buf, ctypes.c_void_p),
        ctypes.c_size_t(len(data_b)),
        ctypes.cast(key_buf, ctypes.c_void_p),
        ctypes.cast(iv_buf, ctypes.c_void_p),
        ctypes.cast(out_buf, ctypes.c_void_p),
    )
    if ret != 0:
        raise RuntimeError('%s returned error %s' % (which, ret))
    return out_buf.raw


def decrypt_ige(cipher_text, key, iv):
    return _call('tg_aes_ige_decrypt', cipher_text, key, iv)


def encrypt_ige(plain_text, key, iv):
    padding = len(plain_text) % 16
    if padding:
        import os as _os
        plain_text += _os.urandom(16 - padding)
    return _call('tg_aes_ige_encrypt', plain_text, key, iv)
