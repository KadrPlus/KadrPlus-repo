"""Telegram resource helpers."""
