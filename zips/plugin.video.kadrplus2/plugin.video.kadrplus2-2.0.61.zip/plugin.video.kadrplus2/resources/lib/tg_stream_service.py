# -*- coding: utf-8 -*-
"""Persistent Telegram streaming service for Kadr+ 2.0.

Architecture used here is intentionally different from the old resolver proxy:
- Kodi's plugin invocation only registers a Telegram file and receives a local URL.
- This module runs from service.py, keeps one asyncio loop and one Telethon client.
- HTTP Range requests are served from a growing local cache; sparse tail/random
  probes are fetched by the same service client, not by new clients in request
  threads.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import os
import re
import sys
import time
import uuid
import threading
import queue
from urllib.parse import quote, unquote, urlparse

try:
    from ptw.debug import fflog, fflog_exc
except Exception:  # pragma: no cover - Kodi only
    def fflog(msg, level=1):
        try:
            print(msg)
        except Exception:
            pass
    def fflog_exc(level=1):
        import traceback
        traceback.print_exc()

try:
    from ptw.libraries import control
except Exception:  # pragma: no cover - unit checks outside Kodi
    control = None

try:
    from resources.lib import tg_ctypes_crypto
except Exception:
    tg_ctypes_crypto = None

_SERVICE = None
_SERVICE_LOCK = threading.RLock()


def _token_tag(token):
    """Return a non-reversible correlation id instead of logging a stream token."""
    return hashlib.sha256(str(token).encode('utf-8')).hexdigest()[:8]


def _addon_path():
    try:
        return control.addonPath
    except Exception:
        # ``tg_stream_service.py`` lives in ``resources/lib``.  Two parent
        # levels are the add-on root; four escaped the package entirely and
        # made the bundled Telethon fallback impossible to locate.
        return os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))


def _data_path():
    try:
        path = control.dataPath
    except Exception:
        path = os.path.join('/tmp', 'kadrplus2')
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        pass
    return path


def _vendor_path():
    return os.path.join(_addon_path(), 'resources', 'lib', 'vendor', 'telegram')


def _ensure_vendor_path():
    vp = _vendor_path()
    if vp and vp not in sys.path:
        sys.path.insert(0, vp)


def _crypto_status():
    """Small production crypto status without old cryptg diagnostics."""
    info = {'telethon_backend': 'unknown'}
    try:
        _ensure_vendor_path()
        from telethon.crypto import aes
        info['telethon_backend'] = aes.crypto_backend()
    except Exception as exc:
        info['error'] = repr(exc)
    try:
        if tg_ctypes_crypto:
            st = tg_ctypes_crypto.status()
            info['tgcrypto_ctypes'] = bool(st.get('available'))
            info['tgcrypto_detail'] = st.get('detail') or ''
            info['tgcrypto_loaded_from'] = st.get('loaded_from') or ''
    except Exception as exc:
        info['tgcrypto_error'] = repr(exc)
    return info


def _cache_dir():
    path = os.path.join(_data_path(), 'telegram', 'service_stream_cache')
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        pass
    return path


def _cleanup_stream_cache(max_bytes=768 * 1024 * 1024, max_age=24 * 3600):
    """Keep Telegram stream cache bounded.

    The cache contains partial progressive downloads, not permanent movies.
    Older builds left those partial files behind after source tests/cancelled opens.
    """
    try:
        path = _cache_dir()
        now = time.time()
        files = []
        for name in os.listdir(path):
            fp = os.path.join(path, name)
            try:
                if not os.path.isfile(fp):
                    continue
                st = os.stat(fp)
                if max_age and now - st.st_mtime > max_age:
                    os.remove(fp)
                    continue
                files.append((st.st_mtime, st.st_size, fp))
            except Exception:
                pass
        total = sum(x[1] for x in files)
        if total > int(max_bytes or 0):
            for _mtime, _size, _fp in sorted(files):
                try:
                    os.remove(_fp)
                    total -= _size
                except Exception:
                    pass
                if total <= int(max_bytes or 0):
                    break
    except Exception:
        pass


def _state_dir():
    path = os.path.join(_data_path(), 'telegram')
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        pass
    return path


def status_path():
    return os.path.join(_state_dir(), 'stream_service.json')


def _safe_name(value, default='video.mp4'):
    try:
        name = os.path.basename(str(value or default).replace('\\', '/')) or default
        # Keep it header/URL friendly; the original name is not essential for Kodi.
        name = re.sub(r'[^A-Za-z0-9._ -]+', '_', name)
        name = re.sub(r'\s+', ' ', name).strip(' ._-') or default
        if '.' not in name:
            mime = ''
            name += '.mp4'
        return name[:160]
    except Exception:
        return default


def _content_disposition(filename):
    try:
        safe = _safe_name(filename)
        original = os.path.basename(str(filename or safe).replace('\\', '/')) or safe
        return "inline; filename=\"%s\"; filename*=UTF-8''%s" % (safe.replace('"', ''), quote(original.encode('utf-8')))
    except Exception:
        return 'inline; filename="video.mp4"'


def _read_status():
    try:
        with open(status_path(), 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_status(port):
    try:
        data = {'port': int(port or 0), 'pid': os.getpid(), 'time': int(time.time())}
        with open(status_path(), 'w', encoding='utf-8') as fh:
            json.dump(data, fh, separators=(',', ':'))
    except Exception:
        pass


def _json_response(handler, status, data):
    raw = json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    handler.send_response(status)
    handler.send_header('Content-Type', 'application/json; charset=utf-8')
    handler.send_header('Content-Length', str(len(raw)))
    handler.send_header('Connection', 'close')
    handler.end_headers()
    if getattr(handler, 'command', 'GET') != 'HEAD':
        handler.wfile.write(raw)


def _parse_range(header, total):
    try:
        total = int(total or 0)
        if total <= 0:
            return 0, 0, False
        m = re.match(r'bytes=(\d*)-(\d*)', header or '')
        if not m:
            return 0, total - 1, False
        if m.group(1) == '' and m.group(2):
            n = int(m.group(2))
            start = max(0, total - n)
            end = total - 1
        else:
            start = int(m.group(1) or 0)
            end = int(m.group(2) or (total - 1))
        start = max(0, min(start, total - 1))
        end = max(start, min(end, total - 1))
        return start, end, True
    except Exception:
        total = int(total or 0)
        return 0, max(0, total - 1), False


def _round_1024(value, up=False):
    value = int(value or 0)
    if up:
        return ((value + 1023) // 1024) * 1024
    return (value // 1024) * 1024


class _StreamJob:
    def __init__(self, service, spec):
        self.service = service
        self.spec = spec or {}
        self.token = self.spec.get('token') or uuid.uuid4().hex
        self.spec['token'] = self.token
        self.total = int(self.spec.get('size') or 0)
        self.mime = self.spec.get('mime') or 'video/mp4'
        self.filename = self.spec.get('filename') or 'video.mp4'
        self.created = time.time()
        self.last_read = time.time()
        self.lock = threading.RLock()
        self.event = threading.Event()
        self.stop = threading.Event()
        self.done = False
        self.error = ''
        self.cached = 0
        self.cache_path = os.path.join(_cache_dir(), '%s_%s' % (self.token[:16], _safe_name(self.filename)))
        self.sparse = {}  # offset -> bytes for tail/random probes
        self.sparse_lock = threading.RLock()
        # While Kodi is reading a post-seek direct range, pause the background
        # progressive downloader so it does not compete with the active stream.
        self.direct_active = threading.Event()
        self.start_thread = None

    def log(self, msg):
        try:
            fflog('[tg-service] [%s] %s' % (_token_tag(self.token), msg), 1)
        except Exception:
            pass

    def cleanup_cache_file(self):
        try:
            if self.cache_path and os.path.exists(self.cache_path):
                os.remove(self.cache_path)
        except Exception:
            pass

    def start(self):
        if self.start_thread and self.start_thread.is_alive():
            return
        self.start_thread = threading.Thread(target=self._run_download, name='KadrPlusTGServiceDownload', daemon=True)
        self.start_thread.start()

    def _run_download(self):
        try:
            try:
                if os.path.exists(self.cache_path):
                    os.remove(self.cache_path)
            except Exception:
                pass
            self.log('progressive download start size=%s file=%r' % (self.total, os.path.basename(self.cache_path)))
            pos = 0
            empty = 0
            with open(self.cache_path, 'ab') as fh:
                while not self.stop.is_set():
                    if self.total and pos >= self.total:
                        self.done = True
                        break
                    if self.direct_active.is_set() and pos >= 16 * 1024 * 1024:
                        # A seek is being served directly from Telegram.  Let that
                        # connection use the available bandwidth; keep the first
                        # 16 MiB cache for startup/probing only.
                        time.sleep(0.25)
                        continue
                    # Start with very small pieces so the cache becomes non-zero
                    # quickly. The previous 512 KiB all-or-nothing request meant
                    # register() could time out with cached=0 even when Telegram was
                    # slowly returning data. After the first MiB, larger pieces are OK.
                    if pos < 1024 * 1024:
                        want = 128 * 1024
                        call_timeout = 12.0
                        result_timeout = 16.0
                    elif pos < 8 * 1024 * 1024:
                        want = 1024 * 1024
                        call_timeout = 18.0
                        result_timeout = 26.0
                    else:
                        # Larger fetch windows avoid re-opening Telethon's
                        # downloader every 256 KiB.  The ctypes AES backend is
                        # fast enough; round-trip overhead is now the enemy.
                        want = 4 * 1024 * 1024
                        call_timeout = 28.0
                        result_timeout = 45.0
                    if self.total:
                        want = min(want, max(0, self.total - pos))
                    try:
                        fut = self.service.submit_coro(self.service.fetch_range(self, pos, want, timeout=call_timeout))
                        data = fut.result(timeout=result_timeout)
                    except Exception as exc:
                        data = b''
                        self.error = repr(exc)
                    if not data:
                        empty += 1
                        if empty >= 3:
                            self.log('progressive stalled pos=%s err=%r' % (pos, self.error))
                            break
                        time.sleep(0.35)
                        continue
                    empty = 0
                    # Important: cached bytes must be readable by the HTTP
                    # thread immediately.  Do not mark bytes as cached before the
                    # file object is flushed; otherwise Kodi may receive HTTP
                    # headers for bytes that still live only in Python's write
                    # buffer.  Flush is cheap enough here; fsync is intentionally
                    # not used.
                    with self.lock:
                        fh.write(data)
                        try:
                            fh.flush()
                        except Exception:
                            pass
                        pos += len(data)
                        self.cached = pos
                    self.event.set()
                    # Do not keep downloading forever after a failed/cancelled open.
                    # Stop quickly after a failed player open. Earlier builds kept
                    # downloading after Kodi had already aborted, which made the UI
                    # feel clogged and made logs hard to copy on Android.
                    if pos >= 512 * 1024 * 1024 and time.time() - self.last_read > 90:
                        self.log('progressive idle stop cached=%s idle=%.1fs' % (pos, time.time() - self.last_read))
                        self.done = True
                        break
            try:
                self.event.set()
            except Exception:
                pass
            self.log('progressive download stop cached=%s done=%s err=%r' % (self.cached, self.done, self.error))
        except Exception as exc:
            self.error = repr(exc)
            self.event.set()
            fflog_exc(1)

    def wait_cached(self, pos, timeout=12.0):
        deadline = time.time() + float(timeout or 0)
        pos = int(pos or 0)
        while time.time() < deadline and not self.stop.is_set():
            with self.lock:
                if self.cached > pos:
                    return True
            if self.done or self.error:
                return False
            self.event.wait(0.20)
            self.event.clear()
        with self.lock:
            return self.cached > pos

    def wait_startup(self, minimum=512 * 1024, timeout=12.0):
        return self.wait_cached(int(minimum or 1) - 1, timeout=timeout)

    def read_cached(self, start, size):
        try:
            with self.lock:
                cached = int(self.cached or 0)
            if cached <= start:
                return b''
            size = min(int(size or 0), cached - int(start or 0))
            if size <= 0:
                return b''
            with open(self.cache_path, 'rb') as fh:
                fh.seek(int(start or 0))
                return fh.read(size)
        except Exception:
            return b''

    def touch(self):
        self.last_read = time.time()


class TelegramStreamService:
    def __init__(self, preferred_port=0):
        _cleanup_stream_cache()
        self.preferred_port = int(preferred_port or 0)
        self.port = 0
        self.server = None
        self.server_thread = None
        self.loop = None
        self.loop_thread = None
        self.jobs = {}
        self.jobs_lock = threading.RLock()
        self.client = None
        self.client_key = None
        self.client_lock = None
        self.abort_monitor = None
        self.running = False

    def start(self, monitor=None):
        if self.running:
            return self.port
        self.abort_monitor = monitor
        _ensure_vendor_path()
        try:
            if tg_ctypes_crypto:
                tg_ctypes_crypto.try_load()
        except Exception:
            pass
        self._start_loop()
        self._start_http()
        self.running = True
        return self.port

    def _start_loop(self):
        ready = threading.Event()
        def runner():
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.loop)
            self.client_lock = asyncio.Lock()
            ready.set()
            self.loop.run_forever()
        self.loop_thread = threading.Thread(target=runner, name='KadrPlusTGAsyncLoop', daemon=True)
        self.loop_thread.start()
        ready.wait(5.0)

    def submit_coro(self, coro):
        if not self.loop:
            raise RuntimeError('telegram service loop not started')
        return asyncio.run_coroutine_threadsafe(coro, self.loop)

    def _start_http(self):
        import http.server
        import socketserver

        service = self

        class ThreadingServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
            daemon_threads = True
            allow_reuse_address = True

        class Handler(http.server.BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'
            server_version = 'KadrPlusTGService/1.0'

            def log_message(self, fmt, *args):
                try:
                    fflog('[tg-service-http] ' + (fmt % args), 0)
                except Exception:
                    pass

            def do_HEAD(self):
                self._dispatch(head_only=True)

            def do_GET(self):
                self._dispatch(head_only=False)

            def do_POST(self):
                self._dispatch(head_only=False)

            def _dispatch(self, head_only=False):
                try:
                    try:
                        self.connection.settimeout(120)
                    except Exception:
                        pass
                    path = urlparse(self.path).path or ''
                    if path == '/ping':
                        return _json_response(self, 200, {'ok': True, 'port': service.port, 'jobs': len(service.jobs)})
                    if path == '/control/register' and self.command == 'POST':
                        length = int(self.headers.get('Content-Length') or 0)
                        raw = self.rfile.read(min(length, 512 * 1024)) if length else b'{}'
                        spec = json.loads(raw.decode('utf-8') or '{}')
                        result = service.register(spec)
                        status = 200 if result.get('ok') else 503
                        return _json_response(self, status, result)
                    m = re.match(r'^/stream/([A-Za-z0-9_-]{16,64})(?:/.*)?$', path)
                    if m:
                        return service.serve_stream(self, m.group(1), head_only=head_only)
                    self.send_error(404, 'not found')
                except Exception:
                    fflog_exc(1)
                    try:
                        self.send_error(500, 'telegram service error')
                    except Exception:
                        pass

        ports = []
        if 1024 < self.preferred_port < 65536:
            ports.append(self.preferred_port)
        ports.append(0)
        last = None
        for p in ports:
            try:
                self.server = ThreadingServer(('127.0.0.1', p), Handler)
                self.port = int(self.server.server_address[1])
                break
            except Exception as exc:
                last = exc
        if not self.server:
            raise RuntimeError('cannot start telegram service HTTP: %r' % (last,))
        self.server_thread = threading.Thread(target=self.server.serve_forever, name='KadrPlusTGServiceHTTP', daemon=True)
        self.server_thread.start()
        _write_status(self.port)
        fflog('[tg-service] started on 127.0.0.1:%s' % self.port, 1)

    async def ensure_client(self, spec):
        _ensure_vendor_path()
        from telethon import TelegramClient
        from telethon.sessions import StringSession
        async with (self.client_lock or asyncio.Lock()):
            api_id = int((spec or {}).get('api_id') or 0)
            api_hash = (spec or {}).get('api_hash') or ''
            session_string = (spec or {}).get('session_string') or ''
            if not (api_id and api_hash and session_string):
                raise RuntimeError('missing api/session for Telegram service')
            key = (api_id, api_hash, session_string[:32])
            if self.client and self.client_key == key:
                try:
                    if await self.client.is_user_authorized():
                        return self.client
                except Exception:
                    pass
            if self.client:
                try:
                    await self.client.disconnect()
                except Exception:
                    pass
                self.client = None
            # A single persistent client; no updates while streaming.
            # Telegram regularly closes an idle MTProto socket; Telethon then
            # reconnects automatically, but its ERROR log looked like a Kadr+
            # crash every ~60 seconds. Real register/stream failures are logged
            # explicitly below, so keep this internal reconnect logger quiet.
            telethon_logger = logging.getLogger('kadrplus.telegram.stream.telethon')
            telethon_logger.setLevel(logging.CRITICAL)
            self.client = TelegramClient(StringSession(session_string), api_id, api_hash,
                                         loop=self.loop, timeout=14, request_retries=1,
                                         connection_retries=3, retry_delay=0.7,
                                         auto_reconnect=True, receive_updates=False,
                                         flood_sleep_threshold=0, entity_cache_limit=256,
                                         base_logger=telethon_logger)
            await self.client.connect()
            if not await self.client.is_user_authorized():
                await self.client.disconnect()
                self.client = None
                raise RuntimeError('Telegram session is not authorised')
            self.client_key = key
            return self.client

    async def prepare_spec(self, spec):
        """Validate and enrich playback metadata before the player sees a URL.

        The source list sometimes carries a display-size or a corrupted tiny
        value in the packed token.  Kodi needs the real Telegram document size
        for HTTP Range, so refresh the message in the persistent Telegram loop
        before creating the stream job whenever the size/location looks wrong.
        """
        spec = dict(spec or {})
        await self.ensure_client(spec)
        size = int(spec.get('size') or 0)
        location = self._document_location_from_spec(spec)
        if (not location) or size < 1024 * 1024:
            await self._refresh_location(self.client, spec)
        size = int(spec.get('size') or 0)
        if size <= 0:
            raise RuntimeError('Telegram document size unavailable')
        if not self._document_location_from_spec(spec):
            raise RuntimeError('Telegram document location unavailable')
        return spec

    def register(self, spec):
        try:
            spec = dict(spec or {})
            # Resolve real document metadata first.  Do this before starting the
            # cache thread, otherwise a wrong tiny size (seen as size=16 in the
            # log) makes the streamer impossible for Kodi to open.
            try:
                spec = self.submit_coro(self.prepare_spec(spec)).result(timeout=24.0)
            except Exception as exc:
                return {'ok': False, 'error': 'Telegram metadata failed: %r' % (exc,), 'cached': 0}
            crypto_info = _crypto_status()
            try:
                fflog('[tg-crypto/register] backend=%s tgcrypto_ctypes=%s detail=%r' % (
                    crypto_info.get('telethon_backend'), crypto_info.get('tgcrypto_ctypes'),
                    crypto_info.get('tgcrypto_detail') or crypto_info.get('error') or ''), 1)
            except Exception:
                pass
            native_backend = (crypto_info.get('telethon_backend') or '').lower()
            fast_backends = ('tgcrypto_ctypes', 'libssl')
            if native_backend not in fast_backends:
                return {
                    'ok': False,
                    'error': 'Brak szybkiej natywnej kryptografii Telegram (tgcrypto_ctypes/libssl). PyCryptodome/pyaes są za wolne do streamingu na tym Androidzie.',
                    'cached': 0,
                    'crypto_backend': native_backend,
                    'crypto': crypto_info,
                    'last_error': crypto_info.get('tgcrypto_detail') or crypto_info.get('error') or ''
                }
            token = uuid.uuid4().hex
            spec['token'] = token
            job = _StreamJob(self, spec)
            with self.jobs_lock:
                # Stop old jobs to reduce disk/network/disk pressure. Keep only the current test/playback.
                for old_token, old_job in list(self.jobs.items()):
                    try:
                        old_job.stop.set()
                    except Exception:
                        pass
                    try:
                        old_job.cleanup_cache_file()
                    except Exception:
                        pass
                    self.jobs.pop(old_token, None)
                _cleanup_stream_cache()
                self.jobs[token] = job
            job.start()
            # Kodi/FFmpeg does not only need the first few bytes.  In the log it
            # opened bytes=0- and then immediately bytes=393216-.  Returning the
            # URL with only 64 KiB made the second seek race the cache.  Wait for
            # a realistic first window, but do not fail if Telegram is slow and
            # we already have a smaller usable window.
            # Pipe mode does not require several MiB before giving Kodi the URL.
            # Long waits here were the visible "sprawdzanie linku" delay.
            # For fast native backends give Kodi a real startup window before it
            # asks FFmpeg to probe/seek. Slow fallbacks are already rejected above.
            # Give Kodi a larger cushion before playback. On large files the
            # bottleneck is no longer AES, but Telegram range throughput and
            # FFmpeg's probing/seek pattern.  A bigger initial cache greatly
            # reduces early underruns without changing the stream URL.
            try:
                startup_mb = max(1, min(16, int(spec.get('startup_buffer_mb') or 4)))
            except Exception:
                startup_mb = 4
            startup_min = startup_mb * 1024 * 1024 if native_backend in fast_backends else 128 * 1024
            startup_timeout = min(24.0, max(10.0, 8.0 + 2.0 * startup_mb)) if native_backend in fast_backends else 8.0
            job.log('startup target=%s MiB timeout=%.1fs' % (startup_mb, startup_timeout))
            ready = job.wait_startup(minimum=startup_min, timeout=startup_timeout)
            cached = int(job.cached or 0)
            if native_backend in ('pyaes', 'unknown') and cached < 128 * 1024:
                job.stop.set()
                return {'ok': False, 'error': 'Brak szybkiej kryptografii Telegram (tgcrypto_ctypes/libssl); pyaes jest za wolny do streamingu na Androidzie', 'cached': cached, 'crypto_backend': native_backend, 'crypto': crypto_info, 'last_error': job.error}
            if cached <= 0:
                job.stop.set()
                return {'ok': False, 'error': 'Telegram service did not deliver first bytes', 'cached': cached, 'last_error': job.error}
            if not ready:
                if cached < 64 * 1024:
                    job.stop.set()
                    return {'ok': False, 'error': 'Telegram startup buffer too small', 'cached': cached, 'last_error': job.error}
                job.log('startup below target cached=%s; handing non-seekable pipe URL' % cached)
            filename = _safe_name(job.filename)
            url = 'http://127.0.0.1:%d/stream/%s/%s' % (self.port, token, quote(filename))
            return {'ok': True, 'url': url, 'token': token, 'cached': cached, 'size': job.total, 'crypto_backend': native_backend, 'crypto': crypto_info}
        except Exception as exc:
            fflog_exc(1)
            return {'ok': False, 'error': repr(exc)}

    def _bounded_range(self, job, start, end, partial):
        # Kept for older callers, but normal playback must not shrink Kodi's
        # requested range. FFmpeg/Kodi uses HEAD + byte ranges to decide if it
        # can seek to MP4/MKV metadata. Returning a fake small 206 for a full
        # resource makes Kodi believe the resource is tiny and the demuxer fails.
        total = int(job.total or 0)
        start = int(start or 0)
        end = int(end if end is not None else max(0, total - 1))
        if total:
            start = max(0, min(start, total - 1))
            end = max(start, min(end, total - 1))
        return start, end, bool(partial)

    def _write_full_headers(self, handler, job, status=200):
        total = int(job.total or 0)
        handler.send_response(status)
        handler.send_header('Content-Type', job.mime or 'video/mp4')
        handler.send_header('Accept-Ranges', 'bytes')
        handler.send_header('Content-Disposition', _content_disposition(job.filename))
        if total:
            handler.send_header('Content-Length', str(total))
        handler.send_header('Connection', 'close')
        handler.end_headers()


    def _write_headers(self, handler, status, job, start, end, partial):
        total = job.total
        length = max(0, int(end) - int(start) + 1) if total else 0
        handler.send_response(status)
        handler.send_header('Content-Type', job.mime or 'video/mp4')
        handler.send_header('Accept-Ranges', 'bytes')
        handler.send_header('Content-Disposition', _content_disposition(job.filename))
        if total:
            if partial:
                handler.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, total))
            handler.send_header('Content-Length', str(length))
        handler.send_header('Connection', 'close')
        handler.end_headers()

    def serve_stream(self, handler, token, head_only=False):
        with self.jobs_lock:
            job = self.jobs.get(token)
        if not job:
            handler.send_error(404, 'stream token not found')
            return
        job.touch()
        total = int(job.total or 0)
        if total <= 0:
            handler.send_error(416, 'unknown file size')
            return

        raw_range = handler.headers.get('Range') or ''
        has_range = bool(raw_range)
        try:
            pipe_mode = 'pipe=1' in (urlparse(handler.path).query or '')
        except Exception:
            pipe_mode = False
        start, end, partial = _parse_range(raw_range, total)
        # IMPORTANT: do not bound/shrink normal HEAD/GET ranges. Kodi/FFmpeg
        # depends on truthful Content-Length and Content-Range to decide when to
        # probe the end of MP4/MKV files. Previous builds answered HEAD with
        # 206 and Content-Length=524288, which effectively told Kodi the whole
        # 1.6 GB file was a 512 KiB resource.
        try:
            fflog('[tg-service] [%s] HTTP %s range=%s-%s/%s cached=%s raw=%r has_range=%s' % (
                _token_tag(token), handler.command, start, end, total, job.cached, raw_range, has_range), 1)
        except Exception:
            pass

        # Kodi often sends HEAD without Range before opening the demuxer. This
        # MUST describe the full representation: 200 OK, full Content-Length,
        # Accept-Ranges, no Content-Range.
        if head_only:
            if not has_range:
                self._write_full_headers(handler, job, 200)
                try:
                    fflog('[tg-service] [%s] HEAD full size=%s cached=%s' % (_token_tag(token), total, job.cached), 1)
                except Exception:
                    pass
                return
            self._write_headers(handler, 206, job, start, end, True)
            return

        # Non-seekable pipe mode: do not allow Kodi/FFmpeg to trigger random
        # tail probes. Serve a single growing stream from byte 0. This is the
        # only mode that avoids UI-clogging random Telegram range fetches on
        # slow Android/Python devices.
        if pipe_mode:
            if has_range and start > 0:
                try:
                    fflog('[tg-service] [%s] pipe ignoring non-zero range start=%s raw=%r' % (_token_tag(token), start, raw_range), 1)
                except Exception:
                    pass
                handler.send_error(416, 'non-seekable Telegram pipe')
                return
            if not job.wait_cached(0, timeout=12.0):
                handler.send_error(504, 'Telegram service did not return first byte')
                return
            self._write_full_headers(handler, job, 200)
            sent = self._send_from_progressive_cache(handler, job, 0, total - 1, wait_for_more=True)
            try:
                fflog('[tg-service] [%s] pipe stream sent=%s cached=%s err=%r' % (_token_tag(token), sent, job.cached, job.error), 1)
            except Exception:
                pass
            return

        # No Range GET: stream the full representation from byte 0.
        if not has_range:
            start, end, partial = 0, total - 1, False
            if not job.wait_cached(0, timeout=20.0):
                handler.send_error(504, 'Telegram service did not return first byte')
                return
            self._write_full_headers(handler, job, 200)
            sent = self._send_from_progressive_cache(handler, job, start, end, wait_for_more=True)
            try:
                fflog('[tg-service] [%s] full stream sent=%s cached=%s err=%r' % (_token_tag(token), sent, job.cached, job.error), 1)
            except Exception:
                pass
            return

        # Prefix/early ranges are streamed continuously from the progressive
        # cache. We honour the requested range in the headers, then feed bytes as
        # the Telegram worker appends them. This is HTTP-correct for Kodi.
        with job.lock:
            cached = int(job.cached or 0)

        if start < max(cached, 16 * 1024 * 1024):
            if cached <= start:
                job.wait_cached(start, timeout=24.0)
            with job.lock:
                cached = int(job.cached or 0)
            if cached > start:
                self._write_headers(handler, 206, job, start, end, True)
                sent = self._send_from_progressive_cache(handler, job, start, end, wait_for_more=True)
                try:
                    fflog('[tg-service] [%s] progressive stream sent=%s range=%s-%s cached=%s err=%r' % (_token_tag(token), sent, start, end, job.cached, job.error), 1)
                except Exception:
                    pass
                return

        # Tail/random probe or a real post-seek stream.
        # Important discovery from 2.41.65: after a user seek Kodi may request an
        # open-ended range such as bytes=201520637-. Returning only an 8 MiB
        # sparse slice with Content-Range ending at 209909244 makes Kodi think it
        # reached EOF for that HTTP response, so playback stops shortly after the
        # seek.  For open-ended non-tail ranges we must stream the requested range
        # continuously from Telegram to EOF (or until Kodi closes the socket).
        want = end - start + 1
        open_ended = False
        try:
            open_ended = bool(has_range and str(raw_range).strip().endswith('-') and end == total - 1)
        except Exception:
            open_ended = False
        tail_probe = bool(open_ended and want <= 16 * 1024 * 1024)

        if open_ended and not tail_probe:
            self._write_headers(handler, 206, job, start, end, True)
            sent = self._send_direct_telegram_range(handler, job, start, end)
            try:
                fflog('[tg-service] [%s] direct range stream sent=%s range=%s-%s cached=%s err=%r' % (_token_tag(token), sent, start, end, job.cached, job.error), 1)
            except Exception:
                pass
            return

        # Small tail probes and explicit bounded ranges can still be served as a
        # pre-fetched sparse block. For MP4 tail probes, send the whole small tail
        # to EOF so FFmpeg can find moov/index metadata.
        if not tail_probe and want > 8 * 1024 * 1024:
            want = 8 * 1024 * 1024
        try:
            data = self.submit_coro(self.fetch_range(job, start, want, timeout=24.0)).result(timeout=36.0)
        except Exception as exc:
            data = b''
            job.error = repr(exc)
        if data:
            real_end = start + len(data) - 1
            self._write_headers(handler, 206, job, start, real_end, True)
            try:
                handler.wfile.write(data)
                handler.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError) as exc:
                try:
                    fflog('[tg-service] [%s] sparse client closed/timeout after bytes=%s err=%r' % (_token_tag(token), len(data), exc), 1)
                except Exception:
                    pass
            try:
                fflog('[tg-service] [%s] sparse sent=%s-%s bytes=%s wanted=%s-%s tail=%s' % (_token_tag(token), start, real_end, len(data), start, end, tail_probe), 1)
            except Exception:
                pass
            return
        handler.send_error(504, 'Telegram service did not return bytes')

    def _send_direct_telegram_range(self, handler, job, start, end):
        """Stream a post-seek open-ended HTTP Range directly from Telegram.

        Production path: one Telethon downloader stream feeds a small Queue,
        and the HTTP thread writes those chunks to Kodi.  Older builds fetched
        1 MiB at a time and re-created the Telegram downloader for every MiB;
        on large 4 GB files that dropped real throughput far below the AES
        benchmark and caused visible buffering after seeks.
        """
        start = int(start or 0)
        end = int(end or 0)
        q = queue.Queue(maxsize=24)
        stop_event = threading.Event()
        try:
            job.direct_active.set()
        except Exception:
            pass

        async def producer():
            stream = None
            try:
                client = await self.ensure_client(job.spec)
                total = int(job.total or 0)
                location = self._document_location_from_spec(job.spec)
                if not location:
                    location = await self._refresh_location(client, job.spec)
                if not location:
                    raise RuntimeError('Telegram document location unavailable')
                dc_id = int(job.spec.get('doc_dc_id') or 0) or None
                msg_data = self._message_data_from_spec(job.spec)
                req = 512 * 1024
                if hasattr(client, '_iter_download'):
                    stream = client._iter_download(location, offset=start, request_size=req,
                                                   chunk_size=req, file_size=total or None,
                                                   dc_id=dc_id, msg_data=msg_data)
                else:
                    stream = client.iter_download(location, offset=start, request_size=req,
                                                  chunk_size=req, file_size=total or None,
                                                  dc_id=dc_id)
                pos = start
                while pos <= end and not stop_event.is_set():
                    try:
                        chunk = await asyncio.wait_for(stream.__anext__(), timeout=28.0)
                    except StopAsyncIteration:
                        break
                    if isinstance(chunk, memoryview):
                        chunk = chunk.tobytes()
                    else:
                        chunk = bytes(chunk or b'')
                    if not chunk:
                        break
                    if pos + len(chunk) - 1 > end:
                        chunk = chunk[:max(0, end - pos + 1)]
                    if not chunk:
                        break
                    pos += len(chunk)
                    while not stop_event.is_set():
                        try:
                            q.put_nowait(chunk)
                            break
                        except queue.Full:
                            await asyncio.sleep(0.05)
                try:
                    q.put_nowait(None)
                except Exception:
                    pass
            except Exception as exc:
                job.error = repr(exc)
                try:
                    q.put_nowait(exc)
                except Exception:
                    pass
            finally:
                try:
                    close = getattr(stream, 'close', None)
                    if close:
                        res = close()
                        if asyncio.iscoroutine(res):
                            await res
                except Exception:
                    pass

        fut = self.submit_coro(producer())
        sent = 0
        pos = start
        last_log = time.time()
        last_data = time.time()
        try:
            while pos <= end and not job.stop.is_set():
                job.touch()
                try:
                    item = q.get(timeout=30.0)
                except queue.Empty:
                    try:
                        fflog('[tg-service] [%s] direct stream queue timeout sent=%s pos=%s err=%r' % (_token_tag(job.token), sent, pos, job.error), 1)
                    except Exception:
                        pass
                    break
                if item is None:
                    break
                if isinstance(item, BaseException):
                    try:
                        fflog('[tg-service] [%s] direct stream producer error sent=%s pos=%s err=%r' % (_token_tag(job.token), sent, pos, item), 1)
                    except Exception:
                        pass
                    break
                data = item
                try:
                    handler.wfile.write(data)
                    handler.wfile.flush()
                except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError) as exc:
                    try:
                        fflog('[tg-service] [%s] direct stream client closed/timeout sent=%s pos=%s err=%r' % (_token_tag(job.token), sent, pos, exc), 1)
                    except Exception:
                        pass
                    return sent
                n = len(data)
                sent += n
                pos += n
                last_data = time.time()
                now = time.time()
                if now - last_log > 30:
                    last_log = now
        finally:
            stop_event.set()
            try:
                job.direct_active.clear()
            except Exception:
                pass
            try:
                fut.cancel()
            except Exception:
                pass
        return sent

    def _send_from_progressive_cache(self, handler, job, start, end, wait_for_more=True):
        pos = int(start or 0)
        end = int(end or 0)
        sent = 0
        last_progress = time.time()
        while pos <= end:
            job.touch()
            data = job.read_cached(pos, min(256 * 1024, end - pos + 1))
            if not data:
                if not wait_for_more or job.done or job.error:
                    break
                if time.time() - last_progress > 26:
                    try:
                        fflog('[tg-service] [%s] cache wait timeout pos=%s cached=%s sent=%s' % (_token_tag(job.token), pos, job.cached, sent), 1)
                    except Exception:
                        pass
                    break
                job.event.wait(0.20)
                job.event.clear()
                continue
            try:
                handler.wfile.write(data)
                handler.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError) as exc:
                # Kodi may open/close several speculative HTTP connections while
                # probing MP4 metadata or after a seek. Do NOT stop the Telegram
                # downloader here; a single closed HTTP request is not a stream
                # cancellation.
                try:
                    fflog('[tg-service] [%s] client closed/timeout after sent=%s; downloader remains alive err=%r' % (_token_tag(job.token), sent, exc), 1)
                except Exception:
                    pass
                return sent
            n = len(data)
            pos += n
            sent += n
            last_progress = time.time()
        return sent

    def _document_location_from_spec(self, spec):
        try:
            from telethon.tl.types import InputDocumentFileLocation
            doc_id = int(spec.get('doc_id') or 0)
            doc_hash = int(spec.get('doc_access_hash') or 0)
            ref = spec.get('doc_file_reference') or ''
            if not (doc_id and doc_hash and ref):
                return None
            ref_bytes = base64.urlsafe_b64decode((str(ref) + '=' * (-len(str(ref)) % 4)).encode('ascii'))
            return InputDocumentFileLocation(doc_id, doc_hash, ref_bytes, '')
        except Exception:
            return None

    async def _refresh_location(self, client, spec):
        try:
            from telethon.tl.types import InputPeerChannel, InputPeerChat
            chat_id = int(spec.get('chat_id') or 0)
            access_hash = int(spec.get('access_hash') or 0)
            peer_type = (spec.get('peer_type') or '').lower()
            if peer_type in ('chat', 'group') and chat_id:
                entity = InputPeerChat(chat_id)
            elif chat_id and access_hash:
                entity = InputPeerChannel(chat_id, access_hash)
            else:
                entity = spec.get('chat_ref') or chat_id
            msg = await client.get_messages(entity, ids=int(spec.get('message_id') or 0))
            doc = getattr(getattr(msg, 'media', None), 'document', None)
            if not doc:
                return None
            spec['doc_id'] = str(getattr(doc, 'id', '') or '')
            spec['doc_access_hash'] = str(getattr(doc, 'access_hash', '') or '')
            ref_bytes = getattr(doc, 'file_reference', b'') or b''
            if ref_bytes:
                spec['doc_file_reference'] = base64.urlsafe_b64encode(ref_bytes).decode('ascii').rstrip('=')
            spec['doc_dc_id'] = str(getattr(doc, 'dc_id', '') or '')
            try:
                real_size = int(getattr(doc, 'size', 0) or 0)
                if real_size > 0:
                    spec['size'] = real_size
            except Exception:
                pass
            try:
                mime = getattr(doc, 'mime_type', '') or ''
                if mime:
                    spec['mime'] = mime
            except Exception:
                pass
            try:
                from telethon.tl.types import DocumentAttributeFilename
                for attr in getattr(doc, 'attributes', []) or []:
                    if isinstance(attr, DocumentAttributeFilename) and getattr(attr, 'file_name', None):
                        spec['filename'] = attr.file_name
                        break
            except Exception:
                pass
            return self._document_location_from_spec(spec)
        except Exception:
            fflog_exc(1)
            return None

    def _message_data_from_spec(self, spec):
        try:
            from telethon.tl.types import InputPeerChannel, InputPeerChat
            chat_id = int((spec or {}).get('chat_id') or 0)
            msg_id = int((spec or {}).get('message_id') or 0)
            if not (chat_id and msg_id):
                return None
            access_hash = int((spec or {}).get('access_hash') or 0)
            peer_type = ((spec or {}).get('peer_type') or '').lower()
            if peer_type in ('chat', 'group'):
                peer = InputPeerChat(chat_id)
            elif access_hash:
                peer = InputPeerChannel(chat_id, access_hash)
            else:
                peer = (spec or {}).get('chat_ref') or chat_id
            return (peer, msg_id)
        except Exception:
            return None

    async def fetch_range(self, job, offset, want, timeout=18.0):
        """Fetch a contiguous Telegram byte range with Telethon's downloader.

        The previous service used a manual upload.getFile call with
        cdn_supported=False. Many large Telegram videos are served through the
        CDN path; Telethon's internal downloader already handles FileCdnRedirect,
        FileMigrate and file_reference refresh. Use that instead of reimplementing
        the raw file protocol.
        """
        client = await self.ensure_client(job.spec)
        offset = int(max(0, offset or 0))
        want = int(max(1, want or 0))
        total = int(job.total or 0)
        if total:
            want = min(want, max(0, total - offset))
        if want <= 0:
            return b''

        location = self._document_location_from_spec(job.spec)
        if not location:
            location = await self._refresh_location(client, job.spec)
        if not location:
            raise RuntimeError('Telegram document location unavailable')
        dc_id = int(job.spec.get('doc_dc_id') or 0) or None
        msg_data = self._message_data_from_spec(job.spec)

        # Small requests are good for the first byte, but sparse MP4 tail
        # probes must not be split into dozens of tiny Telegram requests.  With
        # tgcrypto_ctypes the decryption bottleneck is gone, so use larger pieces
        # for non-prefix/range fetches to reduce round-trip overhead.
        if offset < 1024 * 1024 and want <= 512 * 1024:
            req = 128 * 1024
        elif want >= 1024 * 1024:
            # Telegram's practical request ceiling is 512 KiB.  Use it for
            # larger reads so a single downloader stream yields fewer chunks.
            req = 512 * 1024
        else:
            req = 256 * 1024
        req = min(req, max(4096, want))
        req = (req // 4096) * 4096
        if req < 4096:
            req = 4096

        stream = None
        out = []
        got = 0
        try:
            if hasattr(client, '_iter_download'):
                stream = client._iter_download(location, offset=offset, request_size=req,
                                               chunk_size=req, file_size=total or None,
                                               dc_id=dc_id, msg_data=msg_data)
            else:
                stream = client.iter_download(location, offset=offset, request_size=req,
                                              chunk_size=req, file_size=total or None,
                                              dc_id=dc_id)
            while got < want:
                try:
                    chunk = await asyncio.wait_for(stream.__anext__(), timeout=float(timeout or 18.0))
                except StopAsyncIteration:
                    break
                if isinstance(chunk, memoryview):
                    chunk = chunk.tobytes()
                else:
                    chunk = bytes(chunk or b'')
                if not chunk:
                    break
                need = want - got
                if len(chunk) > need:
                    chunk = chunk[:need]
                out.append(chunk)
                got += len(chunk)
                if got >= want:
                    break
            data = b''.join(out)
            if not data:
                raise RuntimeError('Telethon downloader returned no bytes')
            return data
        finally:
            try:
                close = getattr(stream, 'close', None)
                if close:
                    res = close()
                    if asyncio.iscoroutine(res):
                        await res
            except Exception:
                pass

    def stop_all(self):
        try:
            with self.jobs_lock:
                for job in self.jobs.values():
                    try:
                        job.stop.set()
                    except Exception:
                        pass
                    try:
                        job.cleanup_cache_file()
                    except Exception:
                        pass
                self.jobs.clear()
            _cleanup_stream_cache(max_bytes=256 * 1024 * 1024, max_age=0)
        except Exception:
            pass
        try:
            if self.server:
                self.server.shutdown()
        except Exception:
            pass
        try:
            if self.loop:
                async def _disc():
                    if self.client:
                        await self.client.disconnect()
                try:
                    self.submit_coro(_disc()).result(timeout=5.0)
                except Exception:
                    pass
                self.loop.call_soon_threadsafe(self.loop.stop)
        except Exception:
            pass


def start_service(preferred_port=0, monitor=None):
    global _SERVICE
    with _SERVICE_LOCK:
        if _SERVICE and _SERVICE.running:
            return _SERVICE.port
        _SERVICE = TelegramStreamService(preferred_port=preferred_port)
        return _SERVICE.start(monitor=monitor)


def ensure_service(preferred_port=0):
    return start_service(preferred_port=preferred_port, monitor=None)


def stop_service():
    global _SERVICE
    with _SERVICE_LOCK:
        if _SERVICE:
            try:
                _SERVICE.stop_all()
            except Exception:
                pass
            _SERVICE = None
        try:
            st = status_path()
            if os.path.exists(st):
                os.remove(st)
        except Exception:
            pass


def register_with_service(spec, preferred_port=0, timeout=35.0):
    """Client-side helper used by the source resolver.

    It talks to the persistent service if available. As a rescue path it may
    start the service inside the current interpreter, but normal operation should
    be service.py -> start_service().
    """
    try:
        import requests
        port = int((_read_status() or {}).get('port') or 0)
        if port:
            try:
                r = requests.get('http://127.0.0.1:%d/ping' % port, timeout=1.2)
                if r.status_code != 200:
                    port = 0
            except Exception:
                port = 0
        if not port:
            port = ensure_service(preferred_port=preferred_port)
            # Give HTTP thread a tiny moment to bind/write status.
            time.sleep(0.25)
        if not port:
            return {'ok': False, 'error': 'Telegram stream service is not running'}
        r = requests.post('http://127.0.0.1:%d/control/register' % port, data=json.dumps(spec or {}).encode('utf-8'),
                          headers={'Content-Type': 'application/json; charset=utf-8'}, timeout=float(timeout or 35.0))
        try:
            data = r.json()
        except Exception:
            data = {'ok': False, 'error': r.text[:300]}
        return data
    except Exception as exc:
        fflog_exc(1)
        return {'ok': False, 'error': repr(exc)}
