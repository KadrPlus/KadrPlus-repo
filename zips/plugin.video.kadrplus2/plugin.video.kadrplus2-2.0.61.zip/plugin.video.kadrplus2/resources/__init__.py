"""Kadr+ 2.0 resource helpers."""
