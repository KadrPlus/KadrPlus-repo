"""Small portable lock shared by Kodi's separate Python interpreters."""
from contextlib import contextmanager
from pathlib import Path
import time


@contextmanager
def profile_lock(profile, name, *, timeout=5, stale_after=60):
    profile = Path(profile)
    profile.mkdir(parents=True, exist_ok=True)
    path = profile / name
    deadline = time.monotonic() + timeout
    while True:
        try:
            path.mkdir()
            break
        except FileExistsError:
            try:
                if time.time() - path.stat().st_mtime > stale_after:
                    path.rmdir()  # Remove only an empty, abandoned lock.
                    continue
            except FileNotFoundError:
                continue
            if time.monotonic() >= deadline:
                raise OSError('Profile storage is busy')
            time.sleep(.05)
    try:
        yield
    finally:
        path.rmdir()
