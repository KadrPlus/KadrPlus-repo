# -*- coding: utf-8 -*-
"""Bundled application defaults. Copyright (C) 2026 :) — MIT.

The payload is obfuscated, not a secret vault: any client that uses an API key
can also recover it. Keep keys out of settings defaults, diagnostics and URLs
where the API supports an Authorization header. No user settings are written.
"""
from __future__ import annotations

import base64
import json
import zlib
from functools import lru_cache

_PAYLOAD = (
    'c-mc1O>crQ82&Gw7efo>V>cCNiUMPz@NzM2DNqFCaGS!i|31iWyFTA}zGok8&QFV1I(wekJa<f6<Auoz#<^)~5*3'
    '!PEX`nu2yOQCr{<D%vKtMu_bR>-DpVdl3={>*bLJD6C(#H}1KNlLb$N#tFeF(8EyY2-Z2Sat7=-S-Z<QY(Ykx&=v'
    '?VH2)bwL9gfWo7jryQB9$|dA`|hIOt-K*m=#+~COdk-h5!6{V=94UWIm58P*~Y6fH&T-puyfB+Uxm$0LAt!Ay4S$'
    'CE8X8!-X42_n=d}~rP>_4gaLlH{qsdnT!LKm3ADT*vKM&h>RS}b^{&{~<yK55$VQeOYftQ|PAVUd(1~r@gpmJa#c'
    'tI|=LNH+bZpBs9D<Nz7M6`T7EU3Al%wtE7q5zb*8'
)


@lru_cache(maxsize=1)
def _defaults():
    return json.loads(zlib.decompress(base64.b85decode(_PAYLOAD)).decode('utf-8'))


def tmdb_credentials():
    data = _defaults()
    return data['tmdb_API'], data['tmdb_bearer']


def telegram_credentials(api_id='', api_hash=''):
    """Use bundled credentials only when no existing credential pair is set.

    Never mix half of a custom pair with defaults belonging to another app.
    Even incomplete legacy entries are preserved for recovery from backup.
    """
    saved_id = str(api_id or '').strip()
    saved_hash = str(api_hash or '').strip()
    if saved_id not in ('', '0') or saved_hash:
        return saved_id, saved_hash
    data = _defaults()
    return data['telegram_api_id'], data['telegram_api_hash']
