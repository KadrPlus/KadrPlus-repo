"""Bundled application defaults. User Trakt keys override them from encrypted profile storage."""
import base64
import json
import zlib
from .bundled_credentials import tmdb_credentials

# Legacy non-Trakt app defaults, obfuscated to avoid accidental log disclosure.
_PAYLOAD = 'c$}+NDk)1zigyg~RI*Y~^73`|x9|z{@QjEsH*<FPQ_@jTN=wX3EGj7}1F4D6POSu~vrMxvF-tX1O*TwTv@}UeOfgNdNHj4vOfgI`GD|WsR;mR6j8qxr'
globals().update(json.loads(zlib.decompress(base64.b85decode(_PAYLOAD)).decode('utf-8')))

# Default Trakt application pair. Keep it out of settings/profile plaintext;
# user-provided keys are stored encrypted and always take precedence.
_TRAKT_PAYLOAD = 'c-pI0Dk)0LE{S&x@Kmx=a(4+%E-DW5H1tj_bqpx-u8N2^jg0Wku`nnO@X__~t*WprtIX9+FY`4}(t+wMPE9UKEdgo{%kVZY%Q5y2F3Bj$we(LmNs6jUi4Vy&b2p9mFo`e-DAsj1bMXr(v-DJ|1pskLCw2'
_trakt_defaults = json.loads(zlib.decompress(base64.b85decode(_TRAKT_PAYLOAD)).decode('utf-8'))

tmdb_API, tmdb_bearer = tmdb_credentials()
trakt_API = _trakt_defaults['trakt_API']
trakt_secret = _trakt_defaults['trakt_secret']
del _trakt_defaults
