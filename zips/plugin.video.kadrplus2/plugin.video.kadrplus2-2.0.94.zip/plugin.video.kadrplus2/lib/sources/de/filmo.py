# -*- coding: UTF-8 -*-
# SPDX-FileCopyrightText: 2026 divoff
# SPDX-License-Identifier: MIT
# Contact: https://t.me/div0ff

"""Filmo.to movie source adapter for Kadr+ 2.0.

Filmo groups provider buttons by audio language.  Each button carries a short
site payload; the public page mints the real hoster URL only when the user
opens it.  Kadr+ keeps every language/hoster variant as a separate source and
performs the mint step fresh at playback time in the same HTTP session as the
movie page, so expired CSRF/session data is not cached in the source list.
"""

from __future__ import annotations

import base64
import json
import re
import unicodedata
from difflib import SequenceMatcher
from html import unescape
from html.parser import HTMLParser
from urllib.parse import quote, unquote, urljoin, urlsplit

from lib.ff import requests
from lib.ff.log_utils import fflog, fflog_exc


_BASE_URL = "https://filmo.to"
_BASE_HOSTS = frozenset(("filmo.to", "www.filmo.to"))
_REF_PREFIX = "kadr-filmo:"
_YEAR_RE = re.compile(r"(?<!\d)((?:19|20)\d{2})(?!\d)")
_TAG_RE = re.compile(r"<[^>]+>")
_H1_RE = re.compile(r"<h1\b[^>]*>(.*?)</h1>", re.IGNORECASE | re.DOTALL)
_DATE_RE = re.compile(
    r"Erscheinungsdatum.{0,700}?((?:19|20)\d{2})(?:-\d{2}-\d{2})?",
    re.IGNORECASE | re.DOTALL,
)
_ORIGINAL_LANG_RE = re.compile(
    r"Originalsprache.{0,400}?<(?:dd|div|span)[^>]*>\s*([^<]{1,30})",
    re.IGNORECASE | re.DOTALL,
)
_CSRF_RE = re.compile(
    r"<meta\b[^>]*name=[\"']csrf-token[\"'][^>]*content=[\"']([^\"']+)",
    re.IGNORECASE,
)


def _diag(stage, message=""):
    try:
        from lib.ff import diagnostics
        if not diagnostics.enabled():
            return
        diagnostics.log_event("filmo", ("stage=%s; %s" % (stage, message)).rstrip("; "))
    except Exception:
        pass


def _attrs(values):
    return {str(key).lower(): (value or "") for key, value in values}


def _clean_text(value):
    value = unescape(_TAG_RE.sub(" ", str(value or "")))
    return re.sub(r"\s+", " ", value).strip()


def _normalize_title(value):
    value = str(value or "").replace("ß", "ss")
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    value = re.sub(r"[^a-z0-9]+", " ", value.lower())
    return re.sub(r"\s+", " ", value).strip()


def _title_score(candidate, wanted):
    left = _normalize_title(candidate)
    right = _normalize_title(wanted)
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0
    if left in right or right in left:
        return 0.90
    return SequenceMatcher(None, left, right).ratio()


def _unique_titles(localtitle, title, aliases):
    result = []

    def add(value):
        value = re.sub(r"\s+", " ", str(value or "")).strip()
        key = _normalize_title(value)
        if value and key and all(_normalize_title(current) != key for current in result):
            result.append(value)

    add(localtitle)
    add(title)
    alias_values = list(aliases or ())
    # German catalogues are most likely to use the German TMDB alias.  Try it
    # before unrelated international aliases so a missing title does not turn
    # into a long fan-out of network searches.
    for alias in alias_values:
        if isinstance(alias, dict) and str(alias.get("country") or "").lower() in ("de", "deu", "germany"):
            add(alias.get("title") or alias.get("originalname") or alias.get("name"))
    for alias in alias_values:
        if isinstance(alias, dict):
            add(alias.get("title") or alias.get("originalname") or alias.get("name"))
        else:
            add(alias)
    return result


def _year(value):
    match = _YEAR_RE.search(str(value or ""))
    return match.group(1) if match else ""


def _quality(value):
    value = str(value or "").upper()
    if re.search(r"(?:2160|\b4K\b|\bUHD\b)", value):
        return "4K"
    if "1440" in value:
        return "1440p"
    if re.search(r"1080|\bFHD\b", value):
        return "1080p"
    if re.search(r"720|\bHD\b", value):
        return "720p"
    if re.search(r"\bCAM\b|TELESYNC|\bTS\b", value):
        return "CAM"
    return "SD"


def _display_metadata(value, quality):
    """Keep release/source details, but do not repeat the left quality badge."""
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    patterns = {
        "4K": r"(?i)(?<!\w)(?:2160p?|4k|uhd)(?!\w)",
        "1440p": r"(?i)(?<!\w)1440p?(?!\w)",
        "1080p": r"(?i)(?<!\w)(?:1080p?|fhd)(?!\w)",
        "720p": r"(?i)(?<!\w)720p?(?!\w)",
        "CAM": r"(?i)(?<!\w)(?:cam|telesync|ts)(?!\w)",
    }
    pattern = patterns.get(str(quality or ""))
    if pattern:
        text = re.sub(pattern, " ", text)
    text = re.sub(r"\s+", " ", text).strip(" -|/\t")
    return text


def _lang_bucket(label, original_language=""):
    raw = re.sub(r"\s+", " ", unescape(str(label or ""))).strip()
    norm = _normalize_title(raw)
    aliases = {
        "de": "de", "deu": "de", "deutsch": "de", "german": "de", "germanisch": "de",
        "en": "en", "eng": "en", "english": "en", "englisch": "en",
        "fr": "fr", "fra": "fr", "fre": "fr", "francais": "fr", "french": "fr", "franzosisch": "fr",
        "it": "it", "ita": "it", "italiano": "it", "italian": "it", "italienisch": "it",
        "es": "es", "spa": "es", "espanol": "es", "spanish": "es", "spanisch": "es",
        "pt": "pt", "por": "pt", "portugues": "pt", "portuguese": "pt", "portugiesisch": "pt",
        "pl": "pl", "pol": "pl", "polski": "pl", "polish": "pl", "polnisch": "pl",
        "ko": "ko", "kor": "ko", "korean": "ko", "koreanisch": "ko",
        "ru": "ru", "rus": "ru", "russian": "ru", "russisch": "ru",
    }
    if norm in aliases:
        return aliases[norm], raw or norm.upper()
    if norm in ("original", "originalton", "original audio", "ov"):
        orig = _normalize_title(original_language)
        if orig in aliases:
            return aliases[orig], raw or "Original"
    # The source list has a closed set of sortable language buckets.  Keep an
    # unknown real label visible in info but use MULTI rather than guessing.
    return "multi", raw or "Unknown"


def _is_filmo_url(url):
    try:
        parsed = urlsplit(str(url or ""))
        return parsed.scheme in ("http", "https") and (parsed.hostname or "").lower() in _BASE_HOSTS
    except Exception:
        return False


def _encode_ref(page_url, link_id, hoster, language_raw, quality):
    data = {
        "page": page_url,
        "id": str(link_id or "")[:32],
        "hoster": str(hoster or "")[:80],
        "lang": str(language_raw or "")[:80],
        "quality": str(quality or "")[:20],
    }
    raw = json.dumps(data, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return _REF_PREFIX + base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _decode_ref(value):
    value = str(value or "")
    if not value.startswith(_REF_PREFIX):
        return None
    try:
        token = value[len(_REF_PREFIX):]
        token += "=" * (-len(token) % 4)
        data = json.loads(base64.urlsafe_b64decode(token.encode("ascii")).decode("utf-8"))
        page = str(data.get("page") or "")
        if not _is_filmo_url(page) or not urlsplit(page).path.startswith("/movies/"):
            return None
        return {
            "page": page,
            "id": str(data.get("id") or ""),
            "hoster": str(data.get("hoster") or ""),
            "lang": str(data.get("lang") or ""),
            "quality": str(data.get("quality") or ""),
        }
    except Exception:
        return None


class _SearchParser(HTMLParser):
    """Collect movie-card URLs and their visible title from Filmo search HTML."""

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.items = []
        self._seen = set()
        self._anchor = None
        self._anchor_depth = 0
        self._title_depth = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        data = _attrs(attrs)
        if self._anchor is not None:
            if tag == "a":
                self._anchor_depth += 1
            classes = data.get("class", "")
            if "__title" in classes or classes.endswith("title"):
                self._title_depth += 1
            if tag == "img" and not self._anchor.get("fallback"):
                self._anchor["fallback"] = data.get("alt", "")
            return
        if tag != "a":
            return
        href = urljoin(_BASE_URL + "/", data.get("href", ""))
        if not _is_filmo_url(href) or not urlsplit(href).path.startswith("/movies/"):
            return
        self._anchor = {"url": href, "title_parts": [], "all_parts": [], "fallback": data.get("title", "")}
        self._anchor_depth = 1
        self._title_depth = 0

    def handle_data(self, data):
        if self._anchor is None:
            return
        self._anchor["all_parts"].append(data)
        if self._title_depth:
            self._anchor["title_parts"].append(data)

    def handle_endtag(self, tag):
        if self._anchor is None:
            return
        tag = tag.lower()
        if self._title_depth and tag != "a":
            self._title_depth = max(0, self._title_depth - 1)
        if tag != "a":
            return
        self._anchor_depth -= 1
        if self._anchor_depth > 0:
            return
        item = self._anchor
        self._anchor = None
        title = re.sub(r"\s+", " ", "".join(item["title_parts"])).strip()
        if not title:
            title = re.sub(r"\s+", " ", str(item.get("fallback") or "")).strip()
        if not title:
            title = re.sub(r"\s+", " ", "".join(item["all_parts"])).strip()
        if not title:
            title = urlsplit(item["url"]).path.rsplit("/", 1)[-1].replace("-", " ")
        if item["url"] not in self._seen:
            self._seen.add(item["url"])
            self.items.append({"url": item["url"], "title": title})


class _ProviderParser(HTMLParser):
    """Read every language/hoster chip while keeping language groups separate."""

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.items = []
        self.current_language = ""
        self._language_parts = None
        self._chip = None
        self._chip_div_depth = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        data = _attrs(attrs)
        classes = set(data.get("class", "").split())

        if tag == "span" and "provider-row__lang" in classes:
            self._language_parts = []

        if self._chip is not None:
            if tag == "div":
                self._chip_div_depth += 1
            return

        if tag == "div" and ("data-p" in data) and (
            "data-provider-chip" in data or "provider-chip" in classes
        ):
            self._chip = {
                "data_p": data.get("data-p", ""),
                "link_id": data.get("data-movie-link-id", ""),
                "hoster": data.get("aria-label", "") or data.get("title", ""),
                "language": self.current_language,
                "text": [],
            }
            self._chip_div_depth = 1

    def handle_data(self, data):
        if self._language_parts is not None:
            self._language_parts.append(data)
        if self._chip is not None:
            self._chip["text"].append(data)

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag == "span" and self._language_parts is not None:
            value = re.sub(r"\s+", " ", "".join(self._language_parts)).strip()
            if value:
                self.current_language = value
            self._language_parts = None

        if self._chip is not None and tag == "div":
            self._chip_div_depth -= 1
            if self._chip_div_depth <= 0:
                item = self._chip
                self._chip = None
                text = re.sub(r"\s+", " ", " ".join(item.pop("text", []))).strip()
                item["text"] = text
                if item.get("data_p") and item.get("language"):
                    self.items.append(item)



def _is_external_http(url):
    parsed = urlsplit(str(url or "").strip())
    return (
        parsed.scheme in ("http", "https")
        and bool(parsed.hostname)
        and (parsed.hostname or "").lower() not in _BASE_HOSTS
    )


def _external_redirect_target(response, request_url=""):
    """Extract an external hoster target from HTTP, meta or simple JS redirects."""
    candidates = []

    def add(value, base=""):
        value = unescape(str(value or "")).strip().strip('"\' ')
        if not value:
            return
        absolute = urljoin(base or request_url or "", value)
        if _is_external_http(absolute) and absolute not in candidates:
            candidates.append(absolute)

    add(getattr(response, "url", ""), request_url)
    headers = getattr(response, "headers", {}) or {}
    add(headers.get("Location", ""), request_url)
    for previous in getattr(response, "history", ()) or ():
        previous_url = str(getattr(previous, "url", "") or request_url)
        add((getattr(previous, "headers", {}) or {}).get("Location", ""), previous_url)

    text = unescape(str(getattr(response, "text", "") or ""))
    patterns = (
        r'(?is)<meta[^>]+http-equiv=["\']?refresh["\']?[^>]+content=["\'][^"\']*?url\s*=\s*([^"\'>;]+)',
        r'(?is)<meta[^>]+content=["\'][^"\']*?url\s*=\s*([^"\'>;]+)["\'][^>]+http-equiv=["\']?refresh',
        r'(?is)(?:window\.)?location(?:\.href)?\s*=\s*["\']([^"\']+)',
        r'(?is)(?:window\.)?location\.replace\(\s*["\']([^"\']+)',
        r'(?is)<iframe[^>]+src=["\']([^"\']+)',
    )
    for pattern in patterns:
        for match in re.findall(pattern, text):
            add(match, request_url)
    return candidates[0] if candidates else ""


def _mint_payload_value(payload):
    """Return the first useful mint value used by current/older Filmo backends."""
    if not isinstance(payload, dict):
        return ""
    for key in ("x", "url", "redirect", "target", "href"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    data = payload.get("data")
    if isinstance(data, dict):
        for key in ("x", "url", "redirect", "target", "href"):
            value = data.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
    return ""


def _detail_info(html):
    title = ""
    match = _H1_RE.search(html or "")
    if match:
        title = _clean_text(match.group(1))
    year = ""
    match = _DATE_RE.search(html or "")
    if match:
        year = match.group(1)
    original = ""
    match = _ORIGINAL_LANG_RE.search(html or "")
    if match:
        original = _clean_text(match.group(1))
    return {"title": title, "year": year, "original_language": original}


class source:
    has_sort_order = True
    priority = 2
    language = ["de"]

    def __init__(self):
        self.priority = 2
        self.language = ["de"]
        self.base_link = _BASE_URL
        self.headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
            ),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "de-DE,de;q=0.9,en;q=0.5",
            "Referer": _BASE_URL + "/",
        }
        self.session = self._new_session()
        self._search_cache = {}
        self._page_cache = {}

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        titles = _unique_titles(localtitle, title, aliases)
        wanted_year = _year(year or kwargs.get("year_alt"))
        if not titles:
            return None
        try:
            candidates = []
            seen = set()
            for query in titles[:4]:
                for item in self._search(query):
                    if item["url"] in seen:
                        continue
                    seen.add(item["url"])
                    score = max(_title_score(item.get("title"), wanted) for wanted in titles)
                    if score >= 0.60:
                        candidates.append((score, item))
                # Exact visible search title is strong enough to verify now.
                if candidates and max(pair[0] for pair in candidates) >= 1.0:
                    break

            candidates.sort(key=lambda pair: pair[0], reverse=True)
            for search_score, item in candidates[:4]:
                html, unused_csrf = self._fetch_movie_page(item["url"], use_cache=True)
                info = _detail_info(html)
                canonical = info.get("title") or item.get("title") or ""
                title_score = max(_title_score(canonical, wanted) for wanted in titles)
                if title_score < 0.78:
                    continue
                item_year = info.get("year") or ""
                if wanted_year and item_year and item_year != wanted_year:
                    continue
                parser = _ProviderParser()
                parser.feed(html)
                parser.close()
                if not parser.items:
                    continue
                _diag(
                    "movie",
                    "matched=true; year=%s; variants=%d" % (item_year or "?", len(parser.items)),
                )
                return item["url"]

            _diag("movie", "matched=false; candidates=%d" % len(candidates))
            return None
        except Exception as exc:
            self._kadr_last_error = "%s: %s" % (type(exc).__name__, exc)
            fflog_exc()
            return None

    def sources(self, url, hostDict, hostprDict):
        if not _is_filmo_url(url) or not urlsplit(str(url)).path.startswith("/movies/"):
            return []
        try:
            html, unused_csrf = self._fetch_movie_page(url, use_cache=True)
            info = _detail_info(html)
            parser = _ProviderParser()
            parser.feed(html)
            parser.close()

            result = []
            seen = set()
            for item in parser.items:
                raw_language = str(item.get("language") or "").strip()
                language, display_language = _lang_bucket(raw_language, info.get("original_language", ""))
                hoster = re.sub(r"\s+", " ", str(item.get("hoster") or "Filmo")).strip() or "Filmo"
                quality = _quality(item.get("text"))
                key = (item.get("link_id"), hoster.casefold(), raw_language.casefold(), quality, item.get("data_p"))
                if key in seen:
                    continue
                seen.add(key)

                detail_bits = ["Audio: %s" % display_language]
                metadata = _display_metadata(item.get("text"), quality)
                if metadata:
                    detail_bits.append(metadata)
                result.append({
                    "source": hoster,
                    "quality": quality,
                    "language": language,
                    "url": _encode_ref(url, item.get("link_id"), hoster, raw_language, quality),
                    "info": " | ".join(detail_bits),
                    "direct": False,
                    "debridonly": False,
                })

            _diag(
                "sources",
                "variants=%d; languages=%s" % (
                    len(result),
                    ",".join(sorted(set(str(item.get("language") or "") for item in result))) or "none",
                ),
            )
            return result
        except Exception as exc:
            self._kadr_last_error = "%s: %s" % (type(exc).__name__, exc)
            fflog_exc()
            return []

    def resolve(self, url):
        ref = _decode_ref(url)
        if not ref:
            return None
        try:
            # Always mint with a fresh page/session so cookies and CSRF belong
            # to the same browser session even if the source list was open for
            # several minutes.
            resolved = self._mint_ref(ref)
            if resolved:
                _diag("resolve", "hoster=%s; result=ok" % (ref.get("hoster") or "?"))
                return resolved
            _diag("resolve", "hoster=%s; result=empty" % (ref.get("hoster") or "?"))
            return None
        except Exception as exc:
            self._kadr_last_error = "%s: %s" % (type(exc).__name__, exc)
            fflog_exc()
            return None

    def _new_session(self):
        session = requests.Session()
        session.headers.update(self.headers)
        return session

    def _search(self, query):
        key = _normalize_title(query)
        if key in self._search_cache:
            return self._search_cache[key]
        response = self.session.get(
            self.base_link + "/search",
            params={"q": query},
            timeout=(3, 8),
        )
        response.raise_for_status()
        parser = _SearchParser()
        parser.feed(response.text)
        parser.close()
        self._search_cache[key] = parser.items
        return parser.items

    def _fetch_movie_page(self, page_url, use_cache=False, session=None):
        if use_cache and page_url in self._page_cache:
            return self._page_cache[page_url]
        if not _is_filmo_url(page_url):
            raise ValueError("invalid Filmo page URL")
        session = session or self.session
        response = session.get(page_url, timeout=(3, 8))
        response.raise_for_status()
        html = response.text
        match = _CSRF_RE.search(html)
        csrf = unescape(match.group(1)).strip() if match else ""
        result = (html, csrf)
        if use_cache:
            self._page_cache[page_url] = result
        return result

    @staticmethod
    def _matching_chips(items, ref):
        """Return exact id first, then only equivalent host/lang/quality chips."""
        link_id = str(ref.get("id") or "")
        wanted_hoster = str(ref.get("hoster") or "").casefold()
        wanted_lang = str(ref.get("lang") or "").casefold()
        wanted_quality = str(ref.get("quality") or "")
        exact = []
        fallback = []
        seen = set()
        for item in items:
            if str(item.get("hoster") or "").casefold() != wanted_hoster:
                continue
            if str(item.get("language") or "").casefold() != wanted_lang:
                continue
            if wanted_quality and _quality(item.get("text")) != wanted_quality:
                continue
            marker = (
                str(item.get("link_id") or ""),
                str(item.get("data_p") or ""),
            )
            if marker in seen:
                continue
            seen.add(marker)
            if link_id and str(item.get("link_id") or "") == link_id:
                exact.append(item)
            else:
                fallback.append(item)
        return exact + fallback

    def _mint_ref(self, ref):
        last_status = None
        for attempt in range(2):
            session = self._new_session()
            html, csrf = self._fetch_movie_page(ref["page"], use_cache=False, session=session)
            parser = _ProviderParser()
            parser.feed(html)
            parser.close()
            items = self._matching_chips(parser.items, ref)
            if not items:
                return None

            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "X-Requested-With": "XMLHttpRequest",
                "Referer": ref["page"],
                "Origin": self.base_link,
            }
            if csrf:
                headers["X-CSRF-TOKEN"] = csrf
            try:
                cookies = session.cookies.get_dict()
            except Exception:
                cookies = {}
            xsrf = cookies.get("XSRF-TOKEN") if isinstance(cookies, dict) else None
            if xsrf:
                headers["X-XSRF-TOKEN"] = unquote(str(xsrf))

            refresh_session = False
            for item in items:
                response = session.post(
                    self.base_link + "/n",
                    json={"p": item.get("data_p")},
                    headers=headers,
                    timeout=(3, 8),
                    allow_redirects=True,
                )
                last_status = getattr(response, "status_code", None)
                if last_status == 419 and attempt == 0:
                    refresh_session = True
                    break
                response.raise_for_status()

                # A backend may now redirect directly from POST /n.
                direct = _external_redirect_target(response, self.base_link + "/n")
                if direct:
                    return direct

                try:
                    payload = response.json()
                except Exception:
                    payload = {}
                value = _mint_payload_value(payload)
                if not value:
                    continue
                value = unquote(unescape(str(value).strip()))

                # Some revisions return a complete provider URL directly.  A
                # protocol-relative URL is also a real provider URL, not a mint
                # token, so normalize it before classification.
                if value.startswith("//"):
                    value = "https:" + value
                if _is_external_http(value):
                    return value

                # Otherwise x is traditionally a token for /n/<token>.  Also
                # accept already formed same-site /n/... and n/... paths.
                value_parts = urlsplit(value)
                if value.startswith("/"):
                    minted = urljoin(self.base_link + "/", value)
                elif value.lower().startswith("n/"):
                    minted = urljoin(self.base_link + "/", value)
                elif value_parts.scheme in ("http", "https") and (value_parts.hostname or "").lower() in _BASE_HOSTS:
                    minted = value
                else:
                    minted = "%s/n/%s" % (self.base_link, quote(str(value), safe=""))

                minted_parts = urlsplit(minted)
                if (
                    minted_parts.scheme not in ("http", "https")
                    or not minted_parts.hostname
                    or minted_parts.hostname.lower() not in _BASE_HOSTS
                ):
                    continue

                final = session.get(
                    minted,
                    headers={"Referer": ref["page"], "Accept": "text/html,*/*"},
                    timeout=(3, 8),
                    allow_redirects=True,
                )
                target = _external_redirect_target(final, minted)
                if target:
                    return target

            if refresh_session:
                continue
        _diag("mint", "result=empty; status=%s; hoster=%s" % (
            last_status, ref.get("hoster") or "?",
        ))
        return None

