"""Small renderer for the Kadr+ Tools menus.

Importing the complete media router just to draw a handful of navigation
entries costs several seconds on Android TV devices.  This module mirrors the
static Tools menus with Kodi's built-in API and leaves every actual action on
the regular router.
"""

from __future__ import annotations

from pathlib import Path
from time import monotonic

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from .menu_art import navigation_poster


ADDON_ID = 'plugin.video.kadrplus2'


def _setting(addon: xbmcaddon.Addon, setting_id: str) -> str:
    return str(addon.getSetting(setting_id) or '')


def _setting_bool(addon: xbmcaddon.Addon, setting_id: str) -> bool:
    return _setting(addon, setting_id).strip().lower() == 'true'


def _finish(
    handle: int,
    rows: list[tuple[int, str, str, bool]],
    *,
    started: float,
    route_name: str,
) -> None:
    addon = xbmcaddon.Addon()
    addon_path = Path(addon.getAddonInfo('path'))
    profile = addon.getAddonInfo('profile')
    media_path = addon_path / 'resources' / 'media'
    fanart = str(addon_path / 'fanart.jpg')
    base_url = f'plugin://{ADDON_ID}'

    directory_items = []
    for label_id, route, relative_art, is_folder in rows:
        square = media_path / relative_art
        poster = navigation_poster(
            square,
            media_root=media_path,
            profile=profile,
        )
        item = xbmcgui.ListItem(label=addon.getLocalizedString(label_id))
        item.setArt({
            'thumb': str(square),
            'icon': str(square),
            'poster': poster,
            'fanart': fanart,
        })
        item.setProperty('IsPlayable', 'false')
        directory_items.append((f'{base_url}{route}', item, is_folder))

    # Match const.indexer.tools.view from the full router.  Skins use the
    # portrait ``poster`` artwork for this content type.
    xbmcplugin.setContent(handle, 'sets')
    xbmcplugin.addDirectoryItems(handle, directory_items, len(directory_items))
    xbmcplugin.endOfDirectory(
        handle,
        succeeded=True,
        updateListing=False,
        cacheToDisc=False,
    )
    if _setting_bool(addon, 'diagnostics.enabled'):
        xbmc.log(
            f'[KADR2-DIAG][route] name={route_name}; '
            f'items={len(directory_items)}; elapsed={monotonic() - started:.3f}s',
            xbmc.LOGINFO,
        )


def render_tools(handle: int, *, started: float) -> None:
    """Render the main Tools directory without loading the media router."""
    addon = xbmcaddon.Addon()
    rows: list[tuple[int, str, str, bool]] = [
        (32806, '/settings', 'common/tools.png', False),
        (30368, '/tools/settings', 'common/tools.png', True),
    ]

    tmdb_authorized = bool(
        _setting(addon, 'tmdb.sessionid')
        or _setting(addon, 'tmdb.access_token')
    )
    rows.append((
        30183 if tmdb_authorized else 30184,
        '/tools/tmdb/revoke' if tmdb_authorized else '/tools/tmdb/auth',
        'services/tmdb/main.png',
        False,
    ))

    trakt_authorized = bool(_setting(addon, 'trakt.token'))
    rows.append((
        30185 if trakt_authorized else 30187,
        '/tools/trakt/revoke' if trakt_authorized else '/tools/trakt/auth',
        'services/trakt/main.png',
        False,
    ))
    if trakt_authorized:
        rows.append((
            30186,
            '/tools/trakt/sync',
            'services/trakt/update.png',
            False,
        ))

    # The query-free /tools screen uses this fast renderer instead of
    # indexers.tools.Tools.home().  Keep the NetMirror action in sync with
    # FanFilm/full-router behaviour: show it when the provider is enabled.
    if _setting_bool(addon, 'provider.netmirror'):
        rows.append((30643, '/tools/netmirror/otp', 'common/tools.png', False))

    rows.append((32049, '/tools/views/', 'common/views.png', True))
    if _setting_bool(addon, 'enable_library'):
        rows.append((32541, '/tools/librarytools/', 'common/library.png', True))
    if _setting_bool(addon, 'downloads'):
        rows.append((30306, '/tools/download/', 'common/downloads.png', True))
    rows.extend([
        (30530, '/tools/sources_edit/', 'common/tools.png', True),
        (30254, '/tools/cache/', 'common/cache.png', True),
    ])
    if _setting_bool(addon, 'diagnostics.enabled'):
        rows.append((32964, '/tools/diagnostics/', 'common/tools.png', True))
    rows.append((30373, '/tools/web', 'common/tools.png', False))
    _finish(handle, rows, started=started, route_name='tools')



def open_addon_settings(*, started: float) -> None:
    """Open Kadr+ settings without importing the full media router."""
    addon = xbmcaddon.Addon(ADDON_ID)
    addon.openSettings()
    if _setting_bool(addon, 'diagnostics.enabled'):
        xbmc.log(
            f'[KADR2-DIAG][route] name=settings-fast; '
            f'elapsed={monotonic() - started:.3f}s',
            xbmc.LOGINFO,
        )


def render_manage_settings(handle: int, *, started: float) -> None:
    """Render the settings-management directory without loading the full router."""
    rows = [
        (30369, '/tools/settings/clean', 'common/tools.png', False),
        (30370, '/tools/settings/restore', 'common/tools.png', False),
        (30371, '/tools/settings/backup', 'common/tools.png', False),
        (30497, '/tools/settings/factory_reset', 'common/tools.png', False),
    ]
    _finish(handle, rows, started=started, route_name='tools/settings')

def render_diagnostics(handle: int, *, started: float) -> None:
    """Render the optional diagnostics directory through the fast path."""
    rows = [
        (32965, '/tools/diagnostics/system', 'common/tools.png', False),
    ]
    _finish(handle, rows, started=started, route_name='tools/diagnostics')
