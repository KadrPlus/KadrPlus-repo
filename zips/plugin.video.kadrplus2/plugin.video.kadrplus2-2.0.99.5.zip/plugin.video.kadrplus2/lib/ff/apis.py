"""Bundled application defaults. User Trakt keys override them from encrypted profile storage."""
import base64
import json
import zlib
from .bundled_credentials import tmdb_credentials

# Legacy non-Trakt app defaults, obfuscated to avoid accidental log disclosure.
_PAYLOAD = 'c$}+NDk)1zigyg~RI*Y~^73`|x9|z{@QjEsH*<FPQ_@jTN=wX3EGj7}1F4D6POSu~vrMxvF-tX1O*TwTv@}UeOfgNdNHj4vOfgI`GD|WsR;mR6j8qxr'
globals().update(json.loads(zlib.decompress(base64.b85decode(_PAYLOAD)).decode('utf-8')))

# Default Trakt application pair. Keep it out of settings/profile plaintext;
# user-provided keys are stored encrypted and always take precedence.
_TRAKT_PAYLOAD = 'c$}+NDk)0LE{S&x@Kmx=a(4+%E-DW5H1tj_bqpx-u8N2^jg0U$v@j?R@X__~t*WprtIX9+FZ1<R(t+wMPE9UKEdgo{%kVZYGc@)NF3Bj$wKPaJNs6jUi4Vy&b2p9mFo`e-DAsj1bMXr(v-DJ|1prv@Cjb'
_trakt_defaults = json.loads(zlib.decompress(base64.b85decode(_TRAKT_PAYLOAD)).decode('utf-8'))

tmdb_API, tmdb_bearer = tmdb_credentials()
trakt_API = _trakt_defaults['trakt_API']
trakt_secret = _trakt_defaults['trakt_secret']
del _trakt_defaults
