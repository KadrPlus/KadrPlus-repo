# -*- coding: utf-8 -*-

"""
    Kadr+ 2.0 Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import annotations
import datetime
import json
import random
import re
import sys
from uuid import uuid4
from time import monotonic, time as wall_time
from contextlib import suppress, contextmanager
from threading import Lock, Event
from ast import literal_eval
from enum import Enum, IntEnum
from html import unescape
from itertools import chain
from sqlite3 import dbapi2 as database, Cursor as SqlCursor, OperationalError
from typing import Union, Any, Callable, Dict, List, Set, Sequence, Iterable, Iterator, Tuple, ClassVar, TYPE_CHECKING
from typing_extensions import TypedDict, NotRequired, Unpack, Protocol, Literal, TypeAlias
from urllib.parse import parse_qsl, quote_plus, unquote
from attrs import evolve
import xbmc
import PTN
from ..ff import (
    apis,
    cache,
    cleantitle,
    client,
    control,
    debrid,
    source_utils,
)
from ..windows.sources import SourceDialog, RescanSources, EditDialog
from .info import ffinfo
from .item import FFItem
from .types import EllipsisType
from ..defs import MediaRef, MediaType
from . import player
from .db import state
from .db.playback import get_playback_item
from .db.search import sources_edit_db
from .threads import ThreadCanceled
from ..sources import SourceItem, SourceMeta, Source, scan_source_modules, clear_source_modules
from .log_utils import fflog, fflog_exc, log
from .workers import Thread
from .settings import settings
from .kotools import xsleep
from .. import FAKE
from ..kolang import L
from cdefs import SourceSearchProgressStyle
from const import const, StateMode
if TYPE_CHECKING:
    from typing_extensions import LiteralString
    from .item import FFEpisodeGroup
    from ..sources import SourceModule, SourceResolveKwargs, ProviderProtocol

try:
    import resolveurl
except Exception as e:
    print(e)
    resolveurl = None


class DeadLink(ValueError):
    """Exception raised when a source link is dead or invalid."""


Item = SourceMeta


#: Type of resolver object.
class ResolverClass(Protocol):
    name: str
    domains: Sequence[str]
    pattern: str | None = None


# 1 GiB
GB = 1024**3


def _episode_play_count_advanced(ffitem: FFItem, initial: int, current: int) -> bool:
    """Return whether this episode gained a committed watched play."""
    return bool(ffitem.ref.is_episode and int(current) > int(initial))


SourceSearchQueryKey: TypeAlias = Literal['localtitle', 'title', 'originalname', 'year', 'premiered', 'imdb', 'tmdb', 'tvshowtitle', 'season', 'episode', 'episode_group', 'ffitem']


class SourceSearchQuery(TypedDict):
    localtitle: str      # Local title (in current api language)
    title: str           # English title
    originalname: str    # Original title
    year: int
    premiered: str
    imdb: str
    tmdb: str
    tvshowtitle: str     # DEPRECATED, use `title`
    season: int | None
    episode: int | None
    episode_group: str | None
    episode_offset: dict[str | None, dict[int, int]]  # mapping [group name][group season] = episode number offset
    ffitem: FFItem


#: Link to default color.
DEFAULT_COLOR_LINK: str = "00000000"


class SortElem(Enum):  # NOTE: MUST be in the "hosts.sort.elemN" setting option order
    SERVICE = 0
    LANGUAGE = 1
    QUALITY = 2
    SIZE = 3
    NONE = 4


class Quality(IntEnum):  # NOTE: values in setting "hosts.quality.max" / "hosts.quality.min" values
    """Quality (video resolution)."""
    SD = 0
    HD = 1
    FHD = 2
    UHD = 3

    H_480 = SD
    H_720 = HD
    H_1080 = FHD
    H_2160 = UHD


class ProgressDialogProtocol(Protocol):
    """Protocol for dialogs that can show search progress."""
    def update(self, percent: int, message: str = '', *, providers: Sequence[str] | None = None) -> None: ...
    def start_provider_search(self) -> None: ...
    def iscanceled(self) -> bool: ...


class SourceDialogProtocol(Protocol):
    """Protocol for dialogs that can search sources."""
    # def __init__(self,
    query: SourceSearchQuery
    def __new__(cls,
                *args,
                sources: sources,
                item: FFItem,
                items: Sequence[Source] = (),
                query: SourceSearchQuery,
                default_query: SourceSearchQuery | None = None,
                edit_search: bool = False,
                wait_before_close: Callable[[], Any] | None = None,
                on_visible: Callable[[], Any] | None = None,
                ) -> SourceDialogProtocol: ...
    def start_search(self) -> None: ...
    def cancel_search(self) -> None: ...
    def finish_search(self, sources: Sequence[Source]) -> None: ...
    def do_modal(self) -> Source | None: ...
    def destroy(self) -> None: ...
    def update(self, percent: int, message: str = '', *, providers: Sequence[str] | None = None) -> None: ...
    def iscanceled(self) -> bool: ...


class GetSourcesKwargs(TypedDict):
    title: str
    localtitle: str
    year: int
    imdb: str
    tmdb: str
    season: int | None
    episode: int | None
    tvshowtitle: str
    premiered: str
    originalname: NotRequired[str]
    episode_group: NotRequired[str | None]
    quality: NotRequired[str]
    timeout: NotRequired[int | None]
    ffitem: FFItem
    progress_dialog: NotRequired[ProgressDialogProtocol | None]


class ProvidersSetting(dict):
    """
    Simple setting cache, for mass providers query.

    >>> so = ProvidersSetting('sort.order', default=0, source_mods=mods)
    >>> so['cda']  # value of 'cda.sort.order'
    """

    def __init__(self, name: str, *, default: Any, source_mods: list[SourceModule]) -> None:
        var_name: str = f'has_{name.replace(".", "_")}'
        super().__init__()
        #: Settings name (suffix).
        self.name: str = name
        #: Default valur if settings is not found.
        self.default: Any = default
        #: Providers with settings enabled.
        self._enabled: Set[str] = {srcmod.name for srcmod in source_mods if getattr(srcmod.provider, var_name, False)}

    def _get_settings(self, name: str) -> Any:
        return settings.getString(name)

    def __missing__(self, key: str) -> Any:
        key = key.lower()
        if key in self._enabled:
            value = self._get_settings(f'{key}.{self.name}')
        else:
            value = self.default  # default no-order
        self[key] = value
        return value


class SortOrderSettings(ProvidersSetting):
    """Simple setting cache, for mass query (sorting in filters)."""

    def __init__(self, *, source_mods: list[SourceModule]) -> None:
        super().__init__(name='sort.order', default=None, source_mods=source_mods)

    def _get_settings(self, name: str) -> int:
        return settings.getInt(name)


class ColorSettings(ProvidersSetting):
    """Simple setting cache, for mass query (sorting in filters)."""

    def __init__(self, *, source_mods: list[SourceModule]) -> None:
        super().__init__(name='color.identify2', default=None, source_mods=source_mods)


class LibraryColorSettings(ProvidersSetting):
    """Simple setting cache, for mass query (sorting in filters)."""

    def __init__(self, *, source_mods: list[SourceModule]) -> None:
        super().__init__(name='library.color.identify2', default=None, source_mods=source_mods)


class sources:
    """Main class for searching and playing sources."""

    QUALITIES = {
        Quality.UHD: {'4K', '8K'},
        Quality.FHD: {'1080', '1080p', '1080i', '1440p', '2K', 'FHD'},
        Quality.HD: {'720', '720p', 'HD'},
        Quality.SD: {'480', '480p', 'SD'},
    }
    QUALITY_NAMES = {0: 'SD', 1: '720', 2: '1080', 3: '4K'}
    TOTAL_FORMAT = "[COLOR {color}][B]{count}[/B][/COLOR]"

    # Priorytet typu języka
    language_type_priority = const.sources_dialog.language_type_priority

    # Debug. Run single source provider without threads.
    DEBUG_SINGLE_PROVIDER: ClassVar[str | None] = None

    # Dialog window factory (class).
    SOURCE_DIALOG: ClassVar[type[SourceDialogProtocol]] = SourceDialog

    def __init__(self):
        self.lock = Lock()
        self.sourceFile = control.providercacheFile
        self.selectedSource = None
        self.itemProperty = None
        self.metaProperty = None
        self.source_mods: list[SourceModule] = None
        self.host_list: list[str] = []
        self.pr_host_list: list[str] = []
        self.hq_host_list: list[str] = []
        self.sources: list[Source] = []
        # Optional diagnostics: one sanitized kodi.log record per provider.
        self._provider_stats: dict[str, dict[str, Any]] = {}
        self._diagnostics_enabled = False
        self._search_cancelled = False
        # Wall-clock point at which the current Kodi player actually closed.
        # Used only to avoid opening a return-loading dialog if the parent
        # episode directory has already finished rebuilding in the meantime.
        self._last_playback_stopped_at = 0.0
        # Resume decisions collected immediately after an exact Telegram file is
        # selected. The resolved Source copy returned by the modal consumes the
        # decision exactly once through its media-reference key.
        self._pending_resume_choices: dict[str, tuple[bool | None, float, float]] = {}
        # A Telegram selection starts its local HTTP stream before player.play()
        # is called.  Keep the same session id across that preparation, Kodi's
        # handoff and the service's OnStop result so an older /play route can
        # never consume or overwrite a newer session.
        self._pending_playback_sessions: dict[str, str] = {}
        # Ownership flag for the native busy window that covers synchronous
        # FFItem preparation.  It is released by SourceDialog.onInit(), when
        # Kodi has actually initialized the replacement modal window.  The
        # outer play() finally remains the failure-path safety net.
        self._prepare_busy_open = False
        self._prepare_busy_owner = ''
        # Provider threads that did not finish inside the short Cancel grace
        # period are kept here. A following rescan will never reuse/reset their
        # provider instance until the old thread has actually exited.
        self._lingering_provider_threads: list[tuple[Thread, SourceModule]] = []
        self.test = {}
        self.lang = control.apiLanguage()["tmdb"] or "en"
        self.exts = ("avi", "mkv", "mp4", ".ts", "mpg")  # dozwolone rozszerzenia filmów

    def play(self,
             media_type: MediaType,
             ffid: int,
             season: int | None = None,
             episode: int | None = None,
             *,
             #: If true, show edit search dialog instead of source selection.
             edit_search: bool = False,
             #: Override season and episode numbers (play as episode group).
             override_episode: tuple[int, int] | None = None,
             #: Episode group to use (used if season/episode if not set).
             episode_group: str | None | EllipsisType = ...,
             ) -> None:
        entered_play = False
        try:
            # One physical click can be delivered twice by Kodi while the first
            # /play invocation is still rebuilding the selected FFItem.  The
            # device trace showed two invocations of the same movie 3.9 seconds
            # apart; both source dialogs then searched and resolved concurrently.
            # ``ff.play`` already spans the complete source-dialog/playback
            # lifetime in the service state, so use it as the cross-invocation
            # latch instead of allowing a second resolver handle to interfere.
            if state.get('ff.play', module='player', default=False):
                try:
                    from . import diagnostics
                    diagnostics.log_event(
                        'navigation',
                        'stage=play-route; result=duplicate-ignored; '
                        'ref=%s/%s/%s/%s' % (
                            media_type, ffid, season or '', episode or '',
                        ),
                    )
                except Exception:
                    pass
                return
            # state.delete_all(module='player')
            entered_play = True
            with state.with_var('ff.play', module='player'):
                return self._play(media_type=media_type, ffid=ffid, season=season, episode=episode,
                                  edit_search=edit_search, override_episode=override_episode,
                                  episode_group=episode_group)
        except Exception:
            fflog_exc()
            raise
        finally:
            if entered_play:
                self._close_prepare_busy()
            clear_source_modules()

    def _close_prepare_busy(self) -> None:
        """Release only the busy window owned by initial source preparation."""
        if not self._prepare_busy_open:
            return
        self._prepare_busy_open = False
        owner, self._prepare_busy_owner = self._prepare_busy_owner, ''
        control.close_busy_dialog(owner=owner)

    def _play(self,
              media_type: MediaType,
              ffid: int,
              season: int | None = None,
              episode: int | None = None,
              *,
              edit_search: bool = False,
              override_episode: tuple[int, int] | None = None,
              episode_group: str | None | EllipsisType = ...,
              ) -> None:
        # mark playing state
        state.multi_set(module='player', values=(
            ('playing.run', False),
        ))

        # TODO:  -----------------------------------------------------------------
        # TODO:  ---  refaktor, bez sensu odzyskuje pewne dane, zanim użyć ffinfo
        # TODO:  -----------------------------------------------------------------

        self.sources = []  # create new list to avoid add sources after cancel
        ref: MediaRef = MediaRef(media_type, ffid, season, episode)
        # Loading the FFItem took 23.5 seconds in the failing device trace.  With
        # no modal feedback Kodi accepted another click and started a second
        # /play route.  Cover precisely this synchronous metadata gap with Kodi's
        # native non-cancellable busy window; the source dialog takes over when
        # Kodi confirms its modal XML window through onInit().
        show_prepare_busy = not edit_search
        if show_prepare_busy:
            self._prepare_busy_open = True
            self._prepare_busy_owner = 'sources-' + uuid4().hex
            # A completed-item return cover has its own 45 s failsafe.  Once a
            # new /play route starts, that old alarm must not be allowed to
            # close the new route's owned preparation/playback overlay.
            control.execute('CancelAlarm(KadrPlusEpisodeReturnBusy,true)')
            control.execute('CancelAlarm(KadrPlusMovieReturnBusy,true)')
            control.busy_dialog(
                True,
                owner=self._prepare_busy_owner,
                owner_timeout=90.0,
            )
        item_prepare_started = monotonic()
        ffitem: FFItem | None = ffinfo.find_item(
            ref, details=const.sources.info_details,
        )
        fflog(
            '[SOURCES] Item preparation completed in %.3fs for %s'
            % (monotonic() - item_prepare_started, ref)
        )
        if ffitem is None:
            return

        # override season/episode if requested (play as episode group)
        if ref.is_episode and override_episode:
            ffitem.season, ffitem.episode = override_episode
        # elif ref.is_episode and (episode_group is None or isinstance(episode_group, str)):
        #     ffinfo.switch_episode_group(ffitem, episode_group)

        if ref.type == 'show' and (sh_item := ffitem.show_item):
            vtag = sh_item.getVideoInfoTag()
            premiered = sh_item.date
            # show_title = vtag.getEnglishTvShowTitle() or sh_item.title
        else:
            vtag = ffitem.getVideoInfoTag()
            premiered = ffitem.date
            # show_title = ''
        # `title` and `show_title` should be in English.
        title = vtag.getTitle()
        en_title = vtag.getEnglishTitle() or vtag.getOriginalTitle() or title
        query: SourceSearchQuery = {
            'title': en_title,    # title is in English
            'localtitle': title,  # title is in api locale
            'originalname': vtag.getOriginalTitle(),
            'year': vtag.getYear(),
            'imdb': vtag.getUniqueID('imdb'),
            'tmdb': vtag.getUniqueID('tmdb'),
            'season': ffitem.season,
            'episode': ffitem.episode,
            'tvshowtitle': en_title if ref.type == 'show' else '',
            'premiered': str(premiered or ''),
            'episode_group': None,
            'episode_offset': {},
            'ffitem': ffitem,
        }
        default_query = query.copy()
        if const.sources_dialog.edit_search.cache and (se := sources_edit_db.get(ffitem)):
            query.update(se.data)  # type: ignore[reportArgumentType]

        # Switch episode group if needed
        eg_id: str | None = None
        if ref.is_episode:
            if episode_group is not ...:
                if TYPE_CHECKING:
                    assert not isinstance(episode_group, EllipsisType)
                query['episode_group'] = episode_group
            ffinfo.switch_episode_group(ffitem, query.get('episode_group'))
            if ffitem.episode_group.current is not None:
                default_query['season'] = ffitem.season
                default_query['episode'] = ffitem.episode
                if const.sources_dialog.edit_search.show_granularity == 'show':
                    query['season'] = ffitem.season
                    query['episode'] = ffitem.episode
                elif const.sources_dialog.edit_search.show_granularity == 'season':
                    query['episode'] = ffitem.episode
            if const.sources_dialog.edit_search.cache is not None and 'episode_offset' in const.sources_dialog.edit_search.cache and ffitem.season:
                eg_id = ffitem.episode_group.tmdb_id or None
                if offset := query['episode_offset'].get(eg_id, {}).get(ffitem.season):
                    query['episode'] = (ffitem.episode or 0) + offset
        initial_query = query.copy()  # for detect changes after rescan

        # Create window ASAP (before getConstants and other slow operations)
        # Show empty window as placebo - progress bar will be enabled later in background thread
        win: SourceDialogProtocol | None = None
        if not edit_search:
            win = self.SOURCE_DIALOG(sources=self, item=ffitem, query=query,
                                     default_query=default_query, edit_search=edit_search,
                                     on_visible=self._close_prepare_busy)

        # Initialize aliases and providers in background.  They are independent:
        # loading every provider after waiting for the public Trakt aliases call
        # made the visible "Preparing sources" phase the sum of both costs.  Run
        # them together and wait for both before providers receive the final
        # alias list.  Search accuracy is therefore unchanged on a healthy API,
        # while first-open latency is reduced to the slower of the two jobs.
        init_complete = Event()

        def init_background():
            init_started = monotonic()
            try:
                ffitem.copy_from(ffitem.season_item, ffitem.show_item)
            except Exception:
                fflog_exc()

            alias_elapsed = 0.0

            def load_aliases() -> None:
                nonlocal alias_elapsed
                started = monotonic()
                try:
                    if show_ffitem := ffitem.show_item:
                        ffinfo.get_title_aliases(show_ffitem)
                    else:
                        ffinfo.get_title_aliases(ffitem)
                except Exception:
                    fflog_exc()
                finally:
                    alias_elapsed = monotonic() - started

            alias_thread = Thread(target=load_aliases, name="SourcesAliases")
            alias_thread.start()
            constants_started = monotonic()
            try:
                self.getConstants(ffitem=ffitem)
            except Exception:
                fflog_exc()
            constants_elapsed = monotonic() - constants_started
            alias_thread.join()
            init_complete.set()
            fflog(
                '[SOURCES] Preparation completed in %.3fs '
                '(aliases=%.3fs, providers=%.3fs)'
                % (monotonic() - init_started, alias_elapsed, constants_elapsed)
            )

        # Start background initialization thread (aliases + provider loading)
        init_thread = Thread(target=init_background, name="SourcesInit")
        init_thread.start()

        log_s = f', S{ffitem.season or 0:0>2}E{ffitem.episode or 0:0>2}/group={ffitem.episode_group or ""}' if ref.is_episode else ''
        fflog(f'play(ffid={ffid!r}) ref={ref!a}{log_s}')

        with state.with_var('sources', module='player'):
            # Source searching  int loop (allows rescanning)
            while True:
                # Ensure window exists if needed (e.g., after rescan from EditDialog when edit_search changes to False)
                if not edit_search and win is None:
                    # ``items=None`` is significant: it starts the progress
                    # view and hides the result-only Rescan button until the
                    # fresh provider scan has actually finished.  Passing an
                    # empty sequence left a blank result window visible while
                    # providers were still running in the background; another
                    # click then canceled that scan after only a few seconds.
                    win = self.SOURCE_DIALOG(sources=self, item=ffitem, items=None, query=query,
                                             default_query=default_query, edit_search=edit_search)

                source_to_play: Source | None = None

                try:
                    if win:
                        with state.with_var('sources.window', module='player'):
                            # Search in background thread while window is shown
                            def search_thread(win: SourceDialogProtocol) -> None:
                                # Wait for initialization to complete
                                init_complete.wait()
                                if win.iscanceled():
                                    # Cancel can arrive while aliases/provider modules
                                    # are still being prepared.  Returning here used to
                                    # leave SourceDialog._searching=True forever, so
                                    # every subsequent Back only repeated "Stopping".
                                    # Complete the same state transition as a canceled
                                    # provider scan; there are simply no partial results
                                    # before providers have started.
                                    win.finish_search(())
                                    return
                                # SourceDialog enters search mode in its constructor.
                                # Re-entering it here reset every window property after
                                # the dialog was already visible and caused a noticeable
                                # flash on slower Android devices.
                                self.initial_progress_update(win)
                                # Search for sources
                                sources = self.get_sources(**query, progress_dialog=win) or []
                                # A cancel request stops providers but keeps the
                                # partial list. finish_search() itself ignores a
                                # dialog that was genuinely closed/destroyed.
                                win.finish_search(sources)

                            thread = Thread(target=search_thread, args=(win,), name="SourcesSearch")
                            thread.start()

                            # Show window (blocks until user closes or selects source)
                            # Search thread updates window in background
                            try:
                                source_to_play = win.do_modal()
                            finally:
                                query = win.query  # get possibly updated query from window before closing (event on cancel, to keep user edit changes)
                                # A rescan must never overlap the preceding provider
                                # search.  In particular, Telethon owns background
                                # asyncio tasks and can otherwise keep using the same
                                # account session while the next scan starts.
                                if thread.is_alive():
                                    with suppress(Exception):
                                        win.cancel_search()
                                    thread.join(timeout=5.0)
                                if thread.is_alive():
                                    thread.stop()
                                    thread.join(timeout=1.0)
                                if thread.is_alive():
                                    fflog.warning('[SOURCES] Previous search did not stop before dialog cleanup')
                                with suppress(Exception):
                                    win.destroy()
                                win = None  # remove reference to closed window
                                # make sure to finish changing sources object before allowing next search or exiting
                                init_complete.wait()
                            break  # source selected or canceled, exit while loop
                    else:
                        # make sure to finish changing sources object if there was no window
                        init_complete.wait()
                    if edit_search:
                        # edit search without source-dialog in background
                        edit_win = EditDialog(query=query, default_query=default_query)
                        edit_win.do_modal()
                        del edit_win
                        break
                except RescanSources as rescan:
                    # Rescan requested (as exception), continue loop with new query
                    if rescan.query:
                        query_changed = query != rescan.query
                        fflog(f'[SOURCES] rescan request (edit={query_changed})')
                        # Close current window before rescanning
                        if win is not None:
                            with suppress(Exception):
                                win.destroy()
                            win = None
                        # Always clear cache on rescan to get fresh results
                        # (whether query changed or user wants to refresh results)
                        from .cache import cache_clear_sources
                        self.sources.clear()
                        cache_clear_sources()
                        query = rescan.query
                        if initial_query['episode_group'] != query['episode_group']:
                            # reset season and episode to current if episode group changed, to avoid wrong offsets
                            # fflog(f'>>>>>>>>>> EG {default_query["episode_group"]!r} -> {query.get("episode_group")!r}: {default_query["season"]}x{default_query["episode"]} -> {ffitem.season}x{ffitem.episode}, eg={ffitem.episode_group}')
                            default_query['season'] = ffitem.season or 0
                            default_query['episode'] = ffitem.episode or 0
                        query['ffitem'] = ffitem
                        # Window will be recreated at the start of next loop iteration
                except Exception:
                    fflog_exc()
                    break
                finally:
                    # make sure to finish changing sources object before allowing next search or exiting
                    init_complete.wait()
                edit_search = False  # skip only first sources scan
        fflog(f'source to play {source_to_play!r}')
        if allowed := const.sources_dialog.edit_search.cache:
            if 'episode_offset' in const.sources_dialog.edit_search.cache and ffitem.season:
                def es(q: SourceSearchQuery) -> str:
                    if q['season'] is None or q['episode'] is None:
                        return 'movie'
                    if q['episode_group']:
                        return f'S{q["season"]}E{q["episode"]}({q["episode_group"]})'
                    return f'S{q["season"]}E{q["episode"]}'
                d_offset = default_query['episode'] or 0
                q_offset = query['episode'] or 0
                i_season = initial_query['season'] or 0
                i_episode_group = initial_query['episode_group']
                fflog(f'{ffitem.ref!a}, S{ffitem.season or 0:02d}E{ffitem.episode or 0:02d}:'
                      f' save episode offset: d={es(default_query)}, i={es(initial_query)}, q={es(query)}, {i_episode_group=}')
                if d_offset and q_offset and d_offset != q_offset:
                    query['episode_offset'].setdefault(query['episode_group'], {})[ffitem.season] = q_offset - d_offset
                elif episode_offset := query['episode_offset'].get(i_episode_group):
                    episode_offset.pop(i_season, 0)
                    if not episode_offset:
                        del query['episode_offset'][eg_id]
            if query == default_query and not query.get('episode_group'):
                fflog(f'{ffitem!a}: remove saved edit')
                sources_edit_db.delete(ffitem)
            else:
                save_query = {k: v for k, v in query.items() if k in allowed}
                fflog(f'{ffitem!a}: save edit: {save_query}')
                sources_edit_db.set(ffitem, save_query)
        if source_to_play:
            initial_play_count = self._play_count(ffitem.ref)
            resume_choice, resume_percent, resume_seconds = self._take_resume_choice_for_source(source_to_play)
            playback_session_id = self._take_or_begin_playback_session(source_to_play)
            with state.with_var('playing.prepare', module='player'):
                player.play(
                    source=source_to_play,
                    playback_session_id=playback_session_id,
                    resume_choice=resume_choice,
                    resume_percent=resume_percent,
                    resume_seconds=resume_seconds,
                )
            self._return_to_source_list(
                ffitem=ffitem,
                query=query,
                default_query=default_query,
                initial_play_count=initial_play_count,
                playback_session_id=playback_session_id,
            )
        else:
            with state.with_var('playing.prepare', module='player'):
                player.cancel(ffitem, clean=True)


    def _resume_choice_for_source(
        self, source: Source, *, timing: str = 'after-source-resolve',
    ) -> tuple[bool | None, float, float]:
        """Ask about a fresh local resume point after the source is selected.

        Kodi's directory-level resume prompt used to run before source search and
        its decision was then stale when a second source was chosen after Stop.
        Read the local playback DB again here so a position saved by the just-ended
        stream is immediately available.  A historical watched flag does not
        suppress a newer partial rewatch: watched and resume are independent states.
        """
        ffitem = source.ffitem
        pb = None
        try:
            pb = get_playback_item(ffitem.ref)
            if pb is not None:
                ffitem.progress = pb.as_media_progress()
            # If there is no fresh local row, keep the progress already attached
            # to the item (for example from Trakt).  That is the position used by
            # the delayed resume question after a concrete source is selected.
        except Exception:
            fflog_exc()

        media_progress = ffitem.progress
        if not media_progress:
            return None, 0.0, 0.0
        try:
            progress = float(media_progress.progress or 0.0)
        except (TypeError, ValueError):
            progress = 0.0
        if not 0.0 < progress < 100.0:
            return None, 0.0, 0.0

        try:
            duration = float((pb.duration if pb is not None else 0) or ffitem.vtag.getDuration() or 0.0)
        except (TypeError, ValueError):
            duration = 0.0
        resume_seconds = duration * progress / 100.0 if duration > 0.0 else 0.0

        shown_progress = max(1, min(99, int(round(progress))))
        try:
            from . import diagnostics
            diagnostics.log_event(
                'resume',
                'stage=prompt; timing=%s; progress=%s' % (timing, shown_progress),
            )
        except Exception:
            pass
        choice = control.yesnoDialog(
            L(33163, 'Saved position: {progress}%').format(progress=shown_progress),
            heading=L(33162, 'Resume playback?'),
            nolabel=L(33164, 'Start from beginning'),
            yeslabel=L(30422, 'Continue'),
        )
        try:
            from . import diagnostics
            diagnostics.log_event(
                'resume',
                'stage=choice; result=%s' % ('continue' if choice else 'beginning'),
            )
        except Exception:
            pass
        if not choice:
            return False, 0.0, 0.0
        return True, progress, resume_seconds

    def _take_resume_choice_for_source(self, source: Source) -> tuple[bool | None, float, float]:
        """Consume an early Telegram decision, or use the normal prompt path."""
        try:
            key = str(source.ffitem.ref)
            if key in self._pending_resume_choices:
                return self._pending_resume_choices.pop(key)
        except Exception:
            pass
        return self._resume_choice_for_source(source)

    def _begin_playback_session(self, source: Source) -> str:
        """Own loading/navigation from exact source choice through OnStop."""
        key = str(source.ffitem.ref)
        session_id = self._pending_playback_sessions.get(key)
        if not session_id:
            session_id = uuid4().hex
            self._pending_playback_sessions[key] = session_id
        # Reasserting the same owner is intentional: Kodi may close its native
        # busy window while switching from a modal source list to the player.
        control.busy_dialog(True, owner=session_id, owner_timeout=180.0)
        return session_id

    def _take_or_begin_playback_session(self, source: Source) -> str:
        """Consume a pre-stream Telegram id or create one for another source."""
        key = str(source.ffitem.ref)
        session_id = self._pending_playback_sessions.pop(key, '')
        if not session_id:
            session_id = self._begin_playback_session(source)
            self._pending_playback_sessions.pop(key, None)
        else:
            control.busy_dialog(True, owner=session_id, owner_timeout=180.0)
        return session_id

    def _discard_pending_playback_session(self, source: Source | None) -> None:
        """Release a pre-stream owner when resolve/apply is cancelled or fails."""
        if source is None:
            return
        try:
            key = str(source.ffitem.ref)
        except Exception:
            return
        session_id = self._pending_playback_sessions.pop(key, '')
        self._pending_resume_choices.pop(key, None)
        if session_id:
            control.close_busy_dialog(owner=session_id)

    @staticmethod
    def _playback_session_result(ffitem: FFItem, playback_session_id: str = '') -> str:
        """Return this item's authoritative current-session result, if ready."""
        try:
            result = str(state.get('media.playback_result', module='player', default='') or '')
            if result not in ('completed', 'interrupted'):
                return ''
            result_ref = str(state.get('media.playback_result_ref', module='player', default='') or '')
            if result_ref and result_ref != str(ffitem.ref):
                return ''
            if playback_session_id:
                result_session_id = str(state.get(
                    'media.playback_result_session_id',
                    module='player',
                    default='',
                ) or '')
                if result_session_id != playback_session_id:
                    return ''
                current_session_id = str(state.get(
                    'media.playback_session_id',
                    module='player',
                    default='',
                ) or '')
                if current_session_id != playback_session_id:
                    return ''
            return result
        except Exception:
            return ''

    @staticmethod
    def _playback_session_is_current(playback_session_id: str) -> bool:
        """Return false when a newer concrete playback owns this route."""
        if not playback_session_id:
            return True
        try:
            current = str(state.get(
                'media.playback_session_id', module='player', default='',
            ) or '')
            return current == playback_session_id
        except Exception:
            # A missing ownership check must fail closed: showing the parent or
            # an old source list is more disruptive than leaving the already
            # visible Kodi window untouched.
            return False

    @staticmethod
    def _confirmation_dialog_active() -> bool:
        """Return whether Kodi is showing a modal confirmation/OK dialog.

        Both windows use ``DialogConfirm.xml`` but have different Kodi ids:
        ``yesnodialog`` is 10100 and ``okdialog`` is 12002. Playback-open
        failures use the latter, so checking only the resume/yes-no window let
        the source list open underneath Kodi's still-active error dialog.
        """
        try:
            return bool(
                control.condVisibility('Window.IsActive(yesnodialog)')
                or control.condVisibility('Window.IsActive(okdialog)')
            )
        except Exception:
            return False

    def _wait_until_playback_finishes(
            self, *, ffitem: FFItem | None = None,
            playback_session_id: str = '') -> bool:
        """Wait for playback and the service's local OnStop commit to finish."""
        monitor = xbmc.Monitor()
        kodi_player = control.player()
        started_at = monotonic()
        started = False
        self._last_playback_stopped_at = 0.0

        while monotonic() - started_at < 60.0:
            if monitor.abortRequested():
                return False
            if (playback_session_id
                    and not self._playback_session_is_current(playback_session_id)):
                return False
            if kodi_player.isPlayingVideo():
                started = True
                break
            # Do not return while Kodi is asking whether to resume or while its
            # native playback-error OK dialog is still waiting for confirmation.
            if self._confirmation_dialog_active():
                monitor.waitForAbort(0.25)
                continue
            elapsed = monotonic() - started_at
            service_state = state.get('state', module='player', default='')
            if elapsed >= 1.0 and not service_state:
                break
            if elapsed >= 5.0 and not control.condVisibility('Player.HasMedia'):
                break
            monitor.waitForAbort(0.25)

        if started:
            while kodi_player.isPlayingVideo():
                if monitor.waitForAbort(0.5):
                    return False
            self._last_playback_stopped_at = wall_time()

            # Kodi closes the player before the service finishes OnStop.  Do not
            # inspect resume/watched state until that synchronous commit is done.
            # The device trace showed a healthy local commit arriving 7.1 s
            # after Kodi had already become idle.  Wait for the matching
            # session result, not for an arbitrary six-second timer and never
            # infer this viewing from historical play_count.
            settle_deadline = monotonic() + 30.0
            result_ready = False
            while monotonic() < settle_deadline:
                if monitor.abortRequested():
                    return False
                if (playback_session_id
                        and not self._playback_session_is_current(playback_session_id)):
                    return False
                # player.py clears this before every play. OnStop publishes it
                # only after the local playback DB is durable, so this is a much
                # stronger navigation barrier than a historical play_count.
                session_result = ''
                if ffitem is not None:
                    if playback_session_id:
                        session_result = self._playback_session_result(
                            ffitem, playback_session_id,
                        )
                    else:
                        session_result = self._playback_session_result(ffitem)
                if session_result:
                    result_ready = True
                    break
                # Kodi's player state becomes idle before the service publishes
                # the durable session result.  On the captured completed movie
                # that gap was 1.215 seconds, so treating idle as completion of
                # the barrier reopened the source list.  For a known FFItem wait
                # for the authoritative result (or the bounded six-second safety
                # timeout).  Keep the old idle fallback only for non-item callers.
                if ffitem is None:
                    service_state = str(state.get('state', module='player', default='') or '')
                    playing_video = bool(state.get('playing.video', module='player', default=False))
                    if not playing_video and service_state not in ('play', 'playing', 'stopping'):
                        break
                monitor.waitForAbort(0.10)
            if ffitem is not None and not result_ready:
                try:
                    from . import diagnostics
                    diagnostics.log_event(
                        'navigation',
                        'stage=playback-result; result=unresolved; action=leave-current-window; '
                        'session=%s' % (playback_session_id or 'legacy'),
                        level=xbmc.LOGWARNING,
                    )
                except Exception:
                    pass
                return False
        if playback_session_id:
            control.close_busy_dialog(owner=playback_session_id)
        else:
            control.close_busy_dialog()
        return not monitor.abortRequested()

    def _wait_until_parent_directory_ready(
            self, monitor, timeout: float = 35.0, *,
            parent_container_only: bool = False,
            completion_after: float | None = None,
            completion_view: str | None = None) -> bool:
        """Wait for completed-playback episode rows and their watched overlay."""
        started_at = monotonic()
        stable_since: float | None = None
        update_seen = False
        completion_seen = False
        completion_poll_due = started_at
        result = 'timeout'
        item_count = 0

        while monotonic() - started_at < timeout:
            if monitor.abortRequested():
                result = 'abort'
                break

            # Container(50) is not observable behind the modal source dialog on
            # the tested skin: it stayed at zero for the full 35 s although the
            # parent invocation had called endOfDirectory after 16.24 s. Use the
            # cross-invocation marker written immediately after that call.
            completion_now = monotonic()
            if (completion_after is not None
                    and completion_now >= completion_poll_due):
                completion_poll_due = completion_now + 0.25
                try:
                    completion = state.get_info(
                        'directory.completed',
                        module='navigation',
                        mode=StateMode.DB,
                    )
                    completion_value = completion.value if completion is not None else {}
                    completion_items = int(
                        completion_value.get('items', 0)
                        if isinstance(completion_value, dict) else 0
                    )
                    completion_marker_view = str(
                        completion_value.get('view', '')
                        if isinstance(completion_value, dict) else ''
                    )
                    if (completion is not None
                            and float(completion.updated_at or 0.0) >= float(completion_after)
                            and completion_items > 0
                            and (not completion_view
                                 or completion_marker_view == completion_view)):
                        completion_seen = True
                        item_count = completion_items
                        result = 'directory-complete'
                        break
                except Exception:
                    # The existing Kodi container conditions below remain the
                    # safe fallback if the marker DB is temporarily unavailable.
                    pass

            if parent_container_only:
                updating = bool(control.condVisibility('Container(50).IsUpdating'))
            else:
                updating = bool(
                    control.condVisibility('Container.IsUpdating')
                    or control.condVisibility('Container(50).IsUpdating')
                )
            plugin_names = tuple(
                str(control.infoLabel(label) or '')
                for label in ('Container.PluginName', 'Container(50).PluginName')
            )
            folder_paths = tuple(
                str(control.infoLabel(label) or '')
                for label in ('Container.FolderPath', 'Container(50).FolderPath')
            )
            plugin_container = bool(
                any(name == control.plugin_id for name in plugin_names)
                or any(path.startswith(control.plugin_url) for path in folder_paths)
            )
            item_count = 0
            count_labels = (
                ('Container(50).NumItems',)
                if parent_container_only
                else ('Container.NumItems', 'Container(50).NumItems')
            )
            for label in count_labels:
                try:
                    item_count = max(item_count, int(control.infoLabel(label) or 0))
                except (TypeError, ValueError):
                    pass

            if updating:
                update_seen = True
                stable_since = None
            elif (plugin_container or parent_container_only) and (update_seen or item_count > 0):
                if stable_since is None:
                    stable_since = monotonic()
                # After an observed update, Kodi's own condition is authoritative.
                # Otherwise keep a short grace period so a queued refresh has time
                # to start before the modal window covers the parent container.
                stable_for = 0.35 if update_seen else 1.50
                if monotonic() - stable_since >= stable_for:
                    result = 'ready'
                    break
            elif (not parent_container_only and not plugin_container
                  and monotonic() - started_at >= 1.50):
                # The user may have navigated away while playback was closing.
                result = 'other-window'
                break
            else:
                stable_since = None

            monitor.waitForAbort(0.10)

        try:
            from . import diagnostics
            diagnostics.log_event(
                'navigation',
                'stage=parent-container-wait; result=%s; elapsed_s=%.2f; '
                'update_seen=%s; completion_seen=%s; items=%s' % (
                    result, monotonic() - started_at, bool(update_seen),
                    bool(completion_seen), item_count,
                ),
            )
        except Exception:
            pass
        return result != 'abort'

    @staticmethod
    def _play_count(ref: MediaRef) -> int:
        """Return the locally committed play count used by the episode list."""
        try:
            playback = get_playback_item(ref)
            return int(playback.play_count or 0) if playback is not None else 0
        except Exception:
            return 0

    def _episode_completed_since(self, ffitem: FFItem, initial_play_count: int) -> bool:
        """Detect a completed episode after the service has committed OnStop.

        This is a compatibility fallback only.  Current builds use the explicit
        session result published after the synchronous playback-DB write, so a
        replay of an already-watched episode no longer depends on play-count deltas.
        """
        if not ffitem.ref.is_episode:
            return False
        current_play_count = self._play_count(ffitem.ref)
        return _episode_play_count_advanced(
            ffitem, initial_play_count, current_play_count,
        )

    def _return_to_parent_list_if_completed(
            self, ffitem: FFItem, initial_play_count: int,
            playback_session_id: str = '') -> bool:
        """Skip sources after a committed full play and reveal the parent list."""
        if (playback_session_id
                and not self._playback_session_is_current(playback_session_id)):
            try:
                from . import diagnostics
                diagnostics.log_event(
                    'navigation',
                    'stage=playback-result; result=stale-route; action=ignore; '
                    'session=%s' % playback_session_id,
                    level=xbmc.LOGWARNING,
                )
            except Exception:
                pass
            return True

        if playback_session_id:
            session_result = self._playback_session_result(
                ffitem, playback_session_id,
            )
        else:
            session_result = self._playback_session_result(ffitem)
        if session_result:
            # The explicit result describes the current playback session and is
            # authoritative for both episodes and movies.  Previously the
            # ``is_episode`` guard incorrectly converted a completed movie into
            # an interrupted session, reopening the source dialog at EOF.
            completed = session_result == 'completed'
            decision_source = 'session'
        else:
            # A concrete playback must have an explicit result.  Falling back to
            # historical play_count is exactly what made an already-watched
            # episode choose the wrong window.  Failed-before-AVStart is also
            # published as ``interrupted`` by the service.
            completed = False
            decision_source = 'session-unresolved'
        try:
            from . import diagnostics
            if completed:
                completed_action = 'episode-list' if ffitem.ref.is_episode else 'parent-list'
            else:
                completed_action = 'source-list'
            diagnostics.log_event(
                'navigation',
                'stage=playback-result; result=%s; action=%s; source=%s' % (
                    'completed' if completed else 'interrupted',
                    completed_action,
                    decision_source,
                ),
            )
        except Exception:
            pass
        if completed:
            if not ffitem.ref.is_episode:
                # A movie started from a Home-screen widget returns to Home, not
                # to the Videos media window.  There is no empty plugin folder to
                # cover in that case and, more importantly, no movie directory
                # completion that could close our marker.  Opening the busy
                # dialog unconditionally left widget playback covered until the
                # 45-second safety alarm.  Inspect Kodi's actual underlying
                # window after playback has stopped; only the Videos window can
                # be waiting for a Kadr+ directory refresh.
                try:
                    parent_is_video_window = bool(
                        control.condVisibility('Window.IsActive(videos)')
                    )
                except Exception:
                    parent_is_video_window = False
                if not parent_is_video_window:
                    try:
                        from . import diagnostics
                        diagnostics.log_event(
                            'navigation',
                            'stage=movie-return-loading; '
                            'action=skip-non-video-window',
                        )
                    except Exception:
                        pass
                    return True

                # The log proved that Kodi can expose an empty Videos window for
                # many seconds while the parent movie route rebuilds. Cover only
                # that confirmed gap; KodiDirectory.close() removes this exact
                # marker/dialog at the movies endOfDirectory boundary.
                try:
                    parent_ready = False
                    completion = state.get_info(
                        'directory.completed',
                        module='navigation',
                        mode=StateMode.DB,
                    )
                    completion_value = completion.value if completion is not None else {}
                    if (completion is not None
                            and self._last_playback_stopped_at > 0.0
                            and float(completion.updated_at or 0.0) >= self._last_playback_stopped_at
                            and isinstance(completion_value, dict)
                            and str(completion_value.get('view', '')) == 'movies'
                            and int(completion_value.get('items', 0) or 0) > 0):
                        parent_ready = True

                    if not parent_ready:
                        busy_expires = wall_time() + 45.0
                        state.set(
                            'movie-return-loading',
                            {'ref': str(ffitem.ref), 'expires_at': busy_expires},
                            module='navigation',
                            mode=StateMode.DB,
                        )
                        control.busy_dialog(True)
                        control.execute(
                            'AlarmClock(KadrPlusMovieReturnBusy,'
                            'Dialog.Close(busydialognocancel,true),'
                            '00:00:45,silent,false)'
                        )
                    try:
                        from . import diagnostics
                        diagnostics.log_event(
                            'navigation',
                            'stage=movie-return-loading; action=%s; timeout_s=45'
                            % ('skip-ready' if parent_ready else 'open'),
                        )
                    except Exception:
                        pass
                except Exception:
                    # Loading feedback is cosmetic and must never alter the
                    # completed-movie navigation decision.
                    pass
                return True

            # The service has already committed the local watched/resume state
            # before publishing ``completed``. Do not hold /play open while the
            # parent episode directory rebuilds: returning immediately is what
            # allows Kodi to start that request.  Cover only that unavoidable
            # rebuild gap with Kodi's native non-cancellable busy dialog so the
            # user never sees an empty Videos window.  KodiDirectory.close()
            # closes it exactly after the episode endOfDirectory boundary; the
            # AlarmClock is only a safety net if that directory unexpectedly
            # fails to finish.
            try:
                # On a very fast parent rebuild the episode directory can finish
                # during the short OnStop commit. In that case there is nothing
                # left to cover and opening a busy dialog would only flash it.
                parent_ready = False
                completion = state.get_info(
                    'directory.completed',
                    module='navigation',
                    mode=StateMode.DB,
                )
                completion_value = completion.value if completion is not None else {}
                if (completion is not None
                        and self._last_playback_stopped_at > 0.0
                        and float(completion.updated_at or 0.0) >= self._last_playback_stopped_at
                        and isinstance(completion_value, dict)
                        and str(completion_value.get('view', '')) == 'episodes'
                        and int(completion_value.get('items', 0) or 0) > 0):
                    parent_ready = True

                if not parent_ready:
                    busy_expires = wall_time() + 45.0
                    state.set(
                        'episode-return-loading',
                        {'ref': str(ffitem.ref), 'expires_at': busy_expires},
                        module='navigation',
                        mode=StateMode.DB,
                    )
                    control.busy_dialog(True)
                    control.execute(
                        'AlarmClock(KadrPlusEpisodeReturnBusy,'
                        'Dialog.Close(busydialognocancel,true),'
                        '00:00:45,silent,false)'
                    )
                try:
                    from . import diagnostics
                    diagnostics.log_event(
                        'navigation',
                        'stage=episode-return-loading; action=%s; timeout_s=45'
                        % ('skip-ready' if parent_ready else 'open'),
                    )
                except Exception:
                    pass
            except Exception:
                # Loading feedback is cosmetic.  Never let it alter the already
                # proven completed-playback navigation path.
                pass
            return True
        return False

    def _return_to_source_list(self, *, ffitem: FFItem, query: SourceSearchQuery,
                               default_query: SourceSearchQuery,
                               initial_play_count: int = 0,
                               playback_session_id: str = '') -> None:
        """Reopen the existing results after Stop, matching classic Kadr+ behavior."""
        if not self._wait_until_playback_finishes(
                ffitem=ffitem,
                playback_session_id=playback_session_id):
            return

        # An interrupted current session keeps the already found sources, while
        # a completed session skips the source dialog: episodes go back to
        # their refreshed episode directory, movies reveal their parent movie list.
        if self._return_to_parent_list_if_completed(
                ffitem, initial_play_count, playback_session_id):
            return

        # Only an episode that actually reached Kodi playback can need the
        # covered parent-directory rebuild. Movies already have their previous
        # list underneath the source dialog, and a failed-before-AVStart attempt
        # did not change any watched/resume presentation at all. Waiting 35 s in
        # either case only traps Back on an empty/non-rebuilding parent.
        # ``_last_playback_stopped_at`` is reset before every attempt and is set
        # only after isPlayingVideo() was observed, so it is a reliable local
        # discriminator without adding another cross-thread/session state.
        wait_before_close = None
        if ffitem.ref.is_episode and self._last_playback_stopped_at > 0.0:
            parent_completion_after = wall_time() - 2.0

            def wait_before_close():
                return self._wait_until_parent_directory_ready(
                    xbmc.Monitor(), parent_container_only=True,
                    completion_after=parent_completion_after,
                    completion_view='episodes',
                )

        fresh_scan = False
        while True:
            win = self.SOURCE_DIALOG(
                sources=self,
                item=ffitem,
                # ``None`` starts the progress view; a sequence reopens the
                # already collected results after playback.
                items=None if fresh_scan else self.sources,
                query=query,
                default_query=default_query,
                edit_search=False,
                wait_before_close=wait_before_close,
            )
            selected: Source | None = None
            rescan: RescanSources | None = None
            search_thread: Thread | None = None

            if fresh_scan:
                scan_query = query.copy()

                def search_again() -> None:
                    self.initial_progress_update(win)
                    sources = self.get_sources(**scan_query, progress_dialog=win) or []
                    if not win.iscanceled():
                        win.finish_search(sources)

                search_thread = Thread(
                    target=search_again,
                    name='SourcesReturnRescan',
                )
                search_thread.start()

            try:
                with state.with_var('sources.window', module='player'):
                    selected = win.do_modal()
                    query = win.query
            except RescanSources as exc:
                rescan = exc
            finally:
                # A Back/Cancel during the fresh scan must stop all providers
                # before the returned-list window is destroyed.
                if search_thread is not None and search_thread.is_alive():
                    with suppress(Exception):
                        win.cancel_search()
                    search_thread.join(timeout=5.0)
                if search_thread is not None and search_thread.is_alive():
                    search_thread.stop()
                    search_thread.join(timeout=1.0)
                if search_thread is not None and search_thread.is_alive():
                    fflog.warning('[SOURCES] Returned-list rescan did not stop before cleanup')
                with suppress(Exception):
                    win.destroy()

            if rescan is not None:
                next_query = rescan.query or query
                old_group = query.get('episode_group')
                new_group = next_query.get('episode_group')
                if old_group != new_group:
                    ffinfo.switch_episode_group(ffitem, new_group)
                    default_query['season'] = ffitem.season or 0
                    default_query['episode'] = ffitem.episode or 0
                query = next_query.copy()
                query['ffitem'] = ffitem

                # A real rescan must bypass both the in-memory source list and
                # the normal provider cache.
                from .cache import cache_clear_sources
                self.sources.clear()
                cache_clear_sources()
                fresh_scan = True
                continue

            if not selected:
                return
            initial_play_count = self._play_count(ffitem.ref)
            resume_choice, resume_percent, resume_seconds = self._take_resume_choice_for_source(selected)
            playback_session_id = self._take_or_begin_playback_session(selected)
            with state.with_var('playing.prepare', module='player'):
                player.play(
                    source=selected,
                    start_directly=True,
                    playback_session_id=playback_session_id,
                    resume_choice=resume_choice,
                    resume_percent=resume_percent,
                    resume_seconds=resume_seconds,
                )
            if not self._wait_until_playback_finishes(
                    ffitem=ffitem,
                    playback_session_id=playback_session_id):
                return
            if self._return_to_parent_list_if_completed(
                    ffitem, initial_play_count, playback_session_id):
                return
            fresh_scan = False

    def get_sources(self, **kwargs: Unpack[GetSourcesKwargs]) -> List[Source]:
        with state.with_var('sources.scan', module='player'):
            return self._get_sources(**kwargs)

    def src_format(self, fmt: 'list[list[LiteralString]]', *, qrange: range | None) -> Iterator[str]:
        if qrange is None:
            qmax = settings.getInt("hosts.quality.max")
            qmin = settings.getInt("hosts.quality.min")
            qrange = range(qmin, qmax + 1)
        for f in fmt:
            if len(f) > 2:  # sources
                inc = f[::-1]
                for i in reversed(qrange):  # no reversed(), because pdiag_*_format has already reverted order
                    yield inc[i]
            else:
                yield from f

    def initial_progress_update(self, progress_dialog: ProgressDialogProtocol | None) -> None:
        """Initial progress dialog update."""
        if progress_dialog is None:
            return
        line = L(30536, "Preparing sources...")
        progress_dialog.update(0, line)

    def _run_provider_job(self, srcmod, func, *args, **kwargs) -> None:
        """Run one provider and collect a concise diagnostic status.

        Provider code in this project often catches its own network exceptions.  The
        wrapper therefore records both the provider's explicit last error and the
        number of sources that actually reached the shared list.
        """
        if not self._diagnostics_enabled:
            func(*args, **kwargs)
            return
        name = srcmod.name
        provider = srcmod.provider
        started = monotonic()
        before = sum(1 for src in self.sources if src.provider == name)
        try:
            setattr(provider, '_kadr_last_error', '')
            setattr(provider, '_kadr_deadline_snapshot_used', False)
            setattr(provider, '_kadr_deadline_budget_exhausted', False)
            self._provider_stats[name] = {
                'status': 'running', 'started': started, 'elapsed': 0.0,
                'count': 0, 'error': '',
            }
            func(*args, **kwargs)
        except ThreadCanceled:
            self._provider_stats[name]['status'] = 'cancelled'
            raise
        except BaseException as exc:
            self._provider_stats[name]['status'] = 'error'
            self._provider_stats[name]['error'] = repr(exc)[:240]
            raise
        finally:
            provider_sources = [src for src in self.sources if src.provider == name]
            after = len(provider_sources)
            stat = self._provider_stats.setdefault(name, {})
            stat['elapsed'] = max(0.0, monotonic() - started)
            stat['count'] = max(0, after - before)
            if name == 'telegram':
                # Telegram exposes one aggregate source in the common source
                # list, but that aggregate owns the actual selectable files.
                # Record the inner count so a diagnostic log can distinguish
                # "one Telegram provider row" from e.g. 19 real Telegram hits.
                nested_count = sum(
                    max(0, int(src.get('telegram_count') or 0))
                    for src in provider_sources[before:]
                )
                if nested_count:
                    stat['count'] = nested_count
            provider_error = str(getattr(provider, '_kadr_last_error', '') or '')
            if name == 'telegram' and getattr(provider, '_kadr_deadline_snapshot_used', False):
                stat['status'] = 'ok'
                stat['error'] = ''
            elif name == 'telegram' and getattr(provider, '_kadr_deadline_budget_exhausted', False):
                stat['status'] = 'empty'
                stat['error'] = ''
            elif provider_error:
                stat['error'] = provider_error[:240]
                stat['status'] = 'error'
            elif stat.get('status') == 'running':
                stat['status'] = 'ok' if stat.get('count') else 'empty'

    @staticmethod
    def _canonical_source_url(url: str) -> str:
        """Normalize only safe, presentation-independent URL details for dedup."""
        value = str(url or '').strip()
        if value.startswith('plugin://'):
            return value
        # Kodi headers after | do not change the underlying media identity.
        value = value.split('|', 1)[0].strip()
        value = re.sub(r'(?<!:)//+', '/', value)
        return value.rstrip('/')

    def _source_dedup_key(self, src: Source) -> tuple[Any, ...]:
        """Identity preserving language/quality/release differences."""
        # There is exactly one interactive Telegram aggregate per provider scan.
        # Its URL contains a random selection-cache id, so URL-based identity
        # would incorrectly treat a deadline snapshot and a racing final worker
        # aggregate as two different rows.
        if src.get('telegram_aggregate'):
            return ('telegram-aggregate', src.provider.lower())
        lang = ' '.join(sorted(set(re.findall(r'[a-z]{2,8}', str(src.get('language') or '').lower()))))
        filename = re.sub(r'[^a-z0-9]+', '', str(src.get('filename') or '').lower())
        size = source_utils.convert_size_to_bytes(str(src.get('size') or '')) or 0
        canonical_url = self._canonical_source_url(src.url)
        base = (
            src.provider.lower(), src.hosting.lower(),
            lang, str(src.get('quality') or '').upper(),
        )
        # The same canonical stream returned twice by one provider is a true
        # duplicate even when one copy has richer filename/size metadata.
        if canonical_url:
            return ('url', *base, canonical_url)
        # Defensive fallback for malformed providers without a URL.
        return ('meta', *base, filename, int(size))

    def _deduplicate_sources(self) -> None:
        """Remove real duplicates while keeping language/quality/release variants."""
        before = len(self.sources)
        unique: dict[tuple[Any, ...], Source] = {}
        for src in self.sources:
            key = self._source_dedup_key(src)
            current = unique.get(key)
            if current is None:
                unique[key] = src
                continue
            # Keep the first deterministic item, but enrich missing descriptive fields.
            for field in ('info', 'info2', 'filename', 'size', 'color_identify'):
                if not current.get(field) and src.get(field):
                    current.meta[field] = src.get(field)  # type: ignore[literal-required]
            for field in ('direct', 'premium', 'on_account'):
                if src.get(field):
                    current.meta[field] = True  # type: ignore[literal-required]
        self.sources = list(unique.values())
        removed = before - len(self.sources)
        if removed:
            fflog(f'[SOURCES] dedup removed={removed}, kept={len(self.sources)}')

    def _append_provider_sources(self, provider: ProviderProtocol, sources: Iterable[Source]) -> bool:
        """Append results only while the provider still belongs to the active search."""
        incoming = list(sources)
        with self.lock:
            if getattr(provider, 'canceled', False) and not getattr(provider, '_kadr_partial_ready', False):
                return False
            # If the scheduler has already consumed Telegram's safe deadline
            # snapshot, the provider thread is only unwinding. Never allow its
            # later aggregate to become a second visible Telegram row.
            if getattr(provider, '_kadr_timeout_snapshot_consumed', False):
                incoming = [src for src in incoming if not src.get('telegram_aggregate')]
                if not incoming:
                    return False
            self.sources.extend(incoming)
            return True

    @staticmethod
    def _source_cache_is_fresh(value: Any, *, max_age_seconds: int = 3600) -> bool:
        """Check a ``rel_src`` timestamp using real elapsed seconds."""
        try:
            cached_at = datetime.datetime.strptime(str(value or '')[:16], '%Y-%m-%d %H:%M')
            age = (datetime.datetime.now() - cached_at).total_seconds()
            return -300.0 <= age <= float(max_age_seconds)
        except (TypeError, ValueError):
            return False

    def _get_sources(self, *,
                     title: str,
                     localtitle: str,
                     year: int,
                     imdb: str,
                     tmdb: str,
                     season: int | None,
                     episode: int | None,
                     tvshowtitle: str,
                     premiered: str,
                     originalname: str = "",
                     episode_group: str | None = None,              # used in query, not used directly
                     episode_offset: dict[int, int] | None = None,  # used in query, not used directly
                     quality: str = "HD",
                     timeout: int | None = None,
                     ffitem: FFItem,
                     progress_dialog: ProgressDialogProtocol | None = None,
                     ) -> List[Source]:
        # fflog("get_sources")
        fflog(f'\033[91mget_sources\033[0m({title=}, {localtitle=}, {year=}, {imdb=}, {tmdb=}, '
              f'{season=}, {episode=}, {tvshowtitle=}, {premiered=}, {originalname=} ---------')
        # --- DEBUG ---
        # if 0:
        #     self.sources = [
        #         Source(url='/a/b/c', provider='test', hosting='host', ffitem=ffitem, meta={'size': '1 KB', 'quality': '720p'}),
        #     ]
        #     self.sourcesFilter(ffitem=ffitem)
        #     return self.sources
        # return []

        if timeout is None:
            timeout = settings.getInt("scrapers.timeout.1")
        timeout = max(5, min(int(timeout or 30), 200))
        self._diagnostics_enabled = settings.getBool('diagnostics.enabled')
        self._provider_stats = {}
        self._search_cancelled = False

        # Do not overlap a new scan with provider instances that are still
        # winding down after a previous user Cancel. Most exit immediately, but
        # a network call may need another moment to return. We wait briefly and
        # temporarily skip only providers that are genuinely still alive.
        blocked_provider_names: set[str] = set()
        if self._lingering_provider_threads:
            reap_deadline = monotonic() + 2.0
            still_lingering: list[tuple[Thread, SourceModule]] = []
            for old_thread, old_srcmod in list(self._lingering_provider_threads):
                if old_thread.is_alive() and monotonic() < reap_deadline:
                    old_thread.join(timeout=max(0.0, reap_deadline - monotonic()))
                if old_thread.is_alive():
                    still_lingering.append((old_thread, old_srcmod))
                    blocked_provider_names.add(old_srcmod.name)
                else:
                    old_srcmod.provider.canceled = False
            self._lingering_provider_threads = still_lingering
            if blocked_provider_names:
                fflog.warning('[SOURCES] Providers still stopping after previous Cancel; skipped for this scan: %s' %
                              ', '.join(sorted(blocked_provider_names)))

        # progress_dialog is now always created in _play() before calling get_sources()
        # If None, progress updates will be skipped (used for testing or external calls)

        self.prepareSources()

        # -------------------------------------------------------------------------------------------------------- XXX XXX XXX
        def log_source_mods(title='source_mods'):  # TODO: Rremove it  (DEBUG)
            # from pprint import pformat
            nonlocal source_mods
            source_mods = list(source_mods)  # support for generators
            fflog.debug(f'{title}: {", ".join(smod.name for smod in source_mods)}', stack_depth=2)
            # fflog.debug(f'{title}\n{pformat(source_mods, indent=2, width=240, compact=False)}', stack_depth=2)

        source_mods: Iterable[SourceModule] = self.source_mods
        srcmod: SourceModule
        genres: Set[str]
        log_source_mods('start')
        source_mods = [srcmod for srcmod in source_mods if srcmod.name not in blocked_provider_names]
        for srcmod in source_mods:
            srcmod.provider.canceled = False

        # filter-out provider modules with provider-level pattern (provider, platform, kodi version).
        # no source-level conditions means the provider could be skipped entirely here
        old_srcmods = source_mods
        source_mods = [srcmod for srcmod in source_mods if srcmod.is_enabled_by_rules()]
        if len(source_mods) < len(old_srcmods):
            fflog(f'Providers disabled by rules: {", ".join(srcmod.name for srcmod in old_srcmods if srcmod not in source_mods)}')

        # filtrowanie po dozowlonych providerach, tzn. takich, które włączył użytkownik w ustawieniach
        if const.dev.sources.force_all_sources:
            fflog('[DEV] force_all_sources: skipping provider user-settings filter')
        else:
            try:
                source_mods = filter(lambda srcmod: settings.getBool(f"provider.{srcmod.name}"), source_mods)
            except (TypeError, ValueError):
                fflog_exc()
        log_source_mods('enabled')

        content = "movie" if not season else "episode"
        if content == "movie":
            # filtrowanie po providerach, które posiadają metodę `movie()`
            source_mods = (srcmod for srcmod in source_mods if hasattr(srcmod.provider, "movie"))
            # TODO: TRAKT  genres = set(trakt.getGenre("movie", "imdb", imdb))
        else:
            # filtrowanie po providerach, które posiadają metodę `tvshow()`
            source_mods = (srcmod for srcmod in source_mods if hasattr(srcmod.provider, "tvshow"))
            # TODO: TRAKT  genres = set(trakt.getGenre("show", "tmdb", tmdb))
        log_source_mods('method')

        # filtrowanie po obsługiwanych gatunkach – ŻADEN provider tego nie dostarcza
        source_mods = filter(lambda srcmod: (not getattr(srcmod.provider, "genre_filter", ())
                                             or set(srcmod.provider.genre_filter) & genres),
                             source_mods)
        log_source_mods('genres')

        # filtrowanie po języku, czy provider dostarcza treści w jakimkowiek akceptowalnym dla nas języku
        langs: Set[str] = set(self.getLanguage())
        if not const.dev.sources.force_all_sources:
            source_mods = filter(lambda srcmod: set(srcmod.provider.language) & langs, source_mods)
        log_source_mods('langs')

        # sortowanie po priorytecie
        if False:
            source_mods = list(source_mods)  # generator → list, for random.shuffle()
            random.shuffle(source_mods)
        # od tej pory `source_mods` jest listą nie generatorem, można wielokrotnie przeglądać
        source_mods = sorted(source_mods, key=lambda srcmod: srcmod.provider.priority)
        log_source_mods('sorted')

        # pozyskiwanie źródeł (linków) od providerów (w wątkach)
        threads: dict[Thread, SourceModule] = {}
        fake = str

        if content == "movie":
            # title = self.getTitle(title)  # niszczy polskie znaki diakrytyczne
            # localtitle = self.getTitle(localtitle)  # niszczy polskie znaki diakrytyczne
            # originalname = self.getTitle(originalname)  # niszczy polskie znaki diakrytyczne
            # aliases = self.getTMDBAliasTitles(tmdb, localtitle, content)
            aliases = self.getAliasTitles(imdb, localtitle, content, ffitem=ffitem)
            if originalname:
                aliases = [
                    {"originalname": originalname, "country": "original"},
                    *aliases,
                ]
            if self.DEBUG_SINGLE_PROVIDER:
                if debug_srcmod := next((s for s in source_mods if s.name == self.DEBUG_SINGLE_PROVIDER), None):
                    fflog(f'DEBUG SINGLE PROVIDER: {debug_srcmod.name}')
                    self.getMovieSource(title, localtitle, aliases, fake(year), imdb,
                                        debug_srcmod.name, debug_srcmod.provider, ffitem=ffitem)
                else:
                    fflog.warning(f'DEBUG SINGLE PROVIDER: {self.DEBUG_SINGLE_PROVIDER} not found')
            else:
                for srcmod in source_mods:
                    th = Thread(
                        target=self._run_provider_job,
                        args=(srcmod, self.getMovieSource, title, localtitle, aliases, fake(year), imdb, srcmod.name, srcmod.provider),
                        kwargs={'ffitem': ffitem},
                        name=f'{srcmod.name} movie sources',
                    )
                    if srcmod.name == 'telegram':
                        # Telethon owns asyncio receive tasks. It must observe
                        # provider.canceled and disconnect in its finally block;
                        # injecting ThreadCanceled from logging leaks those tasks.
                        th.cooperative_cancel_only = True
                    threads[th] = srcmod
            localtvshowtitle = ''
        else:
            # tvshowtitle = self.getTitle(tvshowtitle)  # niszczy polskie znaki diakrytyczne
            localtvshowtitle = self.getLocalTitle(tvshowtitle, imdb, tmdb, content)
            # aliases = self.getTMDBAliasTitles(tmdb, localtvshowtitle, content)
            # aliases = self.getAliasTitles(imdb, localtvshowtitle, content, ffitem=ffitem)
            aliases = self.getAliasTitles(imdb, localtvshowtitle, content, ffitem=ffitem.show_item or ffitem)
            if originalname:
                aliases = [
                    {"originalname": originalname, "country": "original"},
                    *aliases,
                ]

            # Disabled on 11/11/17 due to hang. Should be checked in the future and possible enabled again.
            # season, episode = thexem.get_scene_episode_number(tvdb, season, episode)

            if self.DEBUG_SINGLE_PROVIDER:
                if debug_srcmod := next((s for s in source_mods if s.name == self.DEBUG_SINGLE_PROVIDER), None):
                    fflog(f'DEBUG SINGLE PROVIDER: {debug_srcmod.name}')
                    self.getEpisodeSource(title, localtitle, fake(year), imdb, fake(tmdb), fake(season), fake(episode),
                                          tvshowtitle or originalname, localtvshowtitle, aliases,
                                          premiered, debug_srcmod.name, debug_srcmod.provider, ffitem=ffitem)
                else:
                    fflog.warning(f'DEBUG SINGLE PROVIDER: {self.DEBUG_SINGLE_PROVIDER} not found')
            else:
                for srcmod in source_mods:
                    th = Thread(
                        target=self._run_provider_job,
                        args=(
                            srcmod,
                            self.getEpisodeSource,
                            title,
                            localtitle,
                            fake(year),
                            imdb,
                            fake(tmdb),
                            fake(season),
                            fake(episode),
                            tvshowtitle or originalname,
                            localtvshowtitle,
                            aliases,
                            premiered,
                            srcmod.name,
                            srcmod.provider,
                        ),
                        kwargs={
                            'ffitem': ffitem,
                        },
                        name=f'{srcmod.name} episode sources',
                    )
                    if srcmod.name == 'telegram':
                        th.cooperative_cancel_only = True
                    threads[th] = srcmod

        # Start threads z timeout tracking
        start_time: float = monotonic()
        end_time: float = start_time + timeout
        for _srcmod in threads.values():
            if _srcmod.name == 'telegram':
                try:
                    _srcmod.provider._kadr_parent_timeout = float(timeout)
                    _srcmod.provider._kadr_parent_deadline_monotonic = float(end_time)
                except Exception:
                    pass
        fflog(f'[SOURCES] Starting {len(threads)} providers (max {timeout:.1f}s): {", ".join(sorted(srcmod.name for srcmod in threads.values()))}')
        provider_clock_started = False
        for th in threads:
            th.start()
            if not provider_clock_started and progress_dialog is not None:
                # Activate provider activity only after the first worker is
                # genuinely running, never during title/alias preparation.
                with suppress(AttributeError):
                    progress_dialog.start_provider_search()
                provider_clock_started = True

        string_total = L(32601, 'Total')
        string_premium = L(32606, 'Prem')
        string_normal = L(32607, 'Normal')
        string_languages = L(32014, 'Languages')

        qmax = settings.getInt("hosts.quality.max")
        qmin = settings.getInt("hosts.quality.min")
        qrange = range(qmin, qmax + 1)

        line1 = line2 = line3 = ""
        TOTAL = len(self.QUALITIES)
        source_qq = [0] * (TOTAL + 1)    # +1 for [TOTAL] - normal sources
        prem_source_qq = [0] * (TOTAL + 1)  # +1 for [TOTAL] - premium sources (premium=True OR debrid-compatible)

        debrid_list = []
        debrid_status = False

        total_format = self.TOTAL_FORMAT

        # Event-driven monitoring zamiast busy wait
        update_interval = 1.0  # Limit text/count redraws on slower Android devices.
        next_update_time = monotonic() + update_interval
        total_threads = len(threads)

        # Helper functions for progress dialog formatting
        def format_quality_count(count, color=None, width=2):
            """Format single quality count with color and fixed width"""
            if color is None:
                color = "lime" if count > 0 else "red"
            return f"[COLOR {color}][B]{count:>{width}}[/B][/COLOR]"

        def build_progress_line(*lines):
            """Combine lines with optional remaining line"""
            return '\n'.join(str(line) for line in lines if line)

        def build_quality_line(labels_list, quality_names, qrange, prefix=''):
            """Build quality line with proper alignment"""
            parts = [f"{quality_names[i]}: {labels_list[i]}" for i in reversed(qrange)]
            line = " | ".join(parts)
            return f"{prefix}{line}" if prefix else line

        def build_inline_quality_parts(source_qq, prem_source_qq, quality_names, qrange, has_premium):
            """Build quality parts for inline mode with premium in parentheses"""
            parts = []
            for i in reversed(qrange):
                normal_count = source_qq[i]
                premium_count = prem_source_qq[i]
                total_count = normal_count + premium_count

                if has_premium and premium_count > 0:
                    # Show as: "4K: 12 (1)" where 12 is total, (1) is premium in gold
                    part = f"{quality_names[i]}: {format_quality_count(total_count)} [COLOR gold]({premium_count})[/COLOR]"
                else:
                    # Show as: "4K: 12" (no premium sources, or total is 0)
                    part = f"{quality_names[i]}: {format_quality_count(total_count)}"

                parts.append(part)
            return parts

        # Main loop, wait for provider (source-module) threads to complete or timeout
        while (threads := {th: srcmod for th, srcmod in threads.items() if th.is_alive()}) and (now := monotonic()) < end_time:
            if xbmc.Monitor().abortRequested():
                return sys.exit()

            with suppress(AttributeError):
                if progress_dialog.iscanceled():
                    self._search_cancelled = True
                    for _th, _srcmod in threads.items():
                        _srcmod.provider.canceled = True
                        _th.stop()
                    fflog('[SOURCES] Search cancelled by user')
                    break

            try:
                # Update progress only periodically to reduce CPU usage
                if next_update_time <= now:
                    next_update_time = now + update_interval

                    for q in qrange:
                        qq = self.QUALITIES[Quality(q)]
                        # Normal sources: not premium and not debridonly
                        source_qq[q] = sum(1 for e in self.sources if e["quality"] in qq and not e.get("premium") and not e.get("debridonly"))
                    source_qq[TOTAL] = sum(source_qq[0:TOTAL])

                    # Premium sources: premium=True OR debrid-compatible
                    for q in qrange:
                        qq = self.QUALITIES[Quality(q)]
                        prem_source_qq[q] = sum(1 for e in self.sources
                                                if e["quality"] in qq and
                                                (e.get("premium") or (debrid_status and any(d.valid_url("", e["hosting"]) for d in debrid_list))))
                    prem_source_qq[TOTAL] = sum(prem_source_qq[0:TOTAL])

                    try:
                        info = [srcmod.name.upper() for srcmod in threads.values()]

                        # Common calculations
                        total_all = source_qq[TOTAL] + prem_source_qq[TOTAL]
                        quality_names = self.QUALITY_NAMES

                        # Count sources by language (using source.sound.lang integer setting)
                        allowed_source_lang = settings.getInt("source.sound.lang")

                        # Map setting value to allowed languages (same as in prepareSources)
                        langs_map: Dict[int, Set[str]] = {
                            0: set(),  # all languages
                            1: {'pl'},
                            2: {'pl', 'multi'},
                            3: {'en', ''},
                            4: {'en', 'multi', ''},
                            5: {'de'},
                            6: {'de', 'multi'},
                            7: {'pl', 'de', 'multi'},
                            8: {'pl', 'de', 'en', 'multi', ''},
                        }
                        allowed_langs = langs_map.get(allowed_source_lang, set())

                        lang_counts = {}
                        for e in self.sources:
                            lang = e.get("language", "").lower()

                            # Only count if language is allowed (or if all languages allowed)
                            if allowed_source_lang == 0 or any(l in lang.split() for l in allowed_langs):
                                lang_upper = lang.upper() if lang else 'EN'  # empty is EN
                                lang_counts[lang_upper] = lang_counts.get(lang_upper, 0) + 1

                        # Format language display: "EN: 10 | PL: 20 | MULTI: 100"
                        if lang_counts:
                            lang_parts = []
                            for lang, count in sorted(lang_counts.items(), key=lambda x: x[1], reverse=True):
                                color = "lime" if count > 0 else "red"
                                lang_parts.append(f"{lang}: [COLOR {color}][B]{count}[/B][/COLOR]")
                            language_display = " | ".join(lang_parts)
                        else:
                            language_display = ""

                        has_premium = prem_source_qq[TOTAL] > 0

                        # Progress based on completed threads, not time
                        percent = min(99, 100 * (total_threads - len(threads)) // total_threads)

                        # Display mode from const
                        display_mode = SourceSearchProgressStyle(const.sources_dialog.searching.progress_style)

                        if display_mode == SourceSearchProgressStyle.FULL:
                            # Full mode: premium/normal separation with headers
                            prem_source_labels = [format_quality_count(sq, color="gold" if sq > 0 else "red") for sq in prem_source_qq]
                            source_labels = [format_quality_count(sq) for sq in source_qq]

                            if has_premium:
                                # With premium: show headers and totals
                                # Line 0: "Premium" header with total count
                                line0 = f"[B]{string_premium}:[/B] {format_quality_count(prem_source_qq[TOTAL], color='gold')}"
                                # Line 1: Premium qualities
                                line1 = build_quality_line(prem_source_labels, quality_names, qrange)
                                # Line 2: "Normal/Free" header with total count
                                line2 = f"[B]{string_normal}:[/B] {format_quality_count(source_qq[TOTAL])}"
                                # Line 3: Normal qualities
                                line3 = build_quality_line(source_labels, quality_names, qrange)
                                # Line 4: Total (all sources)
                                line4 = f"[B]{string_total}:[/B] {format_quality_count(total_all)}"
                                # Line 5: Languages
                                line5 = f"[B]{string_languages}:[/B] {language_display}" if language_display else None
                                progress_line = build_progress_line(line0, line1, line2, line3, line4, line5)
                            else:
                                # Without premium: no headers, just totals
                                # Line 0: Normal qualities
                                line0 = build_quality_line(source_labels, quality_names, qrange)
                                # Line 1: Total
                                line1 = f"[B]{string_total}:[/B] {format_quality_count(total_all)}"
                                # Line 2: Languages
                                line2 = f"[B]{string_languages}:[/B] {language_display}" if language_display else None
                                progress_line = build_progress_line(line0, line1, line2)

                        elif display_mode == SourceSearchProgressStyle.EXTENDED:
                            # Extended mode: premium in gold parentheses on same line
                            # Line 1: Combined qualities with premium in parentheses
                            combined_parts = build_inline_quality_parts(source_qq, prem_source_qq, quality_names, qrange, has_premium)
                            line1 = ' | '.join(combined_parts)
                            # Line 2: Total with premium shown separately
                            # Format: "Total: 38 (Premium: 4)" or "Total: 38" if no premium
                            if has_premium:
                                line2 = f"{string_total}: {format_quality_count(total_all)} ([COLOR gold]{string_premium}: {prem_source_qq[TOTAL]}[/COLOR])"
                            else:
                                line2 = f"{string_total}: {format_quality_count(total_all)}"
                            progress_line = build_progress_line(line1, line2)

                        else:  # display_mode == SourceSearchProgressStyle.SIMPLE
                            # Normal mode: all sources in one line, no distinction
                            all_sources_qq = [source_qq[i] + prem_source_qq[i] for i in range(len(source_qq))]
                            all_source_labels = [format_quality_count(sq) for sq in all_sources_qq]
                            # Line 1: All sources (normal + premium combined)
                            line1 = build_quality_line(all_source_labels, quality_names, qrange)
                            # Line 2: Total
                            line2 = f"{string_total}: {format_quality_count(total_all)}"
                            progress_line = build_progress_line(line1, line2)

                        if progress_dialog is not None:
                            progress_dialog.update(max(1, percent), progress_line, providers=info)
                    except Exception:
                        fflog_exc()

                # Sleep less when we have sources, more when waiting
                # sleep_time = 0.2 if len(self.sources) > 0 else 0.5
                # xsleep(sleep_time)
                xsleep(0.25)

            except Exception:
                fflog_exc()
                break

        # Final progress update
        try:
            final_message = L(30534, 'Finalizing sources...')
            if progress_dialog is not None:
                progress_dialog.update(100, final_message)
        except Exception:
            pass

        # Cleanup: stop remaining threads. Cancel is special: results that
        # were already collected may stay visible, but only after the provider
        # that produced them has really stopped. This prevents a resolver click
        # (notably KissKH) from racing the provider's still-running search/session.
        if threads:
            reason = 'cancelled' if self._search_cancelled else 'timeout'
            deadline_snapshot_names: set[str] = set()
            deadline_budget_names: set[str] = set()

            # Telegram is deliberately cooperative: we never kill an in-flight
            # MTProto request just to hit the common source deadline.  Therefore
            # a request can still be unwinding when the *authoritative* global
            # timer expires.  Before marking it as a timeout, atomically consume
            # the last provider snapshot made only from already validated hits.
            # This does no Telegram network I/O and turns "found results, but one
            # later RPC stalled" into a normal completed Telegram row.  When the
            # snapshot is empty, global budget exhaustion is a normal empty stop
            # for Telegram rather than a red provider timeout.
            if not self._search_cancelled:
                for th, srcmod in list(threads.items()):
                    if srcmod.name != 'telegram':
                        continue
                    provider = srcmod.provider
                    provider.canceled = True
                    existing = []
                    with self.lock:
                        existing = [src for src in self.sources if src.provider == 'telegram']
                    aggregate = None
                    if not existing:
                        consume = getattr(provider, '_kadr_consume_timeout_snapshot', None)
                        if callable(consume):
                            try:
                                aggregate = consume()
                            except Exception:
                                fflog_exc()
                    appended = False
                    if existing:
                        appended = True
                    elif aggregate:
                        try:
                            converted = Source.from_provider_dict(
                                provider='telegram', ffitem=ffitem, item=aggregate
                            )
                            # Re-check under the common lock in case the worker
                            # completed between snapshot consumption and append.
                            with self.lock:
                                if not any(src.provider == 'telegram' for src in self.sources):
                                    self.sources.append(converted)
                                    appended = True
                                else:
                                    appended = True
                        except Exception:
                            fflog_exc()
                    if appended:
                        setattr(provider, '_kadr_deadline_snapshot_used', True)
                        setattr(provider, '_kadr_deadline_budget_exhausted', False)
                        deadline_snapshot_names.add(srcmod.name)
                        count = 0
                        try:
                            if aggregate:
                                count = max(0, int(aggregate.get('telegram_count') or 0))
                            if not count:
                                with self.lock:
                                    count = sum(
                                        max(0, int(src.get('telegram_count') or 0))
                                        for src in self.sources if src.provider == 'telegram'
                                    )
                        except Exception:
                            count = 0
                        if self._diagnostics_enabled:
                            stat = self._provider_stats.setdefault(srcmod.name, {})
                            stat['status'] = 'ok'
                            stat['count'] = count
                            stat['error'] = ''
                            stat['elapsed'] = max(float(stat.get('elapsed') or 0), monotonic() - start_time)
                        fflog('[SOURCES] Telegram reached global budget; returned safe snapshot (%s result(s))' % count)
                    else:
                        setattr(provider, '_kadr_deadline_snapshot_used', False)
                        setattr(provider, '_kadr_deadline_budget_exhausted', True)
                        deadline_budget_names.add(srcmod.name)
                        if self._diagnostics_enabled:
                            stat = self._provider_stats.setdefault(srcmod.name, {})
                            stat['status'] = 'empty'
                            stat['count'] = 0
                            stat['error'] = ''
                            stat['elapsed'] = max(float(stat.get('elapsed') or 0), monotonic() - start_time)
                        fflog('[SOURCES] Telegram reached global budget with no safe snapshot; finishing as empty')

            stop_reason = reason
            remaining_names = {srcmod.name for srcmod in threads.values()}
            if (not self._search_cancelled and remaining_names and
                    remaining_names.issubset(deadline_snapshot_names | deadline_budget_names)):
                stop_reason = 'global-budget'
            fflog(f'[SOURCES] Stopping {len(threads)} remaining providers ({stop_reason}): {", ".join(sorted(remaining_names))}')
            for th, srcmod in threads.items():
                srcmod.provider.canceled = True
                if self._diagnostics_enabled:
                    stat = self._provider_stats.setdefault(srcmod.name, {})
                    if srcmod.name in deadline_snapshot_names:
                        stat['status'] = 'ok'
                    elif srcmod.name in deadline_budget_names:
                        stat['status'] = 'empty'
                    else:
                        stat['status'] = reason
                    stat['elapsed'] = max(float(stat.get('elapsed') or 0), monotonic() - start_time)
                if th.is_alive():
                    th.stop()

            if self._search_cancelled:
                # One shared grace period, not N seconds per provider. Five
                # seconds is long enough for normal HTTP timeouts/Telethon to
                # unwind without making Cancel feel like another full search.
                join_deadline = monotonic() + 5.0
                # Telegram first because its worker owns an asyncio/MTProto
                # session and must disconnect cleanly before it can be resolved
                # or searched again.
                ordered = sorted(threads.items(), key=lambda it: 0 if it[1].name == 'telegram' else 1)
                for th, srcmod in ordered:
                    if th.is_alive() and monotonic() < join_deadline:
                        th.join(timeout=max(0.0, join_deadline - monotonic()))
            else:
                # No hidden Telegram grace after the user-selected global
                # timeout.  Snapshot/empty budget handling above already made
                # the Telegram outcome final for this scan.  Other providers keep
                # the historical shared one-second cleanup window.
                join_deadline = monotonic() + 1.0
                for th, srcmod in threads.items():
                    if srcmod.name != 'telegram' and th.is_alive():
                        th.join(timeout=max(0.0, join_deadline - monotonic()))
                        if monotonic() >= join_deadline:
                            break

                # An in-flight MTProto request cannot be safely murdered.  Keep
                # its provider instance marked canceled and remember the worker
                # so a following search cannot overlap the old Telegram session.
                lingering_tg = [
                    (th, srcmod) for th, srcmod in threads.items()
                    if srcmod.name == 'telegram' and th.is_alive()
                ]
                if lingering_tg:
                    known = {(id(th), id(sm.provider)) for th, sm in self._lingering_provider_threads}
                    for pair in lingering_tg:
                        key = (id(pair[0]), id(pair[1].provider))
                        if key not in known:
                            self._lingering_provider_threads.append(pair)
                            known.add(key)
                    fflog('[SOURCES] Telegram worker still unwinding after global budget; tracked to prevent overlap')
                for th, srcmod in threads.items():
                    if srcmod.name == 'telegram' and not th.is_alive():
                        srcmod.provider.canceled = False

            if self._search_cancelled:
                unsafe = [(th, srcmod) for th, srcmod in threads.items() if th.is_alive()]
                safe_names = {srcmod.name for th, srcmod in threads.items() if not th.is_alive()}
                for _th, srcmod in threads.items():
                    if not _th.is_alive():
                        # Resolution after Cancel must start from a clean provider
                        # state. The thread stop_event remains local to the old
                        # worker and cannot affect a later resolve().
                        srcmod.provider.canceled = False
                if unsafe:
                    unsafe_names = {srcmod.name for th, srcmod in unsafe}
                    with self.lock:
                        before_cancel_filter = len(self.sources)
                        self.sources = [src for src in self.sources if src.provider not in unsafe_names]
                    removed_cancel = before_cancel_filter - len(self.sources)
                    fflog.warning('[SOURCES] Cancel: %s provider(s) still stopping; removed %s unsafe partial source(s): %s' %
                                  (len(unsafe_names), removed_cancel, ', '.join(sorted(unsafe_names))))
                    # Do not reset these provider.canceled flags yet. A following
                    # scan will reap them first and skip them if they are still
                    # alive, so old and new provider sessions never overlap.
                    known = {(id(th), id(sm.provider)) for th, sm in self._lingering_provider_threads}
                    for pair in unsafe:
                        key = (id(pair[0]), id(pair[1].provider))
                        if key not in known:
                            self._lingering_provider_threads.append(pair)
                            known.add(key)
                fflog('[SOURCES] Cancel cleanup complete; safe providers reset=%s' % ', '.join(sorted(safe_names)))

        elapsed = max(0.0, monotonic() - start_time)
        raw_sources = len(self.sources)
        fflog(f'[SOURCES] Completed: found {raw_sources} sources ({total_threads - len(threads)} / {total_threads} providers) in {elapsed:.1f}s')
        self.sourcesFilter(ffitem=ffitem)
        if self._diagnostics_enabled:
            try:
                from .diagnostics import record_source_search
                record_source_search(
                    self._provider_stats,
                    elapsed=elapsed,
                    raw_sources=raw_sources,
                    visible_sources=len(self.sources),
                    total_providers=total_threads,
                    cancelled=self._search_cancelled,
                )
            except Exception:
                fflog_exc()
        return self.sources

    def prepareSources(self):
        fflog("prepareSources")
        if settings.getBool("enableSourceCache"):
            if not control.existsPath(control.dataPath):
                control.make_dir(control.dataPath)
            self.sourceFile = control.sourcescacheFile
        else:
            self.sourceFile = ':memory:'

    def _init_sources_db(self, dbcur: SqlCursor) -> None:
        try:
            dbcur.execute(
                "CREATE TABLE IF NOT EXISTS rel_url ("
                "source TEXT, "
                "imdb_id TEXT, "
                "season TEXT, "
                "episode TEXT, "
                "rel_url TEXT, "
                "UNIQUE(source, imdb_id, season, episode)"
                ");"
            )
            dbcur.execute(
                "CREATE TABLE IF NOT EXISTS rel_src ("
                "source TEXT, "
                "imdb_id TEXT, "
                "season TEXT, "
                "episode TEXT, "
                "hosts TEXT, "
                "added TEXT, "
                "UNIQUE(source, imdb_id, season, episode)"
                ");"
            )
        except OperationalError:
            fflog_exc()

    @contextmanager
    def _with_calling_provider(self, call: ProviderProtocol):
        """Context manager to log exceptions in provider calls."""
        try:
            yield
        except Exception as exc:
            try:
                setattr(call, '_kadr_last_error', repr(exc))
            except Exception:
                pass
            from .log_utils import CallerInfo, traceback_string
            x = CallerInfo.info(n=2)
            z = traceback_string(exc.__traceback__, stack_limit=1, ffonly=True)
            fflog(f'Exception in provider {call.__class__.__module__}.{call.__class__.__name__}: {exc!r}', stack_depth=3)
            fflog(f' --- {x}, {x.module_name} --- \n{z}')

    def getMovieSource(self, title, localtitle, aliases, year, imdb, source, call: ProviderProtocol, from_cache=False, *, ffitem: FFItem):
        fflog.debug(f'getMovieSource {source=}')

        sources = []
        try:
            call.ffitem = ffitem  # XXX, tylko roboczo
            with database.connect(self.sourceFile) as dbcon:
                dbcur = dbcon.cursor()
                self._init_sources_db(dbcur)

                """ Fix to stop items passed with a 0 IMDB id pulling old unrelated sources from the database. """
                if imdb == "0":
                    try:
                        dbcur.execute(
                            "DELETE FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, "", "")
                        )
                        dbcur.execute(
                            "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, "", "")
                        )
                        dbcon.commit()
                    except Exception:
                        pass
                """ END """
                if source in const.sources_dialog.library_cache:
                    # fix pokazania już pobranych przy włączonym cache
                    try:
                        dbcur.execute(
                            "DELETE FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, "", "")
                        )
                        dbcur.execute(
                            "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, "", "")
                        )
                        dbcon.commit()
                    except Exception:
                        pass
                if not self.DEBUG_SINGLE_PROVIDER:  # use DB if not debugging single provider
                    try:
                        dbcur.execute(
                            "SELECT * FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, "", "")
                        )
                        match = dbcur.fetchone()
                        # Exactly one hour of source cache, including Telegram.
                        # Use elapsed time rather than subtracting YYYYMMDDHHMM
                        # integers (which broke around hour/day boundaries).
                        update = not self._source_cache_is_fresh(match[5], max_age_seconds=3600)
                        if not update:
                            with fflog_exc():
                                sources = [Source.from_json(it, ffitem=ffitem) for it in literal_eval(match[4])]
                            # A transient Telegram connection failure must not
                            # become an authoritative empty result for one hour.
                            # Non-empty Telegram aggregates and every other
                            # provider retain the existing cache contract.
                            if source == 'telegram' and not sources:
                                update = True
                            else:
                                with fflog_exc():
                                    if check_and_add_on_account_sources := getattr(call, 'check_and_add_on_account_sources', None):
                                        check_and_add_on_account_sources(sources, ffitem, source)
                                self._append_provider_sources(call, sources)
                                return
                    except Exception:
                        pass

                url = None
                if not self.DEBUG_SINGLE_PROVIDER:  # use DB if not debugging single provider
                    try:
                        dbcur.execute(
                            "SELECT * FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, "", "")
                        )
                        url = dbcur.fetchone()
                        url = literal_eval(url[4])
                    except Exception:
                        pass

                try:
                    if url is None and not from_cache:
                        # fflog(f'call({call}).movie({imdb=}, {title=}, {localtitle=}, {aliases=}, {year=})')
                        with self._with_calling_provider(call):
                            url = call.movie(imdb, title, localtitle, aliases, year)
                        if getattr(call, 'canceled', False):
                            return
                    if url is None and from_cache:
                        results_cache = cache.cache_get(
                            f"{source}_results", control.sourcescacheFile
                        )
                        if results_cache:  # może w ogóle nie być
                            results_cache = literal_eval(results_cache["value"])
                            if results_cache:  # bo może być pusty
                                url = [results_cache[k] for k in results_cache][0]
                                fflog(f"dla {source} odczytano z cache rekordów: {len(url)}")
                    if url is not None and not self.DEBUG_SINGLE_PROVIDER and not getattr(call, 'canceled', False):  # use DB if not debugging single provider
                        dbcur.execute(
                            "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, "", "")
                        )
                        dbcur.execute(
                            "INSERT INTO rel_url Values (?, ?, ?, ?, ?)",
                            (source, imdb, "", "", repr(url)),
                        )
                        dbcon.commit()
                except Exception:
                    pass

                try:
                    with fflog_exc():
                        try:
                            if from_cache:
                                # fflog(f'call({call}).sources({url=}, {self.host_list=}, {self.pr_host_list=}, {from_cache=})')
                                with self._with_calling_provider(call):
                                    sources = call.sources(url, self.host_list, self.pr_host_list, from_cache=from_cache)
                            else:
                                # fflog(f'call({call}).sources({url=}, {self.host_list=}, {self.pr_host_list=})')
                                with self._with_calling_provider(call):
                                    sources = call.sources(url, self.host_list, self.pr_host_list)
                        except ThreadCanceled:
                            pass
                    if sources is None:
                        raise Exception()
                    if getattr(call, 'canceled', False) and not getattr(call, '_kadr_partial_ready', False):
                        fflog(f'[SOURCES] {source}: canceled result discarded before cache/list update')
                        return
                    # remove duplicates while preserving order
                    # it also should work:
                    sources = list({json.dumps(src, sort_keys=True): src for src in sources}.values())

                    # Check if any items has unexpected keys and log them for debugging
                    for src in sources:
                        if unexpected := src.keys() - SourceItem.__annotations__.keys():
                            fflog.warning(f'Source from provider {call.__class__.__module__}.{call.__class__.__name__}'
                                          f' has unexpected source item keys: {", ".join(unexpected)}')

                    with fflog_exc():
                        sources = [Source.from_provider_dict(provider=source, ffitem=ffitem, item=it) for it in sources]
                    self._append_provider_sources(call, sources)
                    if (not self.DEBUG_SINGLE_PROVIDER
                            and not getattr(call, 'canceled', False)
                            and not (source == 'telegram' and not sources)):  # use DB if not debugging single provider
                        dbcur.execute(
                            "DELETE FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, "", "")
                        )
                        dbcur.execute(
                            "INSERT INTO rel_src Values (?, ?, ?, ?, ?, ?)",
                            (
                                source,
                                imdb,
                                "",
                                "",
                                repr([src.as_json() for src in sources]),
                                datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
                            ),
                        )
                        dbcon.commit()
                except Exception:
                    pass
        except OperationalError:
            pass

    def getEpisodeSource(
        self,
        title,
        localtitle,
        year,
        imdb,
        tmdb,
        season,
        episode,
        tvshowtitle,
        localtvshowtitle,
        aliases,
        premiered,
        source,
        call: ProviderProtocol,
        from_cache=False,
        *,
        ffitem: FFItem,
    ):
        # fflog(f'getEpisodeSource {source=}')

        try:
            call.ffitem = ffitem  # XXX, tylko roboczo
            tvdb = ffitem.ids.get('tvdb')
            with database.connect(self.sourceFile) as dbcon:
                dbcur = dbcon.cursor()
                self._init_sources_db(dbcur)
                if source in const.sources_dialog.library_cache:
                    # fix pokazania już pobranych przy włączonym cache
                    try:
                        dbcur.execute(
                            "DELETE FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, season, episode)
                        )
                        dbcur.execute(
                            "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, season, episode)
                        )
                        dbcon.commit()
                    except Exception:
                        pass
                if not self.DEBUG_SINGLE_PROVIDER:  # use DB if not debugging single provider
                    try:
                        sources = []
                        dbcur.execute(
                            "SELECT * FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, season, episode)
                        )
                        match = dbcur.fetchone()
                        update = not self._source_cache_is_fresh(match[5], max_age_seconds=3600)
                        if not update:
                            with fflog_exc():
                                sources = [Source.from_json(it, ffitem=ffitem) for it in literal_eval(match[4])]
                            with fflog_exc():
                                validate_cached_sources = getattr(call, 'validate_cached_sources', None)
                                if validate_cached_sources and not validate_cached_sources(sources):
                                    update = True
                            if not update:
                                with fflog_exc():
                                    if check_and_add_on_account_sources := getattr(call, 'check_and_add_on_account_sources', None):
                                        check_and_add_on_account_sources(sources, ffitem, source)
                                self._append_provider_sources(call, sources)
                                return
                    except Exception:
                        pass

                url = None
                if not self.DEBUG_SINGLE_PROVIDER:  # use DB if not debugging single provider
                    try:
                        dbcur.execute(
                            "SELECT * FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, "", "")
                        )
                        url = dbcur.fetchone()
                        url = literal_eval(url[4])
                    except Exception:
                        pass

                try:
                    if url is None and not from_cache:
                        tvshowtitle, localtvshowtitle = title, localtitle
                        # fflog(f'call({call}).tvshow({imdb=}, {tvdb=}, {tvshowtitle=}, {localtvshowtitle=}, {aliases=}, {year=})')
                        with self._with_calling_provider(call):
                            url = call.tvshow(imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year)
                        if getattr(call, 'canceled', False):
                            return
                    if url is None and from_cache:
                        results_cache = cache.cache_get(
                            f"{source}_results", control.sourcescacheFile
                        )
                        if results_cache:  # może w ogóle nie być
                            results_cache = literal_eval(results_cache["value"])
                            if results_cache:  # może być pusty
                                url = [results_cache[k] for k in results_cache][0]
                                fflog(f"dla {source} odczytano z cache rekordów: {len(url)}")
                    if url is None:
                        raise Exception()
                    if not self.DEBUG_SINGLE_PROVIDER and not getattr(call, 'canceled', False):  # use DB if not debugging single provider
                        dbcur.execute(
                            "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, "", "")
                        )
                        dbcur.execute(
                            "INSERT INTO rel_url Values (?, ?, ?, ?, ?)",
                            (source, imdb, "", "", repr(url)),
                        )
                        dbcon.commit()
                except Exception:
                    pass

                ep_url = None
                if not self.DEBUG_SINGLE_PROVIDER:  # use DB if not debugging single provider
                    try:
                        dbcur.execute(
                            "SELECT * FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, season, episode)
                        )
                        ep_url = dbcur.fetchone()
                        ep_url = literal_eval(ep_url[4])
                    except Exception:
                        pass

                try:
                    if url is None:
                        raise Exception()
                    if ep_url is None and not from_cache:
                        # fflog(f'call({call}).episode({url=}, {imdb=}, {tvdb=}, {title=}, {premiered=}, {season=}, {episode=})')
                        with self._with_calling_provider(call):
                            ep_url = call.episode(url, imdb, tvdb, title, premiered, season, episode)
                        if getattr(call, 'canceled', False):
                            return
                    if url is None and from_cache:
                        results_cache = cache.cache_get(
                            f"{source}_results", control.sourcescacheFile
                        )
                        if results_cache:  # może w ogóle nie być
                            results_cache = literal_eval(results_cache["value"])
                            if results_cache:  # może być pusty
                                url = [results_cache[k] for k in results_cache][0]
                                fflog(f"dla {source} odczytano z cache rekordów: {len(url)}")
                    if ep_url is None:
                        raise Exception()
                    if not self.DEBUG_SINGLE_PROVIDER and not getattr(call, 'canceled', False):  # use DB if not debugging single provider
                        dbcur.execute(
                            "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, season, episode)
                        )
                        dbcur.execute(
                            "INSERT INTO rel_url Values (?, ?, ?, ?, ?)",
                            (source, imdb, season, episode, repr(ep_url)),
                        )
                        dbcon.commit()
                except Exception:
                    pass

                try:
                    sources = []
                    try:
                        if from_cache:
                            # fflog(f'call({call}).sources({ep_url=}, {self.host_list=}, {self.pr_host_list=}, {from_cache=})')
                            with self._with_calling_provider(call):
                                sources = call.sources(ep_url, self.host_list, self.pr_host_list, from_cache=from_cache)
                        else:
                            # fflog(f'call({call}).sources({ep_url=}, {self.host_list=}, {self.pr_host_list=})')
                            with self._with_calling_provider(call):
                                sources = call.sources(ep_url, self.host_list, self.pr_host_list)
                    except ThreadCanceled:
                        pass
                    if sources is None:
                        raise Exception()
                    if getattr(call, 'canceled', False) and not getattr(call, '_kadr_partial_ready', False):
                        fflog(f'[SOURCES] {source}: canceled episode result discarded before cache/list update')
                        return
                    # remove duplicates while preserving order
                    sources = list({json.dumps(src, sort_keys=True): src for src in sources}.values())

                    # Check if any items has unexpected keys and log them for debugging
                    for src in sources:
                        if unexpected := src.keys() - SourceItem.__annotations__.keys():
                            fflog.warning(f'Source from provider {call.__class__.__module__}.{call.__class__.__name__}'
                                          f' has unexpected source item keys: {", ".join(unexpected)}')

                    sources = [Source.from_provider_dict(provider=source, ffitem=ffitem, item=it) for it in sources]
                    self._append_provider_sources(call, sources)
                    if not self.DEBUG_SINGLE_PROVIDER and not getattr(call, 'canceled', False):  # use DB if not debugging single provider
                        dbcur.execute(
                            "DELETE FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'"
                            % (source, imdb, season, episode)
                        )
                        dbcur.execute(
                            "INSERT INTO rel_src Values (?, ?, ?, ?, ?, ?)",
                            (
                                source,
                                imdb,
                                season,
                                episode,
                                repr([src.as_json() for src in sources]),
                                datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
                            ),
                        )
                        dbcon.commit()
                except Exception:
                    pass
        except OperationalError:
            pass

    def alterSources(self, url):
        fflog("alterSources")

        try:
            if settings.getInt("hosts.mode") == 2:
                url += "&select=1"
            else:
                url += "&select=2"
            control.run_plugin(url)
        except Exception:
            pass

    def sourcesFilter(self, *, ffitem: FFItem):
        fflog("sourcesFilter")
        initial_filter_count = len(self.sources)

        def _filter_checkpoint(stage: str, before: int) -> None:
            after = len(self.sources)
            if after != before:
                fflog(f'[FILTER] {stage}: {before} -> {after} (removed {before - after})')

        # Check if any items has unexpected keys and log them for debugging
        for src in self.sources:
            if unexpected := src.meta.keys() - SourceMeta.__annotations__.keys():
                fflog.warning(f'Source from provider {src.provider or "UNKNOWN"} has unexpected source keys: {", ".join(unexpected)}')

        # Sort by provider+url to get deterministic order after multithreaded collection
        self.sources.sort(key=lambda src: (src.provider, src.url))

        # cache na odczyt ustawień PROVIDER.sort.order
        so = SortOrderSettings(source_mods=self.source_mods)
        # cache na odczyt ustawień PROVIDER.library.color.identify2
        libcolors = LibraryColorSettings(source_mods=self.source_mods)
        # cache na odczyt ustawień PROVIDER.color.identify2
        colors = ColorSettings(source_mods=self.source_mods)
        # Set of src mods with premium color items.
        premium_src_mods: Set[str] = {srcmod.name for srcmod in self.source_mods
                                      if getattr(srcmod.provider, "use_premium_color", False)}

        def language_color(src: Source) -> str:
            """Return Kadr+ 2.0 color for the source language, with global fallback."""
            raw = str(src.get("language") or "").lower()
            if src.provider.lower() == 'telegram' or src.get('telegram_aggregate'):
                return settings.getString('telegram.color.identify2') or 'FF2196F3'
            codes = set(re.findall(r"(?<![a-z])(pl|de|en)(?![a-z])", raw))
            if 'multi' in raw or len(codes) > 1:
                return settings.getString('lang.multi.color.identify2') or 'FF00C853'
            # Keep the order predictable for multi-language results.
            for code in ("pl", "de", "en"):
                if code in codes:
                    color = settings.getString(f"lang.{code}.color.identify2")
                    if color:
                        return color
            return settings.getString("default.color.identify2")

        qmax = Quality(settings.getInt("hosts.quality.max"))
        qmin = Quality(settings.getInt("hosts.quality.min"))
        qrange = range(qmin, qmax + 1)
        allowed_source_lang = settings.getInt("source.sound.lang")

        # random.shuffle(self.sources)

        # filtrowanie po zabronionym host (source)
        _before = len(self.sources)
        self.sources = [src for src in self.sources if src.hosting.lower() not in const.sources_dialog.disabled_hosts]
        _filter_checkpoint('disabled-hosts', _before)

        # filtrowanie po regułach (False wyłącza)
        def is_enabled_by_rule(src: Source) -> bool:
            src.attr_update()
            enabled = True
            for pat, attr in const.sources.rules.items():
                if src.match(pat):
                    enabled = attr is not False
                    if attr and attr.meta:
                        src.meta.update(attr.meta)  # type: ignore[union-attr]  -- attr.meta has not required keys, but if they exist they match SourceMeta
                    if attr and attr.final:
                        break
            return enabled
        _before = len(self.sources)
        self.sources = [src for src in self.sources if is_enabled_by_rule(src)]
        _filter_checkpoint('rules', _before)

        # Filtrowanie po słowach kluczowych w opisie lub linku
        if const.sources.exclude_keywords:
            _before = len(self.sources)
            fflog(f"Filtering sources by keywords: {const.sources.exclude_keywords}")
            keywords_lower = [k.lower() for k in const.sources.exclude_keywords]
            self.sources = [
                src for src in self.sources
                if not any(
                    keyword in src.get("info", "").lower() or
                    keyword in src.get("url", "").lower() or
                    keyword in src.get("filename", "").lower() or
                    keyword in src.get("info2", "").lower()
                    for keyword in keywords_lower
                )
            ]
            _filter_checkpoint('exclude-keywords', _before)

        # wywalanie zepsutych url (jesli nie są to pliki lokalne)
        # self.sources = sources_with_links(self.sources)

        for src in self.sources:
            if src.get("checkquality") and src["hosting"].lower() not in self.hq_host_list and src["quality"] not in ["SD", "SCR", "CAM"]:
                src["quality"] = "SD"

        local = [src for src in self.sources if src.get('local')]
        for src in local:
            src.update({"language": self._getPrimaryLang() or "en"})
        self.sources = [src for src in self.sources if src not in local]

        # `direct` na początek listy
        self.sources.sort(key=lambda src: not src.get('direct'))

        _before_host_filter = len(self.sources)
        filter = []
        # for d in debrid.debrid_resolvers:
        #     valid_hoster = {src.hosting for src in self.sources}
        #     valid_hoster = {hosting.lower() for hosting in valid_hoster if d.valid_url('', hosting)}
        #     filter = [src for src in self.sources if src.hosting.lower() in valid_hoster]
        #     for src in filter:
        #         src.meta['debrid'] = d.name
        # if not debrid_only or not debrid.status():
        filter.extend(src for src in self.sources
                      if src.hosting.lower() not in self.pr_host_list and not src.meta.get("debridonly"))
        self.sources = filter
        _filter_checkpoint('hosting/debrid', _before_host_filter)

        # Telegram aggregate is an interactive folder/picker, not a video stream.
        # It must not be converted to 720p or rejected by the user's quality range.
        telegram_aggregates = [src for src in self.sources if src.get('telegram_aggregate')]
        self.sources = [src for src in self.sources if not src.get('telegram_aggregate')]

        for i in range(len(self.sources)):
            q = self.sources[i]["quality"]
            if q == "HD":
                self.sources[i].update({"quality": "720p"})

        _before_quality_filter = len(self.sources) + len(local) + len(telegram_aggregates)
        filter = []
        filter += local
        filter += telegram_aggregates

        CAM_disallowed = settings.getBool("CAM.disallowed")
        if const.dev.sources.force_all_sources:
            filter += list(self.sources)
        else:
            for i in reversed(qrange):
                qq = self.QUALITIES[Quality(i)]
                filter.extend(s for s in self.sources if s["quality"] in qq)

            if CAM_disallowed:
                filter += [i for i in self.sources if i["quality"] in ["SCR"]]
            else:
                filter += [i for i in self.sources if i["quality"] in ["SCR", "CAM"]]

            # Filtrowanie po dostępności transferu
            if settings.getBool("source.premium.no_transfer"):
                filter = [
                    i for i in filter
                    if not i.get("no_transfer", False) or i.get("on_account", False)
                ]

        self.sources = filter
        _filter_checkpoint('quality/premium', _before_quality_filter)

        # filter_out = {
        #     id(i)
        #     for i in self.sources
        #     if i["source"].lower() in self.hostblockDict and "debrid" not in i
        # }
        # self.sources = [i for i in self.sources if id(i) not in filter_out]

        # filtrowanie po wielkości pliku
        if not const.dev.sources.force_all_sources:
            _before = len(self.sources)
            size_min = settings.getInt('source.size.min') * GB
            size_max = (settings.getInt('source.size.max') or 10**6) * GB
            size_range = range(size_min, size_max + 1)
            self.sources = [
                s for s in self.sources
                if s.provider.lower() == "telegram"
                or s.hosting in ("download", "library")
                or not (size := source_utils.convert_size_to_bytes(s.get("size", "")))
                or size in size_range
            ]
            _filter_checkpoint('size', _before)

        multi = [i["language"] for i in self.sources]
        multi = [x for y, x in enumerate(multi) if x not in multi[:y]]
        multi = True if len(multi) > 1 else False

        if multi:
            self.sources = [i for i in self.sources if not i["language"] == "en"] + [
                i for i in self.sources if i["language"] == "en"
            ]

        # Usuń tylko rzeczywiste duplikaty. Różne języki, jakości, rozmiary
        # i wydania tego samego materiału pozostają osobnymi pozycjami.
        self._deduplicate_sources()

        # ograniczenie maksymalnej ilości źródeł
        self.sources = self.sources[:2000]

        # muszą być wszystkie pozycje, które zwraca source_utils.check_sd_url()
        # i które zostały "zassane" przez zmienną filter
        my_quality_order = ["4K", "1440p", "1080p", "1080i", "720p", "SD", "SCR", "CAM"]
        quality_order = {key: i for i, key in enumerate(my_quality_order)}

        # muszą być wszystkie możliwości wypisane jakie chcemy obsługiwać
        language_order = {key: i for i, key in enumerate(const.sources.language_order)}

        def order_language(src: Source) -> int:
            raw = str(src.get('language') or '').lower().strip()
            if raw in language_order:
                return language_order[raw]
            tokens = re.findall(r'[a-z]{2,8}', raw)
            ranks = [language_order[t] for t in tokens if t in language_order]
            return min(ranks) if ranks else len(language_order) + 10

        def order_quality(src: Source) -> int:
            return quality_order.get(str(src.get('quality') or ''), len(quality_order) + 10)

        priority = self.language_type_priority

        def normalize_language_type(text: str) -> Tuple[Tuple[int, ...], bool]:
            parts = text.lower().replace("|", " ").replace(",", " ").split()
            is_kino = "kino" in parts
            prioritized = tuple(
                priority[p]
                for p in parts
                if p in priority
            )
            return (prioritized, is_kino)

        # ustalenie kolejności dla nazw serwisów
        # z ustawień sort.order
        my_provider_order: List[Union[str, int]] = list(range(1, 11))

        premium_providers = sorted(
            {i["provider"] for i in self.sources if i.get("premium", False)}  # Domyślnie False, jeśli "premium" brak
        )
        my_provider_order.extend(premium_providers)
        provider_order = {key: i for i, key in enumerate(my_provider_order)}

        # --- wpólne funkcje pomocne przy sortowaniu ---
        def order_provider(src: Source) -> int:
            provider: str = src['provider']
            # Sprawdź czy to premium źródło
            if provider.lower() in premium_src_mods and src.get("premium"):
                # Premium - użyj ustawionego sort.order
                return provider_order.get(so[provider] or provider, len(my_provider_order))
            else:
                # Darmowe - standardowa pozycja (bez preferencji)
                return len(my_provider_order)

        def order_size(src: Source) -> int:
            size = src.get("size")
            if not size:
                size = (src.get("info") or "").rpartition("|")[2]
            return source_utils.convert_size_to_bytes(size) * -1

        def order(src: Source, *, by_provider: bool = True) -> int:
            if (order := src.attr.order) is None:
                order = 0
                for i, name in enumerate(reversed(('download', 'library', 'plex', 'jellyfin', 'external')), 1):
                    if src.provider.startswith(name):  # TODO, why not provider == name?
                        order += 2000 + i
                if src.get('on_account', 0):
                    order += 1000
                if by_provider:
                    order += 999 - min(999, order_provider(src))
            # d['_order'] = order  # DEBUG order
            return -order
        # wybór wariantu
        sort_source = settings.getInt("hosts.sort")
        if sort_source == 0:
            fflog("Sortuję wg dostawców")  # by providers
            self.sources = sorted(
                self.sources,
                key=lambda d: (
                    order(d),
                    order_language(d),
                    order_quality(d),
                    d["provider"],  # provider (serwis internetowy www)
                    normalize_language_type(d.get("info", "")),
                    order_size(d),
                ),
            )
        if sort_source == 1:
            fflog("Sortuję wg źródeł (hostingów)")  # by hosting (hosting, server)
            self.sources = sorted(
                self.sources,
                key=lambda d: (
                    order(d),
                    order_language(d),
                    order_quality(d),
                    d["hosting"],  # hosting (serwer, hosting)
                    normalize_language_type(d.get("info", "")),
                    order_size(d),
                ),
            )
        if sort_source == 2:
            fflog("Sortuję wg rozmiaru")  # by size
            self.sources = sorted(
                self.sources,
                key=lambda d: (
                    order(d),
                    order_size(d),
                    normalize_language_type(d.get("info", "")),
                ),
            )
        if sort_source == 3:
            custom_criterion = ' -> '.join(SortElem(settings.getInt(f"hosts.sort.elem{n+1}")).name
                                           for n in range(4))
            fflog(f'Sortuję wg ustawień użytkownika: {custom_criterion}')  # custom

            # funkcja pomocnicza
            def choose_criterium(d: Source, n: int) -> int:
                crit = SortElem(settings.getInt(f"hosts.sort.elem{n+1}"))
                # fflog(f"choose_criterium {n}: {crit.name}")
                try:
                    if crit == SortElem.SERVICE:
                        return order_provider(d)
                    if crit == SortElem.LANGUAGE:
                        return order_language(d)
                    if crit == SortElem.QUALITY:
                        return order_quality(d)
                    if crit == SortElem.SIZE:
                        return order_size(d)
                except Exception as e:
                    fflog(f"Error in choose_criterium for {d}: {e!r}")
                return 0

            # sortowanie
            self.sources = sorted(
                self.sources,
                key=lambda d: (
                    # zawsze na początku (pobrane,local ...) oraz na koncie online
                    order(d, by_provider=False),
                    # kryteria użytkownika
                    choose_criterium(d, 0),  # 1-wsze kryterium
                    choose_criterium(d, 1),  # 2-gie kryterium
                    choose_criterium(d, 2),  # 3-cie kryterium
                    choose_criterium(d, 3),  # 4-te kryterium
                    normalize_language_type(d.get("info", "")),
                ),
            )

        exts = self.exts
        extra_info = settings.getBool("sources.extrainfo")

        # Kompilacja wyrażeń regularnych dla pola 'audio'
        audio_re1 = re.compile(r"(?<!\d)([57]\.[124](?:\.[24])?)\.(ATMOS)\b", re.I)
        audio_re2 = re.compile(r"(?<=[DSPXAC3M])[.-]?([57261]\.[102])\b", re.I)
        audio_re3 = re.compile(r"\b(DTS)[.-]?(HD|ES|EX|X(?!26))[. ]?(MA)?", re.I)
        audio_re4 = re.compile(r"(TRUEHD|DDP)\.(ATMOS)\b", re.I)
        audio_re5 = re.compile(r"(custom|dual)\.(audio)", re.I)
        audio_re6 = re.compile(r"ddp(?!l)", re.I)

        # Kompilacja wyrażeń regularnych dla pola 'codec'
        codec_re1 = re.compile(r"(\d{2,3})(fps)", re.I)
        codec_re2 = re.compile(r"plus", re.I)
        codec_re3 = re.compile(r"\bDoVi\b", re.I)
        codec_re4 = re.compile(r"\s*/\s*DolbyVision", re.I)
        codec_re5 = re.compile(r"DolbyVision", re.I)

        # Kompilacja wyrażeń regularnych dla pola 'quality'
        quality_re1 = re.compile(r"\b(\w+)\.(\w+)\b", re.I)

        for i, src in enumerate(self.sources):
            url2: str = ''
            if extra_info:
                try:
                    if url2 := src.meta.get("filename"):
                        pass
                    else:
                        url2 = (
                            src["url"]
                            .replace(" / ", " ")
                            .replace("_/_", "_")
                            .rstrip("/")
                            .split("/")[-1]
                        )
                        url2 = url2.rstrip("\\").split("\\")[
                            -1
                        ]  # dla plików z własnej biblioteki na dysku lokalnym
                        # fflog(f' {[i]} {url2=!r}')
                        url2 = re.sub(
                            r"(\.(html?|php))+$", "", url2, flags=re.I
                        )  # na przypadki typu "filmik.mkv.htm"
                        if url2.lower()[-3:] not in exts:
                            # próba pozyskanie nazwy z 2-giej linijki lub opisu
                            if (
                                "info2" in src
                                and src["info2"]
                                and src["info2"].lower()[-3:] in exts
                            ):
                                url2 = src["info2"]
                            else:
                                """
                                # to raczej nie będzie już wykorzystywane, bo okazało się, że info może mieć juz swoje oznaczenia, więc mogą się dublować
                                url2 = src["info"] if src["info"] else ''
                                # próba odfiltrowania nazwy
                                url2 = url2.split("|")[-1].strip().lstrip("(").rstrip(")")
                                """
                                url2 = ""

                    url2 = unquote(
                        url2
                    )  # zamiana takich tworów jak %nn (np. %21 to nawias)
                    url2 = unescape(url2)  # pozbycie się encji html-owych

                    t = PTN.parse(url2)  # proces rozpoznawania
                    t3d = (
                        t["3d"] if "3d" in t else ""
                    )  # zapamiętanie informacji pod inną zmienną czy wersja 3D
                    textended = (
                        t["extended"] if "extended" in t else ""
                    )  # informacja o wersji rozszerzonej
                    tremastered = (
                        t["remastered"] if "remastered" in t else ""
                    )  # informacja o wersji zremasterowanej

                    # poniżej korekty wizualne
                    if "audio" in t:
                        t["audio"] = audio_re1.sub(r"\1 \2", t["audio"])
                        t["audio"] = audio_re2.sub(r" \1", t["audio"])
                        t["audio"] = audio_re3.sub(r"\1-\2 \3", t["audio"]).rstrip()
                        t["audio"] = audio_re4.sub(r"\1 \2", t["audio"])
                        t["audio"] = audio_re5.sub(r"\1 \2", t["audio"])
                        t["audio"] = audio_re6.sub("DD+", t["audio"])
                    if "codec" in t:
                        t["codec"] = codec_re1.sub(r"\1 \2", t["codec"])
                        t["codec"] = codec_re2.sub("+", t["codec"])
                        t["codec"] = codec_re3.sub("DV", t["codec"])
                        if "DV".lower() in t["codec"].lower():
                            t["codec"] = codec_re4.sub("", t["codec"])
                        else:
                            t["codec"] = codec_re5.sub("DV", t["codec"])
                    if "quality" in t:
                        t["quality"] = quality_re1.sub(r"\1-\2", t["quality"])

                    t = [
                        t[j]
                        for j in t
                        if "quality" in j or "codec" in j or "audio" in j
                    ]
                    t = " | ".join(t)

                    if not t:
                        t = source_utils.getFileType(
                            url2
                        )  # taki fallback dla PTN.parse()
                        t = t.strip()

                    """
                    # pozbycie się tych samych oznaczeń ze zmiennej info
                    if t:
                        src["info"] = re.sub(fr'(\b|[ ._|/]+)({"|".join(t.split(" / "))})\b', '', src["info"], flags=re.I)
                    """

                    # dodanie dodatkowych informacji (moim zdaniem ważnych)
                    if t3d:
                        if "3d" in url2.lower() and "3d" not in t.lower():
                            t = f"[3D] | {t}"
                        else:
                            t = t.replace("3D", "[3D]")
                    # dodatkowe oznaczenie pliku z wieloma sciezkami audio
                    if (
                        re.search(
                            r"\bMULTI\b", url2, re.I
                        )  # szukam w adresie, który powinien zawierać nazwę pliku
                        and "mul" not in src["language"].lower()
                        # and "PL" not in src["language"].upper()  # założenie, że jak wykryto język PL, to nie ma potrzeby o dodatkowym ozaczeniu
                        and "multi"
                        not in src[
                            "info"
                        ].lower()  # sprawdzenie, czy przypadkiem już nie zostało przekazane przez plik źródła
                        and "multi"
                        not in t.lower()  # sprawdzenie, czy nie ma tej frazy już w opisie
                    ):
                        t += " | MULTI"
                    if (
                        "multi" in t.lower()
                        or "multi" in src["info"].lower()
                    ) and src["language"] != "pl":
                        src["language"] = "multi"  # wymiana języka
                        t = re.sub(
                            r"[/| ]*multi\b", "", t, flags=re.I
                        )  # wywalenie z opisu, aby nie było dubli
                        src["info"] = re.sub(
                            r"[/| ]*multi\b", "", src["info"], flags=re.I
                        )  # wywalenie z opisu, aby nie było dubli

                    if textended:
                        if textended is True:
                            t += " | EXTENDED"
                        else:
                            textended = re.sub(
                                "(directors|alternat(?:iv)?e).(cut)",
                                r"\1 \2",
                                textended,
                                flags=re.I,
                            )
                            t += f" | {textended}"

                    # długi napis i czy aż tak istotny?
                    if tremastered:
                        if tremastered is True:
                            t += " | REMASTERED"
                        else:
                            if "rekonstrukcja" not in t.lower():
                                tremastered = re.sub(
                                    "(Rekonstrukcja).(cyfrowa)",
                                    r"\1 \2",
                                    tremastered,
                                    flags=re.I,
                                )
                                t += f" | {tremastered}"

                    if (
                        "imax" in url2.lower() and "imax" not in t.lower()
                    ):  # sprawdzenie czy dodać info IMAX
                        t += " | [IMAX]"

                    if (
                        "avi" in url2.lower()[-3:] and "avi" not in t.lower()
                    ):  # aby nie bylo zdublowań
                        t += " | AVI"  # oznaczenie tego typu pliku, bo nie zawsze dobrze odtwarza sie "w locie"

                    t = t.lstrip(
                        " | "
                    )  # przydaje się, jak ani PTN.parse() ani getFileType() nic nie znalazły
                    t += " "

                    src.meta['info2'] = ' | '.join(x for x in [src.meta.get('info2'), t] if x.strip())
                except Exception:
                    t = None
            else:
                t = None

            # u = src["url"]  -- NOT USED

            p = src.provider  # serwis, strona www
            lng = src["language"]
            s = src.hosting  # serwer / hosting / dawne "source"
            q = src["quality"]  # rozdzielczość

            s = s.rsplit(".", 1)[
                0
            ]  # wyrzucenie ostatniego człona domeny (np. ".pl", ".com")

            try:  # f to info (tu może być też rozmiar pliku na końcu)
                display_info = source_utils.clean_redundant_language_info(
                    src.get("info", ""), lng
                )
                f = " | ".join(
                    [
                        "[I]%s [/I]" % info.strip()
                        for info in display_info.split("|")
                        if info.strip()
                    ]
                )
            except Exception:
                f = ""

            d = src.meta.setdefault('debrid', '')
            if d.lower() == "real-debrid":
                d = "RD"

            if d:
                label = "%02d | [B]%s | %s[/B] | " % (i, d, p)
            else:
                label = "%02d | [LIGHT][B]%s[/B][/LIGHT] | " % (i, p)

            # oznaczenie, czy źródło jest w tzw. bibliotece danego serwisu
            if src.get('on_account'):
                if expires := src.get('on_account_expires'):
                    label += f'[I]konto ({expires})[/I]  | '
                else:
                    label += "[I]konto[/I]  | "

            # oznaczenie języka
            if lng:
                if (
                    multi
                    and lng != "en"  # nie rozumiem, kiedy ten warunek zachodzi
                    or not multi
                    and lng != "en"  # dałem ten warunek
                ):
                    label += "[B]%s[/B] | " % lng

            if t:  # extra_info
                if q in ["4K", "1440p", "1080p", "1080i", "720p"]:
                    label += "%s | [B][I]%s [/I][/B] | [I]%s[/I] | %s" % (s, q, t, f)
                elif q == "SD":
                    # label += "%s | %s | [I]%s[/I]" % (s, f, t)
                    # moja propozycja (wielkość pliku na końcu - dla spójności)
                    label += "%s | [I]%s[/I] | %s" % (s, t, f)
                else:
                    # label += "%s | %s | [I]%s [/I] | [I]%s[/I]" % (s, f, q, t)
                    # moja propozycja (wielkość pliku na końcu - dla spójności)
                    # label += "[LIGHT]%s | [B][I]%s [/I][/B] | [I]%s[/I] | %s[/LIGHT]" % (s, q, t, f)
                    label += "[LIGHT]%s | [I]%s[/I] | %s[/LIGHT]" % (s, t, f)
            else:
                if q in ["4K", "1440p", "1080p", "1080i", "720p"]:
                    label += "%s | [B][I]%s [/I][/B] | %s" % (s, q, f)
                elif q == "SD":
                    label += "%s | %s" % (s, f)
                else:
                    # label += "%s | %s | [I]%s [/I]" % (s, f, q)
                    # moja propozycja (wielkość pliku na końcu - dla spójności)
                    # label += "[LIGHT]%s | [B][I]%s [/I][/B] | %s[/LIGHT]" % (s, q, f)
                    label += "[LIGHT]%s | %s[/LIGHT]" % (s, f)

            # korekty wizualne
            label = label.replace("| 0 |", "|").replace(" | [I]0 [/I]", "")
            label = re.sub(r"\[I\]\s+\[/I\]", " ", label)
            label = re.sub(r"\|\s+\|", "|", label)
            label = re.sub(
                r"\|\s+\|", "|", label
            )  # w pewnych okolicznościach ponowne wykonanie takiej samej linijki kodu jak wyżej pomaga
            label = re.sub(r"\|(?:\s+|)$", "", label)
            label = re.sub(
                r"(\d+(?:[.,]\d+)?\s*[GMK]B)", r"[B]\1[/B]", label, flags=re.I
            )  # wyróżnienie rozmiaru pliku
            label = re.sub(
                r"(?<=\d)\s+(?=[GMK]B\b)", "\u00A0", label, flags=re.I
            )  # aby nie rodzielal cyfr od jednostek
            # aby np. 1080i było bardziej widoczne
            # label = re.sub(r"\s?((\[\w\])*(?:1080|720|1440)[pi])\s?", r"[LOWERCASE]\1[/LOWERCASE]", label,flags=re.I)
            label = re.sub(
                "((?:1080|720|1440)[pi])",
                r"[LOWERCASE]\1[/LOWERCASE]",
                label,
                flags=re.I,
            )

            # To źródło jest w biliotece, używamy specjalnego koloru dla biblioteki tego providera
            color: str = libcolors[p]
            if not color or not src.get("on_account"):
                # Sprawdź czy to premium źródło od premium providera
                if p.lower() in premium_src_mods and src.get("premium"):
                    # Premium content - użyj dedykowanego koloru providera
                    color = colors[p]
                    if not color or color == DEFAULT_COLOR_LINK:
                        # Fallback na globalny kolor premium
                        color = settings.getString("prem.color.identify2")
                else:
                    # Darmowy content - kolor według języka (PL/DE/EN)
                    color = language_color(src)
            # Jeśli jest kolor, ale jest to kolor domyślny, to jawnie bierzemy jego wartość.
            if color == DEFAULT_COLOR_LINK:
                color = language_color(src)
            # Ręczne nadpisywanie kolorów
            color = src.attr.color or color
            # Jeśli mamy kolor, to kolorujemy
            if color:
                src["color_identify"] = color
                src["label"] = f"[COLOR {color}]{label.upper()}[/COLOR]"
            else:
                # custom-lista musi mieć jakiś kolor, bierzemy domyślny (niejawnie)
                src["color_identify"] = language_color(src)
                src["label"] = label.upper()

            if (
                settings.getBool("sources.filename_in_2nd_line")
                and "info2" not in src
            ):
                if url2 and url2.lower()[-3:] in exts:  # zmienna 'exts' jest definiowana po 'url2'
                    src["info2"] = url2
                elif extra_info and (filename := src.get("filename")):
                    src["info2"] = filename

            if text := src.get("info2"):
                src["info2"] = unescape(unquote(text))  # mam nadzieję, kolejność odkodowywania nie ma znaczenia
                src["label"] += f"[LIGHT][CR]  {text}[/LIGHT]"

        # czy mogą być pozycje bez "label" ?
        self.sources = [src for src in self.sources if "label" in src]

        """to już w dzisiejszych czasach chyba nie ma znaczenia
        if not HEVC:
            self.sources = [
                src
                for src in self.sources
                if "HEVC" not in src["label"] or "265" not in src["label"]
            ]
        """

        if not const.dev.sources.force_all_sources:
            if not settings.getBool("HDR.allowed"):
                self.sources = [
                    src
                    for src in self.sources
                    if "HDR" not in src["label"]
                ]

            if not settings.getBool("DV.allowed"):
                self.sources = [
                    src
                    for src in self.sources
                    if "DV" not in src["label"]
                ]

            if not settings.getBool("AV1.allowed"):
                self.sources = [
                    src
                    for src in self.sources
                    if "AV1" not in src["label"]
                ]

            if not settings.getBool("HEVC.allowed"):
                self.sources = [
                    src
                    for src in self.sources
                    if "HEVC" not in src["label"] or "265" not in src["label"]
                ]

            if not settings.getBool("F3D.allowed"):
                self.sources = [
                    src
                    for src in self.sources
                    if "[3D]" not in src["label"]
                ]

            if not settings.getBool("AVI.allowed"):
                self.sources = [
                    src
                    for src in self.sources
                    if not (
                        src.get("url", "").lower().endswith(".avi")
                        or src.get("filename", "").lower().endswith(".avi")
                    )
                ]

            if CAM_disallowed:
                CAM_format = ["camrip", "tsrip", "hdcam", "hqcam", "dvdcam", "dvdts", "cam", "telesync", " ts"]
                if settings.getBool("HDTS.disallowed"):
                    CAM_format += ["hdts", "hd-ts"]
                self.sources = [
                    src
                    for src in self.sources
                    # if "CAM" not in src["label"]
                    if not any(x in src["label"].lower() for x in CAM_format)
                ]

            if settings.getBool("SUBTITLES.disallowed"):
                def _has_pl_audio(label):
                    return any(x in label for x in ["lektor", "dubbing"])

                def _has_subs(label):
                    return any(x in label for x in ["napisy", "subbed", "subtitles", " sub ", "]sub"])

                self.sources = [src for src in self.sources
                                if not _has_subs(src["label"].lower()) or _has_pl_audio(src["label"].lower())]

            if settings.getBool("LEKTORAI.disallowed"):
                self.sources = [
                    src
                    for src in self.sources
                    if not source_utils.is_ai_lector(src.get("label", ""))
                ]

            if settings.getBool("MD.sound.disallowed"):
                self.sources = [
                    src
                    for src in self.sources
                    if not re.search(r"\b(md|dubbing[ _.-]kino)\b", src["label"], re.I)
                ]

            if allowed_source_lang:
                _before = len(self.sources)
                langs: dict[int, set[str]] = {
                    1: {'pl'},
                    2: {'pl', 'multi'},
                    3: {'en', ''},  # puste to podobno EN
                    4: {'en', 'multi', ''},  # puste to podobno EN
                    5: {'de'},
                    6: {'de', 'multi'},
                    7: {'pl', 'de', 'multi'},
                    8: {'pl', 'de', 'en', 'multi', ''},
                }
                allowed = langs[allowed_source_lang]
                if const.sources.include_languages:
                    allowed |= {lang.lower() for lang in const.sources.include_languages}
                self.sources = [
                    src for src in self.sources
                    if src.get('telegram_aggregate')
                    # Some DE providers intentionally expose several audio
                    # variants on the same title/episode. Once the user enabled
                    # that provider, keep every real language row instead of
                    # silently dropping EN/FR/etc. via the global language preset.
                    # Each source still carries its own language badge.
                    or src.provider.lower() in ('filmo', 'serienstream')
                    or set(src.get('language', '').lower().split()) & allowed
                ]
                _filter_checkpoint('language', _before)

        fflog(f'[FILTER] final: {initial_filter_count} -> {len(self.sources)}')
        # return all sources
        return self.sources

    def resolve_source(self, item: Source, /, info: bool = False,
                       for_resolve: SourceResolveKwargs | None = None,
                       resume_before_stream: bool = False, **kwargs) -> str | None:
        fflog("sourcesResolve")
        if for_resolve is None:
            for_resolve = {}
        diag = None
        try:
            if settings.getBool('diagnostics.enabled'):
                from . import diagnostics as diag
        except Exception:
            diag = None
        try:
            if item is None:
                raise ValueError('No source item')
            if item.get('fake'):
                if resolve_to := item.get('resolve_to'):
                    return str(resolve_to)
                raise ValueError('Fake source item')

            u = url = item["url"]
            if diag is not None:
                diag.log_source_event('resolve-start', item, url)

            d = item["debrid"]
            direct = item.get("direct", False)
            local = item.get("local", False)

            provider = item["provider"]
            src_mod: SourceModule = next(iter(sm for sm in self.source_mods if sm.name == provider))
            fflog(f'Go to {item.provider!r} to resolve {url!r}')
            resolve_kwargs = dict(for_resolve)
            resume_key = str(item.ffitem.ref)
            # Every new selection invalidates an unconsumed decision from a
            # failed previous resolve of the same movie/episode.
            self._pending_resume_choices.pop(resume_key, None)
            if resume_before_stream and item.get('telegram_aggregate'):
                def _before_telegram_stream_start():
                    try:
                        self._pending_resume_choices[resume_key] = self._resume_choice_for_source(
                            item,
                            timing='after-telegram-file-selection-before-stream',
                        )
                    except Exception:
                        # Loading ownership is independent from the optional
                        # resume UI.  If the prompt itself fails, player.play()
                        # still gets the same protected session id.
                        fflog_exc(1)
                    begin_session = getattr(self, '_begin_playback_session', None)
                    return begin_session(item) if callable(begin_session) else ''

                resolve_kwargs['before_stream_start'] = _before_telegram_stream_start
            u = url = src_mod.provider.resolve(url, **resolve_kwargs)
            if diag is not None:
                diag.log_source_event(
                    'provider-resolve', item, url,
                    detail='result=' + ('cancelled' if url is False else 'none' if url is None else 'ok'),
                )

            # Telegram aggregate opens a nested result list inside the source
            # window. Back from that list must not resolve/cancel the Kodi player
            # handle; it simply returns to the still-open main source list.
            telegram_cancelled = (
                url is False or bool(getattr(src_mod.provider, 'selection_cancelled', False))
            )
            if item.get('telegram_aggregate') and telegram_cancelled:
                fflog('[SOURCES] Telegram result picker closed without selection')
                self._discard_pending_playback_session(item)
                return None

            if url is None:
                error_msg = L(30337, 'Selected link is not working')
                fflog.warning(f'Dead link in provider {provider!r} ({item.get("hosting", "unknown")}): {u!r}')
                raise DeadLink(error_msg)

            if "://" not in str(url) and not local:
                # if provider in ('netflix', 'external'):
                #    return url
                raise ValueError(f'Invlaid URL {url!r} in provider {provider!r}')

            if not local:
                url = url[8:] if url.startswith("stack:") else url

                urls = []
                for part in url.split(" , "):
                    u = part
                    # Plugin URLs are internal Kodi paths and should not be passed to external resolvers.
                    if part.startswith("plugin://"):
                        if diag is not None:
                            diag.log_source_event('resolver-plugin', item, part)
                        pass  # Keep the plugin URL as is.
                    elif not d == "":
                        part = debrid.resolver(part, d)
                        if diag is not None:
                            diag.log_source_event('resolver-debrid', item, part, detail='result=' + ('ok' if part else 'empty'))

                    elif not direct:
                        # Kadr+ 2.0's custom resolvers take precedence over upstream
                        # resolveurl for hosts we maintain ourselves
                        # (see lib/resolvers/). Toggle: const.sources.local_resolvers.
                        from ..resolvers import resolve_local
                        if const.sources.local_resolvers and (resolved := resolve_local(u)):
                            part = resolved
                            if diag is not None:
                                diag.log_source_event('resolver-local', item, part, detail='result=ok')
                        elif resolveurl is None:
                            if diag is not None:
                                diag.log_source_event('resolver-resolveurl', item, u, detail='module=missing', level=xbmc.LOGWARNING)
                            fflog.warning('resolveurl module not available')
                            bare = str(u).split('|', 1)[0].split('?', 1)[0].lower()
                            if not bare.endswith(('.m3u8', '.mpd', '.mp4', '.webm', '.ts')):
                                raise DeadLink(L(30337, 'Selected link is not working'))
                        else:
                            hmf = resolveurl.HostedMediaFile(url=u, include_disabled=True, include_universal=False)
                            bare = str(u).split('|', 1)[0].split('?', 1)[0].lower()
                            playable_direct = bare.endswith(('.m3u8', '.mpd', '.mp4', '.webm', '.ts'))
                            if hmf.valid_url():
                                if diag is not None:
                                    diag.log_source_event('resolver-resolveurl', item, u, detail='recognized=true')
                                resolved = hmf.resolve()
                                if resolved:
                                    part = resolved
                                    if diag is not None:
                                        diag.log_source_event('resolver-resolveurl-result', item, part, detail='result=ok')
                                elif not playable_direct:
                                    if diag is not None:
                                        diag.log_source_event('resolver-resolveurl-result', item, u, detail='result=empty', level=xbmc.LOGWARNING)
                                    raise DeadLink(L(30337, 'Selected link is not working'))
                            elif not playable_direct:
                                if diag is not None:
                                    diag.log_source_event('resolver-resolveurl', item, u, detail='recognized=false', level=xbmc.LOGWARNING)
                                # Do not hand an ordinary iframe/embed HTML page
                                # to Kodi as if it were a video stream.  This is
                                # the failure pattern seen for firestream.to/e/...
                                # in the Android log.
                                raise DeadLink(L(30337, 'Selected link is not working'))
                    if direct and diag is not None:
                        diag.log_source_event('resolver-direct', item, part)
                    urls.append(part)

                url = "stack://" + " , ".join(urls) if len(urls) > 1 else urls[0]

            if not url:
                raise ValueError(f'Empty URL in provider {provider!r}')

            ext = (
                url.split("?")[0]
                .split("&")[0]
                .split("|")[0]
                .rsplit(".")[-1]
                .replace("/", "")
                .lower()
            )
            if ext == "rar":
                raise ValueError(f'RAR in URL in provider {provider!r}')

            drm_url, _, headers = url.partition('|')
            if " " in headers:
                headers = quote_plus(headers).replace("%3D", "=")
            headers = dict(parse_qsl(headers))

            if url.startswith("http") and ".m3u8" in url:
                result = client.request(drm_url, headers=headers, output="geturl", timeout=20)
                if result is None:
                    raise DeadLink(f'Resolve m3u8 failed in provider {provider!r}')
            # elif url.startswith("http"):
            #     return url

            fflog(f'[SOURCES] resolve to {url!r} in provider {provider!r}')
            if diag is not None:
                diag.log_source_event('resolve-final', item, url, detail='result=ok')
            return url

        except DeadLink as e:
            # Przewidywane błędy (martwe źródło, invalid URL, itd.) - logujemy jako warning
            error_msg = str(e)
            if diag is not None:
                diag.log_source_event('resolve-failed', item, locals().get('u') or locals().get('url'), detail=f'error={type(e).__name__}: {error_msg}', level=xbmc.LOGWARNING)
            fflog.warning(f'Failed to resolve source: {error_msg}')
            self._discard_pending_playback_session(item)
            if info:
                control.infoDialog(f'{error_msg}', sound=False, icon='INFO')
            return

        except Exception as e:
            # Nieprzewidziane błędy - logujemy jako exception
            if diag is not None:
                try:
                    diag.log_source_event('resolve-exception', item, locals().get('u') or locals().get('url'), detail=f'error={type(e).__name__}: {e}', level=xbmc.LOGERROR)
                except Exception:
                    pass
            fflog_exc()
            self._discard_pending_playback_session(item)
            error_info = L(32401, 'No stream available')
            if str(e):
                import xbmcgui
                xbmcgui.Dialog().notification('Kadr+ 2.0', f'{error_info}: {e}')
            if info:
                # player.cancel()
                control.infoDialog(f'{error_info}: {e}', sound=False, icon='INFO')
            return


    def getLanguage(self):
        fflog.debug("getLanguage")

        langDict = {
            "English": ["en"],
            "German": ["de"],
            "German+English": ["de", "en"],
            "French": ["fr"],
            "French+English": ["fr", "en"],
            "Portuguese": ["pt"],
            "Portuguese+English": ["pt", "en"],
            "Polish": ["pl"],
            "Polish+English": ["pl", "en"],
            "Polish+German": ["pl", "de"],
            "Polish+German+English": ["pl", "de", "en"],
            "Korean": ["ko"],
            "Korean+English": ["ko", "en"],
            "Russian": ["ru"],
            "Russian+English": ["ru", "en"],
            "Spanish": ["es"],
            "Spanish+English": ["es", "en"],
            "Greek": ["gr"],
            "Italian": ["it"],
            "Italian+English": ["it", "en"],
            "Greek+English": ["gr", "en"],
        }
        name = settings.getString("providers.lang")
        return langDict.get(name, ["pl"])

    def getLocalTitle(self, title, imdb, tmdb, content):
        fflog("getLocalTitle")

        lang = self._getPrimaryLang()
        if not lang:
            return title

        # TODO: TRAKT
        t = ''
        # if content == "movie":
        #     t = trakt.getMovieTranslation(imdb, lang)
        # else:
        #     t = trakt.getTVShowTranslation(imdb, lang)

        return t or title

    def getAliasTitles(self, imdb, localtitle, content, *, ffitem: FFItem) -> List[Dict[Literal['title', 'country', 'originalname'], str]]:
        return [{'title': a.title, 'country': a.country} for a in ffitem.aliases_info]
        # fflog("getAliasTitles")
        # lang = self._getPrimaryLang()

        # try:
        #     t = (ffinfo.trakt.aliases('movie', imdb) if content == "movie" else ffinfo.trakt.aliases('show', imdb))
        #     return [i for i in t if (i.get("country", "").lower() in [lang, "", "us"]
        #                              and i.get("title", "").lower() != localtitle.lower())]
        # except:
        #     return []

    def getTMDBAliasTitles(self, tmdb, localtitle, content):
        fflog("getTMDBAliasTitles")

        try:
            api_key = settings.getString("tmdb.api_key") or apis.tmdb_API
            base_url = "https://api.themoviedb.org/3/"

            if content == "movie":
                url = f"{base_url}movie/{tmdb}/alternative_titles?api_key={api_key}"
            else:
                url = f"{base_url}tv/{tmdb}/alternative_titles?api_key={api_key}"

            response = client.request(url, output="json")

            if content == "movie":
                titles = response.get("titles", [])
            else:
                titles = response.get("results", [])

            aliases = []
            added_titles = set()

            for title in titles:
                key = title["title"]
                if key not in added_titles:
                    aliases.append(
                        {
                            "title": title["title"],
                            "country": title["iso_3166_1"].lower(),
                        }
                    )
                    added_titles.add(key)

            # Usuwanie duplikatów
            reduce_dupes = {i["title"]: i for i in aliases}
            aliases = [i for i in reduce_dupes.values()]

            return aliases
        except Exception as e:
            print(f"Wystąpił błąd: {e}")
            return []

    def _getPrimaryLang(self):
        fflog("_getPrimaryLang")

        langDict = {
            "English": "en",
            "German": "de",
            "German+English": "de",
            "French": "fr",
            "French+English": "fr",
            "Portuguese": "pt",
            "Portuguese+English": "pt",
            "Polish": "pl",
            "Polish+English": "pl",
            "Polish+German": "pl",
            "Polish+German+English": "pl",
            "Korean": "ko",
            "Korean+English": "ko",
            "Russian": "ru",
            "Russian+English": "ru",
            "Spanish": "es",
            "Spanish+English": "es",
            "Italian": "it",
            "Italian+English": "it",
            "Greek": "gr",
            "Greek+English": "gr",
        }
        name = settings.getString("providers.lang")
        lang = langDict.get(name)
        return lang

    def getTitle(self, title):
        fflog("getTitle")

        title = cleantitle.normalize(title)
        return title

    def getConstants(self, *, ffitem: FFItem) -> None:
        fflog("getConstants")

        self.itemProperty = f"{control.plugin_id}.container.items"
        self.metaProperty = f"{control.plugin_id}.container.meta"
        self.source_mods = scan_source_modules(ffitem=ffitem)
        if not const.dev.sources.force_all_sources:
            self.source_mods = [sm for sm in self.source_mods if settings.getBool(f"provider.{sm.name}")]
        fflog(f"getConstants scan_sources ({len(self.source_mods)})")

        self.host_list = []
        if resolveurl is not None:
            try:
                # wszyskie demeny (hosty) z wszystkich klas resolvera (z pominięciem generycznego '*'), bez duplikatów
                host_list: List[ResolverClass] = resolveurl.relevant_resolvers(order_matters=True)
                self.host_list = list(dict.fromkeys(domain.lower()
                                                    for cls in host_list
                                                    for domain in cls.domains if domain != '*'))
            except Exception:
                fflog_exc()
        # Merge in hosts handled by Kadr+ 2.0's custom resolvers so scrapers
        # see them as supported even if upstream drops or renames the plugin.
        # Toggle: const.sources.local_resolvers.
        if const.sources.local_resolvers:
            try:
                from ..resolvers import get_local_domains
                self.host_list = list(dict.fromkeys(chain(self.host_list, get_local_domains())))
            except Exception:
                fflog_exc()

        self.pr_host_list = [
            "1fichier.com",
            "rapidgator.net",
            "rg.to",
            "filefactory.com",
            "nitroflare.com",
            "turbobit.net",
        ]
        self.hq_host_list = [
            "gvideo",
            "google.com",
        ]
