"""Application defaults. User Trakt keys live only in the encrypted profile store."""
import base64
import json
import zlib
from .bundled_credentials import tmdb_credentials

# Legacy non-Trakt app defaults, obfuscated to avoid accidental log disclosure.
_PAYLOAD = 'c$}+NDk)1zigyg~RI*Y~^73`|x9|z{@QjEsH*<FPQ_@jTN=wX3EGj7}1F4D6POSu~vrMxvF-tX1O*TwTv@}UeOfgNdNHj4vOfgI`GD|WsR;mR6j8qxr'
globals().update(json.loads(zlib.decompress(base64.b85decode(_PAYLOAD)).decode('utf-8')))

tmdb_API, tmdb_bearer = tmdb_credentials()
trakt_API = ''
trakt_secret = ''
