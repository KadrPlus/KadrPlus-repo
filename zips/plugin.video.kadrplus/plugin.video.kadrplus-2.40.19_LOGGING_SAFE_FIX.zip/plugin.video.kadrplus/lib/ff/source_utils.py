# Kadr+ compatibility layer for FanFilm source_utils.
try:
    from ptw.libraries.source_utils import *  # noqa
except Exception:
    pass

try:
    DEFAULT_UA
except NameError:
    DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"

class ShowData(dict):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.__dict__ = self

ShowDataDict = dict

def show_data_asdict(data):
    if data is None:
        return {}
    if isinstance(data, dict):
        return dict(data)
    try:
        return dict(data.__dict__)
    except Exception:
        return {}
