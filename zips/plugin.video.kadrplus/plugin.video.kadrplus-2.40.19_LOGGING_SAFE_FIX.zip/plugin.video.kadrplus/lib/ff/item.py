# Minimal FFItem compatibility for Kadr+ FanFilm scrapers.
class FFItem(dict):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.__dict__ = self

    def get(self, key=None, default=None):
        if key is None:
            return self
        return super().get(key, default)

    @classmethod
    def from_dict(cls, data):
        return cls(data or {})
