# Kadr+ compatibility layer for newer FanFilm scrapers.
try:
    import requests
except Exception:
    requests = None
try:
    from ptw.libraries import cache, cleantitle, control, client, source_utils
except Exception:
    pass
