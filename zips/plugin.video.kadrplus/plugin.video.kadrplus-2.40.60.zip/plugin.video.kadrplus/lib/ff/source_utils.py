# Kadr+ compatibility layer for FanFilm source_utils.
try:
    from ptw.libraries.source_utils import *  # noqa
except Exception:
    pass

try:
    DEFAULT_UA
except NameError:
    DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"

try:
    CHROME_UA
except NameError:
    CHROME_UA = DEFAULT_UA

try:
    FIREFOX_UA
except NameError:
    FIREFOX_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0"

class ShowData(dict):
    def __init__(self, *args, **kwargs):
        # FanFilm sometimes calls ShowData(title, localtitle, aliases, year).
        # dict.__init__ cannot accept that, so map positional values explicitly.
        super().__init__()
        keys = ["title", "localtitle", "aliases", "year", "imdb", "tmdb", "tvdb", "season", "episode"]
        if len(args) == 1 and isinstance(args[0], dict):
            self.update(args[0])
        elif args:
            for key, value in zip(keys, args):
                self[key] = value
        self.update(kwargs)
        # FanFilm scrapers use both localtitle and local_title naming styles.
        if "localtitle" in self and "local_title" not in self:
            self["local_title"] = self.get("localtitle")
        if "local_title" in self and "localtitle" not in self:
            self["localtitle"] = self.get("local_title")
        if "originaltitle" in self and "original_title" not in self:
            self["original_title"] = self.get("originaltitle")
        if "original_title" in self and "originaltitle" not in self:
            self["originaltitle"] = self.get("original_title")
        self.__dict__ = self

ShowDataDict = dict

def show_data_asdict(data):
    if data is None:
        return {}
    if isinstance(data, dict):
        return dict(data)
    try:
        return dict(data.__dict__)
    except Exception:
        return {}
