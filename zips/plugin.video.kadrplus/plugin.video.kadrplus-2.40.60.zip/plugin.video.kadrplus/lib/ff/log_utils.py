# Kadr+ compatibility layer for FanFilm log_utils.
try:
    from ptw.libraries import log_utils as _kadr_log_utils
except Exception:
    _kadr_log_utils = None

def _safe_log(msg, *args, **kwargs):
    try:
        if args:
            try:
                msg = str(msg) % args
            except Exception:
                msg = " ".join([str(msg)] + [str(x) for x in args])
        if _kadr_log_utils and hasattr(_kadr_log_utils, "log"):
            return _kadr_log_utils.log(str(msg), "module")
    except Exception:
        pass
    try:
        print(str(msg))
    except Exception:
        pass

def log(msg, *args, **kwargs):
    return _safe_log(msg, *args, **kwargs)

def fflog(msg, *args, **kwargs):
    return _safe_log(msg, *args, **kwargs)

def fflog_exc(msg="", *args, **kwargs):
    try:
        if _kadr_log_utils and hasattr(_kadr_log_utils, "log_exception"):
            return _kadr_log_utils.log_exception()
    except Exception:
        pass
    return _safe_log(msg or "FanFilm scraper exception", *args, **kwargs)

def error(msg, *args, **kwargs):
    return _safe_log(msg, *args, **kwargs)

def warning(msg, *args, **kwargs):
    return _safe_log(msg, *args, **kwargs)

def info(msg, *args, **kwargs):
    return _safe_log(msg, *args, **kwargs)

def debug(msg, *args, **kwargs):
    return _safe_log(msg, *args, **kwargs)

def log_exception(*args, **kwargs):
    return fflog_exc(*args, **kwargs)

def log_error(*args, **kwargs):
    return fflog_exc(*args, **kwargs)
