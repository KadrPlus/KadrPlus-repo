# Minimal FFItem compatibility for Kadr+ FanFilm scrapers.
class FFItem(dict):
    def __init__(self, *args, **kwargs):
        super().__init__()
        if len(args) == 1 and isinstance(args[0], dict):
            self.update(args[0])
        elif args:
            # Be permissive for FanFilm positional helper calls.
            keys = ["title", "localtitle", "aliases", "year", "imdb", "tmdb", "tvdb", "season", "episode"]
            for key, value in zip(keys, args):
                self[key] = value
        self.update(kwargs)
        self.__dict__ = self

    def get(self, key=None, default=None):
        if key is None:
            return self
        return super().get(key, default)

    @classmethod
    def from_dict(cls, data):
        return cls(data or {})
