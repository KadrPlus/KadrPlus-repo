# -*- coding: UTF-8 -*-
"""
FanFilm - źródło: repozytorium.fn.org.pl (Filmoteka Narodowa)
Copyright (C) 2025 FF Team

Przeniesione z FanFilm Beta i dostosowane do architektury ptw.
Tylko filmy polskie sprzed 1960 roku. Bez logowania, w 100% legalne.
"""

import re
from urllib.parse import quote_plus

import requests as _requests

from ptw.libraries.client import replaceHTMLCodes
from ptw.libraries.log_utils import fflog
from ptw.libraries import title_matcher
from ptw.debug import fflog_exc


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.base_url = "https://repozytorium.fn.org.pl"
        self.search_url = "https://repozytorium.fn.org.pl/?q=pl/search/site/"
        self.headers = {'User-Agent': 'Mozilla/5.0'}
        self.sess = _requests.Session()

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        try:
            # Filtr kraju: tylko filmy polskie (jak beta: 'PL' in getCountryCodes())
            # W ptw nie mamy vtag, ale aliases zawierają country z TMDB (iso_3166_1 lowercase)
            country_codes = {(a.get('country') or '').upper() for a in (aliases or []) if a.get('country')}
            if country_codes and 'PL' not in country_codes:
                return None

            # Tylko filmy sprzed 1960 - serwis zawiera wyłącznie takie
            try:
                if int(year) >= 1960:
                    return None
            except (TypeError, ValueError):
                return None

            search_terms = title_matcher.title_variants(title, localtitle, aliases, max_items=6)
            search_term = search_terms[0] if search_terms else (localtitle or title)
            search_year = int(year)
            url = self.search_url + quote_plus(search_term)

            req = self.sess.get(url, headers=self.headers, timeout=30)
            if req.status_code != 200:
                return None

            pattern = (
                r'<div class="fntile film-tile">.*?'
                r'<a href="(/\?q=pl/node/\d+)">.*?'
                r'<div class="fntile_title">\s*(.*?)\s*</div>'
            )
            matches = re.findall(pattern, req.text, re.DOTALL | re.IGNORECASE)

            search_norm = re.sub(r'[.,!?;:\']', '', search_term.lower())

            for node_url, movie_title in matches:
                movie_title = replaceHTMLCodes(movie_title.strip())
                title_norm = re.sub(r'[.,!?;:\']', '', movie_title.lower())

                if search_norm not in title_norm and title_norm not in search_norm:
                    continue

                film_url = self.base_url + node_url
                film_req = self.sess.get(film_url, headers=self.headers, timeout=30)
                if film_req.status_code == 200:
                    year_match = re.search(
                        r'<div class="fncustom_field[^>]*field_year[^>]*>.*?'
                        r'<span class="fncustom_field_value">(\d{4})</span>',
                        film_req.text, re.DOTALL
                    )
                    if year_match:
                        film_year = int(year_match.group(1))
                        if abs(film_year - search_year) > 1:
                            continue

                fflog(f'[filmoteka] znaleziono: {movie_title}')
                return self.base_url + node_url

            return None

        except Exception:
            fflog_exc(1)
            return None

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        return None

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        return None

    def sources(self, url, hostDict=None, hostprDict=None):
        if not url:
            return []
        try:
            return [{
                'source': 'Filmoteka Narodowa',
                'quality': 'SD',
                'language': 'pl',
                'url': url,
                'info': '',
                'direct': False,
                'debridonly': False,
                'premium': False,
            }]
        except Exception:
            fflog_exc(1)
            return []

    def resolve(self, url):
        try:
            response = self.sess.get(url, headers=self.headers, timeout=30)
            if response.status_code != 200:
                return None
            match = re.search(r'file:\s*encodeURI\(["\']([^"\']+)["\']\)', response.text)
            if match:
                file_url = match.group(1)
                if not file_url.startswith('http'):
                    file_url = self.base_url + '/' + file_url.lstrip('/')
                return file_url
            return None
        except Exception:
            fflog_exc(1)
            return None
