# -*- coding: UTF-8 -*-
import re
from ptw.libraries.client import parseDOM
from ptw.libraries import control, source_utils, cleantitle, utils
from ptw.libraries.log_utils import log, fflog
from ptw.debug import log_exception, fflog_exc
from urllib.parse import quote_plus, urlparse

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        # self.domains = ["zaluknij.cc"]  # nie uzywane nigdzie

        self.search_title = []
        self.base_link =   "https://zaluknij.cc"
        self.search_link = "https://zaluknij.cc/wyszukiwarka?phrase="
        self.useragent =  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0"
        self.headers = {
            'Referer': 'https://zaluknij.cc/',
            # "Host": "zaluknij.cc",
            'user-agent': self.useragent,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
            # "DNT": "1",
            # "Upgrade-Insecure-Requests": "1",
            }

        if UA := control.setting("zaluknijcc.ua").strip().strip('"\''):
            self.headers.update({"User-Agent": UA, "user-agent": UA})
        if accept := control.setting("zaluknijcc.accept").strip().strip('"\''):
            self.headers.update({"Accept": accept})
        if accept_lang := control.setting("zaluknijcc.accept_language").strip().strip('"\''):
            self.headers.update({"Accept-Language": accept_lang})
        if referer := control.setting("zaluknijcc.referer").strip().strip('"\''):
            self.headers.update({"Referer": referer})
        if origin := control.setting("zaluknijcc.origin").strip().strip('"\''):
            self.headers.update({"Origin": origin})
        if extra_headers := control.setting("zaluknijcc.extra_headers").strip().strip('"\''):
            for _line in extra_headers.splitlines():
                if ":" in _line:
                    _k, _v = _line.split(":", 1)
                    if _k.strip() and _v.strip():
                        self.headers.update({_k.strip(): _v.strip()})

            pass

        cookies = ""
        user_cookies = (control.setting("zaluknijcc.cookies_visible") or control.setting("zaluknijcc.cookies")).strip().strip('"\'')
        if user_cookies:
            cookies += "; " + user_cookies
        cf = control.setting("zaluknijcc.cf").strip().strip('"\'')
        cookies += ("; cf_clearance=" + cf) if cf else ""
        cookies = cookies.strip("; ")
        if cookies:
            self.headers.update({'Cookie': cookies})

        self.sess = None


    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        fflog(f'{title=} {localtitle=} {year=} {kwargs=}',0,1)
        year_alt = kwargs.get("year_alt")
        if year_alt:
            year = (year, year_alt)
        return self.search(title, localtitle, year, 'movie', aliases)


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        fflog(f'{tvshowtitle=} {localtvshowtitle=} {year=} {kwargs=} {aliases=}',0,1)
        year2 = None
        year_alt = 0
        year_alt = kwargs.get("year_alt")
        if year_alt:
            year2 = (year, year_alt)
        premiered = kwargs.get("spremiered")  # ma to być data premiery szukanego sezonu
        if premiered:
            year2 = [year, year_alt, premiered]
        if year2:
            year = year2
        return self.search(tvshowtitle, localtvshowtitle, year, 'tvshow', aliases)


    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        fflog(f'{url=} {season=} {episode=} {premiered=} {kwargs=}',0,1)
        absolute_episode = kwargs.get("absolute_episode")
        return self.search_ep(url, season, episode, absolute_episode)


    def search(self, title, localtitle, year, type_, aliases=None):
        fflog(f'{title=} {localtitle=} {year=} {aliases=}',0,0)
        try:
            if not title:
                return

            if not self.sess:
                try:
                    from resources.lib.sources.doh_helper import make_doh_session
                    self.sess = make_doh_session()
                except Exception:
                    import requests, urllib3; urllib3.disable_warnings()
                    self.sess = requests.Session(); self.sess.verify = False

            # przeważnie jest tylko polski tytuł, więc zamianka
            title, localtitle = localtitle, title

            title = title.lower()
            localtitle = localtitle.lower()

            if title == localtitle and aliases:
                # fflog(f'{aliases=}',1,1)
                originalname = [a for a in aliases if "originalname" in a]
                originalname = originalname[0]["originalname"] if originalname else ""
                originalname = "" if source_utils.czy_litery_krzaczki(originalname) else originalname
                if originalname and originalname.lower() != title:
                    title = originalname.lower()
                else:
                    if aliases[0].get("title"):
                        title = aliases[0]["title"].lower()

            # pierwsze szukanie
            url = self.do_search(title, year, type_)

            # kolejne szukanie, jeśli poprzednie nie przyniosło rezultatu
            if not url and localtitle and localtitle != title:
                control.sleep(500)
                url = self.do_search(localtitle, year, type_)

            # i kolejne szukania, jeśli dalej brak wyniku
            title1 = title
            localtitle1 = localtitle
            # '.' na ':'
            if not url and "." in title1:
                title1 = title1.replace(".", ":")
                control.sleep(500)
                url = self.do_search(title1, year, type_, True)
            if not url and "." in localtitle1:
                localtitle1 = localtitle1.replace(".", ":")
                if localtitle1 != title1:
                    control.sleep(500)
                    url = self.do_search(localtitle1, year, type_, True)

            # "–" na "-"  i  '-' na ''
            if not url and any(m in title1 for m in ["–", "-"]):
                title1 = title1.replace("–", "-").replace(" - ", " ")
                control.sleep(500)
                url = self.do_search(title1, year, type_, True)
            if not url and any(m in localtitle1 for m in ["–", "-"]):
                localtitle1 = localtitle1.replace("–", "-").replace(" - ", " ")
                if localtitle1 != title1:
                    control.sleep(500)
                    url = self.do_search(localtitle1, year, type_, True)

            # i kolejne szukania, jeśli dalej brak wyniku
            # '.' na ''
            if not url and "." in title1:
                title1 = title1.replace(".", "")
                control.sleep(500)
                url = self.do_search(title1, year, type_, True)
            if not url and "." in localtitle1:
                localtitle1 = localtitle1.replace(".", "")
                if localtitle1 != title1:
                    control.sleep(500)
                    url = self.do_search(localtitle1, year, type_, True)

            # i kolejne szukania, jeśli dalej brak wyniku
            # ':' na ''
            if not url and ":" in title1:
                title1 = title1.replace(":", "")
                control.sleep(500)
                url = self.do_search(title1, year, type_, True)
            if not url and ":" in localtitle1:
                localtitle1 = localtitle1.replace(":", "")
                if localtitle1 != title1:
                    control.sleep(500)
                    url = self.do_search(localtitle1, year, type_, True)

            # i kolejne szukania, jeśli dalej brak wyniku
            # "'" na ''
            if not url and "'" in title1:
                title1 = title1.replace("'", "")
                control.sleep(500)
                url = self.do_search(title1, year, type_, True)
            if not url and "'" in localtitle1:
                localtitle1 = localtitle1.replace("'", "")
                if localtitle1 != title1:
                    control.sleep(500)
                    url = self.do_search(localtitle1, year, type_, True)

            # i kolejne szukania, jeśli dalej brak wyniku
            # "!" na ''
            if not url and "!" in title1:
                title1 = title1.replace("!", "")
                control.sleep(500)
                url = self.do_search(title1, year, type_, True)
            if not url and "!" in localtitle1:
                localtitle1 = localtitle1.replace("!", "")
                if localtitle1 != title1:
                    control.sleep(500)
                    url = self.do_search(localtitle1, year, type_, True)

            # i kolejne szukania, jeśli dalej brak wyniku
            # "?" na ''
            if not url and "?" in title1:
                title1 = title1.replace("?", "")
                control.sleep(500)
                url = self.do_search(title1, year, type_, True)
            if not url and "?" in localtitle1:
                localtitle1 = localtitle1.replace("?", "")
                if localtitle1 != title1:
                    control.sleep(500)
                    url = self.do_search(localtitle1, year, type_, True)

            # PONIŻSZE MOGĄ DAWAĆ NIEPRAWDZIWE WYNIKI, bo nie jest sprawdzany tytuł
            if not control.settings.getBool("zaluknijcc.validate_full_title"):
                fflog(f'validate_full_title={control.settings.getBool("zaluknijcc.validate_full_title")}')
                # Fix if end of title char makes a search problem
                if not url:
                    title1 = title[:-1]  # czy title1 lepiej ?
                    if len(title1) > 1:
                        control.sleep(500)
                        url = self.do_search(title1, year, type_, False)
                        if url:
                            fflog('Uwaga! znaleziona pozycja może nie być tą, którą chcemy')
                            pass
                if not url and localtitle and localtitle != title:
                    localtitle1 = localtitle[:-1]  # czy localtitle1 lepiej ?
                    if len(localtitle1) > 1:
                        control.sleep(500)
                        url = self.do_search(localtitle1, year, type_, False)
                        if url:
                            fflog('Uwaga! znaleziona pozycja może nie być tą, którą chcemy')
                            pass

                # Search title phrase before ':'
                if not url and ":" in title:
                    split_title = title.split(":")[0]
                    control.sleep(500)
                    url = self.do_search(split_title, year, type_, False)
                    if url:
                        fflog('Uwaga! znaleziona pozycja może nie być tą, którą chcemy')
                        pass
                if not url and ":" in localtitle and localtitle != title:
                    split_title = localtitle.split(":")[0]
                    control.sleep(500)
                    url = self.do_search(split_title, year, type_, False)
                    if url:
                        fflog('Uwaga! znaleziona pozycja może nie być tą, którą chcemy')
                        pass

                # Search title phrase before '.'
                if not url and "." in title:
                    split_title = title.split(".")[0]
                    control.sleep(500)
                    url = self.do_search(split_title, year, type_, False)
                    if url:
                        fflog('Uwaga! znaleziona pozycja może nie być tą, którą chcemy')
                        pass
                if not url and "." in localtitle and localtitle != title:
                    split_title = localtitle.split(".")[0]
                    control.sleep(500)
                    url = self.do_search(split_title, year, type_, False)
                    if url:
                        fflog('Uwaga! znaleziona pozycja może nie być tą, którą chcemy')
                        pass

            fflog(f'{url=}',1,1)
            return url
        except Exception:
            #log_exception(1)
            fflog_exc(1)
            pass


    def do_search(self, title, year, type_, validate_full_title=True):
        # print("[ZaluknijCC.py] search_title: ", title)

        # title = title.lower()
        if title in self.search_title:
            # fflog(f"search_title: {title=} has already been searched")
            return
        else:
            self.search_title.append(title)

        fflog(f"search_title: {title=}  {type_=}  {year=}  {validate_full_title=}")

        if not title:
            return

        fout = []
        sout = []
        results = []
        out_url = []

        search_url = f'{self.search_link}{quote_plus(title)}'
        # fflog(f'{search_url=}')

        req = self.sess.get(search_url, headers=self.headers, timeout=7, verify=False)
        if req is None:
            req_status = 0
        else:
            req_status = req.status_code

        if not req or req_status != 200:
            msg = f'Odpowiedź z serwera: {req_status}'
            fflog(msg)
            if not control.window.getProperty("blocked_sources_extend") == 'break':
                control.infoDialog(msg, 'Zaluknij', "WARNING")
            if req_status in (403, 429, 503):
                fflog('[zaluknijcc] Cloudflare/403 active - skipped safely')
                return

        html = req.text

        links = parseDOM(html, 'div', attrs={'id': 'advanced-search'})
        if links:
            links = links[0]
        else:
            if "<body" not in html:
                fflog(f'{html=}', 1)
            else:
                fflog('wystąpił jakiś problem')
                fflog(f'{html=}', 0)               
            # html='Database connection could not be established.'  # też trafiłem na taki komunikat
            return

        links = parseDOM(links, 'div', attrs={'class': r'col-sm-\d+'})
        # fflog(f'{len(links)=}')

        for link in links:
            # fflog(f'{link=}')
            if 'href' in link:
                href  = parseDOM(link, 'a', ret='href')[0]
                tytul = parseDOM(link, 'div', attrs={'class': 'title'})[0]
                tytul = tytul.replace(" (Edycja kolorowa)", "")
                # fflog(f'{tytul=} {href=}')

                if not validate_full_title or re.search(f'( / |^){re.escape(title)}( / |$)', tytul.lower()):
                    # fflog(f'dołączam {tytul=} {href=}') if validate_full_title else ""
                    if 'serial-online' in href or 'seasons' in href:
                        sout.append({'title': tytul, 'url': href})
                    else:
                        fout.append({'title': tytul, 'url': href})

        if type_ == 'movie':
            results = fout
        elif type_ == 'tvshow':
            results = sout
        # fflog(f'{len(results)=}  {results=}',1,1)

        if not results:
            return

        results.sort(key=lambda k: len(k['title']), reverse=True)  # najdłuższe tytuły na początek listy?
        # fflog(f'{len(results)=}')

        if year:
            year_alt = 0
            premiered = 0
            # fflog(f'{year=}')
            # if isinstance(year, tuple):
            if isinstance(year, (tuple, list)):
                if len(year) == 3:
                    year, year_alt, premiered = year
                    premiered = re.findall(r"\d{4}", premiered)
                    premiered = int(premiered[0]) if premiered else 0
                else:
                    year, year_alt = year
                year_alt = int(year_alt) if year_alt else 0
            # fflog(f'{year=}')
            year = int(year)
            if year_alt:
                years = [year, year_alt]
            else:
                years = [year]
            if premiered:
                years += [premiered]
            if type_ == 'movie':  # czy dla seriali też trzeba ?
                years += [year-1]
                years += [year+1]  # jak premiera w Polsce jest w następnym roku niż światowa, to ten serwis podaje rok w Polsce
            if type_ == 'tvshow':
                years += [year+1]
                # years += [year-1]  # jeszcze nie trafiłem
        years = list(dict.fromkeys(years))  # pozbycie się duplikatów
        # fflog(f'{years=}')

        date = "0"

        for url in results:
            if type_ == 'movie':
                date = str(url['url'])[-4:]  # znaleziona data w adresie url
                # fflog(f"w url'u  {date=}")
            elif type_ == 'tvshow':
                control.sleep(500)
                html = self.sess.get(url['url'], headers=self.headers, timeout=7, verify=False)
                if not html:
                    fflog(f'{html=}')
                    continue
                html = html.text
                try:
                    date = parseDOM(html, 'div', attrs={'class': 'info'})
                    date = (parseDOM(date, 'li')[-1:])[0]
                except:
                    date = "0"
            # fflog(f'{year=} {date=}')
            if year and date.isnumeric() and int(date):
                #if int(date) == int(year):
                if int(date) in years:
                    fflog(f'pasuje {url=}')
                    # out_url = url['url']
                    # out_url.append(url['url'])
                    out_url.append(url)
                    if type_ == 'movie':
                        break
                else:
                    fflog(f'odrzucone z powodu braku dopasowania daty i roku  {date=}  dla  {url=}')
            else:
                fflog(f'problem, bo brak roku')
                # out_url = url['url']
                out_url = url
                break

        # fflog(f'{len(out_url)=}  {out_url=}') if out_url else ""
        out_url = [out_url] if not isinstance(out_url, list) else out_url
        # fflog(f'{len(out_url)=}  {out_url=}',1,1)
        out = []
        if out_url:
            for url in out_url:
                # fflog(f'sprawdzam jeszcze {url=}')
                if (url and (
                             not validate_full_title
                             or year and date.isnumeric() and int(date) and year != int(date)
                             or True  # a może zawsze warto?
                            )
                    ):
                    tytul = url['title']
                    # fflog(f'{tytul=}',1,1)
                    if date.isnumeric() and int(date):
                        tytul += f" ({date})"
                    # fflog(f'{url=}',1,1)
                    # return (out_url, tytul)
                    if type_ == 'movie':
                        return ( url['url'], tytul)
                    out.append( (url['url'], tytul) )
        # fflog(f'{len(out)=}  {out=}',1,1)

        if out:
            # out.sort(key=lambda k: len(k[1]), reverse=False)
            import json  # do debugu
            out2 = []
            for o in out:
                for t in o[1].split("/"):
                    primary_words, ratio_primary, levenshtein_primary = self._calculate_similarity(t, title)
                    fflog(f'{primary_words=}  {ratio_primary=}  {levenshtein_primary=}  {o=}  {t=}  {title=}',0,1)
                    o2 = list(o)
                    o2.append({"ratio": ratio_primary, "levenshtein": levenshtein_primary})
                    o2 = tuple(o2)
                    out2.append(o2)
            # fflog(f'{len(out2)=}  out2={json.dumps(out2, indent=2)}',1,1)
            # out2 = sorted(out2, key=lambda x: (x[2]["ratio"], -x[2]["levenshtein"]), reverse=True)  # najlepiej dopasowane na początek
            out2.sort(key=lambda x: (-x[2]["levenshtein"], x[2]["ratio"], ), reverse=True)  # najlepiej dopasowane na początek
            # fflog(f'{len(out2)=}  out2={json.dumps(out2, indent=2)}',1,1)
            out = out2
            out = [o for i, o in enumerate(out) if o[0] not in [x[0] for x in out[:i]]]
            fflog(f'{len(out)=}  out={json.dumps(out, indent=2)}  \n{out=}',0,1)
        return out


    def search_ep(self, urls, season, episode, absolute_episode=0):
        # fflog(f'{urls=} {season=} {episode=} {absolute_episode=}',1,1)

        if not self.sess:
            try:
                from resources.lib.sources.doh_helper import make_doh_session
                self.sess = make_doh_session()
            except Exception:
                import requests, urllib3; urllib3.disable_warnings()
                self.sess = requests.Session(); self.sess.verify = False

        if not isinstance(urls, list):
            urls = [urls]

        for url in urls:
            # fflog(f'{url=}',1,1)

            if isinstance(url, tuple):
                info2 = url[1]
                url = url[0]
            else:
                info2 = ''

            if not url:
                # return
                continue

            html = self.sess.get(url, headers=self.headers, timeout=7, verify=False)

            if html.status_code != 200:
                fflog(f'otrzymano niestandardowy kod odpowiedzi z serwera: {html.status_code}')
                if html.status_code == 403:
                    fflog(f'prawdopodobnie włączona weryfikacja cloudflare',1,1)
                    # fflog(f'{req.text=}')
                    return

            html = html.text

            sesres = parseDOM(html, 'ul', attrs={'id': 'episode-list'})
            if sesres:
                sesres = sesres[0]
            else:
                fflog(f'{sesres=}',1,1)
                # return
                continue

            sezony = re.findall(r'(<span>.*?</ul>)', sesres, re.DOTALL)
            # fflog(f'{sezony=}',1,1)

            episode_url = ''
            should_break = False
            # fflog(f'{len(sezony)=}',1,1)
            for sezon in sezony:
                if should_break:
                    break
                sesx = parseDOM(sezon, 'span')
                ses = ''
                if sesx:
                    mch = re.search(r'(\d+)', sesx[0], re.DOTALL)
                    ses = mch[1] if mch else '0'
                eps = parseDOM(sezon, 'li')
                # fflog(f'{len(eps)=}',1,1)
                for ep in eps:
                    href = parseDOM(ep, 'a', ret='href')[0]
                    tyt2 = parseDOM(ep, 'a')[0]
                    epis = re.findall(r's\d+e(\d+)', tyt2)[0]
                    # fflog(f'{ses=} {season=} {epis=} {episode=}',1,1)
                    if (   int(ses) == int(season) and int(epis) == int(episode)
                        or int(ses) == 1 and int(epis) == absolute_episode
                        # or int(epis) == absolute_episode  # and int(ses) == int(season)  # z pewnych względów warto nie w tym miejscu
                        ):
                        fflog(f'1 pasuje  {href=}  {ses=} {epis=}',0,1)
                        episode_url = href
                        info2 += f"  [s{ses:0>2} e{epis}]"
                        should_break = True
                        break
                if not should_break and absolute_episode and int(season) > 1:
                    for ep in eps:
                        href = parseDOM(ep, 'a', ret='href')[0]
                        tyt2 = parseDOM(ep, 'a')[0]
                        epis = re.findall(r's\d+e(\d+)', tyt2)[0]
                        # fflog(f'{ses=} {season=} {epis=} {episode=}',1,1)
                        if (
                            int(epis) == absolute_episode and int(ses) == int(season)  # takie dziwne dla tego serwisu
                            ):
                            fflog(f'2 pasuje  {href=}  {ses=} {epis=}',0,1)
                            episode_url = href
                            info2 += f"  [s{ses:0>2} e{epis}]"
                            should_break = True
                            break
            fflog(f'{episode_url=} {info2=}',1,1)
            if episode_url:
                if info2:
                    return (episode_url, info2.strip())
                else:
                    return episode_url


    def sources(self, url, hostDict, hostprDict):
        fflog(f'{url=}',0,1)
        sources = []
        if not url:
            fflog('brak źródeł do przekazania')
            return sources
        if not self.sess:
            try:
                from resources.lib.sources.doh_helper import make_doh_session
                self.sess = make_doh_session()
            except Exception:
                import requests, urllib3; urllib3.disable_warnings()
                self.sess = requests.Session(); self.sess.verify = False
        info2 = ''
        if isinstance(url, tuple):
            # fflog(f'{url=}')
            info2 = url[1]
            url = url[0]
        if not url:
            fflog('brak źródeł do przekazania')
            return sources
        out = []
        # fflog(f'{url=}')
        control.sleep(500)
        try:
            html = self.sess.get(url, headers=self.headers, timeout=7, verify=False)
        except Exception:
            fflog_exc(1)
            html = None
            pass
        if not html:
            fflog(f'{html=}  {url=}')
            return sources
        new_variant = False
        html = html.text
        result = parseDOM(html, 'tbody')
        if not result:
            # result = parseDOM(html, 'div', attrs={'id': 'item-info'})
            result = parseDOM(html, 'div', attrs={'class': r'row g-\d+'})
            new_variant = True
        # fflog(f'{result=}')
        if result:
            result = result[0]
            if not new_variant:
                videos = parseDOM(result, 'tr')
            else:
            # if not videos:
                videos = parseDOM(result, 'div', attrs={'class': 'video-card link-to-video'})
            # fflog(f'{len(videos)=}  {videos=}')
            for vid in videos:
                # fflog(f'{vid=}')
                if not new_variant:
                    hosthrefquallang = re.findall(r'href\s*=\s*"([^"]+).*?<td>([^<]+).*?<td>([^<]+)', vid, re.DOTALL)
                    # fflog(f'{len(hosthrefquallang)=} {hosthrefquallang=}')
                    if hosthrefquallang:  # len(hosthrefquallang)=1
                        for href, lang, qual in hosthrefquallang:
                            host = urlparse(href).netloc
                            out.append({
                                'href': href,
                                'host': host,
                                'lang': lang,
                                'qual': qual,
                                })
                else:
                    try:
                        href = parseDOM(vid, 'a', attrs={'class': 'stretched-link'}, ret='href')[0]
                        # host = parseDOM(vid, 'strong')[0]
                        lang = parseDOM(vid, 'span', attrs={'class': 'badge badge-version'})[0]
                        qual = ''
                        host = urlparse(href).netloc
                        out.append({
                            'href': href,
                            'host': host,
                            'lang': lang,
                            'qual': qual,
                            })
                    except Exception:
                        fflog_exc(1)
                        pass
            if out:
                for x in out:
                    if (link := x.get('href')):
                        if any(link == s["url"] for s in sources):
                            fflog(f'dubel {link=}',0)
                            continue
                        host = (x.get('host') or "").rsplit(".", 1)[0].rsplit(".", 1)[-1]
                        lang = x.get('lang')
                        qual = x.get('qual').lower()
                        sources.append({
                                        'source': host,
                                        'quality': '720p' if qual=='wysoka' else 'CAM' if qual=='niska' else 'SD',
                                        'language': 'pl',
                                        'url': link,
                                        'info': lang,
                                        'direct': False,
                                        'debridonly': False,
                                        'info2': info2,
                                        })
                    else:
                        fflog(f'{link=}')
                        pass
            else:
                fflog(f'{len(out)=}  {out=}')
                pass
        else:
            fflog(f'{result=}')
            pass
        fflog(f'przekazano źródeł: {len(sources)}')
        # import json
        # fflog(f'sources={json.dumps(sources, indent=2)}',1,1)
        return sources


    def resolve(self, url):
        link = str(url).replace('\\/', '/')
        link = link.replace("//", "/").replace(":/", "://")
        fflog(f'{link=}')
        return link


    def _calculate_similarity(self, tvshow_title, search_title):
        search_title = cleantitle.normalize(search_title)
        primary_words = cleantitle.normalize(tvshow_title.strip().lower())
        ratio_primary = utils.calculate_similarity_ratio(search_title, primary_words)
        levenshtein_primary = utils.calculate_levenshtein_distance(search_title, primary_words)
        return primary_words, ratio_primary, levenshtein_primary
