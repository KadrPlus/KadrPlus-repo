# -*- coding: UTF-8 -*-
"""
    Scraper dla MegaKino1.watch
    
    Cloudflare blokuje GET /films/ i /serials/ dla requests.
    Obejście: POST /engine/ajax/controller.php z mod=showfull&id=NEWS_ID
    lub POST /index.php?do=cat z newsid — DLE wewnętrzne endpointy
    które nie przechodzą przez CF routing.
    
    ID tytułu pobieramy z wyników wyszukiwania POST /index.php (działa).
"""
import re
from html import unescape
from urllib.parse import urlencode, quote_plus, unquote_plus, urljoin

from ptw.libraries import control, source_utils, cleantitle, title_matcher
from ptw.debug import fflog, fflog_exc


class source:
    def __init__(self):
        self.priority  = 1
        self.language  = ['de']
        self.base_link = (control.setting('megakino.base') or 'https://megakino4.to').strip().rstrip('/')
        # Kadr+ 2.40.54: aktualna publiczna domena MegaKino to megakino4.to.
        # Stare zapisane ustawienia megakino3.org/megakino1.* potrafią zwracać stronę listy
        # zamiast strony szczegółów, przez co seriale nie mają hostów.
        _old_domains = ('megakino3.org', 'megakino1.', 'megakino2.', 'megakino.to')
        if any(x in self.base_link for x in _old_domains):
            self.base_link = 'https://megakino4.to'
        if not self.base_link.startswith('http'):
            self.base_link = 'https://' + self.base_link
        self.headers   = {
            'User-Agent':    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0',
            'Accept':        'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'de-DE,de;q=0.9,en;q=0.3',
        }
        self.session   = None
        self._cache    = {}

    # ------------------------------------------------------------------

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        fflog(f'[megakino] film: {title=}  {year=}  {imdb=}', 1)
        year_alt = kwargs.get('year_alt')
        if year_alt: year = (year, year_alt)
        url = self._search(title, localtitle, aliases, year, 'film')
        fflog(f'[megakino] film url: {url}', 1)
        return url

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        fflog(f'[megakino] serial: {tvshowtitle=}  {year=}', 1)
        year_alt = kwargs.get('year_alt')
        if year_alt: year = (year, year_alt)
        url = self._search(tvshowtitle, localtvshowtitle, aliases, year, 'serial')
        if url:
            # Kadr+ 2.40.48: Megakino ma często osobne strony dla sezonów
            # (np. Cobra Kai - Staffel 2), więc przechowujemy dane serialu,
            # żeby episode() mogło znaleźć właściwą stronę sezonu.
            meta = []
            if tvshowtitle: meta.append('show=' + quote_plus(str(tvshowtitle)))
            if localtvshowtitle: meta.append('local=' + quote_plus(str(localtvshowtitle)))
            if year: meta.append('year=' + quote_plus(str(year)))
            if meta:
                url = url + '|KADR|' + '|'.join(meta)
        fflog(f'[megakino] serial url: {url}', 1)
        return url

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        fflog(f'[megakino] episode {url=}  {season=}  {episode=}', 1)
        if not url: return None
        base_url, meta = self._split_meta(url)
        try:
            # Megakino publikuje wiele seriali jako oddzielne wpisy sezonów.
            # Dla S02E02 szukamy więc najpierw strony typu "Cobra Kai Staffel 2",
            # zamiast używać ogólnego wpisu serialu, gdzie ep2 może oznaczać zły sezon.
            show = meta.get('show') or meta.get('local') or ''
            local = meta.get('local') or show
            year = meta.get('year') or None
            season_url = self._search_season_page(show, local, year, int(season), base_url)
            if season_url:
                base_url = season_url
        except Exception:
            fflog_exc(1)
        return f'{base_url}#S{season}E{episode}'

    def sources(self, url, hostDict, hostprDict):
        result = []
        fflog(f'[megakino] sources {url=}', 1)
        if not url: return result
        try:
            self._init_session()
            season = episode = None
            url, _meta = self._split_meta(url)
            m = re.search(r'#S(\d+)E(\d+)$', url)
            if m:
                season  = int(m.group(1))
                episode = int(m.group(2))
                url     = url[:m.start()]

            # ID z URL: Megakino używa różnych kategorii:
            # /serials/92-cobra-kai.html, ale sezony są często pod /drama/4005-cobra-kai-staffel-1.html
            # albo /action/4373-cobra-kai-staffel-6.html. Dlatego nie ograniczamy się do films/serials.
            id_m = re.search(r'/(?:[a-z0-9_-]+)/(\d+)-', url, re.I)
            if not id_m:
                fflog(f'[megakino] nie mozna wyciagnac ID z {url}', 1)
                return result
            news_id = id_m.group(1)
            fflog(f'[megakino] news_id={news_id}  season={season}  episode={episode}', 1)

            html = self._fetch_by_id(news_id, url)
            if not html:
                return result

            fflog(f'[megakino] html len={len(html)}', 1)
            links = self._extract_links(html, season, episode, news_id=news_id, referer=url)
            fflog(f'[megakino] linków: {len(links)}', 1)

            for item in links:
                link = item.get('url', '')
                if not link: continue
                valid, hoster = source_utils.is_host_valid(link, hostDict)
                if not valid:
                    valid, hoster = source_utils.is_host_valid(link, hostprDict)
                if not valid:
                    from urllib.parse import urlsplit
                    hoster = urlsplit(link).hostname or link
                result.append({
                    'source': hoster, 'quality': item.get('quality', 'HD'),
                    'language': 'de', 'url': link,
                    'info': item.get('info', ''), 'direct': False, 'debridonly': False,
                })
        except Exception:
            fflog_exc(1)
        fflog(f'[megakino] zwracam {len(result)} zrodel', 1)
        return result

    def resolve(self, url):
        return url

    # ------------------------------------------------------------------

    def _is_valid_detail_html(self, html, news_id=None, original_url=None):
        # Kadr+ 2.40.55: walidacja strony szczegółów MegaKino.
        try:
            if not html or len(html) < 500:
                return False
            low = html.lower()
            if any(x in low[:5000] for x in ('seite nicht gefunden', 'not found')):
                return False
            if news_id and (str(news_id) in low or ('newsid=%s' % news_id) in low):
                return True
            if original_url:
                m = re.search(r'/(\d+)-([^/]+?)\.html', original_url, re.I)
                if m:
                    slug = m.group(2).replace('-', ' ').lower()
                    words = [w for w in re.split(r'\W+', slug) if len(w) > 2]
                    if words and sum(1 for w in words[:6] if w in low) >= max(1, min(3, len(words))):
                        return True
            if self._has_content(html):
                return True
            if re.search(r'<h[12][^>]*>\s*[^<]{2,160}', html, re.I):
                return True
        except Exception:
            pass
        return False

    def _normalize_hoster_url(self, url):
        try:
            url = (url or '').strip()
            if not url:
                return ''
            url = url.replace('\\/', '/')
            if url.startswith('//'):
                url = 'https:' + url
            if url.startswith('/'):
                return ''
            if not url.startswith('http'):
                return ''
            bad_hosts = ('megakino', 'youtube.com', 'youtu.be', 'schema.org', 'example.', 'cvt-', 'google', 'facebook', 'twitter')
            if any(x in url.lower() for x in bad_hosts):
                return ''
            return url
        except Exception:
            return ''


    def _strip_html(self, text):
        try:
            text = re.sub(r'<[^>]+>', ' ', text or '')
            text = unescape(text)
            text = re.sub(r'\s+', ' ', text).strip()
            return text
        except Exception:
            return text or ''

    def _resolve_internal_value(self, value, referer=None):
        """
        Megakino sometimes stores hoster options as an internal AJAX/relative URL.
        Resolve it once and extract external hoster links from the returned HTML/JSON.
        """
        links = []
        seen = set()
        try:
            value = (value or '').strip().replace('\\/', '/')
            if not value:
                return links
            if value.startswith('//'):
                value = 'https:' + value
            if value.startswith('/'):
                value = self.base_link + value
            if not value.startswith('http'):
                # Some DLE snippets store path without leading slash.
                if value.startswith('engine/') or value.startswith('index.php'):
                    value = self.base_link + '/' + value
                else:
                    return links
            if 'megakino' not in value:
                self._add_hoster_link(links, seen, value)
                return links
            headers = dict(self.headers)
            headers['Referer'] = referer or self.base_link + '/'
            headers['X-Requested-With'] = 'XMLHttpRequest'
            r = self.session.get(value, headers=headers, timeout=(8, 12), allow_redirects=True)
            txt = r.text or ''
            fflog(f'[megakino] internal hoster GET status={r.status_code} len={len(txt)} url={value[:80]}', 1)
            # JSON / HTML / JS values
            for m in re.finditer(r"https?:\\?/\\?/[^'\"<>\\s]+", txt, re.I):
                self._add_hoster_link(links, seen, m.group(0))
            for m in re.finditer(r"(?:url|link|file|src|iframe)\s*[:=]\s*['\"]([^'\"]+)['\"]", txt, re.I):
                self._add_hoster_link(links, seen, m.group(1))
            for m in re.finditer(r"(?:data-url|data-link|data-src|href|src)=['\"]([^'\"]+)['\"]", txt, re.I):
                self._add_hoster_link(links, seen, m.group(1))
        except Exception:
            fflog_exc(1)
        return links

    def _add_hoster_link(self, links, seen, url, label='Hoster'):
        url = self._normalize_hoster_url(url)
        if not url or url in seen:
            return
        seen.add(url)
        try:
            host_m = re.search(r'https?://(?:www\.)?([^/]+)', url, re.I)
            host = host_m.group(1).split('.')[0].capitalize() if host_m else label
        except Exception:
            host = label or 'Hoster'
        links.append({'url': url, 'quality': self._quality((label or '') + ' ' + url), 'info': f'DE | {host}'})
        fflog(f'[megakino]   host link: {host} {url[:70]}', 1)

    def _links_from_episode_context(self, html, ep_id, seen):
        links = []
        try:
            if not html or not ep_id:
                return links
            positions = [m.start() for m in re.finditer(re.escape(str(ep_id)), html, re.I)]
            if not positions:
                return links
            for pos in positions[:4]:
                block = html[max(0, pos - 5000):pos + 12000]
                for sm in re.finditer(r'<select[^>]*>(.*?)</select>', block, re.S|re.I):
                    links.extend(self._options_from_block(sm.group(1), seen))
                for m in re.finditer(r"(?:data-url|data-link|data-src|href|src)=['\"](https?://[^'\"]+)['\"]", block, re.I):
                    self._add_hoster_link(links, seen, m.group(1))
                for m in re.finditer(r"https?://[^'\"<>\s]+", block, re.I):
                    self._add_hoster_link(links, seen, m.group(0))
            return links
        except Exception:
            fflog_exc(1)
            return links

    def _all_hoster_links(self, html, seen):
        links = []
        try:
            if not html:
                return links
            for sm in re.finditer(r'<select[^>]*>(.*?)</select>', html, re.S|re.I):
                links.extend(self._options_from_block(sm.group(1), seen))
            for m in re.finditer(r"(?:data-url|data-link|data-src|href|src)=['\"](https?://[^'\"]+)['\"]", html, re.I):
                self._add_hoster_link(links, seen, m.group(1))
            for m in re.finditer(r"https?://[^'\"<>\s]+", html, re.I):
                self._add_hoster_link(links, seen, m.group(0))
        except Exception:
            fflog_exc(1)
        return links

    # ------------------------------------------------------------------

    def _fetch_by_id(self, news_id, original_url):
        """
        Próbuje pobrać HTML strony tytułu kilkoma metodami — od najmniej
        do najbardziej kosztownej. Cloudflare chroni GET /films/ i /serials/
        ale DLE ma endpointy AJAX które mogą nie być objęte CF.
        """
        # Metoda 1: GET konkretnej strony szczegółów. To jest najpewniejsze dla megakino4.to.
        html = self._try_direct_get(original_url, news_id=news_id)
        if html and len(html) > 1000 and self._is_valid_detail_html(html, news_id, original_url) and self._has_content(html):
            fflog('[megakino] metoda 1 (direct detail GET) OK', 1)
            return html

        # Metoda 2: DLE controller AJAX showfull
        html = self._try_ajax_showfull(news_id)
        if html and len(html) > 1000 and self._has_content(html):
            fflog('[megakino] metoda 2 (ajax showfull) OK', 1)
            return html

        # Metoda 3: GET przez /index.php?newsid=ID (DLE shortlink)
        html = self._try_newsid(news_id)
        if html and len(html) > 1000 and self._has_content(html):
            fflog('[megakino] metoda 3 (newsid) OK', 1)
            return html

        fflog(f'[megakino] wszystkie metody zawiodly dla id={news_id}', 1)
        return None

    def _has_content(self, html):
        # Sprawdza czy HTML wygląda jak strona tytułu z odtwarzaczami/odcinkami.
        if not html:
            return False
        h = html.lower()
        if 'mr-select' in h or 'se-select' in h or 'episode' in h:
            return True
        if any(x in h for x in ('voe.sx', 'veev.to', 'vidmoly', 'dood.', 'vidsonic', 'vidara', 'filemoon', 'streamtape')):
            return True
        if re.search(r'<iframe[^>]+(?:data-src|src)=["\']https?://', html, re.I):
            return True
        if re.search(r'(?:data-url|data-link|href|src)=["\']https?://', html, re.I):
            return True
        return False

    def _try_ajax_showfull(self, news_id):
        """POST /engine/ajax/controller.php?mod=showfull — DLE internal"""
        try:
            url = self.base_link + '/engine/ajax/controller.php'
            data = urlencode({'mod': 'showfull', 'id': news_id})
            headers = dict(self.headers)
            headers['Content-Type'] = 'application/x-www-form-urlencoded'
            headers['X-Requested-With'] = 'XMLHttpRequest'
            headers['Referer'] = self.base_link + '/'
            fflog(f'[megakino] ajax showfull id={news_id}', 1)
            r = self.session.post(url, data=data, headers=headers, timeout=(10, 20))
            fflog(f'[megakino] ajax showfull status={r.status_code} len={len(r.text)}', 1)
            if r.status_code == 200:
                return r.text
        except Exception:
            fflog_exc(1)
        return None

    def _try_direct_get(self, url, news_id=None):
        """GET z krokiem weryfikacji yg_token (jak fetch w JS)"""
        cache_key = f'get:{url}'
        if cache_key in self._cache:
            return self._cache[cache_key]
        try:
            headers = dict(self.headers)
            headers['Referer'] = self.base_link + '/'
            # Krok 1: weryfikacja - jak JS fetch("/index.php?yg=token", {credentials:"include"})
            # fetch używa XHR headers, nie nawigacyjnych
            verify_headers = dict(self.headers)
            verify_headers['Referer'] = url  # Referer = strona którą chcemy otworzyć
            verify_headers['X-Requested-With'] = 'XMLHttpRequest'
            fflog('[megakino] yg token verify', 1)
            rv = self.session.get(self.base_link + '/index.php?yg=token',
                                  headers=verify_headers, timeout=(10, 15))
            fflog(f'[megakino] yg verify status={rv.status_code}', 1)
            # Pobierz nowy yg_token z odpowiedzi jeśli serwer go odświeżył
            new_yg = rv.cookies.get('yg_token')
            if new_yg:
                self.session.cookies.set('yg_token', new_yg)
                fflog(f'[megakino] nowy yg_token z verify: {new_yg[:20]}...', 1)
            # Krok 2: GET strony tytułu z Referer = strona główna
            fflog(f'[megakino] direct GET {url}', 1)
            r = self.session.get(url, headers=headers, timeout=(10, 18), allow_redirects=True)
            fflog(f'[megakino] direct GET status={r.status_code} len={len(r.text)} final={r.url}', 1)
            if len(r.text) < 500:
                fflog(f'[megakino] body: {repr(r.text[:300])}', 1)
            # Jeżeli serwer zrzucił nas na kategorię/listę, nie akceptuj tego jako strony tytułu.
            try:
                if news_id and ('/%s-' % news_id) not in r.url:
                    if not self._is_valid_detail_html(r.text, news_id, url):
                        fflog(f'[megakino] direct GET rejected: final URL/page mismatch for id={news_id}', 1)
                        return None
            except Exception:
                pass
            self._cache[cache_key] = r.text
            return r.text
        except Exception:
            fflog_exc(1)
        return None

    def _try_newsid(self, news_id):
        """GET /index.php?newsid=ID — DLE shortlink redirect"""
        try:
            url = f'{self.base_link}/index.php?newsid={news_id}'
            headers = dict(self.headers)
            headers['Referer'] = self.base_link + '/'
            fflog(f'[megakino] newsid GET {url}', 1)
            r = self.session.get(url, headers=headers, timeout=(15, 30),
                                 allow_redirects=True)
            fflog(f'[megakino] newsid status={r.status_code} len={len(r.text)} final={r.url}', 1)
            if r.status_code == 200:
                return r.text
        except Exception:
            fflog_exc(1)
        return None

    # ------------------------------------------------------------------

    def _search(self, title, localtitle, aliases, year, content):
        try:
            self._init_session()
            year_int = year_alt_int = None
            if isinstance(year, (tuple, list)):
                try: year_int     = int(year[0])
                except: pass
                try: year_alt_int = int(year[1])
                except: pass
            else:
                try: year_int = int(year)
                except: pass

            # DE aliasy priorityzujemy (megakino = strona niemiecka)
            de_aliases, other_aliases = [], []
            if aliases:
                try:
                    import json
                    if isinstance(aliases, str): aliases = json.loads(aliases)
                    raw = list(aliases.values()) if isinstance(aliases, dict) else list(aliases)
                    for a in raw:
                        t_str = country = ''
                        if isinstance(a, str):
                            t_str = a
                        elif isinstance(a, dict):
                            t_str = a.get('title') or a.get('name') or ''
                            country = a.get('country', '')
                        if not t_str or t_str.lower() == title.lower():
                            continue
                        if country in ('de', 'at', 'ch'):
                            de_aliases.append(t_str)
                        else:
                            other_aliases.append(t_str)
                except Exception: pass
            # Megakino = serwis DE. W praktyce filmy są w wielu kategoriach,
            # a seriale/sezony często mają osobne wpisy typu "Cobra Kai - Staffel 2".
            # Szukamy kilkoma wariantami i dopiero potem wybieramy najlepszy wynik globalnie.
            alias_objs = []
            for a in de_aliases:
                alias_objs.append({'title': a})
            titles = title_matcher.title_variants(title, localtitle, alias_objs, max_items=10)
            if not titles:
                titles = [title or localtitle]

            all_results = []
            seen_urls = set()
            for t in titles[:6]:
                html = self._post_search(t)
                if not html: continue
                results = self._parse_results(html, content)
                fflog(f'[megakino] wynikow ({content}): {len(results)} dla {t!r}', 1)
                for r in results:
                    u = r.get('url')
                    if u and u not in seen_urls:
                        seen_urls.add(u)
                        all_results.append(r)

            match = self._best_match(all_results, titles, year_int, year_alt_int, content)
            if match:
                return match
        except Exception:
            fflog_exc(1)
        return None

    def _split_meta(self, url):
        meta = {}
        if not url or '|KADR|' not in url:
            return url, meta
        base, tail = url.split('|KADR|', 1)
        for part in tail.split('|'):
            if '=' in part:
                k, v = part.split('=', 1)
                try:
                    meta[k] = unquote_plus(v)
                except Exception:
                    meta[k] = v
        return base, meta

    def _season_token_match(self, text, season):
        text = (text or '').lower()
        try:
            s = int(season)
        except Exception:
            return False
        pats = [
            r'\bstaffel\D*%d\b' % s,
            r'\bseason\D*%d\b' % s,
            r'\b%d\D*staffel\b' % s,
            r'\b%d\D*season\b' % s,
            r'\bs%02d\b' % s,
            r'\bs%d\b' % s,
            r'staffel-%d' % s,
            r'season-%d' % s,
        ]
        return any(re.search(p, text, re.I) for p in pats)

    def _base_title_match(self, candidate, show):
        cand = re.sub(r'\b(staffel|season)\D*\d+\b|\b\d+\D*(staffel|season)\b|\bs\d{1,2}\b', ' ', str(candidate or ''), flags=re.I)
        sh = re.sub(r'\b(staffel|season)\D*\d+\b|\b\d+\D*(staffel|season)\b|\bs\d{1,2}\b', ' ', str(show or ''), flags=re.I)
        if title_matcher.matches(cand, sh, threshold=78):
            return True
        cn = cleantitle.normalize(cleantitle.getsearch(cand))
        sn = cleantitle.normalize(cleantitle.getsearch(sh))
        if not cn or not sn:
            return False
        if cn == sn or sn in cn or cn in sn:
            return True
        sw = set(sn.split())
        cw = set(cn.split())
        return bool(sw) and len(sw & cw) >= max(1, len(sw) * 2 // 3)

    def _search_season_page(self, show, local, year, season, fallback_url):
        if not show and not local:
            return None
        queries = []
        for base in [local, show]:
            if not base: continue
            bases = [str(base)]
            simplified = re.sub(r'[:|/]+', ' ', str(base))
            simplified = re.sub(r'\s+', ' ', simplified).strip()
            if simplified and simplified not in bases:
                bases.append(simplified)
            for b in bases:
                for q in [f'{b} Staffel {season}', f'{b} {season} Staffel', f'Staffel {season} {b}', f'{b} Season {season}', f'{b} S{int(season):02d}', str(b)]:
                    if q and q not in queries:
                        queries.append(q)
        for q in queries[:6]:
            html = self._post_search(q)
            if not html: continue
            results = self._parse_results(html, 'serial')
            fflog(f'[megakino] season-search {q!r}: {len(results)} wynikow', 1)
            candidates = []
            for r in results:
                hay = '%s %s' % (r.get('title') or '', r.get('url') or '')
                if not self._season_token_match(hay, season):
                    continue
                if not (self._base_title_match(r.get('title'), show) or self._base_title_match(r.get('url'), show)):
                    continue
                candidates.append(r)
            if candidates:
                # Prefer URL containing explicit Staffel/Season token and shorter, cleaner slug.
                candidates.sort(key=lambda r: (0 if self._season_token_match(r.get('url'), season) else 1, len(r.get('url') or '')))
                fflog(f'[megakino] season page match: {candidates[0].get("title")!r} -> {candidates[0].get("url")}', 1)
                return candidates[0].get('url')
        return None

    def _post_search(self, title):
        ck = f'search:{title}'
        if ck in self._cache: return self._cache[ck]
        try:
            from urllib.parse import quote
            h = dict(self.headers)
            h['Content-Type'] = 'application/x-www-form-urlencoded'
            h['Referer']      = self.base_link + '/'
            title_norm = title.lower().split()[0] if title else ''
            # Dla tytułów wielowyrazowych sprawdzaj co najmniej 2 pierwsze słowa,
            # żeby uniknąć fałszywych trafień (np. "one" jest na każdej stronie)
            title_words = title.lower().split()
            title_check = ' '.join(title_words[:2]) if len(title_words) > 1 else title_norm

            def _contains(text):
                t = text.lower()
                return title_check in t or (title_norm and title_norm in t and len(title_norm) > 5)

            # Próba 1: DLE AJAX search controller (JSON response)
            ajax_url = self.base_link + '/engine/ajax/controller.php?mod=search'
            ajax_data = urlencode({'story': title, 'startshownews': 0})
            try:
                r1 = self.session.post(ajax_url, data=ajax_data, headers=h, timeout=(10, 25))
                fflog(f'[megakino] AJAX search {title!r} status={r1.status_code} len={len(r1.text)}', 1)
                if r1.status_code < 400 and _contains(r1.text):
                    self._cache[ck] = r1.text
                    return r1.text
            except Exception: pass

            # Próba 2: POST DLE klasyczny
            r = self.session.post(
                self.base_link + '/index.php',
                data=urlencode({'do': 'search', 'subaction': 'search', 'story': title}),
                headers=h, timeout=(10, 30)
            )
            fflog(f'[megakino] POST search {title!r} status={r.status_code} len={len(r.text)}', 1)
            if r.status_code < 400 and _contains(r.text):
                self._cache[ck] = r.text
                return r.text

            # Próba 3: GET warianty
            for param in ['?s=', '/?q=', '/search/?q=']:
                get_url = self.base_link + param + quote(title)
                r2 = self.session.get(get_url, headers=h, timeout=(10, 30))
                fflog(f'[megakino] GET search {get_url!r} status={r2.status_code} len={len(r2.text)}', 1)
                if r2.status_code < 400 and _contains(r2.text):
                    self._cache[ck] = r2.text
                    return r2.text

            # Próba 4: DLE search z from_page
            for page in ['0', '1']:
                fp_url = (self.base_link + '/index.php?do=search&subaction=search'
                          + '&from_page=' + page + '&story=' + quote(title))
                r3 = self.session.get(fp_url, headers=h, timeout=(10, 25))
                fflog(f'[megakino] GET from_page search {title!r} p={page} status={r3.status_code}', 1)
                if r3.status_code < 400 and _contains(r3.text):
                    self._cache[ck] = r3.text
                    return r3.text

            result = r.text if r.status_code < 400 else None
            self._cache[ck] = result
            return result
        except Exception:
            fflog_exc(1)
            return None

    def _parse_results(self, html, content):
        """
        Megakino nie trzyma wszystkich filmów pod /films/ i seriali pod /serials/.
        W praktyce wyniki/sezony leżą często w kategoriach typu /drama/4005-cobra-kai-staffel-1.html
        albo /action/4373-cobra-kai-staffel-6.html. Parsujemy więc wszystkie linki DLE z ID,
        a potem filtrujemy po tytule/roku/sezonie.
        """
        results = []
        seen    = set()
        pat = re.compile(
            r'href=["\'](?:' + re.escape(self.base_link) + r')?'
            r'(/(?!page/|index\.php|engine/|xfsearch/|tags/|uploads/|templates/)[a-z0-9_-]+/(\d+)-([^"\']+?)\.html)["\']',
            re.I
        )
        for m in pat.finditer(html or ''):
            path, nid, slug = m.group(1), m.group(2), m.group(3)
            if path in seen:
                continue
            seen.add(path)
            surroundings = html[max(0, m.start()-350):m.end()+350]
            alt_m = re.search(r'alt=["\']([^"\']{3,})["\']', surroundings, re.I)
            title_m = re.search(r'title=["\']([^"\']{3,})["\']', surroundings, re.I)
            text_m = re.search(r'>\s*([^<>]{3,120}?)\s*</a>', surroundings, re.S|re.I)
            title = (alt_m.group(1) if alt_m else (title_m.group(1) if title_m else (text_m.group(1) if text_m else slug.replace('-', ' '))))
            title = re.sub(r'\s+', ' ', title).strip()
            year_m = re.search(r'\b(19|20)\d{2}\b', surroundings + ' ' + slug)
            year   = int(year_m.group()) if year_m else None
            lower_hay = (slug + ' ' + title + ' ' + path).lower()
            is_season_page = bool(re.search(r'\b(staffel|season)\D*\d+\b|\bs\d{1,2}\b', lower_hay, re.I))
            if content == 'film' and is_season_page:
                # Nie zwracaj stron sezonów jako filmy.
                continue
            results.append({
                'url': self.base_link + path,
                'id': nid,
                'title': title,
                'slug': slug,
                'year': year,
                'season_page': is_season_page,
                'category': path.strip('/').split('/')[0]
            })
            fflog(f'[megakino]   wynik: {title!r} ({year}) id={nid} path={path}', 1)

        # JSON/AJAX fallback: DLE search can return snippets with escaped slashes or JSON fields.
        json_pat = re.compile(r'["\'](?:url|link|href)["\']\s*:\s*["\']([^"\']+?/(\d+)-([^"\']+?)\.html)["\']', re.I)
        for m in json_pat.finditer(html or ''):
            path, nid, slug = m.group(1), m.group(2), m.group(3)
            path = path.replace('\\/', '/')
            if path.startswith('http'):
                url = path
                path_part = '/' + '/'.join(path.split('/')[3:])
            else:
                path_part = path if path.startswith('/') else '/' + path
                url = self.base_link + path_part
            if path_part in seen:
                continue
            seen.add(path_part)
            title = slug.replace('-', ' ')
            lower_hay = (slug + ' ' + title + ' ' + path_part).lower()
            is_season_page = bool(re.search(r'\b(staffel|season)\D*\d+\b|\bs\d{1,2}\b', lower_hay, re.I))
            if content == 'film' and is_season_page:
                continue
            results.append({'url': url, 'id': nid, 'title': title, 'slug': slug, 'year': None,
                            'season_page': is_season_page, 'category': path_part.strip('/').split('/')[0]})
        return results

    def _detail_years(self, html, slug=''):
        years = set()
        sample = (slug or '') + ' ' + (html or '')[:3500]
        for y in re.findall(r'\b((?:19|20)\d{2})\b', sample):
            try:
                yi = int(y)
                if 1900 <= yi <= 2035:
                    years.add(yi)
            except Exception:
                pass
        return years

    def _verify_result_page(self, r, wanted_titles, year=None, year_alt=None, content='film'):
        try:
            url = r.get('url')
            if not url:
                return False
            html = self._fetch_by_id(r.get('id') or '', url)
            if not html:
                return False
            title = r.get('title') or r.get('slug', '').replace('-', ' ')
            # Detal ma czasem lepszy tytuł w h1/title niż wynik wyszukiwania.
            m = re.search(r'<h[12][^>]*>\s*([^<]{2,140})', html, re.I)
            if m:
                title = re.sub(r'\s+', ' ', m.group(1)).strip()
            if not title_matcher.matches_any(title, wanted_titles, threshold=78) and not title_matcher.matches_any(r.get('slug','').replace('-', ' '), wanted_titles, threshold=78):
                return False
            if content == 'film' and r.get('season_page'):
                return False
            if year:
                years = self._detail_years(html, r.get('slug') or '')
                if years and not any(abs(y - int(year)) <= 1 or (year_alt and y == int(year_alt)) for y in years):
                    # Megakino także potrafi mieć kategorie/strony bez jednoznacznego roku; jeśli jest rok ewidentnie zły, odrzuć.
                    return False
            return True
        except Exception:
            return False

    def _best_match(self, results, wanted_titles, year, year_alt, content='film'):
        if not results:
            return None
        if isinstance(wanted_titles, str):
            wanted_titles = [wanted_titles]
        scored = []
        for r in results:
            title = r.get('title') or ''
            slug_title = (r.get('slug') or '').replace('-', ' ')
            title_score = max(title_matcher.score(title, w) for w in wanted_titles) if wanted_titles else 0
            slug_score  = max(title_matcher.score(slug_title, w) for w in wanted_titles) if wanted_titles else 0
            ts = max(title_score, slug_score)
            if ts < 76:
                continue
            ry = r.get('year')
            yr = (18 if ry and year and ry in (year, year_alt)
                  else 8 if ry and year and abs(ry-year) <= 1
                  else -35 if ry and year and abs(ry-year) > 1 else 0)
            season_bonus = 0
            if content == 'serial':
                season_bonus = 8 if r.get('season_page') else 0
            elif r.get('season_page'):
                season_bonus = -60
            total = ts + yr + season_bonus
            scored.append((total, r['url'], title, ry, r))
            fflog(f'[megakino]   score={total} title_score={ts} {title!r} ({ry}) -> {r["url"]}', 1)
        if not scored:
            return None
        scored.sort(key=lambda x: x[0], reverse=True)
        if scored[0][0] < 82:
            return None

        # Weryfikuj top kandydatów stroną szczegółów, bo Megakino miesza filmy i sezony w kategoriach.
        for total, url, title, ry, r in scored[:5]:
            if self._verify_result_page(r, wanted_titles, year, year_alt, content):
                fflog(f'[megakino] detail verify OK score={total} {title!r} -> {url}', 1)
                return url

        fflog(f'[megakino] detail verify fallback score={scored[0][0]} -> {scored[0][1]}', 1)
        return scored[0][1]

    def _extract_links(self, html, season=None, episode=None, news_id=None, referer=None):
        links = []
        seen  = set()
        if season is not None and episode is not None:
            # Kadr+ 2.40.57:
            # For TV episodes return only hosters tied to the selected episode id.
            # Do not scan the whole season page, because that can return hosters from a wrong episode.
            season_block = self._season_block(html, int(season)) or html
            ep_id = self._find_ep_id(season_block, int(episode))
            fflog(f'[megakino] ep_id={ep_id} dla S{season}E{episode} (strict episode block)', 1)
            if ep_id:
                links = self._links_from_select(season_block, ep_id, seen)
                if not links:
                    links = self._links_from_strict_episode_container(season_block, ep_id, seen)
                if not links:
                    links = self._links_from_episode_ajax(html, news_id, season, episode, ep_id, referer, seen)
            if not links:
                fflog(f'[megakino] brak hosterow dla konkretnego odcinka S{season}E{episode}; nie zwracam hosterow z calego sezonu', 1)
        else:
            # Movies: full-page hoster scan is fine.
            for m in re.finditer(
                r'<select[^>]+class=["\'][^"\']*mr-select[^"\']*["\'][^>]*>(.*?)</select>',
                html, re.S|re.I
            ):
                links += self._options_from_block(m.group(1), seen)
            if not links:
                for m in re.finditer(
                    r'<iframe[^>]+(?:data-src|src)=["\'](\s*https?://[^"\']+)["\']',
                    html, re.I
                ):
                    url = m.group(1).strip()
                    if 'youtube.com' in url or 'megakino' in url:
                        continue
                    if url in seen:
                        continue
                    seen.add(url)
                    host_m = re.search(r'https?://(?:www\.)?([^/]+)', url)
                    label = host_m.group(1).split('.')[0].capitalize() if host_m else 'Hoster'
                    links.append({'url': url, 'quality': self._quality(url), 'info': f'DE | {label}'})
                    fflog(f'[megakino]   iframe link: {label} {url[:60]}', 1)
            if not links:
                links = self._all_hoster_links(html, seen)
        return links

    def _season_block(self, html, season):
        """
        Kadr+ 2.40.52: wycina fragment HTML właściwy dla sezonu.
        Megakino ma strony sezonowe, ale część HTML/AJAX nadal zawiera wiele list
        odcinków. Jeśli metoda nie znajdzie jednoznacznego bloku, zwraca cały HTML,
        żeby istniejący fallback mógł dalej znaleźć ep_id.
        """
        try:
            if not html or not season:
                return None
            s = int(season)
            # Najpierw szukamy nagłówka/zakładki Staffel/Season/Sxx i bierzemy zakres do kolejnego sezonu.
            token = r'(?:Staffel|Season)\s*%d|S%02d\b|S%d\b' % (s, s, s)
            starts = []
            for m in re.finditer(token, html, re.I):
                starts.append(m.start())
            if starts:
                start = starts[0]
                next_pat = r'(?:Staffel|Season)\s*%d|S%02d\b|S%d\b' % (s + 1, s + 1, s + 1)
                n = re.search(next_pat, html[start + 1:], re.I)
                end = start + 1 + n.start() if n else len(html)
                block = html[max(0, start - 3000):end]
                if 'ep' in block.lower() or 'mr-select' in block.lower() or 'se-select' in block.lower():
                    return block
            # Na sezonowej stronie typu cobra-kai-staffel-2.html cały dokument jest już właściwym sezonem.
            if self._season_token_match(html[:8000], s) or self._season_token_match(html, s):
                return html
            # Jeżeli URL/tytuł strony nie niesie sezonu, ale HTML zawiera wybór odcinków,
            # zostawiamy istniejący fallback na cały HTML.
            if 'se-select' in html or 'mr-select' in html:
                return html
        except Exception:
            pass
        return None

    def _find_ep_id(self, html, episode):
        try:
            e = int(episode)
            se = re.search(
                r'<select[^>]+class=["\'][^"\']*se-select[^"\']*["\'][^>]*>(.*?)</select>',
                html, re.S|re.I
            )
            if se:
                opts = []
                for m in re.finditer(r'<option([^>]*)>(.*?)</option>', se.group(1), re.S|re.I):
                    attrs, label_html = m.group(1), m.group(2)
                    vm = re.search(r'value=["\']([^"\']+)["\']', attrs, re.I)
                    if not vm:
                        continue
                    value = vm.group(1).strip()
                    label = self._strip_html(label_html)
                    hay = ' '.join([value, label]).lower()
                    # Covers: ep6, ep06, Episode 6, Folge 6, 6. Requiem, 6 Requiem.
                    pats = [
                        r'\bep0?%d\b' % e,
                        r'\bepisode\s*0?%d\b' % e,
                        r'\bfolge\s*0?%d\b' % e,
                        r'(^|\D)0?%d(\D|$)' % e,
                    ]
                    opts.append(value)
                    if any(re.search(p, hay, re.I) for p in pats):
                        return value
                if 0 < e <= len(opts):
                    return opts[e-1]
        except Exception:
            fflog_exc(1)
        return f'ep{episode}'


    def _links_from_episode_ajax(self, html, news_id, season, episode, ep_id, referer, seen):
        """
        Kadr+ 2.40.60: exact-episode fallback for MegaKino.

        The older working parser could find a hoster select by exact id/value like
        `ep6` in the full detail HTML.  The later strict season-block code was safer
        against wrong-episode links, but when the hoster select was outside the clipped
        block it ended with 0 links, and 2.40.59 additionally missed this method.

        This fallback is still strict: it only accepts links tied to the exact episode
        identifier (`ep6`, etc.), then tries one-hop internal Megakino AJAX/player
        values. It does not return hosters from the whole season page.
        """
        links = []
        try:
            if not html or not ep_id:
                return links

            # 1) Restore the old successful path: exact <select id="epX"> from full HTML.
            try:
                links = self._links_from_select(html, ep_id, seen)
                if links:
                    fflog(f'[megakino] exact full-page select {ep_id}: {len(links)} linkow', 1)
                    return links
            except Exception:
                fflog_exc(1)

            sid = str(ep_id)
            sid_re = re.escape(sid)

            # 2) Look for episode-specific wrappers/buttons containing internal player data.
            patterns = [
                r'(<[^>]+(?:id|data-id|data-episode|data-ep|value|href)=["\'][^"\']*%s[^"\']*["\'][^>]*>)' % sid_re,
                r'(<option[^>]+value=["\']%s["\'][^>]*>.*?</option>)' % sid_re,
            ]
            positions = []
            for pat in patterns:
                for m in re.finditer(pat, html, re.S | re.I):
                    positions.append(m.start())
            # also check raw ep id positions, but keep this limited.
            for m in re.finditer(r'\b%s\b' % sid_re, html, re.I):
                positions.append(m.start())

            uniq = []
            for pos in sorted(set(positions)):
                if not uniq or abs(pos - uniq[-1]) > 200:
                    uniq.append(pos)

            for pos in uniq[:10]:
                start = max(0, pos - 2500)
                end = min(len(html), pos + 12000)
                # Stop at next episode marker if it is close, so we do not bleed into another ep.
                try:
                    em = re.search(r'ep0?(\d+)', sid, re.I)
                    if em:
                        nxt = 'ep%d' % (int(em.group(1)) + 1)
                        nm = re.search(re.escape(nxt), html[pos + 1:pos + 16000], re.I)
                        if nm:
                            end = min(end, pos + 1 + nm.start())
                except Exception:
                    pass
                block = html[start:end]

                # First parse any selects in this exact neighbourhood.
                for sm in re.finditer(r'<select[^>]*>(.*?)</select>', block, re.S | re.I):
                    links.extend(self._options_from_block(sm.group(1), seen))
                    if links:
                        fflog(f'[megakino] exact episode neighbourhood select {ep_id}: {len(links)} linkow', 1)
                        return links

                # Then resolve only values/links attached to this neighbourhood.
                values = []
                attr_pat = r'(?:data-url|data-link|data-src|data-file|data-href|href|src)=(["\'])(.*?)\1'
                for m in re.finditer(attr_pat, block, re.I):
                    val = (m.group(2) or '').strip()
                    if val and not val.startswith('#') and not val.lower().startswith('javascript'):
                        values.append(val)
                js_pat = r'(?:url|link|file|src|iframe|player|load)\s*[:=]\s*(["\'])(.*?)\1'
                for m in re.finditer(js_pat, block, re.I):
                    val = (m.group(2) or '').strip()
                    if val:
                        values.append(val)

                for val in values[:12]:
                    if val.startswith('http') and 'megakino' not in val:
                        self._add_hoster_link(links, seen, val)
                    else:
                        for it in self._resolve_internal_value(val, referer=referer):
                            u = it.get('url')
                            if u and u not in seen:
                                seen.add(u)
                                links.append(it)
                    if links:
                        fflog(f'[megakino] exact episode ajax/internal {ep_id}: {len(links)} linkow', 1)
                        return links

            # 3) Last exact DLE-style attempts.  Keep them bounded and episode-specific.
            if news_id:
                endpoint_payloads = [
                    ('/engine/ajax/controller.php', {'mod': 'showfull', 'id': str(news_id), 'episode': str(episode), 'season': str(season), 'ep': sid}),
                    ('/engine/ajax/controller.php?mod=showfull', {'id': str(news_id), 'episode': str(episode), 'season': str(season), 'ep': sid}),
                    ('/engine/ajax/play.php', {'news_id': str(news_id), 'id': str(news_id), 'episode': str(episode), 'season': str(season), 'ep': sid}),
                    ('/index.php?do=ajax', {'news_id': str(news_id), 'id': str(news_id), 'episode': str(episode), 'season': str(season), 'ep': sid}),
                ]
                headers = dict(self.headers)
                headers['Referer'] = referer or self.base_link + '/'
                headers['X-Requested-With'] = 'XMLHttpRequest'
                headers['Content-Type'] = 'application/x-www-form-urlencoded'
                for path, data in endpoint_payloads:
                    try:
                        url = self.base_link + path
                        r = self.session.post(url, data=urlencode(data), headers=headers, timeout=(6, 10))
                        body = r.text or ''
                        fflog(f'[megakino] ajax fallback {path} status={r.status_code} len={len(body)}', 1)
                        if r.status_code not in (200, 204) or len(body) < 5:
                            continue
                        # Only accept response if it mentions selected ep/news or contains direct hoster links.
                        if sid not in body and str(news_id) not in body and not re.search(r'https?:\\?/\\?/[^\'"<>\\s]+', body, re.I):
                            continue
                        for m in re.finditer(r'(?:data-url|data-link|data-src|data-file|href|src)=(["\'])(.*?)\1', body, re.I):
                            val = (m.group(2) or '').strip()
                            if val.startswith('http') and 'megakino' not in val:
                                self._add_hoster_link(links, seen, val)
                            else:
                                for it in self._resolve_internal_value(val, referer=referer):
                                    u = it.get('url')
                                    if u and u not in seen:
                                        seen.add(u)
                                        links.append(it)
                        for m in re.finditer(r'https?:\\?/\\?/[^\'"<>\\s]+', body, re.I):
                            self._add_hoster_link(links, seen, m.group(0))
                        if links:
                            fflog(f'[megakino] ajax fallback returned {len(links)} linkow', 1)
                            return links
                    except Exception:
                        fflog_exc(1)
        except Exception:
            fflog_exc(1)
        return links

    def _links_from_strict_episode_container(self, html, ep_id, seen):
        """
        Kadr+ 2.40.58: strict per-episode hoster extraction.
        MegaKino sometimes stores the selected episode value (e.g. ep6) in a tab/button,
        and the hoster select/list is in the nearest following container rather than in a
        select with id/name=ep6.  This scans only small containers around that exact ep_id,
        so it does not accidentally return hosters from the whole season.
        """
        links = []
        try:
            if not html or not ep_id:
                return links
            sid = str(ep_id)
            sid_re = re.escape(sid)
            positions = []
            patterns = [
                r'(?:id|data-id|data-episode|data-ep|value|href)=["\'][^"\']*%s[^"\']*["\']' % sid_re,
                r'\b%s\b' % sid_re,
            ]
            for pat in patterns:
                for m in re.finditer(pat, html, re.I):
                    positions.append(m.start())
            uniq = []
            for pos in sorted(positions):
                if not uniq or abs(pos - uniq[-1]) > 150:
                    uniq.append(pos)
            for pos in uniq[:8]:
                start = max(0, pos - 2500)
                end = min(len(html), pos + 10000)
                try:
                    mcur = re.search(r'ep0?(\d+)', sid, re.I)
                    if mcur:
                        nxt = 'ep%d' % (int(mcur.group(1)) + 1)
                        n = re.search(re.escape(nxt), html[pos + 1:pos + 16000], re.I)
                        if n:
                            end = min(end, pos + 1 + n.start())
                except Exception:
                    pass
                block = html[start:end]
                for sm in re.finditer(r'<select[^>]*>(.*?)</select>', block, re.S | re.I):
                    links.extend(self._options_from_block(sm.group(1), seen))
                    if links:
                        return links
                for m in re.finditer(r'(?:data-url|data-link|data-src|data-file|href|src)=["\']([^"\']+)["\']', block, re.I):
                    val = (m.group(1) or '').strip()
                    if not val or val.startswith('#') or val.startswith('javascript'):
                        continue
                    if val.startswith('http') and 'megakino' not in val:
                        self._add_hoster_link(links, seen, val)
                    else:
                        for it in self._resolve_internal_value(val):
                            u = it.get('url')
                            if u and u not in seen:
                                seen.add(u)
                                links.append(it)
                    if links:
                        return links
                for m in re.finditer(r'(?:url|link|file|src|iframe)\s*[:=]\s*["\']([^"\']+)["\']', block, re.I):
                    val = (m.group(1) or '').strip()
                    if not val:
                        continue
                    if val.startswith('http') and 'megakino' not in val:
                        self._add_hoster_link(links, seen, val)
                    else:
                        for it in self._resolve_internal_value(val):
                            u = it.get('url')
                            if u and u not in seen:
                                seen.add(u)
                                links.append(it)
                    if links:
                        return links
                for m in re.finditer(r'https?://[^\'"<>\s]+', block, re.I):
                    val = m.group(0)
                    if 'megakino' in val or 'youtube.com' in val or 'google' in val:
                        continue
                    self._add_hoster_link(links, seen, val)
                    if links:
                        return links
        except Exception:
            fflog_exc(1)
        return links

    def _links_from_select(self, html, select_id, seen):
        if not select_id:
            return []
        links = []
        sid = str(select_id)
        sid_re = re.escape(sid)
        # Main case: hoster select has id/name/data matching episode id, e.g. id="ep6".
        select_patterns = [
            rf'<select[^>]+(?:id|name|data-id|data-episode|data-ep)=["\']{sid_re}["\'][^>]*>(.*?)</select>',
            rf'<select[^>]+[^>]*\b{sid_re}\b[^>]*>(.*?)</select>',
        ]
        for pat in select_patterns:
            for m in re.finditer(pat, html, re.S|re.I):
                links.extend(self._options_from_block(m.group(1), seen))
                if links:
                    return links
        # Some templates keep episode id in a nearby wrapper and select follows it.
        for pos in [m.start() for m in re.finditer(r'(?:id|data-id|data-episode|value)=["\']%s["\']' % sid_re, html, re.I)][:4]:
            block = html[max(0, pos-800):pos+6000]
            for sm in re.finditer(r'<select[^>]*>(.*?)</select>', block, re.S|re.I):
                links.extend(self._options_from_block(sm.group(1), seen))
                if links:
                    return links
        return links

    def _options_from_block(self, block, seen):
        links = []
        for m in re.finditer(r'<option([^>]*)>(.*?)</option>', block or '', re.S|re.I):
            attrs, label_html = m.group(1), m.group(2)
            vm = re.search(r'value=["\']([^"\']+)["\']', attrs, re.I)
            if not vm:
                continue
            url, label = vm.group(1).strip(), self._strip_html(label_html)
            if not url or url in seen:
                continue
            if url.startswith('http') and 'megakino' not in url:
                seen.add(url)
                links.append({'url': url, 'quality': self._quality(label+url), 'info': f'DE | {label or "Hoster"}'})
                fflog(f'[megakino]   link: {label} {url[:60]}', 1)
            else:
                # Relative/internal Megakino value -> resolve one hop to external hosters.
                for it in self._resolve_internal_value(url):
                    if it.get('url') not in seen:
                        seen.add(it.get('url'))
                        links.append(it)
        return links

    def _quality(self, t):
        t = t.lower()
        if '4k' in t or '2160' in t: return '4K'
        if '1080' in t: return '1080p'
        if '720' in t:  return '720p'
        return 'HD'

    def _init_session(self):
        if not self.session:
            import requests, urllib3
            urllib3.disable_warnings()
            self.session = requests.Session()
            self.session.verify = False
            self.session.headers.update(self.headers)
            try:
                # Krok 1: homepage — ustanowienie sesji
                r = self.session.get(self.base_link + '/', timeout=(10, 20))
                fflog(f'[megakino] homepage status={r.status_code}', 1)
                # Krok 2: pobranie yg_token
                token_headers = dict(self.headers)
                token_headers['Referer'] = self.base_link + '/'
                rt = self.session.get(
                    self.base_link + '/index.php?yg=token',
                    headers=token_headers, timeout=(10, 15)
                )
                fflog(f'[megakino] yg_token status={rt.status_code} cookies={list(self.session.cookies.keys())}', 1)
                # Krok 3: index.php — pełna inicjalizacja sesji
                self.session.get(self.base_link + '/index.php', timeout=(10, 20))
            except Exception:
                fflog_exc(1)
