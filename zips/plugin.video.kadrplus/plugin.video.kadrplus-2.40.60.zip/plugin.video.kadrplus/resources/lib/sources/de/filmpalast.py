# -*- coding: UTF-8 -*-
"""
    Scraper dla filmpalast.to (serwis NIEMIECKI)
    Oparty na oryginalnej wtyczce plugin.video.filmpalast.ex v0.5.1
"""
import re
from urllib.parse import quote_plus, quote as url_quote

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from ptw.libraries import control, source_utils, cleantitle, title_matcher
from ptw.debug import fflog, fflog_exc


class source:
    def __init__(self):
        self.priority = 2
        self.language = ['de']

        self.base_link   = 'https://filmpalast.to'
        self.search_link = '/search/title/%s'

        self.headers = {
            'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0',
            'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'de-DE,de;q=0.9,en;q=0.3',
            'Referer':         'https://filmpalast.to/',
        }
        self.session = None
        self._cache  = {}

    # ------------------------------------------------------------------ #
    #  Metody wymagane przez FanFilm                                       #
    # ------------------------------------------------------------------ #

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        fflog(f'[filmpalast] {title=}  {year=}', 1)
        year_alt = kwargs.get('year_alt')
        if year_alt:
            year = (year, year_alt)
        return self._search(title, localtitle, aliases, year, 'movie')

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        fflog(f'[filmpalast] {tvshowtitle=}  {year=}', 1)
        year_alt = kwargs.get('year_alt')
        if year_alt:
            year = (year, year_alt)
        return self._search(tvshowtitle, localtvshowtitle, aliases, year, 'tvshow')

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        fflog(f'[filmpalast] {url=}  {season=}  {episode=}', 1)
        if not url:
            return None
        return self._get_episode_url(url, int(season), int(episode))

    def sources(self, url, hostDict, hostprDict):
        result = []
        fflog(f'[filmpalast] sources {url=}', 1)
        if not url:
            return result
        try:
            self._init_session()
            html = self._get(url)
            if not html:
                return result
            links = self._extract_sources(html)
            for item in links:
                link = item.get('url', '')
                if not link:
                    continue
                valid, hoster = source_utils.is_host_valid(link, hostDict)
                if not valid:
                    valid, hoster = source_utils.is_host_valid(link, hostprDict)
                if not valid:
                    # resolveurl nie zna hosta, ale przepuszczamy — filmpalast to zaufane źródło
                    from urllib.parse import urlsplit
                    hoster = urlsplit(link).hostname or link
                    valid = True
                if valid:
                    result.append({
                        'source':     hoster,
                        'quality':    item.get('quality', 'HD'),
                        'language':   'de',
                        'url':        link,
                        'info':       item.get('info', ''),
                        'direct':     False,
                        'debridonly': False,
                    })
                else:
                    fflog(f'[filmpalast] nierozpoznany host: {link}', 1)
        except Exception:
            fflog_exc(1)
        fflog(f'[filmpalast] zwracam {len(result)} zrodel')
        return result

    def resolve(self, url):
        return url

    # ------------------------------------------------------------------ #
    #  Wyszukiwanie                                                        #
    # ------------------------------------------------------------------ #

    def _search(self, title, localtitle, aliases, year, content_type):
        try:
            self._init_session()

            year_int = year_alt_int = None
            if isinstance(year, (tuple, list)):
                try: year_int     = int(year[0])
                except: pass
                try: year_alt_int = int(year[1])
                except: pass
            else:
                try: year_int = int(year)
                except: pass

            # FilmPalast ma proste /stream/<slug>, ale wyszukiwarka zwraca też podobne
            # tytuły i odcinki. Używamy wariantów: tytuł lokalny, oryginalny, aliasy DE,
            # części po ':' '/' '-' oraz bezpieczny fuzzy matching.
            titles_to_try = title_matcher.title_variants(title, localtitle, aliases, max_items=10)
            if not titles_to_try:
                titles_to_try = [title or localtitle]

            # Szybki direct fallback dla najczęstszej struktury FilmPalast:
            # /stream/we-bury-the-dead, /stream/the-thing, /stream/io-2018,
            # seriale: /stream/reacher -> odcinki /stream/reacher-s03e07.
            direct = self._direct_stream_match(titles_to_try, year_int, year_alt_int, content_type)
            if direct:
                fflog(f'[filmpalast] direct match: {direct}', 1)
                return direct

            all_results = []
            for search_title in titles_to_try[:6]:
                search_url = self.base_link + self.search_link % url_quote(search_title)
                fflog(f'[filmpalast] GET {search_url}', 1)

                html = self._get(search_url)
                if not html:
                    continue

                results = self._parse_search_results(html)
                fflog(f'[filmpalast] wynikow: {len(results)} dla "{search_title}"', 1)
                for r in results:
                    if r.get('url') not in [x.get('url') for x in all_results]:
                        all_results.append(r)

            match = self._find_best_match(all_results, titles_to_try, year_int, year_alt_int, content_type)
            if match:
                fflog(f'[filmpalast] dopasowano: {match}', 1)
                return match

            fflog(f'[filmpalast] nie znaleziono: {title!r}')
            return None

        except Exception:
            fflog_exc(1)
            return None

    def _parse_search_results(self, html):
        """
        Pattern z oryginalnej wtyczki (movie_data):
          href="//filmpalast.to/stream/SLUG" title="TYTUL"
        """
        results = []
        seen_slugs = set()
        try:
            pattern = re.compile(
                r'href="(?:https?:)?//filmpalast\.to(/stream/([^"?#\s]+))"[^>]*title="([^"]*)"',
                re.IGNORECASE
            )

            for m in pattern.finditer(html):
                path  = m.group(1)
                slug  = m.group(2).strip().strip('/')
                title = m.group(3).strip()

                if not slug or slug in seen_slugs:
                    continue
                # Odrzuc slugi menu
                if slug in ('new', 'view', 'top', 'movies', 'serien'):
                    continue
                seen_slugs.add(slug)

                url = f'{self.base_link}{path}'

                                # Szukaj roku w tytule (np. "Mercy (2026)") - filmpalast często podaje rok w nawiasach
                year = None
                ym = re.search(r'\(((?:19|20)\d{2})\)', title)
                if ym:
                    year = int(ym.group(1))

                # Fallback: szukaj roku w slugu (np. "rampage-2018")
                if not year:
                    ym = re.search(r'-((?:19|20)\d{2})(?:-|$)', slug)
                    if ym:
                        year = int(ym.group(1))

                # Fallback: szukaj roku w okolicach linka
                if not year:
                    ctx = html[max(0, m.start() - 500):m.end() + 300]
                    ym = re.search(r'>Ver(?:&ouml;|ö)ffentlicht:\s*((?:19|20)\d{2})\b', ctx, re.IGNORECASE)
                    if not ym:
                        ym = re.search(r'(?:Jahr|Erscheinungsjahr|Veroeffentlicht)[:\s]*(?:<[^>]+>)*\s*((?:19|20)\d{2})', ctx, re.IGNORECASE)
                    if ym:
                        year = int(ym.group(1))

                results.append({'url': url, 'title': title, 'year': year, 'slug': slug})
                fflog(f'[filmpalast]   wynik: {title!r} ({year}) -> {slug}', 1)

        except Exception:
            fflog_exc(1)
        return results

    def _slugify(self, text):
        text = title_matcher.normalize(text or '')
        return re.sub(r'-+', '-', text.replace(' ', '-')).strip('-')

    def _detail_title(self, html, slug=''):
        title = ''
        m = re.search(r'<h[12][^>]*>\s*([^<]{2,120})', html or '', re.I)
        if not m:
            m = re.search(r'<title>\s*(?:Film\s+)?(.+?)\s+Stream', html or '', re.I)
        if m:
            title = re.sub(r'\s+', ' ', m.group(1)).strip()
        return title or slug.replace('-', ' ')

    def _detail_years(self, html, slug=''):
        years = set()
        for y in re.findall(r'\b((?:19|20)\d{2})\b', (slug or '') + ' ' + (html or '')[:2500]):
            try:
                yi = int(y)
                if 1900 <= yi <= 2035:
                    years.add(yi)
            except Exception:
                pass
        # FilmPalast często ma release-name z prawdziwym rokiem, a "Veröffentlicht" bywa rokiem uploadu.
        # Nie bierzemy więc samego upload-year jako twardego kryterium, tylko jako bonus.
        return years

    def _detail_matches(self, url, wanted_titles, year=None, year_alt=None, content_type='movie'):
        try:
            html = self._get(url)
            if not html or not self._has_player(html):
                return False
            slug_m = re.search(r'/stream/([^?#/]+)', url)
            slug = slug_m.group(1) if slug_m else ''
            title = self._detail_title(html, slug)
            if not title_matcher.matches_any(title, wanted_titles, threshold=82) and not title_matcher.matches_any(slug.replace('-', ' '), wanted_titles, threshold=82):
                return False
            if content_type == 'movie' and re.search(r'-s\d{1,2}e\d{1,2}$', slug, re.I):
                return False
            if year:
                years = self._detail_years(html, slug)
                if years and not any(abs(y - int(year)) <= 1 or (year_alt and y == int(year_alt)) for y in years):
                    # Nie odrzucaj tylko wtedy, gdy jedyny rok wygląda jak przyszły/upload-year.
                    if all(y > int(year) + 2 for y in years):
                        return True
                    return False
            return True
        except Exception:
            return False

    def _direct_stream_match(self, wanted_titles, year, year_alt, content_type='movie'):
        tried = set()
        for title in wanted_titles[:6]:
            slug = self._slugify(title)
            if not slug:
                continue
            candidates = [slug]
            if content_type == 'movie' and year:
                candidates.insert(0, f'{slug}-{int(year)}')
            for cand in candidates:
                if cand in tried:
                    continue
                tried.add(cand)
                url = f'{self.base_link}/stream/{cand}'
                if self._detail_matches(url, wanted_titles, year, year_alt, content_type):
                    return url
        return None

    def _find_best_match(self, results, wanted_titles, year, year_alt, content_type='movie'):
        if not results:
            return None
        if isinstance(wanted_titles, str):
            wanted_titles = [wanted_titles]
        ep_pattern  = re.compile(r'-s\d{1,2}e\d{1,2}$', re.IGNORECASE)

        scored = []
        for r in results:
            slug = r['slug']
            slug_is_episode = bool(ep_pattern.search(slug))
            slug_base  = ep_pattern.sub('', slug)
            slug_title = slug_base.replace('-', ' ')
            raw_title  = r.get('title') or slug_title

            ts = max(
                title_matcher.score(raw_title, w) for w in wanted_titles
            ) if wanted_titles else 0
            ss = max(
                title_matcher.score(slug_title, w) for w in wanted_titles
            ) if wanted_titles else 0
            best = max(ts, ss)
            if best < 76:
                continue

            result_year = r.get('year')
            yr = 0
            if result_year and year:
                if result_year in (year, year_alt):
                    yr = 18
                elif abs(result_year - year) <= 1:
                    yr = 8
                elif result_year > year + 2:
                    yr = 0  # możliwy upload/published year, np. FilmPalast potrafi mieć 2026 dla filmu 2024
                else:
                    yr = -35

            type_bonus = 0
            if content_type == 'tvshow':
                type_bonus = 10 if slug_is_episode else 3
            elif slug_is_episode:
                type_bonus = -40

            total = best + yr + type_bonus
            scored.append((total, r['url'], slug, raw_title))
            fflog(f'[filmpalast] score={total} title_score={best} {raw_title!r} ({result_year}) -> {slug}', 1)

        if not scored:
            return results[0]['url'] if len(results) == 1 else None

        scored.sort(key=lambda x: x[0], reverse=True)
        if scored[0][0] < 78:
            return None

        # Weryfikacja najlepszych stron szczegółów, żeby uniknąć kolizji typu IO/Io 2018, The Thing 1982/2011.
        for total, url, slug, raw_title in scored[:4]:
            if self._detail_matches(url, wanted_titles, year, year_alt, content_type):
                fflog(f'[filmpalast] detail verify OK: score={total} slug={slug}', 1)
                if content_type == 'tvshow' and ep_pattern.search(slug):
                    base_slug = ep_pattern.sub('', slug)
                    return f'{self.base_link}/stream/{base_slug}'
                return url

        fflog(f'[filmpalast] detail verify brak, fallback top score={scored[0][0]} slug={scored[0][2]}', 1)
        if content_type == 'tvshow' and ep_pattern.search(scored[0][2]):
            return f'{self.base_link}/stream/{ep_pattern.sub("", scored[0][2])}'
        return scored[0][1]

    # ------------------------------------------------------------------ #
    #  Odcinki seriali                                                     #
    # ------------------------------------------------------------------ #

    def _get_episode_url(self, show_url, season, episode):
        try:
            self._init_session()
            m = re.search(r'/stream/([^?#/]+)', show_url)
            if not m:
                return None
            base_slug = re.sub(r'-s\d+e\d+$', '', m.group(1), flags=re.IGNORECASE)

            ep_url = f'{self.base_link}/stream/{base_slug}-s{season:02d}e{episode:02d}'
            fflog(f'[filmpalast] odcinek: {ep_url}', 1)

            html = self._get(ep_url)
            if html and self._has_player(html):
                return ep_url

            show_html = self._get(show_url)
            if show_html:
                pat = re.compile(
                    rf'/stream/{re.escape(base_slug)}-s{season:02d}e{episode:02d}',
                    re.IGNORECASE
                )
                if pat.search(show_html):
                    return ep_url

            return ep_url
        except Exception:
            fflog_exc(1)
            return None

    # ------------------------------------------------------------------ #
    #  Wyciaganie zrodel — pattern z oryginalnej wtyczki                  #
    # ------------------------------------------------------------------ #

    def _detect_quality_from_release(self, html):
        """Wykryj jakość z nazwy releasu (np. Greenland.2.1080p.WEB)."""
        m = re.search(
            r'\b(2160p?|4[Kk]|UHD|1080p?|720p?|480p?|HDRip|BRRip|BluRay|WEB.?DL|WEBRip|HDCAM|CAM)\b',
            html, re.IGNORECASE
        )
        if m:
            q = m.group(1).upper().replace('-', '').replace('.', '')
            if '2160' in q or '4K' in q or 'UHD' in q: return '4K'
            if '1080' in q: return '1080p'
            if '720' in q: return '720p'
            if 'CAM' in q: return 'CAM'
        return 'HD'

    def _extract_sources(self, html):
        """
        Pattern z oryginalnej wtyczki filmpalast.ex:
        'video_sources': r'<p class="hostName">(.*?)<.*?<li class="streamPlayBtn clearfix rb">.*?<a.*?class="button.*?(?:url|href)="(.*?)"'
        """
        links = []
        seen  = set()

        # Wykryj jakość z nazwy releasu (np. "Reacher.S03E07.German.DL.1080p.WEB")
        release_quality = self._detect_quality_from_release(html)
        # Filmpalast = serwis niemiecki, audio zawsze w języku niemieckim
        audio_info = 'Dubbing DE'

        def quality_from_label(label):
            c = (label or '').upper()
            if any(x in c for x in ('2160', '4K', 'UHD')): return '4K'
            if '1080' in c: return '1080p'
            if '720'  in c: return '720p'
            if 'HD'   in c: return release_quality  # użyj jakości z releasu gdy etykieta mówi "HD"
            return release_quality

        def add(url, info='', quality=None):
            url = url.strip().replace('\\/', '/')
            if url.startswith('//'): url = 'https:' + url
            if not url.startswith('http'): return
            if 'filmpalast.to' in url: return
            if '#' in url and not url.startswith('http'): return
            if url not in seen:
                q = quality or quality_from_label(info)
                seen.add(url)
                # info = "Dubbing DE | NazwaHostera"
                full_info = f'{audio_info} | {info}' if info else audio_info
                links.append({'url': url, 'quality': q, 'info': full_info})
                fflog(f'[filmpalast] zrodlo [{q}] {full_info}: {url}', 1)

        # === GLOWNY PATTERN z oryginalnej wtyczki ===
        main_pattern = re.compile(
            r'<p\s+class="hostName">(.*?)</p>.*?'
            r'<li\s+class="streamPlayBtn[^"]*">.*?'
            r'<a[^>]*(?:url|href)=["\']([^"\'#\s][^"\']*)["\']',
            re.IGNORECASE | re.DOTALL
        )
        for m in main_pattern.finditer(html):
            hoster = re.sub(r'<[^>]+>', '', m.group(1)).strip()
            url    = m.group(2).strip()
            if url and not url.startswith('#'):
                add(url, hoster)

        # === FALLBACK: szukaj linkow do znanych hostow ===
        if not links:
            fflog('[filmpalast] glowny pattern 0 zrodel, fallback', 1)
            known = re.compile(
                r'(?:href|url|src)=["\']('
                r'https?://(?:'
                r'voe\.sx|veev\.|streamtape\.|dood\.|upstream\.'
                r'|vidara\.|vidsonic\.|vidhide\.|vidplay\.'
                r'|streamwish\.|filemoon\.|mixdrop\.|vidoza\.'
                r'|streamlare\.|mp4upload\.|vidmoly\.|netu\.'
                r'|supervideo\.|emturbovid\.|uqload\.|vudeo\.'
                r')[^"\'<>\s]+)["\']',
                re.IGNORECASE
            )
            for m in known.finditer(html):
                add(m.group(1))

        fflog(f'[filmpalast] lacznie {len(links)} zrodel')
        return links

    def _has_player(self, html):
        return bool(re.search(
            r'class="hostName"|class="streamPlayBtn"|iframe|\.mp4|\.m3u8|voe\.sx|streamtape|veev\.',
            html, re.IGNORECASE
        ))

    # ------------------------------------------------------------------ #
    #  HTTP — DoH (DNS-over-HTTPS) jak w oryginalnej wtyczce filmpalast  #
    #  Podmienia tylko gniazdo TCP, URL/Host/SNI pozostają niezmienione  #
    # ------------------------------------------------------------------ #

    def _init_session(self):
        if not self.session:
            try:
                from resources.lib.sources.doh_helper import make_doh_session
                self.session = make_doh_session()
                fflog('[filmpalast] sesja DoH OK', 1)
            except Exception:
                fflog_exc(1)
                import requests, urllib3
                urllib3.disable_warnings()
                self.session = requests.Session()
                self.session.verify = False
            self.session.headers.update(self.headers)

    def _get(self, url, timeout=(10, 30)):
        if url in self._cache:
            return self._cache[url]
        try:
            fflog(f'[filmpalast] GET {url}', 1)
            r = self.session.get(url, headers=self.headers, timeout=timeout, verify=False)
            fflog(f'[filmpalast] status={r.status_code} len={len(r.text)}', 1)
            if r is None or r.status_code >= 400:
                self._cache[url] = None
                return None
            self._cache[url] = r.text
            return r.text
        except Exception:
            fflog_exc(1)
            self._cache[url] = None
            return None
