"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import os
import shutil
import zipfile

import re

import urllib3  # potrzebne, aby poniższa linijka zadziałała
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


class ResolveUrlChecker:
    def __init__(self):
        # xbmc.log(f"[checker] {xbmc.LOGERROR=}", 1)
        # xbmc.log( "[checker] test logu (czy się wyświetli)", xbmc.LOGERROR, )
        self.addonName = "script.module.resolveurl"
        self.LocalVersion = self.getInstalledResolveUrlVersion()
        self.resolveUrlLink = ("https://raw.githubusercontent.com/Gujal00/smrzips/master/addons.xml")
        self.OfficialVersion = self.getOfficialResolveUrlVersion()
        self.resolveUrlLinkZip = f"https://raw.githubusercontent.com/Gujal00/smrzips/master/zips/{self.addonName}/{self.addonName}-{self.OfficialVersion}.zip"
        self.resolveUrlLinkZipB = "https://github.com/Gujal00/ResolveURL/archive/refs/heads/master.zip"  # taka beta, zawsze najnowsza
        # xbmc.log(f"[checker]      {self.LocalVersion=}", 1)


    def getOfficialResolveUrlVersion(self):
        try:
            from ptw.libraries import cache
            import requests
            # content = requests.get(self.resolveUrlLink, verify=False, timeout=10).text
            content = cache.get(requests.get, 1, self.resolveUrlLink, kwargs={"verify":False, "timeout":10}, callback=".text")
            resolveUrlVersion = re.findall(r"ResolveURL\" version=\"(.*?)\"", content)[0]
            xbmc.log(f"[checker]      {resolveUrlVersion=}", 1)
            return resolveUrlVersion
        except Exception as e:
            xbmc.log(f"[checker] {e}", 1)
            xbmc.log( "[checker] Can't get resolveUrl version from official repo", xbmc.LOGERROR, )
            return


    def getInstalledResolveUrlVersion(self):
        try:
            self.setResolveUrlOnOff(enabled=True)
            resolveUrlAddon = xbmcaddon.Addon(self.addonName)
            resolveUrlAddonVersion = resolveUrlAddon.getAddonInfo("version")
            xbmc.log(f"[checker] {resolveUrlAddonVersion=}", 1)
            return resolveUrlAddonVersion
        except Exception as e:
            xbmc.log(f"[checker] {e}", 1)
            xbmc.log( "[checker] Can't get resolveUrl version from kodi installation", xbmc.LOGERROR, )
            return "0.0.0"


    def checkVersion(self):
        # from packaging.version import parse
        if self.OfficialVersion and self.LocalVersion != self.OfficialVersion and parse(self.OfficialVersion) > parse(self.LocalVersion):
            if xbmcaddon.Addon().getSetting('resolverUpdateConfirm') == "true":
                dialog = xbmcgui.Dialog()
                ret = dialog.yesno("FanFilm",
                    "Czy zaktulizować ResolveURL do najnowszej oficjalnej wersji?", )
            else:
                ret = True
            if ret:
                self.installResolveUrl()


    def installBetaVersion(self, beta=1):
        dialog = xbmcgui.Dialog()
        if beta:
            ret = dialog.yesno('"beta" wersja Resolvera',
                'Czy chcesz pobrać najnowszą wersję "betę" ResolveURL?', )
        else:
            ret = dialog.yesno('oficjalna wersja Resolvera',
                'Czy chcesz pobrać najnowszą oficjalną wersję ResolveURL?', )
        if ret:
            dialog = xbmcgui.Dialog()
            dialog.notification(heading="FanFilm", message='proszę poczekać ...')
            # ResolveUrlChecker.busy()
            self.busy()
            try:
                self.installResolveUrl(beta=beta)
            except Exception as e:
                xbmc.log(f"[checker] {e}", xbmc.LOGERROR)
                xbmc.log(f"[checker] installBetaVersion fails  |  {beta=}", 1)
                # ResolveUrlChecker.idle(2)
                self.idle(2)
                # dialog = xbmcgui.Dialog()
                dialog.notification("FanFilm", 'wystąpił jakiś błąd przy instalacji Bety Resolvera', xbmcgui.NOTIFICATION_ERROR, 3000)
                return False
            # ResolveUrlChecker.idle(2)
            self.idle(2)


    def removeResolveUrl(self):
        addonPath = xbmcvfs.translatePath("special://home/addons/script.module.resolveurl")
        if os.path.isdir(addonPath):
            self.setResolveUrlOnOff(enabled=False)
            xbmc.log("[checker] Usunięcie obecnego dodatku script.module.resolveurl z dysku", 1)
            shutil.rmtree(addonPath, ignore_errors=False)


    def installResolveUrl(self, beta=0):
        xbmc.log("[checker] Przygotowanie do instalacji dodatku script.module.resolveurl" + f" | {beta=}", 1)
        dialog = xbmcgui.Dialog()
        if beta:
            dialog.notification(heading="FanFilm", message=f"Instalacja wersji beta ResolveURL'a ...")
        else:
            dialog.notification(heading="FanFilm", message=f"Aktualizacja ResolveURL'a ...")
        unzipPath = xbmcvfs.translatePath("special://home/addons/")
        if not beta:
            zipPath = self.download_file(self.resolveUrlLinkZip)
        else:
            zipPath = self.download_file(self.resolveUrlLinkZipB)
        if zipPath:
            try:
                self.removeResolveUrl()
            except Exception as e:
                xbmc.log(f"[checker] {e}", xbmc.LOGERROR)
                pass
            stat = self.unzip_addon(zipPath, unzipPath, beta=beta)
            self.removeZipFile(zipPath)
            if stat is not False:
                self.closeKodi(beta)
        else:
            dialog = xbmcgui.Dialog()
            dialog.notification("FanFilm", 'wystąpił jakiś błąd przy aktualizacji Resolvera', xbmcgui.NOTIFICATION_ERROR, 3000)
            return False


    def download_file(self, url):
        xbmc.log("[checker] Pobieranie pliku instalacyjnego dodatku script.module.resolveurl", 1)
        try:
            localFileName = url.split("/")[-1]
            addonsDirectory = xbmcvfs.translatePath("special://home/addons/")
            import requests
            with requests.get(url, stream=True) as r:
                r.raise_for_status()
                with open(os.path.join(addonsDirectory, localFileName), "wb") as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)
            return os.path.join(addonsDirectory, localFileName)
        except Exception as e:
            xbmc.log(f"[checker] {e}", xbmc.LOGERROR)
            xbmc.log( "[checker] Downloading addon fails", 1)
            return False


    def unzip_addon(self, path_to_zip_file, directory_to_extract_to, beta=0):
        xbmc.log('[checker] Rozpakowanie pobranego pliku zip ("instalacja") dodatku script.module.resolveurl', 1)
        try:
            if not os.path.exists(directory_to_extract_to):
                os.makedirs(directory_to_extract_to)

            with zipfile.ZipFile(path_to_zip_file, "r") as zip_ref:

                if not beta:
                    zip_ref.extractall(directory_to_extract_to)

                else:  # beta
                    for file in zip_ref.namelist():
                        if file.startswith('ResolveURL-master/script.module.resolveurl/'):
                            # xbmc.log(f"[checker] extract {file=}", 1)
                            zip_ref.extract(file, directory_to_extract_to)

                    os.rename(f'{directory_to_extract_to}/ResolveURL-master/script.module.resolveurl', f'{directory_to_extract_to}/script.module.resolveurl')

                    shutil.rmtree(f'{directory_to_extract_to}/ResolveURL-master', ignore_errors=True)

                    # with open(f'{directory_to_extract_to}/script.module.resolveurl/beta.txt', "w") as f:
                        # f.write('Beta')
                    with open(f'{directory_to_extract_to}/script.module.resolveurl/addon.xml', encoding='utf-8') as f:
                        content = f.read()

                    def zmien_numer_wersji(match):
                        version = match[1].split(".")
                        version[-1] = str(int(version[-1]) + 1)
                        version = ".".join(version)

                        import time
                        timestamp = time.time()
                        local_time = time.localtime(timestamp)
                        #formatted_time = time.strftime("%Y-%m-%d %H:%M", local_time)
                        formatted_time = time.strftime("%Y%m%d%H%M", local_time)
                        return f'{version}~beta{formatted_time}'

                    content = re.sub(r'(?<=ResolveURL" version=")(.*?)(?=")', zmien_numer_wersji, content, 1)
                    if content:
                        with open(f'{directory_to_extract_to}/script.module.resolveurl/addon.xml', 'w', encoding='utf-8') as f:
                            f.write(content)

        except Exception as e:
            xbmc.log(f"[checker] {e}", xbmc.LOGERROR)
            xbmc.log("[checker] Unpacking addon fails", 1)
            import traceback
            # import xbmc
            xbmc.log(f'\n{traceback.format_exc()}',1)
            dialog = xbmcgui.Dialog()
            dialog.notification("FanFilm", 'wystąpił jakiś błąd przy aktualizacji Resolvera', xbmcgui.NOTIFICATION_ERROR, 3000)
            return False


    def removeZipFile(self, zipFilePath):
        try:
            xbmc.log("[checker] Usunięcie pobranego pliku instalacyjnego dodatku script.module.resolveurl", 1)
            # zipFilePath = xbmcvfs.translatePath(f"special://home/addons/script.module.resolveurl-{self.OfficialVersion}.zip")
            os.remove(zipFilePath)
        except Exception as e:
            xbmc.log(f"[checker] {e}", xbmc.LOGERROR)
            xbmc.log("[checker] removeZipFile fails", 1)
            return False


    def closeKodi(self, beta=0):
        xbmc.sleep(200)
        try:
            self.setResolveUrlOnOff(enabled=True)
        except Exception:
            pass
        xbmc.log("[checker] odświeżam informacje o wtyczkach", 1)
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.sleep(1500)  # na wolnych sprzętach i dużej ilości zainstalowanych dodatków może być potrzeba zwiększenia tego czasu
        self.LocalVersion = self.getInstalledResolveUrlVersion()
        # xbmc.log(f"[checker]      {self.LocalVersion=}", 1)
        if not beta and self.LocalVersion != self.OfficialVersion:
            xbmc.log("[checker] potrzeba restartu Kodi (ResolveUrlChecker)", 1)
            choice = xbmcgui.Dialog().ok("Zamknięcie", "Kodi musi zostać zamknięte, aby aktualizacja Resolvera została zatwierdzona")
            if choice == 1:
                xbmc.log("[checker] Kodi zostanie zamknięte (ResolveUrlChecker)", 1)
                os._exit(1)
            else:
                xbmc.log("[checker] rezygnacja użytkownika z potrzeby restartu Kodi (ResolveUrlChecker)", 1)
                xbmc.executebuiltin("Action(Close)")
        else:
            dialog = xbmcgui.Dialog()
            if beta:
                dialog.notification(heading="FanFilm", message=f'Zainstalowano najnowszą "betę" Resolvera')
            else:
                dialog.notification(heading="FanFilm", message=f"Zaktualizowano ResolveURL do {self.LocalVersion}")
            xbmc.log("[checker] nie ma potrzeby ponownego uruchamiania Kodi (ResolveUrlChecker)", 1)
            pass


    def setResolveUrlOnOff(self, enabled=True):
        if enabled:  # włączyć
            xbmc.log("[checker] Włączenie (jeśli nie włączony) dodatku script.module.resolveurl", 1)
            xbmc.executeJSONRPC(
                f'{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{{"addonid": "{self.addonName}","enabled":true}}}}')
        else:  # wyłączyć
            xbmc.log("[checker] Wyłączenie dodatku script.module.resolveurl", 1)
            xbmc.executeJSONRPC(
                f'{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{{"addonid": "{self.addonName}","enabled":false}}}}')
        xbmc.sleep(100)  # nie wiem, czy potrzeba


    @staticmethod
    def busy():
        Kodi = xbmc.getInfoLabel("System.BuildVersion")[:2]
        try:
            Kodi = int(Kodi)
            if Kodi > 17:
                if not xbmc.getCondVisibility("Window.IsActive(busydialognocancel)") and not xbmc.getCondVisibility("Window.IsActive(busydialog)"):
                    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")  # Kodi 18
            else:
                if not xbmc.getCondVisibility("Window.IsActive(busydialog)"):
                    xbmc.executebuiltin("ActivateWindow(busydialog)")  # Kodi 17
        except Exception:
            pass


    @staticmethod
    def idle(mode=0):
        if mode != 2 and xbmc.getCondVisibility("Window.IsActive(busydialog)"):
            xbmc.executebuiltin("Dialog.Close(busydialog)")  # Kodi 17
        if mode != 1 and xbmc.getCondVisibility("Window.IsActive(busydialognocancel)"):
            xbmc.executebuiltin("Dialog.Close(busydialognocancel)")  # Kodi 18


class parse:
    def __init__(self, v_str):
        # Rozdzielamy na cyfry i resztę po tyldzie
        parts = v_str.split('~', 1)
        self.base = [int(x) for x in parts[0].split('.')]
        self.has_tilde = '~' in v_str
        self.suffix = parts[1] if self.has_tilde else ""

    def __lt__(self, other):
        # Najpierw porównujemy cyfry (np. 1.2.0)
        if self.base != other.base:
            return self.base < other.base
        # Jeśli cyfry są równe, wersja Z tyldą jest mniejsza (starsza)
        if self.has_tilde != other.has_tilde:
            return self.has_tilde  # True (ma tyldę) oznacza, że jest mniejsza
        # Jeśli obie mają tyldę, decyduje tekst
        return self.suffix < other.suffix

    def __gt__(self, other): return other < self
    def __eq__(self, other): return self.base == other.base and self.has_tilde == other.has_tilde and self.suffix == other.suffix
