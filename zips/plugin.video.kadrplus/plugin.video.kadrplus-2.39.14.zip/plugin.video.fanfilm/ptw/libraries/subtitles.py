# -*- coding: utf-8 -*-

"""
    FanFilm Add-on
    Obsługa napisów przez OpenSubtitles REST API v1
    https://opensubtitles.stoplight.io/docs/opensubtitles-api

    Stare API XML-RPC zostało wyłączone przez OpenSubtitles w 2023 roku.
    Nowe API wymaga darmowego klucza API (rejestracja na opensubtitles.com).
    Limity: 5 pobrań/dzień (bez loginu) lub 20/dzień (z loginem darmowego konta).
"""

import os
import re
import zipfile

import requests
import xbmc
import xbmcvfs

from ptw.libraries import control
from ptw.debug import fflog, fflog_exc

# Adres nowego REST API
OS_API_URL = "https://api.opensubtitles.com/api/v1"

# Mapowanie nazw języków na kody ISO 639-1 (wymagane przez nowe API)
LANG_MAP = {
    "Polish":             "pl",
    "English":            "en",
    "German":             "de",
    "French":             "fr",
    "Spanish":            "es",
    "Italian":            "it",
    "Russian":            "ru",
    "Czech":              "cs",
    "Slovak":             "sk",
    "Hungarian":          "hu",
    "Romanian":           "ro",
    "Bulgarian":          "bg",
    "Croatian":           "hr",
    "Serbian":            "sr",
    "Slovenian":          "sl",
    "Ukrainian":          "uk",
    "Dutch":              "nl",
    "Portuguese":         "pt",
    "Portuguese(Brazil)": "pt-BR",
    "Swedish":            "sv",
    "Norwegian":          "no",
    "Danish":             "da",
    "Finnish":            "fi",
    "Greek":              "el",
    "Turkish":            "tr",
    "Arabic":             "ar",
    "Hebrew":             "he",
    "Chinese":            "zh",
    "Japanese":           "ja",
    "Korean":             "ko",
}


def _get_api_key():
    """Zwróć klucz API użytkownika z ustawień."""
    return control.setting("opensubtitles.apikey").strip()


def _get_headers(token=None):
    """Nagłówki HTTP wymagane przez nowe API."""
    headers = {
        "Api-Key": _get_api_key(),
        "Content-Type": "application/json",
        "User-Agent": "FanFilm v1",
        "Accept": "application/json",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _login():
    """
    Zaloguj się do OpenSubtitles i zwróć token sesji.
    Logowanie jest opcjonalne - zwiększa limit pobrań z 5 do 20/dzień.
    Zwraca None jeśli brak danych logowania lub logowanie nieudane.
    """
    username = control.setting("opensubtitles.user").strip()
    password = control.setting("opensubtitles.pass").strip()

    if not username or not password:
        fflog("OpenSubtitles: brak loginu/hasła - działam bez logowania (limit 5 pobrań/dzień)", 1)
        return None

    try:
        resp = requests.post(
            f"{OS_API_URL}/login",
            json={"username": username, "password": password},
            headers=_get_headers(),
            timeout=10,
        )
        if resp.status_code == 200:
            token = resp.json().get("token")
            fflog(f"OpenSubtitles: zalogowano jako {username}", 1)
            return token
        else:
            fflog(f"OpenSubtitles: błąd logowania {resp.status_code}", 1)
            return None
    except Exception:
        fflog_exc(1)
        return None


def _search(imdb_id, languages, season=None, episode=None, token=None):
    """
    Wyszukaj napisy przez REST API.
    Zwraca listę wyników lub [] przy błędzie.
    """
    params = {
        "imdb_id": re.sub(r"[^0-9]", "", imdb_id),
        "languages": ",".join(languages),
        "order_by": "download_count",
        "order_direction": "desc",
    }

    if season and episode:
        params["season_number"] = int(season)
        params["episode_number"] = int(episode)
        params["type"] = "episode"
    else:
        params["type"] = "movie"

    try:
        resp = requests.get(
            f"{OS_API_URL}/subtitles",
            params=params,
            headers=_get_headers(token),
            timeout=10,
        )
        if resp.status_code == 200:
            results = resp.json().get("data", [])
            fflog(f"OpenSubtitles: znaleziono {len(results)} napisów dla {imdb_id} [{','.join(languages)}]", 1)
            return results
        elif resp.status_code == 401:
            fflog("OpenSubtitles: błąd 401 - nieprawidłowy klucz API", 1)
        elif resp.status_code == 429:
            fflog("OpenSubtitles: błąd 429 - przekroczono limit zapytań", 1)
        else:
            fflog(f"OpenSubtitles: błąd wyszukiwania {resp.status_code}", 1)
    except Exception:
        fflog_exc(1)

    return []


def _get_download_url(file_id, token=None):
    """
    Pobierz jednorazowy link do pobrania pliku napisów.
    Zwraca URL lub None przy błędzie/przekroczeniu limitu.
    """
    try:
        resp = requests.post(
            f"{OS_API_URL}/download",
            json={"file_id": file_id},
            headers=_get_headers(token),
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json()
            remaining = data.get("remaining_downloads", "?")
            fflog(f"OpenSubtitles: link OK, pozostało pobrań dziś: {remaining}", 1)
            return data.get("link")
        elif resp.status_code == 406:
            fflog("OpenSubtitles: przekroczono dzienny limit pobrań", 1)
            if not control.window.getProperty("blocked_sources_extend") == "break":
                control.infoDialog(
                    "Przekroczono dzienny limit pobrań OpenSubtitles.\n"
                    "Zaloguj się w Ustawieniach > Autoryzacje lub poczekaj do jutra.",
                    "OpenSubtitles - limit",
                    "WARNING",
                    time=7000,
                )
        elif resp.status_code == 429:
            fflog("OpenSubtitles: błąd 429 - zbyt wiele zapytań", 1)
        else:
            fflog(f"OpenSubtitles: błąd pobierania linku {resp.status_code}", 1)
    except Exception:
        fflog_exc(1)

    return None


def _download_subtitle(url, lang_code):
    """
    Pobierz plik z napisami i zapisz w katalogu tymczasowym.
    Obsługuje formaty .srt bezpośrednie i spakowane w .zip.
    Zwraca ścieżkę do pliku .srt lub None przy błędzie.
    """
    try:
        resp = requests.get(url, timeout=15)
        if resp.status_code != 200:
            fflog(f"OpenSubtitles: błąd pobierania pliku {resp.status_code}", 1)
            return None

        temp_dir = xbmcvfs.translatePath("special://temp/")
        content_type = resp.headers.get("Content-Type", "")
        content = resp.content

        # Obsługa archiwum ZIP
        if "zip" in content_type or url.lower().endswith(".zip"):
            zip_path = os.path.join(temp_dir, "TemporarySubs_fanfilm.zip")
            with open(zip_path, "wb") as f:
                f.write(content)
            with zipfile.ZipFile(zip_path, "r") as z:
                srt_files = [n for n in z.namelist() if n.lower().endswith(".srt")]
                if not srt_files:
                    fflog("OpenSubtitles: brak pliku .srt w archiwum", 1)
                    return None
                content = z.read(srt_files[0])

        subtitle_path = os.path.join(temp_dir, f"TemporarySubs_fanfilm.{lang_code}.srt")
        with open(subtitle_path, "wb") as f:
            f.write(content if isinstance(content, bytes) else content.encode("utf-8"))

        fflog(f"OpenSubtitles: napisy zapisane → {subtitle_path}", 1)
        return subtitle_path

    except Exception:
        fflog_exc(1)
        return None


def get(name, imdb, season="", episode=""):
    """
    Główna funkcja - wyszukaj i załaduj napisy do aktualnie odtwarzanego materiału.

    Args:
        name:    tytuł (do logowania)
        imdb:    IMDb ID (np. "tt1234567")
        season:  numer sezonu (puste dla filmów)
        episode: numer odcinka (puste dla filmów)
    """
    try:
        # Sprawdź czy funkcja jest włączona
        if control.setting("opensubtitles.enable") != "true":
            return

        # Sprawdź czy jest klucz API
        if not _get_api_key():
            fflog("OpenSubtitles: brak klucza API - ustaw go w Ustawieniach > Autoryzacje", 1)
            return

        # Zbierz żądane języki z ustawień
        languages = []
        for key in ("opensubtitles.lang1", "opensubtitles.lang2"):
            lang_name = control.setting(key)
            lang_code = LANG_MAP.get(lang_name)
            if lang_code and lang_code not in languages:
                languages.append(lang_code)

        if not languages:
            languages = ["pl"]

        fflog(f"OpenSubtitles: szukam napisów '{name}' {imdb} [{','.join(languages)}]", 1)

        # Zaloguj (opcjonalnie)
        token = _login()

        # Wyszukaj
        results = _search(imdb, languages, season or None, episode or None, token)
        if not results:
            fflog(f"OpenSubtitles: brak wyników dla '{name}'", 1)
            return

        # Wybierz najlepszy wynik z priorytetem pierwszego języka
        best = None
        for lang in languages:
            for item in results:
                if item.get("attributes", {}).get("language") == lang:
                    best = item
                    break
            if best:
                break
        if not best:
            best = results[0]

        attrs = best.get("attributes", {})
        lang_code = attrs.get("language", languages[0])
        files = attrs.get("files", [])

        if not files:
            fflog("OpenSubtitles: wybrany wynik nie ma plików", 1)
            return

        file_id = files[0].get("file_id")
        fflog(f"OpenSubtitles: wybrany: {files[0].get('file_name', '?')} [{lang_code}]", 1)

        # Pobierz link do pobrania
        download_url = _get_download_url(file_id, token)
        if not download_url:
            return

        # Pobierz i zapisz plik
        subtitle_path = _download_subtitle(download_url, lang_code)
        if not subtitle_path:
            return

        # Załaduj napisy do odtwarzacza Kodi
        xbmc.sleep(500)
        xbmc.Player().setSubtitles(subtitle_path)
        fflog(f"OpenSubtitles: napisy załadowane [{lang_code}]", 1)

    except Exception:
        fflog_exc(1)
