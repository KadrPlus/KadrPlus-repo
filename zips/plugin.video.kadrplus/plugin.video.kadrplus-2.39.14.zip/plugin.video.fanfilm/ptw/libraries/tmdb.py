# tu można by zamieszczać utils-y związane z tmdb

from ptw.libraries import control


def add_rating(content, tmdb, season, episode):
    try:
        action = "add_rating"
        control.log(f'[FanFilm]  start {action=}',1)

        control.busy()
        control.infoDialog(control.lang(33066), control.lang(33067), sound=False)
        control.window.setProperty("fanfilm.addRating_in_progress", "1")
        control.sleep(1000)

        import requests

        from ptw.libraries import apis
        tm_user = control.setting("tm.user") or apis.tmdb_API

        if content == "episode":
            tmdb_rating_link = f"https://api.themoviedb.org/3/tv/%%s/season/{season}/episode/{episode}/rating?api_key=%s" % tm_user
        else:
            tmdb_rating_link = f"https://api.themoviedb.org/3/{content}/%%s/rating?api_key=%s" % tm_user

        tmdb_sessionid = control.setting("tmdb.sessionid") or ""

        control.busy()
        control.sleep(500)
        if tmdb_sessionid:
            # control.log(f'[FanFilm]  będzie sesja autoryzowanego użytkownika',1)
            tmdb_rating_link += "&session_id=%s" % tmdb_sessionid
            pass
        else:
            # control.busy()
            # control.sleep(500)
            control.log(f'[FanFilm]  sesja dla gościa',1)
            control.infoDialog(control.lang(33068), control.lang(33067), sound=False, time=10000)
            # sprawdzenie, czy jakiejś już nie ma
            # guest_session_id = None
            guest_session_id = control.setting('tmdb.guest_session_id')
            """
            guest_session = control.setting('tmdb.guest_session')
            control.log(f'[FanFilm]  odczytana z ustawień {guest_session=}',1)
            if guest_session:
                try:
                    guest_session = eval(guest_session)
                    guest_session_id = guest_session.get("guest_session_id")
                except:
                    guest_session_id = guest_session
            else:
                guest_session_id = control.setting('tmdb.guest_session_id')
            guest_session = None  # niepotrzebna zmienna już
            """
            if guest_session_id:
                response = None
                # test, czy jeszcze ważny
                url = f'https://api.themoviedb.org/3/guest_session/{guest_session_id}/rated/movies?api_key={tm_user}'
                response = True
                control.busy()
                control.sleep(500)
                response = requests.get(url)
                # response = None
                if response is not None and (response or response.status_code == 404):
                    # klucz sesji ważny
                    control.log(f'[FanFilm]  klucz sesji gościa jest niby ważny',1)
                    # control.log(f'[FanFilm]  klucz sesji gościa jest niby ważny   {response=}  {url=}',1)
                    control.log('[FanFilm]  potrzeba odczekania przed następnym requestem',1)
                    control.busy()
                    control.sleep(9000)  # zwłoka większa
                else:
                    control.log('[FanFilm]  klucz sesji gościa chyba już nie ważny',1)
                    guest_session_id = ""
                    # control.setSetting('tmdb.guest_session', '')
                    control.setSetting('tmdb.guest_session_id', '')
                    control.busy()
                    control.sleep(1000)  # zwłoka
            if not guest_session_id:
                # potrzebny nowy klucz sesji
                control.log('[FanFilm]  potrzebny nowy klucz sesji gościa',1)
                # control.infoDialog('generowanie nowej sesji gościa', 'Ocena dla TMDB', sound=False)
                control.busy()
                control.sleep(500)
                response = requests.get(f'https://api.themoviedb.org/3/authentication/guest_session/new?api_key={tm_user}')
                if response:
                    response = response.json()
                    control.log(f'[FanFilm]  {response=}',1)
                    if response.get("success") is True:
                        guest_session_id = response.get("guest_session_id")
                        # zachować sesję na godzinę "expires_at": response.get("expires_at")  # https://developer.themoviedb.org/reference/authentication-create-guest-session
                        # control.setSetting('tmdb.guest_session', repr(response))
                        # control.setSetting('tmdb.guest_session', guest_session_id)
                        control.setSetting('tmdb.guest_session_id', guest_session_id)
                    else:
                        control.log(f'[FanFilm]  wystąpił jakiś problem  {response=}  {url=}',0)
                        control.log(f'[FanFilm]  wystąpił jakiś problem  {response=}',1)
                else:
                    control.log(f'[FanFilm]  wystąpił jakiś problem  {response=}  {response.text=}  {url=}  ',0)
                    control.log(f'[FanFilm]  wystąpił jakiś problem  {response=}  {response.text=}',1)
                control.log('[FanFilm]  potrzeba odczekania przed następnym requestem',1)
                control.busy()
                control.sleep(4000)  # zwłoka
            if guest_session_id:
                tmdb_rating_link += "&guest_session_id=%s" % guest_session_id  # link url
            else:
                control.log(f'[FanFilm]  Problem, bo {guest_session_id=}',1)
                control.window.clearProperty("fanfilm.addRating_in_progress")
                control.idle(2)
                return sys.exit()

        url = tmdb_rating_link % tmdb
        # control.log(f'[FanFilm]  {url=}',1)

        # control.busy()
        # control.sleep(500)
        import xbmcgui
        while True:
            control.busy()
            control.sleep(500)
            control.log(f'[FanFilm]  oczekiwanie na wprowadzenie cyfr przez użytkownika',1)
            # s = xbmcgui.Dialog().input("wpisz ocenę TMDB\n(1-10 lub 11-100)", type=xbmcgui.INPUT_NUMERIC)
            s = xbmcgui.Dialog().numeric(0, "wpisz ocenę TMDB\n(1-10 lub 11-100)")  # chyba to samo
            if not s or 0 <= int(s) <= 100:
                break
            if not xbmcgui.Dialog().yesno('Niepoprawna wartość', (f"Wpisana wartość [B]{s}[/B] jest nieprawidłowa. \nCzy chcesz poprawić?")):
                s = ''
                break
        control.window.clearProperty("fanfilm.addRating_in_progress")  # już tu mogę przewać blokadę
        if s:
            control.busy()
            control.sleep(500)
            # dodatkowy komunikat
            # control.log('[FanFilm]  proszę czekać ...',1)
            control.infoDialog(control.lang(33071), control.lang(33067), sound=False, time=5000)
            if not tmdb_sessionid:
                control.log('[FanFilm]  potrzeba odczekania 5s przed następnym requestem',1)
                control.busy()
                control.sleep(5000)  # zwłoka potrzebna
                pass
            else:
                control.log('[FanFilm]  potrzeba odczekania 4s przed następnym requestem',1)
                control.busy()
                control.sleep(4000)
                pass

            rating = s
            # control.log(f'[FanFilm]  {rating=}',1)
            rating = int(rating)
            if rating:
                if rating > 10:
                    rating = rating / 10
                    # rating = round(rating, 1)
                    rating = round(rating * 2) / 2  # bo musi być podzielna przez 0.5
                control.log(f'[FanFilm]  {rating=}',1)

                payload = {"value": rating}
                control.log(f'[FanFilm]  post',1)
                # control.log(f'[FanFilm]  post {url=}',1)
                control.busy()
                control.sleep(500)
                # tmdb_results = requests.post(url, data=payload)  # do serwera
                tmdb_results = requests.post(url, json=payload)  # do serwera
            else:
                payload = ""
                control.log(f'[FanFilm]  delete',1)
                # control.log(f'[FanFilm]  delete {url=}',1)
                control.busy()
                control.sleep(500)
                tmdb_results = requests.delete(url)  # do serwera
        else:
            control.log(f'[FanFilm]  anulowanie operacji {action=}',1)
            tmdb_results = None

        if tmdb_results is not None:
            icon = ""
            if not tmdb_results:
                if tmdb_results.status_code != 404:
                    # control.log(f'[FanFilm]  wystąpił jakiś problem  {tmdb_results=}  {url=}  {payload=}  {tmdb_results.text=}',1)
                    control.log(f'[FanFilm]  wystąpił jakiś problem  {tmdb_results=}  {payload=}  {tmdb_results.text=}',1)
                    icon = "ERROR"
                else:
                    icon = "WARNING"
                    # control.log(f'[FanFilm]  być może była nie dawno robiona ocena',1)
                    monitor = control.monitor
                    counter = 10
                    while counter > 0 and tmdb_results.status_code == 404:
                        try:
                            status_code = tmdb_results.json().get("status_code")
                            if status_code not in [34]:  # https://developer.themoviedb.org/docs/errors
                                break
                        except:
                            break
                        counter -= 1
                        control.log(f'[FanFilm]  czekam przed ponowieniem żądania do serwera  {counter=}',1)
                        control.busy()
                        control.sleep(5000)
                        if monitor.abortRequested():
                            break
                        control.busy()
                        control.sleep(500)
                        if payload:
                            # tmdb_results = requests.post(url, data=payload)
                            tmdb_results = requests.post(url, json=payload)
                        else:
                            tmdb_results = requests.delete(url)
                if tmdb_results:
                    icon = ""
                tmdb_results = tmdb_results.json()  # format json, czyli słownik będzie w Pythonie
            control.log(f'[FanFilm]  {tmdb_results=}  {{tmdb_results.text=}}',1)
            try:
                import json  # dla poniższego tylko
                control.log(f'[FanFilm]  tmdb_results={json.dumps(tmdb_results, indent=2)}',0)
                pass
            except:
                pass
            # dać komunikat
            control.infoDialog((control.lang(33070) if icon else control.lang(33069)), control.lang(33067), sound=True, icon=icon)

        control.window.clearProperty("fanfilm.addRating_in_progress")
        control.idle(2)
        # przydałoby się jeszcze dorobić usunięcie z cache listy ocenionych

    except Exception:
        control.window.clearProperty("fanfilm.addRating_in_progress")
        control.idle(2)
        from ptw.debug import fflog_exc
        fflog_exc(1)
