# https://stackoverflow.com/questions/66514500/how-do-i-configure-a-python-server-for-post

#!/usr/env python3
# import http.server
# import os
# import logging

try:
    import http.server as http_server
except ImportError:
    # Handle Python 2.x
    # import SimpleHTTPServer as server
    pass


def fflog(msg, level=1, cos=1):
    print(msg)
    pass

def fflog_exc(level=1):
    import traceback
    print(f'EXCEPTION: \n{traceback.format_exc()}')

try:
    import xbmc  # pod monitor potrzebne
    # import xbmcaddon
    from ptw.debug import fflog_exc, fflog
    from ptw.libraries import control
    # control.setting = xbmcaddon.Addon().getSetting
    # control.setSetting = xbmcaddon.Addon().setSetting
except:
    xbmc = None
    control = None
    pass

import json

# potrzebne do uzupełniania wartości w Ustawieniach wtyczki
web_server_cookies = {

    'cda-hd.cc': {
        ':user_agent':  'cdahd.ua',
        'cf_clearance': 'cdahd.cf',
    },

    'filman.cc': {
        ':user_agent':  'filman_web.USER_AGENT',
        'BKD_REMEMBER': 'filman_web.cookies',
        'cf_clearance': 'filman_web.cookies.cf',
    },

    'zaluknij.cc': {
        ':user_agent':  'zaluknijcc.ua',
        'cf_clearance': 'zaluknijcc.cf',
    },
}

if 1:
    from pathlib import Path
    www_folder = Path(__file__).parent / 'resources/web'
    # fflog(f'{type(www_folder)=}  {www_folder=}')



class HTTPRequestHandler(http_server.SimpleHTTPRequestHandler):

    if 1:
        pass
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=str(www_folder), **kwargs)
            pass


    def do_GET(self):
        fflog(f'\n') if not control else ""
        # fflog(f'{dir(self)=}')
        for i in dir(self):
            # print(i, ": ", getattr(self, i ) )
            # fflog(f' {i}: {getattr(self, i)}' )
            pass

        # print(self.request.getsockname()[0])  # https://stackoverflow.com/questions/57511973/with-http-server-how-to-access-the-called-ip-address
        # logging.warning(self.headers)
        fflog(self.requestline)
        # fflog(self.headers)
        # if self.path.startswith('/kill_server'):
            # print "Server is going down, run it again manually!"
            # self.server._BaseServer__shutdown_request = True
            # setattr(self.server, '_BaseServer__shutdown_request', True)
            # return
        if 0:
            try:
                length = int(self.headers["Content-Length"])
                path = self.translate_path(self.path)
                fflog(f'{path=}',1,1)
                fflog(self.rfile.read(length),1,1)
                if False:
                    with open(path, "wb") as dst:
                        dst.write(self.rfile.read(length))
                        pass
            except Exception:
                # fflog_exc(1)
                pass
        try:
            # print(f'{self.headers["Content-Length"]=}')
            # fflog(f'{self.directory=}')
            # fflog(f'{self.path=}')
            # fflog(f'{dir(self.headers)=}')
            # fflog(f'{self.headers.items()=}')
            # fflog(f'{self.headers=}')  # to nie (<http.client.HTTPMessage object at 0x0000021D51BEA280>)
            # fflog(f'{str(self.headers)=}')  # to w 1 linijce pokazuje
            # fflog(f'{self.headers}')  # to najlepsze
            if 1:
                if self.path == "/credentials":
                    # fajnie byłoby najpierw sprawdzić czy hasło jest ok i wtedy zwrócić dane
                    content = self.list_of_some_settings()
                    # https://stackoverflow.com/a/69492832
                    self.send_response(200)
                    self.send_header('Content-type','application/json')
                    self.end_headers()
                    message = json.dumps(content)
                    self.wfile.write(message.encode('utf-8'))
                else:
                # if self.path == "/" or self.path == "/index.html":
                    # http_server.SimpleHTTPRequestHandler.do_GET(self)
                    super().do_GET()
            else:
                self.send_response(200)
                self.send_header('Content-type','text/html')
                self.end_headers()
                message = "Hello, FanFilm World!"
                self.wfile.write(bytes(message, "utf8"))
        except Exception as e:
            # fflog_exc(1)
            fflog(f'error: {str(e)}',1,1)
            pass


    def korekty_kluczy(self, k):
        if k.startswith("filman"):
            k = k.replace("filman.", "filman_web.").replace("cookies_cf", "cookies.cf").replace("user_agent", "USER_AGENT")
        elif k.startswith("cdahd") or k.startswith("zaluknij"):
            k = k.replace("cookies_cf", "cf").replace("user_agent", "ua").replace("zaluknij.", "zaluknijcc.")
        else:
            # fflog(f'niedozwolone {k=}',1,1)
            # k = ""
            pass
        return k

    ALLOWED_SETTINGS = ['cdahd.cookies_cf', 'cdahd.user_agent',
                        'filman.cookies', 'filman.cookies_cf', 'filman.user_agent',
                        'zaluknij.cookies_cf', 'zaluknij.user_agent',
                        # 'stalkervod.server_address', 'stalkervod.mac_address',
                        {'words.disallowed': 'Filtry źródeł.Unikaj fraz'},
                       ]
    ALLOWED_SETTINGS = {k: v for el in ALLOWED_SETTINGS for k, v in (el.items() if isinstance(el, dict) else [(el, "")])}  # słownik

    def list_of_some_settings(self):
        settings = self.ALLOWED_SETTINGS
        # settings = [{"name": k} for k in settings]  # gdy lista
        settings = [{"name": k, "label": v} for k, v in settings.items()]  # gdy słownik
        content = {"settings": settings}
        import xbmcaddon
        control.setting = xbmcaddon.Addon().getSetting
        for s in content.get("settings"):
            k = s.get("name")
            k1 = self.korekty_kluczy(k)
            if k1:
                # s.update({"value": control.setting( k1 )})
                s["value"] = control.setting( k1 )
                if l := s.get("label"):
                    s["section"] = l.split(".")[0]
                    s["label"] = l.split(".")[-1]
                else:
                    s["section"] = k.split(".")[0]
                    s["label"] = k.split(".")[-1]
                s['cookie'] = ':user_agent' if k.endswith('user_agent') else ""
                # s["name"] = k1 #albo k1  ale chyba nie trzeba
            else:
                fflog(f'problem, bo {k=} jest niedozwolone',1,1)
                pass
        # fflog(f'content={json.dumps(content, indent=2)}',1,1)
        return content


    def do_POST(self):
        """Save a file following a HTTP POST request"""
        fflog(f'\n') if not control else ""
        fflog(self.requestline)
        # logging.warning(self.headers)
        fflog (self.headers,1,1)

        fflog(f'{self.path=}',1,1)

        import os
        filename = os.path.basename(self.path)
        # print(f'{filename=}')

        if self.path != '/cookies' and self.path != '/credentials':
            fflog("nieobsługiwana ścieżka")
            return

        content = ""
        try:
            file_length = int(self.headers['Content-Length'])
            content = self.rfile.read(file_length)
            # print(f'{content=}')
            # import json  # dałem na górze
            content = json.loads(content)
            # print('content=', json.dumps(content, indent=2),1,1)
            # xbmc.log(f'content={json.dumps(content, indent=2)}',0) if xbmc else ""
            fflog(f'{len(content)=}',1,1)
            fflog(f'content={json.dumps(content, indent=2)}',0,1)
        except Exception as exc:
            fflog_exc(1)
            # import traceback
            # print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}')
            # xbmc.log(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}',1) if xbmc else ""
            pass

        if content:
            # from ptw.libraries import control
            data = content

            settings_count = 0  # do kontroli tylko
            host = ""

            if self.path == '/cookies':  # od skryptu z wtyczki TamperMonkey
                if host := data.get('host'):
                    fflog(f'{host=}',1,1)
                    if conv := web_server_cookies.get(host):
                        # fflog(f'{conv=}',1,1)
                        cookies = {name: value for cookie in data.get('cookies', []) if (name := cookie.get('name')) and (value := cookie.get('value'))}
                        cfs = [c for c in data.get('cookies') if c.get("name")=="cf_clearance" and c.get("secure")]
                        if cfs:
                            cookies = {**cookies, "cf_clearance": cfs[0]["value"]}
                        # fflog(f'{cookies=}',1,1)
                        for cookie_name, settings_name in conv.items():
                            # fflog(f'{cookie_name=}  {settings_name=}',1,1)
                            if cookie_name == ':UA':  # user-agent
                                cookie_name = ':user_agent'
                            try:
                                if cookie_name.startswith(':'):  # meta, ex: user-agent
                                    control.setSetting(settings_name, data.get(cookie_name[1:], ''))
                                    settings_count += 1
                                else:
                                    control.setSetting(settings_name, cookies.get(cookie_name, ''))
                                    settings_count += 1
                            except Exception:
                                fflog_exc(1)
                                control.infoDialog(f"błąd podczas aktualizowania ciasteczek dla {host}", icon="ERROR")
                                pass

            elif self.path == '/credentials':  # od strony www (formularz)
                allowed_settings = self.ALLOWED_SETTINGS
                for s in content.get("settings"):
                    k = s.get("name")
                    if k in allowed_settings:
                        k = self.korekty_kluczy(k)
                    elif (k := self.korekty_kluczy(k)) in allowed_settings:
                        pass
                    else:
                        k = ""
                    if k:
                        v = s.get("value")  # wartość
                        if v or 1:  # czy dopuszczalne jest wyczyszczenie ustawienia?
                            # fflog(f'{k=} {v=}',1,1)
                            control.setSetting(k, v)
                            settings_count += 1
                    else:
                        if k == s.get("name"):
                            fflog(f'niedozwolone {k=}',1,1)
                        else:
                            fflog(f'niedozwolone {k=} lub {s.get("name")=}',1,1)

            # settings_count = 0
            fflog(f'{settings_count=}',1,1)
            # xbmc.log(f'{settings_count=}',1) if xbmc else ""
            if settings_count:
                if host:
                    control.infoDialog(f"zaktualizowano ciasteczka dla {host}")
                    fflog(f"zaktualizowano ciasteczka dla {host}",1,1)
                    self.send_response(200, 'OK')
                    self.end_headers()
                    reply_body = 'zapisano'
                    self.wfile.write(reply_body.encode('utf-8'))
                    return
                else:
                    control.infoDialog('zaktualizowano "ciasteczka" i inne dane')
                    # content = self.list_of_some_settings()  # a po co pobierać?
                    # https://stackoverflow.com/a/69492832
                    self.send_response(200)
                    self.send_header('Content-type','application/json')
                    self.end_headers()
                    message = json.dumps(content)
                    self.wfile.write(message.encode('utf-8'))
                    return
            else:
                # if 0:
                    # return {
                        # 'success': True,
                        # 'settings_count': settings_count,
                    # }
                self.send_response(200, 'OK')  # chyba komunikat zwrotny dla skryptu z TamperMonkey i formularza
                self.end_headers()
                reply_body = 'nic nie zapisano'
                self.wfile.write(reply_body.encode('utf-8'))
                return
        else:
            self.send_response(200, 'No data received')
            self.end_headers()
            reply_body = 'brak danych do zapisania'
            self.wfile.write(reply_body.encode('utf-8'))
            return

        r"""
        if 0:  # bo chyba już nieaktualne
            # Don't overwrite files
            if os.path.exists(filename):
                self.send_response(409, 'Conflict')
                self.end_headers()
                reply_body = '"%s" already exists\n' % filename
                self.wfile.write(reply_body.encode('utf-8'))
                return
            if content:
                # file_length = int(self.headers['Content-Length'])
                try:
                    with open(filename, 'wb') as output_file:
                        # output_file.write(self.rfile.read(file_length))
                        output_file.write(content)

                    self.send_response(201, 'Created')
                    self.end_headers()
                    reply_body = 'Saved "%s"\n' % filename
                    self.wfile.write(reply_body.encode('utf-8'))
                except Exception as exc:
                    fflog_exc(1)
                    # import traceback
                    # print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}')
                    # xbmc.log(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}',1) if xbmc else ""
                    pass
            else:
                self.send_response(200, 'No data')
                self.end_headers()
                reply_body = 'brak danych do zapisania'
                self.wfile.write(reply_body.encode('utf-8'))
                return
        """


import re

try:
    monitor = xbmc.Monitor()
except:
    pass


def IPAddress(recurency=0):
    if 1:
        try:
            ip_address = control.infoLabel('Network.IPAddress') if control else ""
            if not re.search(r'(\d{1,3}\.){4}', ip_address+".") and recurency < 10 and control:
                monitor.waitForAbort(1)
                recurency += 1
                IPAddress(recurency)
            else:
                fflog(f"Kodi {ip_address=}  ({recurency})", 1)
                pass
        except Exception:
            fflog_exc(1)
            pass


# force_stop = None


def check_if_not_running(port):
    """ https://stackoverflow.com/a/51097316 """
    import socket
    sock = socket.socket()
    sock.settimeout(2)  # this prevents a 2 second lag when starting the server
    result = sock.connect_ex(('127.0.0.1', port))
    sock.close()
    if result == 0:
        fflog(f"Sorry, {port=} already in use.",1,1)
        fflog('nowy serwer na tym porcie nie zostanie uruchomiony',1,1)
        if control:
            control.infoDialog(f"port {port} jest zajęty - serwer http nie zostanie uruchomiony", time=3000)
            # jak sprawdzić, czy to ten od FanFilm a nie inny?
            if control.window.getProperty('FanFilm.httpserver.status'):
                # control.setSetting('http_server.status', 'uruchomiony')
                pass
        exit()
    # print(f"{port=} dostępny")
    return True


def start(silent=True):
    fflog(f'\n') if not control else ""

    if control:
        if control.window.getProperty('FanFilm.httpserver.status'):
            fflog(f'prawdopodobnie już serwer (na jakimś porcie) jest uruchomiony',1,1)
            # control.setSetting('http_server.status', 'uruchomiony')
            return
    
    IPAddress()  # może dać w wątek, bo blokuje dalsze wykonywanie programu

    try:
        port = int(control.setting("http_server.port"))
        if port and not( 1024 < port < 65536 ):
            fflog(f'nieprawidłowy zakres portu {port=} - powinien być w przedziale 1025-65535')
            if not silent:
                if control:
                    control.infoDialog(f"nieprawidłowy zakres portu (powinien być w przedziale 1025-65535)", time=3000)
            return
        elif port == 0:
            fflog(f'serwer http nie będzie uruchamiany, bo {port=}')
    except:
        if not control:
            port = 8663
        else:
            fflog(f'podano nieprawidłowy {port=} - powinien być w przedziale 1025-65535')
            return

    if not check_if_not_running(port):
        fflog(f'{port=} zajęty - prawdopodobnie serwer jest już uruchomiony',1,1)
        return


    # global force_stop
    # force_stop = False
    try:
        control.window.clearProperty('FanFilm.httpserver.force_stop')
    except:
        pass

    try:
        # xbmc.log('starting httpserver.py', 1) if xbmc else ""
        fflog('starting httpserver', 1,1)
    except:
        print('starting httpserver')

    if 0:
        # server = http_server
        http_server.test(HandlerClass=HTTPRequestHandler, port=port, bind='0.0.0.0')
        # After running this program locally you can try connecting using a Web browser to port http://localhost:8000.
        # ta metoda "test" ma trochę ograniczeń, więcej możliwości daje uruchomienie serwera za pomocą serve_forever
        # okazuje się, że metoda test też wywołuje serwer za pomocą serve_forever
    else:
        with http_server.HTTPServer(('', port), HTTPRequestHandler) as server:
            # print(f'{dir(server)=}')
            for i in dir(server):
                # print(i, ": ", getattr(server, i ) )
                pass
            # print(f'{server.server_address=}')
            fflog(f'{server.server_name=}')
            fflog(f'{server.server_port=}')
            try:
                fflog('zmieniam status serwera na "uruchomiony"')
                # control.setSetting('http_server.status', 'uruchomiony')
                # xbmcaddon.Addon().setSetting('http_server.status', 'uruchomiony')
                # control.setSetting('http_server.name', server.server_name)
                # control.window.setProperty('FanFilm.httpserver.name', server.server_name)  # do pamięci
                # control.window.setProperty('FanFilm.httpserver.status', 'uruchomiony')  # do pamięci
                # control.window.setProperty('FanFilm.httpserver.status', f'[B]uruchomiony[/B] ({port=}, nazwa: [B]{server.server_name}[/B])')  # do pamięci
                control.window.setProperty('FanFilm.httpserver.status', f'[B]uruchomiony[/B] ({port=})')  # do pamięci
            except Exception:
                if control:
                    fflog_exc(1)
                    pass

            import threading
            _httpd_thread2 = threading.Thread( target=stop, args=(server,) )
            _httpd_thread2.start()           

            try:
                if not silent:
                    if control:
                        control.infoDialog(f"uruchomiono serwer http na porcie {port}", time=1500)
                server.serve_forever()
                fflog('serwer skończył działanie')
                if control:
                    control.window.clearProperty('FanFilm.httpserver.status')
            except KeyboardInterrupt:
                if control:
                    control.window.clearProperty('FanFilm.httpserver.status')
                # sys.exit(0)
                pass


def stop(server):
    fflog(f'\n') if not xbmc else ""
    try:
        # monitor = xbmc.Monitor()
        # c = 1
        # import time
        force_stop = None
        
        while (
                not (abortRequested := monitor.abortRequested()) 
                and not (force_stop := control.window.getProperty('FanFilm.httpserver.force_stop'))
              ):
            # c -= 1
            # time.sleep(5)
            monitor.waitForAbort(5)

        fflog(f"{force_stop=}  {abortRequested=}",1,1)
        fflog(f'{server.server_port=}',1,1)
        fflog("zatrzymuję serwer http",1,1)
        # xbmc.log("zatrzymuję serwer http",1) if xbmc else ""
        server._BaseServer__shutdown_request = True
        fflog('zmieniam status serwera na "zatrzymany"')
        # control.setSetting('http_server.status', 'zatrzymany')
        if not abortRequested:
            control.infoDialog(f"zatrzymano serwer http ({server.server_port})", time=2000)
            control.window.clearProperty('FanFilm.httpserver.status')
        pass
    except (NameError, AttributeError):
        print("WARNING: Nie uruchomiono z Kodi, bo brak modułu xbmc \n")
        pass


# if 1:
if __name__ == '__main__':
    start()

