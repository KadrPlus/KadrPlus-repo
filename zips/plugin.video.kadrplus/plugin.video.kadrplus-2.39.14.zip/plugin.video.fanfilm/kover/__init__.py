# -*- coding: utf-8 -*-
"""
KOver - Kodi Version unification proxy (wbudowany w Kadr+).
https://github.com/libka-pl/script.module.kover
MIT License
"""

def autoinstall():
    """Patch xbmc* modules to unify K19/K20 API."""
    try:
        import xbmcgui
        # Kodi 20+ compatibility - suppress ListItem.setInfo() deprecation warnings
        _orig_ListItem = xbmcgui.ListItem

        class _ListItem(_orig_ListItem):
            def setInfo(self, type, infoLabels):
                try:
                    tag = self.getVideoInfoTag() if type == 'video' else None
                    if tag:
                        for key, val in infoLabels.items():
                            setter = getattr(tag, f'set{key[0].upper()}{key[1:]}', None)
                            if setter and val is not None:
                                try:
                                    setter(val)
                                except Exception:
                                    pass
                        return
                except Exception:
                    pass
                super().setInfo(type, infoLabels)

        xbmcgui.ListItem = _ListItem
    except Exception:
        pass


__all__ = ['autoinstall']
