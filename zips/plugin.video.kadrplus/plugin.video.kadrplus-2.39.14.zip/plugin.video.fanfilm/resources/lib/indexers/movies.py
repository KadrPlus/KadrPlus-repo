"""
    Fanfilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
def movies():  # wrapper

    import datetime
    import json
    import os
    import re
    import sys
    import urllib
    from threading import Thread, active_count
    from xbmc import Actor, VideoStreamDetail
    from xbmcplugin import addSortMethod, SORT_METHOD_UNSORTED, SORT_METHOD_PLAYLIST_ORDER, SORT_METHOD_LABEL, SORT_METHOD_TITLE, SORT_METHOD_VIDEO_YEAR, SORT_METHOD_DURATION, SORT_METHOD_VIDEO_RATING

    try:
        import urllib.parse as urllib
    except:
        pass
    from resources.lib.indexers import navigator
    from ptw.libraries import cache
    from ptw.libraries import cleantitle
    from ptw.libraries import client
    from ptw.libraries import control
    from ptw.libraries import log_utils
    from ptw.libraries.log_utils import log, fflog, _is_debugging
    from ptw.debug import log_exception, fflog_exc
    from ptw.libraries import playcount
    from ptw.libraries import trakt
    from ptw.libraries import utils
    from ptw.libraries import views
    from ptw.libraries import apis
    from ptw.libraries import source_utils
    from ptw.libraries.utils import convert
    from ptw.libraries import bookmarks


    # tylko, że to się nie zmienia przy kolejnych wywołaniach podstrony
    # params = dict(urllib.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 1 else {}  # nie przetestowałem do końca
    params = dict(urllib.parse_qsl(sys.argv[2].replace("?", ""))) if len(sys.argv) > 1 else dict()
    action = params.get("action")

    monitor = control.monitor

    class movies:
        def __init__(self):
            # fflog("inicjalizacja klasy movies")

            # fix for not always current value
            # global params, action
            # nonlocal params, action
            # params = dict(urllib.parse_qsl(sys.argv[2].replace("?", ""))) if len(sys.argv) > 1 else dict()
            # action = params.get("action")
            # fflog(f'{params=}')  # kontrola

            ### BASE ###
            self.idx = True
            self.next_page = True
            self.meta = None
            self.list = []
            import requests
            self.session = requests.Session()
            self.imdb_link  = "http://www.imdb.com"
            self.trakt_link = "https://api.trakt.tv"
            self.tmdb_link  = "https://api.themoviedb.org"


            ### SETTINGS ###

            self.moviessort = control.setting("movies.sort")
            if self.moviessort == "0":
                self.moviessort = "popularity.desc"
            elif self.moviessort == "1":
                self.moviessort = "primary_release_date.desc"

            self.tmdbvote = control.setting("tmdbmovie.vote")

            self.trakt_user = control.setting("trakt.user").strip()
            self.imdb_user = control.setting("imdb.user").replace("ur", "").replace("/", "").strip()
            self.user = str(control.setting("fanart.tv.user")) + str(control.setting("tm.user"))

            self.tm_user = control.setting("tm.user") or apis.tmdb_API  # api_key
            # self.tm_bearer = control.setting("tm.user_bearer") or apis.tmdb_bearer  # v4 - czy to nie to samo co access_token?
            self.tm_bearer = control.setting("tm.user_bearer")  # v4 - czy to nie to samo co access_token?
            self.tmdbuser = control.setting("tmdb.username") or "me"  # or control.setting("tmdb.account_id")  # może lepiej nie mieszać (nie wiem)
            self.tmdb_account_id = control.setting("tmdb.account_id") or ""  # v4  https://www.themoviedb.org/talk/6531957e481382011c209e34
            self.tmdb_sessionid = control.setting("tmdb.sessionid") or ""  # potrzebne do indywidualnych operacji
            self.tmdb_guest_session_id = control.setting("tmdb.guest_session_id") or ""  # do ocen anonimowych użytkowników
            self.tmdb_access_token = control.setting("tmdb.access_token") or ""  # v4 ? czym to się różni od bearer?

            self.lang = control.apiLanguage()["tmdb"]  # iso 639-1 | daje 'pl' (ciekawe, czy wielkość liter ma znaczenie, bo wg Wiki to "PL"
            self.language = f"{self.lang}-{self.lang.upper()}"  # ISO_3166_1 | wg doc api z tmdb to "language-COUNTRY", czyli np. "pl-PL" (z wyjątkiem obrazków?)
            self.region = self.lang.upper()  # filter to search for and display matching release date information. This parameter is expected to be an ISO 3166-1 code


            ## DATY ##
            self.datetime = datetime.datetime.utcnow() - datetime.timedelta(hours=5)
            self.systime = self.datetime.strftime("%Y%m%d%H%M%S%f")
            self.year_date = (self.datetime - datetime.timedelta(days=365)).strftime("%Y-%m-%d")
            self.today_date = self.datetime.strftime("%Y-%m-%d")
            self.today_date_cinema = self.datetime.strftime("%Y-%m-%d")  # to samo co wyżej
            self.hidecinema = control.setting("hidecinema")
            self.hidecinema_rollback = int(control.setting("hidecinema.rollback"))
            self.hidecinema_rollback2 = self.hidecinema_rollback * 31  # dobrać eksperymentalnie
            self.hidecinema_date = (datetime.date.today() - datetime.timedelta(days=self.hidecinema_rollback2)).strftime("%Y-%m-%d")
            # self.cinemanow_date = datetime.date.today() - datetime.timedelta(61)  # ostatnie 2 miechy  (ale już chyba nieużywane, bo tmdb wprowadził na to specjalną listę)
            if self.hidecinema == "true":
                self.today_date = self.hidecinema_date
                fflog(f'{self.hidecinema_date=}', 1)
            else:
                #self.today_date = ""  # można spróbować, bo domyślnie tmdb i tak chyba bierze dzisiejszą, a ścieżki będą uniwersalniejsze
                pass

            ### LINKI API DO TMDB ###
            # nie wiem dokładnie, czy to służy jak jakaś skrócona wersja?
            self.metasearch = (self.tm_user, self.lang, self.today_date,)  # TODO dodatkowe ustawienia

            # "popularity.desc" is default value for "sort_by"
            self.tmdb_collection_search = "https://api.themoviedb.org/3/search/collection?api_key=%s&language=%s&query=%%s&page=1" % (self.tm_user, self.lang)

            self.tmdb_movie_search     = "https://api.themoviedb.org/3/search/movie?api_key=%s&language=%s&sort_by=popularity.desc&query=%%s&page=1" % (self.tm_user, self.lang)
            self.tmdb_movie_discover = "https://api.themoviedb.org/3/discover/movie?api_key=%s&language=%s&sort_by=popularity.desc&with_text_query=%%s&page=1" % (self.tm_user, self.lang)
            if 0:  # zrobić jako opcję
                self.tmdb_movie_search = self.tmdb_movie_discover

            self.tmdb_epg_search  =  "https://api.themoviedb.org/3/search/movie?api_key=%s&language=%s&sort_by=popularity.desc&query=%%s&page=1" % (self.tm_user, self.lang)

            self.tmdb_discover = ("https://api.themoviedb.org/3/discover/movie?api_key=%s&language=%s&sort_by=%s&primary_release_date.lte=%s&vote_count.gte=%s&include_adult=false&include_video=false&%%s&page=1" % (
                self.tm_user, self.lang, self.moviessort, self.today_date, self.tmdbvote))

            self.tmdb_language = ("https://api.themoviedb.org/3/discover/movie?api_key=%s&language=%s&sort_by=%s&primary_release_date.lte=%s&include_adult=false&include_video=false&%%s&page=1" % (
                self.tm_user, self.lang, self.moviessort, self.today_date))

            self.tmdb_discover_year =  ("https://api.themoviedb.org/3/discover/movie?api_key=%s&language=%s&sort_by=primary_release_date.asc&include_adult=false&include_video=false&primary_release_year=%%s&vote_count.gte=%s&with_watch_monetization_types=flatrate&page=1" % (
                self.tm_user, self.lang, self.tmdbvote))

            self.tmdb_discover_years = ("https://api.themoviedb.org/3/discover/movie?api_key=%s&language=%s&sort_by=popularity.desc&primary_release_date.gte=%%s&primary_release_date.lte=%%s&vote_count.gte=%s&include_adult=false&include_video=false&page=1" % (
                self.tm_user, self.lang, self.tmdbvote))

            self.tmdb_companies_link = self.tmdb_link + '/3/discover/movie?api_key=%s&with_companies=%s&language=%s&sort_by=%s&page=1' % (self.tm_user, '%s', self.lang, self.moviessort)

            #self.tmdb_popular_link = ("https://api.themoviedb.org/3/movie/popular?api_key=%s&language=%s&primary_release_date.lte=%s&include_adult=false&include_video=false&page=1" % self.metasearch)
            self.tmdb_popular_link = ("https://api.themoviedb.org/3/movie/popular?api_key=%s&language=%s&region=%s&page=1" % (self.tm_user, self.language, self.region))

            self.tmdb_top_rated_link = ("https://api.themoviedb.org/3/movie/top_rated?api_key=%s&language=%s&region=%s&page=1" % (self.tm_user, self.language, self.region))

            self.tmdb_upcoming_link = ("https://api.themoviedb.org/3/movie/upcoming?api_key=%s&language=%s&region=%s&page=1" % (self.tm_user, self.language, self.region))

            self.tmdb_new_link = ("https://api.themoviedb.org/3/discover/movie?api_key=%s&language=%s&sort_by=primary_release_date.desc&primary_release_date.lte=%s&vote_count.gte=%s&include_adult=false&include_video=false&with_runtime.gte=30&%%s&page=1" % (
                self.tm_user, self.language, self.today_date, self.tmdbvote))

            # nie wiem, czy to jeszcze jest wykorzystywane
            self.tmdb_trending_link = ("https://api.themoviedb.org/3/trending/movie/week?api_key=%s&language=%s&primary_release_date.lte=%s&vote_count.gte=100&include_adult=false&include_video=false&page=1" % self.metasearch)

            self.tmdb_views_link = ("https://api.themoviedb.org/3/trending/movie/week?api_key=%s&language=%ssort_by=vote_count.desc&primary_release_date.lte=%s&vote_count.gte=1000&include_adult=false&include_video=false&page=1" % self.metasearch)

            self.tmdb_similar = ("https://api.themoviedb.org/3/movie/%%s/similar?api_key=%s&language=%s&sort_by=%s&primary_release_date.lte=%s&vote_count.gte=%s&include_adult=false&include_video=false&page=1" % (
                self.tm_user, self.lang, self.moviessort, self.today_date, self.tmdbvote))

            self.tmdb_recommendations = ("https://api.themoviedb.org/3/movie/%%s/recommendations?api_key=%s&language=%s&sort_by=%s&primary_release_date.lte=%s&vote_count.gte=%s&include_adult=false&include_video=false&page=1" % (
                self.tm_user, self.lang, self.moviessort, self.today_date, self.tmdbvote))

            self.tmdb_collection = "https://api.themoviedb.org/3/collection/%%s?api_key=%s&language=%s&include_adult=false&page=1" % (self.tm_user, self.lang)

            """
            self.tmbd_cinema_link = (
                    "https://api.themoviedb.org/3/discover/movie?api_key=%s&language=%s&sort_by=primary_release_date.desc&primary_release_date.gte=%s&with_release_type=3&vote_count.gte=%s&include_adult=false&include_video=false&page=1" % (
                self.tm_user, self.lang, self.cinemanow_date, self.tmdbvote))
            self.tmbd_cinema_link = (
                    "https://api.themoviedb.org/3/discover/movie?api_key=%s&language=%s&sort_by=primary_release_date.desc&primary_release_date.gte=%s&primary_release_date.lte=%s&with_release_type=2|3&vote_count.gte=%s&include_adult=false&include_video=false&with_runtime.gte=20&page=1" % (
                        self.tm_user, self.language, self.cinemanow_date, self.today_date_cinema, self.tmdbvote))
            """
            self.tmbd_cinema_link = ( "https://api.themoviedb.org/3/movie/now_playing?api_key=%s&language=%s&region=%s&page=1" % (self.tm_user, self.language, self.region) )

            # nie wiem, który będzie lepszy
            self.tmdb_multi_search = "https://api.themoviedb.org/3/search/multi?api_key=%s&language=%s&query=%%s&include_adult=false&page=1" % (self.tm_user, self.lang)


            # aktorzy
            self.tmdb_person_link = "https://api.themoviedb.org/3/search/person?api_key=%s&language=%s&query=%%s&include_adult=false&page=1" % (self.tm_user, self.lang)
            self.tmdb_personid_link = "https://api.themoviedb.org/3/person/%%s?api_key=%s&language=%s&append_to_response=images&page=1" % (self.tm_user, self.lang)
            self.tmdb_personid_credits_link = "https://api.themoviedb.org/3/person/%%s/%%s_credits?api_key=%s&language=%s&include_adult=false&page=1" % (self.tm_user, self.lang)


            ### Manager TMDB ###
            self.tmdb_add_to_favourite_link = "https://api.themoviedb.org/3/account/%s/favorite?api_key=%s&session_id=%s"  % (self.tmdbuser, self.tm_user, self.tmdb_sessionid)
            self.tmdb_add_to_watchlist_link = "https://api.themoviedb.org/3/account/%s/watchlist?api_key=%s&session_id=%s" % (self.tmdbuser, self.tm_user, self.tmdb_sessionid)

            # self.tmdbuserAddItem_link    = "https://api.themoviedb.org/3/list/%%s/add_item?api_key=%s&session_id=%s" % (self.tm_user, self.tmdb_sessionid)
            # self.tmdbuserRemoveItem_link = "https://api.themoviedb.org/3/list/%%s/remove_item?api_key=%s&session_id=%s" % (self.tm_user, self.tmdb_sessionid)

            self.tmdbuserAddItems_link    = "https://api.themoviedb.org/4/list/%%s/items?api_key=%s&session_id=%s" % (self.tm_user, self.tmdb_sessionid)
            self.tmdbuserRemoveItems_link = "https://api.themoviedb.org/4/list/%%s/items?api_key=%s&session_id=%s" % (self.tm_user, self.tmdb_sessionid)  # delete method

            self.tmdbuserCreateList_link = "https://api.themoviedb.org/3/list?api_key=%s&session_id=%s" % (self.tm_user, self.tmdb_sessionid)
            self.tmdbuserDeleteList_link = "https://api.themoviedb.org/3/list/%%s?api_key=%s&session_id=%s" % (self.tm_user, self.tmdb_sessionid)  # delete method


            ### TMDB USER ###
            self.tmdb_user_lists = ("https://api.themoviedb.org/3/account/%s/lists?api_key=%s&language=%s&session_id=%s&page=1" % (
                self.tmdbuser, self.tm_user, self.lang, self.tmdb_sessionid))

            self.tmdb_lists_link = ("https://api.themoviedb.org/3/list/%%s?api_key=%s&language=%s&session_id=%s&page=1" % (
                    self.tm_user, self.lang, self.tmdb_sessionid))

            self.tmdbuserwatchlist_link = ("https://api.themoviedb.org/3/account/%s/watchlist/movies?api_key=%s&language=%s&session_id=%s&sort_by=created_at.desc&page=1" % (
                self.tmdbuser, self.tm_user, self.lang, self.tmdb_sessionid))

            self.tmdbuserfavourite_link = ("https://api.themoviedb.org/3/account/%s/favorite/movies?api_key=%s&language=%s&session_id=%s&sort_by=created_at.desc&page=1" % (
                self.tmdbuser, self.tm_user, self.lang, self.tmdb_sessionid))

            self.tmdbuserrated_link = ("https://api.themoviedb.org/3/account/%s/rated/movies?api_key=%s&language=%s&session_id=%s&sort_by=created_at.desc&page=1" % (
                self.tmdbuser, self.tm_user, self.lang, self.tmdb_sessionid))

            # self.tmdbguestrated_link = ("https://api.themoviedb.org/3/guest_session/%%s/rated/movies?api_key=%s&language=%s&sort_by=created_at.desc&page=1" % (
                # self.tm_user, self.lang))
            self.tmdbguestrated_link = ("https://api.themoviedb.org/3/guest_session/%s/rated/movies?api_key=%s&language=%s&sort_by=created_at.desc&page=1" % (
                self.tmdb_guest_session_id, self.tm_user, self.lang))

            # czy to jest używane ? chyba przeniosłem w inne miejsce
            # add rating
            self.tmdb_rating_link = "https://api.themoviedb.org/3/movie/%%s/rating?api_key=%s&session_id=%s" % (self.tm_user, self.tmdb_sessionid)

            # v4
            self.tmdbrecommended_link = "https://api.themoviedb.org/4/account/%s/movie/recommendations?language=%s&page=1" % (self.tmdb_account_id, self.language)
            # przeróbka nic nie dała, bo ale musi być tmdb_account_id, a tego nie dostaniemy logując się w v3
            # self.tmdbrecommended_link = "https://api.themoviedb.org/4/account/%s/movie/recommendations?language=%s&page=1&api_key=%s&session_id=%s" % (self.tmdb_account_id, self.language, self.tm_user, self.tmdb_sessionid)


            ### SUPERINFO ###
            self.tmdb_arts      = "https://api.themoviedb.org/3/movie/{}/images?api_key={}".format("%s", self.tm_user, )
            self.tmdb_providers = "https://api.themoviedb.org/3/movie/%s/watch/providers?api_key=%s" % ("%s", self.tm_user)
            self.tmdb_by_imdb   = "https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id" % ("%s", self.tm_user)
            self.tmdb_api_link  = "https://api.themoviedb.org/3/movie/%s?api_key=%s&language=%s&append_to_response=credits,external_ids" % ("%s", self.tm_user, self.lang)
            self.tm_art_link    = "https://api.themoviedb.org/3/movie/%s/images?api_key=%s&language=en-US&include_image_language=en,%s,null" % ("%s", self.tm_user, self.lang)
            self.tm_img_link    = "https://image.tmdb.org/t/p/w%s%s"


            ### grafiki z FanartTV
            self.fanart_tv_user       = (control.setting("fanart.tv.user") or apis.fanarttv_client_key)
            self.fanart_tv_API_key    = (control.setting("fanart.tv.dev") or apis.fanarttv_API_key)
            self.fanart_tv_headers    = {"api-key": self.fanart_tv_API_key, "client-key": self.fanart_tv_user, }
            self.fanart_tv_art_link   = "https://webservice.fanart.tv/v3/movies/%s"
            self.fanart_tv_level_link = "https://webservice.fanart.tv/v3/level"  # ?


            ## TRAKT - POJEDYNCZE LINKI ##
            self.traktcollection_link = "https://api.trakt.tv/users/me/collection/movies"
            self.traktwatchlist_link  = "https://api.trakt.tv/users/me/watchlist/movies"
            self.traktfavorites_link  = "https://api.trakt.tv/users/me/favorites/movies"
            self.trakthistory_link    = "https://api.trakt.tv/users/me/history/movies?limit=20&page=1"
            self.traktlists_link      = "https://api.trakt.tv/users/me/lists"
            self.traktlikedlists_link = "https://api.trakt.tv/users/likes/lists?limit=1000000"
            self.traktlist_link       = "https://api.trakt.tv/users/%s/lists/%s/items"  # sortowanie wg autora
            # self.traktlist_link       = "https://api.trakt.tv/users/%s/lists/%s/items?sort_by=added&sort_how=desc"  # najnowsze na początku listy
            self.traktfeatured_link   = "https://api.trakt.tv/recommendations/movies?limit=20"
            self.boxoffice_link       = "https://api.trakt.tv/movies/boxoffice"
            self.trending_link        = "https://api.trakt.tv/movies/trending?limit=20&page=1"
            self.trending_lists_link  = 'https://api.trakt.tv/lists/trending?limit=300&page=1'  # page tu chyba jest opcjonalne
            self.popular_lists_link   = 'https://api.trakt.tv/lists/popular?limit=300'
            self.search_lists_link    = 'https://api.trakt.tv/search/list?limit=300'


            ## IMDB - POJEDYNCZE LINKI ##
            #imdb_count_limit = 20  # nie wdrożone
            self.imdb_awards = "https://www.imdb.com/search/title/?groups=%s&sort=year,desc&count=100&start=1"
            # self.imdb_awards = "https://www.imdb.com/search/title/?groups=%s&sort=year,desc"  # taki adres pokazuje z przeglądarce (oczywiście po uzupełnieniu groups na np. oscar_winner) i ściąga do 25 pozycji (a w js siedzi 50 pozycji)

            # self.imdbUserLists_link = "https://www.imdb.com/list/ls%s/?view=detail&sort=alpha,asc&title_type=movie&count=100&start=1"  # nie występuje w kodzie nigdzie

            self.imdblist1_link =     "https://www.imdb.com/list/%s/?view=detail&sort=alpha,asc&title_type=movie&count=80&start=1"
            self.imdblist2_link =     "https://www.imdb.com/list/ls%s/?view=detail&sort=date_added,desc&title_type=movie&count=80&start=1"

            self.imdblists_link =     "https://www.imdb.com/user/ur%s/lists?tab=all&sort=mdfd&order=desc&filter=titles" % self.imdb_user

            self.imdbwatchlist_link = "https://www.imdb.com/user/ur%s/watchlist" % self.imdb_user
            self.imdbwatchlist1_link ="https://www.imdb.com/user/ur%s/watchlist?sort=alpha,asc&count=80&start=1" % self.imdb_user
            self.imdbwatchlist2_link ="https://www.imdb.com/user/ur%s/watchlist?sort=date_added,desc&count=80&start=1" % self.imdb_user


            import resources.lib.indexers.tmdb_manager as subm
            methods = [ m for m in dir(subm)
                       if not m.startswith('__')
                      ]
            for m in methods:
                # setattr(movies, m, getattr(subm, m))
                setattr(type(self), m, getattr(subm, m))
                pass
            subm = None


        ### Katalogi filmów ###


        ## Języki ##
        def languages(self, ret_list=False, extended=None):
            languages = [("polski", "pl"),
                        ("afrykanerski", "af"), ("albański", "sq"), ("angielski", "en"), ("arabski", "ar"), ("azerski", "az"),
                        ("białoruski", "be"), ("bośniacki", "bs"), ("bułgarski", "bg"), ("chiński", "zh"), ("chorwacki", "hr"),
                        ("czeski", "cs"), ("duński", "da"), ("estoński", "et"), ("fiński", "fi"), ("francuski", "fr"),
                        ("grecki", "el"), ("gruziński", "ka"), ("hebrajski", "he"), ("hindi ", "hi"), ("hiszpański", "es"),
                        ("holenderski", "nl"), ("irlandzki", "ga"), ("islandzki", "is"), ("japoński", "ja"), ("koreański", "ko"),
                        ("litewski", "lt"), ("łotewski", "lv"), ("macedoński", "mk"), ("mołdawski", "mo"), ("niemiecki", "de"),
                        ("norweski", "no"), ("ormiański", "hy"),
                        ("pendżabski", "pa"), ("perski", "fa"), ("portugalski", "pt"), ("rosyjski", "ru"), ("rumuński", "ro"),
                        ("serbski", "sr"), ("serbsko-chorwacki", "sh"), ("słowacki", "sk"), ("słoweński", "sl"),
                        ("szwedzki", "sv"), ("turecki", "tr"), ("ukraiński", "uk"), ("węgierski", "hu"), ("włoski", "it"),
            ]

            if ret_list:
                if not extended:
                    return languages
                else:
                    # return languages, ("with_original_language", 1)
                    return (0, ["Wszystkie"] + languages), ("with_original_language", 1)

            for i in languages:
                self.list.append({
                                    "name": i[0],
                                    "url": self.tmdb_language % ("with_original_language=" + i[1]),
                                    "image": "languages.png",
                                    # "action": "movies" + f"&item={i[1]}",
                                    "action": "movies" + f"&item={i[0]}",
                                })
            self.addDirectory(self.list, category="Języki")
            return self.list


        ## Certyfikaty ##
        def certifications(self, ret_list=False, extended=None):  # tego chyba nie ma w menu (przynajmniej ja nie mogę znaleźć)
            #certificates = ["G", "PG", "PG-13", "R", "NC-17"]
            certificates = [
                ("G", "(wszystkie grupy wiekowe)"),
                ("PG", "(7+)"),
                ("PG-13", "(13+)"),
                ("R", "(16+)"),
                ("NC-17", "(18+)"),
                # ("NR", "(bez oceny)")  # a jak pod filmem pojawia się NR,18 ?? może stosować certification.gte ?
            ]

            if ret_list:
                if not extended:
                    return certificates
                else:
                    # return certificates, ("certification_country=US&certification", 0)
                    return (1, ["brak"] + certificates), ("certification_country=US&certification", 0)

            for i in certificates:
                self.list.append({
                    "name": str(i[0]) + f"  {i[1]}",
                    "url": self.tmdb_discover % ("certification_country=US&certification=" + str(i[0])),
                    "image": "certificates.png",
                    # "action": "movies" + f"&item={str(i[0])}",
                    "action": "movies" + f"&item={urllib.quote_plus(str(i[1]).strip(')('))}",
                    })
            self.addDirectory(self.list, category="Kategorie wiekowe")
            return self.list


        ## Lata ##
        def years(self, ret_list=False, extended=None):

            if not ret_list:
                # wstawienie odnośnika do zakresów lat
                navigator.navigator().addDirectoryItem(32630, "movieYearsTop", "years.png", "DefaultMovies.png")

            # lata
            year = self.datetime.strftime("%Y")
            zakres = range(int(year) - 0, 1899, -1)

            if ret_list:
                years_list = [i for i in zakres]
                if not extended:
                    return years_list
                else:
                    return ["Wszystkie"] + years_list, "primary_release_year"

            # for i in range(int(year) - 0, 1899, -1):
            for i in zakres:
                self.list.append({
                    "name": str(i),
                    "url": self.tmdb_discover_year % (str(i)),
                    "image": "years.png",
                    "action": "movies" + f"&item={str(i)}",
                    })

            self.addDirectory(self.list, category="Lata")
            return self.list


        ## Lata TOP (zakres lat) ##
        def years_top(self):
            year = self.datetime.strftime("%Y")
            dec = int(year[:3]) * 10
            for i in range(dec, 1860, -10):  # od 1870
                self.list.append({"name": str(i) + "-" + str(i + 9),
                                  #"url": self.tmdb_discover_years % (str(i), str(i + 9)),
                                  "url": self.tmdb_discover_years % (str(i)+"-01-01", str(i + 9)+"-12-31"),
                                  "image": "years.png",
                                  "action": "movies" + f'&item={str(i) + "-" + str(i + 9)}',
                                  })
            self.addDirectory(self.list, category="Lata")
            return self.list


        ## Gatunki ##
        def genres(self, ret_list=False, extended=None):
            genres = [
                      ("28", "Akcja", "Action.png"),
                      ("16", "Animacja", "Animation.png"),
                      ("99", "Dokumentalny", "Documentary.png"),
                      ("18", "Dramat", "Drama.png"),
                      ("10751", "Familijny", "Family.png"),
                      ("14", "Fantasy", "Fantasy.png"),
                      ("36", "Historyczny", "History.png"),
                      ("27", "Horror", "Horror.png"),
                      ("35", "Komedia", "Comedy.png"),
                      ("80", "Kryminał", "Crime.png"),
                      ("10402", "Muzyczny", "Music.png"),
                      ("12", "Przygodowy", "Adventure.png"),
                      ("10749", "Romans", "Romance.png"),
                      ("878", "Sci-Fi", "Sci-Fi.png"),
                      ("9648", "Tajemnica", "Mystery.png"),
                      ("53", "Thriller", "Thriller.png"),
                      ("10770", "Telewizyjny", "Tvmovie.png"),
                      ("37", "Western", "Western.png"),
                      ("10752", "Wojenny", "War.png"),
                     ]

            if ret_list:
                if not extended:
                    return genres
                else:
                    # return genres, ("with_genres", 0)
                    return (1, ["Wszystkie"] + genres), ("with_genres", 0)

            for i in genres:
                self.list.append({"name": i[1],
                                  "url": self.tmdb_discover % ("with_genres=" + i[0]),
                                  "image": i[2],
                                  "action": "movies" + f"&item={i[1]}",
                                 })
            self.addDirectory(self.list, category="Gatunki")
            return self.list


        def companies(self, ret_list=False, extended=None):
            companies = [
                ('20580',       'Amazon Studios',              '/oRR9EXVoKP9szDkVKlze5HVJS7g.png'),
                ('178464',      'Netflix',                     '/tyHnxjQJLH6h4iDQKhN5iqebWmX.png'),
                ('3268|7429',   'HBO',                         '/tuomPhY2UtuPTqqFnKMVHvSb724.png'),
                ('6480',        'TVP',                         '/qJUUNzFYXNUDaisssBTV3Zdki9R.png'),
                ('5622',        'TVN Group',                   '/bKcpepYRLylECRb5LVkskW0TQIX.png'),
                ('25|127928',   '20th Century',                '/qZCc1lty5FzX30aOCVRBLzaVmcp.png'),
                ('7',           'DreamWorks Pictures',         '/1kqoutvio9eDaQpp0l4gQoEF4Yf.png'),
                ('4',           'Paramount',                   '/gz66EfNoYPqHTYI4q9UEN4CbHRc.png'),
                ('33',          'Universal Pictures',          '/8lvHyhjr8oUKOOy2dKXoALWKdp0.png'),
                ('2',           'Walt Disney Pictures',        '/wdrCwmRnLFJhEoH8GSfymY85KHT.png'),
                ('17',          'Warner Bros. Entertainment',  '/7Qu05UOqxdTGLl3kOvkRBv723Vz.png'),
                ('3',           'Pixar',                       '/1TjvGVDMYsj6JBxOAkUHpPEwLf7.png'),
                ('1',           'Lucasfilm Ltd.',              '/tlVSws0RvvtPBwViUyOFAO0vcQS.png'),
                ('5',           'Columbia Pictures',           '/71BqEFAF4V3qjjMPCpLuyJFB9A.png' ),
                ('34',          'Sony Pictures',               '/mtp1fvZbe4H991Ka1HOORl572VH.png'),
                ('38',          'Zespół Filmowy "Tor"',        '/qMi10Y3HnR7BQRqMC4ch7qZ6HN4.png'),
                ('21',          'Metro-Goldwyn-Mayer',         '/usUnaYV6hQnlVAXP6r4HwrlLFPG.png'),
                ('7926',        'Zespół Filmowy Kadr',         '' ),
                ('58225',       'Studio Filmowe Zebra',        '' ),
                ('81883',       'Studio Filmowe Iluzjon',      '' ),
                ('18392',       'Monolith Films',              '' ),
                ('14',          'Miramax',                     '/m6AHu84oZQxvq7n1rsvMNJIAsMu.png'),
                ('6704',        'Illumination',                '/uwy3O0fb0CKeLqINPgiGKbTMeux.png'),
                ('12',          'New Line Cinema',             '/iaYpEp3LQmb8AfAtmTvpqd4149c.png'),
                ('56',          'Amblin Entertainment',        '/cEaxANEisCqeEoRvODv2dO1I0iI.png'),
                ('429',         'DC Comics',                   '/2Tc1P3Ac8M479naPp1kYT3izLS5.png'),
                ('923',         'Legendary Pictures',          '/8M99Dkt23MjQMTTWukq4m5XsEuo.png'),
                ('10342',       'Studio Ghibli',               '/eS79pslnoKbWg7t3PMA9ayl0bGs.png'),
                ('521',         'DreamWorks Animation',        '/kP7t6RwGz2AvvTkvnI1uteEwHet.png'),
            ]

            companies = [(c[0], c[1], "https://image.tmdb.org/t/p/h100_filter(negate,000,666)"+c[2] if c[2] else "") for c in companies]

            companies = sorted(companies, key=lambda k: k[1])

            if ret_list:
                if not extended:
                    return companies
                else:
                    # return companies, ("with_companies", 0)
                    return (1, ["Wszystkie"] + companies), ("with_companies", 0)

            for i in companies:
                self.list.append(
                    {
                        "name": i[1],
                        "url": self.tmdb_companies_link % i[0],
                        "image": i[2],
                        # "action": "movies" + f"&item={str(i[1])}",
                        "action": "movies" + f"&item={urllib.quote_plus(str(i[1]))}",
                        
                    }
                )
            # self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))
            self.addDirectory(self.list, category="Wytwórnie")
            return self.list


        def custom(self, url2=""):
            # fflog(f'{url2=}',1,1)
            if not url2:

                folderpath = control.infoLabel('Container.FolderPath')
                params1 = dict(urllib.parse_qsl(folderpath.split('?')[-1]))
                action1 = params1.get('action')  # może być też puste
                fflog(f'{action1=}',1,1)
                if action1 in ["moviePage", "movies"]:  # pomaga, aby klawiatura nie pojawiała ponownie się przy cofnięciu
                # if action1 not in ["movieNavigator", "cu2stomMovieCriteria"]:
                    return
                    pass

                criteria = {
                    # "gatunki": [0, (1, ["Wszystkie"] + self.genres(ret_list=True)), ("with_genres",0)],
                    "gatunki": [0, *self.genres(ret_list=True, extended=True)],
                    "wytwórnie": [0, *self.companies(ret_list=True, extended=True)],
                    # "języki": [0, (0,[("wszystkie",""), ("polski", "pl"), ("angielski","en"), ("chiński","ch")]), ("with_original_language",1)],
                    "języki": [0, *self.languages(ret_list=True, extended=True)],
                    # "lata": [0, ["wszystkie", 2025, 2024, 2023], "primary_release_year"],
                    "lata": [0, *self.years(ret_list=True, extended=True)],
                    "ograniczenia wiekowe": [0, *self.certifications(ret_list=True, extended=True)],
                    "minimalna ilość głosów": [0, sorted(set([0,1,10,5,50,100,int(self.tmdbvote)])), "vote_count.gte"],
                }
                if "minimalna ilość głosów" in criteria:
                    criteria["minimalna ilość głosów"][0] = criteria["minimalna ilość głosów"][1].index(int(self.tmdbvote))
                # fflog(f'{criteria=}',1,1)
                # fflog(f'criteria={json.dumps(criteria, indent=2)}',1,1)

                przechowalnia = control.window.getProperty('FanFilm.var.MovieCriteria')  # z pamięci
                if przechowalnia:
                    from ast import literal_eval
                    przechowalnia = literal_eval(przechowalnia)
                    for k,v in przechowalnia.items():
                        if k in criteria:
                            criteria[k][0] = v
                            pass
                # fflog(f'{criteria=}',1,1)
                # fflog(f'criteria={json.dumps(criteria, indent=2)}',1,1)

                preselect = -1
                selected0 = 0
                if action1 not in ["moviePage", "movies"]:  # pomaga, aby klawiatura nie pojawiała ponownie się przy cofnięciu
                    while selected0 > -1:
                        # główne menu - wybór głównych kryteriów
                        labels = [f"[LIGHT]{k}[/LIGHT]: [I]" + (
                                                                # "Wszystkie" if v[0]==0 else 
                                                                ( str(v[1][1][0]) if isinstance(v[1], tuple) else str(v[1][0]) )  if v[0]==0  else 
                                                                    "[B]" + ( f"{v[1][1] [v[0]] [ v[1][0] ]}" if isinstance(v[1], tuple) else str(v[1][v[0]]) ) + "[/B]"
                                                               ) + "[/I]"
                                                                for k,v in criteria.items()]
                        labels += ["===  [B] S z u k a j [/B]  ==="]  # jako ostatni - takie założenie, bo potem jest to sprawdzane
                        # control.log(f'GŁÓWNE {labels=}',1)
                        selected0 = control.selectDialog(labels, 'Wybierz [I]kryteria[/I] i [B]Szukaj[/B]', preselect=preselect)
                        # selected0 = 0  # dokonany wybór pozycji z listy
                        if selected0 > -1:
                            preselect = selected0
                            # wybór podkryteriów
                            podkryterium = labels[selected0].split(":")[0]
                            podkryterium = podkryterium.replace("[LIGHT]", "").replace("[/LIGHT]", "")
                            # if podkryterium.startswith("Szukaj"):
                            if selected0 == len(labels) - 1:  # ostatni
                                # selected0 = -1
                                # control.log(f'SZUKAM\n{criteria=}',1)
                                break
                            labels1 = criteria[podkryterium][1]
                            if isinstance(labels1, tuple):
                                index = labels1[0]
                                #print(index)
                                labels1 = [ l[index] if isinstance(l,tuple) else l  for l in labels1[1] ]
                            labels1 = [str(l) for l in labels1]  # konwersja liczb na string (jeśli są)
                            # control.log(f'{podkryterium=}  {labels1=}',1)
                            preselect1 = criteria[podkryterium][0]
                            selected1 = control.selectDialog(labels1, f'wybierz {podkryterium}', preselect=preselect1)
                            # selected1 = 1
                            if selected1 > -1:
                                # preselect1 = selected1
                                criteria[podkryterium][0] = selected1  # modyfikacja
                                selected1 = -1  # czy to potrzebne?

                if selected0 > -1:
                    # trzeba zbudować teraz adres 
                    query = ""
                    for k,v in criteria.items():
                        # fflog(f'{k=} {v=}',1,1)
                        if v[0] or v[-1] == 'vote_count.gte':
                            if isinstance(v[1], tuple):
                                key = v[2] [0]
                                val = v[1] [1] [v[0]] [ v[2][1] ]
                            else:
                                key = v[2]
                                val = v[1] [v[0]]
                            val = str(val).strip()
                            # fflog(f'{key=}, {val=}',1,1)
                            if "%%s" in key:
                                query += "&" + key.replace("%%s", str(val))
                                pass
                            else:
                                query += f"&{key}={val}"
                                pass
                    fflog(f'{query=}',1,1)
                    if not query:
                        fflog("nie wybrałeś żadnych kryteriów",1,1)
                        # control.dialog.notification("FanFilm", "nie wybrałeś żadnych kryteriów")
                        control.infoDialog('Nie wybrałeś żadnych kryteriów', sound=True, icon="WARNING")
                        pass
                    else:
                        """ do testów było
                        class self:
                            pass
                        from ptw.libraries import apis
                        self.tm_user = control.setting("tm.user") or apis.tmdb_API
                        self.lang = control.apiLanguage()["tmdb"]
                        self.moviessort = control.setting("movies.sort")
                        if self.moviessort == "0":
                            self.moviessort = "popularity.desc"
                        elif self.moviessort == "1":
                            self.moviessort = "primary_release_date.desc"
                        self.tmdbvote = control.setting("tmdbmovie.vote")
                        import datetime
                        self.datetime = datetime.datetime.utcnow() - datetime.timedelta(hours=5)
                        self.today_date = self.datetime.strftime("%Y-%m-%d")
                        """
                        # self.tmdb_discover = ("https://api.themoviedb.org/3/discover/movie?api_key=%s&language=%s&sort_by=%s&primary_release_date.lte=%s&vote_count.gte=%s&include_adult=false&include_video=false&%%s&page=1" % (
                                        # self.tm_user, self.lang, self.moviessort, self.today_date, self.tmdbvote))

                        url2 = self.tmdb_discover % query
                        url2 = url2.replace("&&", "&")
                        # url2 = url2.replace("primary_release_date.lte", "nic")  # test
                        # control.log(f'{url2=}',1)

                        url2 = re.sub("(?<=api_key=)[^&]*", "", url2)
                        url2 = re.sub("(?<=session_id=)[^&]*", "", url2)

                        przechowalnia = {}
                        for k,v in criteria.items():
                            przechowalnia.update({k: v[0]})
                        control.window.setProperty('FanFilm.var.MovieCriteria', repr(przechowalnia))  # do pamięci
                        # fflog(f'{przechowalnia=}',1,1)
                        # do wyświetlenia to lepiej odrzucić 0 i wyświetlać etykiety zamiast cyfr (budowa prawie jak głównych labels)
                        # do_wyswietlenia = str(przechowalnia).replace("{","").replace("}","").replace("'","")
                        # control.dialog.notification("", do_wyswietlenia, time=3000)

            if url2:
                # movies.get(self, url2, category="Własne kryteria")
                # return  # koniec funkcji
                pass

                # pomaga, aby klawiatura nie pojawiała ponownie się przy cofnięciu
                generate_short_path = control.setting("generate_short_path") == "true"
                if not generate_short_path:
                    url = "{}?action={}".format(sys.argv[0], "movies&url=%s" % urllib.quote_plus(url2))
                else:
                    control.window.setProperty('FanFilm.var.url', url2)
                    url = "{}?action={}".format(sys.argv[0], "movies&item=%s" % urllib.quote_plus('Własne kryteria'))
                # navigator.navigator().addDirectoryItem('... proszę czekać, trwa wyszukiwanie wg wybranych kryteriów ...', "", "search.png", "DefaultAddonsSearch.png")
                control.addItem(int(sys.argv[1]), url, control.item("... proszę czekać, trwa wyszukiwanie wg wybranych kryteriów ..."), True)
                control.directory(int(sys.argv[1]), cacheToDisc=False)
                # navigator.navigator().endDirectory(cacheToDisc=False, category="Własne kryteria")
                control.sleep0(100)
                control.execute('Container.Update("%s")' % url)  # nowe rozdanie :-)
                # control.execute('Container.Update("%s")' % (url+"&r=1"))  # nowe rozdanie :-)
                return  # koniec funkcji


        ## Nagrody ##
        def awards(self):
            awards = [
                      ("best_picture_winner", "Oscary - najlepszy film", "oscar-winners.png"),
                      ("oscar_best_picture_nominees", "Oscary - najlepszy film - nominowane", "oscar-winners.png",),
                      ("best_director_winner", "Oscary - najlepszy reżyser", "oscar-winners.png",),
                      ("oscar_best_director_nominees", "Oscary - najlepszy reżyser - nominowane", "oscar-winners.png",),
                      ("oscar_winner", "Oscary - wszystkie kategorie", "oscar-winners.png",),
                      ("oscar_nominee", "Oscary - wszystkie kategorie - nominowane", "oscar-winners.png",),
                      ("emmy_winner", "Nagrody Emmy", "emmy_winner.png"),
                      ("emmy_nominee", "Nagrody Emmy - nominowane", "emmy_winner.png"),
                      ("golden_globe_winner", "Złote Globy", "golden_globe_winner.png"),
                      ("golden_globe_nominee", "Złote Globy - nominowane", "golden_globe_winner.png"),
                      ("razzie_winner", "Złote Maliny", "razzie_winners.png"),
                      ("razzie_nominee", "Złote Maliny - nominowane", "razzie_winners.png"),
                      ("national_film_preservation_board_winner", "Narodowa Rada Ochrony Filmu", "national_film_preservation_board_winner.png"),
                     ]
            # i = 0
            for a in awards:
                # i += 1
                self.list.append({
                    "name": a[1],
                    "url": self.imdb_awards % (a[0]),
                    "image": a[2],
                    # "action": "movies" + f"&item={a[0]}",
                    "action": "movies" + f"&item={a[1]}",
                })
            #fflog(f'[awards] {self.list=}')
            self.addDirectory(self.list, category="Nagrody")
            return self.list



        ## Podobne filmy ##
        def similar(self, tmdb):
            movies.get(self, self.tmdb_similar % tmdb)


        def recommendations(self, tmdb):
            movies.get(self, self.tmdb_recommendations % tmdb)


        ## Kolekcja (zestaw) filmów danego tytułu ##
        def collection(self, tmdb):
            movies.get(self, self.tmdb_collection % tmdb, category="Wszystkie z kolekcji")


        ### SEARCH ###
        def search(self, s_type="movie", category=""):
            # log_utils.fflog(f'{sys.argv=}')
            # navigator.navigator().addDirectoryItem('(odśwież)', "movieSearch", "search.png", "DefaultMovies.png")

            generate_short_path = control.setting("generate_short_path") == "true"

            navigator.navigator().addDirectoryItem("[LIGHT][B]["+control.lang(32603)+"][/B][/LIGHT]", f"{s_type}Searchnew", "", "DefaultMovieTitle.png")

            from sqlite3 import dbapi2 as database

            dbcon = database.connect(control.searchFile)
            dbcur = dbcon.cursor()

            try:
                dbcur.executescript(f"CREATE TABLE IF NOT EXISTS {s_type}s (ID Integer PRIMARY KEY AUTOINCREMENT, term);")
            except:
                pass

            dbcur.execute(f"SELECT * FROM {s_type}s ORDER BY ID DESC")

            lst = []
            delete_option = False
            for (id, term) in dbcur.fetchall():
                if term not in str(lst):  # by nie było dubli na ekranie
                    lst += [term]
                    delete_option = True

                    context=[
                        # ("Szukaj inaczej", f"{s_type}Searchterm&name=%s&discover=1" % urllib.quote_plus(term), True),
                        ("Szukaj inaczej", f"{s_type}Searchterm&item=%s&discover=1" % len(lst) if generate_short_path else f"{s_type}Searchterm&name=%s&discover=1" % urllib.quote_plus(term), True),
                        ("Popraw", f"{s_type}Searchnew&q=%s" % urllib.quote_plus(term), True),
                        ("Usuń z historii", f"removeFromSearchHistory&term=%s&content={s_type}s" % urllib.quote_plus(term), ),
                    ]
                    if s_type in ["movie"] and not re.search(r'^(.+) +(?:[([]|y:|0)(\d{4})[)\]]?$', term):
                        context.insert(2, ("Dodaj rok", f"{s_type}Searchnew&q=%s&askforyear=1" % urllib.quote_plus(term), True),)

                    navigator.navigator().addDirectoryItem(
                        term,
                        # "movieSearchterm&name=%s" % term,
                        # "movieSearchterm",  # po powrocie focus ustawia się zawsze na pierwszym elemencie
                        #"movieSearchterm&item=%s" % len(lst),  # aby po powrocie focus ustawiał się na poprzedniej pozycji
                        # f"{s_type}Searchterm&item=%s" % len(lst) if generate_short_path else f"{s_type}Searchterm&name=%s" % term,
                        f"{s_type}Searchterm&item=%s" % len(lst) if generate_short_path else f"{s_type}Searchterm&name=%s" % urllib.quote_plus(term),
                        "search.png",
                        "DefaultAddonsSearch.png", 
                        context=context
                    )
            dbcur.close()

            if delete_option:
                navigator.navigator().addDirectoryItem("[LIGHT][I]["+control.lang(32605)+"][/I][/LIGHT]", f"clearCacheSearch&content={s_type}s", "", "DefaultIconWarning.png", isFolder=False)

            syshandle = int(sys.argv[1])
            addSortMethod(syshandle, sortMethod=SORT_METHOD_UNSORTED)
            addSortMethod(syshandle, sortMethod=SORT_METHOD_LABEL)
            # if category:
                # control.pluginCategory(syshandle, category)
            navigator.navigator().endDirectory(cacheToDisc=False, category=["Szukaj", category])


        def search_new(self, s_type="movie", q="", askforyear=None, name=""):
            folderpath = control.infoLabel('Container.FolderPath')
            params1 = dict(urllib.parse_qsl(folderpath.split('?')[-1]))
            action1 = params1.get('action')  # może być też puste
            # fflog(f'{action1=}',1,1)
            if action1 in ["play", "movieSearchterm", "personSearchterm", "multiSearchterm", "collectionSearchterm"]:
                return
                pass
            """
            if action1 in ["movieSearchterm", "play"]:
                # taki hack na Kodi, bo inaczej wywala do głównego menu Kodi
                fflog(f'dodanie pustego katalogu',1,1)
                control.directory(int(sys.argv[1]), cacheToDisc=True)
                url = "{}?action={}".format(sys.argv[0], "movieSearch")
                control.sleep0(100)
                fflog(f'zmiana adresu',1,1)
                # control.execute('Container.Update("%s", replace)' % url)  # ale po cofnięciu i tak wywala aż do początku
                control.execute('Container.Update("%s")' % url)  # nie przetestowałem jeszcze
                return
            """

            if askforyear and not re.search(r'^(.+) +(?:[([]|y:|0)(\d{4})[)\]]?$', q):
                while True:
                    s = control.dialog.input("Rok premiery", "", type=1)
                    if not s or re.match(r"^(19|20)[\d]{2,2}$", s):
                        break
                    if not control.dialog.yesno('Niepoprawna wartość', (f"Wpisana wartość [B]{s}[/B] jest nieprawidłowa. \nCzy chcesz poprawić? \n[COLOR gray]dozwolony zakres to [1900-2099][/COLOR]")):
                        s = ''
                        break
                if s:
                    q += f" [{s}]"

            if not name:
                q0 = q
                k = control.keyboard(q, control.lang(32010))
                k.doModal()
                q = k.getText() if k.isConfirmed() else ""
                q = q.strip() if q is not None else q
                if q is None or q == "" or q == "..":
                    # fflog(f'dodanie pustego katalogu',1,1)
                    # navigator.navigator().endDirectory()
                    # control.sleep0(100)
                    # fflog(f'akcja wstecz',1,1)
                    # control.execute('Action(Back)')
                    return
            else:
                q0 = q = name

            # q = cleantitle.normalize(q)  # for polish characters

            # wstawienie do bazy
            from sqlite3 import dbapi2 as database
            dbcon = database.connect(control.searchFile)
            dbcur = dbcon.cursor()

            if q0:
                dbcur.execute(f"SELECT * FROM {s_type}s WHERE term=?", (q0,))
                if dbcur.fetchone():
                    dbcur.execute(f"DELETE FROM {s_type}s WHERE term=?", (q0,))

            dbcur.execute(f"SELECT * FROM {s_type}s WHERE term=?", (q,))
            if dbcur.fetchone():
                dbcur.execute(f"DELETE FROM {s_type}s WHERE term=?", (q,))
            dbcur.execute(f"INSERT INTO {s_type}s VALUES (?,?)", (None, q))

            dbcon.commit()
            dbcur.close()

            if not name:
                # if not control.condVisibility('Window.IsActive(busydialog)'):
                if True:  # pomaga, aby klawiatura nie pojawiała ponownie się przy cofnięciu
                    navigator.navigator().addDirectoryItem('... proszę czekać, trwa wyszukiwanie ...', f"{s_type}Search", "search.png")
                    control.directory(int(sys.argv[1]), cacheToDisc=False)
                    generate_short_path = control.setting("generate_short_path") == "true"
                    if not generate_short_path:
                        url = "{}?action={}".format(sys.argv[0], f"{s_type}Searchterm&name=%s" % urllib.quote_plus(q))  # nie pasuje do generate_short_path
                    else:
                        control.window.setProperty('FanFilm.var.name', q)
                        url = "{}?action={}".format(sys.argv[0], f"{s_type}Searchterm&item=%s" % '1')
                    control.sleep0(100)
                    control.execute('Container.Update("%s")' % url)  # nowe rozdanie :-)
                    return  # koniec funkcji

            # control.busy()
            # fflog(f"{q=}",1,1)
            if s_type == "movie":
                # movies.get(self, self.tmdb_movie_search % urllib.quote_plus(q))
                movies.get(self, self.tmdb_movie_search % urllib.quote_plus(q), category=name)
                # movies.get(self, self.tmdb_movie_search % urllib.quote_plus(name) + f"&primary_release_year={year}", category=name)
                # movies.get(self, tmdb_movie_search_or_discover % urllib.quote_plus(name) + f"&primary_release_year={year}", category=name)
            elif s_type == "multi":
                movies.multi(self, self.tmdb_multi_search % urllib.quote_plus(name), category=name)
            elif s_type == "person":
                # pass
                # movies.persons(self, self.tmdb_person_link % urllib.quote_plus(q), department="all", media_type="ask")
                movies.persons(self, self.tmdb_person_link % urllib.quote_plus(name), department="all", media_type="ask", category=["Osoby", name])
            elif s_type == "collection":
                movies.collections(self, self.tmdb_collection_search % urllib.quote_plus(name), category=["Kolekcje", name])
            # control.idle()


        def search_term(self, name, s_type="movie", year="", discover=False):
            # log_utils.fflog(f"{name=}",1,1)
            if name and name != "..":
                # if m := re.search(r'^(.+) +(?:\(|y:)(\d{4})\)?$', name):
                if m := re.search(r'^(.+) +(?:[([]|y:|0)(\d{4})[)\]]?$', name):
                    name, year = m[1], m[2]
                if s_type == "movie":
                    tmdb_movie_search_or_discover = self.tmdb_movie_discover if discover else self.tmdb_movie_search
                    if year:
                        # movies.get(self, self.tmdb_movie_search % urllib.quote_plus(name) + f"&primary_release_year={year}", category=name)
                        movies.get(self, tmdb_movie_search_or_discover % urllib.quote_plus(name) + f"&primary_release_year={year}", category=name)
                    else:
                        # movies.get(self, self.tmdb_movie_search % urllib.quote_plus(name), category=name)
                        movies.get(self, tmdb_movie_search_or_discover % urllib.quote_plus(name), category=name)
                elif s_type == "multi":
                    movies.multi(self, self.tmdb_multi_search % urllib.quote_plus(name), category=name)
                elif s_type == "person":
                    movies.persons(self, self.tmdb_person_link % urllib.quote_plus(name), department="all", media_type="ask", category=["Osoby", name])
                elif s_type == "collection":
                    movies.collections(self, self.tmdb_collection_search % urllib.quote_plus(name), category=["Kolekcje", name])
            else:
                log_utils.fflog(f'szukanie niemożliwe z powodu błędnego parametru {name=}')
                import xbmcgui
                xbmcgui.Dialog().notification('FanFilm', 'szukanie niemożliwe z powodu błędnego parametru', xbmcgui.NOTIFICATION_ERROR)
                # fflog(f'dodanie pustego katalogu',1,1)
                # navigator.navigator().endDirectory()
                # control.sleep0(100)
                # fflog('akcja wstecz',1,1)
                # control.execute('Action(Back)')
            

        def search_epg(self, name, year):
            fflog(f'{name=}  {year=}',1,1)
            category = name
            if year:
                category += f' ({year})'
            # fflog(f'{category=}',1,1)
            movies.get(self, self.tmdb_epg_search % (urllib.quote_plus(name) + "&primary_release_year=" + (year or "")), category=category)
            

        ### SEARCH PERSONS ### TODO - historia
        def person(self, url=None, **kwargs):
            try:
                if not url:
                    t = control.lang(32010)
                    k = control.keyboard("", t)
                    k.doModal()
                    q = k.getText() if k.isConfirmed() else ""
                    q = q.strip() if q is not None else q

                    if q is None or q == "":
                        return

                    # q = cleantitle.normalize(q)  # for polish characters
                    
                    # fflog(f' {q=}',1,1)
                    # wstawić do bazy

                    # url = self.persons_link + urllib.quote_plus(q)
                    # url = '%s?action=moviePersons&url=%s' % (sys.argv[0], urllib.quote_plus(url))
                    movies.persons(self, self.tmdb_person_link % urllib.quote_plus(q), **kwargs)
                else:
                    movies.persons(self, url, **kwargs)  # przy następnych stronach
            except Exception as e:
                print(e)
                fflog_exc(1)
                return


        ## Osoby - wyszukiwanie ##
        def persons(self, url, department="Acting", media_type="movie", category=""):  # or "tv"
            # fflog(f'{url=}  {department=}  {media_type=}  {category=}',1,1)
            url = re.sub("(?<=api_key=)[^&]*", self.tm_user, url)
            url = re.sub("(?<=session_id=)[^&]*", self.tmdb_sessionid, url)
            if 0:
                import requests
                # tmdb_results = requests.get(url).json()
                tmdb_results = cache.get(requests.get, 1, url, callback=".json()")
                # tmdb_results = cache.get(requests.get, 1, kwargs={"url":url}, callback=".json()")  # można też tak
            else:
                tmdb_results = cache.get(self.doRequest, 1, url, callback=".json()")
            
            if not tmdb_results or "results" not in tmdb_results:
                fflog(f'problem, bo {tmdb_results=}  {url=}',1,1)
                self.addDirectory(self.list, category=category)
                return self.list  # na ten moment chyba niewykorzystywane
                return

            page  = tmdb_results.get("page", 0)
            total = tmdb_results.get("total_pages", 0)
            # fflog(f'{page=} {total=}',1,1)
            if page < total and "page=" in url:
                next_page = re.sub(r"page=\d+", f"page={page + 1}", url)
            else:
                next_page = ""
            # fflog(f'{next_page=}',1,1)

            next_page = re.sub("(?<=api_key=)[^&]*", "", next_page)
            next_page = re.sub("(?<=session_id=)[^&]*", "", next_page)

            department = "" if department == "all" else department

            translate_department = {
                                    "Acting": "aktor(ka)",
                                    "Camera": "zdjęcia",
                                    "Writing": "scenarzyst(k)a",
                                    "Directing": "reżyser(ka)",
                                    "Crew": "ekipa",
                                    "Art": "sztuka",
                                    "Production": "producent(ka)",
                                   }

            generate_short_path = control.setting("generate_short_path") == "true"

            i = 0
            for item in tmdb_results["results"]:
                # if True:
                if not department or item.get("known_for_department") == department:
                    i += 1

                    if item.get("profile_path"):
                        # photo = "https://www.themoviedb.org/t/p/w300_and_h450_bestv2" + item["profile_path"]  # umożliwia wycięcie fragmentu z oryginalnego zdjęcia
                        photo = "https://image.tmdb.org/t/p/w300" + item["profile_path"]  # skaluje całe zdjęcie
                    else:
                        photo = "people.png"
                        photo = "DefaultActor.png"
                        photo = "DefaultActorSolid.png"
                        # photo = "DefaultArtist.png"
                        # photo = ""

                    gender = item.get("gender") or 0

                    translated_department = translate_department.get(item.get("known_for_department"), item.get("known_for_department"))
                    if gender == 1:
                        translated_department = translated_department.replace("(", "").replace(")", "")
                    elif gender == 2:
                        translated_department = re.sub(r"\(\w+\)", "", translated_department)

                    # media_type = "" if media_type == "ask" else media_type

                    details = {}
                    try:
                        if 0:
                            import requests
                            # details = requests.get(self.tmdb_personid_link % item["id"]).json()
                            details = cache.get(requests.get, 1, self.tmdb_personid_link % item["id"], callback=".json()")
                        else:
                            details = cache.get(self.doRequest, 1, self.tmdb_personid_link % item["id"], callback=".json()")
                        details.get("deathday")  # test czy to słownik
                    except:
                        pass
                    # fflog(f'{details=}',1,1)

                    castandrole = []
                    for zz in item.get("known_for"):
                        castandrole.append({
                            "name": zz.get("title") or zz.get("name") or "",
                            "role": zz.get("release_date", "")[:4] or zz.get("first_air_date", "")[:4] or "",
                            # "thumbnail": ("https://www.themoviedb.org/t/p/w150_and_h225_bestv2" + zz["backdrop_path"]) if zz.get("backdrop_path") else "",
                            "thumbnail": ("https://image.tmdb.org/t/p/w150_and_h225_bestv2" + zz["backdrop_path"]) if zz.get("backdrop_path") else "",
                        })

                    tagline = [z["name"] for z in castandrole if z.get("name")]
                    if tagline:
                        if gender == 1:
                            tagline = ["znana m.in. z:"] + tagline
                        else:
                            tagline = ["znany m.in. z:"] + tagline
                        if len(tagline) < 4:
                            tagline[0] = tagline[0].replace(" m.in.", "")
                    tagline = "\n - ".join(tagline)
                    # tagline = ""

                    for zz in details.get("images", {}).get("profiles", {}):
                        if zz.get("file_path") == item.get("profile_path"):
                            continue
                        castandrole.append({
                            "name": " ",
                            # "thumbnail": ("https://www.themoviedb.org/t/p/w150_and_h225_bestv2" + zz["file_path"]) if zz.get("file_path") else "",
                            "thumbnail": ("https://image.tmdb.org/t/p/w150_and_h225_bestv2" + zz["file_path"]) if zz.get("file_path") else "",
                        })

                    plotoutline = (details.get("birthday") or "")[:4]
                    if plotoutline:
                        plotoutline += " - "
                    if details.get("deathday"):
                        plotoutline += f'{details["deathday"][:4]} '

                    plotoutline, tagline = tagline, plotoutline  # zamianka

                    self.list.append(
                        {
                         # "name": item.get("name"),
                         "name": item.get("name") + (f'  [LIGHT][I][{translated_department}][/I][/LIGHT]' if not department else ''),
                         "image": photo,
                         # "url": self.tmdb_personid_credits_link % str(item.get("id")),
                         "url": self.tmdb_personid_credits_link % (str(item.get("id")), media_type),
                         # "action": "movies" + (f'&item={item.get("name")}' if generate_short_path else ""),
                         # "action": "movies" + (f'&item={i}' if generate_short_path else ""),
                         "action": ("movies" if media_type == "movie" else "tvshows" if media_type == "tv" else "findMediaWithPerson") + (f'&item={i}' if generate_short_path else ""),
                         "plotoutline": plotoutline,
                         "tagline": tagline,
                         "plot": details.get("biography"),
                         "biography": True if details.get("biography") else False,
                         "castandrole": castandrole if castandrole else [{"name": item.get("name"), "role": translated_department, "thumbnail": photo if photo.startswith("http") else ""}],
                         # może pomyśleć nad informacjami typu "znana z ..."
                        }
                    )
            # fflog(f'{len(self.list)=}',1,1)
            # fflog(f'self.list={json.dumps(self.list, indent=2)}',1,1)
            if self.list:
                # self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))  # strona www nie sortuje
                pass
            if self.list and next_page:
                self.list[0]["next"] = {"url": next_page,
                                        # "action": f"{media_type}Person" + ("&department=all" if not department else ""),
                                        "action": f"{media_type}Person".replace("askPerson", "searchPerson"),
                                        # "action": f"{media_type}Person".replace("askPerson", "searchPerson") + (f"&department=all&media_type={media_type}" if not department else ""),
                                        "total_pages": total,
                                        "curr_page": page,
                                        # "category": category,
                                       }
            self.addDirectory(self.list, category=category)
            return self.list  # na ten moment chyba niewykorzystywane


        def collections(self, url, category=""):
            # fflog(f'{url=} ',1,1)
            url = re.sub("(?<=api_key=)[^&]*", self.tm_user, url)
            url = re.sub("(?<=session_id=)[^&]*", self.tmdb_sessionid, url)

            # tmdb_results = requests.get(url).json()
            tmdb_results = self.doRequest(url).json()
            
            if not tmdb_results or "results" not in tmdb_results:
                fflog(f'{tmdb_results=}  {url=}',1,1)
                self.addDirectory(self.list, category=category)
                return self.list  # na ten moment chyba niewykorzystywane
                return

            page  = tmdb_results.get("page", 0)
            total = tmdb_results.get("total_pages", 0)
            # fflog(f'{page=} {total=}',1,1)
            if page < total and "page=" in url:
                next_page = re.sub(r"page=\d+", f"page={page + 1}", url)
            else:
                next_page = ""
            # fflog(f'{next_page=}',1,1)

            next_page = re.sub("(?<=api_key=)[^&]*", "", next_page)
            next_page = re.sub("(?<=session_id=)[^&]*", "", next_page)

            generate_short_path = control.setting("generate_short_path") == "true"

            i = 0

            for item in tmdb_results.get("results", []):

                name = item.get("name")

                if "Collection" not in name and "Kolekcja" not in name:  # takie, założenie, że w nazwie musi być słowo Kolekcja, bo zdarzają się błędne wyniki zwrócone przez TMDB
                    continue

                i += 1

                if item.get("poster_path"):
                    # image = "http://www.themoviedb.org/t/p/w300_and_h450_bestv2" + item["poster_path"]
                    image = "https://image.tmdb.org/t/p/w300" + item["poster_path"]
                else:
                    image = ""

                if item.get("backdrop_path"):
                    # fanart = "http://www.themoviedb.org/t/p/w1280_and_h720_bestv2" + item["backdrop_path"]  # umożliwia wycięcie fragmentu z oryginalnego zdjęcia
                    fanart = "https://image.tmdb.org/t/p/w1280" + item["backdrop_path"]
                else:
                    fanart = ""
                # fflog(f'{fanart=}',1,1)

                self.list.append({
                    "name": name,
                    "image": image,
                    "fanart": fanart,
                    # "action": "collections" + (f'&item={i}' if generate_short_path else ""),
                    "action": "collections" + f"&item={str(i)}",
                    "url": self.tmdb_collection % str(item.get("id")) + "&query=%s" % urllib.quote_plus(name),
                    "plot": item.get("overview") or "",
                })

            if self.list and next_page:
                self.list[0]["next"] = {
                                        "action": "collectionsPage",
                                        "url": next_page,
                                        "total_pages": total,
                                        "curr_page": page,
                                       }
            if self.list:
                self.addDirectory(self.list, category=category)
            else:
                import xbmcgui
                xbmcgui.Dialog().notification('Błąd', 'Nic nie znaleziono', xbmcgui.NOTIFICATION_ERROR)
                fflog('nic nie znaleziono', 0)
                fflog(f'{params=}', 0)
                fflog(f'{url=}', 0)
                # navigator.navigator().endDirectory()
                # control.sleep0(100)
                # control.execute('Action(Back)')


        def multi(self, url, refresh=None, category=""):
            # self.list = self.tmdb_list(url, disallowed_media_types=["person"])
            self.list = cache.get(self.tmdb_list, 12, url, ["person"], ["movie", "tv"])
            if self.list and self.next_page and self.list[0].get("next"):
                # cache następnej strony  - na razie coś chyba inaczej działa niż w funkcji get (2 razy pobiera stronę przy przejściu do następnej strony)
                # thread = Thread(target=cache.get, args=(self.tmdb_list, 12, self.list[0].get("next"), ["person"], ["movie", "tv"],))
                # thread.start()
                pass
            if self.list:
                self.movieDirectory(self.list, multi=True, category=category)
            else:
                fflog( 'nic nie znaleziono', 1,1)
                fflog(f'{params=}', 0)
                fflog(f'{url=}', 0)
                import xbmcgui
                xbmcgui.Dialog().notification('Błąd', 'Nic nie znaleziono', xbmcgui.NOTIFICATION_ERROR)
                # navigator.navigator().endDirectory()
                # control.sleep0(100)
                # control.execute('Action(Back)')
            return self.list


        def list_by_imdb_or_tmdb(self, lista, category=""):
            media_list = []
            for l in lista:
                media_list.append({
                    "imdb": l.get('imdb') or "0",
                    "tmdb": l.get('tmdb') or "0",
                    "media_type": "tv" if l.get("media_type")=="episode" else l.get("media_type", "movie"),
                })
            # fflog(f'{media_list=}',1,1)
            media_list = [i for n, i in enumerate(media_list) if i not in media_list[:n]]  # eliminacja dubli
            self.list = self.worker(media_list)  # doczytanie większej ilości parametrów filmu
            if self.list:
                self.movieDirectory(self.list, multi=True, category=category)
            else:
                fflog( 'nic nie znaleziono', 1,1)
                fflog(f'{params=}', 0)
                import xbmcgui
                xbmcgui.Dialog().notification('Błąd', 'Nic nie znaleziono', xbmcgui.NOTIFICATION_ERROR)
                # navigator.navigator().endDirectory()
                # control.sleep0(100)
                # control.execute('Action(Back)')       


     
        ### SCRAPERY API/STRON ###

        ### TMDB ###
        def tmdb_list(self, url, disallowed_media_types=["tv"], allowed_media_types=["movie"]):
            """pobiera dane z serwisu TMDB za pomocą ich API """

            if allowed_media_types is None:
                allowed_media_types = []

            media_list = []

            # fflog(f'{params=}', 1, 1)
            # fflog(f'{url=}',1,1)
            # fflog(f'{disallowed_media_types=}',1,1)

            if 0:
                if (
                    "/4/" in url
                    # or self.tm_bearer  # ten ogólny (nie zastąpi chyba session_id)
                    # or self.tmdb_access_token  # a ten bardziej indywidualny chyba (zastępuje chyba nawet session_id)
                   ):  # v4 API
                    fflog(f'zastosowane będzie v4 API',1,1)
                    bearer = self.tmdb_access_token or self.tm_bearer
                    headers = {
                        "accept": "application/json",
                        # "content-type": "application/json",  # to tylko przy post chyba potrzebne
                        # "Authorization": f"Bearer {self.tm_bearer}"  # nie wiem, który powinien być
                        # "Authorization": f"Bearer {self.tmdb_access_token}"  # nie wiem, który powinien być
                        "Authorization": f"Bearer {bearer}"
                    }
                    if bearer:
                        # fflog('usuwam zmienne kluczy z adresu (jeśli są)',1,1)
                        url = re.sub(r"[&]?\bapi_key=[^&]*", "", url)
                        url = re.sub(r"[&]?\bsession_id=[^&]*", "", url)  # kurcze, tylko w niektórych endpointach wg dokumentacji to jest wymagane
                        url = url.rstrip("?")
                        # fflog(f'{url=}',1,1)
                    if 0:  # do testów tylko, bo tak naprawdę, to nie powinno się doczepiać takich rzeczy do adresu
                        if self.tmdb_sessionid and self.tm_user and "api_key=" not in url and "&session_id=" not in url:
                            url += "?" if not "?" in url else "&"
                            url += "api_key="+self.tm_user
                            url += "&session_id="+self.tmdb_sessionid
                    # control.log(f'v4 {url=}',1)
                    # tmdb_results = requests.get(url)
                    # tmdb_results = requests.get(url, headers=headers)  # zapytanie do serwera
                    tmdb_results = self.session.get(url, headers=headers)  # zapytanie do serwera
                else:
                    headers = {}  # dla komatybilności
                    # dodanie danych autoryzacyjnych (gdy potrzebne)
                    url = re.sub("(?<=api_key=)[^&]*", self.tm_user, url)
                    url = re.sub("(?<=session_id=)[^&]*", self.tmdb_sessionid, url)
                    # guest_session_id = control.setting('tmdb.guest_session_id')
                    # url = re.sub("(?<=/guest_session/)%s", guest_session_id, url)
                    # url = url.replace("/guest_session/%s/", f"/guest_session/{guest_session_id}/")
                    # control.log(f'v3 {url=}',1)
                    # tmdb_results = requests.get(url)  # zapytanie do serwera
                    tmdb_results = self.session.get(url)  # zapytanie do serwera
            else:
                tmdb_results = self.doRequest(url)  # zapytanie do serwera

            if not tmdb_results:
                fflog(f'wystąpił jakiś problem  {tmdb_results=}  {url=}',1,1)
                pass

            tmdb_results = tmdb_results.json()  # format json, czyli słownik będzie w Pythonie
            # fflog(f'{tmdb_results=}',1,1)
            # fflog(f'tmdb_results={json.dumps(tmdb_results, indent=2)}',1,1)

            page  = tmdb_results.get("page", 0)
            total = tmdb_results.get("total_pages", 0)
            # fflog(f'{page=}  {total=}',1,1)
            total = 500 if total > 500 else total  # jakieś ograniczenie ze strony tmdb
            # fflog(f'{page=}  {total=}',1,1)
            if page < total and "page=" in url:
                next_page = re.sub(r"page=\d+", f"page={page + 1}", url)
            else:
                next_page = ""

            # next_page = re.sub("(?<=api_key=)[^&]*", "", next_page)
            # next_page = re.sub("(?<=session_id=)[^&]*", "", next_page)
            # fflog(f'{next_page=}')

            moviessort = int(control.setting("movies.sort"))
            # fflog(f'{moviessort=}',1,1)

            # monitor = control.monitor
            fflog(f'{self.idx=}',1,1)
            if (not self.idx
                or ("/now_playing" in url and moviessort)  # taki wyjątek
                ):
                # fflog(f'{self.idx=}',1,1)
                if  ("/watchlist/" in url or "/favorite/" in url
                     or "/now_playing" in url
                    ):
                    fflog(f'kolejne strony mogą być potrzebne')
                    # tmdb_results = {'results': []}  # nie, bo chcę połączyć z pierwszym
                    for np in range(2, total + 1):  # od 2 strony
                        fflog(f'{np=}')
                        next_url = re.sub(r"page=\d+", f"page={np}", url)
                        # fflog(f'{next_url=}',1,1)
                        if 0:
                            # tmdb_results_tmp = requests.get(next_url)  # kolejny request do serwera
                            tmdb_results_tmp = self.session.get(next_url)  # kolejny request do serwera
                            # tmdb_results_tmp = requests.get(next_url, headers=headers)  # j.w.
                        else:
                            tmdb_results_tmp = self.doRequest(next_url)  # j.w.
                        if tmdb_results_tmp:
                            tmdb_results_tmp = tmdb_results_tmp.json()
                            [tmdb_results['results'].append(x) for x in tmdb_results_tmp['results']]  # dodanie wyników
                        else:
                            fflog(f'problem  {tmdb_results_tmp=}  {next_url=}',1,1)
                            pass
                        if monitor.abortRequested():
                            fflog('sygnal zamknięcia Kodi',1,1)
                            return []
                            # return media_list
                            # return sys.exit()
                    if self.idx:
                        next_page = ""  # czy to dobrze? pomyśleć nad tym
                else:
                    fflog(f'adres url nie jest objęty warunkiem pozyskiwania kolejnych podstron')
                    pass

            if "results" in tmdb_results:
                items = tmdb_results["results"]
            elif "items" in tmdb_results:
                items = tmdb_results["items"]
            elif "parts" in tmdb_results:
                items = tmdb_results["parts"]
            elif "cast" in tmdb_results and (items := tmdb_results["cast"]):
                # items = tmdb_results["cast"]
                pass
            elif "crew" in tmdb_results and (items := tmdb_results["crew"]):
                # items = tmdb_results["crew"]
                pass
            elif "id" in tmdb_results and isinstance(tmdb_results, dict):
                items = [tmdb_results]
            elif isinstance(tmdb_results, list):  # tego nie testowałem jeszcze
                items = tmdb_results
            else:
                fflog(f'[tmdb_list] błąd: brak poprawnych danych do stworzenia listy  |  {tmdb_results=}')
                return media_list

            fflog(f'{len(items)=}',1,1)
            media_id_list = []  # pomocniczo
            for item in items:
                # fflog(f'{item.get("media_type")=}',1,1)
                # if item.get('original_language') != 'ru':
                # if item.get("media_type") != "tv":
                if item.get("media_type") not in disallowed_media_types:
                    if allowed_media_types and item.get("media_type") and item.get("media_type") not in allowed_media_types:
                        fflog(f'odrzucony, bo {item.get("media_type")=} not in {allowed_media_types=}',0,1)
                        continue
                    if allowed_media_types == ["movie"] and item.get("video") is None:  # trafiłem, że api zwróciło kolekcję na zapytanie o filmy
                        continue
                    # if not any(x for x in media_list if x["tmdb"] == item.get("id")):
                    if (m_id := item.get("id")) not in media_id_list:
                        if m_id:
                            media_id_list.append(m_id)
                        media_list.append({
                                           "name": item.get("name", ""),
                                           "title": item.get("title", ""),
                                           "originaltitle": item.get("original_title", ""),
                                           "year": item.get("release_date", "")[0:4],  # to nie zawsze jest prawdą (bywają nawet duże różnice czasami)
                                           "premiered": item.get("release_date", ""),  # może się różnić od year
                                           # "release_date": item.get("release_date", ""),  # w Kodi jest ReleaseDate ale odnosi się tylko do muzyki
                                           # i ten parametr TMDB potrafi dać w zależności od zapytania inny (czyli nie można na nim polegać)
                                           "tmdb": str(item.get("id", "")),
                                           "plot": item.get("overview", ""),
                                           "votes": item.get("vote_count", ""),
                                           "rating": item.get("vote_average", ""),
                                           "popularity": item.get("popularity", ""),
                                           "tvdb": "0",
                                           "imdb": "0",
                                           "poster": "0",
                                           "next": next_page,  # url
                                           "curr_page": page,  # number
                                           "total_pages": total,
                                           "media_type": item.get("media_type", ""),
                                           "collection": str(item.get("collection", "")),
                                           # "video": item.get("video", "-") if allowed_media_types==["movie"] else None,
                                          })
                else:
                    fflog(f'niedopuszczony, bo {item.get("media_type")=} is on {disallowed_media_types=}',0,1)
                    pass
            # fflog(f'media_list={json.dumps(media_list, indent=2)}',1,1)

            # dodatkowe sortowania dla niektórych typów list
            # tylko problem taki, że to idzie do cache i gdy user przestawi sposób sortowania w ustawieniach, to zmiana nie zostanie zaaplikowana.
            # drugi problem z tym taki, że premiered (release_date) zmienia się potem na inną i sortowanie w innym miejscu nie pomoże
            # rozwiązanie, to opcja z menu kontekstowego "Odśwież teraz"
            # tylko z tym sortowaniem po stronie FF jest taki problem, że sortujemy tylko 1 stronę, podczas gdy całość została podzielona na strony z uwzględnieniem sortowania po stronie TMDB
            if "/now_playing" in url:
                reverse = True
                if moviessort:
                    fflog(f'posortowanie wg premiery ({"malejąco" if reverse else "rosnąco"})',1,1)
                    media_list = sorted(media_list, key=lambda k: k.get("premiered", ""), reverse=reverse)
                    pass
                else:
                    # fflog('sortowanie Tmdb (często wg popularności)',1)
                    pass
            # fflog(f'media_list={json.dumps(media_list, indent=2)}',1,1)

            media_list = self.worker(media_list)  # doczytanie większej ilości parametrów filmu
            # fflog(f'media_list={json.dumps(media_list, indent=2)}',1,1)

            return media_list


        ### TRAKT ###

        def search_trakt_lists(self):
            folderpath = control.infoLabel('Container.FolderPath')
            params1 = dict(urllib.parse_qsl(folderpath.split('?')[-1]))
            action1 = params1.get('action')  # może być też puste
            fflog(f'{action1=}',1,1)
            if action1 in ["movies", "moviePage"]:
                # poniższe nic nie zmianiją
                # fflog(f'dodanie pustego katalogu',1,1)
                # navigator.navigator().endDirectory()
                # control.sleep0(100)
                # url = "{}?action={}".format(sys.argv[0], "publicTraktListsNavigator")
                # fflog(f'{url=}',1,1)
                # control.execute('Container.Update("%s")' % url)  # przetestowałem i bez zmian - taki sam efekt
                # fflog(f'akcja wstecz',1,1)
                # control.execute('Action(Back)')
                # control.sleep0(100)
                return
                pass

            url = self.search_lists_link
            # search_phrase = "80s"
            search_phrase = control.dialog.input("szukana fraza:", "")
            search_phrase = search_phrase.strip()
            if search_phrase:
                # params={'query': search_phrase}  # problem przy next page (nie zachowuje się - trzeba by przerobić kod, choć i tak sprowadzi się to do wprowadzenia do adresu, bo w Kodi nie ma post dla pozycji)
                # url = "https://api.trakt.tv" + "/search/list?query=90s";  params = None
                # url = "https://api.trakt.tv" + "/search/list?query=tron"
                q = dict(urllib.parse_qsl(urllib.urlsplit(url).query))
                q.update({"query": search_phrase})
                q = (urllib.urlencode(q)).replace("%2C", ",")
                url = url.replace("?" + urllib.urlparse(url).query, "") + "?" + q
                # u = u.rstrip('?&')
                # fflog(f'{url=}',1,1)
                # fflog(f'{params=}',1,1)  # zmienna globalna!
                try:
                    # control.busy()
                    self.trakt_list(url, params=params)
                except Exception:
                    fflog_exc(1)
                    pass
                finally:
                    # fflog('finally',1,1)
                    # control.idle(2)
                    pass
            else:
                # control.sleep(100)
                pass


        def trakt_list(self, url, user=None, sort_how=None, multi=True, params=None):
            # fflog(f'{url=}  {user=}  {params=}',1,1)
            result2 = []
            items = []
            media_list = []
            headers = {}
            try:
                page_max_items = 20
                if not self.idx:
                    page_max_items = 10000

                pagination = "0"
                if not "TRAKTNEXT" in url:
                    pass
                else:
                    pagination = str(url).split("TRAKTNEXT=")[1]
                    if page := re.search(r'page=(\d*)', pagination):
                        # fflog(f'{page[1]=}  {url=}',1,1)
                        pagination = str( int(page[1]) * page_max_items - page_max_items)
        
                    url = str(url).split("TRAKTNEXT=")[0]
                fflog(f'{pagination=}',1,1)

                if sort_how:
                    # fflog(f'{sort_how=}',1,1)
                    # fflog(f'{url=}',1,1)
                    # if re.search('[?&]sort_how=[^&]*', url):
                        # url = re.sub("[?&]sort_how=[^&]*", "", url)
                    if f"sort_how={sort_how}" not in url:  # uproszczenie
                        sign = "?" if "?" not in url else "&"
                        url += f"{sign}sort_how={sort_how}"
                    # fflog(f'{url=}',1,1)

                q = dict(urllib.parse_qsl(urllib.urlsplit(url).query))
                # tmdb_results = self.find_Movie_ID(q['query'])
                # q.update({"extended": "full"})  # i tak dane będą pobierane z tmdb, więc to chyba nic nie daje (trzeba by dogłębniejsze testy zrobić)
                # q.update({"sort_by": "votes", "sort_how": "asc"})  # test
                # q.update({"sort_how": "desc"})  # test
                # if sort_how:
                    # q.update({"sort_how": sort_how})  # robię to dla url, aby na kolejne strony się przenosiło
                    # pass
                q = (urllib.urlencode(q)).replace("%2C", ",")
                u = url.replace("?" + urllib.urlparse(url).query, "") + "?" + q
                u = u.rstrip('?&')
                # url = u  # nie wienm czy to dobrze, bo po coś u zostało wydzielone od url
                # u2 = f'https://api.trakt.tv/search/tmdb/%s?type=movie'
                # fflog(f'{u=}',1,1)
                # u = u.replace("/users/trakt/lists/", "/lists/")
                # u = u.replace("/users/trakt/", "/")
                # u = u.replace("/users/None/", "/")
                # fflog(f'{u=}  {params=}',1,1)  # params tu jako lokalna zmienna
                if params or user:
                    # fflog(f'{params=}  {user=}  {u=}',1,1)
                    result, headers = trakt.getTraktAsJson(u, params=params, ret_headers=True)  # pobranie danych z serwera
                else:
                    # fflog(f'tylko {u=}',1,1)
                    # result = trakt.getTraktAsJson(u)  # pobranie danych z serwera
                    # result, headers = trakt.getTraktAsJson(u, ret_headers=True)  # pobranie danych z serwera
                    result, headers = cache.get(trakt.getTraktAsJson, 0.01, u, None, True)  # cache powoduje problem, jak za szybko chce się pobrać listę np. Ulubionych po zmianie na stronie

                # fflog(f'{type(headers)=}',1,1)
                # fflog(f'{headers=}',1,1)
                # fflog(f' headers={json.dumps(dict(headers), indent=2)}',1,1)

                # fflog(f'{len(result)=}',1,1)
                # fflog(f'{result=}',1,1)
                # fflog(f'{len(result)=}  result={json.dumps(result, indent=2)}',1,1)
                for i in result:
                    # fflog(f'i={json.dumps(i, indent=2)}',1,1)
                    try:
                        if i.get('movie'):
                            result2.append(i)
                        elif i.get('ids'):
                            result2.append(i)
                        else:
                            # fflog('inny typ niż "movie" lub "ids"',1,1)
                            if i.get('list'):
                                userlists = cache.get(self.trakt_user_list, 12, "", self.trakt_user, result)
                                self.list = userlists
                                if not self.list:
                                    import xbmcgui
                                    xbmcgui.Dialog().notification('Błąd', 'Nic nie znaleziono', xbmcgui.NOTIFICATION_WARNING, time=2000)
                                    fflog('nic nie znaleziono', 0)
                                    fflog(f'{params=}', 0)
                                    fflog(f'{url=}', 0)
                                    # navigator.navigator().endDirectory()
                                    # control.sleep0(100)
                                    # control.execute('Action(Back)')
                                    # return None
                                generate_short_path = control.setting("generate_short_path") == "true"
                                for i in range(0, len(self.list)):
                                    self.list[i].update({"action": "movies" + (f"&item={str(i+1)}" if generate_short_path else "")})
                                # fflog(f'jeszcze sortowanie',1,1)
                                # fflog(f'{len(self.list)=} self.list={json.dumps(self.list, indent=2)}')
                                # self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))  # to "psuje" tutaj
                                # self.list = sorted(self.list, key=lambda k: k["likes"], reverse=True)
                                fflog(f'{len(self.list)=}')
                                if (total := int(headers.get('X-Pagination-Page-Count'))) > (page := int(headers.get('X-Pagination-Page'))):
                                    # fflog(f'{page=}  {total=}  \n{url=} \n  {u=}',1,1)
                                    q = dict(urllib.parse_qsl(urllib.urlsplit(url).query))
                                    try:
                                        q.update({"page": str(int(q["page"]) + 1)})
                                    except:
                                        q.update({"page": str(int(page) + 1)})
                                    # if sort_how:
                                        # q.update({"sort_how": sort_how})
                                        # pass
                                    q = (urllib.urlencode(q)).replace("%2C", ",")
                                    next_page = url.replace("?" + urllib.urlparse(url).query, "") + "?" + q
                                    if self.list:
                                        if 0:
                                            self.list[0].update({"next": next_page})
                                        else:
                                            self.list[0]["next"] = {"url": next_page,
                                                                    # "action": "movies",
                                                                    "action": "listPage",
                                                                    "total_pages": total,
                                                                    "curr_page": page,
                                                                    # "category": category,
                                                                   }
                                # fflog(f'{len(self.list)=} self.list={json.dumps(self.list, indent=2)}')
                                self.addDirectory(self.list, queue=True, add_refresh=True)
                                # control.idle(2)
                                return None
                            else:
                                # fflog(f'i={json.dumps(i, indent=2)}',1,1)
                                if multi and i.get('show'):
                                    result2.append(i)
                                else:
                                    fflog(f"{i.get('type')=}",1,1)
                                    # bo są jeszcze season oraz episode (a może i people też)
                                    pass
                                pass

                    except Exception:
                        fflog_exc(1)
                        pass
                fflog(f'{len(result2)=}',1,1)

                try:
                    if "/users/" in url and "/collection/" in url:
                        if not multi:
                            result2 = sorted( result2, key=lambda k: utils.title_key(k['movie']["title"]) )
                        else:
                            result2 = sorted( result2, key=lambda k: utils.title_key(k.get('movie', {}).get("title") or k.get('show', {}).get("title")) )
                            # media_type = i.get('type')
                            # result2 = sorted( result2, key=lambda k: utils.title_key(k[media_type]["title"]) )
                except Exception:
                    fflog_exc(1)
                    pass

                # result = convert(result)
                for i in result2[int(pagination):int(pagination) + page_max_items]:  # wybranie fragmentu z całej odpowiedzi serwera
                    # fflog(f'i={json.dumps(i, indent=2)}',1,1)
                    try:
                        if multi:
                            items.append(i.get("movie") or {**i.get("show"), **{"type": i['type']}})
                            # item = i[i['type']]
                            # item.update({"type": i['type']})
                            # items.append( item )
                        else:
                            items.append( i["movie"] )
                    except Exception:
                        fflog_exc(1)
                        pass
                if len(items) == 0:
                    fflog(f'{len(items)=}',1,1)
                    items = result2  # bo są różne wersje wyników
                    fflog(f'{len(items)=}',1,1)
                    pass
            except Exception as e:
                fflog_exc(1)
                pass

            try:
                q = dict(urllib.parse_qsl(urllib.urlsplit(url).query))
                if not int(q["limit"]) == len(items):
                    raise Exception()
                q.update({"page": str(int(q["page"]) + 1)})
                # if sort_how:
                    # q.update({"sort_how": sort_how})
                    # pass
                q = (urllib.urlencode(q)).replace("%2C", ",")
                next_page = url.replace("?" + urllib.urlparse(url).query, "") + "?" + q
            except:
                next_page = ""
            # fflog(f'{next_page=}',1,1)
            if not next_page and self.idx:
                if len(result2[int(pagination):int(pagination) + 21]) == 21 and page_max_items < len(result2):
                    next_page = url + "TRAKTNEXT=" + str(int(pagination) + page_max_items)
                else:
                    self.next_page = False
                # fflog(f'{next_page=}',1,1)

            curr_page   = int(headers.get('X-Pagination-Page') or 0)
            total_pages = int(headers.get('X-Pagination-Page-Count') or 0)
            # fflog(f'{curr_page=}  {total_pages=}',1,1)
            if total_pages <= 1:
                from math import ceil
                curr_page = int( int(pagination) / page_max_items ) + 1
                total_pages = ceil( len(result2) / page_max_items )
                # fflog(f'{curr_page=}  {total_pages=}',1,1)
            fflog(f'{curr_page=}  {total_pages=}',1,1)

            fflog(f'{len(items)=}',1,1)
            for item in items:
                # fflog(f'item={json.dumps(item, indent=2)}',1,1)
                try:
                    media_type = item.get("type")
                    if media_type in ["season", "episode"]:
                        media_type = "show"
                    if media_type == "people":
                        continue

                    slug = item["ids"].get("slug")
                    if any(x["slug"] == slug for x in media_list):
                        continue

                    imdb = item["ids"].get("imdb")
                    if imdb is None or imdb == "":
                        #raise Exception()
                        # continue
                        pass
                    # imdb = "tt" + re.sub("[^0-9]", "", str(imdb))  # to już chyba nieaktualne

                    tmdb = str(item.get("ids", {}).get("tmdb", 0))

                    year = item.get("year") or ""
                    year = re.sub("[^0-9]", "", str(year))
                    year_now = self.datetime.strftime("%Y")
                    if year and int(year) > int(year_now):
                        #raise Exception()
                        continue

                    if not "title" in item:
                        continue
                    title = item["title"]  # angielski tytuł
                    title = client.replaceHTMLCodes(title)
                    localtitle = title
                    # localtitle = trakt.getMovieTranslation(imdb, lang=self.lang) or title  # nie wiem, czy jest sens, bo i tak to zostanie pobrane z tmdb, a to bardzo spowalnia kod
                    """
                    country = item["country"]
                    fflog(f'{country=}')
                    aliases = trakt.getMovieAliases(imdb)  # kicha, bo może być kilka, więc nie wiadomo które to oryginlny
                    fflog(f'{aliases=}')
                    """
                    try:
                        premiered = item["released"]
                    except:
                        premiered = "0"
                    try:
                        premiered = re.compile(r"(\d{4}-\d{2}-\d{2})").findall(premiered)[0]
                    except:
                        premiered = "0"

                    try:
                        genre = item["genres"]
                    except:
                        genre = "0"
                    genre = [i.title() for i in genre]
                    if not genre:
                        genre = "0"
                    genre = " / ".join(genre)

                    try:
                        duration = str(item["runtime"])
                    except:
                        duration = "0"
                    if duration is None:
                        duration = "0"

                    try:
                        rating = str(item["rating"])
                    except:
                        rating = "0"
                    if rating is None or rating == "0.0":
                        rating = "0"

                    try:
                        votes = str(item["votes"])
                    except:
                        votes = "0"
                    try:
                        votes = str(format(int(votes), ",d"))
                    except:
                        pass
                    if votes is None:
                        votes = "0"

                    try:
                        mpaa = item["certification"]
                    except:
                        mpaa = "0"
                    if mpaa is None:
                        mpaa = "0"

                    try:
                        plot = item["overview"]
                    except:
                        plot = "0"
                    if plot is None:
                        plot = "0"
                    plot = client.replaceHTMLCodes(plot)

                    try:
                        tagline = item["tagline"]
                    except:
                        tagline = "0"
                    if tagline is None:
                        tagline = "0"
                    tagline = client.replaceHTMLCodes(tagline)

                    media_list.append(
                        {
                         "slug": slug,
                         "title": title, "localtitle": localtitle, "originaltitle": title, "year": year, "premiered": premiered, "genre": genre,
                         "duration": duration, "rating": rating, "votes": votes, "mpaa": mpaa, "plot": plot,
                         "tagline": tagline, "imdb": imdb, "tmdb": tmdb, "tvdb": "0", "poster": "0", "next": next_page,
                         "total_pages": total_pages, "curr_page": curr_page,
                         "media_type": media_type,
                        }
                    )
                    # if media_type:
                        # media_list[-1].update({"media_type": media_type})
                        # pass

                except Exception:
                    fflog_exc(1)
                    pass

            fflog(f'{len(media_list)=}',1,1)
            # fflog(f'media_list={json.dumps(media_list, indent=2)}',1,1)
            if media_list:
                fflog('jeszcze wzbogacić o informacje z tmdb',1,1)
                media_list = self.worker(media_list)  # aby wzbogacić o informacje z tmdb
            return media_list


        ### IMDB ###
        def imdb_list(self, url):
            media_list = []
            fflog(f'[imdb_list] {url=}')

            for i in re.findall(r"date\[(\d+)]", url):
                url = url.replace("date[%s]" % i, (self.datetime - datetime.timedelta(days=int(i))).strftime("%Y-%m-%d"), )
                fflog(f'[imdb_list] {url=}')

            def imdb_watchlist_id(url):  # na razie (albo już) nieużywane
                # fflog(f'[imdb_list][imdb_watchlist_id] {url=}')
                resp = client.request(url)
                # fflog(f'[imdb_list][imdb_watchlist_id] {resp=}')
                if resp:
                    resp1 = client.parseDOM(resp, "meta", ret="content", attrs={"property": "pageId"}, )
                # fflog(f'[imdb_list][imdb_watchlist_id] {resp1=}')
                if resp1:
                    return resp1[0]
                else:
                    return []  # nie wiem, czy to dobry zwrot
                # return resp  # kod HTML

            # fflog(f'[imdb_list] {url=}')
            if url == self.imdbwatchlist_link:
                fflog(f'[imdb_list] imdbwatchlist  (wariant 0)')
                pass
            elif url == self.imdbwatchlist1_link:
                fflog(f'[imdb_list] imdbwatchlist1 (wariant 1)')
                # coś się zmieniło na stronie IMDb - może to już niepotrzebne
                # url = cache.get(imdb_watchlist_id, 8640, url)
                # url = self.imdblist1_link % url
                pass
            elif url == self.imdbwatchlist2_link:
                fflog(f'[imdb_list] imdbwatchlist2')
                # coś się zmieniło na stronie IMDb - może to już niepotrzebne
                # url = cache.get(imdb_watchlist_id, 8640, url)
                # url = self.imdblist2_link % url
                pass
            else:
                # to nie jest watchlista
                pass
            # fflog(f'[imdb_list] {url=}')

            result = client.request(url, headers={'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7'})
            # result = result.replace("\n", " ")
            # fflog(f'[imdb_list] {result=}')
            if not result:
                fflog(f'{result=}')
                return

            # check if list is private
            private_list = client.parseDOM(result, "h3", attrs={"class": "ipc-title__text"})
            if private_list and "rivate list" in private_list[0]:
                # fflog(f'[imdb_list] {re.sub("<[^>]+>", "", private_list[0])}')
                fflog(f'[imdb_list] {client.replaceHTMLCodes(private_list[0])}')
                private_list_description = client.parseDOM(result, "div", attrs={"class": "ipc-title__description"})
                if private_list_description:
                    fflog(f'[imdb_list] description: {private_list_description[0]}')
                control.infoDialog('Private list\n'+private_list_description[0], 'IMDb', "WARNING", 5000)
                control.sleep(5000)
                return

            jsdata = client.parseDOM(result, "script", attrs={"type": "application/json"})
            try:
                jsdata = json.loads(jsdata[0])
                # fflog(f'jsdata={json.dumps(jsdata, indent=4)}',1,1)
            except Exception:
                fflog_exc(1)
                jsdata = {}

            js_items = {}
            if jsdata:
                try:
                    js_items = jsdata['props']['pageProps']
                    # fflog(f'js_items={json.dumps(js_items, indent=4)}',1,1)
                except Exception:
                    fflog_exc(1)

                jsdata = None

                if js_items:
                    if "/list/" in url:
                        try:
                            js_items = js_items['mainColumnData']['list']['titleListItemSearch']['edges']  # pasuje do watchlist
                        except Exception:
                            fflog_exc(1)
                    elif "/user/" in url:
                        try:
                            js_items = js_items['mainColumnData']['predefinedList']['titleListItemSearch']['edges']  # pasuje do watchlist
                        except Exception:
                            fflog_exc(1)
                    else:
                        try:
                            js_items = js_items['searchResults']['titleResults']['titleListItems']  # pasuje do Oskarów
                        except Exception:
                            fflog_exc(1)

                    fflog(f'{len(js_items)=}', 1,1)

            items = []
            #items = client.parseDOM(result, "div", attrs={"class": "lister-item .+?"})
            # items = client.parseDOM(result, "ul", attrs={"class": "ipc-metadata-list .+?"})
            # fflog(f'[imdb_list] {items=}')
            #items += client.parseDOM(result, "div", attrs={"class": "list_item.+?"})
            items += client.parseDOM(result, "li", attrs={"class": "ipc-metadata-list-summary-item"})  # każdy tytuł z osobna
            fflog(f'[imdb_list] {len(items)=}')

            if len(js_items) >= len(items):
                items = js_items

            next_page = ""
            """
            try:  # tylko, że teraz paginacja jest poprzez dynamiczne doczytywanie, więc to już nie działa Trzeba by podejrzeć, co przeglądarka wysyła i z tym kombinować.
                next_page = client.parseDOM(result, "a", ret="href", attrs={"class": ".+?ister-page-nex.+?"})
                if len(next_page) == 0:
                    next_page = client.parseDOM(result, "div", attrs={"class": "pagination"})[0]
                    next_page = zip(client.parseDOM(next_page, "a", ret="href"), client.parseDOM(next_page, "a"))
                    next_page = [i[0] for i in next_page if "Next" in i[1]]
                next_page = url.replace(urllib.urlparse(url).query, urllib.urlparse(next_page[0]).query)
                next_page = client.replaceHTMLCodes(next_page)
            # next_page = next_page.encode("utf-8")
            except Exception:
                # fflog_exc(1)
                fflog(f'[imdb_list] brak paginacji')
                next_page = ""
            """
            
            result = None

            fflog(f'[imdb_list] zatem {len(items)=}')
            for item in items:
                # fflog(f'[imdb_list] {item=}')
                try:
                    if items is js_items:
                        if "/user/" in url or "/list/" in url:
                            title = item['listItem']['titleText']['text']
                            originaltitle = item['listItem']['originalTitleText']['text']
                        else:
                            title = item['titleText']
                            originaltitle = item['originalTitleText']
                    else:
                        title = client.parseDOM(item, "a")[1]  # bo pierwszy link, to obrazek
                        # fflog(f'[imdb_list] {title=}')
                        title = client.parseDOM(title, "h3", attrs={"class": "ipc-title__text"})[0]
                        title = client.replaceHTMLCodes(title)
                        title = re.sub(r"^\d+\. ", "", title)
                        # title = title.encode("utf-8").decode()
                        originaltitle = title
                    # fflog(f'{title=}',1,1)

                    # to się przydaje dla watchlist, ale nie wiem, czy nie popsuje list nagród (Oskarów, Malin itd)
                    if items is js_items:
                        if "/user/" in url or "/list/" in url:
                            # content_type = item['listItem']['titleType']['id']  # "movie"
                            content_type = item['listItem']['titleType']['text']  # "Movie"
                        else:
                            # content_type = item['titleType']['id']  # "movie"
                            content_type = item['titleType']['text']  # ""
                    else:
                        content_type = client.parseDOM(item, "span", attrs={"class": ".+? dli-title-type-data"})
                        content_type = content_type[0] if content_type else ""
                        # fflog(f'[imdb_list] {content_type=}')
                    if content_type and content_type.lower() != "movie":  # przy filmach nie powinno tego być (gdy scrapujemy)
                        # fflog(f'to nie jest film {title=}  {content_type=}', 1, 1)
                        continue

                    if items is js_items:
                        if "/user/" in url or "/list/" in url:
                            year = item['listItem']['releaseYear']['year']
                        else:
                            year = item['releaseYear']
                        year = str(year)
                    else:
                        #year = client.parseDOM(item, "span", attrs={"class": "lister-item-year.+?"})
                        year = client.parseDOM(item, "span", attrs={"class": ".+? dli-title-metadata-item"})
                        #year += client.parseDOM(item, "span", attrs={"class": "year_type"})  # chyba już nie ma czegoś takiego (nawet nie wiem, co to było)
                        # fflog(f'[imdb_list] {year=}')
                        try:
                            if type(year) == list:
                                year = year[0]
                            year = re.compile(r"(\d{4})").findall(year)[0]
                        except:
                            year = "0"
                        # year = year.encode("utf-8")
                    # fflog(f'[imdb_list] {year=} | {self.datetime.strftime("%Y")=}')
                    if int(year) > int(self.datetime.strftime("%Y")):  # to coś pomija, ale dlaczego?
                        fflog(f' {int(year)=}  >  {int(self.datetime.strftime("%Y"))=} | {title=}')
                        #raise Exception()
                        # continue
                        pass

                    if items is js_items:
                        if "/user/" in url or "/list/" in url:
                            imdb = item['listItem']['id']
                        else:
                            imdb = item['titleId']
                    else:
                        imdb = client.parseDOM(item, "a", ret="href")[0]
                        imdb = re.findall(r"(tt\d*)", imdb)[0]
                        # imdb = imdb.encode("utf-8")

                    genre = duration = rating = votes = mpaa = director = cast = plot = poster = "0"

                    r""" reszta niepotrzebna bo i tak zostanie pobrana z super_info (chyba, że nie będzie tego w bazie tmdb, to wówczas warto)
                    try:
                        poster = client.parseDOM(item, "img", ret="src")[0]
                    except:
                        poster = "0"
                    if "/nopicture/" in poster:
                        poster = "0"
                    poster = re.sub(r"(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.", "_SX500.", poster)
                    poster = client.replaceHTMLCodes(poster)
                    # poster = poster.encode("utf-8")

                    try:
                        genre = client.parseDOM(item, "span", attrs={"class": "genre"})[0]
                    except:
                        genre = "0"
                    genre = " / ".join([i.strip() for i in genre.split(",")])
                    if genre == "":
                        genre = "0"
                    genre = client.replaceHTMLCodes(genre)
                    # genre = genre.encode("utf-8")

                    try:
                        duration = re.findall(r"(\d+?) min(?:s|)", item)[-1]
                    except:
                        duration = "0"
                    # duration = duration.encode("utf-8")

                    rating = "0"
                    try:
                        rating = client.parseDOM(item, "span", attrs={"class": "rating-rating"})[0]
                    except:
                        pass
                    try:
                        rating = client.parseDOM(rating, "span", attrs={"class": "value"})[0]
                    except:
                        rating = "0"
                    try:
                        rating = client.parseDOM(item, "div", ret="data-value", attrs={"class": ".*?imdb-rating"})[0]
                    except:
                        pass
                    if rating == "" or rating == "-":
                        rating = "0"
                    rating = client.replaceHTMLCodes(rating)
                    # rating = rating.encode("utf-8")

                    try:
                        votes = client.parseDOM(item, "div", ret="title", attrs={"class": ".*?rating-list"})[0]
                    except:
                        votes = "0"
                    try:
                        votes = re.findall(r"\((.+?) vote(?:s|)\)", votes)[0]
                    except:
                        votes = "0"
                    if votes == "":
                        votes = "0"
                    votes = client.replaceHTMLCodes(votes)
                    # votes = votes.encode("utf-8")

                    try:
                        mpaa = client.parseDOM(item, "span", attrs={"class": "certificate"})[0]
                    except:
                        mpaa = "0"
                    if mpaa == "" or mpaa == "NOT_RATED":
                        mpaa = "0"
                    mpaa = mpaa.replace("_", "-")
                    mpaa = client.replaceHTMLCodes(mpaa)
                    # mpaa = mpaa.encode("utf-8")

                    try:
                        director = re.findall(r"Director(?:s|):(.+?)(?:\||</div>)", item)[0]
                    except:
                        director = "0"
                    director = client.parseDOM(director, "a")
                    director = " / ".join(director)
                    if director == "":
                        director = "0"
                    director = client.replaceHTMLCodes(director)
                    # director = director.encode("utf-8")

                    try:
                        cast = re.findall(r"Stars(?:s|):(.+?)(?:\||</div>)", item)[0]
                    except:
                        cast = "0"
                    cast = client.replaceHTMLCodes(cast)
                    # cast = cast.encode("utf-8")
                    cast = client.parseDOM(cast, "a")
                    if not cast:
                        cast = "0"

                    plot = "0"
                    try:
                        plot = client.parseDOM(item, "p", attrs={"class": "text-muted"})[0]
                    except:
                        pass
                    try:
                        plot = client.parseDOM(item, "div", attrs={"class": "item_description"})[0]
                    except:
                        pass
                    plot = plot.rsplit("<span>", 1)[0].strip()
                    plot = re.sub("<.+?>|</.+?>", "", plot)
                    if plot == "":
                        plot = "0"
                    plot = client.replaceHTMLCodes(plot)
                    # plot = plot.encode("utf-8")
                    """

                    #media_list.append(
                    media_item = (
                        {
                        "title": title,  # tytuły mogą być angielskie
                        "originaltitle": originaltitle,
                        "year": year,
                        "genre": genre,
                        "duration": duration,
                        "rating": rating,
                        "votes": votes,
                        "mpaa": mpaa,
                        "director": director,
                        "cast": cast,
                        "plot": plot,
                        "tagline": "0",
                        "imdb": imdb,
                        "tmdb": "0", "tvdb": "0",  # to chyba oznacza, że pobrano z imdb, a nie z innych (taka identyfikacja)
                        "poster": poster,
                        "next": next_page,
                        }
                    )
                    # fflog(f'[imdb_list] {media_item=}')
                    # fflog( "[imdb_list] " + "media_item=\n" + ("\n"+chr(32)).join(map(repr, media_item.items())) )
                    media_list.append(media_item)

                except Exception as e:
                    print(e)
                    fflog_exc(1)
                    pass

            # fflog(f'[imdb_list] {media_list=}')
            media_list = self.worker(media_list)  # uzupełnienie danych z super_info
            return media_list


        ### MOJE FILMY - LISTY FILMÓW ###
        ## Listy Użytkownika (TRAKT + IMDB + TMDB)
        def userlists(self, refresh=None):
            fflog(f'{params=}', 1, 1)

            userlists = []

            try:
                # fflog(f'{trakt.getTraktCredentialsInfo()=}')
                if not trakt.getTraktCredentialsInfo():
                    raise Exception()
                    # activity = trakt.getActivity()
                    # fflog(f'{activity=}')
            except Exception:
                # fflog_exc(1)
                pass

            try:
                self.list = []
                if self.tmdb_sessionid == "":
                    raise Exception()
                cache_timeout = 0 if refresh else 0.1  # 6 minut
                userlists += cache.get(self.tmdblist, cache_timeout, self.tmdb_user_lists)
            except Exception:
                # fflog_exc(1)
                pass

            try:
                self.list = []
                if self.imdb_user == "":
                    raise Exception()
                cache_timeout = 0 if refresh else 0.5  # 30 minut
                userlists += cache.get(self.imdb_user_list, cache_timeout, self.imdblists_link)
            except Exception:
                # fflog_exc(1)
                pass

            try:
                self.list = []
                if not trakt.getTraktCredentialsInfo():
                    raise Exception()
                try:
                    # fflog(f'{self.traktlists_link=} {self.trakt_user=}',1,1)
                    cache_timeout = cache.timeout(self.trakt_user_list, self.traktlists_link, self.trakt_user)
                    # fflog(f'{cache_timeout=} {trakt.getActivity()=}',1,1)
                    if not cache_timeout:
                        lists = cache.get(self.trakt_user_list, 24, self.traktlists_link, self.trakt_user)
                        #fflog(f'1 {lists=}')
                        lists = sorted(lists, key=lambda k: utils.title_key(k["name"]))
                        userlists += lists
                    else:
                        if trakt.getActivity() > cache.timeout(self.trakt_user_list, self.traktlists_link, self.trakt_user):
                            raise Exception()
                        else:
                            lists = cache.get(self.trakt_user_list, 24, self.traktlists_link, self.trakt_user)
                            #fflog(f'2 {lists=}')
                            lists = sorted(lists, key=lambda k: utils.title_key(k["name"]))
                            userlists += lists
                except Exception:
                    lists = cache.get(self.trakt_user_list, 0, self.traktlists_link, self.trakt_user)
                    # fflog(f'3 {lists=}')
                    lists = sorted(lists, key=lambda k: utils.title_key(k["name"]))
                    userlists += lists
            except Exception:
                # fflog_exc(1)
                pass

            try:
                self.list = []
                if not trakt.getTraktCredentialsInfo():
                    raise Exception()
                try:  # polubione
                    # fflog(f'{self.traktlikedlists_link=} {self.trakt_user=}',1,1)
                    cache_timeout = cache.timeout(self.trakt_user_list, self.traktlikedlists_link, self.trakt_user)
                    # fflog(f'{cache_timeout=} {trakt.getActivity()=}',1,1)
                    if not cache_timeout:
                        lists = cache.get(self.trakt_user_list, 24, self.traktlikedlists_link, self.trakt_user)
                        lists = sorted(lists, key=lambda k: utils.title_key(k["name"]))
                        userlists += lists
                    else:
                        if trakt.getActivity() > cache.timeout(self.trakt_user_list, self.traktlikedlists_link, self.trakt_user):
                            raise Exception()
                        else:
                            lists = cache.get(self.trakt_user_list, 24, self.traktlikedlists_link, self.trakt_user)
                            lists = sorted(lists, key=lambda k: utils.title_key(k["name"]))
                            userlists += lists
                except Exception:
                    lists = cache.get(self.trakt_user_list, 0, self.traktlikedlists_link, self.trakt_user)
                    lists = sorted(lists, key=lambda k: utils.title_key(k["name"]))
                    userlists += lists
            except Exception:
                #fflog_exc(1)
                pass

            generate_short_path = control.setting("generate_short_path") == "true"
            self.list = userlists
            for i in range(0, len(self.list)):
                self.list[i].update({"action": "movies" + (f"&item={str(i+1)}" if generate_short_path else "")})
            # self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))  # to "psuje" tutaj
            # fflog(f'{self.list=}')
            # fflog(f'{len(self.list)=} self.list={json.dumps(self.list, indent=2)}')
            self.addDirectory(self.list, queue=True, add_refresh=True)
            return self.list


        ### TRAKT ###
        def trakt_user_list(self, link, user, items=None):
            # fflog(f'{link=}  {user=}',1,1)
            if not items:
                try:
                    items = trakt.getTraktAsJson(link)
                except Exception:
                    fflog_exc(1)
                    pass
            # fflog(f'{items=}',1,1)
            # fflog(f'{len(items)=}',1,1)
            # fflog(f'items={json.dumps(items, indent=2)}',1,1)

            Burdel_frazy = ("dupa",)
            # pattern = "|".join( Burdel_frazy )
            pattern = "|".join( re.escape(bf) for bf in Burdel_frazy )
            pattern_re = re.compile(pattern, re.I)

            for item in items:
                # fflog(f'item={json.dumps(item, indent=2)}',1,1)
                try:
                    try:
                        item_count = item["list"]["item_count"]
                    except:
                        # item_count = ""
                        item_count = item["item_count"]

                    try:
                        name = item["list"]["name"]
                    except:
                        name = item["name"]

                    if 0:
                        if bf := pattern_re.search(name):
                            # fflog(f'odrzucone z powodu niechcianej frazy  {bf[0]=}',1,1)
                            continue
                            pass

                    if item_count:  # and item_count != 0:
                        name += f'  [LIGHT]({item_count}*)[/LIGHT]'
                        pass
                    else:
                        continue
                        pass

                    try:
                        name += f'  [LIGHT][I][{item["list"]["user"]["username"]}][/I][/LIGHT]'
                    except:
                        try:
                            name += f'  [LIGHT][I][{item["list"]["username"]}][/I][/LIGHT]'
                        except:
                            # fflog_exc(1)
                            # fflog(f'item={json.dumps(item, indent=2)}',1,1)
                            pass

                    name = client.replaceHTMLCodes(name)

                    try:
                        description = item["list"]["description"]
                    except:
                        try:
                            description = item["description"]
                        except Exception:
                            fflog_exc(1)
                            description = ""
                    if description:
                        description = client.replaceHTMLCodes(description)  # nie wiem, czy to potrzebne

                    if 0:
                        try:
                            share_link = item["list"]["share_link"]
                        except:
                            share_link = item["share_link"]
                        try:
                            share_link_api = share_link.replace('//trakt', '//api.trakt') + "/items"
                            pass
                        except:
                            share_link = ""
                            pass
                    else:
                        share_link = ""

                    try:
                        # url = (trakt.slug(item["list"]["user"]["username"]), item["list"]["ids"]["slug"],)
                        url = (item["list"]["user"]["ids"]["slug"], item["list"]["ids"]["slug"],)
                    except:
                        try:
                            url = ("me", item["ids"]["slug"])
                        except:
                            # fflog_exc(1)
                            url = ("None", item["list"]["ids"]["trakt"])
                            pass
                            # fflog(f'item={json.dumps(item, indent=2)}',1,1)
                            # share_link = item["list"]["share_link"]                     

                    try:
                        url = self.traktlist_link % url
                        url = url.replace("/users/None/", "/")
                        # fflog(f'\n       {url=} \n{share_link=}',1,1)
                        # url = url.encode("utf-8")
                    except:
                        fflog_exc(1)
                        # fflog(f'\n{self.traktlist_link=} \n         {share_link=}',1,1)
                        pass
                        continue
                        # fflog_exc(1)
                        # fflog(f'item={json.dumps(item, indent=2)}',1,1)
                    # fflog(f'{url=}')

                    try:
                        likes = item["list"]["likes"]
                    except:
                        # fflog(f'items={json.dumps(items, indent=2)}',1,1)
                        likes = item.get("likes") or 0
                        # likes = item["like_count"]

                    sort_by  = item.get("list", {}).get("sort_by")  or item.get("sort_by")  or ""
                    sort_how = item.get("list", {}).get("sort_how") or item.get("sort_how") or ""

                    # fflog(f'{url=}',1,1)
                    if sort_by:
                        q_or_a = "?" if "?" not in url else "&"
                        url += f"{q_or_a}sort_by={sort_by}"
                    if sort_how:
                        q_or_a = "?" if "?" not in url else "&"
                        url += f"{q_or_a}sort_how={sort_how}"
                    # fflog(f'{url=}',1,1)

                    self.list.append({
                        "name": name,
                        # "url": share_link or url,  # nie działa, bo musi być api.trakt, a to daje https://trakt.tv/lists .... (trzeba by dopisać "api." i na końcu "/items"
                        "url": url,
                        "context": url,
                        "image": "trakt.png",
                        "likes": likes,
                        "plot": description,
                        "plotoutline": f"Polubień: {likes}" if likes else "",
                        # "tagline": "link: "+share_link,  # może tu dać datę ostatniej aktualizacji? Tylko skórki nie wiem, czy to w ogóle wyświetlą, jak nie będzie typu contentu okreśłonego
                        "sort_by": sort_by,
                        "sort_how": sort_how,
                    })
                except Exception:
                    fflog_exc(1)
                    # fflog(f'{item=}',1,1)
                    # fflog(f'item={json.dumps(item, indent=2)}',1,1)
                    pass

            # self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))  # bo nie zawsze tak potrzeba
            fflog(f'{len(self.list)=}',1,1)
            return self.list


        ## TMDB ##
        def tmdblist(self, url):
            # fflog(f'{url=}', 1, 1)
            # url = self.tmdb_user_lists
            url = re.sub("(?<=api_key=)[^&]*", self.tm_user, url)
            url = re.sub("(?<=session_id=)[^&]*", self.tmdb_sessionid, url)
            # tmdb_results = requests.get(url).json()
            tmdb_results = self.doRequest(url).json()

            # page = tmdb_results.get("page", 0)
            # total = tmdb_results.get("total_pages", 0)
            r"""
            if page < total and "page=" in url:
                next_page = re.sub(r"page=\d+", f"page={page + 1}", url)
            else:
                next_page = ""
            """
            # next_page = re.sub("(?<=api_key=)[^&]*", "", next_page)
            # next_page = re.sub("(?<=session_id=)[^&]*", "", next_page)
            # fflog(f'{next_page=}')

            if "results" in tmdb_results:
                items = tmdb_results["results"]
            elif "items" in tmdb_results:
                items = tmdb_results["items"]
            elif "parts" in tmdb_results:
                items = tmdb_results["parts"]
            elif "cast" in tmdb_results and (items := tmdb_results["cast"]):
                # items = tmdb_results["cast"]
                pass
            elif "crew" in tmdb_results and (items := tmdb_results["crew"]):
                # items = tmdb_results["crew"]
                pass
            else:
                items = []
                fflog(f'jakiś błąd  {tmdb_results=}',1,1)

            for item in items:
                # if item.get('original_language') != 'ru':
                if item.get('list_type') != 'movie':  # tylko, że zawsze jest "movie" (głupie TMDB)
                    # continue
                    pass
                self.list.append({
                    "name": item.get("name"),
                    "id": str(item.get("id")),
                    "url": self.tmdb_lists_link % str(item.get("id")),
                    "context": self.tmdb_lists_link % str(item.get("id")),  # potrzebne do moviesToLibrary
                    "image": "tmdb.png",
                    # "next": next_page,
                    })

            fflog(f'{len(self.list)=}',1,1)
            # self.addDirectory(self.list)
            if self.list:
                self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))
            return self.list


        ### IMDB ###
        def imdb_user_list(self, url):  # to nie jest watchlista - to są listy użytkownika
            # fflog(f'[imdb_user_list] {url=}')
            try:
                result = client.request(url)
                # fflog(f'[imdb_user_list] {result=}')
                items = client.parseDOM(result, "li", attrs={"class": "ipc-metadata-list-summary-item"})
            except Exception:
                fflog_exc(1)
                items = []
                pass
            # fflog(f'[imdb_user_list] {len(items)=}')
            for item in items:
                # fflog(f'[imdb_user_list] {item=}')
                try:
                    name = client.parseDOM(item, "a", attrs={"class": "ipc-metadata-list-summary-item__t"})[0]
                    # fflog(f'[imdb_user_list] {name=}')
                    name = client.replaceHTMLCodes(name)
                    # name = name.encode("utf-8")
                    # fflog(f'[imdb_user_list] {name=}')

                    url = client.parseDOM(item, "a", ret="href", attrs={"class": "ipc-metadata-list-summary-item__t"})[0]  # choć tu class nie jest potrzebne
                    # fflog(f'[imdb_user_list] {url=}')
                    url = url.split("/list/", 1)[-1].strip("/")
                    # fflog(f'[imdb_user_list] {url=}')
                    url = self.imdblist1_link % url
                    # fflog(f'[imdb_user_list] {url=}')
                    url = client.replaceHTMLCodes(url)
                    # fflog(f'[imdb_user_list] {url=}')
                    # url = url.encode("utf-8")

                    self.list.append({"name": name, "url": url, "context": url, "image": "imdb.png", })
                except Exception:
                    fflog_exc(1)
                    pass
            # fflog(f'[imdb_user_list] {len(self.list)=}')
            self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))
            return self.list


        ### GET ###
        def get(self, url, idx=True, create_directory=True, refresh=None, category="", sort_how=""):
            """ tworzy różne katalogi (wirtualne) Kodi """
            # Uwaga: refresh nie jest jeszcze wszędzie zaaplikowany (a może nie wszędzie trzeba?)
            # debug
            if not "http" in url: 
                fflog(f'{params=}', fn=True)
                pass
            else:
                if not _is_debugging():
                    fflog(f'params={({**params, "url": "*"})}', 1,1)
                    # fflog(f'params={({**params, "url": url})}', 1,1)
                    pass
                else:
                    fflog(f'params={({**params, "url": url})}', 0)

            self.idx = idx

            # sys.path.append("D:\PyCharm 2022.1.4\debug-eggs\pydevd-pycharm.egg")
            # import pydevd_pycharm
            # pydevd_pycharm.settrace('localhost', port=5678, stdoutToServer=True, stderrToServer=True)

            try:
                thread = None
                # if re.search("api_key=(&|$)", url):
                url = re.sub("(?<=api_key=)[^&]*", self.tm_user, url)
                url = re.sub("(?<=session_id=)[^&]*", self.tmdb_sessionid, url)

                # convert "meta" URL (like `tmdb_trending`) to full URL (like link form `self.tmdb_trending_link`)
                url = getattr(self, url + "_link", url)
                u = urllib.urlparse(url).netloc.lower()
                # fflog(f'{u=}',1,1)
                # control.log(f'{url=}', 1)

                if u in self.trakt_link and "/users/" in url:
                    # fflog(f'wariant 1',1,1)
                    try:
                        if url == self.trakthistory_link:
                            raise Exception()
                        # if not "/users/me/" in url:
                        #     raise Exception()
                        if not self.idx:
                            fflog(f'wariant 1a',1,1)
                            self.list = cache.get(self.trakt_list, 0, url, self.trakt_user, sort_how)
                        else:
                            fflog(f'wariant 1b  {url=}',1,1)
                            cache_timeout_date = cache.timeout(self.trakt_list, url, self.trakt_user, sort_how)  # to jest kolumna daty (chyba w formacie timestamp)
                            # fflog(f'{cache_timeout_date=}',1,1)  # (np. 1754436095)
                            # cache_timeout = 0 if refresh else cache_timeout  # nie wiem, czy to jest w ogóle potrzebne, bo tu jest to jakoś inaczej rozwiązane niż w serialach
                            cache_timeout = 0 if refresh else 1
                            if not cache_timeout or "TRAKTNEXT" in url or "page=" in url:
                                fflog(f'wariant 1c',1,1)
                                self.list = cache.get(self.trakt_list, 0, url, self.trakt_user, sort_how)
                                if self.list and self.next_page and self.list[0].get("next"):
                                    fflog(f'dalej wariant 1c - next page',1,1)
                                    thread = Thread(target=cache.get, args=(self.trakt_list, 0, self.list[0].get("next"), self.trakt_user, sort_how))
                                    # thread.start()
                            else:
                                # fflog(f'{trakt.getActivity()=}',1,1)  # jaki to format ?
                                # fflog(f'  {trakt.getActivity()=}  \n{cache.timeout(self.trakt_list, url, self.trakt_user, sort_how)=}',1,1)
                                if trakt.getActivity() > cache_timeout_date:
                                    raise Exception()
                                else:
                                    fflog(f'wariant 1d',1,1)
                                    self.list = cache.get(self.trakt_list, 24, url, self.trakt_user, sort_how)
                    except Exception:
                        # fflog_exc(0)
                        fflog(f'wariant 1e',1,1)
                        self.list = cache.get(self.trakt_list, 0, url, self.trakt_user, sort_how)
                        if self.list and self.next_page and self.list[0].get("next"):
                            fflog(f'dalej wariant 1e - next page',1,1)
                            thread = Thread(target=cache.get, args=(self.trakt_list, 0, self.list[0].get("next"), self.trakt_user, sort_how))
                            # thread.start()

                    if "/users/" in url and "/collection/" in url:
                        fflog(f'wariant 1f',1,1)
                        if self.list:
                            self.list = sorted(self.list, key=lambda k: utils.title_key(k["title"]))
                            pass

                    # if idx:  #     self.worker()

                elif u in self.tmdb_link:
                    # control.log(f'[get]  {url=}',1)
                    if not self.idx:
                        self.list = cache.get(self.tmdb_list, 0, url)
                    else:
                        cache_timeout = 0 if refresh else 12  # 12 godzin
                        if cache_timeout:
                            # if any(i in url for i in ["/watchlist/", "/favorite/", "/rated/"]):
                            if any(i in url for i in ["/account/", "/list/", "/guest_session/"]):
                                # cache_timeout = 0  # wyłączenie z cachowania
                                cache_timeout = 0 if refresh else 0.1  # 6 minut
                                pass
                        if "/watchlist/" in url or "/favorite/" in url:
                            self.list = cache.get(self.tmdb_list, cache_timeout, url)
                        else:
                            # self.list = cache.get(self.tmdb_list, 24, url)
                            self.list = cache.get(self.tmdb_list, cache_timeout, url)
                            if self.list and self.next_page and self.list[0].get("next"):
                                # thread = Thread(target=cache.get, args=(self.tmdb_list, 24, self.list[0].get("next")))
                                thread = Thread(target=cache.get, args=(self.tmdb_list, cache_timeout, self.list[0].get("next")))
                                # thread.start()
                    if self.list and ("/search/" in url or "/collection/" in url or "/now_p2laying" in url):
                        # fflog(f'tmdb przestał sortować wyszukiwania, którą są wg frazy',1,1)
                        # fflog(f'self.list={json.dumps(self.list, indent=2)}',1,1)  # dla sprawdzenia
                        moviessort = int(control.setting("movies.sort"))
                        # fflog(f'{moviessort=}')
                        reverse = True
                        if "/search/" in url:
                            moviessort = 0  # wymuszenie na popularność, bo to w tym przypadku jest praktyczniejsze
                            pass
                        if "/collection/" in url:
                            moviessort = 1  # wymuszenie na rok premiery
                            reverse = False  # rosnąco
                            pass

                        if moviessort:
                            if "/now_p2laying" in url:  # bo ze względu na cachowanie informacji przez super_info może być zapisana inna data
                                pass
                                # fflog(f'posortowanie wg premiery ({"malejąco" if reverse else "rosnąco"})',1,1)
                                # self.list = sorted(self.list, key=lambda k: k.get("release_date", ""), reverse=reverse)
                            else:
                                fflog(f'posortowanie wg roku ({"malejąco" if reverse else "rosnąco"})',1,1)
                                # self.list = sorted(self.list, key=lambda k: k.get("year", ""), reverse=reverse)
                                # self.list = sorted(self.list, key=lambda k: k.get("premiered", ""), reverse=reverse)  # a może lepiej wg premiery? tylko, czy ona zawsze jest?
                                self.list = sorted(self.list, key=lambda k: (k.get("year", ""), k.get("premiered", "")), reverse=reverse)  # miks powyższych
                                # self.list = sorted(self.list, key=lambda k: (k.get("year", k.get("premiered", "")[0:4]), k.get("premiered", "")), reverse=reverse)  # chyba jeszcze lepszy miks powyższych
                                pass
                        else:
                            fflog(f'posortowanie wg popularności (malejąco)',1,1)
                            self.list = sorted(self.list, key=lambda k: k.get("popularity", 0), reverse=True)
                    else:
                        fflog(f'nie będzie zastosowane sortowanie przez FanFilm',0,1)
                        pass

                elif u in self.trakt_link:
                    # fflog(f'inny trakt  {u=}  {url=}',1,1)
                    self.list = cache.get(self.trakt_list, 12, url, self.trakt_user, sort_how)  # if idx:  #     self.worker()
                    if self.list and self.next_page and self.list[0].get("next"):
                        # fflog(f'dalej inny trakt - next page',1,1)
                        thread = Thread(target=cache.get, args=(self.trakt_list, 12, self.list[0].get("next"), self.trakt_user, sort_how))
                        # thread.start()

                elif u in self.imdb_link and ("/user/" in url or "/list/" in url):  # a /watchlist/ ? - /user/ wystarczy
                    # fflog(f'imdb /user/ lub /list/  {u=}  {url=}')
                    # fflog(f'{self.idx=}')
                    if not self.idx or refresh:
                        self.list = cache.get(self.imdb_list, 0, url)
                    else:
                        self.list = cache.get(self.imdb_list, 1, url)  # if idx:  #     self.worker()
                        if self.list and self.next_page and self.list[0].get("next"):
                            # fflog(f'{self.list[0].get("next")=}')
                            thread = Thread(target=cache.get, args=(self.imdb_list, 1, self.list[0].get("next")))
                            # thread.start()

                elif u in self.imdb_link:
                    # fflog(f'imdb inny  {u=}  {url=}')
                    self.list = cache.get(self.imdb_list, 24, url)  # if idx:  #     self.worker()
                    #fflog(f'{self.list=}')
                    if self.list and self.next_page and self.list[0].get("next"):
                        # fflog(f'{self.list[0].get("next")=}')
                        thread = Thread(target=cache.get, args=(self.imdb_list, 24, self.list[0].get("next")))
                        # thread.start()

                if self.list:
                    # w serialach przydało się, ale w filmach to chyba nie ma takiej potrzeby
                    # self.list = [i for n, i in enumerate(self.list) if i not in self.list[:n]]  # eliminacja dubli
                    pass

                if idx is True and create_directory is True:
                    if self.list:
                        self.movieDirectory(self.list, category=category)
                        if thread:
                            thread.start()
                            pass
                    else:
                        if self.list is not None:  # czy może lepsze byłoby False
                            import xbmcgui
                            xbmcgui.Dialog().notification('Błąd', 'Nic nie znaleziono', xbmcgui.NOTIFICATION_ERROR)
                            fflog('nic nie znaleziono', 0)
                            fflog(f'{params=}', 0)
                            fflog(f'{url=}', 0)
                            # navigator.navigator().endDirectory()
                            # control.sleep0(100)
                            # control.execute('Action(Back)')

                return self.list
            except Exception as e:
                print(e)
                fflog_exc(1)
                return


        ### WORKER ###
        def worker(self, media_list=[], level=1, media_type="movie"):
            from threading import Thread, active_count
            from resources.lib.indexers.super_info import SuperInfo

            PluginName = control.infoLabel("Container.PluginName")
            fflog(f'{PluginName=}',1,1)
            if PluginName:  # == 'plugin.video.kadrplus'
                max_workers = 10
            else:
                # max_workers = 5
                max_workers = int(control.setting("threads.widget"))
            fflog(f'{max_workers=}',1,1)

            # self.meta = []
            if not media_list:
                media_list = self.list

            total = len(media_list) if media_list else 0

            # fflog(f'{len(media_list)=}',1,1)
            # fflog(f'{len(media_list)=}  {media_list=}',1,1)
            # for i in range(0, total):
            #     self.list[i].update({"metacache": False})
            #
            # self.list = metacache.fetch(self.list, self.lang, self.user)
            #
            # for i in range(total):
            #     self.list[i]["metacache"] = False
            #
            # self.list = metacache.fetch(self.list, self.lang, self.user)
            # log_utils.fflog(f"{len(media_list)=} {media_list=}")

            super_info_media_list = []  # do zwrócenia wyniku

            if 0:
                # monitor = control.monitor

                for r in range(0, total, 20):

                    threads = {super_info_obj: Thread(target=super_info_obj.get_info, args=(i,)) 
                                for i in range(r, min(total, r + 20))
                                for super_info_obj in (SuperInfo(media_list, self.session, self.lang, media_type),)
                              }
                    fflog(f'{len(threads)=}',1,1)

                    if 0:
                        [i.start() for i in threads.values()]
                    else:
                        for i in threads.values():
                            i.daemon = True  # pozwoli Kodi ubić te wątki przy wyjściu
                            i.start()
                            while active_count() > max_workers:  # nie więcej niż 10 wątków na raz
                                if monitor.abortRequested():
                                    fflog('sygnal zamknięcia Kodi',1,1)
                                    return []
                                control.sleep0(50)

                    [i.join()  for i in threads.values()]  # czekanie na skończenie wątków

                    for super_info_obj in threads:
                        if super_info_obj.meta:
                            super_info_media_list.append(super_info_obj.meta[0].get('item'))

            else:
                from concurrent.futures import ThreadPoolExecutor

                for r in range(0, total, 20):

                    super_info_objects = [
                        SuperInfo(media_list, self.session, self.lang, media_type)
                        for i in range(r, min(total, r + 20))
                    ]

                    with ThreadPoolExecutor(max_workers=max_workers) as executor:  # nie więcej niż 10 wątków na raz
                        # uruchamiamy zadania
                        futures = [
                            executor.submit(obj.get_info, i)
                            for obj, i in zip(super_info_objects, range(r, min(total, r + 20)))
                        ]

                        # czekamy na wykonanie
                        # for f in futures:
                            # f.result()

                    # zbieramy wyniki jak w starym kodzie
                    for obj in super_info_objects:
                        if obj.meta:
                            super_info_media_list.append(obj.meta[0].get('item'))

                # if self.meta:  #     metacache.insert(self.meta)
            # fflog(f'{len(super_info_media_list)=}  {super_info_media_list=}')
            return super_info_media_list


        def get_meta_for_movie(self, imdb=None, tmdb=None, media_type="movie"):
            try:
                meta = cache.cache_get("superinfo" + f"_{tmdb or imdb}")  # sprawdzenie, czy nie ma już w cache
                if not meta:
                    log_utils.fflog('próba pobrania informacji przez super_info.py')
                    from resources.lib.indexers.super_info import SuperInfo
                    media_list = [{'tmdb': tmdb, 'imdb': imdb}]
                    if not self.session:
                        import requests
                        session = requests.Session()
                    else:
                        session = self.session
                    lang = control.apiLanguage()["tmdb"]
                    super_info_obj = SuperInfo(media_list, session, lang, media_type)
                    super_info_obj.get_info(0)

                    meta = cache.cache_get("superinfo" + f"_{tmdb or imdb}")
                if meta:
                    from ast import literal_eval
                    meta = meta["value"]
                    meta = literal_eval(meta)
                else:
                    meta = {}
            except Exception:
                meta = {}
                fflog_exc(1)
            return meta


        ### MOVIE DIR ###
        def movieDirectory(self, items, cacheToDisc=False, multi=False, category=""):
            fflog('[movieDirectory]',1)
            # fflog(f'{cacheToDisc=}  {multi=}  {category=}',1,1)
            # fflog(f'items={json.dumps(items, indent=2)}',1,1)
            # sys.path.append("D:\PyCharm 2022.1.4\debug-eggs\pydevd-pycharm.egg")
            # import pydevd_pycharm
            # pydevd_pycharm.settrace('localhost', port=5678, stdoutToServer=True, stderrToServer=True)

            if items is None or len(items) == 0:
                # sys.exit()
                return

            sysaddon = sys.argv[0]
            syshandle = int(sys.argv[1])
            currentPath = dict(urllib.parse_qsl(sys.argv[2][1:]))

            if control.setting("zastepcze_grafiki") == "true":
                addonPoster =  control.addonPoster()
                addonFanart = control.addonFanart()
                addonBanner = control.addonBanner()
            else:
                addonPoster = addonFanart = addonBanner = ""

            settingFanart =  control.setting("fanart")

            meta = {}

            multi_select = []

            try:
                isOld = False
                control.item().getArt("type")
            except:
                isOld = True

            PluginName = control.infoLabel("Container.PluginName")
            # PluginName = PluginName == "plugin.video.kadrplus"  # nie wiem, czy to potrzebne
            # fflog(f'{PluginName=}',1,1)

            add_year = control.setting("titles.add_year") == "true"
            generate_short_path = control.setting("generate_short_path") == "true"
            # isFolder = False if control.setting("hosts.mode") == "0" else True
            isFolder = False if control.setting("hosts.mode") != "1" else True
            # fflog(f'{isFolder=}',1,1)
            #isPlayable = "true" if "plugin" not in control.infoLabel("Container.PluginName") else "false"  # dziwny ten warunek (ale chyba pozwalał omijać setResolvedUrl)
            isPlayable = "true" if not isFolder else "false"
            # fflog(f'{isPlayable=}',1,1)
            yatse = control.setting("yatse") == "true"
            yatse = False if not isFolder else yatse  # zastanowić się
            # yatse = False if PluginName == 'plugin.video.kadrplus' else yatse  # to nie za bardzo się sprawdza
            playbackMenu = control.lang(32063) if control.setting("hosts.mode") == "2" else control.lang(32064)
            dont_use_setResolvedUrl = control.setting("player.dont_use_setResolvedUrl") == "true"
            fflog(f'{dont_use_setResolvedUrl=}') if dont_use_setResolvedUrl else ''
            tmdbCredentials = False if control.setting("tmdb.sessionid") == "" else True
            traktCredentials = trakt.getTraktCredentialsInfo()
            traktIndicators  = trakt.getTraktIndicatorsInfo()
            watchedMenu =   control.lang(32068) if traktIndicators is True else control.lang(32066)
            unwatchedMenu = control.lang(32069) if traktIndicators is True else control.lang(32067)
            indicator_kodi = control.setting("indicator.kodi") == "true"
            # fflog(f'{traktCredentials=}  {traktIndicators=}  {indicator_kodi=}')
            fflog(f'{action=}',1,1)
            indicators = playcount.getMovieIndicators(refresh=True) if action == "movies" or action == "lastWatched" else playcount.getMovieIndicators()
            # indicators = playcount.getMovieIndicators(refresh=True)
            # fflog(f'{indicators=}',1,1)
            queueMenu = control.lang(32065)  # Dodaj do kolejki (FF)
            traktManagerMenu = control.lang(32070)
            tmdbManagerMenu = "Menadżer TMDB"
            nextMenu = control.lang(32053)
            nextMenu = nextMenu + "  >>"
            addToLibrary = control.lang(32551)
            addMultiToLibrary = control.lang(32635)
            kodiver = source_utils.get_kodi_version()
            # fflog(f'{kodiver.version=}')
            # fflog(f'{kodiver.major=} {kodiver.minor=}')

            # add_rating_for_tmdb = control.setting("add_rating_for_tmdb.movies") == "true" and control.setting("add_rating_for_tmdb") == "true"
            add_rating_for_tmdb = True

            moviessort = int(control.setting("movies.sort"))
            # fflog(f'{moviessort=}')

            # TODO: add options, example: label2Mask="[%D]|[%Y]"
            addSortMethod(syshandle, sortMethod=SORT_METHOD_UNSORTED, labelMask="%L")  # pokazuje napis "Domyślny", ale nie sortuje
            addSortMethod(syshandle, sortMethod=SORT_METHOD_PLAYLIST_ORDER, labelMask="%L")  # wykorzystuje countera
            addSortMethod(syshandle, sortMethod=SORT_METHOD_VIDEO_YEAR, labelMask="%L")
            addSortMethod(syshandle, sortMethod=SORT_METHOD_TITLE, labelMask="%L")
            addSortMethod(syshandle, sortMethod=SORT_METHOD_DURATION, labelMask="%L")
            addSortMethod(syshandle, sortMethod=SORT_METHOD_VIDEO_RATING, labelMask="%L")

            downloads = (
                control.setting("downloads") == "true"
                and not (
                    control.setting("movie.download.path") == ""
                    or control.setting("tv.download.path") == ""
                )
            )
            downloadMenu = control.lang(32403)

            cm_enable_autoplay = control.setting("cm.enable.autoplay") == "true"
            cm_enable_similar_trakt = control.setting("cm.enable.similar_trakt") == "true"
            cm_enabl_similar_tmdb = control.setting("cm.enable.similar_tmdb") == "true"
            cm_enable_recommendations_tmdb = control.setting("cm.enable.recommendations_tmdb") == "true"
            cm_enable_removeFromBookmarks = control.setting("cm.enable.removeFromBookmarks") == "true"
            cm_enable_addToLibrary = control.setting("cm.enable.addToLibrary") == "true"
            cm_enable_addMultiToLibrary = control.setting("cm.enable.addMultiToLibrary") == "true"
            cm_enable_editForSearch = control.setting("cm.enable.editForSearch") == "true"
            cm_enable_queueMenu = control.setting("cm.enable.queueMenu") == "true"  # to chyba Kodi dodaje od wersji 21.2
            cm_enable_watchedUnwatched = control.setting("cm.enable.watchedUnwatched") == "true"
            cm_enable_cacheRefresh = control.setting("cm.enable.cacheRefresh") == "true"
            cm_enable_exitFromList = control.setting("cm.enable.exitFromList") == "true"
            cacheIsEnabled = control.setting("enableSourceCache") == "true"
            # eksperyment
            cm_enable_katalog_gdy_autoodtwarzanie = control.setting("cm.enable.katalog_gdy_autoodtwarzanie") == "true"

            show_unpremiered_movies = control.setting("show_unpremiered_movies") == "true"

            unpremiered_color = control.setting("unpremiered_color")
            if unpremiered_color == "inny":
                unpremiered_color = control.setting("unpremiered_custom_color")
            else:
                colors_map = {
                    "szary": "gray",
                    "czerwony": "red",
                    "fioletowy": "magenta",
                    "pomarańczowy": "orange",
                    }
                unpremiered_color = colors_map[unpremiered_color]
            # fflog(f'{unpremiered_color=}')

            # self.today_date = self.datetime.strftime("%Y-%m-%d")  # bo przy wyborze "Ukryj filmy w kinie" data dzisiejsza jest cofana (ale może to jednak dobrze)

            hide_anime = control.setting("hide_anime") == "true"

            trailer_plugin = control.setting("trailer.plugin")

            # jakoś może to da się wykryć, że to od multi ?
            tvshows_class = None
            # if multi:
                # from resources.lib.indexers import tvshows
                # tvshows_class = tvshows.tvshows()
            tvshow_indicators = None

            back_to = params.get("back_to", "")
            if not back_to:
                # back_to = sys.argv[2][1:]
                folderpath  = control.infoLabel('Container.FolderPath')
                back_to = folderpath.split('?')[-1]
            fflog(f'{back_to=}',1,1)

            list_of_items = []

            counter = 1

            fflog(f'{len(items)=}',1,1)
            for i in items:

                # fflog(f'i={json.dumps(i, indent=2)}',1,1)

                if hide_anime and "anime" in i.get("keywords"):
                    # fflog(f'pomijam, bo to anime {i=}')
                    continue

                if (media_type := i.get("media_type")) and media_type != "movie" or i.get("episodes"):
                    # fflog(f'{media_type=}',1,1)
                    if not tvshows_class:
                        multi = True
                        from resources.lib.indexers import tvshows
                        tvshows_class = tvshows.tvshows()
                    tvshow_indicators, list_of_items = tvshows_class.tvshowDirectory([i], directory=False, multi=multi, indicators=tvshow_indicators, counter=counter, list_of_items=list_of_items)
                    counter += 1
                    continue

                def has(key):
                    val = i.get(key)
                    return val and val != "0"

                try:
                    label = "{} [LIGHT]({})[/LIGHT]".format(i.get("label") or i.get("title"), i["year"])  # to display
                    title = i.get("title")
                    label = title if title and not add_year else label.replace(" [LIGHT]()[/LIGHT]", "", 1)
                    if not label:
                        continue
                    # syslabel = quote_plus(label)

                    title, year = i["originaltitle"], i["year"]

                    imdb, tmdb = i["imdb"], i["tmdb"]

                    # prepare to context menu url
                    sysname = urllib.quote_plus("{} ({})".format(title, year))
                    systitle = urllib.quote_plus(title)
                    syslocaltitle = urllib.quote_plus(i.get("title"))

                    meta = {k: v for k, v in i.items() if not v == "0"}  # budowanie mety

                    meta.pop("next", None)  # to chyba niepotrzebne tu, więc out

                    meta.update({"imdbnumber": imdb})
                    # meta.update({"code": tmdb})  # "code" to coś innego oznacza 
                    # meta.update({"code": imdb, "imdbnumber": imdb, "imdb_id": imdb})
                    # meta.update({"tmdb_id": tmdb})

                    meta.update({"mediatype": "movie"})
                    if isFolder:
                        # meta.update({"mediatype": "tvshow"})  # dla ustawionego katalogu, aby pokazywał "Przeglądaj" zamiast "Odtwarzaj" po naciśnięciu I (informacje), tylko że wtedy skórka może pokazywać inne pola
                        pass

                    # fflog(f'{meta.get("trailer")=}  |  {title=}',1,1)
                    trailer = meta.get("trailer")
                    if trailer_plugin == "0":
                        meta.update({"trailer": "%s?action=trailer&name=%s&url=%s" % (sysaddon, urllib.quote_plus(label), urllib.quote_plus(trailer or ""))})
                    else:
                        # meta.update({'trailer': 'plugin://script.extendedinfo/?info=playtrailer&&id=%s' % imdb})  # zależne od pluginu extendedinfo
                        meta.update({"trailer": "%s?action=trailer&name=%s" % (sysaddon, urllib.quote_plus(label))})  # szukanie po nazwie
                        if trailer:
                            # trailer = trailer.replace("https://www.youtube.com/watch?v=", "plugin://plugin.video.youtube/play/?video_id=")
                            tid = trailer.split("?v=")[-1].split("/")[-1].split("?")[0].split("&")[0]
                            if tid:
                                trailer = "plugin://plugin.video.youtube/play/?video_id=%s" % tid
                                if trailer_plugin == "2":
                                    # trailer = trailer.replace('plugin://plugin.video.youtube/play/?video_id=', 'plugin://slyguy.trailers/play/?busy=0&video_id=')
                                    trailer = "plugin://slyguy.trailers/play/?busy=0&video_id=%s" % tid
                                meta.update({'trailer': trailer})
                    # fflog(f'{meta.get("trailer")=}  |  {title=}',1,1)

                    if "duration" not in i:
                        # meta.update({"duration": "120"})  # nie wiem, czy trzeba wstawiać wymyślone
                        # meta.update({"duration": "1"})  # jeśli coś trzeba wstawić, to może tylko 1 sekundę wystarczy ?
                        pass
                    elif i["duration"] == "0":
                        # meta.update({"duration": "120"})
                        # meta.update({"duration": "1"})
                        pass
                    try:
                        if meta.get("duration") and meta.get("duration") != "0":
                            meta.update({"duration": str(int(meta["duration"]) * 60)})  # docelowo ma być w sekundach
                    except:
                        pass

                    poster = [i[x] for x in ["poster3", "poster", "poster2"] if i.get(x, "0") != "0"]
                    poster = poster[0] if poster else addonPoster
                    # fflog(f'{poster=}',1,1)
                    meta["poster"] = poster

                    # eksperymenty
                    # 2-jki w śródku, to szybkie wyłączenie
                    icon = i.get("icon") or i.get("di2scart") or poster  # tylko nie wiem, czy preferowany jest kwadrat, czy prostokąt
                    thumb = i.get("thumb") or i.get("fa2nart") or i.get("lan2dscape") or poster  # j. w. (wg wiki to prostokąt https://kodi.wiki/view/Artwork_types )
                    # ponieważ grafiki dużo ważą, może jednak zostawić pusto ?
                    # icon = i.get("icon") or ""  # jak niżej (nie wiem, czy icon jeszcze jest używany)
                    # thumb = i.get("thumb") or ""  # jednak lepiej dać poster jak ma coś być, bo dla typu video to jest brane pod uwagę

                    # try:
                    #     meta.update({"genre": cleangenre.lang(meta["genre"], self.lang)})
                    # except:
                    #     pass

                    # fflog(f'{meta.get("genre")=}')
                    # fflog(f'{meta.get("country")=}')
                    # fflog(f'{meta.get("originalname")=}')
                    anime = False
                    if meta.get("country") in ["Japan", "China", "Korea"]:
                        if any(i in (meta.get("genre") or "") for i in ["Animacja", "Fantasy", "Anime"]):
                            if source_utils.czy_litery_krzaczki(meta.get("originalname", "")):
                                anime = True

                    premiered = meta.get("premiered", 0)
                    if not premiered or int(re.sub("[^0-9]", "", str(premiered))) > int(re.sub("[^0-9]", "", str(self.today_date))):
                        if show_unpremiered_movies:
                            label = f"[COLOR {unpremiered_color}][I]%s[/I][/COLOR]" % label
                        else:
                            fflog(f'ukrywam {title=}', 0)
                            continue

                    if not anime:
                        if meta.get("local_premieres"):
                            local_premiered = next(
                                    (i.get("release_date").split("T")[0]
                                    for i in meta.get("local_premieres")
                                    if i.get("type") >=3)  # 3 to kinowa
                                ,"")
                            meta["premiered"] = local_premiered or meta.get("premiered", "")

                    meta = convert(meta)

                    sysmeta = urllib.quote_plus(json.dumps(meta))

                    # url = "{}?action=play&title={}&localtitle={}&year={}&imdb={}&tmdb={}&meta={}&t={}".format(sysaddon, systitle, syslocaltitle, year or "", imdb, tmdb, sysmeta, self.systime, )
                    url = "{}?action=play&title={}&localtitle={}&year={}&imdb={}&tmdb={}&meta={}".format(sysaddon, systitle, syslocaltitle, year or "", imdb, tmdb, sysmeta, )
                    sysurl = urllib.quote_plus(url)  # potrzebne dla context menu
                    fullpath = ""
                    if generate_short_path and isFolder:  # zastanowić się nad isFolder
                        fullpath = url
                        url = "{}?action=play&item={}".format(sysaddon, counter)
                        #sysurl = urllib.quote_plus(url)  # czy trzeba ?  bo może bardziej zaszkodzi
                        pass

                    # path = "{}?action=play&title={}&year={}&imdb={}".format(sysaddon, systitle, year or "", imdb, )


                    item = control.item(label=label, offscreen=True)  # create ListItem


                    cm = []  # prepare context menu

                    # autoodtwarzanie, albo zatrzymanie autoodtwarzania
                    if cm_enable_autoplay:
                        if not isFolder and playbackMenu == control.lang(32063) and cm_enable_katalog_gdy_autoodtwarzanie:  # 0 to okienko, 1 to katalog
                            if 2:
                                ctxm = [
                                        ( "okno",    "PlayMedia(%s?action=alterSources&url=%s)" % (sysaddon, sysurl) ),
                                        ( "katalog", "Container.Update(%s?action=alterSources&url=%s)" % (sysaddon, sysurl+"%26select%3D1") if PluginName 
                                                else "ActivateWindow(10025,%s?action=alterSources&url=%s,return)" % (sysaddon, sysurl+"%26select%3D1") ),
                                       ]
                                cm.append((playbackMenu+":", "RunPlugin(%s?action=contextmenu&list=%s)" % (sysaddon, urllib.quote_plus(repr(ctxm)) ),))  # test wybory między oknem a katalogiem
                            else:
                                cm.append((playbackMenu+" (o)", "PlayMedia(%s?action=alterSources&url=%s)" % (sysaddon, sysurl),))  # okienko (dodatkowo dla testów)
                                if PluginName:
                                    cm.append((playbackMenu+" (k)", "Container.Update(%s?action=alterSources&url=%s)" % (sysaddon, sysurl+"%26select%3D1"),))  # katalog
                                else:
                                    cm.append((playbackMenu+" (k)", "ActivateWindow(10025,%s?action=alterSources&url=%s,return)" % (sysaddon, sysurl+"%26select%3D1"),))  # katalog
                        else:  # okienko
                            #cm.append((playbackMenu, "RunPlugin(%s?action=alterSources&url=%s&meta=%s)" % (sysaddon, sysurl, sysmeta),))  # w url jest już meta
                            # cm.append((playbackMenu, "RunPlugin(%s?action=alterSources&url=%s)" % (sysaddon, sysurl),))  # handle -1
                            cm.append((playbackMenu, "PlayMedia(%s?action=alterSources&url=%s)" % (sysaddon, sysurl),))

                    if cm_enable_editForSearch:
                        if not isFolder:
                            # cm.append(("EDYTUJ dane do wyszukiwarki", "RunPlugin(%s?action=alterSources&url=%s)" % (sysaddon, sysurl+"%26customTitles%3D1"),))  # handle -1
                            cm.append(("EDYTUJ dane do wyszukiwarki", "PlayMedia(%s?action=alterSources&url=%s)" % (sysaddon, sysurl+"%26customTitles%3D1"),))
                            # cm.append(("EDYTUJ dane do wyszukiwarki", "PlayMedia(%s)" % (url + "&customTitles=1"),))
                        else:
                            if not generate_short_path:
                                if PluginName:
                                    cm.append(("EDYTUJ dane do wyszukiwarki", "Container.Update(%s?action=alterSources&url=%s)" % (sysaddon, sysurl+"%26customTitles%3D1"),))  # nie działa, gdy z widgetu
                                else:
                                    cm.append(("EDYTUJ dane do Wyszukiwarki", "ActivateWindow(10025,%s?action=alterSources&url=%s,return)" % (sysaddon, sysurl+"%26customTitles%3D1%26noref%3D1"),))
                                # cm.append(("EDYTUJ dane do wyszukiwarki", "RunPlugin(%s?action=alterSources&url=%s)" % (sysaddon, sysurl+"%26customTitles%3D1%26noref%3D1"),))  # handle -1, zmienia na okienko
                            else:
                                cm.append(("EDYTUJ dane do wyszukiwarki", "Container.Update(%s)" % (url + "&customTitles=1"),))

                    if downloads and not isFolder:
                        cm.append((downloadMenu, "RunPlugin(%s)" % (url + "&download=1"),))
                        #cm.append((downloadMenu, "RunPlugin(%s?action=download&name=%s&image=%s&source=%s&extrainfo=%s)" % (sysaddon, sysname, sysimage, syssource, quote_plus(extrainfo)  ), ))

                    if cm_enable_addToLibrary:
                        cm.append((addToLibrary, "RunPlugin(%s?action=movieToLibrary&name=%s&title=%s&localtitle=%s&year=%s&imdb=%s&tmdb=%s)" % (
                                                                            sysaddon, sysname, systitle, syslocaltitle, year or "", imdb, tmdb),))
                    if cm_enable_addMultiToLibrary:
                        cm.append((addMultiToLibrary, f"RunPlugin({sysaddon}?action=moviesMultiToLibrary&select=multi_select)",))

                    if cm_enable_cacheRefresh and cacheIsEnabled:
                        if not isFolder:
                            cm.append(("Odśwież cache źródeł", "PlayMedia(%s)" % (url + "&refreshCache=1"),))
                        else:
                            if PluginName:
                                cm.append(("Odśwież cache źródeł", "Container.Update(%s)" % (url + "&refreshCache=1"),))
                            else:
                                cm.append(("Odśwież cache źródeł", "ActivateWindow(10025,%s,return)" % (url + "&refreshCache=1"),))

                    overlay = None
                    if isFolder or traktIndicators or not indicator_kodi:
                        try:
                            overlay = playcount.getMovieOverlay(indicators, imdb, tmdb)
                            overlay = int(overlay) if overlay else overlay
                            # fflog(f'{overlay=}  {imdb=}  {tmdb=}  {title=}  {label=}  {indicators=}')
                            if overlay == 7:
                                meta.update({"playcount": 1, "overlay": 7})  # to zmienia ptaszki
                                if not traktIndicators:
                                    if cm_enable_watchedUnwatched:
                                        cm.append((unwatchedMenu, "RunPlugin(%s?action=moviePlaycount&imdb=%s&tmdb=%s&query=6)" % (sysaddon, imdb, tmdb),))
                            else:
                                meta.update({"playcount": 0, "overlay": 6})  # to zmienia ptaszki
                                if not traktIndicators:
                                    if cm_enable_watchedUnwatched:
                                        cm.append((watchedMenu,   "RunPlugin(%s?action=moviePlaycount&imdb=%s&tmdb=%s&query=7)" % (sysaddon, imdb, tmdb),))
                        except Exception:
                            fflog_exc(1)
                            pass

                    vtag = item.getVideoInfoTag()  # od Kodi 20

                    percent = None
                    if overlay != 7:
                        # if True:
                        if isFolder or traktIndicators or not indicator_kodi:
                            try:
                                percent = 0
                                # if trakt.getTraktIndicatorsInfo() and trakt.getTraktCredentialsInfo() == True:
                                if traktIndicators is True:
                                    offsetSource = "trakt"
                                    percent = bookmarks.get_scrobble("movie", imdb, tmdb=tmdb)
                                    # fflog(f'{percent=}  trakt  {imdb=}  {tmdb=}  {label=}',1,1)
                                    runtime = offset = 0  # bo nie ma takiej informacji z powyższej funkcji
                                else:
                                    offset, runtime, offsetSource = bookmarks.get("movie", imdb, tmdb=tmdb)
                                    # fflog(f'{offset=}  {runtime=}  {offsetSource=}  {imdb=}  {tmdb=}  {label=}',1,1)
                                    runtime = runtime or int(meta.get("duration") or 0)
                                    # fflog(f'{offset=}  {runtime=}  {offsetSource=}  {imdb=}  {tmdb=}  {label=}',1,1)
                                    if runtime and offset > 1:
                                        percent = int((offset / runtime) * 100)
                                        # fflog(f'{percent=}  {offsetSource}  {imdb=}  {tmdb=}  {label=}',1,1)
                                    else:
                                        percent = None
                            except Exception:
                                fflog_exc(1)
                                percent = None
                                pass
                            # fflog(f'{percent=}  {offsetSource}  {imdb=}  {tmdb=}  {label=}',1,1)
                            if percent and percent < 85:
                                item.setProperty("WatchedProgress", str(percent) )  # a może jest lepszy sposób?
                                pass

                                totalTime = runtime or float(meta.get("duration") or 0)
                                time = offset or float(percent / 100) * totalTime
                                if totalTime and totalTime > 10:
                                    if kodiver.major < 20:
                                        try:
                                            item.setProperty("resumetime", str(time))
                                            item.setProperty("totaltime", str(totalTime))
                                            pass
                                        except Exception:
                                            # fflog_exc(1)
                                            pass
                                    else:
                                        try:
                                            # bo vtag i setResumePoint dopiero od Kodi v20
                                            vtag.setResumePoint(time, totalTime)
                                            pass
                                        except Exception:
                                            # fflog_exc(1)
                                            # fflog(f'{time=}, {totalTime=}',1,1)
                                            pass
                        else:
                            percent = None

                    overlay = "" if overlay is None else overlay
                    percent = "" if percent is None else percent  # a nie lepiej aby to się nazywało progress ?

                    if traktCredentials:
                        cm.append((traktManagerMenu, "RunPlugin(%s?action=traktManager&name=%s&imdb=%s&tmdb=%s&content=movie&overlay=%s)" % (sysaddon, sysname, imdb, tmdb, overlay),))

                    if tmdbCredentials:
                        if add_rating_for_tmdb:
                            cm.append((tmdbManagerMenu, "RunPlugin(%s?action=tmdbManager&tmdb=%s&content=movie&overlay=%s&progress=%s)" % (sysaddon, tmdb, overlay, percent),))
                        else:
                            cm.append((tmdbManagerMenu, "RunPlugin(%s?action=tmdbManager&tmdb=%s&content=movie)" % (sysaddon, tmdb),))

                    if cm_enable_removeFromBookmarks:
                        if currentPath.get("action") == "lastWatched":
                        # if True:  # zawsze (a może jakiś warunek sprawdzający, czy w ogóle jest potrzeba, tzn. czy jest w bazie bookmarks)
                            cm.append(("Usuń z lokalnej historii", "RunPlugin(%s?action=removeFromBookmarks&imdb=%s&tmdb=%s&content=movie)" % (sysaddon, imdb, tmdb),))

                    collection = i.get("collection")
                    if collection:
                        # name = f'{i.get("title")} {i.get("originaltitle")}'
                        name = wybierz_nazwe_do_wyszukania_kolekcji( i.get("originaltitle"), i.get("title") )
                        # fflog(f'{name=}',1,1)
                        if name:
                            if PluginName:
                                cm.append(("Wyszukaj Kolekcje", "Container.Update(%s?action=collectionSearchterm&name=%s)" % (sysaddon, urllib.quote_plus(name)),))
                            else:
                                pass
                                cm.append(("Wyszukaj Kolekcje", "ActivateWindow(10025,%s?action=collectionSearchterm&name=%s,return)" % (sysaddon, urllib.quote_plus(name)),))
                        else:
                            if currentPath.get("action") not in ["collection", "collections"]:
                                if not generate_short_path:
                                # if True:
                                    if PluginName:
                                        cm.append(("Wszystkie z Kolekcji", "Container.Update(%s?action=collection&tmdb=%s)" % (sysaddon, collection),))
                                    else:
                                        pass
                                        cm.append(("Wszystkie z Kolekcji", "ActivateWindow(10025,%s?action=collection&tmdb=%s,return)" % (sysaddon, collection),))
                                else:
                                    if PluginName:
                                        cm.append(("Wszystkie z Kolekcji", "Container.Update(%s?action=collection)" % (sysaddon,),))
                                    else:
                                        pass
                                        cm.append(("Wszystkie z Kolekcji", "ActivateWindow(10025,%s?action=collection,return)" % (sysaddon,),))

                    if cm_enable_similar_trakt:
                        if imdb and imdb != "None" and imdb != "0":
                            cm.append(
                                (
                                    "Znajdź podobne (Trakt)",
                                    "ActivateWindow(10025,%s?action=movies&url=https://api.trakt.tv/movies/%s/related,return)"
                                    % (sysaddon, imdb),  # https://trakt.docs.apiary.io/#reference/movies/related/get-related-movies
                                    # % (sysaddon, tmdb),  # źle działa, bo wg dokumentacji to może być tylko Trakt ID (numer), Trakt slug (nazwa typu tytul-filmu-2018) lub IMDB ID
                                )
                            )

                    if cm_enabl_similar_tmdb:
                        if not generate_short_path:
                            if PluginName:
                                cm.append(("Znajdź podobne", "Container.Update(%s?action=similar&tmdb=%s)" % (sysaddon, tmdb),))
                            else:
                                cm.append(("Znajdź podobne", "ActivateWindow(10025,%s?action=similar&tmdb=%s)" % (sysaddon, tmdb),))
                        else:
                            cm.append(("Znajdź podobne", "Container.Update(%s?action=similar)" % (sysaddon,),))

                    if cm_enable_recommendations_tmdb:
                        if not generate_short_path:
                            if PluginName:
                                cm.append(("Rekomendacje", "Container.Update(%s?action=recommendations&tmdb=%s)" % (sysaddon, tmdb),))
                            else:
                                cm.append(("Rekomendacje", "ActivateWindow(10025,%s?action=recommendations&tmdb=%s)" % (sysaddon, tmdb),))
                        else:
                            cm.append(("Rekomendacje", "Container.Update(%s?action=recommendations)" % (sysaddon,),))

                    if cm_enable_queueMenu:
                        if not isFolder:
                            if kodiver.major < 21 or kodiver.major >= 21 and kodiver.minor < 2:
                                cm.append((queueMenu, "RunPlugin(%s?action=queueItem)" % sysaddon))

                    if fullpath:
                        cm.append(("[I]przygotuj do ulubionych[/I]", "Container.Update(%s?action=prepareItemForAddToLibrary)" % (sysaddon),))

                    if isOld:
                        cm.append((control.lang2(19033), "Action(Info)"))  # "Informacje" ? Może w starszym Kodi nie dodawał automatycznie


                    # fflog(f'{overlay=}  {percent=}',1,1)
                    if add_rating_for_tmdb:
                        if overlay == 7 or percent and int(percent) > 40:
                        # if True:
                            if not tmdbCredentials:
                                cm.append(("Oceń film", "RunPlugin(%s?action=add_rating&content=movie&tmdb=%s)" % (sysaddon, tmdb),))


                    if cm_enable_exitFromList and back_to:
                        cm.append(("Wyjdź z listy", "Container.Update(%s?%s, replace)" % (sysaddon, back_to) ))
                        pass


                    art = {}

                    art.update({
                                "icon": icon or poster,  # nie wiem, czy to jeszcze występuje gdzieś
                                "thumb": thumb or poster,  # to ważniejsze
                                "poster": poster,
                               })

                    art["fanart"] = i["fanart"] if settingFanart == 'true' and has("fanart") else addonFanart

                    art["landscape"] = i["landscape"] if has("landscape") else art["fanart"]

                    art["banner"] = i["banner"] if has("banner") else addonBanner

                    # for key in ("clearlogo", "clearart", "keyart", "discart", "banner", "landscape", "fanart"):
                    for key in ("clearlogo", "clearart", "keyart", "discart"):
                        if has(key):
                            art[key] = i[key]

                    # fflog(f'{label=}  {art=}',1,1)
                    item.setArt(art)


                    castwiththumb = i.get("castwiththumb")
                    if castwiththumb:
                        # fflog(f'{castwiththumb=}',1,1)
                        castwiththumb = [Actor(**a) for a in castwiththumb]
                        vtag.setCast(castwiththumb)


                    # ustawienie m.in. tytułu na podstawie meta
                    item.setInfo(type="Video", infoLabels=control.metadataClean(meta))  # ten sposób będzie porzucony w którymś nowszym Kodi
                    # fflog(f'meta={json.dumps(control.metadataClean(meta), indent=2)}',1,1)
                    # nowszy sposób
                    # vtag.setMediaType('movie')  # yatse ma z tym problem
                    # vtag.setMediaType('video')  # workaround
                    # vtag.setTitle( meta.get("title") )
                    # if meta.get("year"):  vtag.setYear( int( meta.get("year") ) )
                    # vtag.setPlot( meta.get("plot") or "" )
                    # vtag.setPremiered(  )
                    # vtag.setDuration(  )
                    # pewnie trzeba jeszcze więcej dorobić

                    item.setProperty("meta", json.dumps(meta))  # bo poprzednio było ograniczenie (z powodu metadataClean, bez którego Kodi mogło by się wywalić)

                    # korekta pod standard ListItem (bo super_info.py inaczej generuje)
                    # vtag.setOriginalTitle(meta.get("originalname"))  # nie wiem czy dopiero od Kodi 20
                    item.setInfo(type="Video", infoLabels={'OriginalTitle': meta.get("originalname") or meta.get("originaltitle", "")})
                    # nie wiem czy dopiero od Kodi 20
                    # vtag.setOriginalTitle( meta.get("originalname") or meta.get("originaltitle", "") )

                    # taki mój dodatek
                    item.setProperty("EnglishTitle", meta.get("englishtitle") or meta.get("originaltitle", ""))

                    item.setInfo(type="Video", infoLabels={'count': counter})  # do sortowania potrzebne

                    # item.setInfo(type="Video", infoLabels={"sorttitle": meta.get("title")})  # do przetestowania, bo nie wiem, jak to wykorzystać

                    if yatse:
                        vtag.setMediaType('video')  # yatse źle interpretuje element, gdy jest podany jako typ Movie, tzn. nie chce wyświetlać źródeł, jeśli mają być wyświetlone w katalogu (na fonie)


                    try:  # bo nie wiem czy dostępne dopiero od Kodi 20 (choć ListItem.UniqueID() dostępne już od Kodi 19, więc może przez infoLabels trzeba ustawiać)
                        #vtag.setUniqueID(imdb, "imdb")
                        #vtag.setUniqueID(tmdb, "tmdb")
                        vtag.setUniqueIDs({'imdb': imdb, 'tmdb': tmdb})  # od razu kilka na raz
                    except Exception:
                        #item.setInfo(type="Video", infoLabels={'UniqueID("imdb")': imdb, 'UniqueID("tmdb")': tmdb})  # wstawia tylko dla imdb
                        #item.setProperty("imdb_id", imdb)
                        #item.setProperty("tmdb_id", tmdb)
                        item.setProperties({'imdb_id': imdb, 'tmdb_id': tmdb})  # kilka na raz
                        pass

                    if generate_short_path and collection:
                        item.setProperty("collection_id", str(collection))

                    if fullpath:
                        item.setProperty("fullpath", fullpath)

                    if not isFolder and not dont_use_setResolvedUrl:
                    # if not isFolder:
                        isPlayable = "true"  # umożliwi używanie setResolvedUrl nawet dla okienka (ale chyba w przypadku rezygnacji z odtwarzania pojawi się błąd Kodi "nieudane odtwarzanie")
                        # isPlayable = "false"  # wymuszenie (tak było kiedyś)
                    else:
                        isPlayable = "false"  # aby nie było komunikatów o nieudanym odtwarzaniu
                    if isPlayable == "true":  # kiedyś nie warto było ustawiać "false"
                        item.setProperty("IsPlayable", isPlayable)
                    # fflog(f'{isPlayable=} for {title=}',1,1)

                    # vtag.addVideoStream(VideoStreamDetail(codec="h264"))  # czemu tak? czy to coś przyspiesza, ułatwia?

                    item.addContextMenuItems(cm)  # dodanie menu kontekstowego

                    # control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)  # dodanie całej pozycji do listy katalogu Kodi
                    list_of_items.append((url, item, isFolder,))

                    counter += 1

                except Exception as exc:
                    fflog_exc(1)
                    import traceback
                    # print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}', file=sys.stderr)  # stderr is logged as ERROR
                    print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}')  # default (stdout) is logged as DEBUG
                    pass

                multi_select.append({"title": i["originaltitle"], "title_multi": i["title"], "year": i["year"], "imdb": i["imdb"], "tmdb": i["tmdb"], })

            fflog(f'{len(list_of_items)=}',1,1)
            control.addItems(syshandle, list_of_items)  # dodanie zbiorcze

            try:
                # curr_page = items[0].get("curr_page")
                total_pages = items[0].get("total_pages") or 1
                total_pages = 500 if total_pages > 500 else total_pages  # jakieś ograniczenie ze strony tmdb
                # fflog(f'{total_pages=}',1,1)
                pass
            except Exception:
                pass
                # fflog_exc(1)

            if params.get("url"):
                url = dict(urllib.parse_qsl(params.get("url")))
                # fflog(f'{url=}',1,1)
                curr_page = int(url.get("page") or 0)  # to coś źle działa na ostatniej stronie
                # fflog(f'{curr_page=}',1,1)
            else:
                # curr_page = items[0].get("curr_page") if items else 0  # to chyba sprawdzało się
                # fflog(f'{curr_page=}',1,1)
                # fflog(f'{params=}',1,1)
                curr_page = int(params.get("page") or 0)
                # fflog(f'{curr_page=}',1,1)
            # fflog(f'{curr_page=} \n{params=} \n{url=}')

            # następna strona
            try:
                url = items[0].get("next")
                if url:
                    # fflog(f'przygotowanie elementu Następna strona, bo {url=}',1,1)
                    url = re.sub("(?<=api_key=)[^&]*", "", url)
                    url = re.sub("(?<=session_id=)[^&]*", "", url)

                    icon = control.addonNext()

                    addonLandscape = control.addonLandscape()

                    label = nextMenu

                    # fflog(f'items[0]={json.dumps(items[0], indent=2)}',1,1)

                    total_pages = items[0].get("total_pages") or 1
                    total_pages = 500 if total_pages > 500 else total_pages  # jakieś ograniczenie ze strony tmdb
                    curr_page = items[0].get("curr_page") or 0
                    # fflog(f'{curr_page=}  {total_pages=}',1,1)

                    if curr_page + 1 <= total_pages or total_pages == 1:

                        if total_pages > 1:  # nie potrafię na ten moment zidentyfikować problemu
                            if (curr_page + 1 == total_pages
                                and total_pages > 2
                            ):
                                label = label.replace("Następna", "Ostatnia")
                                pass

                            if total_pages and curr_page:
                                label += f"[I][LIGHT] ({curr_page + 1} z {total_pages}) [/LIGHT][/I]"

                        item = control.item(label=label)  # create ListItem

                        item.setArt({
                                    "icon": icon, 
                                    "thumb": icon, 
                                    "poster": icon,
                                    "banner": icon,
                                    "fanart": addonFanart, 
                                    "landscape": addonLandscape,
                                    })

                        if generate_short_path:
                            page = dict(urllib.parse_qsl(url)).get("page", "")
                            # item.setProperty("url", url.replace(f"&page={page}", ""))
                            # item.setProperty("url", re.sub(f"(?<=[?&/])page[=/]{page}", "", url).replace("&&", "&").replace("?&", "?").rstrip("?&"))  # uniwersalniejsze
                            item.setProperty("url", re.sub(f"((?<=[?/])|&)page[=/]{page}", "", url).replace("?&", "?").rstrip("?&"))  # uniwersalniejsze
                            url = "{}?action=moviePage&page={}".format(sysaddon, page)
                        else:
                            url = "{}?action=moviePage&url={}".format(sysaddon, urllib.quote_plus(url))

                        if multi:
                            if self.tmdb_link in items[0].get("next"):
                                url = url.replace("=moviePage&", "=multiPage&", 1)
                                pass

                        # może pomóc dla zachowania kategorii na kolejnych stronach
                        if params.get("item") and "item=" not in url:
                            url += "&item=" + urllib.quote_plus(params.get("item"))

                        # pomaga odświeżać kolejne podstrony
                        if params.get("refresh") and "refresh=" not in url:
                            url += "&refresh=" + urllib.quote_plus(params.get("refresh"))

                        # item.setInfo(type="Video", infoLabels={'count': counter})  # do sortowania potrzebne - tylko, że to nie jest element wideo, a inaczej nie można wstawić countera - głupie to

                        if total_pages > 1:
                            cm = []
                            # cm.append(("A Wybierz stronę", "Container.Update(%s&total_pages=%s&curr_page=%s)" % (url, total_pages, curr_page,),))
                            # cm.append(("Wybierz stronę", "RunPlugin(%s&total_pages=%s&curr_page=%s)" % (url, total_pages, curr_page,),))
                            cm.append(("Wybierz stronę", "RunPlugin(%s&total_pages=%s&curr_page=%s&back_to=%s)" % (url, total_pages, curr_page, urllib.quote_plus(back_to),),))
                            item.addContextMenuItems(cm)

                        item.setProperty("SpecialSort", "bottom")  # The item will remain at the top or bottom of the current list ( https://alwinesch.github.io/group__python__xbmcgui__listitem.html#ga96f1976952584c91e6d59c310ce86a25 )

                        if back_to:
                            url += f"&back_to={urllib.quote_plus(back_to)}"

                        control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
                    else:
                        fflog(f'ale problem, bo  {curr_page=}  {total_pages=}',1,1)
                        pass
                else:
                    # fflog(f'brak następnej strony',1,1)
                    # fflog(f'{len(items)=}',1,1)
                    # fflog(f'items={json.dumps(items, indent=2)}',1,1)
                    pass
            except Exception as exc:
                # curr_page = 1
                fflog_exc(1)
                import traceback
                # print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}', file=sys.stderr)  # stderr is logged as ERROR
                print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}')  # default (stdout) is logged as DEBUG
                pass

            if not multi:
                control.content(syshandle, "movies")  # to chyba ważne dla Kodi i skórek
            else:
                # control.content(syshandle, "videos")  # nie wiem, jaki typ byłby najlepszy
                control.content(syshandle, "tvshows")  # umożliwia pokazywanie ilości odcinków pozostałych do obejrzenia
                # control.content(syshandle, "seasons")  # takiego typu oficjalnie nie ma (albo brak takiej informacji w dokumentacji)

            cat_label = ""
            if category:
                if isinstance(category, list):
                    category = " / ".join(category).strip(" /")
                cat_label += category
            if curr_page and curr_page > 1:
                if cat_label:
                    cat_label += " [LIGHT]/[/LIGHT] "
                cat_label += f'[LIGHT]str. {curr_page}[/LIGHT]'
            if cat_label:
                control.pluginCategory(syshandle, cat_label)

            updateListing = False
            """
            params = dict(urllib.parse_qsl(sys.argv[2].replace("?", "")))
            updateListing = False if params.get("name") or params.get("item") else True  # True może świadczyć, że po drodze było odświeżanie
            """
            # fflog(f'{action=}  {params=}',1,1)
            updateListing = True if params.get("r") else False  # True świadczy, że po drodze było odświeżanie
            # updateListing = True if action=="movieSearchnew" else updateListing  # to w niczym nie pomaga
            control.directory(syshandle, cacheToDisc=cacheToDisc, updateListing=updateListing)

            if PluginName:
                if not multi:
                    views.setView("movies")  # dodatkowa funkcja FanFilm
                else:
                    views.setView("tvshows")

            if meta:  # dziwny warunek, zależny od ostatniego elementu z listy filmów
                cache.cache_insert("multi_select", repr(multi_select))
                pass

            # fflog(f'{moviessort=}',1,1)
            if moviessort:
                # trzeba to przemyśleć
                # control.execute("Container.SetSortMethod(16)")  # https://kodi.wiki/view/List_of_built-in_functions#List_of_sort_methods
                pass

            if PluginName or 0:  # nie wiem, czy dobrze
                if control.condVisibility('Container.Sortmethod(16)') or control.condVisibility('Container.Sortmethod(17)'):
                    if control.condVisibility('Container.SortDirection(ascending)'):
                        control.execute("Container.SetSortDirection")
                        pass

            fflog('koniec metody',1,1)


        ### FOLDER ###
        def addDirectory(self, items, queue=False, cacheToDisc=True, add_refresh=False, category=""):
            fflog("[addDirectory]")

            if items is None or len(items) == 0:
                # sys.exit()
                return

            sysaddon = sys.argv[0]
            syshandle = int(sys.argv[1])

            PluginName = control.infoLabel("Container.PluginName")
            # PluginName = PluginName == "plugin.video.kadrplus"  # nie wiem, czy to potrzebne
            # fflog(f'{PluginName=}',1,1)

            addonFanart, addonThumb, artPath = control.addonFanart(), control.addonThumb(), control.artPath()
            settingFanart =  control.setting("fanart")
            queueMenu = control.lang(32065)  # Dodaj do kolejki (FF)
            playRandom = control.lang(32535)
            isFolder = False if control.setting("hosts.mode") != "1" else True
            addToLibrary = control.lang(32551)
            generate_short_path = control.setting("generate_short_path") == "true"

            list_of_items = []

            for i in items:
                # fflog(f'(i) item={json.dumps(i, indent=2)}',1,1)

                def has(key):
                    val = i.get(key)
                    return val and val != "0"

                try:
                    label = i["name"]  # wyświetlana nazwa pozycji

                    # plot = i.get("plot") or ""
                    plot = i.get("plot") or "[CR]"

                    # fflog(f'{i["image"]=}',1,1)
                    if i["image"].startswith("http"):
                        thumb = i["image"]
                    elif i["image"].startswith("Default"):
                        thumb = i["image"]
                    elif artPath is not None:
                        thumb = os.path.join(artPath, i["image"])
                    else:
                        thumb = addonThumb
                    # fflog(f'{thumb=}',1,1)

                    i["url"] = re.sub("(?<=api_key=)[^&]*", "", i["url"])
                    i["url"] = re.sub("(?<=session_id=)[^&]*", "", i["url"])

                    # bulding context menu
                    cm = []

                    # odtwórz losowo
                    # rtype - a jak jest multi ? Np. mieszane listy Trakt
                    if not isFolder:
                        cm.append((playRandom, "RunPlugin(%s?action=random&rtype=movie&url=%s)" % (sysaddon, urllib.quote_plus(i["url"])),))
                    else:
                        cm.append((playRandom, "RunPlugin(%s?action=random&rtype=movie&url=%s&select=%s)" % (sysaddon, urllib.quote_plus(i["url"]), 1),))
                        # cm.append((playRandom, "Container.Update(%s?action=random&rtype=movie&url=%s)" % (sysaddon, urllib.quote_plus(i["url"])),))  # problem z podwójnym przekierowaniem
                        pass

                    if queue:
                        cm.append((queueMenu, "RunPlugin(%s?action=queueItem)" % sysaddon))

                    try:
                        cm.append((addToLibrary, "RunPlugin(%s?action=moviesToLibrary&url=%s)" % (sysaddon, urllib.quote_plus(i["context"])),))
                    except Exception:
                        # fflog_exc(1)
                        pass


                    item = control.item(label=label, offscreen=True)  # create ListItem

                    item.setArt({
                                "icon": thumb, 
                                "thumb": thumb, 
                                "poster": thumb, 
                                "fanart": i["fanart"] if settingFanart == 'true' and has("fanart") else addonFanart, 
                                })

                    biography = i.get("biography") or ""
                    if plot or biography:
                        vtag = item.getVideoInfoTag()
                        vtag.setPlot(plot or biography)
                        vtag.setTagLine(i.get("tagline") or "")
                        vtag.setPlotOutline(i.get("plotoutline") or "")
                        vtag.setTitle(label)
                        mediatype = i.get("mediatype")
                        if mediatype:
                            vtag.setMediaType(mediatype)
                        else:
                            # vtag.setMediaType('video')  # jak ma być w kontekstowym opcja "Informacje" (szkodza, że nie ma typu "person" czy "actor"
                            # vtag.setMediaType('movie')
                            # vtag.setMediaType('tvshow')  # pozwala wyświetlić przycisk "przeglądaj" zamiast "odtwarzaj"
                            # tylko wtedy dubluje się własny wpis w menu kontekstowym
                            pass
                        # a może zrobić własny wpis w contekst menu, który wywoła informacje?
                        if not mediatype:
                            if biography:
                                cm.append(("Biografia", "Action(Info)"))
                                pass
                            else:
                                cm.append(("Informacje", "Action(Info)"))
                                pass
                        if i.get("castandrole"):
                            # castandrole = [{"name": " "}]  # placeholder
                            castandrole = i.get("castandrole")
                            castandrole = [Actor(**a) for a in castandrole]
                            vtag.setCast(castandrole)  # tylko, że tworzy się zdublowana informacja (przynajmniej na domyślnej skórce), bo skórka traktuje to jako obsadę do wideo
                    else:
                        # fflog(f'{i=}',1,1)
                        pass

                    if f"https://api.themoviedb.org/3/list/{(list_id:=i.get('id'))}?" in i["url"]:
                        cm.append(( "Usuń listę", "RunPlugin(%s?action=DeleteList&id=%s&name=%s)" % (sysaddon, list_id, urllib.quote_plus(i["name"]),) ))

                    url = "{}?action={}".format(sysaddon, i["action"])  # akcja, czyli co ma się wykonać po naciśnięciu ENTER na danej pozycji
                    # action = dict(urllib.parse_qsl("action="+i["action"]))
                    # fflog(f'{i["action"]=}  {action=}')
                    try:
                        #if not generate_short_path or i["action"] not in ["movies", "moviePage", "findMediaWithPerson"]:  # zabezpieczenie, jakbym nie wszystko sprawdził
                        # if not generate_short_path or not "item" in action:  # teraz wykorzystuje item
                        if not generate_short_path:
                            # fflog(f'długa ścieżka')
                            url += "&url=%s" % urllib.quote_plus(i["url"])
                            # url = re.sub(r"\bitem=[^&]*", "", url)  # przeszkadza dla category
                        else:
                            # fflog(f'krótka ścieżka')
                            item.setProperty("url", i["url"])
                            item.setProperty("urlD", i["url"])
                    except Exception:
                        fflog_exc(1)
                        pass

                    if add_refresh:
                        # if PluginName:
                        cm.append(("Odśwież teraz", "Container.Update(%s&refresh=1)" % url))  # url potrzebny

                    # fflog(f'{url=}  \n{i["url"]=}',1,1)
                    if "api.trakt.tv/users/" in i["url"]:
                        # if PluginName:
                        # cm.append(("Sortowanie od końca", "Container.Update(%s&sort_how=desc&refresh=1)" % url))  # url potrzebny
                        # fflog(f'{i=}',1,1)
                        # fflog(f'{url=}',1,1)
                        if "sort_how%3Ddesc" in url:
                            url2 = url.replace("sort_how%3Ddesc", "sort_how%3Dasc")
                            cm.append(("Wyświetl listę rosnąco", "Container.Update(%s)" % url2))  # url potrzebny
                        elif "sort_how%3Ddasc" in url:
                            url2 = url.replace("sort_how%3Dasc", "sort_how%3Ddesc")
                            cm.append(("Wyświetl listę malejąco", "Container.Update(%s)" % url2))  # url potrzebny
                        else:
                            url2 = url + ("&sort_how=desc")
                            cm.append(("Wyświetl listę od końca", "Container.Update(%s)" % url2))  # url potrzebny

                    item.addContextMenuItems(cm)

                    # control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
                    list_of_items.append((url, item, True,))

                except Exception as exc:
                    fflog_exc(1)
                    import traceback
                    # print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}', file=sys.stderr)  # stderr is logged as ERROR
                    print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}')  # default (stdout) is logged as DEBUG
                    pass

            fflog(f'{len(list_of_items)=}',1,1)
            control.addItems(syshandle, list_of_items)  # dodanie zbiorcze

            try:
                # curr_page = int(items[0].get("next").get("curr_page"))
                total_pages = items[0].get("total_pages") or 1
                total_pages = 500 if total_pages > 500 else total_pages  # jakieś ograniczenie ze strony tmdb
                pass
            except Exception:
                total_pages = 1
                pass
                # fflog_exc(1)

            if params.get("url"):
                url = dict(urllib.parse_qsl(params.get("url")))
                # fflog(f'{url=}',1,1)
                curr_page = int(url.get("page") or 0)
                # fflog(f'{curr_page=}',1,1)
            else:
                # curr_page = items[0].get("curr_page") if items else 0
                # fflog(f'{curr_page=}',1,1)
                # fflog(f'{params=}',1,1)
                curr_page = int(params.get("page") or 0)
                # fflog(f'{curr_page=}',1,1)
            # fflog(f'{curr_page=} \n{params=} \n{url=}')

            # następna strona
            try:
                i = items[0]
                url = i.get("next")
                if url:
                    # fflog(f'next {url=}',1,1)
                    if isinstance(url, dict):
                        action = url.get("action")
                        url = url.get("url")
                    else:
                        # action = ""  # ? coś musi być action z linijek wyżej
                        fflog(f'{action=}',1,1)
                        pass

                    url = re.sub("(?<=api_key=)[^&]*", "", url)
                    url = re.sub("(?<=session_id=)[^&]*", "", url)

                    nextMenu = control.lang(32053)
                    nextMenu = nextMenu + "  >>"
                    icon = control.addonNext()
                    addonFanart = control.addonFanart()
                    addonLandscape = control.addonLandscape()

                    label = nextMenu

                    try:
                        total_pages = i.get("next").get("total_pages") or 1
                    except Exception:
                        fflog_exc(1)
                        total_pages = 1
                        pass
                    total_pages = 500 if total_pages > 500 else total_pages  # jakieś ograniczenie ze strony tmdb (ale trakt nie ma takiego chyba)

                    try:
                        curr_page = i.get("next").get("curr_page") or 0
                    except:
                        curr_page = 0
                    # fflog(f'{curr_page=}  {total_pages=}',1,1)

                    if curr_page + 1 <= total_pages or total_pages == 1:

                        if total_pages > 1:  # nie potrafię na ten moment zidentyfikować problemu
                            if (curr_page + 1 == total_pages
                                and total_pages > 2
                            ):
                                label = label.replace("Następna", "Ostatnia")
                                pass

                            if total_pages and curr_page:
                                label += f"[I][LIGHT] ({curr_page + 1} z {total_pages}) [/LIGHT][/I]"

                        item = control.item(label=label)  # create ListItem

                        item.setArt({
                                    "icon": icon, 
                                    "thumb": icon, 
                                    "poster": icon,
                                    "banner": icon,
                                    "fanart": addonFanart, 
                                    "landscape": addonLandscape,
                                    })

                        if not generate_short_path:  # or not "item" in action:
                            url = "{}?action={}&url={}".format(sysaddon, action, urllib.quote_plus(url))
                            # url = re.sub(r"\bitem=[^&]*", "", url)
                        else:
                            page = dict(urllib.parse_qsl(url)).get("page", "")
                            # fflog(f'next {page=}',1,1)
                            item.setProperty("urlDNext", url)
                            url = "{}?action={}&page={}".format(sysaddon, action, page)
                        # fflog(f'next {url=}',1,1)

                        # pomaga odświeżać kolejne podstrony (choć nie wiem, czy tu akurat jest to wykorzystywane)
                        if params.get("refresh") and "refresh=" not in url:
                            url += "&refresh=" + urllib.quote_plus(params.get("refresh"))

                        # item.setInfo(type="Video", infoLabels={'count': counter})  # do sortowania potrzebne - tylko, że to nie jest element wideo, a inaczej nie można wstawić countera - głupie to

                        d_back_to = params.get("d_back_to", "")
                        if not d_back_to:
                            # fflog(f'{sys.argv[2][1:]=}',1,1)
                            d_back_to = sys.argv[2][1:]
                            folderpath  = control.infoLabel('Container.FolderPath')
                            # referer = dict(urllib.parse_qsl(folderpath.split('?')[-1]))
                            # fflog(f'{referer=}',1,1)
                            d_back_to = folderpath.split('?')[-1]
                        fflog(f'{d_back_to=}',1,1)
                        # d_back_to = ''

                        if total_pages > 1:
                            cm = []
                            cm.append(("Wybierz stronę", "RunPlugin(%s&total_pages=%s&curr_page=%s&d_back_to=%s)" % (url, total_pages, curr_page, urllib.quote_plus(d_back_to),),))
                            # fflog(f'{action=}',1,1)
                            item.addContextMenuItems(cm)

                        if d_back_to:
                            url += f"&d_back_to={urllib.quote_plus(d_back_to)}"

                        item.setProperty("SpecialSort", "bottom")  # The item will remain at the top or bottom of the current list ( https://alwinesch.github.io/group__python__xbmcgui__listitem.html#ga96f1976952584c91e6d59c310ce86a25 )

                        control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
                    else:
                        # fflog(f'ale problem, bo  {curr_page=}  {total_pages=}',1,1)
                        pass
                else:
                    # fflog(f'brak następnej strony',1,1)
                    # fflog(f'{len(items)=}',1,1)
                    # fflog(f'items={json.dumps(items, indent=2)}',1,1)
                    pass

            except Exception as exc:
                fflog_exc(1)
                # import traceback
                # print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}', file=sys.stderr)  # stderr is logged as ERROR
                # print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}')  # default (stdout) is logged as DEBUG
                pass

            cat_label = ""
            if category:
                if isinstance(category, list):
                    category = " / ".join(category).strip(" /")
                cat_label += category
            if curr_page and curr_page > 1:
                if cat_label:
                    cat_label += " [LIGHT]/[/LIGHT] "
                cat_label += f'[LIGHT]str. {curr_page}[/LIGHT]'
            if cat_label:
                control.pluginCategory(syshandle, cat_label)

            # control.content(syshandle, "addons")  # to psuje wyświetlanie informacji o osobach dla domyślnej skórki (nie bierze plot-u)
            # control.content(syshandle, "movies")
            updateListing = True if params.get("r") else False  # True świadczy, że po drodze było odświeżanie
            control.directory(syshandle, cacheToDisc=cacheToDisc, updateListing=updateListing)

            if PluginName:
                views.setView("addons")  # dodatkowa funkcja FanFilm

            fflog('koniec metody',1,1)




    def import_and_join(file_module, join_to):
        # import resources.lib.indexers.tmdb_manager as subm
        # import file_module as subm  # to nie działa

        # subn = ["lib", "indexers", "tmdb_manager"]
        # subm = __import__("resources.lib.indexers.tmdb_manager")
        # while subn:
            # subm = getattr(subm, subn.pop(0))
        # fflog(f'{subm=}',1,1)

        subm = __import__(file_module)
        subn = file_module.split(".")
        subn.pop(0)
        while subn:
            subm = getattr(subm, subn.pop(0))

        methods = [ m for m in dir(subm)
                   if not m.startswith('__')
                  ]
        for m in methods:
            setattr(join_to, m, getattr(subm, m))
            pass
        # subm = None


    # import_and_join("resources.lib.indexers.tmdb_manager", movies)



    def wybierz_nazwe_do_wyszukania_kolekcji(original, localized):
        """ funkcja zwraca nazwę, gdy tytuł filmu jest na specjalnej liście """

        if localized.lower() == "człowiek ze stali":  # wyjątek
            localized = "superman"
            
        keywords = KOLEKCJE_WYJATKI

        for keyword in keywords:
            if keyword in original.lower() or keyword in localized.lower():
                return keyword



    def wybierz_nazwe_do_wyszukania_kolekcji_inne_podejscie(name):
        """ funkcja może być przydatna, gdyby próbować szukać w ciemno """
        name = name.lower()
        name = name.split(" ")  # podział na wyrazy

        # ogólny zarys
        if name[0] == "the":
            name = f'{name[0]} {name[1]}'
        # elif ...:
            # pass
        else:
            name = name[0]

        return name



    # lista nazw kolekcji, których jest kilka dla jakiejś serii
    KOLEKCJE_WYJATKI = (
        "star trek",
        "spider-man",
        "superman",
        "batman",
        "star wars",
        "how to train your dragon",
        "lion king",
        "stitch",
        "planet of the apes",
        "godzilla",
        "ghost in the shell",
        "dragon ball",
        "obcy",
        "asteriks",
        # kolejny tytuł (małymi literami) w cudzysłowie ,
    )



    return movies()  # wrapper