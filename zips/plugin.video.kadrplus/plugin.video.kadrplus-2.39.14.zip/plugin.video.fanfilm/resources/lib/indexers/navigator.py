"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
def navigator():

    import os
    import sys

    from ptw.libraries import control
    from ptw.libraries import trakt

    from ptw.libraries.log_utils import log, fflog
    from ptw.debug import log_exception, fflog_exc


    try:
        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])
    except Exception:
        # gdy wywołanie z service.py
        pass

    queueMenu = control.lang(32065)
    artPath = control.artPath()
    addonFanart = control.addonFanart()

    # imdbCredentials = False if control.setting("imdb.user") == "" else True
    # tmdbCredentials = False if control.setting("tmdb.sessionid") == "" else True
    # traktCredentials = trakt.getTraktCredentialsInfo()
    # traktIndicators = trakt.getTraktIndicatorsInfo()
    imdbCredentials = tmdbCredentials = traktCredentials = traktIndicators = PluginName = False

    imdbCredentials = False if control.setting("imdb.user") == "" else True
    tmdbCredentials = False if control.setting("tmdb.sessionid") == "" else True
    traktCredentials = trakt.getTraktCredentialsInfo()
    traktIndicators = trakt.getTraktIndicatorsInfo()

    PluginName = control.infoLabel("Container.PluginName")
    # PluginName = PluginName == "plugin.video.kadrplus"  # nie wiem, czy to potrzebne
    fflog(f'{PluginName=}',0,1)


    class navigator:

        def __init__(self):
            if 0:
                # fix for not always current value
                # global syshandle
                nonlocal syshandle
                syshandle = int(sys.argv[1])
                # global imdbCredentials, tmdbCredentials, traktCredentials, traktIndicators
                nonlocal imdbCredentials, tmdbCredentials, traktCredentials, traktIndicators
                imdbCredentials = False if control.setting("imdb.user") == "" else True
                tmdbCredentials = False if control.setting("tmdb.sessionid") == "" else True
                traktCredentials = trakt.getTraktCredentialsInfo()
                traktIndicators = trakt.getTraktIndicatorsInfo()

                # global PluginName
                nonlocal PluginName
                PluginName = control.infoLabel("Container.PluginName")
                # PluginName = PluginName == "plugin.video.kadrplus"  # nie wiem, czy to potrzebne
                fflog(f'{PluginName=}',0,1)


        def root(self):
            """ wyświetla początkowe menu """

            self.addDirectoryItem(32010, "searchNavigator", "search.png", "DefaultAddonsSearch.png")

            self.addDirectoryItem(32001, "movieNavigator", "movies.png", "DefaultMovies.png")

            self.addDirectoryItem(32002, "tvNavigator", "tvshows.png", "DefaultTVShows.png")

            self.addDirectoryItem("Publiczne listy Trakt", "publicTraktListsNavigator", "traktlists.png", "DefaultVideoPlaylists.png")  # from trakt

            limit = int(control.setting("lastWatchedList.limit"))
            if limit:
                ostatnio_ogladane  = "Ostatnio oglądan"+("y" if limit == 1 else "e")
                ostatnio_ogladane += "  [LIGHT][I](to urządzenie)[/I][/LIGHT]" if trakt.getTraktIndicatorsInfo() else ""
                self.addDirectoryItem(ostatnio_ogladane, "lastWatched", "last_watched.png", "DefaultInProgressShows.png")

            """
            downloads = (True  if (
                                    control.setting("downloads") == "true"
                                    and (len(control.listDir(control.setting("movie.download.path"))[0]) > 0
                                      or len(control.listDir(control.setting("movie.download.path"))[1]) > 0
                                      or len(control.listDir(control.setting("tv.download.path"))[0]) > 0  # seriale zawsze są (albo powinny być) w folderach
                                      or len(control.listDir(control.setting("tv.download.path"))[1]) > 0  # test
                                        )
                                  )
                         else False)
            """
            downloads = (
                control.setting("downloads") == "true"
                and not (
                    control.setting("movie.download.path") == ""
                    or control.setting("tv.download.path") == ""
                )
            )
            if downloads:
                self.addDirectoryItem(32009, "downloadNavigator", "downloads.png", "DefaultAddonsRepo.png")

            self.addDirectoryItem(32008, "toolNavigator", "tools.png", "DefaultAddonProgram.png")
            # self.addDirectoryItem("Testy", "test", "", "")  # do testowania

            # control.pluginCategory(syshandle, "FanFilm")
            self.endDirectory(category=[""])

            if False:  # do testów
                try:
                    a = b
                    pass
                except Exception:
                    fflog_exc(1)
                    pass

            if 0:  # testy
                control.sleep(1000)
                control.log(f"{control.infoLabel('System.CurrentWindow')=}", 1)
                control.log(f"{control.infoLabel('System.CurrentControl')=}", 1)
                control.log(f"{control.infoLabel('System.CurrentControlID')=}", 1)
            if 0:  # testy
                win_id = control.currentWindowId
                control.log(f"{win_id=}", 1)
                focus_panel_id = control.getCurrentViewId()  # focus_panel_id
                control.log(f"{focus_panel_id=}", 1)
                # import xbmc
                # xbmc.executebuiltin('SetFocus(9000,14000)')
                # https://kodi.wiki/view/List_of_built-in_functions#GUI_control_built-in's
                # https://xbmc.github.io/docs.kodi.tv/master/kodi-base/d0/d3e/page__list_of_built_in_functions.html#built_in_functions_7
                # xbmc.executebuiltin('Control.Message(50,moveup)')
                # xbmc.executebuiltin('Control.Move(50,1)')
                # xbmc.executebuiltin('SetFocus(50,2,absolute)')
                control.execute(f'SetFocus({focus_panel_id},2,absolute)')
                control.sleep(200)
                control.log(f"{control.infoLabel('ListItem.Label')=}", 1)



        def publicTraktListsNavigator(self):
            self.addDirectoryItem("Na czasie (trendy)", "movies&url=trending_lists", "traktlists.png", "DefaultVideoPlaylists.png")  # from trakt
            self.addDirectoryItem("Popularne", "movies&url=popular_lists", "traktlists.png", "DefaultVideoPlaylists.png")  # from trakt
            self.addDirectoryItem("[B]Wyszukaj[/B] listy", "traktListsSearch", "search.png", "DefaultAddonsSearch.png")
            self.endDirectory(category=["", "Listy Trakt"])
            # self.endDirectory(category="Listy Trakt")



        def movies(self, lite=False):
            self.addDirectoryItem(32010, "movieSearch", "search.png", "DefaultAddonsSearch.png")
            if (traktCredentials == True or imdbCredentials == True or tmdbCredentials == True or 0):
                self.addDirectoryItem(32003, "mymovieNavigator", "mymovies.png", "DefaultVideoPlaylists.png")
            self.addDirectoryItem(32005, "movies&url=tmdb_new", "latest-movies.png", "DefaultRecentlyAddedMovies.png")
            self.addDirectoryItem("Nadchodzące", "movies&url=tmdb_upcoming", "latest-movies.png", "DefaultRecentlyAddedMovies.png")
            self.addDirectoryItem(32022, "movies&url=tmbd_cinema", "in-theaters.png", "DefaultRecentlyAddedMovies.png", refresh=True)
            self.addDirectoryItem(32007, "channels", "channels.png", "DefaultAddonPVRClient.png")  # what is on TV
            self.addDirectoryItem((32018,"  (wg TMDB)"), "movies&url=tmdb_popular", "people_watching_movies.png", "DefaultFavourites.png")
            self.addDirectoryItem((32017,"  (wg Trakt)"), "movies&url=trending", "featured.png", "DefaultAddonAudioDSP.png")  # from trakt
            self.addDirectoryItem(32020, "movies&url=boxoffice", "box-office.png", "DefaultMusicTop100.png")  # from trakt
            self.addDirectoryItem("Najwyżej oceniane  (wg TMDB)", "movies&url=tmdb_top_rated", "highly-rated.png", "DefaultAddonAudioDecoder.png")
            self.addDirectoryItem(32631, "moviesAwards", "awards.png", "DefaultMusicTop100.png")
            self.addDirectoryItem(32011, "movieGenres", "genres.png", "DefaultGenre.png")
            self.addDirectoryItem(32632, "movieCompanies", "companies.png", "DefaultStudios.png")
            self.addDirectoryItem(32014, "movieLanguages", "languages.png", "DefaultAddonLanguage.png")
            self.addDirectoryItem("Rok (lub lata)", "movieYears", "years.png", "DefaultYear.png")
            self.addDirectoryItem("Kategorie wiekowe", "movieCertificates", "certificates.png", "DefaultUser.png")
            self.addDirectoryItem("Własny miks kryteriów", "customMovieCriteria", "search_movies.png", "DefaultAddonContextItem.png")

            if not tmdbCredentials:
                self.addDirectoryItem("Ocenione filmy (podczas sesji gościa)", "movies&url=tmdbguestrated", "tmdb.png", "DefaultFavourites.png",
                    refresh=True,
                    queue=True,
                    # context=(32551, "moviesToLibrary&url=tmdbguestrated"),
                    )

            # control.pluginCategory(syshandle, "FanFilm / Filmy")
            self.endDirectory(category=["", "Filmy"])



        def mymovies(self, lite=False):  # indywidualne listy z trakt, tmdb lub imdb
            self.accountCheck()

            if traktCredentials:
                self.addDirectoryItem(32032, "movies&url=traktcollection", "trakt.png", "DefaultVCD.png", queue=True, refresh=True,
                    context=(32551, "moviesToLibrary&url=traktcollection"), )

                self.addDirectoryItem(32033, "movies&url=traktwatchlist", "trakt.png", "DefaultFavourites.png", queue=True, refresh=True,
                    context=(32551, "moviesToLibrary&url=traktwatchlist"), )

                self.addDirectoryItem("Ulubione", "movies&url=traktfavorites", "trakt.png", "DefaultFavourites.png", queue=True, refresh=True,
                    context=(32551, "moviesToLibrary&url=traktfavorites"), )

                self.addDirectoryItem(32035, "movies&url=traktfeatured", "featured.png", "DefaultAddonAudioDecoder.png", queue=True, )  # Proponowane

                self.addDirectoryItem(32036, "movies&url=trakthistory", "trakt.png", "DefaultYear.png",
                  #context=("Odśwież teraz", "movies&url=trakthistory&refresh=1", "Container.Update"),  # sprawdzić, czy potrzebne, bo tam jakoś to inaczej jest to rozwiązane niż w serialach
                  refresh=True,  # jak coś, to teraz tak można
                )

            if tmdbCredentials:
                self.addDirectoryItem("Ulubione TMDB", "movies&url=tmdbuserfavourite", "tmdb.png", "DefaultFavourites.png",
                    refresh=True,
                    queue=True,
                    context=(32551, "moviesToLibrary&url=tmdbuserfavourite"),
                    )

                self.addDirectoryItem("Obserwowane TMDB", "movies&url=tmdbuserwatchlist", "tmdb.png", "DefaultFavourites.png",
                    refresh=True,
                    queue=True,
                    context=(32551, "moviesToLibrary&url=tmdbuserwatchlist"),
                    )


                if control.setting('tmdb.account_id'):  # v4
                    self.addDirectoryItem("Rekomendowane TMDB", "movies&url=tmdbrecommended", "tmdb.png", "DefaultFavourites.png",
                        refresh=True,
                        queue=True,
                        context=(32551, "moviesToLibrary&url=tmdbrecommended"),
                        )

                self.addDirectoryItem("Ocenione filmy (w TMDB)", "movies&url=tmdbuserrated", "tmdb.png", "DefaultFavourites.png",
                    refresh=True,
                    queue=True,
                    context=(32551, "moviesToLibrary&url=tmdbuserrated"),
                    )


            if imdbCredentials:
                self.addDirectoryItem("Obserwowane IMDb",   "movies&url=imdbwatchlist", "imdb.png", "DefaultFavourites.png",
                                # context=("Odśwież teraz", "movies&url=imdbwatchlist&refresh=1", "Container.Update"),
                                # context=(32551, "moviesToLibrary&url=imdbwatchlist"),  # na razie nie można kilku pozycji dodać - trzeba przerobić funkcję addDirectoryItem
                                # context=[(1menu), (2menu)]
                                refresh=True,
                                queue=True,
                                context=(32551, "moviesToLibrary&url=imdbwatchlist"),
                                )

            self.addDirectoryItem("Własne listy", "movieUserlists", "userlists.png", "DefaultVideoPlaylists.png", refresh=True,)

            # control.content(syshandle, "addons")  # pomaga w kategoriach dla domyślnej skórki
            self.endDirectory(category="Moje filmy")



        def tvshows(self, lite=False):
            self.addDirectoryItem(32010, "tvSearch", "search.png", "DefaultAddonsSearch.png")
            if (traktCredentials == True or imdbCredentials == True or tmdbCredentials == True):
                self.addDirectoryItem(32004, "mytvNavigator", "mytvshows.png", "DefaultVideoPlaylists.png")
            self.addDirectoryItem(control.lang(32017)+"  (wg Trakt)", "tvshows&url=trending", "featured.png", "DefaultAddonAudioDSP.png", )  # by trakt
            self.addDirectoryItem(control.lang(32018)+"  (wg TMDB)", "tvshows&url=tmdb_popular", "people-watching.png", "DefaultFavourites.png")
            self.addDirectoryItem((32026,"  (TMDB)"), "tvshows&url=tmdb_premiere", "new-tvshows.png", "DefaultRecentlyAddedEpisodes.png")
            self.addDirectoryItem((32024,"  (TMDB)"), "tvshows&url=tmbd_airing", "airing-today.png", "DefaultAddonPVRClient.png")
            self.addDirectoryItem("Najwyżej oceniane  (wg TMDB)", "tvshows&url=tmdb_top_rated", "highly-rated.png", "DefaultMusicTop100.png")
            self.addDirectoryItem(32011, "tvGenres", "genres.png", "DefaultGenre.png")
            self.addDirectoryItem(32016, "tvNetworks", "networks.png", "DefaultStudios.png")
            self.addDirectoryItem((32012," (lata)"), "tvYears", "years.png", "DefaultYear.png")
            self.addDirectoryItem(32014, "tvLanguages", "languages.png", "DefaultCountry.png")
            self.addDirectoryItem("Kategorie wiekowe", "tvCertificates", "certificates.png", "DefaultUser.png")
            self.addDirectoryItem("Własny miks kryteriów", "customTvCriteria", "search_tvshows.png", "DefaultAddonContextItem.png")

            if not tmdbCredentials:
                self.addDirectoryItem("Ocenione seriale (podczas sesji gościa)", "tvshows&url=tmdbguestrated", "tmdb.png", "DefaultFavourites.png",
                    refresh=True,
                    queue=True,
                    # context=(32551, "tvshowsToLibrary&url=tmdbguestrated"),
                    )

                self.addDirectoryItem("Ocenione odcinki (podczas sesji gościa)", "calendar&url=tmdbguestratedepisodes", "tmdb.png", "DefaultFavourites.png",
                    refresh=True,
                    queue=True,
                    # context=(32551, "tvshowsToLibrary&url=tmdbguestratedepisodes"),  # lepiej tego nie włączać dla tej pozycji (bo nawet nie sprawdzałem)
                    )

            # control.pluginCategory(syshandle, "Seriale")
            self.endDirectory(category=["", "Seriale"])



        def mytvshows(self, lite=False):
            self.accountCheck()
            PluginName = control.infoLabel("Container.PluginName")
            # PluginName = PluginName == "plugin.video.kadrplus"  # nie wiem, czy to potrzebne
            if traktCredentials == True:

                self.addDirectoryItem(32032, "tvshows&url=traktcollection", "trakt.png", "DefaultVCD.png", refresh=True,
                    context=(32551, "tvshowsToLibrary&url=traktcollection"), )

                self.addDirectoryItem(32033, "tvshows&url=traktwatchlist", "trakt.png", "DefaultFavourites.png", refresh=True,
                    context=(32551, "tvshowsToLibrary&url=traktwatchlist"), )

                self.addDirectoryItem("Ulubione", "tvshows&url=traktfavorites", "trakt.png", "DefaultFavourites.png", refresh=True,
                    context=(32551, "tvshowsToLibrary&url=traktfavorites"), )

                self.addDirectoryItem(32035, "tvshows&url=traktfeatured", "trakt.png", "DefaultAddonAudioDecoder.png")  # Proponowane

                self.addDirectoryItem(32036,   "calendar&url=trakthistory", "trakt.png", "DefaultYear.png",
                   # context=("Odśwież teraz", "calendar&url=trakthistory&refresh=1", "Container.Update"), )
                   refresh=True, ) # jak coś, to teraz tak można

                self.addDirectoryItem(32037, "calendar&url=progress", "trakt.png", "DefaultInProgressShows.png",
                   context=("Odśwież teraz", "calendar&url=progress&refresh=1", "Container.Update" if PluginName else "ActivateWindow"), queue=True, )  # Postęp

                self.addDirectoryItem(32038, "calendar&url=mycalendar", "trakt.png", "DefaultRecentlyAddedEpisodes.png", queue=True, )  # odcinki (tu chyba pojawiają się nowe odcinki oglądanego serialu) 


            if tmdbCredentials:
                self.addDirectoryItem("Ulubione TMDB", "tvshows&url=tmdbuserfavourite", "tmdb.png", "DefaultFavourites.png",
                    refresh=True, queue=True, context=(32551, "tvshowsToLibrary&url=tmdbuserfavourite"), )

                self.addDirectoryItem("Obserwowane TMDB", "tvshows&url=tmdbuserwatchlist", "tmdb.png", "DefaultFavourites.png",
                    refresh=True, queue=True, context=(32551, "tvshowsToLibrary&url=tmdbuserwatchlist"), )

                if control.setting('tmdb.account_id'):
                    self.addDirectoryItem("Rekomendowane TMDB", "tvshows&url=tmdbrecommended", "tmdb.png", "DefaultFavourites.png",
                        refresh=True,
                        queue=True,
                        context=(32551, "tvshowsToLibrary&url=tmdbrecommended"),
                        )

                self.addDirectoryItem("Ocenione seriale (w TMDB)", "tvshows&url=tmdbuserrated", "tmdb.png", "DefaultFavourites.png",
                    refresh=True, queue=True, context=(32551, "tvshowsToLibrary&url=tmdbuserrated"), )


            if imdbCredentials:
                self.addDirectoryItem("Obserwowane IMDb", "tvshows&url=imdbwatchlist", "imdb.png", "DefaultFavourites.png",
                    refresh=True, queue=True, context=(32551, "tvshowsToLibrary&url=imdbwatchlist"), )


            self.addDirectoryItem(32040, "tvUserlists", "userlists.png", "DefaultVideoPlaylists.png", refresh=True,)  # Listy seriali

            if traktCredentials:
                self.addDirectoryItem(32041, "episodeUserlists", "userlists.png", "DefaultVideoPlaylists.png")  # Listy odcinków

            if tmdbCredentials:
                self.addDirectoryItem("Ocenione odcinki (w TMDB)", "calendar&url=tmdbuserratedepisodes", "tmdb.png", "DefaultFavourites.png",
                    refresh=True, queue=True, 
                    # context=(32551, "tvshowsToLibrary&url=tmdbuserratedepisodes"),  # lepiej tego nie włączać dla tej pozycji (bo nawet nie sprawdzałem)
                    )


            # control.content(syshandle, "addons")  # pomaga w kategoriach dla domyślnej skórki
            self.endDirectory()



        def tools(self): #WIELKIE PORZĄDKI - wywalenie skrótów do ustawień, zostawienie biblioteki i konserwacji
            self.addDirectoryItem(32043, "openSettings", "", "DefaultAddonService.png", isFolder=False)
            self.addDirectoryItem(32556, "libraryNavigator", "", "DefaultAddonLibrary.png")  # isFolder=True (domyślne ustawienie)
            self.addDirectoryItem(32049, "viewsNavigator", "", "DefaultAddonLookAndFeel.png")
            self.addDirectoryItem("[B]FanFilm[/B]: Cache", "cacheNavigator", "", "DefaultHardDisk.png")
            self.addDirectoryItem(32073, "authTrakt", "trakt.png", "DefaultAddonProgram.png", isFolder=False)
            self.addDirectoryItem("[B]TMDB[/B]: Autoryzacja", "tmdbauthorize", "tmdb.png", "DefaultAddonProgram.png", isFolder=False)
            # control.pluginCategory(syshandle, "FanFilm / Narzędzia")
            self.endDirectory(category=["", "Narzędzia"])



        def cache(self):
            self.addDirectoryItem(32604, "clearCacheSearch", "", "DefaultIconWarning.png", isFolder=False)
            self.addDirectoryItem(32050, "clearSources", "", "DefaultIconWarning.png", isFolder=False)
            self.addDirectoryItem("[B]FanFilm[/B]: Wyczyść cache seriali", "clearLibCache", "", "DefaultIconWarning.png", isFolder=False)
            self.addDirectoryItem(32052, "clearCache", "", "DefaultIconWarning.png", isFolder=False)
            # control.pluginCategory(syshandle, "FanFilm / Narzędzia / Cache")
            self.endDirectory(category=["", "Narzędzia", "Cache"])



        def library(self):
            self.addDirectoryItem(32559, control.setting("library.movie"), "movies.png",  "DefaultMovies.png",  isAction=False, )
            self.addDirectoryItem(32560, control.setting("library.tv"),    "tvshows.png", "DefaultTVShows.png", isAction=False, )

            self.addDirectoryItem("[B]FanFilm[/B]: Zaktualizuj Bibliotekę seriali o nowe odcinki",
                                  "updateLibrary",
                                  "library_update.png",
                                  "DefaultAddonsUpdates.png",
                                  context=("Uaktualnij libcache", "updateLibrary&query=update_libcache"),
                                  isFolder=True)

            PluginName = control.infoLabel('Container.PluginName')  # tu można pomyśleć (jak pusty, lub nie 'plugin.video.kadrplus', to oznacza, że wywoływane z innego pluginu)
            fflog(f"{PluginName=}", 1, 1)
            setIsFolder = PluginName != "plugin.video.kadrplus"
            fflog(f"{setIsFolder=}", 1, 1)

            if trakt.getTraktCredentialsInfo():
                self.addDirectoryItem(32561, "moviesToLibrary&url=traktcollection",  "trakt.png", "DefaultMovies.png",  isFolder=setIsFolder, )
                self.addDirectoryItem(32562, "moviesToLibrary&url=traktwatchlist",   "trakt.png", "DefaultMovies.png",  isFolder=setIsFolder, )
                self.addDirectoryItem(32563, "tvshowsToLibrary&url=traktcollection", "trakt.png", "DefaultTVShows.png", isFolder=setIsFolder, )
                self.addDirectoryItem(32564, "tvshowsToLibrary&url=traktwatchlist",  "trakt.png", "DefaultTVShows.png", isFolder=setIsFolder, )

            if tmdbCredentials:
                self.addDirectoryItem("[B]TMDB[/B]: Importuj obserwowane filmy",   "moviesToLibrary&url=tmdbuserwatchlist",  "tmdb.png", "DefaultMovies.png",  isFolder=setIsFolder, )
                self.addDirectoryItem("[B]TMDB[/B]: Importuj ulubione filmy",      "moviesToLibrary&url=tmdbuserfavourite",  "tmdb.png", "DefaultMovies.png",  isFolder=setIsFolder, )
                self.addDirectoryItem("[B]TMDB[/B]: Importuj obserwowane seriale", "tvshowsToLibrary&url=tmdbuserwatchlist", "tmdb.png", "DefaultTVShows.png", isFolder=setIsFolder, )
                self.addDirectoryItem("[B]TMDB[/B]: Importuj ulubione seriale",    "tvshowsToLibrary&url=tmdbuserfavourite", "tmdb.png", "DefaultTVShows.png", isFolder=setIsFolder, )

            if imdbCredentials:
                self.addDirectoryItem("[B]IMDb[/B]: Importuj obserwowane filmy",   "moviesToLibrary&url=imdbwatchlist",  "imdb.png", "DefaultMovies.png",  isFolder=setIsFolder, )
                self.addDirectoryItem("[B]IMDb[/B]: Importuj obserwowane seriale", "tvshowsToLibrary&url=imdbwatchlist", "imdb.png", "DefaultTVShows.png", isFolder=setIsFolder, )

            # control.pluginCategory(syshandle, "FanFilm / Narzędzia / Biblioteka")
            self.endDirectory(category=["", "Narzędzia", "Biblioteka"])



        def downloads(self):
            movie_downloads = control.setting("movie.download.path")
            tv_downloads = control.setting("tv.download.path")

            zawartosc_folderu_filmow = control.listDir(movie_downloads)
            # fflog(f'{zawartosc_folderu_filmow=}',1,1)
            if len(zawartosc_folderu_filmow[0]) > 0 or len(zawartosc_folderu_filmow[1]) > 0:
                self.addDirectoryItem(32001, movie_downloads, "movies.png", "DefaultMovies.png", isAction=False, )

            if ( len(control.listDir(tv_downloads)[0]) > 0  # seriale zawsze są (albo powinny być) w folderach
              or len(control.listDir(tv_downloads)[1]) > 0  # test
            ):
                self.addDirectoryItem(32002, tv_downloads, "tvshows.png", "DefaultTVShows.png", isAction=False)

            self.addDirectoryItem("Menadżer pobierania", "downloadManager", "", "DefaultNetwork.png", )

            # control.pluginCategory(syshandle, "FanFilm / Pobrane")

            self.endDirectory(category=["", "Pobrane"])



        def search(self): #DODANIE ALL
            self.addDirectoryItem(32001, "movieSearch", "movies.png", "DefaultMovies.png")

            self.addDirectoryItem(32002, "tvSearch", "tvshows.png", "DefaultTVShows.png")
            """
            yatse = control.setting("yatse") == "true"
            if not yatse:
                self.addDirectoryItem("Aktorzy", "searchActor", "people-search.png", "people-search.png", isFolder=False)
            else:
                self.addDirectoryItem(32029, "moviePerson", "people-search.png", "DefaultMovies.png")
                self.addDirectoryItem(32030, "tvPerson", "people-search.png", "DefaultTVShows.png")

            # self.addDirectoryItem("Osoby", "searchPerson&department=all&media_type=ask", "people-search.png", "people-search.png")
            self.addDirectoryItem("Osoby", "searchPerson", "people-search.png", "people-search.png")
            """
            self.addDirectoryItem("Filmy i seriale", "multiSearch", "channels.png", "DefaultAddonsSearch.png")

            self.addDirectoryItem("Kolekcje", "collectionSearch", "collection.png", "DefaultSets.png")

            self.addDirectoryItem("Osoby", "personSearch", "people-search.png", "DefaultActor.png")
            
            self.addDirectoryItem("Listy Trakt", "traktListsSearch", "search.png", "")

            # control.pluginCategory(syshandle, "FanFilm / Wyszukiwanie")

            self.endDirectory(category=["", "Wyszukiwanie"])



        def views(self):
            try:            
                items = [
                         (control.lang(32001), "movies"),
                         (control.lang(32002), "tvshows"),
                         (control.lang(32054), "seasons"),
                         (control.lang(32038), "episodes"),
                         (control.lang(32345), "files"),
                         ("Katalogi menu", "addons"),
                        ]

                select = control.selectDialog([i[0] for i in items], control.lang(32049))

                if select == -1:
                    control.directory(syshandle, cacheToDisc=False)
                    control.sleep0(100)
                    control.execute('Action(Back)')
                    return False

                content = items[select][1]

                title = control.lang(32059)  # KLIKNIJ TUTAJ ABY ZAPISAĆ WIDOK
                url = "{}?action=addView&content={}".format(sysaddon, content)

                poster, banner, fanart = control.addonPoster(), control.addonBanner(), control.addonFanart()

                item = control.item(label=title)

                item.setInfo(type="Video", infoLabels={"title": title})
                item.setArt({"icon": poster, "thumb": poster, "poster": poster, "banner": banner})
                item.setProperty("Fanart_Image", fanart)

                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
                control.content(syshandle, content)
                control.directory(syshandle, cacheToDisc=True)

                from ptw.libraries import views
                views.setView(content, {})
            except Exception:
                fflog_exc(1)
                return



        def accountCheck(self):
            if (traktCredentials == False and imdbCredentials == False and tmdbCredentials == False):
                control.infoDialog(control.lang(32042), sound=True, icon="WARNING")
                sys.exit()



        def infoCheck(self, version):
            """ nie wiem, do czego to służy """
            try:
                control.infoDialog("", control.lang(32074), time=5000, sound=False)  # POMOC
                return "1"
            except Exception:
                # fflog_exc(1)
                return "1"



        def clearLibCache(self):
            yes = control.yesnoDialog(control.lang(32056))
            if not yes:
                return
            from ptw.libraries import libtools
            libtools.lib_tools.lib_cache_clear()
            control.infoDialog(control.lang(32057), sound=True, icon="INFO")



        def clearCache(self):
            yes = control.yesnoDialog(control.lang(32056))
            if not yes:
                return
            from ptw.libraries import cache
            cache.cache_clear()
            control.infoDialog(control.lang(32057), sound=True, icon="INFO")



        def clearCacheMeta(self):
            yes = control.yesnoDialog(control.lang(32056))
            if not yes:
                return
            from ptw.libraries import cache
            cache.cache_clear_meta()
            control.infoDialog(control.lang(32057), sound=True, icon="INFO")



        def clearCacheProviders(self):
            yes = control.yesnoDialog(control.lang(32056))
            if not yes:
                return
            from ptw.libraries import cache
            cache.cache_clear_providers()
            control.infoDialog(control.lang(32057), sound=True, icon="INFO")



        def clearCacheSearch(self, content=None):
            yes = control.yesnoDialog(control.lang(32056))
            if not yes:
                return False
            from ptw.libraries import cache
            ok = cache.cache_clear_search(content)
            if ok:
                control.infoDialog(control.lang(32057), sound=True, icon="INFO")
            else:
                control.infoDialog('Wystąpił jakiś błąd', sound=True, icon="ERROR")
                pass



        def removeFromSearchHistory(self, term, content=None):
            yes = control.yesnoDialog(f'Czy chcesz usunąć z historii wyszukiwania element [CR][B]{term}[/B] ? ')
            if not yes:
                return False
            from ptw.libraries import cache
            ok = cache.cache_clear_search_by_term(term, content)
            if ok:
                control.infoDialog(control.lang(32057), sound=True, icon="INFO")
            else:
                control.infoDialog('Wystąpił jakiś błąd', sound=True, icon="ERROR")
                pass



        def clearCacheAll(self):
            yes = control.yesnoDialog(control.lang(32056))
            if not yes:
                return
            from ptw.libraries import cache
            cache.cache_clear_all()
            control.infoDialog(control.lang(32057), sound=True, icon="INFO")



        def clearCacheAllSilent(self):
            from ptw.libraries import cache
            cache.cache_clear_all()



        def addDirectoryItem(self, name, query, thumb, icon="", context=None, refresh=False, queue=False, isAction=True, isFolder=True, name_to_url=False, meta=None, counter=None, ret=False):
            if isinstance(name, tuple):
                name, name2 = name
            else:
                name2 = ""
            try:
                #name = control.lang(name)
                name = control.lang(name)
            except:
                pass

            url = "{}?action={}".format(sysaddon, query) if isAction == True else query

            # if name_to_url and not "&item=" in url:
            if "&url=" in url and not "&item=" in url:  # automat
                from urllib.parse import quote_plus
                url += "&item=" + quote_plus(name)
                # fflog(f'{url=}',1,1)

            if "http" not in thumb:
                thumb = os.path.join(artPath, thumb) if thumb and artPath is not None else icon

            cm = []

            if refresh:
                # w init do robię
                # PluginName = control.infoLabel("Container.PluginName")
                # PluginName = PluginName == "plugin.video.kadrplus"  # nie wiem, czy to potrzebne
                if PluginName:
                    cm.append(("Odśwież teraz", "Container.Update(%s&refresh=1)" % url))
                else:
                    cm.append(("Odśwież teraz", "ActivateWindow(10025,%s&refresh=1,return)" % url))

            if context is not None:
                if not isinstance(context, list):  # ale trzeba mieć pewność, że nigdzie w innych plikach nie jest używana lista, tylko krotka (jeśli odwołują się do tej metody)
                    context0 = [context]
                else:
                    context0 = context
                for context in context0:
                    label = control.lang(context[0]) if isinstance(context[0], int) else context[0]
                    if "(" in context[1]:
                        cm.append((label, context[1]))
                    else:
                        funct = ("RunPlugin"
                                 if not (len(context)==3 and context[2])
                                 else ("Container.Update" if PluginName else "ActivateWindow")
                                    if isinstance(context[2], (bool, int)) or context[2]=="showdir"  # "showdir", czyli wyświetlaj katalog chyba (Container.Update)
                                    else context[2]
                                )
                        if funct == "ActivateWindow":
                            cm.append((label, "ActivateWindow(10025,{}?action={},return)".format(sysaddon, context[1]),))
                        else:
                            cm.append((label, "{}({}?action={})".format(funct, sysaddon, context[1]),))

            if queue:
                cm.append((queueMenu, "RunPlugin(%s?action=queueItem)" % sysaddon))

            item = control.item(label=name+name2)

            item.addContextMenuItems(cm)

            item.setArt({"icon": icon, "thumb": thumb})
            if addonFanart is not None:
                item.setProperty("Fanart_Image", addonFanart)

            if meta:
                # fflog(f'{meta=}',1,1)
                if "datetime" in meta:
                    try:  # bo to od Kodi v20
                        item.setDateTime(meta["datetime"])
                        meta.pop("datetime")
                    except Exception:
                        pass
                # item.setInfo(type="Video", infoLabels=meta)
                item.setInfo(type="Video", infoLabels=control.metadataClean(meta))
                item.setArt({"poster": thumb})

            if counter:
                # fflog(f'{counter=}',1,1)
                item.setInfo(type="Video", infoLabels={'count': counter})  # do sortowania

            if not ret:
                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
            else:
                return (url, item, isFolder,)


        def addDirectoryItems(self, list_of_items):
            control.addItems(syshandle, list_of_items)  # dodanie zbiorcze


        def endDirectory(self, cacheToDisc=True, succeeded=True, updateListing=False, category=""):
            default_category = "FanFilm"
            if category:
                if isinstance(category, list):
                    if category[0] == "":
                        category[0] = default_category
                    # fflog(f'plugin {category=}',1,1)
                    category = " / ".join(category).strip(" /")
                control.pluginCategory(syshandle, category)
            else:
                # control.pluginCategory(syshandle, default_category)
                pass
            # control.content(syshandle, "addons")  # to chyba nie jest do końca prawidłowe (na niektórych skórkach może co prawda pokazywać dodatkowe ikonki, ale to zależy od skórki)
            control.directory(syshandle, cacheToDisc=cacheToDisc, succeeded=succeeded, updateListing=updateListing)
            # views.setView("addons")  # dodatkowa funkcja FanFilm  NIE WIEM, CZY TU WARTO


    return navigator()