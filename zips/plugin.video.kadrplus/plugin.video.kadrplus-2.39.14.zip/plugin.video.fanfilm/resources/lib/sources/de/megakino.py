# -*- coding: UTF-8 -*-
"""
    Scraper dla MegaKino1.watch
    
    Cloudflare blokuje GET /films/ i /serials/ dla requests.
    Obejście: POST /engine/ajax/controller.php z mod=showfull&id=NEWS_ID
    lub POST /index.php?do=cat z newsid — DLE wewnętrzne endpointy
    które nie przechodzą przez CF routing.
    
    ID tytułu pobieramy z wyników wyszukiwania POST /index.php (działa).
"""
import re
from urllib.parse import urlencode

from ptw.libraries import control, source_utils, cleantitle
from ptw.debug import fflog, fflog_exc


class source:
    def __init__(self):
        self.priority  = 1
        self.language  = ['de']
        self.base_link = 'https://megakino3.org'
        self.headers   = {
            'User-Agent':    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0',
            'Accept':        'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'de-DE,de;q=0.9,en;q=0.3',
        }
        self.session   = None
        self._cache    = {}

    # ------------------------------------------------------------------

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        fflog(f'[megakino] film: {title=}  {year=}  {imdb=}', 1)
        year_alt = kwargs.get('year_alt')
        if year_alt: year = (year, year_alt)
        url = self._search(title, localtitle, aliases, year, 'film')
        fflog(f'[megakino] film url: {url}', 1)
        return url

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        fflog(f'[megakino] serial: {tvshowtitle=}  {year=}', 1)
        year_alt = kwargs.get('year_alt')
        if year_alt: year = (year, year_alt)
        url = self._search(tvshowtitle, localtvshowtitle, aliases, year, 'serial')
        fflog(f'[megakino] serial url: {url}', 1)
        return url

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        fflog(f'[megakino] episode {url=}  {season=}  {episode=}', 1)
        if not url: return None
        return f'{url}#S{season}E{episode}'

    def sources(self, url, hostDict, hostprDict):
        result = []
        fflog(f'[megakino] sources {url=}', 1)
        if not url: return result
        try:
            self._init_session()
            season = episode = None
            m = re.search(r'#S(\d+)E(\d+)$', url)
            if m:
                season  = int(m.group(1))
                episode = int(m.group(2))
                url     = url[:m.start()]

            # ID z URL: /serials/5969-slug.html -> 5969
            id_m = re.search(r'/(?:films|serials)/(\d+)-', url)
            if not id_m:
                fflog(f'[megakino] nie mozna wyciagnac ID z {url}', 1)
                return result
            news_id = id_m.group(1)
            fflog(f'[megakino] news_id={news_id}  season={season}  episode={episode}', 1)

            html = self._fetch_by_id(news_id, url)
            if not html:
                return result

            fflog(f'[megakino] html len={len(html)}', 1)
            links = self._extract_links(html, season, episode)
            fflog(f'[megakino] linków: {len(links)}', 1)

            for item in links:
                link = item.get('url', '')
                if not link: continue
                valid, hoster = source_utils.is_host_valid(link, hostDict)
                if not valid:
                    valid, hoster = source_utils.is_host_valid(link, hostprDict)
                if not valid:
                    from urllib.parse import urlsplit
                    hoster = urlsplit(link).hostname or link
                result.append({
                    'source': hoster, 'quality': item.get('quality', 'HD'),
                    'language': 'de', 'url': link,
                    'info': item.get('info', ''), 'direct': False, 'debridonly': False,
                })
        except Exception:
            fflog_exc(1)
        fflog(f'[megakino] zwracam {len(result)} zrodel', 1)
        return result

    def resolve(self, url):
        return url

    # ------------------------------------------------------------------

    def _fetch_by_id(self, news_id, original_url):
        """
        Próbuje pobrać HTML strony tytułu kilkoma metodami — od najmniej
        do najbardziej kosztownej. Cloudflare chroni GET /films/ i /serials/
        ale DLE ma endpointy AJAX które mogą nie być objęte CF.
        """
        # Metoda 1: DLE controller AJAX showfull
        html = self._try_ajax_showfull(news_id)
        if html and len(html) > 1000 and self._has_content(html):
            fflog('[megakino] metoda 1 (ajax showfull) OK', 1)
            return html

        # Metoda 2: GET bezpośredni z pełnymi nagłówkami przeglądarki
        html = self._try_direct_get(original_url)
        if html and len(html) > 1000 and self._has_content(html):
            fflog('[megakino] metoda 2 (direct GET) OK', 1)
            return html

        # Metoda 3: GET przez /index.php?newsid=ID (DLE shortlink)
        html = self._try_newsid(news_id)
        if html and len(html) > 1000 and self._has_content(html):
            fflog('[megakino] metoda 3 (newsid) OK', 1)
            return html

        fflog(f'[megakino] wszystkie metody zawiodly dla id={news_id}', 1)
        return None

    def _has_content(self, html):
        """Sprawdza czy HTML zawiera linki do hostów"""
        if 'mr-select' in html:
            return True
        # Filmy: iframe z data-src lub src do zewnętrznego hostera
        if re.search(r'<iframe[^>]+(?:data-src|src)=["\']https?://', html, re.I):
            return True
        return False

    def _try_ajax_showfull(self, news_id):
        """POST /engine/ajax/controller.php?mod=showfull — DLE internal"""
        try:
            url = self.base_link + '/engine/ajax/controller.php'
            data = urlencode({'mod': 'showfull', 'id': news_id})
            headers = dict(self.headers)
            headers['Content-Type'] = 'application/x-www-form-urlencoded'
            headers['X-Requested-With'] = 'XMLHttpRequest'
            headers['Referer'] = self.base_link + '/'
            fflog(f'[megakino] ajax showfull id={news_id}', 1)
            r = self.session.post(url, data=data, headers=headers, timeout=(10, 20))
            fflog(f'[megakino] ajax showfull status={r.status_code} len={len(r.text)}', 1)
            if r.status_code == 200:
                return r.text
        except Exception:
            fflog_exc(1)
        return None

    def _try_direct_get(self, url):
        """GET z krokiem weryfikacji yg_token (jak fetch w JS)"""
        cache_key = f'get:{url}'
        if cache_key in self._cache:
            return self._cache[cache_key]
        try:
            headers = dict(self.headers)
            headers['Referer'] = self.base_link + '/'
            # Krok 1: weryfikacja - jak JS fetch("/index.php?yg=token", {credentials:"include"})
            # fetch używa XHR headers, nie nawigacyjnych
            verify_headers = dict(self.headers)
            verify_headers['Referer'] = url  # Referer = strona którą chcemy otworzyć
            verify_headers['X-Requested-With'] = 'XMLHttpRequest'
            fflog('[megakino] yg token verify', 1)
            rv = self.session.get(self.base_link + '/index.php?yg=token',
                                  headers=verify_headers, timeout=(10, 15))
            fflog(f'[megakino] yg verify status={rv.status_code}', 1)
            # Pobierz nowy yg_token z odpowiedzi jeśli serwer go odświeżył
            new_yg = rv.cookies.get('yg_token')
            if new_yg:
                self.session.cookies.set('yg_token', new_yg, domain='.megakino3.org')
                fflog(f'[megakino] nowy yg_token z verify: {new_yg[:20]}...', 1)
            # Krok 2: GET strony tytułu z Referer = strona główna
            fflog(f'[megakino] direct GET {url}', 1)
            r = self.session.get(url, headers=headers, timeout=(15, 30))
            fflog(f'[megakino] direct GET status={r.status_code} len={len(r.text)}', 1)
            if len(r.text) < 500:
                fflog(f'[megakino] body: {repr(r.text[:300])}', 1)
            self._cache[cache_key] = r.text
            return r.text
        except Exception:
            fflog_exc(1)
        return None

    def _try_newsid(self, news_id):
        """GET /index.php?newsid=ID — DLE shortlink redirect"""
        try:
            url = f'{self.base_link}/index.php?newsid={news_id}'
            headers = dict(self.headers)
            headers['Referer'] = self.base_link + '/'
            fflog(f'[megakino] newsid GET {url}', 1)
            r = self.session.get(url, headers=headers, timeout=(15, 30),
                                 allow_redirects=True)
            fflog(f'[megakino] newsid status={r.status_code} len={len(r.text)} final={r.url}', 1)
            if r.status_code == 200:
                return r.text
        except Exception:
            fflog_exc(1)
        return None

    # ------------------------------------------------------------------

    def _search(self, title, localtitle, aliases, year, content):
        try:
            self._init_session()
            year_int = year_alt_int = None
            if isinstance(year, (tuple, list)):
                try: year_int     = int(year[0])
                except: pass
                try: year_alt_int = int(year[1])
                except: pass
            else:
                try: year_int = int(year)
                except: pass

            # DE aliasy priorityzujemy (megakino = strona niemiecka)
            de_aliases, other_aliases = [], []
            if aliases:
                try:
                    import json
                    if isinstance(aliases, str): aliases = json.loads(aliases)
                    raw = list(aliases.values()) if isinstance(aliases, dict) else list(aliases)
                    for a in raw:
                        t_str = country = ''
                        if isinstance(a, str):
                            t_str = a
                        elif isinstance(a, dict):
                            t_str = a.get('title') or a.get('name') or ''
                            country = a.get('country', '')
                        if not t_str or t_str.lower() == title.lower():
                            continue
                        if country in ('de', 'at', 'ch'):
                            de_aliases.append(t_str)
                        else:
                            other_aliases.append(t_str)
                except Exception: pass
            # Megakino = serwis DE: szukamy tylko po tytule EN + aliasach DE
            # other_aliases (IT, FR, ES itp.) celowo pomijamy — powodują fałszywe trafienia
            titles = [title] + de_aliases
            if localtitle and localtitle.lower() != title.lower() and localtitle not in titles:
                titles.insert(1, localtitle)

            for t in titles[:5]:
                html = self._post_search(t)
                if not html: continue
                results = self._parse_results(html, content)
                fflog(f'[megakino] wynikow ({content}): {len(results)} dla {t!r}', 1)
                if not results: continue
                match = self._best_match(results, t, year_int, year_alt_int)
                if match: return match
        except Exception:
            fflog_exc(1)
        return None

    def _post_search(self, title):
        ck = f'search:{title}'
        if ck in self._cache: return self._cache[ck]
        try:
            from urllib.parse import quote
            h = dict(self.headers)
            h['Content-Type'] = 'application/x-www-form-urlencoded'
            h['Referer']      = self.base_link + '/'
            title_norm = title.lower().split()[0] if title else ''
            # Dla tytułów wielowyrazowych sprawdzaj co najmniej 2 pierwsze słowa,
            # żeby uniknąć fałszywych trafień (np. "one" jest na każdej stronie)
            title_words = title.lower().split()
            title_check = ' '.join(title_words[:2]) if len(title_words) > 1 else title_norm

            def _contains(text):
                t = text.lower()
                return title_check in t or (title_norm and title_norm in t and len(title_norm) > 5)

            # Próba 1: DLE AJAX search controller (JSON response)
            ajax_url = self.base_link + '/engine/ajax/controller.php?mod=search'
            ajax_data = urlencode({'story': title, 'startshownews': 0})
            try:
                r1 = self.session.post(ajax_url, data=ajax_data, headers=h, timeout=(10, 25))
                fflog(f'[megakino] AJAX search {title!r} status={r1.status_code} len={len(r1.text)}', 1)
                if r1.status_code < 400 and _contains(r1.text):
                    self._cache[ck] = r1.text
                    return r1.text
            except Exception: pass

            # Próba 2: POST DLE klasyczny
            r = self.session.post(
                self.base_link + '/index.php',
                data=urlencode({'do': 'search', 'subaction': 'search', 'story': title}),
                headers=h, timeout=(10, 30)
            )
            fflog(f'[megakino] POST search {title!r} status={r.status_code} len={len(r.text)}', 1)
            if r.status_code < 400 and _contains(r.text):
                self._cache[ck] = r.text
                return r.text

            # Próba 3: GET warianty
            for param in ['?s=', '/?q=', '/search/?q=']:
                get_url = self.base_link + param + quote(title)
                r2 = self.session.get(get_url, headers=h, timeout=(10, 30))
                fflog(f'[megakino] GET search {get_url!r} status={r2.status_code} len={len(r2.text)}', 1)
                if r2.status_code < 400 and _contains(r2.text):
                    self._cache[ck] = r2.text
                    return r2.text

            # Próba 4: DLE search z from_page
            for page in ['0', '1']:
                fp_url = (self.base_link + '/index.php?do=search&subaction=search'
                          + '&from_page=' + page + '&story=' + quote(title))
                r3 = self.session.get(fp_url, headers=h, timeout=(10, 25))
                fflog(f'[megakino] GET from_page search {title!r} p={page} status={r3.status_code}', 1)
                if r3.status_code < 400 and _contains(r3.text):
                    self._cache[ck] = r3.text
                    return r3.text

            result = r.text if r.status_code < 400 else None
            self._cache[ck] = result
            return result
        except Exception:
            fflog_exc(1)
            return None

    def _parse_results(self, html, content):
        results = []
        seen    = set()
        pat = re.compile(
            r'href=["\'](?:' + re.escape(self.base_link) + r')?'
            r'(/' + ('films' if content == 'film' else 'serials') + r'/(\d+)-([^"\']+?)\.html)["\']',
            re.I
        )
        for m in pat.finditer(html):
            path, nid, slug = m.group(1), m.group(2), m.group(3)
            if path in seen: continue
            seen.add(path)
            year_m = re.search(r'\b(19|20)\d{2}\b', slug)
            year   = int(year_m.group()) if year_m else None
            # szukaj alt="" obok linku
            surroundings = html[max(0,m.start()-200):m.end()+200]
            alt_m = re.search(r'alt=["\']([^"\']{3,})["\']', surroundings)
            title = alt_m.group(1) if alt_m else slug.replace('-', ' ')
            results.append({'url': self.base_link+path, 'id': nid, 'title': title, 'year': year})
            fflog(f'[megakino]   wynik: {title!r} ({year}) id={nid}', 1)
        return results

    def _best_match(self, results, search_title, year, year_alt):
        if not results: return None
        sn = cleantitle.normalize(cleantitle.getsearch(search_title))
        scored = []
        for r in results:
            t = cleantitle.normalize(cleantitle.getsearch(r['title']))
            if not t: continue
            ts = 3 if sn==t else (2 if (sn in t or t in sn) else 0)
            if ts == 0:
                sw = set(sn.split()); st = set(t.split())
                # Wymaga co najmniej 2/3 slow dla tytułów wielowyrazowych
                min_words = max(2, len(sw) * 2 // 3) if len(sw) > 2 else max(1, len(sw)//2)
                ts = 1 if len(sw & st) >= min_words else 0
            if ts == 0: continue
            ry = r.get('year')
            yr = (2 if ry and year and ry in (year, year_alt)
                  else 1 if ry and year and abs(ry-year)<=1
                  else -2 if ry and year and abs(ry-year)>1 else 0)
            scored.append((ts+yr, r['url']))
            fflog(f'[megakino]   score={ts+yr} {r["title"]!r} ({ry})', 1)
        if not scored: return None  # żaden wynik nie pasuje tytułem — nie zwracaj losowego
        best_score = max(s for s, u in scored)
        # Nie akceptuj slabych dopasowań — wymagaj przynajmniej score>=2
        if best_score <= 1:
            return None
        return max(scored, key=lambda x: x[0])[1]

    def _extract_links(self, html, season=None, episode=None):
        links = []
        seen  = set()
        if season is not None and episode is not None:
            ep_id = self._find_ep_id(html, episode)
            fflog(f'[megakino] ep_id={ep_id} dla episode={episode}', 1)
            links = self._links_from_select(html, ep_id, seen) if ep_id else []
        else:
            # Seriale: <select class="mr-select">
            for m in re.finditer(
                r'<select[^>]+class=["\'][^"\']*mr-select[^"\']*["\'][^>]*>(.*?)</select>',
                html, re.S|re.I
            ):
                links += self._options_from_block(m.group(1), seen)
            if not links:
                # Filmy: <iframe data-src="https://..."> lub <iframe src="https://...">
                for m in re.finditer(
                    r'<iframe[^>]+(?:data-src|src)=["\'](\s*https?://[^"\']+)["\']',
                    html, re.I
                ):
                    url = m.group(1).strip()
                    # Pomiń YouTube (trailers) i same megakino
                    if 'youtube.com' in url or 'megakino' in url:
                        continue
                    if url in seen:
                        continue
                    seen.add(url)
                    # Wyciągnij nazwę hostera z domeny
                    host_m = re.search(r'https?://(?:www\.)?([^/]+)', url)
                    label = host_m.group(1).split('.')[0].capitalize() if host_m else 'Hoster'
                    links.append({'url': url, 'quality': self._quality(url), 'info': f'DE | {label}'})
                    fflog(f'[megakino]   iframe link: {label} {url[:60]}', 1)
        return links

    def _find_ep_id(self, html, episode):
        se = re.search(
            r'<select[^>]+class=["\'][^"\']*se-select[^"\']*["\'][^>]*>(.*?)</select>',
            html, re.S|re.I
        )
        if se:
            opts = re.findall(r'<option[^>]+value=["\']([^"\']+)["\'][^>]*>[^<]*[Ee]p(?:isode)?\s*(\d+)', se.group(1))
            for ep_id, ep_num in opts:
                if int(ep_num) == episode: return ep_id
            all_opts = re.findall(r'<option[^>]+value=["\']([^"\']+)["\']', se.group(1))
            if 0 < episode <= len(all_opts): return all_opts[episode-1]
        return f'ep{episode}'

    def _links_from_select(self, html, select_id, seen):
        m = re.search(
            rf'<select[^>]+id=["\']{re.escape(select_id)}["\'][^>]*>(.*?)</select>',
            html, re.S|re.I
        )
        return self._options_from_block(m.group(1), seen) if m else []

    def _options_from_block(self, block, seen):
        links = []
        for m in re.finditer(r'<option[^>]+value=["\']([^"\']+)["\'][^>]*>([^<]*)</option>', block, re.I):
            url, label = m.group(1).strip(), m.group(2).strip()
            if not url.startswith('http') or url in seen: continue
            seen.add(url)
            links.append({'url': url, 'quality': self._quality(label+url), 'info': f'DE | {label}'})
            fflog(f'[megakino]   link: {label} {url[:60]}', 1)
        return links

    def _quality(self, t):
        t = t.lower()
        if '4k' in t or '2160' in t: return '4K'
        if '1080' in t: return '1080p'
        if '720' in t:  return '720p'
        return 'HD'

    def _init_session(self):
        if not self.session:
            import requests, urllib3
            urllib3.disable_warnings()
            self.session = requests.Session()
            self.session.verify = False
            self.session.headers.update(self.headers)
            try:
                # Krok 1: homepage — ustanowienie sesji
                r = self.session.get(self.base_link + '/', timeout=(10, 20))
                fflog(f'[megakino] homepage status={r.status_code}', 1)
                # Krok 2: pobranie yg_token
                token_headers = dict(self.headers)
                token_headers['Referer'] = self.base_link + '/'
                rt = self.session.get(
                    self.base_link + '/index.php?yg=token',
                    headers=token_headers, timeout=(10, 15)
                )
                fflog(f'[megakino] yg_token status={rt.status_code} cookies={list(self.session.cookies.keys())}', 1)
                # Krok 3: index.php — pełna inicjalizacja sesji
                self.session.get(self.base_link + '/index.php', timeout=(10, 20))
            except Exception:
                fflog_exc(1)
