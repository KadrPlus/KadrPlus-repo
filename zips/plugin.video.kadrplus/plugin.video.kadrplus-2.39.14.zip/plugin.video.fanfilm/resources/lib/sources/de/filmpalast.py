# -*- coding: UTF-8 -*-
"""
    Scraper dla filmpalast.to (serwis NIEMIECKI)
    Oparty na oryginalnej wtyczce plugin.video.filmpalast.ex v0.5.1
"""
import re
from urllib.parse import quote_plus, quote as url_quote

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from ptw.libraries import control, source_utils, cleantitle
from ptw.debug import fflog, fflog_exc


class source:
    def __init__(self):
        self.priority = 2
        self.language = ['de']

        self.base_link   = 'https://filmpalast.to'
        self.search_link = '/search/title/%s'

        self.headers = {
            'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0',
            'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'de-DE,de;q=0.9,en;q=0.3',
            'Referer':         'https://filmpalast.to/',
        }
        self.session = None
        self._cache  = {}

    # ------------------------------------------------------------------ #
    #  Metody wymagane przez FanFilm                                       #
    # ------------------------------------------------------------------ #

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        fflog(f'[filmpalast] {title=}  {year=}', 1)
        year_alt = kwargs.get('year_alt')
        if year_alt:
            year = (year, year_alt)
        return self._search(title, localtitle, aliases, year, 'movie')

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        fflog(f'[filmpalast] {tvshowtitle=}  {year=}', 1)
        year_alt = kwargs.get('year_alt')
        if year_alt:
            year = (year, year_alt)
        return self._search(tvshowtitle, localtvshowtitle, aliases, year, 'tvshow')

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        fflog(f'[filmpalast] {url=}  {season=}  {episode=}', 1)
        if not url:
            return None
        return self._get_episode_url(url, int(season), int(episode))

    def sources(self, url, hostDict, hostprDict):
        result = []
        fflog(f'[filmpalast] sources {url=}', 1)
        if not url:
            return result
        try:
            self._init_session()
            html = self._get(url)
            if not html:
                return result
            links = self._extract_sources(html)
            for item in links:
                link = item.get('url', '')
                if not link:
                    continue
                valid, hoster = source_utils.is_host_valid(link, hostDict)
                if not valid:
                    valid, hoster = source_utils.is_host_valid(link, hostprDict)
                if not valid:
                    # resolveurl nie zna hosta, ale przepuszczamy — filmpalast to zaufane źródło
                    from urllib.parse import urlsplit
                    hoster = urlsplit(link).hostname or link
                    valid = True
                if valid:
                    result.append({
                        'source':     hoster,
                        'quality':    item.get('quality', 'HD'),
                        'language':   'de',
                        'url':        link,
                        'info':       item.get('info', ''),
                        'direct':     False,
                        'debridonly': False,
                    })
                else:
                    fflog(f'[filmpalast] nierozpoznany host: {link}', 1)
        except Exception:
            fflog_exc(1)
        fflog(f'[filmpalast] zwracam {len(result)} zrodel')
        return result

    def resolve(self, url):
        return url

    # ------------------------------------------------------------------ #
    #  Wyszukiwanie                                                        #
    # ------------------------------------------------------------------ #

    def _search(self, title, localtitle, aliases, year, content_type):
        try:
            self._init_session()

            year_int = year_alt_int = None
            if isinstance(year, (tuple, list)):
                try: year_int     = int(year[0])
                except: pass
                try: year_alt_int = int(year[1])
                except: pass
            else:
                try: year_int = int(year)
                except: pass

            # DE aliasy priorityzujemy (filmpalast = strona niemiecka)
            de_aliases, other_aliases = [], []
            if aliases:
                try:
                    import json as _json
                    _al = aliases if not isinstance(aliases, str) else _json.loads(aliases)
                    if isinstance(_al, dict): _al = list(_al.values())
                    for a in _al:
                        t_str = country = ''
                        if isinstance(a, str):
                            t_str = a
                        elif isinstance(a, dict):
                            t_str = a.get('title') or a.get('name') or ''
                            country = a.get('country', '')
                        if not t_str or t_str.lower() == title.lower():
                            continue
                        if country in ('de', 'at', 'ch'):
                            de_aliases.append(t_str)
                        else:
                            other_aliases.append(t_str)
                except Exception: pass
            titles_to_try = [title] + de_aliases + other_aliases
            if localtitle and localtitle.lower() != title.lower() and localtitle not in titles_to_try:
                titles_to_try.insert(1, localtitle)
            # Max 5 prób żeby nie spowalniać
            titles_to_try = titles_to_try[:5]

            for search_title in titles_to_try:
                search_url = self.base_link + self.search_link % url_quote(search_title)
                fflog(f'[filmpalast] GET {search_url}', 1)

                html = self._get(search_url)
                if not html:
                    continue

                results = self._parse_search_results(html)
                fflog(f'[filmpalast] wynikow: {len(results)} dla "{search_title}"', 1)
                if not results:
                    continue

                match = self._find_best_match(results, search_title, year_int, year_alt_int, content_type)
                if match:
                    fflog(f'[filmpalast] dopasowano: {match}', 1)
                    return match

            fflog(f'[filmpalast] nie znaleziono: {title!r}')
            return None

        except Exception:
            fflog_exc(1)
            return None

    def _parse_search_results(self, html):
        """
        Pattern z oryginalnej wtyczki (movie_data):
          href="//filmpalast.to/stream/SLUG" title="TYTUL"
        """
        results = []
        seen_slugs = set()
        try:
            pattern = re.compile(
                r'href="(?:https?:)?//filmpalast\.to(/stream/([^"?#\s]+))"[^>]*title="([^"]*)"',
                re.IGNORECASE
            )

            for m in pattern.finditer(html):
                path  = m.group(1)
                slug  = m.group(2).strip().strip('/')
                title = m.group(3).strip()

                if not slug or slug in seen_slugs:
                    continue
                # Odrzuc slugi menu
                if slug in ('new', 'view', 'top', 'movies', 'serien'):
                    continue
                seen_slugs.add(slug)

                url = f'{self.base_link}{path}'

                                # Szukaj roku w tytule (np. "Mercy (2026)") - filmpalast często podaje rok w nawiasach
                year = None
                ym = re.search(r'\(((?:19|20)\d{2})\)', title)
                if ym:
                    year = int(ym.group(1))

                # Fallback: szukaj roku w slugu (np. "rampage-2018")
                if not year:
                    ym = re.search(r'-((?:19|20)\d{2})(?:-|$)', slug)
                    if ym:
                        year = int(ym.group(1))

                # Fallback: szukaj roku w okolicach linka
                if not year:
                    ctx = html[max(0, m.start() - 500):m.end() + 300]
                    ym = re.search(r'>Ver(?:&ouml;|ö)ffentlicht:\s*((?:19|20)\d{2})\b', ctx, re.IGNORECASE)
                    if not ym:
                        ym = re.search(r'(?:Jahr|Erscheinungsjahr|Veroeffentlicht)[:\s]*(?:<[^>]+>)*\s*((?:19|20)\d{2})', ctx, re.IGNORECASE)
                    if ym:
                        year = int(ym.group(1))

                results.append({'url': url, 'title': title, 'year': year, 'slug': slug})
                fflog(f'[filmpalast]   wynik: {title!r} ({year}) -> {slug}', 1)

        except Exception:
            fflog_exc(1)
        return results

    def _find_best_match(self, results, search_title, year, year_alt, content_type='movie'):
        if not results:
            return None

        search_norm = cleantitle.normalize(cleantitle.getsearch(search_title))
        ep_pattern  = re.compile(r'-s\d{1,2}e\d{1,2}$', re.IGNORECASE)

        scored = []
        for r in results:
            slug = r['slug']
            slug_is_episode = bool(ep_pattern.search(slug))
            slug_base  = ep_pattern.sub('', slug)
            slug_title = slug_base.replace('-', ' ')

            title_norm = cleantitle.normalize(cleantitle.getsearch(r.get('title') or slug_title))
            slug_norm  = cleantitle.normalize(cleantitle.getsearch(slug_title))

            best = 0
            for candidate in [title_norm, slug_norm]:
                if not candidate:
                    continue
                if search_norm == candidate:
                    s = 3
                elif search_norm in candidate or candidate in search_norm:
                    s = 2
                else:
                    sw = set(search_norm.split())
                    cw = set(candidate.split())
                    s  = 1 if len(sw & cw) >= max(1, len(sw) // 2) else 0
                best = max(best, s)

            if best == 0:
                continue

            yr = 0
            result_year = r.get('year')
            if result_year and year:
                if result_year in (year, year_alt):
                    yr = 2   # dobry rok — mocny bonus
                elif abs(result_year - year) <= 1:
                    yr = 1   # rok +-1 — słaby bonus
                else:
                    yr = -2  # zły rok — kara

            type_bonus = 0
            if content_type == 'tvshow':
                type_bonus = 10 if slug_is_episode else -2

            scored.append((best + yr + type_bonus, r['url'], slug))

        if not scored:
            return results[0]['url'] if len(results) == 1 else None

        scored.sort(key=lambda x: x[0], reverse=True)

        # Gdy rok nieznany lub wielu kandydatow z tym samym score - weryfikuj rok na stronie szczegolów
        # (fix: Rampage 2018 vs 2009, Cold Mountain itp.)
        if year:
            top_score = scored[0][0]
            candidates = [(s, u, slug) for s, u, slug in scored if s == top_score]
            needs_verify = (all(r.get('year') is None for r in results) and len(candidates) > 1) or                            (len(candidates) == 1 and results[0].get('year') is None)
            if needs_verify:
                fflog(f'[filmpalast] {len(candidates)} kandydatow score={top_score}, weryfikuje rok na stronach szczegolów', 1)
                year_alt_val = year_alt if year_alt else -1

                def _extract_year_from_detail(html):
                    # Filmpalast uses HTML entity: >Ver&ouml;ffentlicht: YEAR (original plugin pattern)
                    m = re.search(r'>Ver(?:&ouml;|ö)ffentlicht:\s*((?:19|20)\d{2})\b', html, re.IGNORECASE)
                    if m: return int(m.group(1))
                    # Fallback: generic label search
                    m = re.search(
                        r'(?:Jahr|Erscheinungsjahr|Veroeffentlicht)[:\s]*(?:<[^>]+>)*\s*((?:19|20)\d{2})\b',
                        html, re.IGNORECASE
                    )
                    if m: return int(m.group(1))
                    m = re.search(r'"date(?:Created|Published)"\s*:\s*"((?:19|20)\d{2})', html)
                    if m: return int(m.group(1))
                    m = re.search(r'itemprop="date[^"]*"[^>]*>((?:19|20)\d{2})', html, re.IGNORECASE)
                    if m: return int(m.group(1))
                    m = re.search(r'data-year="((?:19|20)\d{2})"', html)
                    if m: return int(m.group(1))
                    m = re.search(r'<title>[^<]*\(((?:19|20)\d{2})\)', html, re.IGNORECASE)
                    if m: return int(m.group(1))
                    # Last resort: find year in spans, exclude current year (likely footer copyright)
                    import datetime
                    current_year = datetime.datetime.now().year
                    spans = re.findall(r'>((?:19|20)\d{2})</span>', html)
                    years = [int(y) for y in spans if 1900 <= int(y) < current_year]
                    if len(years) == 1: return years[0]
                    return None

                for s, u, slug in candidates:
                    try:
                        detail_html = self._get(u)
                        if not detail_html:
                            continue
                        detail_year = _extract_year_from_detail(detail_html)
                        fflog(f'[filmpalast] {slug}: rok={detail_year}', 1)
                        if detail_year and detail_year in (year, year_alt_val):
                            fflog(f'[filmpalast] rok pasuje! wybrano: {u}', 1)
                            return u
                    except Exception:
                        pass

        fflog(f'[filmpalast] top dopasowanie: score={scored[0][0]} slug={scored[0][2]}', 1)

        if content_type == 'tvshow':
            best_url  = scored[0][1]
            best_slug = scored[0][2]
            if ep_pattern.search(best_slug):
                base_slug = ep_pattern.sub('', best_slug)
                base_url  = f'{self.base_link}/stream/{base_slug}'
                fflog(f'[filmpalast] serial: bazowy URL = {base_url}', 1)
                return base_url
            return best_url

        return scored[0][1]

    # ------------------------------------------------------------------ #
    #  Odcinki seriali                                                     #
    # ------------------------------------------------------------------ #

    def _get_episode_url(self, show_url, season, episode):
        try:
            self._init_session()
            m = re.search(r'/stream/([^?#/]+)', show_url)
            if not m:
                return None
            base_slug = re.sub(r'-s\d+e\d+$', '', m.group(1), flags=re.IGNORECASE)

            ep_url = f'{self.base_link}/stream/{base_slug}-s{season:02d}e{episode:02d}'
            fflog(f'[filmpalast] odcinek: {ep_url}', 1)

            html = self._get(ep_url)
            if html and self._has_player(html):
                return ep_url

            show_html = self._get(show_url)
            if show_html:
                pat = re.compile(
                    rf'/stream/{re.escape(base_slug)}-s{season:02d}e{episode:02d}',
                    re.IGNORECASE
                )
                if pat.search(show_html):
                    return ep_url

            return ep_url
        except Exception:
            fflog_exc(1)
            return None

    # ------------------------------------------------------------------ #
    #  Wyciaganie zrodel — pattern z oryginalnej wtyczki                  #
    # ------------------------------------------------------------------ #

    def _detect_quality_from_release(self, html):
        """Wykryj jakość z nazwy releasu (np. Greenland.2.1080p.WEB)."""
        m = re.search(
            r'\b(2160p?|4[Kk]|UHD|1080p?|720p?|480p?|HDRip|BRRip|BluRay|WEB.?DL|WEBRip|HDCAM|CAM)\b',
            html, re.IGNORECASE
        )
        if m:
            q = m.group(1).upper().replace('-', '').replace('.', '')
            if '2160' in q or '4K' in q or 'UHD' in q: return '4K'
            if '1080' in q: return '1080p'
            if '720' in q: return '720p'
            if 'CAM' in q: return 'CAM'
        return 'HD'

    def _extract_sources(self, html):
        """
        Pattern z oryginalnej wtyczki filmpalast.ex:
        'video_sources': r'<p class="hostName">(.*?)<.*?<li class="streamPlayBtn clearfix rb">.*?<a.*?class="button.*?(?:url|href)="(.*?)"'
        """
        links = []
        seen  = set()

        # Wykryj jakość z nazwy releasu (np. "Reacher.S03E07.German.DL.1080p.WEB")
        release_quality = self._detect_quality_from_release(html)
        # Filmpalast = serwis niemiecki, audio zawsze w języku niemieckim
        audio_info = 'Dubbing DE'

        def quality_from_label(label):
            c = (label or '').upper()
            if any(x in c for x in ('2160', '4K', 'UHD')): return '4K'
            if '1080' in c: return '1080p'
            if '720'  in c: return '720p'
            if 'HD'   in c: return release_quality  # użyj jakości z releasu gdy etykieta mówi "HD"
            return release_quality

        def add(url, info='', quality=None):
            url = url.strip().replace('\\/', '/')
            if url.startswith('//'): url = 'https:' + url
            if not url.startswith('http'): return
            if 'filmpalast.to' in url: return
            if '#' in url and not url.startswith('http'): return
            if url not in seen:
                q = quality or quality_from_label(info)
                seen.add(url)
                # info = "Dubbing DE | NazwaHostera"
                full_info = f'{audio_info} | {info}' if info else audio_info
                links.append({'url': url, 'quality': q, 'info': full_info})
                fflog(f'[filmpalast] zrodlo [{q}] {full_info}: {url}', 1)

        # === GLOWNY PATTERN z oryginalnej wtyczki ===
        main_pattern = re.compile(
            r'<p\s+class="hostName">(.*?)</p>.*?'
            r'<li\s+class="streamPlayBtn[^"]*">.*?'
            r'<a[^>]*(?:url|href)=["\']([^"\'#\s][^"\']*)["\']',
            re.IGNORECASE | re.DOTALL
        )
        for m in main_pattern.finditer(html):
            hoster = re.sub(r'<[^>]+>', '', m.group(1)).strip()
            url    = m.group(2).strip()
            if url and not url.startswith('#'):
                add(url, hoster)

        # === FALLBACK: szukaj linkow do znanych hostow ===
        if not links:
            fflog('[filmpalast] glowny pattern 0 zrodel, fallback', 1)
            known = re.compile(
                r'(?:href|url|src)=["\']('
                r'https?://(?:'
                r'voe\.sx|veev\.|streamtape\.|dood\.|upstream\.'
                r'|vidara\.|vidsonic\.|vidhide\.|vidplay\.'
                r'|streamwish\.|filemoon\.|mixdrop\.|vidoza\.'
                r'|streamlare\.|mp4upload\.|vidmoly\.|netu\.'
                r'|supervideo\.|emturbovid\.|uqload\.|vudeo\.'
                r')[^"\'<>\s]+)["\']',
                re.IGNORECASE
            )
            for m in known.finditer(html):
                add(m.group(1))

        fflog(f'[filmpalast] lacznie {len(links)} zrodel')
        return links

    def _has_player(self, html):
        return bool(re.search(
            r'class="hostName"|class="streamPlayBtn"|iframe|\.mp4|\.m3u8|voe\.sx|streamtape|veev\.',
            html, re.IGNORECASE
        ))

    # ------------------------------------------------------------------ #
    #  HTTP — DoH (DNS-over-HTTPS) jak w oryginalnej wtyczce filmpalast  #
    #  Podmienia tylko gniazdo TCP, URL/Host/SNI pozostają niezmienione  #
    # ------------------------------------------------------------------ #

    def _init_session(self):
        if not self.session:
            try:
                from resources.lib.sources.doh_helper import make_doh_session
                self.session = make_doh_session()
                fflog('[filmpalast] sesja DoH OK', 1)
            except Exception:
                fflog_exc(1)
                import requests, urllib3
                urllib3.disable_warnings()
                self.session = requests.Session()
                self.session.verify = False
            self.session.headers.update(self.headers)

    def _get(self, url, timeout=(10, 30)):
        if url in self._cache:
            return self._cache[url]
        try:
            fflog(f'[filmpalast] GET {url}', 1)
            r = self.session.get(url, headers=self.headers, timeout=timeout, verify=False)
            fflog(f'[filmpalast] status={r.status_code} len={len(r.text)}', 1)
            if r is None or r.status_code >= 400:
                self._cache[url] = None
                return None
            self._cache[url] = r.text
            return r.text
        except Exception:
            fflog_exc(1)
            self._cache[url] = None
            return None
