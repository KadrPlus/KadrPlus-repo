# -*- coding: UTF-8 -*-
"""
    Scraper dla vavoo.to (serwis NIEMIECKI)
    Oparty na oryginalnej wtyczce plugin.video.vavooto

    API flow:
      1. Pobierz auth-signature z https://www.lokke.app/api/app/ping
      2. POST https://vavoo.to/mediahubmx-source.json z tmdb_id
      3. Odpowiedź: lista mirrorów z url, tag (jakość), languages
"""
import re
import time

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from ptw.debug import fflog, fflog_exc
from ptw.libraries import source_utils


class source:
    def __init__(self):
        self.priority = 2
        self.language = ['de']

        self._sig_cache    = None   # (signature, timestamp)
        self._mirror_cache = {}     # (tmdb_id, season, episode) -> mirrors
        self.session       = None

        self._PING_URL    = 'https://www.lokke.app/api/app/ping'
        self._SOURCE_URL  = 'https://vavoo.to/mediahubmx-source.json'
        self._PING_TOKEN  = ('ldCvE092e7gER0rVIajfsXIvRhwlrAzP6_1oEJ4q6HH89QHt24v6NNL_'
                             'jQJO219hiLOXF2hqEfsUuEWitEIGN4EaHHEHb7Cd7gojc5SQYRFzU3X'
                             'Wo_kMeryAUbcwWnQrnf0-')

    # ------------------------------------------------------------------ #
    #  Metody wymagane przez FanFilm                                       #
    # ------------------------------------------------------------------ #

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        fflog(f'[vavoo] {title=}  {year=}', 1)
        tmdb = kwargs.get('tmdb') or kwargs.get('tmdb_id') or ''
        if not tmdb:
            fflog('[vavoo] brak tmdb_id, pomijam')
            return None
        return f'movie:{tmdb}'

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        fflog(f'[vavoo] {tvshowtitle=}  {year=}', 1)
        tmdb = kwargs.get('tmdb') or kwargs.get('tmdb_id') or ''
        if not tmdb:
            fflog('[vavoo] brak tmdb_id, pomijam')
            return None
        return f'series:{tmdb}'

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        fflog(f'[vavoo] episode {url=}  {season=}  {episode=}', 1)
        if not url:
            return None
        return f'{url}:{season}:{episode}'

    def sources(self, url, hostDict, hostprDict):
        result = []
        fflog(f'[vavoo] sources {url=}', 1)
        if not url:
            return result
        try:
            self._init_session()
            mirrors = self._get_mirrors(url)
            if not mirrors:
                fflog('[vavoo] brak mirrorów')
                return result

            for m in mirrors:
                link     = m.get('url', '')
                quality  = m.get('quality', 'HD')
                info     = m.get('info', '')
                if not link:
                    continue

                valid, hoster = source_utils.is_host_valid(link, hostDict)
                if not valid:
                    valid, hoster = source_utils.is_host_valid(link, hostprDict)
                if not valid:
                    from urllib.parse import urlsplit
                    hoster = urlsplit(link).hostname or link

                result.append({
                    'source':     hoster,
                    'quality':    quality,
                    'language':   'de',
                    'url':        link,
                    'info':       info,
                    'direct':     False,
                    'debridonly': False,
                })

        except Exception:
            fflog_exc(1)

        fflog(f'[vavoo] zwracam {len(result)} zrodel')
        return result

    def resolve(self, url):
        return url

    # ------------------------------------------------------------------ #
    #  Pobieranie mirrorów z API                                           #
    # ------------------------------------------------------------------ #

    def _get_mirrors(self, url):
        """
        url format:
          movie:TMDB_ID
          series:TMDB_ID:SEASON:EPISODE
        """
        parts    = url.split(':')
        kind     = parts[0]        # 'movie' lub 'series'
        tmdb_id  = parts[1]
        season   = parts[2] if len(parts) > 2 else None
        episode  = parts[3] if len(parts) > 3 else None

        cache_key = (kind, tmdb_id, season, episode)
        if cache_key in self._mirror_cache:
            return self._mirror_cache[cache_key]

        sig = self._get_signature()
        if not sig:
            fflog('[vavoo] nie udało się pobrać signature')
            return []

        headers = {
            'user-agent':           'MediaHubMX/2',
            'content-type':         'application/json; charset=utf-8',
            'accept-encoding':      'gzip',
            'mediahubmx-signature': sig,
        }

        if kind == 'movie':
            data = {
                'language':      'de',
                'region':        'AT',
                'type':          'movie',
                'ids':           {'tmdb_id': tmdb_id},
                'name':          '',
                'episode':       {},
                'clientVersion': '3.0.2',
            }
        else:
            data = {
                'language':      'de',
                'region':        'AT',
                'type':          'series',
                'ids':           {'tmdb_id': tmdb_id},
                'name':          '',
                'episode':       {'season': season, 'episode': episode},
                'clientVersion': '3.0.2',
            }

        fflog(f'[vavoo] POST {self._SOURCE_URL} tmdb={tmdb_id} {kind}', 1)
        try:
            resp = self.session.post(
                self._SOURCE_URL,
                json=data,
                headers=headers,
                timeout=(8, 30),
                verify=False,
            )
            raw = resp.json()
        except Exception:
            fflog_exc(1)
            return []

        if not raw:
            fflog('[vavoo] pusta odpowiedź API')
            return []

        fflog(f'[vavoo] API zwróciło {len(raw)} mirrorów', 1)

        mirrors = []
        for m in raw:
            # Filtruj tylko niemieckie
            langs = m.get('languages', [])
            if langs and 'de' not in langs:
                fflog(f'[vavoo] pomijam (lang={langs}): {m.get("url", "")}', 1)
                continue

            link = m.get('url', '')
            if not link:
                continue

            # Pomiń nieprzydatne hostery
            from urllib.parse import urlparse
            hoster = urlparse(link).netloc
            if 'streamz' in hoster:
                continue

            # Jakość z pola "tag"
            tag = m.get('tag', '')
            quality = self._tag_to_quality(tag)

            # Info = "Dubbing DE | jakość"
            info = f'Dubbing DE | {quality}' if quality else 'Dubbing DE'

            mirrors.append({
                'url':     link,
                'quality': quality,
                'info':    info,
                'hoster':  hoster,
            })
            fflog(f'[vavoo] mirror [{quality}] {hoster}: {link}', 1)

        # Sortuj: lepsza jakość na górze
        order = {'4K': 0, '1080p': 1, '720p': 2, 'HD': 3, 'SD': 4}
        mirrors.sort(key=lambda x: order.get(x['quality'], 5))

        self._mirror_cache[cache_key] = mirrors
        return mirrors

    def _tag_to_quality(self, tag):
        t = (tag or '').upper()
        if t in ('2160P', '4K', 'UHD'):  return '4K'
        if t in ('1080P', 'FHD'):        return '1080p'
        if t in ('720P', 'HD'):          return '720p'
        if t == 'SD':                    return 'SD'
        # Fallback: szukaj cyfr w tagu
        if '2160' in t or '4K' in t:     return '4K'
        if '1080' in t:                  return '1080p'
        if '720'  in t:                  return '720p'
        return 'HD'

    # ------------------------------------------------------------------ #
    #  Auth signature                                                      #
    # ------------------------------------------------------------------ #

    def _get_signature(self):
        """Pobierz auth signature - próbuje dwóch endpointów z oryginalnej wtyczki."""
        now = int(time.time())
        if self._sig_cache:
            sig, ts = self._sig_cache
            if now - ts < 3000:
                return sig

        # Metoda 1: vavoo.tv/api/box/ping2 (z utils.py - gettsSignature)
        sig = self._get_sig_ping2()
        if sig:
            self._sig_cache = (sig, now)
            fflog('[vavoo] signature OK (ping2)', 1)
            return sig

        # Metoda 2: lokke.app (fallback)
        sig = self._get_sig_lokke()
        if sig:
            self._sig_cache = (sig, now)
            fflog('[vavoo] signature OK (lokke)', 1)
            return sig

        fflog('[vavoo] nie udało się pobrać signature żadną metodą')
        return None

    def _get_sig_ping2(self):
        """Signature przez vavoo.tv/api/box/ping2 (gettsSignature z utils.py)."""
        try:
            vec = {"vec": "9frjpxPjxSNilxJPCJ0XGYs6scej3dW/h/VWlnKUiLSG8IP7mfyDU7NirOlld+VtCKGj03XjetfliDMhIev7wcARo+YTU8KPFuVQP9E2DVXzY2BFo1NhE6qEmPfNDnm74eyl/7iFJ0EETm6XbYyz8IKBkAqPN/Spp3PZ2ulKg3QBSDxcVN4R5zRn7OsgLJ2CNTuWkd/h451lDCp+TtTuvnAEhcQckdsydFhTZCK5IiWrrTIC/d4qDXEd+GtOP4hPdoIuCaNzYfX3lLCwFENC6RZoTBYLrcKVVgbqyQZ7DnLqfLqvf3z0FVUWx9H21liGFpByzdnoxyFkue3NzrFtkRL37xkx9ITucepSYKzUVEfyBh+/3mtzKY26VIRkJFkpf8KVcCRNrTRQn47Wuq4gC7sSwT7eHCAydKSACcUMMdpPSvbvfOmIqeBNA83osX8FPFYUMZsjvYNEE3arbFiGsQlggBKgg1V3oN+5ni3Vjc5InHg/xv476LHDFnNdAJx448ph3DoAiJjr2g4ZTNynfSxdzA68qSuJY8UjyzgDjG0RIMv2h7DlQNjkAXv4k1BrPpfOiOqH67yIarNmkPIwrIV+W9TTV/yRyE1LEgOr4DK8uW2AUtHOPA2gn6P5sgFyi68w55MZBPepddfYTQ+E1N6R/hWnMYPt/i0xSUeMPekX47iucfpFBEv9Uh9zdGiEB+0P3LVMP+q+pbBU4o1NkKyY1V8wH1Wilr0a+q87kEnQ1LWYMMBhaP9yFseGSbYwdeLsX9uR1uPaN+u4woO2g8sw9Y5ze5XMgOVpFCZaut02I5k0U4WPyN5adQjG8sAzxsI3KsV04DEVymj224iqg2Lzz53Xz9yEy+7/85ILQpJ6llCyqpHLFyHq/kJxYPhDUF755WaHJEaFRPxUqbparNX+mCE9Xzy7Q/KTgAPiRS41FHXXv+7XSPp4cy9jli0BVnYf13Xsp28OGs/D8Nl3NgEn3/eUcMN80JRdsOrV62fnBVMBNf36+LbISdvsFAFr0xyuPGmlIETcFyxJkrGZnhHAxwzsvZ+Uwf8lffBfZFPRrNv+tgeeLpatVcHLHZGeTgWWml6tIHwWUqv2TVJeMkAEL5PPS4Gtbscau5HM+FEjtGS+KClfX1CNKvgYJl7mLDEf5ZYQv5kHaoQ6RcPaR6vUNn02zpq5/X3EPIgUKF0r/0ctmoT84B2J1BKfCbctdFY9br7JSJ6DvUxyde68jB+Il6qNcQwTFj4cNErk4x719Y42NoAnnQYC2/qfL/gAhJl8TKMvBt3Bno+va8ve8E0z8yEuMLUqe8OXLce6nCa+L5LYK1aBdb60BYbMeWk1qmG6Nk9OnYLhzDyrd9iHDd7X95OM6X5wiMVZRn5ebw4askTTc50xmrg4eic2U1w1JpSEjdH/u/hXrWKSMWAxaj34uQnMuWxPZEXoVxzGyuUbroXRfkhzpqmqqqOcypjsWPdq5BOUGL/Riwjm6yMI0x9kbO8+VoQ6RYfjAbxNriZ1cQ+AW1fqEgnRWXmjt4Z1M0ygUBi8w71bDML1YG6UHeC2cJ2CCCxSrfycKQhpSdI1QIuwd2eyIpd4LgwrMiY3xNWreAF+qobNxvE7ypKTISNrz0iYIhU0aKNlcGwYd0FXIRfKVBzSBe4MRK2pGLDNO6ytoHxvJweZ8h1XG8RWc4aB5gTnB7Tjiqym4b64lRdj1DPHJnzD4aqRixpXhzYzWVDN2kONCR5i2quYbnVFN4sSfLiKeOwKX4JdmzpYixNZXjLkG14seS6KR0Wl8Itp5IMIWFpnNokjRH76RYRZAcx0jP0V5/GfNNTi5QsEU98en0SiXHQGXnROiHpRUDXTl8FmJORjwXc0AjrEMuQ2FDJDmAIlKUSLhjbIiKw3iaqp5TVyXuz0ZMYBhnqhcwqULqtFSuIKpaW8FgF8QJfP2frADf4kKZG1bQ99MrRrb2A="}
            resp = self.session.post(
                'https://www.vavoo.tv/api/box/ping2',
                data=vec,
                timeout=(8, 20),
                verify=False,
            )
            fflog(f'[vavoo] ping2 status={resp.status_code}', 1)
            data = resp.json()
            sig = data.get('response', {}).get('signed')
            return sig
        except Exception:
            fflog_exc(1)
            return None

    def _get_sig_lokke(self):
        """Signature przez lokke.app (fallback)."""
        try:
            headers = {
                'user-agent':      'okhttp/4.11.0',
                'accept':          'application/json',
                'content-type':    'application/json; charset=utf-8',
                'accept-encoding': 'gzip',
            }
            data = {
                'token':  self._PING_TOKEN,
                'reason': 'app-blur',
                'locale': 'de',
                'theme':  'dark',
                'metadata': {
                    'device': {'type': 'Handset', 'brand': 'google', 'model': 'Nexus',
                               'name': '21081111RG', 'uniqueId': 'd10e5d99ab665233'},
                    'os': {'name': 'android', 'version': '7.1.2',
                           'abis': ['arm64-v8a'], 'host': 'android'},
                    'app': {'platform': 'android', 'version': '1.1.0', 'buildId': '97215000',
                            'engine': 'hbc85',
                            'signatures': ['6e8a975e3cbf07d5de823a760d4c2547f86c1403105020adee5de67ac510999e'],
                            'installer': 'com.android.vending'},
                    'version': {'package': 'app.lokke.main', 'binary': '1.1.0', 'js': '1.1.0'},
                    'platform': {'isAndroid': True, 'isIOS': False, 'isTV': False,
                                 'isWeb': False, 'isMobile': True},
                },
                'devMode': True, 'hasAddon': True,
                'package': 'app.lokke.main', 'version': '1.1.0',
            }
            resp = self.session.post(
                self._PING_URL, json=data, headers=headers,
                timeout=(8, 20), verify=False,
            )
            fflog(f'[vavoo] lokke status={resp.status_code}', 1)
            return resp.json().get('addonSig')
        except Exception:
            fflog_exc(1)
            return None

    # ------------------------------------------------------------------ #
    #  HTTP session                                                        #
    # ------------------------------------------------------------------ #

    def _init_session(self):
        if not self.session:
            import requests as req
            self.session = req.Session()
            self.session.headers.update({
                'User-Agent': 'MediaHubMX/2',
            })
