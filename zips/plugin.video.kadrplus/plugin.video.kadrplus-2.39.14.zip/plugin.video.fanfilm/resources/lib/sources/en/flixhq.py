# -*- coding: utf-8 -*-
"""
FanFilm - źródło: flixhq.to
Copyright (C) 2025 FF Team

Przeniesione z FanFilm Beta i dostosowane do architektury ptw.
Filmy i seriale EN. Bez logowania, bez konta.
"""

import re
import json
from urllib.parse import parse_qs, urljoin, urlencode, quote_plus

from ptw.libraries import client, cleantitle, control
from ptw.libraries.log_utils import fflog
from ptw.debug import fflog_exc

DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0"


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["en"]
        self.domains   = ["flixhq.to"]
        self.base_link = "https://flixhq.to"
        self.search_link             = "/search/%s"
        self.ajax_seasons_link       = "/ajax/v2/tv/seasons/%s"
        self.ajax_episodes_link      = "/ajax/v2/season/episodes/%s"
        self.ajax_servers_link       = "/ajax/v2/episode/servers/%s"
        self.ajax_movie_episodes_link = "/ajax/movie/episodes/%s"
        self.ajax_episode_sources_link = "/ajax/episode/sources/%s"
        self.headers = {"User-Agent": DEFAULT_UA, "Referer": self.base_link}
        self.provider = "Vidcloud"

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        try:
            url = urlencode({"imdb": imdb, "title": title, "year": year})
            return url
        except Exception:
            fflog_exc(1)
            return None

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        try:
            url = urlencode({"imdb": imdb, "tmdb": tvdb, "tvshowtitle": tvshowtitle, "year": year})
            return url
        except Exception:
            fflog_exc(1)
            return None

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        try:
            if not url:
                return None
            data = dict([(k, v[0]) if v else (k, "") for k, v in parse_qs(url).items()])
            data.update({"title": title, "premiered": premiered, "season": season, "episode": episode})
            return urlencode(data)
        except Exception:
            fflog_exc(1)
            return None

    def sources(self, url, hostDict=None, hostprDict=None):
        sources = []
        try:
            if not url:
                return sources

            data = dict([(k, v[0]) if v else (k, "") for k, v in parse_qs(url).items()])
            title = data.get("title", "")
            year  = data.get("year", "")

            # Wyodrębnij rok z tytułu jeśli brak
            search_title = title
            if not year and title:
                year_match = re.search(r'\b(19|20)\d{2}\b', title)
                if year_match:
                    year = year_match.group(0)
                    search_title = re.sub(r'\s{2,}', ' ',
                        title[:year_match.start()] + title[year_match.end():]).strip()
            if not search_title:
                search_title = title

            clean_search_title = cleantitle.get(search_title or title)
            query = title.replace(" ", "-")
            search_url = urljoin(self.base_link, self.search_link % quote_plus(query))

            r = client.request(search_url, headers=self.headers)
            if not r:
                return sources

            r_cleaned = re.sub(r'\n', '', r)
            items = r_cleaned.split('class="flw-item"')[1:]

            media_id   = None
            media_type = None

            for item in items:
                lobster = re.search(
                    r'.*img data-src="([^"]*)".*<a href=".*/(tv|movie)/watch-.*-([0-9]*)"'
                    r'.*title="([^"]*)".*class="fdi-item">([^<]*)</span>.*', item
                )
                if lobster:
                    item_type  = lobster.group(2)
                    item_id    = lobster.group(3)
                    item_title = lobster.group(4)
                    item_year  = lobster.group(5)
                else:
                    link_match = re.search(
                        r'<a[^>]+href="[^"]*/(tv|movie)/watch-[^"]*-([0-9]+)"[^>]*title="([^"]*)"', item
                    )
                    year_match = re.search(r'class="fdi-item">([^<]*)</span>', item)
                    if not link_match:
                        continue
                    item_type  = link_match.group(1)
                    item_id    = link_match.group(2)
                    item_title = link_match.group(3)
                    item_year  = year_match.group(1) if year_match else ""

                if cleantitle.get(item_title) != clean_search_title:
                    continue

                if year and item_year and year in item_year:
                    media_id = item_id; media_type = item_type; break
                elif not year and "tvshowtitle" not in data and item_type == "movie":
                    media_id = item_id; media_type = item_type; break
                elif not year and "tvshowtitle" in data and item_type == "tv" \
                        and ("EPS" in item_year.upper() or "EPISODE" in item_year.upper()):
                    media_id = item_id; media_type = item_type; break
                elif not media_id:
                    media_id = item_id; media_type = item_type

            if not media_id:
                return sources

            # --- TV Show ---
            server_ids = []
            if "tvshowtitle" in data and media_type == "tv":
                season  = data.get("season", "1")
                episode = data.get("episode", "1")

                seasons_r = client.request(
                    urljoin(self.base_link, self.ajax_seasons_link % media_id), headers=self.headers
                )
                if not seasons_r:
                    return sources

                season_match = re.search(
                    r'href=".*-([0-9]*)">' + re.escape(f'Season {season}') + r'</a>', seasons_r
                )
                if not season_match:
                    return sources
                season_id = season_match.group(1)

                episodes_r = client.request(
                    urljoin(self.base_link, self.ajax_episodes_link % season_id), headers=self.headers
                )
                if not episodes_r:
                    return sources

                ep_items = re.sub(r'\n', '', episodes_r).split('class="nav-item"')
                data_id = None
                target_ep_num = int(episode) if str(episode).isdigit() else episode

                for ep_item in ep_items:
                    ep_match = re.search(r'data-id="([0-9]*)".*title="([^"]*)">', ep_item)
                    if ep_match:
                        ep_id    = ep_match.group(1)
                        ep_title = ep_match.group(2)
                        num_match = re.search(r'(?:Episode|Ep|E)\s*(\d+)', ep_title, re.IGNORECASE)
                        if num_match and int(num_match.group(1)) == target_ep_num:
                            data_id = ep_id; break
                        elif not num_match and str(target_ep_num) in ep_title:
                            data_id = ep_id; break

                if not data_id and ep_items:
                    try:
                        idx = int(episode) - 1
                        if 0 <= idx < len(ep_items):
                            m = re.search(r'data-id="([0-9]*)"', ep_items[idx])
                            if m:
                                data_id = m.group(1)
                    except Exception:
                        pass

                if not data_id:
                    return sources

                servers_r = client.request(
                    urljoin(self.base_link, self.ajax_servers_link % data_id), headers=self.headers
                )
                if not servers_r:
                    return sources

                for sv_item in re.sub(r'\n', '', servers_r).split('class="nav-item"'):
                    sv_match = re.search(r'data-id="([0-9]*)".*title="([^"]*)"', sv_item)
                    if sv_match and "Vidcloud" in sv_match.group(2):
                        server_ids.append((sv_match.group(1), sv_match.group(2)))

            # --- Movie ---
            else:
                movie_r = client.request(
                    urljoin(self.base_link, self.ajax_movie_episodes_link % media_id), headers=self.headers
                )
                if not movie_r:
                    return sources

                for movie_link, server_title in re.findall(r'href="([^"]*)"[^>]*title="([^"]*)"', movie_r):
                    ep_id_match = re.search(r'-([0-9]*)\.([0-9]*)$', movie_link)
                    if ep_id_match and "Vidcloud" in server_title:
                        server_ids.append((ep_id_match.group(2), server_title))

            if not server_ids:
                return sources

            # --- Pobierz embed linki ---
            for server_id, server_name in server_ids:
                sources_r = client.request(
                    urljoin(self.base_link, self.ajax_episode_sources_link % server_id),
                    headers=self.headers
                )
                if not sources_r:
                    continue
                try:
                    sources_data = json.loads(sources_r)
                    embed_link   = sources_data.get("link", "")
                    if not embed_link:
                        continue

                    quality = "1080p"
                    if "4K" in server_name.upper(): quality = "4K"
                    elif "720" in server_name: quality = "720p"

                    sources.append({
                        "source": f"flixhq-{server_name.lower().replace(' ', '')}",
                        "quality": quality,
                        "language": "en",
                        "url": embed_link,
                        "info": "",
                        "direct": False,
                        "debridonly": False,
                    })
                except json.JSONDecodeError:
                    continue

            fflog(f'[flixhq] znaleziono źródeł: {len(sources)}')
            return sources

        except Exception:
            fflog_exc(1)
            return sources

    def resolve(self, url):
        try:
            decrypt_url = f"https://dec.eatmynerds.live/?url={url}"
            data = client.request(decrypt_url, headers=self.headers)
            if not data:
                return url

            json_data = json.loads(data)
            sources_array = json_data.get("sources", [])
            if sources_array:
                file_url = sources_array[0].get("file", "")
                if file_url and file_url.endswith(".m3u8"):
                    return f"{file_url}|Referer=https://flixhq.to"

            file_match = re.search(r'"file":\s*"([^"]*\.m3u8)"', data)
            if file_match:
                return f"{file_match.group(1)}|Referer=https://flixhq.to"

            return url
        except Exception:
            fflog_exc(1)
            return url
