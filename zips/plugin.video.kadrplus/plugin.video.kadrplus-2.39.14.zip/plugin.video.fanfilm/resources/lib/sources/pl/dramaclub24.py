# -*- coding: utf-8 -*-
"""
FanFilm - źródło: dramaclub24.org
Copyright (C) 2025 FF Team

Przeniesione z FanFilm Beta i dostosowane do architektury ptw.
K-drama, J-drama, C-drama z polskim lektorem/napisami.
"""

from __future__ import annotations
import re
import requests
from typing import Dict, Generator, List, Optional, Set, Tuple
from urllib.parse import quote_plus, urljoin
from html import unescape

from ptw.libraries import cleantitle, source_utils, control
from ptw.libraries.log_utils import fflog
from ptw.debug import fflog_exc

DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0"

ASIAN_COUNTRIES = frozenset({'KR', 'JP', 'CN'})

RE_SEARCH_RESULT  = re.compile(r'<li\s+class="short-list_item[^"]*".*?</li>', re.DOTALL)
RE_HREF           = re.compile(r'<a\s+href="([^"]*)"')
RE_TITLE          = re.compile(r'(?:alt|title)="([^"]*)"')
RE_POSTER_TITLE   = re.compile(r'<p\s+class="poster-short_title">([^<]+)</p>')
RE_LANG_INFO      = re.compile(r'\b((?:Lektor|Napisy|Dubbing)\s+[A-Za-z]{2})\b', re.IGNORECASE)
RE_PLAYLIST_URL   = re.compile(r'PLAYLIST_URL\s*=\s*["\']([^"\']+\.m3u8)["\']')
RE_SEASON         = re.compile(r'\bSezon\s+(\d+)\b', re.IGNORECASE)
RE_SEASON_SUFFIX  = re.compile(r'season\d+$')


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.base_link = "https://dramaclub24.org"
        self.search_link = "https://dramaclub24.org/index.php?do=search&subaction=search&story={title}"
        self.session = requests.Session()
        self.session.headers.update({
            "Host": "dramaclub24.org",
            "User-Agent": DEFAULT_UA,
        })

    # ------------------------------------------------------------------ #
    #  Pomocnicze — wykrywanie krajów azjatyckich
    # ------------------------------------------------------------------ #

    def _is_asian(self, imdb, tvdb, content_type, aliases=None):
        """
        Sprawdza czy tytuł pochodzi z Azji (KR/JP/CN/TW/HK).
        Używa country codes z aliasów TMDB — szybkie i bez zewnętrznych API.
        Fallback: True (próbuj zawsze gdy brak danych o kraju).
        """
        ASIAN = frozenset({'kr', 'jp', 'cn', 'tw', 'hk'})
        try:
            if aliases:
                countries = {
                    (a.get('country') or '').lower()
                    for a in aliases
                    if a.get('country')
                }
                if countries:
                    return bool(countries & ASIAN)
        except Exception:
            pass
        return True  # brak danych o kraju — próbuj

    # ------------------------------------------------------------------ #
    #  Public API
    # ------------------------------------------------------------------ #

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        alias_titles = self._prepare_aliases(title, localtitle, aliases, year)
        if not self._is_asian(imdb, None, 'movie', aliases):
            return None
        for search_title in self._search_queries(title, localtitle):
            fflog(f'[dramaclub24] szukam film: {search_title!r}')
            page = self.session.get(
                self.search_link.format(title=quote_plus(search_title)), verify=False
            ).text
            result = self._match_results(page, search_title, alias_titles, year, 'movie')
            if result:
                return result
        return None

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        return {'title': tvshowtitle, 'local_title': localtvshowtitle,
                'aliases': aliases, 'year': year, 'imdb': imdb, 'tvdb': tvdb}

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        if not isinstance(url, dict):
            return None
        if not self._is_asian(url.get('imdb'), url.get('tvdb'), 'show', url.get('aliases')):
            return None

        show_data = url
        alias_titles = self._prepare_aliases(
            show_data['title'], show_data['local_title'],
            show_data.get('aliases', []), show_data['year']
        )
        for search_title in self._search_queries(show_data['title'], show_data['local_title']):
            fflog(f'[dramaclub24] szukam serial: {search_title!r}')
            page = self.session.get(
                self.search_link.format(title=quote_plus(search_title)), verify=False
            ).text
            result = self._match_results(
                page, search_title, alias_titles, show_data['year'],
                'tvshow', season=int(season)
            )
            if result:
                show_url = result[0]
                show_page = self.session.get(show_url, verify=False).text
                info, language = self._detect_lang_info(show_page)
                sources = self._extract_episode_sources(
                    show_page, int(episode), info=info, language=language,
                    filename=self._url_to_filename(show_url)
                )
                if sources:
                    fflog(f'[dramaclub24] ep {episode}: {len(sources)} źródeł')
                    return sources
        return None

    def sources(self, url, hostDict=None, hostprDict=None):
        try:
            if isinstance(url, list):
                return url  # episode() zwraca gotową listę

            if isinstance(url, tuple):
                url = url[0]
            if not url:
                return []

            page_content = self.session.get(url, verify=False).text
            info, language = self._detect_lang_info(page_content)
            return self._extract_sources_from_page(
                page_content, info=info, language=language,
                filename=self._url_to_filename(url)
            )
        except Exception:
            fflog_exc(1)
            return []

    def resolve(self, url):
        if not url:
            return url
        headers = "Referer=https://dramaclub24.org/&Origin=https://dramaclub24.org"
        if ".m3u8" in url:
            return f"isa+{url}|{headers}"
        if ".mp4" in url and url.startswith("https://dramaclub24.org"):
            return f"{url}|{headers}"
        return url

    # ------------------------------------------------------------------ #
    #  Wyszukiwanie i dopasowanie
    # ------------------------------------------------------------------ #

    def _search_queries(self, title, local_title):
        if local_title:
            yield local_title
        if title and cleantitle.get_simple(title) != cleantitle.get_simple(local_title):
            yield title

    def _parse_search_results(self, page_content, media_type):
        candidates = []
        for item_html in RE_SEARCH_RESULT.findall(page_content):
            try:
                href_match = RE_HREF.findall(item_html)
                if not href_match:
                    continue
                href = href_match[0]
                is_movie  = "/filmy/" in href
                is_tvshow = "/dramy/" in href
                if (media_type == 'movie' and not is_movie) or (media_type == 'tvshow' and not is_tvshow):
                    continue
                title_match = RE_POSTER_TITLE.findall(item_html) or RE_TITLE.findall(item_html)
                if not title_match:
                    continue
                full_title = unescape(title_match[0].strip())
                # Usuń "Sezon N" z tytułu
                title_parts = [p.strip() for p in re.split(r'\s*/\s*|\s*\|\s*', full_title)]
                title_parts_clean = [
                    cleantitle.get(RE_SEASON.sub('', p).strip())
                    for p in title_parts
                ]
                candidates.append({
                    'href': href,
                    'full_title': full_title,
                    'title_parts_clean': title_parts_clean,
                })
            except Exception:
                continue
        return candidates

    def _match_results(self, page_content, primary_title, alias_titles, year, media_type, season=0):
        candidates = self._parse_search_results(page_content, media_type)
        if not candidates:
            return None

        primary_clean = cleantitle.get(primary_title)
        alias_cleans  = {cleantitle.get(a) for a in alias_titles}

        for c in candidates:
            for part in c["title_parts_clean"]:
                if part == primary_clean:
                    return (c["href"], c["full_title"])

        for c in candidates:
            for part in c["title_parts_clean"]:
                if part in alias_cleans:
                    return (c["href"], c["full_title"])

        if season > 0:
            for c in candidates:
                for part in c["title_parts_clean"]:
                    base = RE_SEASON_SUFFIX.sub('', part).rstrip()
                    if base == primary_clean or base in alias_cleans:
                        return (c["href"], c["full_title"])

        return None

    def _prepare_aliases(self, title, local_title, aliases, year):
        seen = {}
        def _add(t):
            t = (t or '').strip()
            if t: seen[t] = None
        _add(title)
        _add(local_title)
        year_str = str(year)
        for a in (aliases or []):
            t = (a.get('title') or a.get('originalname') or '')
            t = t.replace(year_str, '').replace('()', '').strip()
            if t and not source_utils.czy_litery_krzaczki(t):
                _add(t)
        return list(seen)

    # ------------------------------------------------------------------ #
    #  Ekstrakcja źródeł
    # ------------------------------------------------------------------ #

    def _detect_lang_info(self, page_content):
        m = RE_LANG_INFO.search(page_content)
        if m:
            parts = m.group(1).split()
            return parts[0].capitalize(), parts[1].lower()
        return "", "pl"

    def _url_to_filename(self, url):
        path = url.replace(self.base_link, "").strip("/")
        path = path.rsplit(".", 1)[0]
        parts = path.split("/", 1)
        return parts[1] if len(parts) > 1 else path

    def _make_source(self, url, *, info, language, direct, filename=""):
        bare = url.replace("https://", "").replace("http://", "")
        parts = bare.split("/")[0].split(".")
        host = f"{parts[-2]}.{parts[-1]}" if len(parts) >= 2 else bare.split("/")[0]
        return {
            "source": host,
            "url": url,
            "quality": "720p",
            "language": language,
            "info": info,
            "filename": filename,
            "direct": direct,
            "debridonly": False,
            "premium": False,
        }

    def _parse_m3u8_entries(self, content):
        lines = [l.strip() for l in content.strip().splitlines()]
        for line, nxt in zip(lines, lines[1:]):
            if line.startswith('#EXTINF:'):
                t = line.split(',', 1)[1] if ',' in line else ''
                if nxt and not nxt.startswith('#'):
                    yield t, nxt

    def _fetch_source_playlist(self, url, *, info, language, filename=""):
        try:
            content = self.session.get(url, verify=False).text
            if '#EXT-X-STREAM-INF' in content or '#EXT-X-TARGETDURATION' in content:
                return []
            sources = []
            for _, src_url in self._parse_m3u8_entries(content):
                src = self._make_source(
                    src_url, info=info, language=language,
                    direct=src_url.startswith(self.base_link), filename=filename
                )
                sources.append(src)
            return sources
        except Exception:
            fflog_exc(1)
            return []

    def _extract_episode_sources(self, show_page, episode_num, *, info, language, filename=""):
        try:
            m = RE_PLAYLIST_URL.search(show_page)
            if not m:
                return []
            playlist_url = m.group(1)
            content = self.session.get(playlist_url, verify=False).text
            ep_re = re.compile(rf'\bOdcinek\s+{episode_num}\b', re.IGNORECASE)
            sources = []
            for title_entry, src_url in self._parse_m3u8_entries(content):
                if ep_re.search(title_entry):
                    ep_filename = f"{filename} | {title_entry.strip()}" if filename else title_entry.strip()
                    sources.append(self._make_source(
                        src_url, info=info, language=language,
                        direct=src_url.startswith(self.base_link), filename=ep_filename
                    ))
            return sources
        except Exception:
            fflog_exc(1)
            return []

    def _extract_sources_from_page(self, page_content, *, info, language, filename=""):
        sources = []
        seen_urls: Set[str] = set()

        def add(url, *, direct=True):
            if url not in seen_urls:
                seen_urls.add(url)
                sources.append(self._make_source(url, info=info, language=language,
                                                 direct=direct, filename=filename))

        for m in re.finditer(r'https?://[^"\s<>]+\.m3u8', page_content):
            url = m.group(0)
            playlist = self._fetch_source_playlist(url, info=info, language=language, filename=filename)
            if playlist:
                for s in playlist:
                    add(s["url"], direct=s["direct"])
            else:
                add(url)

        for m in re.finditer(r'https?://dramaclub24\.org/[^"\s<>]+\.mp4', page_content):
            add(m.group(0))

        for m in re.finditer(r'<iframe[^>]*(?:src|data-src)="([^"]+)"', page_content):
            url = m.group(1)
            if not url.startswith(self.base_link):
                add(url, direct=False)

        for m in re.finditer(r'<video[^>]*>.*?<source[^>]*src="([^"]+)"', page_content, re.DOTALL):
            add(m.group(1))

        fflog(f'[dramaclub24] znaleziono źródeł: {len(sources)}')
        return sources
