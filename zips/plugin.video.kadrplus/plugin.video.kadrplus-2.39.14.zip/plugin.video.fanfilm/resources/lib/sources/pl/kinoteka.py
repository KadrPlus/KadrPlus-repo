# -*- coding: UTF-8 -*-
"""
    Scraper dla kinoteka.cc
    Struktura URL:
      Szukanie:    /search.php?q=tytuł
      Film/serial: /watch.php?film=slug
      Odcinki:     /watch.php?film=slug&season=S&episode=E
"""
import re
from urllib.parse import quote_plus, urljoin

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from ptw.libraries import control, source_utils, cleantitle
from ptw.debug import fflog, fflog_exc


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['pl']

        self.base_link   = 'https://kinoteka.cc'
        self.search_link = '/search.php?q=%s'

        self.headers = {
            'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0',
            'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'Referer':         'https://kinoteka.cc/',
        }
        self.session = None
        # Cache odpowiedzi - nie pytamy dwa razy o ten sam URL
        self._cache = {}


    # ------------------------------------------------------------------ #
    #  Metody wymagane przez FanFilm                                       #
    # ------------------------------------------------------------------ #

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        fflog(f'{title=}  {localtitle=}  {year=}', 1)
        year_alt = kwargs.get('year_alt')
        if year_alt:
            year = (year, year_alt)
        return self._search(title, localtitle, year, 'movie')


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        fflog(f'{tvshowtitle=}  {localtvshowtitle=}  {year=}', 1)
        year_alt = kwargs.get('year_alt')
        if year_alt:
            year = (year, year_alt)
        return self._search(tvshowtitle, localtvshowtitle, year, 'tvshow')


    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        fflog(f'{url=}  {season=}  {episode=}', 1)
        if not url:
            return None
        return self._get_episode_url(url, int(season), int(episode))


    def sources(self, url, hostDict, hostprDict):
        sources = []
        fflog(f'{url=}', 1)
        if not url:
            return sources
        try:
            self._init_session()

            # Wyciagnij season/episode z URL jesli sa
            m_ep = re.search(r'[?&]season=(\d+)&(?:amp;)?episode=(\d+)', url)
            season_num = int(m_ep.group(1)) if m_ep else None
            episode_num = int(m_ep.group(2)) if m_ep else None

            # Pobierz strone glowna serialu (bez parametrow)
            show_url = re.sub(r'[?&]season=\d+.*', '', url) if m_ep else url
            html = self._get(show_url)
            if not html:
                fflog('brak odpowiedzi od serwera')
                return sources

            # Sprobuj wyciagnac JSON z osadzonymi zrodlami odcinkow
            episodes_data = self._extract_episodes_json(html) if season_num else None
            if episodes_data and season_num and episode_num:
                s_key = str(season_num)
                e_key = str(episode_num)
                ep_sources = episodes_data.get(s_key, {}).get(e_key, [])
                fflog(f'JSON: sezon={s_key} odcinek={e_key} zrodel={len(ep_sources)}', 1)
                links = []
                for src in ep_sources:
                    embed = src.get('embed_code', '').replace('\\\/', '/').strip()
                    if not embed or not embed.startswith('http'):
                        continue
                    quality = src.get('quality', 'SD')
                    version = src.get('version', '')
                    if 'lektor' in version.lower():
                        info = 'Lektor PL'
                    elif 'napisy' in version.lower() or 'sub' in version.lower():
                        info = 'Napisy PL'
                    elif 'dubbing' in version.lower():
                        info = 'Dubbing PL'
                    else:
                        info = version or ''
                    links.append({'url': embed, 'quality': quality, 'info': info})
            else:
                # Film lub fallback: wyciagnij zrodla ze statycznego HTML
                links = self._extract_sources(html)

            for link_data in links:
                link = link_data.get('url', '')
                if not link:
                    continue
                valid, hoster = source_utils.is_host_valid(link, hostDict)
                if not valid:
                    valid, hoster = source_utils.is_host_valid(link, hostprDict)
                if not valid:
                    from urllib.parse import urlsplit
                    hoster = urlsplit(link).hostname or link
                sources.append({
                    'source':     hoster,
                    'quality':    link_data.get('quality', 'SD'),
                    'language':   'pl',
                    'url':        link,
                    'info':       link_data.get('info', ''),
                    'direct':     False,
                    'debridonly': False,
                })
        except Exception:
            fflog_exc(1)
        fflog(f'przekazano źródeł: {len(sources)}')
        return sources


    def resolve(self, url):
        return url


    # ------------------------------------------------------------------ #
    #  Wyszukiwanie                                                        #
    # ------------------------------------------------------------------ #

    def _search(self, title, localtitle, year, content_type):
        """
        UWAGA: kinoteka.cc jest bardzo wolna (timeouty ~25s).
        Robimy MAKSYMALNIE 2 próby: tytuł PL i tytuł oryginalny.
        Aliasy celowo ignorujemy - każdy dodatkowy request to strata czasu.
        """
        try:
            self._init_session()

            # Normalizacja roku
            year_int = year_alt_int = None
            if isinstance(year, (tuple, list)):
                try: year_int     = int(year[0])
                except: pass
                try: year_alt_int = int(year[1])
                except: pass
            else:
                try: year_int = int(year)
                except: pass

            # Maksymalnie 2 tytuły do sprawdzenia: PL i oryginalny
            titles_to_try = []
            if localtitle and localtitle.lower() != title.lower():
                titles_to_try.append(localtitle)
            titles_to_try.append(title)
            # BRAK aliasów - strona jest zbyt wolna żeby iterować przez 20+ aliasów

            for search_title in titles_to_try:
                search_url = self.base_link + self.search_link % quote_plus(search_title)
                fflog(f'szukam: {search_url}', 1)

                html = self._get(search_url)
                if not html:
                    fflog(f'brak odpowiedzi dla: {search_url}', 1)
                    continue

                results = self._parse_search_results(html)
                fflog(f'znaleziono {len(results)} wyników dla "{search_title}"', 1)

                if not results:
                    continue

                match = self._find_best_match(results, search_title, year_int, year_alt_int)
                if match:
                    fflog(f'dopasowano: {match}', 1)
                    return match

            fflog(f'nic nie znaleziono dla {title!r}')
            return None

        except Exception:
            fflog_exc(1)
            return None


    def _parse_search_results(self, html):
        """
        Wyciąga wyniki ze struktury kinoteka.cc:
          <div class="movie-card" onclick="window.location.href=\'watch.php?film=SLUG\'">
            <div class="quality-badge quality-1080p">1080p</div>
            <div class="movie-overlay">
              <div class="movie-title">TYTUŁ</div>
              <div class="movie-meta"><span>2021</span>...</div>
            </div>
          </div>
        """
        results = []
        try:
            # Główny wzorzec - slug w onclick + zawartość karty
            cards = re.findall(
                r'<div class="movie-card"[^>]+watch\.php\?film=([\w-]+)[^>]+>(.*?)'
                r'</div>\s*</div>\s*</div>',
                html, re.DOTALL
            )

            if not cards:
                # Fallback - wyciągnij tylko slugi
                slugs = re.findall(r'watch\.php\?film=([\w-]+)', html)
                seen = set()
                for slug in slugs:
                    if slug not in seen:
                        seen.add(slug)
                        url = f'{self.base_link}/watch.php?film={slug}'
                        results.append({'url': url, 'title': '', 'year': None, 'slug': slug})
                if results:
                    fflog(f'fallback: znaleziono {len(results)} slugów', 1)
                return results

            for slug, card_html in cards:
                url = f'{self.base_link}/watch.php?film={slug}'

                # Tytuł
                title_m = re.search(r'<div class="movie-title">([^<]+)<', card_html)
                title = title_m.group(1).strip() if title_m else ''

                # Rok - pierwsza czysta <span> w movie-meta
                year_m = re.search(
                    r'<div class="movie-meta">.*?<span>(\d{4})<',
                    card_html, re.DOTALL
                )
                year = int(year_m.group(1)) if year_m else None

                # Jakość
                qual_m = re.search(r'quality-badge[^>]*>([^<]+)<', card_html)
                quality = qual_m.group(1).strip() if qual_m else ''

                fflog(f'  wynik: {title!r} ({year}) [{quality}] -> {slug}', 1)
                results.append({'url': url, 'title': title, 'year': year, 'slug': slug})

        except Exception:
            fflog_exc(1)

        return results


    def _find_best_match(self, results, search_title, year, year_alt):
        """Znajdź najlepiej pasujący wynik."""
        if not results:
            return None

        search_norm = cleantitle.normalize(cleantitle.getsearch(search_title))
        fflog(f'szukam dopasowania dla {search_norm!r} (rok={year})', 1)

        scored = []
        for r in results:
            result_norm = cleantitle.normalize(cleantitle.getsearch(r.get('title', '')))
            result_year = r.get('year')

            # Dopasowanie tytułu
            if search_norm == result_norm:
                title_score = 3
            elif search_norm in result_norm or result_norm in search_norm:
                title_score = 2
            elif result_norm:
                s_words = set(search_norm.split())
                r_words = set(result_norm.split())
                common = s_words & r_words
                if len(common) >= max(1, len(s_words) // 2):
                    title_score = 1
                else:
                    continue
            else:
                title_score = 0

            # Bonus/kara za rok
            year_score = 0
            if result_year and year:
                if result_year == year or result_year == year_alt:
                    year_score = 2
                else:
                    year_score = -1  # kara za zły rok

            scored.append((title_score + year_score, r['url']))
            fflog(f'  score={title_score + year_score}: {r.get("title")!r} ({result_year})', 1)

        if not scored:
            if len(results) == 1:
                fflog(f'fallback - 1 wynik: {results[0]["url"]}', 1)
                return results[0]['url']
            return None

        scored.sort(key=lambda x: x[0], reverse=True)
        return scored[0][1]


    # ------------------------------------------------------------------ #
    #  Odcinki seriali                                                     #
    # ------------------------------------------------------------------ #

    def _get_episode_url(self, show_url, season, episode):
        """Zwróć URL konkretnego odcinka serialu."""
        try:
            self._init_session()

            m = re.search(r'film=([^&]+)', show_url)
            if not m:
                fflog(f'brak sluga w {show_url}', 1)
                return None
            slug = m.group(1)

            # Pobierz stronę i sprawdź czy to faktycznie serial
            html = self._get(show_url)
            if not html:
                fflog(f'brak HTML dla {show_url}', 1)
                return None

            if not self._is_tvshow(html):
                fflog(f'strona nie wygląda jak serial (brak sezonów/odcinków) — odrzucam', 1)
                return None

            # Wyciągnij JSON z osadzonymi źródłami odcinków
            # Format: const episodes = {"1":{"1":[{...}],"2":[{...}]},"2":{...}}
            episodes_data = self._extract_episodes_json(html)
            ep_url = f'{self.base_link}/watch.php?film={slug}&season={season}&episode={episode}'
            if episodes_data:
                fflog(f'znaleziono JSON z odcinkami, sezony: {list(episodes_data.keys())}', 1)
            else:
                fflog(f'brak JSON z odcinkami — próbuję bezpośrednio', 1)
            fflog(f'zwracam: {ep_url}', 1)
            return ep_url

        except Exception:
            fflog_exc(1)
            return None


    def _extract_episodes_json(self, html):
        """Wyciagnij JSON z osadzonymi zrodlami wszystkich odcinkow serialu.
        Format w HTML: const episodes = {"1":{"1":[{embed_code, quality, version, season, episode}]}}
        """
        try:
            m = re.search(r'const\s+episodes\s*=\s*(\{.+?\});\s*\n', html, re.DOTALL)
            if not m:
                return None
            import json
            raw = m.group(1)
            raw = raw.replace('\\\/', '/')
            return json.loads(raw)
        except Exception:
            fflog_exc(1)
            return None

    def _is_tvshow(self, html):
        """Sprawdź czy strona to serial (ma sezon/odcinki) a nie film."""
        return bool(re.search(
            r'season=\d|episode=\d|sezon\s*\d|odcinek\s*\d|seria\s*\d',
            html, re.IGNORECASE
        ))

    def _find_episode_link(self, html, season, episode, slug):
        """Szukaj linku do odcinka w HTML strony serialu."""
        patterns = [
            rf"watch\.php\?film={re.escape(slug)}&(?:amp;)?season={season}&(?:amp;)?episode={episode}",
            rf"watch\.php\?film=[^'\"]*[sS]0*{season}[eE]0*{episode}",
        ]
        for pat in patterns:
            m = re.search(pat, html, re.IGNORECASE)
            if m:
                href = m.group(0)
                if not href.startswith('http'):
                    href = urljoin(self.base_link, href)
                return href
        return None


    def _has_player(self, html):
        return bool(re.search(r'iframe|\.mp4|\.m3u8|player|embed|data-src', html, re.IGNORECASE))


    # ------------------------------------------------------------------ #
    #  Wyciąganie źródeł wideo                                            #
    # ------------------------------------------------------------------ #

    def _detect_audio_type(self, html):
        """Wykryj typ audio z HTML strony kinoteki."""
        text = html.lower()
        if re.search(r'lektor|lektorski|voice.?over|pl.?dub(?:bed)?(?!\s*pl\s*sub)', text):
            return 'Lektor PL'
        if re.search(r'napisy|subtitle|pl.?sub|napis', text):
            return 'Napisy PL'
        if re.search(r'dubbing|dubbed|dub\b', text):
            return 'Dubbing PL'
        return ''

    def _detect_quality(self, html):
        """Wykryj jakość z HTML strony lub nazwy pliku."""
        m = re.search(
            r'\b(2160p?|4[Kk]|UHD|1080p?|720p?|480p?|HDRip|BRRip|BluRay|WEB.?DL|WEBRip)\b',
            html, re.IGNORECASE
        )
        if m:
            q = m.group(1).upper().replace('-', '').replace('.', '')
            if '2160' in q or '4K' in q or 'UHD' in q: return '4K'
            if '1080' in q: return '1080p'
            if '720' in q: return '720p'
        return 'SD'

    def _extract_sources(self, html):
        """Wyciągnij linki do źródeł wideo ze strony watch.php."""
        links = []
        seen = set()

        audio_info = self._detect_audio_type(html)
        page_quality = self._detect_quality(html)

        # Domeny które na pewno NIE są playerami wideo - ignorujemy
        SKIP_DOMAINS = (
            'image.tmdb.org', 'tmdb.org', 'imgur.com', 'cloudflare',
            'cdnjs.cloudflare', 'font-awesome', 'googleapis.com',
            'gstatic.com', 'acscdn.com', '.css', '.js', '.png',
            '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.ico',
        )

        def add(url, quality='SD', info=''):
            url = url.strip()
            # Odescapuj backslashe z JSON-a: https:\/\/streamtape.com -> https://streamtape.com
            url = url.replace('\/', '/')
            if url.startswith('//'):
                url = 'https:' + url
            if not url or not url.startswith('http'):
                return
            if 'kinoteka' in url:
                return
            if any(skip in url for skip in SKIP_DOMAINS):
                return
            if url not in seen:
                seen.add(url)
                links.append({'url': url, 'quality': quality, 'info': info})
                fflog(f'znaleziono źródło: {url}', 1)

        # 1. iframe src=
        for m in re.finditer(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE):
            add(m.group(1), page_quality, audio_info)

        # 2. data-src, data-url, data-embed, data-video, data-file
        for attr in ('data-src', 'data-url', 'data-embed', 'data-video', 'data-file'):
            for m in re.finditer(rf'{attr}=["\']([^"\']+)["\']', html, re.IGNORECASE):
                add(m.group(1), page_quality, audio_info)

        # 3. JavaScript: file/src/url/link: 'https://...'
        for m in re.finditer(
            r'(?:file|src|source|url|link)\s*[=:]\s*["\']([^"\']{15,})["\']',
            html, re.IGNORECASE
        ):
            val = m.group(1)
            if val.startswith('http') or val.startswith('//'):
                add(val, page_quality, audio_info)

        # 4. Bezpośrednie linki .mp4 / .m3u8
        for m in re.finditer(r'["\']([^"\']+\.(?:mp4|m3u8)[^"\']*)["\']', html, re.IGNORECASE):
            add(m.group(1), page_quality, audio_info)

        # 5. Linki do znanych zewnętrznych playerów
        known = ('cda.pl', 'streamtape', 'vk.com', 'ok.ru', 'dailymotion', 'dood.', 'upstream')
        for m in re.finditer(r'href=["\']([^"\']+)["\']', html, re.IGNORECASE):
            if any(h in m.group(1) for h in known):
                add(m.group(1), page_quality, audio_info)

        fflog(f'wyciągnięto łącznie {len(links)} źródeł', 1)
        return links


    # ------------------------------------------------------------------ #
    #  Pomocnicze                                                          #
    # ------------------------------------------------------------------ #

    def _init_session(self):
        if not self.session:
            import requests
            self.session = requests.Session()
            self.session.headers.update(self.headers)


    def _get(self, url, timeout=(8, 40)):
        """
        Pobierz stronę i zwróć HTML lub None przy błędzie.
        timeout=(connect_timeout, read_timeout):
          - 8s na nawiązanie połączenia
          - 20s na odebranie odpowiedzi
        Wyniki są cachowane - ten sam URL nie jest pobierany dwa razy.
        """
        if url in self._cache:
            fflog(f'cache hit: {url}', 1)
            return self._cache[url]
        try:
            fflog(f'GET {url}', 1)
            r = self.session.get(url, headers=self.headers, timeout=timeout, verify=False)
            if r is None or r.status_code >= 400:
                fflog(f'HTTP {r.status_code if r else "None"} dla {url}', 1)
                self._cache[url] = None
                return None
            fflog(f'HTTP {r.status_code}, rozmiar: {len(r.text)} znaków', 1)
            self._cache[url] = r.text
            return r.text
        except Exception:
            fflog_exc(1)
            self._cache[url] = None
            return None
