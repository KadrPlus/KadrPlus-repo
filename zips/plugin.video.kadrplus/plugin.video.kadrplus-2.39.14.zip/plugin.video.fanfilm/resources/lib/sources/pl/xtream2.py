# -*- coding: utf-8 -*-

import time
import re
import unicodedata
import os
import xbmcaddon
import urllib.request
import urllib.parse
import urllib.error

import hashlib
import json
# from ast import literal_eval
from ptw.libraries import cache
from ptw.libraries import cleantitle, source_utils
from ptw.debug import fflog, fflog_exc


class source:

    def __init__(self):
        self.priority = 1
        self.language = ['pl']
        self.useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0'
        self.x_sources = []  # lista źródeł:  {'type': 'file'/'url', 'path': ścieżka/URL}
        self.search_mode = 'all'  # 'first' - pierwsze znalezione, 'all' - wszystkie pasujące
        self.all_found_urls = []  # TU JEST KLUCZ: przechowuje wszystkie URL znalezione w trybie "all"
        self.all_entries = []
        self.all_entries_movies = []
        self.all_entries_tvshows = []
        self.url = ''


    @staticmethod
    def get_data_hash(data_obj):
        # 1. Normalizacja: sort_keys=True jest KLUCZOWE
        # separator pozbywa się zbędnych spacji, co ujednolica string
        normalized_json = json.dumps(data_obj, sort_keys=True, separators=(',', ':'))
        return hashlib.sha256(normalized_json.encode('utf-8')).hexdigest()


    def _get_x_sources(self):
        """Pobiera listę źródeł z ustawień FanFilm."""
        try:
            addon = xbmcaddon.Addon()
            sources = []
            
            # # Pobierz tryb wyszukiwania
            # self.search_mode = addon.getSetting('xtream2.search_mode') or '0'
            
            # # Konwersja z wartości enum (0/1) na tekst
            # if self.search_mode == '0':
                # self.search_mode = 'first'
            # elif self.search_mode == '1':
                # self.search_mode = 'all'
            # else:
                # # domyślnie
                # self.search_mode = 'first'
                # self.search_mode = 'all'


            url = addon.getSetting('xtream2.server').rstrip('/').strip() or ''
            if url and (url.startswith('http://') or url.startswith('https://')):
                username = addon.getSetting('xtream2.username').strip() or ''
                password = addon.getSetting('xtream2.password').strip() or ''
                url = f'{url}/player_api.php?username={username}&password={password}'
                # fflog(f'{url=}', 1,1)
                self.url = url
                sources.append({'type': 'url', 'path': url})

            sources = [source for x, source in enumerate(sources) if source not in sources[:x]]  # eliminacja dubli
            if sources:
                fflog(f'xtream2: {len(sources)}  tryb: {self.search_mode}', 1, 1)
            else:
                fflog(f'{len(sources)=}', 1,1)
            # fflog(f'{len(sources)=}  {sources=}', 1,1)

            try:
                prev_hash_sources = cache.cache_get("xtream2.settings_sources")["value"]
            except:
                prev_hash_sources = ''
            curr_hash_sources = self.get_data_hash(sources)
            if curr_hash_sources != prev_hash_sources:
                fflog(f'wykryto zmianę ustawień źródeł - nastąpi wyczyszczenie cache wpisów', 1,1)
                cache.cache_insert("xtream2.all_entries.tvshows", '')
                cache.cache_insert("xtream2.all_entries.movies", '')
                cache.cache_insert("xtream2.settings_sources", curr_hash_sources)
                time.sleep(0.1)

            return sources
            
        except Exception as e:
            fflog(f'xtream2: błąd odczytu ustawień: {e}', 1, 1)
            fflog_exc(1)
            return []


    def _download_from_url(self, url, timeout=40):
        """Pobiera zawartość z URL."""
        try:
            # fflog(f'{url=}',1,1)
            if not url:
                fflog(f'błąd, bo {url=}',1,1)
                return None
            req = urllib.request.Request(
                url,
                headers={
                    'User-Agent': self.useragent,
                    'Accept': '*/*',
                    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                    'Connection': 'keep-alive'
                }
            )
            with urllib.request.urlopen(req, timeout=timeout) as response:
                if 1:
                    # fflog(f'{response.headers}',1,1)
                    content_length = response.headers.get('Content-Length')
                    if content_length:
                        file_size_mb = int(content_length) / (1024 * 1024)
                        if file_size_mb > (0.01 * 1024 * 1024):
                            fflog(f'do pobrania {file_size_mb:.2f} MB',1,1)
                            pass
                content = response.read()
                if len(content) > (0.01 * 1024 * 1024):
                    fflog(f'pobrano {len(content) / (1024*1024):.2f} MB',1,1)
                    pass
                # return json.loads(response.read().decode('utf-8'))
                # Spróbuj różne kodowania
                try:
                    return content.decode('utf-8')
                except UnicodeDecodeError:
                    try:
                        return content.decode('latin-1')
                    except UnicodeDecodeError:
                        return content.decode('utf-8', errors='ignore')
                        
        except urllib.error.URLError:
            fflog_exc(1)
            return None
        except Exception:
            fflog_exc(1)
            return None


    def _is_cyrillic(self, text):
        """Sprawdza czy tekst zawiera cyrylicę."""
        # fflog('_is_cyrillic',1,1)
        if not text:
            return False
        
        # Zakresy Unicode dla cyrylicy
        cyrillic_ranges = [
            (0x0400, 0x04FF),  # Cyrillic
            (0x0500, 0x052F),  # Cyrillic Supplement
            (0x2DE0, 0x2DFF),  # Cyrillic Extended-A
            (0xA640, 0xA69F),  # Cyrillic Extended-B
        ]
        
        for char in text:
            code = ord(char)
            for start, end in cyrillic_ranges:
                if start <= code <= end:
                    # fflog('koniec _is_cyrillic',1,1)
                    return True
        # fflog('koniec _is_cyrillic',1,1)
        return False


    def _transliterate_cyrillic(self, text):
        """Transliteracja tekstu cyrylickiego na łaciński."""
        # fflog('_transliterate_cyrillic',1,1)
        
        if not text:
            return text
        
        # Jeśli nie ma cyrylicy, zwróć oryginał
        if not self._is_cyrillic(text):
            return text
        
        # Słownik transliteracji rosyjskiej
        cyrillic_map = {
            'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd',
            'е': 'e', 'ё': 'yo', 'ж': 'zh', 'з': 'z', 'и': 'i',
            'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n',
            'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't',
            'у': 'u', 'ф': 'f', 'х': 'kh', 'ц': 'ts', 'ч': 'ch',
            'ш': 'sh', 'щ': 'shch', 'ъ': '', 'ы': 'y', 'ь': '',
            'э': 'e', 'ю': 'yu', 'я': 'ya',
            'А': 'a', 'Б': 'b', 'В': 'v', 'Г': 'g', 'Д': 'd',
            'Е': 'e', 'Ё': 'yo', 'Ж': 'zh', 'З': 'z', 'И': 'i',
            'Й': 'y', 'К': 'k', 'Л': 'l', 'М': 'm', 'Н': 'n',
            'О': 'o', 'П': 'p', 'Р': 'r', 'С': 's', 'Т': 't',
            'У': 'u', 'Ф': 'f', 'Х': 'kh', 'Ц': 'ts', 'Ч': 'ch',
            'Ш': 'sh', 'Щ': 'shch', 'Ъ': '', 'Ы': 'y', 'Ь': '',
            'Э': 'e', 'Ю': 'yu', 'Я': 'ya'
        }
        
        result = []
        for char in text:
            if char in cyrillic_map:
                result.append(cyrillic_map[char])
            else:
                result.append(char)
        # fflog('koniec _transliterate_cyrillic',1,1)
        return ''.join(result)


    def _normalize_x_title(self, title):
        """Normalizacja tytułu """
        if not title:
            return '', None
        
        # 1. Wyodrębnij rok z tytułu
        year_match = re.search(r'\((\d{4})\)', title)
        year = (year_match.group(1)) if year_match else None
        
        # 2. Usuń rok z tytułu
        if year:
            # title = re.sub(r'\s*\(\d{4}\)\s*', '', title)
            # title = re.sub(fr'\s*\({year}\)\s*', '', title)
            # title = title.replace(year, '').replace('()', '').strip()
            title = title.split(year)[0].rstrip('(')
            # year = int(year)
        
        # 3. Zamień podkreślniki na spacje
        title = title.replace('_', ' ')
        
        # 4. Transliteruj TYLKO cyrylicę
        title = self._transliterate_cyrillic(title)
        
        # 5. Użyj oryginalnego cleantitle.get()
        title_clean = cleantitle.get(title)
        return title_clean, year


    def _normalize_search_title(self, title):
        """Normalizacja tytułu do wyszukiwania."""
        # fflog('_normalize_search_title',1,1)
        if not title:
            return ''
        
        # Transliteruj TYLKO jeśli zawiera cyrylicę
        title = self._transliterate_cyrillic(title)
        # fflog('koniec _normalize_search_title',1,1)
        return cleantitle.get(title)


    def get_cached_x(self, episode=None):
        """Pobiera wszystkie listy ze wszystkich źródeł."""
        # fflog('get_cached_x',1,1)
        try:
            if not self.x_sources:
                self.x_sources = self._get_x_sources()

            if not self.x_sources:
                return None

            if self.all_entries:
                return self.all_entries
            else:
                try:
                    if episode:
                        self.all_entries = json.loads(cache.cache_get("xtream2.all_entries.tvshows")["value"])
                    else:
                        self.all_entries = json.loads(cache.cache_get("xtream2.all_entries.movies")["value"])
                    fflog('pobrano z cache',1,1)
                    return self.all_entries
                except:
                    pass
            
            all_entries = []

            # fflog(f'{len(self.x_sources)=}',1,1)
            for source_info in self.x_sources:

                source_type = source_info['type']
                source_path = source_info['path']
                # source_name = f"{source_type}:{os.path.basename(source_path) if source_type == 'file' else 'url'}"
                source_name = ""
                
                content = None
                
                if source_type == 'file':
                    pass
                    # # Plik lokalny
                    # if not os.path.exists(source_path):
                        # continue
                    
                    # try:
                        # with open(source_path, "r", encoding="utf-8") as f:
                            # content = f.read()
                    # except UnicodeDecodeError:
                        # try:
                            # with open(source_path, "r", encoding="latin-1") as f:
                                # content = f.read()
                        # except Exception:
                            # continue
                    # except Exception:
                        # continue
                
                elif source_type == 'url':
                    # URL

                    # kategorie
                    if episode:
                        source_path += "&action=get_series_categories"
                    else:
                        source_path += "&action=get_vod_categories"
                    content = self._download_from_url(source_path)
                    if content:
                        # entries = self._parse_x(content, source_name)
                        categories = json.loads(content)
                    else:
                        categories = []
                    fflog(f'{len(categories)=}',1,1)

                    # index
                    if episode:
                        source_path += "&action=get_series"
                    else:
                        source_path += "&action=get_vod_streams"
                    content = self._download_from_url(source_path)

                    if not content:
                        continue
                
                if content:
                    # entries = self._parse_x(content, source_name)
                    entries = json.loads(content)

                    if 1:
                        cat_map = {d["category_id"]: d["category_name"] for d in categories}

                        niechciane_frazy = ['kabarety', 'silownia', 'siłownia', 'fitness', 'dieta', 'zdrowie',
                                            'gry', 'komputer', 'przepisy', 'poradniki', 'gadżety', 'zapowiedzi',
                                            'sport', 'karaoke', 'przewodnik', 'mecz', 'nba', 'piłka', 'eurosport', 'hokej', 'karate', 'teledyski',
                                            'nauka jezykow', 'nauka języków', 'podcast',
                                            'ppv',
                                            ]

                        keep = ['name', 'tmdb', 'stream_id', 'series_id', 'container_extension', 'direct_source']

                        entries = [
                            {
                                **{k: e[k] for k in keep if k in e},  # Kopiujemy tylko wybrane klucze
                                # dodajemy nowe pola
                                "category_name": category_name,
                                "title_clean": (_ := self._normalize_x_title(e.get("name")))[0],
                                "year": _[1],
                            } 
                            for e in entries
                                if e.get('container_extension') != 'mp3'
                                    and all(kw not in (category_name := cat_map.get(e.get("category_id"), "")).lower() for kw in niechciane_frazy)
                        ]

                        if 0:
                            entries_bez_tmdb = [e for e in entries if not e.get('tmdb')]
                            fflog(f'{len(entries_bez_tmdb)=}',1,1)
                            if entries_bez_tmdb:
                                fflog(f'entries_bez_tmdb={json.dumps(entries_bez_tmdb, indent=2)}',1,1)
                                pass

                    all_entries.extend(entries)
            
            # if all_entries:
            fflog(f'xtream2: Załadowano {len(all_entries)} wpisów ', 1, 1)
            self.all_entries = all_entries
            # if episode:
                # self.all_entries_tvshows = all_entries
            # else:
                # self.all_entries_movies = all_entries
            fflog(f'{len(all_entries)=}',1,1)
            if all_entries:
                try:
                    if episode:
                        cache.cache_insert("xtream2.all_entries.tvshows", json.dumps(all_entries))  # wstawienie do bazy
                    else:
                        cache.cache_insert("xtream2.all_entries.movies", json.dumps(all_entries))  # wstawienie do bazy
                    fflog('zapisano do cache',1,1)
                except:
                    pass
            return all_entries
            
        except Exception as e:
            fflog(f'xtream2: Błąd w get_cached_x: {e}', 1, 1)
            fflog_exc(1)
            return None


    def _search_items(self, title, year=None, season=None, episode=None, tmdb=None):
        # fflog(f'{title=}  {year=}  {season=}  {episode=}  {tmdb=}',1,1)
        """Wyszukiwanie filmu we wszystkich listach """
        entries = self.get_cached_x(episode=episode)
        # fflog(f'{len(entries)=}',1,1)
        if not entries:
            return [] if self.search_mode == 'all' else None
        
        found_urls = []

        # tmdb = None  # testy tylko
        if tmdb:
            for e in entries:
                if tmdb == e['tmdb']:
                    if episode:
                        found_urls.append((e['series_id'], e['name'], season, episode, e['category_name']))
                        if self.search_mode == 'first':
                            break
                    else:
                        found_urls.append((e['stream_id'], e['name'], e['container_extension'], e['category_name']))
                        if self.search_mode == 'first':
                            break

        if found_urls:
            # fflog('dopasowano wg identyfikatora tmdb',1,1)
            if 1:  # zastanowić się
                if self.search_mode == 'first':
                    return found_urls[0]
                else:
                    return found_urls

        if 1:
            # fflog('nie dopasowano wg identyfikatora tmdb - będą próby po nazwie',1,1)

            search_title_clean = self._normalize_search_title(title)  # szukany tytuł
            if episode:
                # search_title_clean += f"s{season:>02}e{episode:>02}"
                pass
            fflog(f'{search_title_clean=}',1,1)

            # trzeba rok wyodrębnić
            # 1. Najpierw próbuj dokładne dopasowanie z rokiem
            for e in entries:
                # fflog(f'1) {e=}',1,1)
                # fflog(f"1) {e['title_clean']=}",1,1)
                if search_title_clean == e['title_clean']:
                    # fflog(f"1) dopasowano tytuł {e['title_clean']=}",1,1)
                    if year and e['year']:
                        # fflog(f"1) kontrola roku {e['year']=} {e['title_clean']=}",1,1)
                        if year == e['year']:
                            # fflog(f"1) potwierdzono także rok {e['year']=} {e['title_clean']=}",1,1)
                            if episode:
                                found_urls.append((e['series_id'], e['name'], season, episode, e['category_name']))
                                if self.search_mode == 'first':
                                    break
                            else:
                                found_urls.append((e['stream_id'], e['name'], e['container_extension'], e['category_name']))
                                if self.search_mode == 'first':
                                    break
                        else:
                            # fflog(f"1) brak zgodnosci roku rok {e['year']=} {e['title_clean']=}",1,1)
                            pass

                    else:
                        # fflog(f"1) brak roku {e['year']=} {e['title_clean']=}",1,1)
                        if episode:
                            found_urls.append((e['series_id'], e['name'], season, episode, e['category_name']))
                            if self.search_mode == 'first':
                                break
                        else:
                            found_urls.append((e['stream_id'], e['name'], e['container_extension'], e['category_name']))
                            if self.search_mode == 'first':
                                break
            
            if found_urls and self.search_mode == 'first':
                return found_urls[0]
            
            # 2. Jeśli nie znaleziono z rokiem, spróbuj BEZ roku
            if year:
                for e in entries:
                    # fflog(f'2) {e=}',1,1)
                    # fflog(f"2) {e['title_clean']=}",1,1)
                    if search_title_clean == e['title_clean']:
                        # fflog(f"2) dopasowano tytuł {e['title_clean']=}",1,1)
                        if episode:
                            found_urls.append((e['series_id'], e['name'], season, episode, e['category_name']))
                            if self.search_mode == 'first':
                                break
                        else:
                            found_urls.append((e['stream_id'], e['name'], e['container_extension'], e['category_name']))
                            if self.search_mode == 'first':
                                break
            
            if found_urls and self.search_mode == 'first':
                return found_urls[0]
            
            # 3. Próbuj częściowe dopasowanie
            for e in entries:
                # fflog(f'3) {e=}',1,1)
                # fflog(f"3) {e['title_clean']=}",1,1)
                if search_title_clean in e['title_clean'] or len(e['title_clean']) > 3 and e['title_clean'] in search_title_clean:
                    # fflog(f"3) dopasowano tytuł {e['title_clean']=}",1,1)
                    if 0:
                        if not episode and re.search(r's\d{2}e\d{2,4}$', e['title_clean']):
                            # continue
                            pass
                        if episode and not re.search(r's\d{2}e\d{2,4}$', e['title_clean']):
                            # continue
                            pass
                    if year and e['year']:
                        if year == e['year']:
                            # fflog(f"3) dopasowano z rokiem {e['year']=} {e['title_clean']=}  {search_title_clean=}",1,1)
                            if episode:
                                found_urls.append((e['series_id'], e['name'], season, episode, e['category_name']))
                                if self.search_mode == 'first':
                                    break
                            else:
                                found_urls.append((e['stream_id'], e['name'], e['container_extension'], e['category_name']))
                                if self.search_mode == 'first':
                                    break
                        else:
                            # fflog(f"3) brak zgodnosci roku rok {e['year']=} {e['title_clean']=}",1,1)
                            pass

                    else:
                        # fflog(f"3) dopasowano bez roku {e['year']=} {e['title_clean']=}  {search_title_clean=}",1,1)
                        if episode:
                            found_urls.append((e['series_id'], e['name'], season, episode, e['category_name']))
                            if self.search_mode == 'first':
                                break
                        else:
                            found_urls.append((e['stream_id'], e['name'], e['container_extension'], e['category_name']))
                            if self.search_mode == 'first':
                                break

            if found_urls:
                fflog(f'{len(found_urls)=}',1,1)
                if self.search_mode == 'first':
                    return found_urls[0]
                else:
                    return found_urls
        
        return [] if self.search_mode == 'all' else None


    def get_movie_info(self, stream_id):
        url = self.url
        url += f"&action=get_vod_info&vod_id={stream_id}"
        content = self._download_from_url(url)
        if not content:
            fflog(f'problem, bo {content=}',1,1)
            result = None
        else:
            # entries = self._parse_x(content, source_name)
            result = json.loads(content)
        return result


    def _get_episode(self, series_id, season, episode):
        url = self.url
        url += f"&action=get_series_info&series_id={series_id}"
        content = self._download_from_url(url)
        if not content:
            fflog(f'problem, bo {content=} a to jest serial, czyli nie znaleziono odcinków',1,1)
            # continue
            result = None
        else:
            # entries = self._parse_x(content, source_name)
            result = json.loads(content)
            result = result['episodes'].get(str(season))
            if result:
                e = {}
                try:
                    if 0:
                        e = result[int(episode) - 1]  # jest jeszcze ryzyko, że odcinki nie będą po kolei
                    else:
                        for ep in result:
                            if int(ep.get('episode_num', 0)) == int(episode):
                                e = ep
                                break
                except Exception:
                    fflog_exc(1)
                    # e = {}
                    fflog(f'brak odcinka {episode=}',1,1)
                if e:
                    # result = (e['id'], e['title'], e['container_extension'], 'series')
                    result = e
                    fflog(f'xtream2: ✓ Znaleziono odcinek {e["episode_num"]=}  {e["season"]=}', 1, 1)
                else:
                    result = None
            else:
                fflog(f'brak sezonu {season=}',1,1)
        return result


    def search(self, title, localtitle, aliases, year, season=None, episode=None, tmdb=None):
        """Główna metoda wyszukiwania"""
        try:
            # DEBUG: podsumowanie danych z TMDB
            fflog(f'xtream2: Szukam filmu: "{title}" / "{localtitle}", rok: {year}  {tmdb=}  {season=}  {episode=}', 1, 1)
            
            # Lista kandydatów
            candidates = []
            
            # 1. Tytuł lokalny (polski)
            if localtitle:
                candidates.append(localtitle)
            
            # 2. Tytuł oryginalny
            if title:
                candidates.append(title)
            
            # 3. WSZYSTKIE aliasy z TMDB (wszystkie języki)
            if aliases and isinstance(aliases, list):
                for alias in aliases:
                    if isinstance(alias, dict):
                        alias_title = alias.get('title') or alias.get('originalname')
                        if alias_title and alias_title not in candidates:
                            # fflog(f'{alias_title=}',1,1)
                            alias_title = alias_title.replace(year, '').strip()
                            # fflog(f'{alias_title=}',1,1)
                            candidates.append(alias_title)
            
            # Usuń duplikaty
            unique_candidates = []
            seen = set()
            for candidate in candidates:
                if candidate and candidate not in seen:
                    seen.add(candidate)
                    unique_candidates.append(candidate)
            
            # Próbuj każdego kandydata
            all_found_urls = []  # Zbierz wszystkie URL dla trybu "all"

            fflog(f'{len(unique_candidates)=}',1,1)
            for candidate in unique_candidates:
                # fflog(f'{candidate=}',1,1)
                result = self._search_items(candidate, year, season, episode, tmdb)
                # fflog(f'{result=}',1,1)
                if result:
                    if self.search_mode == 'first':
                        fflog(f'xtream2: ✓ Znaleziono URL', 1, 1)
                        if episode:
                            # result = self._get_episode(result[0], season, episode)
                            pass
                        return result
                    else:
                        # W trybie "all" result to lista URL
                        if isinstance(result, list):
                            for url in result:
                                if url and url not in all_found_urls:
                                    if episode:
                                        # url = self._get_episode(url[0], season, episode)
                                        pass
                                    all_found_urls.append(url)
                if tmdb:
                    # break
                    pass
            
            if self.search_mode == 'all' and all_found_urls:
                # Zapisz wszystkie znalezione URL do zmiennej instancji
                self.all_found_urls = all_found_urls
                fflog(f'xtream2: Znaleziono {len(all_found_urls)} źródeł', 1, 1)
                
                # Zwróć pierwszy URL (reszta będzie w sources())
                return all_found_urls[0] if all_found_urls else None
            
            return None
            
        except Exception:
            fflog_exc(1)


    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        tmdb = kwargs.get('tmdb')
        return self.search(title, localtitle, aliases, year, tmdb=tmdb)


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return (tvshowtitle, localtvshowtitle), year, aliases


    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        title = url[0][0]
        localtitle = url[0][1]
        year = url[1]
        aliases = url[2]
        aliases = None
        tmdb = kwargs.get('tmdb')
        return self.search(title, localtitle, aliases, year, season, episode, tmdb)


    def sources(self, url, hostDict, hostprDict):
        try:
            # fflog('sources',1,1)
            if not url:
                fflog(f'{url=}',1,1)
                return []

            # fflog(f'{type(url)=}  {len(url)=}',1,1)

            if not self.url:
                self._get_x_sources()

            # W trybie "all" używamy wszystkich zapisanych URL
            if self.search_mode == 'all' and hasattr(self, 'all_found_urls') and self.all_found_urls:
                all_urls = self.all_found_urls
            else:
                # W trybie "first" lub jeśli nie ma zapisanych źródeł
                fflog(f'brak zapisanych źródeł',1,1)
                all_urls = [url] if url else []
            # fflog(f'{len(all_urls)=}',1,1)

            sources_list = []
            
            for movie_url in all_urls:
                try:
                    # fflog(f'{movie_url=}',1,1)
                    group_title = ''
                    if isinstance(movie_url, tuple):  # musi tak być
                        # fflog(f'{len(movie_url)=}',1,1)
                        if len(movie_url) == 5:
                            stream_id, title, season, episode, group_title = movie_url
                        else:
                            stream_id, title, container_extension, group_title = movie_url
                            episode = season = None
                    else:  # nie może tak być
                        fflog(f'jakiś problem, bo {type(movie_url)=} i będzie wyzerowany title',1,1)
                        title = ''

                    if episode:
                        einfo = self._get_episode(stream_id, season, episode)
                        if einfo:
                            stream_id, title, container_extension = (einfo['id'], einfo['title'], einfo['container_extension'])
                    else:
                        einfo = self.get_movie_info(stream_id)

                    movie_url = self.url
                    movie_url = movie_url.replace('player_api.php', 'series' if episode else 'movie')
                    movie_url = movie_url.replace('?username=', '/').replace('&password=', '/')
                    movie_url += f"/{stream_id}.{container_extension}"
                    # fflog(f'{movie_url=}',1,1)

                    source_info = ""
                    
                    host_match = re.search(r'https?://(?:www\.)?([^:/]+)', movie_url)
                    host_name = host_match.group(1) if host_match else ''
                    host_name = host_name.rsplit('.', 2)[-2] if '.' in host_name else host_name

                    unsure = None
                    if einfo:
                        try:
                            quality = einfo['info']['video']['height']
                            quality = einfo['info']['video']['width']
                            # fflog(f'{quality=}',1,1)
                            quality = source_utils.label_to_quality(str(quality), by_width=True)
                            # fflog(f'{quality=}',1,1)
                        except Exception:
                            fflog_exc(1)
                            pass
                            quality = ''
                    if not quality:
                        quality = '1080p'  # na sztywno
                        unsure = ["quality"]
                        if title:
                            # fflog(f'do sprawdzania jakości: {title + f" | {group_title}"}',1,1)
                            quality = source_utils.get_qual(title + f" | {group_title}")
                            # fflog(f'{quality=}  {title=}',1,1)
                            if not quality or quality == 'SD' and 'SD' not in title:
                                if 'FHD' in title:
                                    quality = '1080p'
                                elif ' HD' in title:
                                    quality = '720p'
                                else:
                                    quality = '1080p'  # na sztywno
                                pass
                            else:
                                unsure = None
                            pass

                    info = ''
                    tech_info = ''
                    try:
                        codec_name = einfo['info']['video']['codec_name']
                        if codec_name not in 'h264':
                            tech_info += codec_name + ', '
                    except Exception:
                        fflog_exc(1)
                        pass

                    try:
                        codec_name = einfo['info']['audio']['codec_name']
                        if codec_name not in 'aac mpeg':  # bo to popularne
                            tech_info +=  codec_name + ''
                        if einfo['info']['audio']['channels'] != 2:
                            tech_info += " " + einfo['info']['audio']['channel_layout'].split('(')[0]
                    except Exception:
                        fflog_exc(1)
                        pass

                    language = ''
                    try:
                        language = einfo['info']['audio']['tags']['language']  # nie zawsze to jest
                        # info_for_lang = einfo['info']['audio']['disposition']  # tu może być info o napisach, dubingu
                        # fflog(f'{info_for_lang=}  {title=}',1,1)
                    except Exception:
                        # fflog_exc(1)
                        # fflog(f"{json.dumps(einfo['info'], indent=2)}",1,1)
                        pass

                    if language == 'pol':
                        language = 'pl'
                        pass
                    if language != 'pl': 
                        language, info_for_lang = source_utils.get_lang_by_type(title + f' | {group_title}')
                        info += info_for_lang + ' | '
                    
                    tech_info = tech_info.replace('  ', ' ').replace(' | | ', ' | ').strip(' |')
                    if tech_info:
                        info += f" | ({tech_info})"

                    if 1:  # do debugu się przydaje
                        title = title.strip(' |')
                        if 1:
                            title += f' | {group_title}'  # nazwa kategorii w jakiej zostało to umieszczone
                        title = title.strip(' |')
                        if 0:
                            title += f' | {movie_url.rpartition("/")[-1]}'  # nazwa pliku, ale to tylko numer
                    title = title.replace(' | | ', ' | ').strip(' |')
                    title = title.replace('  ', ' ')

                    source_entry = {
                        # 'provider': 'dupa',  # tylko, że sie resolver nie wywoła
                        # 'source': source_info,
                        'source': host_name,
                        'quality': quality,
                        'language': language,
                        'url': movie_url,
                        'info': info.strip(' |'),
                        'info2': ' ',
                        'info2': title,
                        # 'filename': title,
                        'direct': True,
                        'debridonly': False,
                        'premium': True,
                    }
                    
                    # Dodaj informację o źródle w nazwie (dla użytkownika)
                    # przeniosłem to wyżej
                    # if self.search_mode == 'all':
                        # source_entry['info'] = f"{host_name} ({source_info})"
     
                    if unsure:
                        source_entry['unsure'] = unsure
                        pass
     
                    sources_list.append(source_entry)

                except Exception:
                    fflog_exc(1)
            
            # Wyczyść zapisane URL po użyciu
            if hasattr(self, 'all_found_urls'):
                self.all_found_urls = []
            # fflog('koniec sources',1,1)
            return sources_list
            
        except Exception:
            fflog_exc(1)
            return []


    def resolve(self, url):
        if 1:
            return url + "|User-Agent=vlc&verifypeer=false"
        return url


    def check_account(self):
        fflog(f'checking ... ',1,1)
        try:
            if not self.url:
                self._get_x_sources()
            content = self._download_from_url(self.url)
            if not content:
                fflog(f'problem, bo {content=}',1,1)
            else:
                content = json.loads(content)
            username = ''
            if content:
                # fflog(f'content={json.dumps(content, indent=2)}',1,1)
                server_time = content.get("server_info", {}).get("time_now")
                fflog(f'{server_time=}',1,1)
                content = content.get("user_info", {})
                from datetime import datetime
                exp_date = str(datetime.fromtimestamp(int(content.get('exp_date') or 0)))
                username = content.get('username')
                results = ''
                # results += f" username: {content.get('username')}"
                results += f" status: {content.get('status')}"
                results += f"\n exp_date: {exp_date}"
                results += f"\n max_connections: {content.get('max_connections')}"
                results += f"\n active_cons: {content.get('active_cons')}"
                results += f"\n is_trial: {content.get('is_trial')}"
                # fflog(f'\n{results}',1,1)
            else:
                results = "Problem z otrzymaniem danych"
            import xbmcgui
            tytul_okna = '[LIGHT]Informacje o koncie[/LIGHT]'
            if username:
                tytul_okna += f" {username}"
            xbmcgui.Dialog().ok(tytul_okna, results)
        except Exception:
            fflog_exc(1)