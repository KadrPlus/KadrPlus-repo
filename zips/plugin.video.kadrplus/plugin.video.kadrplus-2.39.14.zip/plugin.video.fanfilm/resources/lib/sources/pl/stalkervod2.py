
import re

from urllib.parse import urlsplit

from ptw.libraries import source_utils
from ptw.libraries import control, cache

from ptw.debug import fflog, fflog_exc


# import requests
# import urllib3
# urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import json


class source:

    def __init__(self):
        self.priority = 1
        self.language = ["pl"]


    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        # fflog(f'{title=}  {localtitle=}  {year=}  {kwargs=}  {aliases=}',1,1)
        tmdb = kwargs.get("tmdb", "")
        return self.search(title, localtitle, year, tmdb, aliases=aliases)


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # fflog(f'{tvshowtitle=}  {localtvshowtitle=}  {year=}  {kwargs=}',1,1)
        # return self.search(tvshowtitle, localtvshowtitle, year, is_tvshow=True, tmdb=tmdb)  # tu się to nie sprawdzi
        return (tvshowtitle, localtvshowtitle, aliases), year


    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        # fflog(f'{url=}  {season=}  {episode=}  {kwargs=}',1,1)
        if not url:
            return None
        tvshowtitle = url[0][0]
        localtvshowtitle = url[0][1]
        aliases = url[0][2]
        year = url[1]
        tmdb = kwargs.get("tmdb", "")
        absolute_episode = kwargs.get("absolute_episode")
        return self.search(tvshowtitle, localtvshowtitle, year, tmdb, int(season), int(episode), absolute_episode, aliases)


    def search(self, title, localtitle, year, tmdb='', season=None, episode=None, absolute_episode=0, aliases=None):
        fflog(f'{title=}  {localtitle=}  {year=}  {tmdb=}  {season=}  {episode=}  {absolute_episode}  {aliases=}',1,1)
        try:
            if aliases is None:
                aliases = []

            originalname = [a for a in aliases if "originalname" in a]
            originalname = originalname[0]["originalname"] if originalname else ""
            # originalname = "" if source_utils.czy_litery_krzaczki(originalname) else originalname  # co z rosyjskimi tytułami?

            original_first = True  # ewentualnie dorobić przełącznik w Ustawieniach
            if original_first:
                titles = [originalname, localtitle, title]
            else:
                titles = [localtitle, title, originalname]

            if 1:
                language_order = ["pl", "us", "en", "uk", "gb", "au", "it", "fr", "de" ]  # aby dać niektóre na początek - to są troche inne kody niż w Trexie
                language_order = {key: i for i, key in enumerate(language_order)}
                aliases = sorted(aliases, key=lambda d:(language_order.get(d["country"], 99),) )  # bo nie zawsze pomaga, czasami jp romaji jest najlepsze
                aliases1 = [
                    (a.get("title") or a.get("originalname") or "")
                    + " ("
                    + a.get("country", "")
                    + ")"
                    for a in aliases
                ]
                aliases2 = [a.rpartition(" (")[0] for a in aliases1]  # country out
                aliases2 = [a.replace(year, "").replace("()", "").rstrip() for a in aliases2]  # year out
                # aliases2 = [a for a in aliases2 if not source_utils.czy_litery_krzaczki(a)]  # krzaczki out
                aliases2 = [alias for i, alias in enumerate(aliases2) if alias.lower() not in [x.lower() for x in aliases2[:i]]]  # kolejne duplikaty są usuwane niezależnie od wielkości liter
                # fflog(f'{aliases2=}')
                titles += aliases2

            # titles = [t.lower() for t in titles]  # ta wyszukiwarka zwraca na to uwagę
            titles = list(filter(None, titles))  # usunięcie pustych
            titles = list(dict.fromkeys(titles))  # pozbycie się duplikatów
            fflog(f'{titles=}',1,1)

            if control.setting('stalkervod2.not_check_languages') != 'true':
                languages = control.setting('stalkervod2.languages').strip()
                if 1:
                    # import re
                    languages = re.split(" *[ ,|] *", languages)
                else:
                    languages = languages.replace("|", ",").rstrip(',')
                    languages = languages.split(',')  # string into list
                    languages = [l.strip().replace('"', '') for l in languages]  # clean a little
                languages = [l.upper() for l in languages]
                languages = list(filter(None, languages))  # eliminate empty
                languages = list(dict.fromkeys(languages))  # eliminate duplicates

                langs_target = control.setting('stalkervod2.languages.target')
                fflog(f'{langs_target=}',1,1)
                if not episode and int(langs_target) not in [0, 1]:
                    languages = []
                if episode and int(langs_target) not in [0, 2]:
                    languages = []

                if 'PL' not in languages:
                    languages.insert(0, 'PL')
                if 'POL' not in languages:
                    languages.insert(1, 'POL')
                if 'MULTI' not in languages:
                    languages.append('MULTI')

                fflog(f'{languages=}',1,1)
            else:
                languages = []

                language_order = ["PL", "POL", "MUL", "MULTI", "US", "EN", "ENG", ""]
                language_order = {key: i for i, key in enumerate(language_order)}

            stclient = StalkerClient()

            videos = []  # filmy albo seriale
            filtered = []
            trash = None
            # len_titles = len(titles)
            searched_titles = []
            counter = 0

            for search_title in titles:
                # if not search_title:
                    # continue
                    # pass

                if ":" in search_title:
                    # tylko czy tak jest zawsze? Zaobserwowałem, że to daje źródła w PL
                    search_title = search_title.split(":")[0].strip()
                    # search_title = search_title.replace(":", " -")
                    pass

                if search_title.startswith('The '):
                    search_title = search_title.replace('The ', '')
                    pass

                if search_title in searched_titles:
                    fflog(f'fraza {search_title} była już wyszukiwana')
                    continue

                counter += 1
                if counter > 5:
                    break

                searched_titles += [search_title]

                fflog(f'{search_title=}',1,1)


                control.sleep(100)  # nie wiem, czy to pomaga

                def search_videos(search_title, all_filtered):
                    videos = []
                    filtered = []
                    nonlocal trash

                    videos += stclient.get_videos(
                        category_id="*",
                        search=search_title,
                        media_type='series' if episode is not None else 'vod'
                    )

                    fflog(f'{len(videos)=}',1,1)
                    # fflog(f'{len(videos)=}  {json.dumps(videos, indent=2)}',1,1)

                    videos = [v for v in videos if v["id"] not in [x["id"] for x in all_filtered]]  # usuwanie kolejnych duplikatów
                    fflog(f'{len(videos)=}',1,1)

                    if videos:

                        if tmdb:
                            filtered = [
                                v for v in videos
                                if (1
                                    and (tmdb_id := v.get('tmdb_id', '')) == tmdb or tmdb_id == int(tmdb)
                                   )
                            ]
                        if not filtered:
                            if year:
                                filtered = [
                                    v for v in videos
                                    if (1
                                        and ((yr := v.get('year', '')).startswith(year)
                                             or not yr or yr == "N/A"
                                            )
                                       )
                                ]
                            if episode is not None:
                                filtered = [
                                    v for v in filtered
                                    if (1
                                        and v.get('has_files')
                                        # and v.get('is_series')
                                       )
                                ]
                        fflog(f'1) {len(filtered)=}',1,1)
                        # fflog(f'1 {len(filtered)=} {json.dumps(filtered, indent=2)}',1,1)

                        if filtered:
                            lang_re = re.compile(r'\b([A-Z]{2}-[A-Z]{2}|[A-Z]{2,4})\b')
                            if control.setting('stalkervod2.not_check_languages') != 'true':
                                fflog('filtruje języki',1,1)
                                if 0:  # debug
                                    for v in filtered:
                                        f = source_utils.get_lang_by_type(f"{v['name']} {v.get('description', '')}")
                                        fflog(f"{f=}   {v['name']} {v.get('description', '')}",1,1)
                                filtered2 = [
                                    v for v in filtered
                                    if (1
                                        # and 'PL' in v.get('name', '')
                                        and(
                                            any(
                                                re.search(rf'\b{x}\b', v['name'])
                                                for x in languages
                                               )
                                            or source_utils.get_lang_by_type(f"{v['name']} {v.get('description', '')}")[0]
                                            )
                                       )
                                ]
                                fflog(f'2) {len(filtered2)=}',1,1)
                                if filtered2:
                                    # oznaczenie językami
                                    for f in filtered2:
                                        for i, x in enumerate(languages):
                                            if re.search(rf'\b{x}\b', f['name']):
                                                m = lang_re.search(f['name'])
                                                # f.update(dict(lang=x))  # czasami są 2 kody języków (np. FR Heweliusz (PL) i to miesza
                                                f.update(dict(lang=m[1]))
                                                if x != m[1]:
                                                    i += 50
                                                f.update(dict(lang_priority=i))
                                            elif source_utils.get_lang_by_type(f"{f['name']} {f.get('description', '')}")[0]:
                                                f.update(dict(lang="PL"))
                                                f.update(dict(lang_priority=1))
                                                pass
                                            else:
                                                f.update(dict(lang=None))
                                                pass
                                    filtered = filtered2
                                    # fflog(f'{len(filtered)=}  {json.dumps(filtered, indent=2)}',1,1)
                                    trash = False
                                else:
                                    # a może tylko angielskie zostawiać?
                                    [v.update({"trash": "language"}) for v in filtered]
                                    # fflog(f'{len(filtered)=}  {json.dumps(filtered, indent=2)}',1,1)
                                    trash = True
                            else:
                                fflog('nie filtruje języków',1,1)
                                # oznaczenie językami
                                for f in filtered:
                                    if m := lang_re.search(f['name']):
                                        f.update(dict(lang=m[1]))
                                        f.update(dict(lang_priority=language_order.get(m[1], 99) ))
                                # fflog(f'{len(filtered)=}  {json.dumps(filtered, indent=2)}',1,1)

                        # if 0:
                            # filtered = sorted(
                                # filtered,
                                # key=lambda x: x.get('added', ''),
                                # reverse=True
                            # )
                        filtered = sorted(
                            filtered,
                            key=lambda x: (
                                            x.get('lang_priority', 99),
                                            '4K' in x['name'],
                                            'UHD' in x['name'],
                                           ),
                            reverse=False
                        )
                        # fflog(f'3 {len(filtered)=} {json.dumps(filtered, indent=2)}',1,1)

                        if filtered and control.setting('stalkervod2.only_first_avail_lang') == 'true' or episode:
                            lang = filtered[0].get('lang')
                            # fflog(f'tylko {lang=}',1,1)
                            if lang:
                                fflog(f'wybieram tylko dla {lang=}',1,1)
                                filtered = [f for f in filtered if f.get('lang') == lang]
                            else:
                                if episode:
                                    fflog(f'nie ma określonego języka, ale dla seriali tylko 2 pierwsze z listy',1,1)
                                    # filtered = [filtered[0]]  # tylko 1
                                    filtered = filtered[0:2]  # tylko 2 pierwsze (na wypadek jakby było 4k i SD
                                else:
                                    fflog(f'daje wszystkie, bo nie ma określonego języka',1,1)
                            # fflog(f'3l {len(filtered)=} {json.dumps(filtered, indent=2)}',1,1)
                            # fflog(f'3l {len(filtered)=}',1,1)

                    return filtered

                filtered += search_videos(search_title, filtered)


                # fflog(f'{len(filtered)=} {trash=}',1,1)
                if filtered and not trash:
                    if not original_first or counter > 1:
                        break  # przerwanie szukanie
                        pass


                # if 0:  # na górze włączyłem
                    # if (not filtered or trash):  # and len_titles == len(titles):  # and search_title == titles[-1]:  # ostatni
                        # # fflog(f'{len_titles=}  {len(titles)=}',1,1)
                        # # fflog(f'nic nie znaleziono, a to był ostatni tytuł do wyszukiwarki',1,1)
                        # if ":" in search_title:
                            # search_title = search_title.split(":")[0].strip()
                            # # search_title = search_title.replace(":", " -")
                            # # search_title = search_title.replace(": ", " - ")
                            # titles.append(search_title)
                            # fflog(f'jeszcze dodano do kolejki {search_title=}',1,1)
                            # # fflog(f'{len_titles=}  {len(titles)=}',1,1)
                            # control.sleep(500)  # nie wiem, czy to pomaga
                            # pass


            if episode is not None:
                if filtered:  # powinien zostać się tylko 1 - a co, jak będzie więcej, np. wersje FullHD i 4K, albo PL i EN?
                    # fflog(f'3s {len(filtered)=} {json.dumps(filtered, indent=2)}',1,1)
                    fflog(f'3s {len(filtered)=}',1,1)
                    def find_episodes(filtered):
                        nonlocal season, episode
                        fflog(f"teraz szukam sezonów  (id={filtered[0]['id']})",1,1)
                        control.sleep(4000)  # nie wiem, czy to pomaga
                        seasons = stclient.get_all_episodes( filtered[0]['id'] )
                        if not seasons:
                            fflog(f'znaleziono sezonów: {len(seasons)}',1,1)
                            fflog(f"ponawiam szukanie sezonów",1,1)
                            control.sleep(4000)  # nie wiem, czy to pomaga
                            seasons = stclient.get_all_episodes( filtered[0]['id'] )
                        fflog(f'znaleziono sezonów: {len(seasons)}',1,1)
                        # fflog(f'{len(filtered)=}  {json.dumps(seasons, indent=2)}',1,1)
                        # wybranie konkretnego sezonu
                        filtered = [
                            v for v in seasons
                            if (1
                                and v.get('id', '').endswith(f":{season}")
                                and episode in v.get('series', [])  # sprawdzenie, czy taki odcinek istnieje - może rozbić na oddzielne filtrowanie?
                               )
                        ]
                        fflog(f'4 {len(filtered)=}',1,1)
                        # fflog(f'4 {len(filtered)=}  {json.dumps(filtered, indent=2)}',1,1)
                        if not filtered:
                            fflog(f'nie ma takiego sezonu ani odcinka',1,1)
                            # sprawdzić jeszcze dla absolute_episode
                            if season > 1 and len(seasons) == 1 and 1:  # nie przetestowane jeszcze
                                season = 1
                                episode = absolute_episode
                                fflog(f'próba znalezienia odcinka korzystając z numeracji absolutnej {absolute_episode=}',1,1)
                                # i ponowna filtracja
                                filtered = [
                                    v for v in seasons
                                    if (1
                                        and v.get('id', '').endswith(f":{season}")
                                        and episode in v.get('series', [])  # sprawdzenie, czy taki odcinek istnieje - może rozbić na oddzielne filtrowanie?
                                       )
                                ]
                                fflog(f'4a {len(filtered)=}',1,1)
                                # fflog(f'4a {len(filtered)=}  {json.dumps(filtered, indent=2)}',1,1)
                                if not filtered:
                                    fflog(f'nie ma takiego sezonu ani odcinka',1,1)
                        return filtered
                    # filtered = find_episodes(filtered)  # jeden
                    ftemp = []
                    for f in filtered[:2]:  # ograniczenie do dwóch
                        ftemp += find_episodes([f])
                    filtered = ftemp


            fflog(f'Znaleziono pasujących: {len(filtered)=}',1,1)
            # fflog(f'return {len(filtered)=}  {json.dumps(filtered, indent=2)}',1,1)

            if episode is not None:
                return filtered, season, episode
            return filtered

        except Exception:
            fflog_exc(1)
            return None


    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if isinstance(url, tuple):
                url, season, episode = url
            else:
                # season = None
                episode = None
                episode = 0  # nie wiem, czy stalker przewiduje odcinki specjalne

            if not url:
                return sources

            host = source_utils.top_domain(control.setting('stalkervod2.server_address').strip())
            if not re.search(r'(\d{1,3}\.){3}\d{1,3}', host):
                host = host.rsplit(".", 1)[0]

            for s in url:

                try:
                    # fflog(f'{json.dumps(s, indent=2)}',1)

                    title = s.get('name')
                    if episode:
                        season_title = title
                        title = s.get('path').replace('_', ' ')
                        season_title = season_title.replace('eason', 'ezon')
                        title += f"   [{season_title}  odc. {episode}]"
                        # title += f"  S{season:0>2}E{episode:0>2}"
                        # title += f"  E{episode:0>2}"

                    # host_name = 'VOD'
                    host_name = ''
                    
                    vod_url = repr({
                                    'id': s['id'],
                                    'cmd': s.get('cmd'),
                                    'series': episode,
                                   })

                    if episode:
                        def_qual = control.setting('stalkervod2.default_quality.tvshows')
                    else:
                        def_qual = control.setting('stalkervod2.default_quality.movies')
                    # quality = '1080p' if s.get('hd') else 'SD'  # na sztywno
                    quality = def_qual if s.get('hd') else 'SD'  # na sztywno
                    unsure = ["quality"]
                    if title:
                        quality = source_utils.get_qual(title)
                        # fflog(f'{quality=}  {title=}',1,1)
                        if not quality or quality == 'SD':
                            # quality = '1080p'  # na sztywno
                            quality = def_qual if s.get('hd') else 'SD'
                            pass
                        else:
                            unsure = None
                        pass

                    info = ''
                    language = 'pl'
                    if title and 1:  # a co jak nie ma PL w nazwie?
                        language = source_utils.get_lang_by_type(f"{title} {s.get('description', '')}")
                        # fflog(f'{language=}  {title=}',1,1)
                        language, info = language
                        pass

                    if host_name:
                        info += f" | {host_name}"

                    sources.append({
                        'source': host,
                        'quality': quality,
                        'language': language,
                        'url': vod_url,
                        'info': info.strip(' |'),
                        'filename': title,
                        'direct': True,
                        'debridonly': False,
                        'premium': True,
                    })

                    if unsure:
                        sources[-1]['unsure'] = unsure
                        pass

                    if trash := s.get('trash'):
                        sources[-1]['trash'] = trash

                except Exception:
                    fflog_exc(1)
                    pass

            fflog(f'Przekazano: {len(sources)} źródeł')
            return sources

        except Exception:
            fflog_exc(1)
            return sources


    def resolve(self, url):
        """Zwraca URL """
        from ast import literal_eval
        video = literal_eval(url)
        # fflog(f'{video=}',1,1)
        # fflog(f'video={json.dumps(video, indent=2)}',1,1)

        stclient = StalkerClient()

        stream_url = stclient.get_vod_stream_url(
            video_id=video['id'],
            cmd=video.get('cmd'),
            series=video.get('series') or 0
        )

        if 1:
            # stclient.mac_address2 = control.setting('stalkervod2.mac_address.2').strip()
            # stclient.mac_address3 = control.setting('stalkervod2.mac_address.3').strip()
            # macs = [stclient.mac_address2, stclient.mac_address3,]
            macs = control.setting('stalkervod2.macs_alt').strip()
            if 1:
                # import re
                macs = re.split(" *[ ,|] *", macs)
            else:
                macs = macs.replace("|", ",").rstrip(',')
                macs = macs.split(',')  # string into list
                macs = [l.strip().replace('"', '') for l in macs]  # clean a little
            macs = [l.upper() for l in macs]
            macs = list(filter(None, macs))  # usunięcie pustych
            macs = list(dict.fromkeys(macs))  # pozbycie się duplikatów
            # fflog(f'{macs=}',1,1)
            if macs:
                from ptw.libraries import client
                for mac in macs:
                    if mac == stclient.mac_address:
                        continue
                    fflog(f'testowanie streamu',1,1)
                    # fflog(f'testowanie  {stream_url=}',1,1)
                    result = client.request(stream_url, output="geturl", timeout="20")  # wpierw test obecnego
                    if result:
                        # return {"url":stream_url, "check_link":False}
                        break
                    fflog(f'testuje następny MAC',1,1)
                    stream_url = re.sub("(?<=mac=)[^&]*", mac, stream_url)  # potem wymiana mac

        # fflog(f'{stream_url=}',1,1)
        return stream_url



import math


class StalkerClient:


    def __init__(self):
        self.server_address = control.setting('stalkervod2.server_address').strip()
        if not self.server_address:
            raise Exception('brak adresu serwera w Ustawieniach')
        self.portal_url = self.server_address.rstrip('/')
        if self.portal_url.endswith('/c'):
            # context_path = '/server/load.php'  # taki wariant przeważnie pasuje
            context_path = '/portal.php' if control.setting('stalkervod2.alternative_context_path')=='true' else '/server/load.php'
            # self.portal_url = self.portal_url.replace('/c', '') + context_path  # to chyba złe jednak
            self.portal_url = self.portal_url + context_path
        else:
            portal_base_url = self.__get_portal_base_url()
            # context_path = '/portal.php'  # taki wariant przeważnie pasuje
            context_path = '/portal.php' if control.setting('stalkervod2.alternative_context_path')=='false' else '/server/load.php'  # odwrotnie
            # self.portal_url = portal_base_url + '/stalker_portal' + context_path  # to chyba nie koniecznie zawsze się sprawdza
            self.portal_url = portal_base_url + '' + context_path
        # fflog(f'{self.portal_url=}',1,1)

        self.mac_address = control.setting('stalkervod2.mac_address').strip().upper()
        if not self.mac_address:
            # fflog('brak adresu MAC w Ustawieniach')
            raise Exception('brak adresu MAC w Ustawieniach')

        # self.mac_address2 = control.setting('stalkervod2.mac_address.2').strip()
        # self.mac_address3 = control.setting('stalkervod2.mac_address.3').strip()

        self.serial = ''  # pozyskiwać z ustawień
        self.serial = self.serial or self.mac_address.replace(':', '') or ''

        self.timeout = 30

        self.token = None
        try:
            self.token = cache.cache_get("stalkervod2_token")["value"]
            # fflog(f'1) {self.token=}',1,1)
        except Exception:
            # fflog_exc(1)
            pass

        import requests
        self.session = requests.Session()

        self.session.headers.update({
            'Cookie': f'mac={self.mac_address}',
            'SN': self.serial,
            'X-User-Agent': 'Model: MAG250; Link: WiFi',
            'User-Agent': 'Mozilla/5.0 (QtEmbedded; Linux)',
            'Referrer': self.server_address
        })


    def __get_portal_base_url(self):
        """Get portal base url"""
        split_url = urlsplit(self.server_address)
        return split_url.scheme + '://' + split_url.netloc



    def authenticate(self, check_mac_expire_date=True):
        params = {
            'type': 'stb',
            'action': 'handshake',
            'token': ''
        }

        r = self.session.get(
                self.portal_url,
                params=params,
                timeout=self.timeout
        )
        # fflog(f'{r.status_code=}  {r.url=}',1,1)
        # fflog(f'{r.text=}',1,1)
        if not r:
            control.setSetting('stalkervod2.expire_date', "[I]nieważne ? [/I]")
            if not control.window.getProperty("blocked_sources_extend") == 'break':
                control.infoDialog(f"błąd serwera: {r.status_code}", 'stalkervod2', "ERROR")

        r.raise_for_status()

        try:
            data = r.json()
        except Exception:
            fflog(str(r.text), 1,1)
            raise RuntimeError('[stalkervod2.py] [authenticate] Handshake: odpowiedź nie jest JSON')

        js = data.get('js', {})
        if not js:
            # fflog(f'{r.text=}',1,1)
            pass

        token = js.get('token')

        # fflog(f'1) {token=}',1,1)

        if not token:
            token = data.get('token')
            # fflog(f'2) {token=}',1,1)

        if not token:
            # fflog(f'3) {token=}',1,1)
            return

        self.token = token
        # control.setSetting('stalkervod2.token', token)
        cache.cache_insert("stalkervod2_token", token)  # wstawienie do bazy
        self.session.headers['Authorization'] = f'Bearer {self.token}'
        if check_mac_expire_date:
            self.check_expiry()


    def _call(self, params, recurency=None):
        fflog(f'{recurency=}',1,1) if recurency else ''

        if not self.token:
            # fflog(f'{self.token=}',1,1)
            self.authenticate()

        fflog(f'{params=}',0,1)
        r = self.session.get(
                self.portal_url,
                params=params,
                timeout=self.timeout
        )
        # fflog(f'{r.status_code=}  {r.url=}',1,1)
        if r is None or r.status_code >= 400:
            if not control.window.getProperty("blocked_sources_extend") == 'break':
                control.infoDialog(f"błąd serwera: {r.status_code}", 'stalkervod2', "ERROR")

        r.raise_for_status()

        if 'Authorization failed' in r.text:
            self.token = None
            cache.cache_remove("stalkervod2_token")
            if not recurency:
                return self._call(params, recurency=True)

        try:
            ret = r.json()
        except:
            fflog(f'{r.text=}',1,1)
            fflog('odpowiedź nie jest JSON',1,1)
            # raise RuntimeError('[stalkervod2.py] [_call] odpowiedź nie jest JSON')
            ret = {}
        # fflog(f'ret = {json.dumps(ret, indent=2)}',1,1)
        ret1 = ret['js']
        # ret1 = ret.get('js', {})
        if not ret1:
            fflog('wystąpił problem',1,1)
            fflog(f'{r.text=}',1,1)
            fflog(f'{ret1=}',1,1)
            fflog(f'ret = {json.dumps(ret, indent=2)}',1,1)
            fflog(f'nie otrzymano danych z serwera',1,1)
            if not control.window.getProperty("blocked_sources_extend") == 'break':
                control.infoDialog("nie otrzymano danych z serwera", 'stalkervod2', "WARNING")
            ret1 = {}
            raise Exception('[stalkervod2.py] [_call] nie otrzymano danych z serwera')
        return ret1


    # def _search(self, media_type, category_id, search, page, max_pages):
    def get_videos(
        self,
        category_id,
        page=1,
        search='',
        fav=0,
        max_pages=3,
        media_type='vod'
    ):
        params = {
            'type': media_type,  # 'vod' or 'series'
            'action': 'get_ordered_list',
            'category': category_id,
            'sortby': 'added',
            'fav': fav,
            'p': page
        }

        if search.strip():
            params['search'] = search.strip()

        result = self._call(params)
        if not result:
            fflog(f'nie otrzymano danych z serwera {result=}',1,1)
            return []
        videos = result.get('data')
        if not videos:
            fflog(f'brak danych {videos=}',1,1)
            return []
            pass
        total_items = result['total_items']
        per_page = result['max_page_items']
        total_pages = int(math.ceil(total_items / float(per_page)))
        for p in range(page + 1, min(page + max_pages, total_pages + 1)):
            params['p'] = p
            result = self._call(params)
            if result:
                videos.extend(result.get('data') or [])
            else:
                fflog(f'2) nie otrzymano danych z serwera {result=}',1,1)
                break
                pass
        fflog(f'{len(videos)=}',1,1)
        return videos


    def get_vod_stream_url(
        self,
        video_id="",
        cmd="",
        series=0,
        use_cmd=True
    ):
        if not cmd and video_id:
            use_cmd=False

        if not use_cmd and video_id:
            fflog('wariant 1 (z id)',0,1)
            response = self._call_raw({
                'type': 'vod',
                'action': 'create_link',
                'cmd': f'/media/{video_id}.mpg',
                'series': str(series)
            })

            if response.status_code == 200:
                data = response.json().get('js', {})
                stream_url = data.get('cmd')
            else:
                stream_url = None
        else:
            stream_url = None

        if not stream_url and cmd:
            fflog('wariant 2 (z cmd)',0,1)
            data = self._call({
                'type': 'vod',
                'action': 'create_link',
                'cmd': cmd,
                'series': str(series)
            })
            stream_url = data.get('cmd')

        if not stream_url:
            raise RuntimeError('Nie udało się uzyskać URL streamu')

        if ' ' in stream_url:  # może być "ffmpeg " na początku
            # fflog(f'spacja w adresie {stream_url=}',1,1)
            stream_url = stream_url.split(' ', 1)[1]
            pass

        return stream_url


    def _call_raw(self, params, recurency=None):
        fflog(f'{recurency=}',1,1) if recurency else ''

        if not self.token:
            self.authenticate()

        r = self.session.get(
            self.portal_url,
            params=params,
            timeout=self.timeout
        )
        # fflog(f'{r.status_code=}  {r.url=}',1,1)
        if 'Authorization failed' in r.text:
            self.token = None
            cache.cache_remove("stalkervod2_token")
            if not recurency:
                return self._call_raw(params, recurency=True)

        if not r:
            fflog(f'{r.text=}',1,1)
        return r


    def get_all_episodes(self, movie_id, max_pages=10):  # max_pages - to może mieć znaczenie dla seriali z większą ilością sezonów czy odcinków (jeszcze nie wiem)
        params = {
            'type': 'series',
            'action': 'get_ordered_list',
            'movie_id': movie_id,
            'p': 1
        }
        result = self._call(params)

        episodes = result['data']
        total_items = result['total_items']
        per_page = result['max_page_items']
        total_pages = int((total_items + per_page - 1) / per_page)

        for p in range(2, min(total_pages + 1, max_pages + 1)):
            params['p'] = p
            result = self._call(params)
            episodes.extend(result['data'])

        return episodes


    def check_expiry(self, paste_into_settings=True):
        try:
            # fflog('Sprawdzam datę ważności głównego MACa', 1, 1)
            data_waznosci = None

            # 1. account_info
            try:
                params = {'type': 'account_info', 'action': 'get_main_info', 'JsHttpRequest': '1-xml'}
                r = self.session.get(self.portal_url, params=params, timeout=self.timeout)
                if r.status_code == 200:
                    info = r.json().get('js', {})
                    # fflog(f'1) info={json.dumps(info, indent=2)}',1,1)
                    # Różne pola: expire_date, exp_date, phone (czasem tam jest data)
                    temp = info.get('expire_date') or info.get('exp_date') or info.get('phone')
                    if temp and temp != "0000-00-00 00:00:00":
                        data_waznosci = temp
                else:
                    fflog(f'{r.status_code=}',1,1)
            except Exception:
                fflog_exc(1)
                pass

            # 2. get_profile (chyba urządzenia)
            if not data_waznosci:
                try:
                    params = {'type': 'stb', 'action': 'get_profile', 'JsHttpRequest': '1-xml'}
                    r = self.session.get(self.portal_url, params=params, timeout=self.timeout)
                    if r.status_code == 200:
                        info = r.json().get('js', {})
                        # fflog(f'2) info={json.dumps(info, indent=2)}',1,1)
                        temp = info.get('expire_date') or info.get('end_date') or info.get('expire_billing_date')
                        if temp and temp != "0000-00-00 00:00:00":
                            data_waznosci = temp
                    else:
                        fflog(f'{r.status_code=}',1,1)
                except Exception:
                    fflog_exc(1)
                    pass

            # fflog(f'{data_waznosci=}',1,1)

            if paste_into_settings:
                if data_waznosci:
                    control.setSetting('stalkervod2.expire_date', str(data_waznosci))
                    pass
                else:
                    # Opcjonalnie: info o braku daty, jeśli chcesz widziec że sprawdzilo
                    control.setSetting('stalkervod2.expire_date', "Brak informacji")
                    pass

            return data_waznosci

        except Exception:
            fflog_exc(1)
            pass


    def mac_expire_date(self):
        fflog(f'checking ... ',1,1)
        try:
            macs = control.setting('stalkervod2.macs_alt').strip()
            if 1:
                # import re
                macs = re.split(" *[ ,|] *", macs)
            else:
                macs = macs.replace("|", ",").rstrip(',')
                macs = macs.split(',')  # string into list
                macs = [l.strip().replace('"', '') for l in macs]  # clean a little
            macs.insert(0, control.setting('stalkervod2.mac_address').strip())
            macs = [l.upper() for l in macs]
            macs = list(filter(None, macs))
            macs = list(dict.fromkeys(macs))
            # fflog(f'{macs=}',1,1)
            if not self.token:
                self.authenticate(check_mac_expire_date=False)
            results = ""
            for mac in macs:
                serial = mac.replace(':', '') or ''
                self.session.headers.update({
                    'Cookie': f'mac={mac}',
                    'SN': serial,
                })
                expire_date = self.check_expiry(paste_into_settings=False)
                results += f'\n{mac} - {expire_date}'
                if mac != macs[-1]:
                    control.sleep(200)
            # fflog(f'results={results}',1,1)
            control.dialog.ok('Daty ważności', results)
        except Exception:
            fflog_exc(1)
