# -*- coding: utf-8 -*-
"""
FanFilm - źródło: bajeczki24.pl
Copyright (C) 2025 :)

Dystrybuowane na licencji MIT <https://mit-license.org>
"""

import time
import re
from ptw.libraries import control, cache, cleantitle
from ptw.debug import fflog, fflog_exc
# import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['pl']
        self.base_link = 'https://bajeczki24.pl'
        self.useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0'
        self.headers = {
            'Referer': self.base_link,
            'User-Agent': self.useragent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3'
        }
        # self.sess = requests.Session()
        self.sess = None


    def _match_item(self, item, search_title_clean, year=None, episode=None):
        item_match = re.search(r'<title>(.*?)</title>.*?<link>(.*?)</link>', item, flags=re.DOTALL)
        if not item_match:
            return None

        full_title_str = item_match.group(1).strip()
        item_link = item_match.group(2).strip()

        title_parts_match = re.match(r'(.+?)(?:\s+\((\d{4})\))?(?:\s*-\s*(S\d+E\d+))?$', full_title_str)
        if not title_parts_match:
            rss_title = full_title_str
            item_year = None
            item_episode = None
        else:
            rss_title = title_parts_match.group(1).strip()
            item_year_str = title_parts_match.group(2)
            item_year = int(item_year_str) if item_year_str else None
            item_episode = title_parts_match.group(3)

        item_title_clean = cleantitle.get(rss_title)

        if year and item_year and item_year != int(year):
            return None
        if search_title_clean != item_title_clean:
            return None
        if episode and item_episode != episode:
            return None

        return item_link


    def _search_items(self, title, year=None, episode=None, type_='movie'):

        html = self.get_cached_rss()
        if not html:
            fflog(f'{html=}',1,1)
            return None

        items = re.findall(r'<item>(.*?)</item>', html, flags=re.DOTALL)
        search_title_clean = cleantitle.get(title)

        for item in items:
            link = self._match_item(item, search_title_clean, year, episode)
            if not link:
                continue

            if type_ == 'movie' and '/filmy/' not in link:
                continue
            # fflog(f'{link=}',1,1)
            return link
        fflog(f'nic nie znaleziono',1,1)
        return None


    def movie(self, imdb, title, localtitle, aliases, year):
        # fflog(f'{imdb=} {title=} {localtitle=} {year=}',1,1)
        return self.search_movie(title, localtitle, year, 'movie', aliases)


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # fflog(f'{imdb=} {tvdb=} {tvshowtitle=} {localtvshowtitle=} {year=} {aliases=}',1,1)
        return ((tvshowtitle, localtvshowtitle), year)


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # fflog(f'{url=} {imdb=} {tvdb=} {title=} {premiered=} {season=} {episode=}',1,1)
        if not url:
            return None
        en_title, pl_title = url[0][0], url[0][1]
        year = url[1]
        return self.search_episode(en_title, pl_title, year, season, episode)


    def search_movie(self, title, localtitle, year, type_, aliases=None):
        if not self.sess:
            import requests
            self.sess = requests.Session()
        try:
            if not title:
                return None
            # priorytet: polski tytuł
            if localtitle:
                url = self._search_items(localtitle, year, type_='movie')
                if url:
                    return url
            # fallback: tytuł EN
            if title.lower() != (localtitle or '').lower():
                return self._search_items(title, year, type_='movie')
            return None
        except Exception:
            fflog_exc(1)
            return None


    def search_episode(self, en_title, pl_title, year, season, episode):
        fflog(f'[bajeczki24] search_episode: pl={pl_title}, en={en_title}, year={year}, S{int(season):02d}E{int(episode):02d}')
        if not self.sess:
            import requests
            self.sess = requests.Session()
        try:
            se_pattern = f'S{int(season):02d}E{int(episode):02d}'
            # priorytet: polski tytuł
            if pl_title:
                url = self._search_items(pl_title, year, episode=se_pattern, type_='episode')
                if url:
                    return url
            # fallback: angielski tytuł
            if en_title.lower() != (pl_title or '').lower():
                return self._search_items(en_title, year, episode=se_pattern, type_='episode')
            fflog(f'No episode found for pl={pl_title} en={en_title} {se_pattern}')
            return None
        except Exception:
            fflog_exc(1)
            return None


    def get_cached_rss(self):
        """
        Pobieranie RSS z użyciem ETag (If-None-Match).
        Brak sztywnego timeoutu czasowego – aktualność zapewnia serwer (Cloudflare).
        """
        try:

            cache_key_rss = 'bajeczki24_rss'
            cache_key_etag = 'bajeczki24_rss_etag'

            row = cache.cache_get(cache_key_rss, control.providercacheFile)
            cached_rss = row['value'] if row else None

            row_etag = cache.cache_get(cache_key_etag, control.providercacheFile)
            cached_etag = row_etag['value'] if row_etag else None

            headers = dict(self.headers)
            if cached_etag:
                headers['If-None-Match'] = cached_etag

            rss_url = f'{self.base_link}/rss.xml'
            r = self.sess.get(rss_url, headers=headers, timeout=30, verify=False)

            if r.status_code == 304:
                return cached_rss

            if r.status_code != 200:
                return cached_rss if cached_rss else None

            html = r.text
            etag = r.headers.get('ETag')

            cache.cache_insert(cache_key_rss, html, control.providercacheFile)
            if etag:
                cache.cache_insert(cache_key_etag, etag, control.providercacheFile)

            return html

        except Exception:
            fflog_exc(1)
            cached_rss = cache.cache_value('bajeczki24_rss', control.providercacheFile)
            return cached_rss if cached_rss else None


    def sources(self, url, hostDict, hostprDict):
        # fflog(f'{url=}',1,1)
        try:
            if not url:
                fflog(f'{url=}',1,1)
                return []

            if not self.sess:
                import requests
                self.sess = requests.Session()

            r = self.sess.get(url, headers=self.headers, timeout=30, verify=False)
            if r.status_code != 200:
                fflog(f'{r.status_code=}',1,1)
                return []

            match_frame = re.search(r'<iframe.*?src="(.*?)"', r.text)
            if not match_frame:
                fflog(f'{match_frame=}',1,1)
                return []

            frame = match_frame.group(1)
            # uproszczenie host_name
            host_match = re.search(r'https?://(?:www\.)?([^./]+)', frame)
            host_name = host_match.group(1) if host_match else frame

            # fflog(f'{url=}',1,1)
            # filename = url
            filename = url.strip('/').rpartition('/')[-1]
            # fflog(f'{filename=}',1,1)

            source = {
                'source': host_name,
                'quality': '1080p',
                'language': 'pl',
                'url': frame,
                'info': '',
                'filename': filename,
                'direct': False,
                'debridonly': False,
                # 'premium': False,
            }
            fflog(f'Przekazano źródeł: {len([source])}')
            return [source]
        except Exception:
            fflog_exc(1)
            return []


    def resolve(self, url):
        return url
