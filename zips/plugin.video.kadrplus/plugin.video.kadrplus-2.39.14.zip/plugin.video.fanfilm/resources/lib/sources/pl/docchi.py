# -*- coding: utf-8 -*-
"""
FanFilm - zrodlo: docchi.pl
Copyright (C) 2025 :)

Portowane z FanFilm Beta do architektury ptw.
Logika wyszukiwania identyczna z beta:
  - seriale: Kitsu API -> mal_id -> /series/related/{mal_id} -> slug -> local_ep
  - filmy:   Kitsu API -> mal_id -> /series/related/{mal_id}
  - fallback: 3 podejscia (related/list/find slug)
"""

import re
import unicodedata
from datetime import datetime
from urllib.parse import quote_plus

import requests

from ptw.libraries import cleantitle, source_utils, control
from ptw.libraries.log_utils import fflog
from ptw.debug import fflog_exc

DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0"


class source:

    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.base_link = "https://docchi.pl"
        self.api_base  = "https://api.docchi.pl/v1"
        self.session   = requests.Session()
        self.headers   = {
            "Host": "docchi.pl",
            "User-Agent": DEFAULT_UA,
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
            "Accept-Encoding": "identity",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }
        self._current_episode = 1

    # ------------------------------------------------------------------ #
    #  Publiczne API
    # ------------------------------------------------------------------ #

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        try:
            if not self._is_anime_by_imdb(imdb, 'movie'):
                return None
            from ptw.api import kitsu as kitsu_api
            tmdb = kwargs.get('tmdb')
            movie_info = kitsu_api.get_movie_info(tmdb) if tmdb else None
            if movie_info and movie_info.get('mal_id'):
                mal_id = movie_info['mal_id']
                fflog(f'docchi/movie: kitsu="{movie_info["title"]}" mal_id={mal_id}')
                api_headers = self._api_headers()
                r = self.session.get(f'{self.api_base}/series/related/{mal_id}', headers=api_headers)
                if r and r.status_code == 200:
                    try:
                        data = r.json()
                        if isinstance(data, list) and data:
                            series_slug  = data[0].get('slug', '')
                            series_title = data[0].get('title', '')
                            if series_slug:
                                fflog(f'docchi/movie: znaleziono "{series_title}" slug="{series_slug}"')
                                self._current_episode = 1
                                return series_slug
                    except Exception:
                        fflog_exc(1)
                fflog(f'docchi/movie: brak w bazie (mal_id={mal_id})')
                return None
            # brak MAL ID - fallback tytulowy
            jp_aliases = [a["title"] for a in (aliases or []) if a.get("country") == "jp"]
            titles = (jp_aliases[:1] if jp_aliases else []) + [title]
            fflog(f'docchi/movie: fallback tytulowy {titles}')
            return self._search_ep_or_movie(titles, None, None, None, aliases)
        except Exception:
            fflog_exc(1)
            return None

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        jp_aliases = [a["title"] for a in (aliases or []) if a.get("country") == "jp"]
        jp_titles = jp_aliases[:1] if jp_aliases else []
        titles = jp_titles + [tvshowtitle]
        fflog(f'TVShow search titles: {titles}')
        return titles, year, aliases

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        try:
            if not isinstance(url, (list, tuple)) or len(url) < 1:
                return None
            titles = url[0]
            aliases = url[2] if len(url) > 2 else []

            if not self._is_anime_by_tvdb(tvdb, imdb):
                return None

            from ptw.api import kitsu as kitsu_api
            tmdb = kwargs.get('tmdb')
            if tmdb:
                return self._search_with_kitsu(
                    titles, season, episode, str(tmdb), aliases,
                    premiered=premiered,
                    spremiered=kwargs.get('spremiered'),
                    absolute_episode=kwargs.get('absolute_episode'),
                )
            return self._fallback_search(titles, aliases, tvdb, season, episode)
        except Exception:
            fflog_exc(1)
            return None

    def sources(self, url, hostDict=None, hostprDict=None):
        sources_list = []
        if not url:
            return sources_list
        try:
            series_slug = url[0] if isinstance(url, list) else url
            episode_num = getattr(self, '_current_episode', 1)

            api_headers = self._api_headers()
            api_url = f"{self.api_base}/episodes/find/{series_slug}/{episode_num}"
            resp = self.session.get(api_url, headers=api_headers)
            if not resp or resp.status_code != 200:
                return sources_list

            episode_data = resp.json()
            players_list = []
            if isinstance(episode_data, list):
                players_list = episode_data
            elif "players" in episode_data:
                players_list = episode_data["players"]
            elif "data" in episode_data:
                players_list = episode_data["data"]

            for player in players_list:
                player_url  = player.get("player", "")
                hosting     = player.get("player_hosting", "Unknown")
                translator  = player.get("translator_title", "")
                if not player_url:
                    continue
                quality = "720p"
                if "forcedQuality=hd1080" in player_url: quality = "1080p"
                elif "forcedQuality=sd"   in player_url: quality = "SD"
                language = "pl"
                if translator and any(w in translator.lower() for w in ["eng", "english"]):
                    language = "en"
                slug_display = re.sub(r'-\d+$', '', series_slug)
                filename = f'{translator} | {slug_display}' if translator else slug_display
                sources_list.append({
                    "source": hosting.upper(), "quality": quality, "language": language,
                    "url": player_url, "info": "", "filename": filename,
                    "direct": False, "debridonly": False, "premium": False,
                })
                fflog(f'docchi: zrodlo: {hosting.upper()} {quality}')

            return sources_list
        except Exception:
            fflog_exc(1)
            return sources_list

    def resolve(self, url):
        return url

    # ------------------------------------------------------------------ #
    #  Kitsu path (identyczny z beta)
    # ------------------------------------------------------------------ #

    def _search_with_kitsu(self, titles, season, episode, tmdb, aliases,
                            premiered=None, spremiered=None, absolute_episode=None):
        try:
            from ptw.api import kitsu as kitsu_api
            cours = kitsu_api.get_cour_structure(tmdb)
            if not cours:
                fflog(f'docchi/kitsu: brak danych dla tmdb={tmdb}')
                return self._fallback_search(titles, aliases, None, season, episode)

            cour, local_ep = self._resolve_cour(kitsu_api, cours, season, episode,
                                                premiered, spremiered, absolute_episode)
            if not cour:
                fflog(f'docchi/kitsu: nie znaleziono coura dla tmdb={tmdb}')
                return self._fallback_search(titles, aliases, None, season, episode)

            kitsu_title = cour['title']
            mal_id      = cour.get('mal_id')
            fflog(f'docchi/kitsu: cour="{kitsu_title}" mal_id={mal_id} local_ep={local_ep}')

            if not mal_id:
                fflog(f'docchi/kitsu: brak mal_id dla "{kitsu_title}"')
                return self._fallback_search(titles, aliases, None, season, episode)

            control.sleep(200)
            api_headers = self._api_headers()
            related_url = f'{self.api_base}/series/related/{mal_id}'
            fflog(f'docchi/kitsu: szukam mal_id={mal_id}')

            r = self.session.get(related_url, headers=api_headers)
            if r and r.status_code == 200:
                try:
                    data = r.json()
                    if isinstance(data, list) and data:
                        series_slug  = data[0].get('slug', '')
                        series_title = data[0].get('title', '')
                        if series_slug:
                            fflog(f'docchi/kitsu: znaleziono "{series_title}" slug="{series_slug}" ep {local_ep}')
                            self._current_episode = local_ep
                            return series_slug
                except Exception:
                    fflog_exc(1)

            fflog(f'docchi/kitsu: brak wynikow dla mal_id={mal_id}')
            return self._fallback_search(titles, aliases, None, season, episode)
        except Exception:
            fflog_exc(1)
            return None

    # ------------------------------------------------------------------ #
    #  Fallback (identyczny z beta.search_ep_or_movie)
    # ------------------------------------------------------------------ #

    def _fallback_search(self, titles, aliases, tvdb, season, episode):
        try:
            if season is not None and episode is not None:
                absolute_ep = source_utils.absoluteNumber(tvdb, episode, season)
                if absolute_ep is None:
                    return None
                target_ep = absolute_ep
            else:
                target_ep = 1
            if not isinstance(titles, (list, tuple)):
                titles = [titles] if titles else []
            return self._search_ep_or_movie(titles, season, episode, target_ep, aliases)
        except Exception:
            fflog_exc(1)
            return None

    def _search_ep_or_movie(self, titles, season, episode, target_ep, aliases):
        try:
            if not isinstance(titles, (list, tuple)):
                titles = [titles] if titles else []
            titles = list(dict.fromkeys([t.lower() for t in titles if t]))
            fflog(f'docchi search titles: {titles}')

            match_titles = set()
            for a in (aliases or []):
                for key in ('title', 'originalname'):
                    v = a.get(key, '')
                    if v:
                        match_titles.add(cleantitle.normalize(v).lower())
            for t in titles:
                if t:
                    match_titles.add(cleantitle.normalize(t).lower())

            api_headers = self._api_headers()

            for title in titles:
                if not title:
                    continue
                control.sleep(200)
                t_norm = unicodedata.normalize('NFD', title)
                t_norm = ''.join(c for c in t_norm if unicodedata.category(c) != 'Mn')
                t_norm = t_norm.replace("shippuden", "shippuuden")

                # Podejscie 1: series/related
                related_url = f"{self.api_base}/series/related/{quote_plus(t_norm)}"
                r = self.session.get(related_url, headers=api_headers)
                if r:
                    try:
                        data = r.json()
                        if isinstance(data, dict) and "slug" in data and "title" in data:
                            clean = cleantitle.normalize(
                                cleantitle.getsearch(data.get("title", "").lower())
                            ).replace("  ", " ")
                            words = clean.split()
                            if any(self._contains_all(mt, words) for mt in match_titles) and data.get("slug"):
                                self._current_episode = target_ep
                                return data["slug"]
                        elif isinstance(data, list) and data:
                            slug   = data[0].get('slug', '')
                            stitle = data[0].get('title', '').lower()
                            clean  = cleantitle.normalize(cleantitle.getsearch(stitle)).replace("  ", " ")
                            if any(self._contains_all(mt, clean.split()) for mt in match_titles) and slug:
                                self._current_episode = target_ep
                                return slug
                    except Exception:
                        pass

                # Podejscie 2: series/list
                list_url = f"{self.api_base}/series/list?limit=100"
                r = self.session.get(list_url, headers=api_headers)
                if r and r.status_code == 200:
                    try:
                        list_data = r.json()
                        if isinstance(list_data, dict):
                            series_list = list_data.get("data", list_data.get("series", []))
                        elif isinstance(list_data, list):
                            series_list = list_data
                        else:
                            series_list = []
                        for series in series_list:
                            if not isinstance(series, dict):
                                continue
                            stitle = series.get("title", "").lower()
                            slug   = series.get("slug", "")
                            alts   = series.get("alternative_titles", [])
                            all_titles = [stitle] + [a.lower() for a in alts if a]
                            for check in all_titles:
                                clean = cleantitle.normalize(
                                    cleantitle.getsearch(check)
                                ).replace("  ", " ")
                                if any(self._contains_all(mt, clean.split()) for mt in match_titles) and slug:
                                    self._current_episode = target_ep
                                    return slug
                    except Exception:
                        pass

                # Podejscie 3: slug guesses
                base_slug = re.sub(r'["\':]', '', t_norm.lower()).replace(" ", "-")
                base_slug = re.sub(r'-+', '-', base_slug).strip('-')
                guesses = [base_slug]
                for mt in match_titles:
                    g = re.sub(r'["\':]', '', mt).replace(" ", "-")
                    g = re.sub(r'-+', '-', g).strip('-')
                    if g and g not in guesses:
                        guesses.append(g)

                for guess in guesses:
                    if not guess:
                        continue
                    find_url = f"{self.api_base}/series/find/{guess}"
                    fflog(f'docchi find API: {guess}')
                    r = self.session.get(find_url, headers=api_headers)
                    if r and r.status_code == 200:
                        try:
                            data = r.json()
                            if isinstance(data, dict) and "slug" in data:
                                self._current_episode = target_ep
                                return data["slug"]
                        except Exception:
                            pass
                    control.sleep(100)

            fflog('docchi: nic nie znaleziono')
        except Exception:
            fflog_exc(1)
        return None

    # ------------------------------------------------------------------ #
    #  Resolve cour
    # ------------------------------------------------------------------ #

    def _resolve_cour(self, kitsu_api, cours, season, episode,
                       premiered, spremiered, absolute_episode):
        abs_ep = absolute_episode

        ep_date = None
        if premiered:
            try:
                ep_date = datetime.strptime(premiered[:10], '%Y-%m-%d').date()
            except Exception:
                pass

        season_start = None
        if spremiered:
            try:
                season_start = datetime.strptime(spremiered[:10], '%Y-%m-%d').date()
            except Exception:
                pass

        cour = None
        local_ep = None

        if ep_date:
            cour, offset = kitsu_api.find_cour_by_date(cours, ep_date)
            if cour:
                tmdb_ep = int(episode) if episode else None
                if (tmdb_ep and season_start and cour['start_date']
                        and season_start <= cour['start_date']):
                    season_offset = sum(
                        c['ep_count'] for c in cours
                        if c['start_date'] and c['ep_count']
                        and season_start <= c['start_date'] < cour['start_date']
                    )
                    local_ep = tmdb_ep - season_offset
                elif abs_ep:
                    local_ep = abs_ep - offset
                else:
                    cour = None

                if local_ep and (local_ep < 1 or (cour and cour['ep_count'] and local_ep > cour['ep_count'])):
                    cour = None

        if not cour:
            if not abs_ep:
                abs_ep = int(episode) if episode else 1
            cour, local_ep = kitsu_api.map_episode(cours, abs_ep)

        return cour, local_ep

    def _api_headers(self):
        h = self.headers.copy()
        h["Host"] = "api.docchi.pl"
        h["Accept"] = "application/json"
        return h

    def _contains_all(self, text, words):
        return all(w in text for w in words)

    def _is_anime_by_imdb(self, imdb, content_type):
        try:
            if imdb:
                return source_utils.is_anime(content_type, 'imdb', imdb)
        except Exception:
            pass
        return True

    def _is_anime_by_tvdb(self, tvdb, imdb):
        try:
            if tvdb:
                return source_utils.is_anime('show', 'tvdb', tvdb)
            if imdb:
                return source_utils.is_anime('show', 'imdb', imdb)
        except Exception:
            pass
        return True
