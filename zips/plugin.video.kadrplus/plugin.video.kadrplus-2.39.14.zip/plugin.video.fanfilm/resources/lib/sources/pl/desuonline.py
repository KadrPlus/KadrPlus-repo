# -*- coding: utf-8 -*-
"""
FanFilm - źródło: desu-online.pl
Copyright (C) 2025 :)

Portowane z FanFilm Beta do architektury ptw.
Logika wyszukiwania identyczna z betą:
  - seriale: Kitsu API (cour structure) → tytuł romaji → szukaj → local_ep
  - filmy:   Kitsu API (get_movie_info) → tytuł kitsu → szukaj
  - fallback: jp_alias + tvshowtitle → contains_all match
"""

import re
import base64
import unicodedata
from datetime import datetime
from urllib.parse import quote_plus

import requests

from ptw.libraries import cleantitle, source_utils, control, client
from ptw.libraries.log_utils import fflog
from ptw.debug import fflog_exc

DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0"


class source:

    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.base_link = "https://desu-online.pl"
        self.search_link = "https://desu-online.pl/?s=%s"
        self.session = requests.Session()
        self.headers = {
            "Host": "desu-online.pl",
            "User-Agent": DEFAULT_UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
            "Accept-Encoding": "identity",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }

    # ------------------------------------------------------------------ #
    #  Publiczne API
    # ------------------------------------------------------------------ #

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        try:
            if not self._is_anime_by_imdb(imdb, 'movie'):
                return None
            from ptw.api import kitsu as kitsu_api
            tmdb = kwargs.get('tmdb')
            movie_info = kitsu_api.get_movie_info(tmdb) if tmdb else None
            if movie_info:
                titles = [movie_info['title'], title]
                fflog(f'desuonline/movie: kitsu="{movie_info["title"]}"')
            else:
                jp_aliases = [a["title"] for a in (aliases or []) if a.get("country") == "jp"]
                titles = (jp_aliases[:1] if jp_aliases else []) + [title]
            return self._search_ep_or_movie(titles, None, None, None, aliases)
        except Exception:
            fflog_exc(1)
            return None

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        jp_aliases = [a["title"] for a in (aliases or []) if a.get("country") == "jp"]
        jp_titles = jp_aliases[:1] if jp_aliases else []
        titles = jp_titles + [tvshowtitle]
        return titles, year, aliases

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        try:
            if not isinstance(url, (list, tuple)) or len(url) < 1:
                return None
            titles = url[0]
            aliases = url[2] if len(url) > 2 else []

            if not self._is_anime_by_tvdb(tvdb, imdb):
                return None

            from ptw.api import kitsu as kitsu_api
            tmdb = kwargs.get('tmdb')
            if tmdb:
                return self._search_with_kitsu(
                    titles, season, episode, str(tmdb), aliases,
                    premiered=premiered,
                    spremiered=kwargs.get('spremiered'),
                    absolute_episode=kwargs.get('absolute_episode'),
                )
            return self._fallback_search(titles, aliases, tvdb, season, episode)
        except Exception:
            fflog_exc(1)
            return None

    def sources(self, url, hostDict=None, hostprDict=None):
        sources_list = []
        if not url:
            return sources_list
        try:
            if isinstance(url, list):
                url = url[0]
            ep_path = url.replace(self.base_link, '').strip('/')
            r = self.session.get(url, headers=self.headers)
            if not r or r.status_code != 200:
                return sources_list
            content = r.text
            content = re.sub(r'(<[^>]*?)\n([^>]*?>)', r'\1 \2', content)
            sourcebox = client.parseDOM(content, 'select', attrs={'class': 'mirror'})
            if not sourcebox:
                return sources_list
            all_options = client.parseDOM(sourcebox[0], 'option')
            all_values  = client.parseDOM(sourcebox[0], 'option', ret='value')
            players = all_options[1:]
            values  = [v for v in all_values if v != '']
            for player, value in zip(players, values):
                try:
                    decoded = self._decrypt(value)
                    if not decoded:
                        continue
                    iframe_srcs = client.parseDOM(decoded, 'iframe', ret='src')
                    if not iframe_srcs:
                        continue
                    iframe_url = iframe_srcs[0]
                    if iframe_url.startswith('//'):
                        iframe_url = 'https:' + iframe_url
                    elif iframe_url.startswith('/'):
                        iframe_url = self.base_link + iframe_url
                    host_match = re.search(r'https?://(?:www\.)?([^/.]+)', iframe_url)
                    host_name = (host_match.group(1) if host_match else player).upper()
                    sources_list.append({
                        "source": host_name, "quality": "720p", "language": "pl",
                        "url": iframe_url, "info": "", "filename": ep_path,
                        "direct": False, "debridonly": False, "premium": False,
                    })
                except Exception:
                    fflog_exc(1)
                    continue
            fflog(f'desuonline: znaleziono zrodel: {len(sources_list)}')
            return sources_list
        except Exception:
            fflog_exc(1)
            return sources_list

    def resolve(self, url):
        return url

    # ------------------------------------------------------------------ #
    #  Kitsu path (identyczny z betą)
    # ------------------------------------------------------------------ #

    def _search_with_kitsu(self, titles, season, episode, tmdb, aliases,
                            premiered=None, spremiered=None, absolute_episode=None):
        try:
            from ptw.api import kitsu as kitsu_api
            cours = kitsu_api.get_cour_structure(tmdb)
            if not cours:
                fflog(f'desuonline/kitsu: brak danych dla tmdb={tmdb}')
                return self._fallback_search(titles, aliases, None, season, episode)

            cour, local_ep = self._resolve_cour(kitsu_api, cours, season, episode,
                                                premiered, spremiered, absolute_episode)
            if not cour:
                fflog(f'desuonline/kitsu: nie znaleziono coura dla tmdb={tmdb}')
                return self._fallback_search(titles, aliases, None, season, episode)

            kitsu_title = cour['title']
            kitsu_norm  = kitsu_api.normalize_romaji(kitsu_title)
            fflog(f'desuonline/kitsu: cour="{kitsu_title}" local_ep={local_ep}')

            control.sleep(200)
            title_normalized = unicodedata.normalize('NFD', kitsu_title)
            title_normalized = ''.join(c for c in title_normalized if unicodedata.category(c) != 'Mn')
            search_url = self.search_link % quote_plus(title_normalized)

            r = self.session.get(search_url, headers=self.headers)
            if not r or r.status_code != 200:
                return None

            listupd = client.parseDOM(r.text, 'div', attrs={'class': 'listupd'})
            if not listupd:
                fflog('desuonline/kitsu: brak wynikow')
                return None

            anime_entries = client.parseDOM(listupd[0], 'div', attrs={'class': 'bsx'})
            fflog(f'desuonline/kitsu: znaleziono {len(anime_entries)} wynikow')

            tmdb_year = None
            if premiered:
                try:
                    tmdb_year = str(datetime.strptime(premiered[:10], '%Y-%m-%d').year)
                except Exception:
                    pass

            candidates = []
            kitsu_words = set(kitsu_norm.split())

            for entry in anime_entries:
                try:
                    links  = client.parseDOM(entry, 'a', ret='href')
                    titles_found = client.parseDOM(entry, 'h2')
                    if not links or not titles_found:
                        continue
                    anime_url   = links[0]
                    anime_title = titles_found[0].strip()

                    year_match = re.search(r'\((\d{4})\)', anime_title)
                    res_year   = year_match.group(1) if year_match else None

                    if res_year and tmdb_year and res_year != tmdb_year:
                        continue

                    anime_norm = kitsu_api.normalize_romaji(anime_title)

                    if anime_norm == kitsu_norm:
                        fflog(f'desuonline/kitsu: exact "{anime_title}" ep {local_ep}')
                        return self._get_episode_link(anime_url, local_ep)

                    anime_words = set(anime_norm.split())
                    if res_year and res_year in anime_words:
                        anime_words.discard(res_year)

                    if kitsu_words.issubset(anime_words) or anime_words.issubset(kitsu_words):
                        if res_year and res_year == tmdb_year:
                            fflog(f'desuonline/kitsu: rok "{anime_title}" ep {local_ep}')
                            return self._get_episode_link(anime_url, local_ep)
                        candidates.append((anime_url, anime_title, len(anime_words)))
                except Exception:
                    continue

            if candidates:
                candidates.sort(key=lambda x: x[2])
                anime_url, anime_title, _ = candidates[0]
                fflog(f'desuonline/kitsu: subset "{anime_title}" ep {local_ep}')
                return self._get_episode_link(anime_url, local_ep)

            fflog(f'desuonline/kitsu: brak dopasowania dla "{kitsu_title}"')
            return None
        except Exception:
            fflog_exc(1)
            return None

    # ------------------------------------------------------------------ #
    #  Fallback tytułowy
    # ------------------------------------------------------------------ #

    def _fallback_search(self, titles, aliases, tvdb, season, episode):
        try:
            if season is not None and episode is not None:
                absolute_ep = source_utils.absoluteNumber(tvdb, episode, season)
                if absolute_ep is None:
                    return None
                target_episode = absolute_ep
            else:
                target_episode = 1
            if not isinstance(titles, (list, tuple)):
                titles = [titles] if titles else []
            return self._search_ep_or_movie(titles, season, episode, target_episode, aliases)
        except Exception:
            fflog_exc(1)
            return None

    def _search_ep_or_movie(self, titles, season, episode, target_episode, aliases):
        try:
            if not isinstance(titles, (list, tuple)):
                titles = [titles] if titles else []
            titles = list(dict.fromkeys([t.lower() for t in titles if t]))

            match_titles = set()
            for a in (aliases or []):
                for key in ('title', 'originalname'):
                    v = a.get(key, '')
                    if v:
                        match_titles.add(cleantitle.normalize(v).lower())
            for t in titles:
                if t:
                    match_titles.add(cleantitle.normalize(t).lower())

            for title in titles:
                if not title:
                    continue
                control.sleep(200)
                t_norm = unicodedata.normalize('NFD', title)
                t_norm = ''.join(c for c in t_norm if unicodedata.category(c) != 'Mn')
                r = self.session.get(self.search_link % quote_plus(t_norm), headers=self.headers)
                if not r or r.status_code != 200:
                    control.sleep(500)
                    continue
                listupd = client.parseDOM(r.text, 'div', attrs={'class': 'listupd'})
                if not listupd:
                    continue
                for entry in client.parseDOM(listupd[0], 'div', attrs={'class': 'bsx'}):
                    try:
                        links  = client.parseDOM(entry, 'a', ret='href')
                        titles_found = client.parseDOM(entry, 'h2')
                        if not links or not titles_found:
                            continue
                        anime_url   = links[0]
                        anime_title = titles_found[0].strip()
                        result_norm = cleantitle.normalize(anime_title).lower()
                        matched = any(
                            all(word in result_norm for word in mt.split())
                            for mt in match_titles
                        )
                        if matched:
                            episode_url = self._get_episode_link(anime_url, target_episode)
                            if episode_url:
                                return episode_url
                            return None
                    except Exception:
                        fflog_exc(1)
                        continue
        except Exception:
            fflog_exc(1)
        return None

    def _get_episode_link(self, anime_url, episode_number):
        try:
            r = self.session.get(anime_url, headers=self.headers)
            if not r or r.status_code != 200:
                return None
            epbox = client.parseDOM(r.text, 'div', attrs={'class': 'eplister'})
            if not epbox:
                return None
            ep_numbers = client.parseDOM(epbox[0], 'div', attrs={'class': 'epl-num'})
            ep_links   = client.parseDOM(epbox[0], 'a', ret='href')
            for ep_num, ep_link in zip(ep_numbers, ep_links):
                num_match = re.search(r'(\d+)', ep_num)
                if num_match and int(num_match.group(1)) == episode_number:
                    return ep_link
            return None
        except Exception:
            fflog_exc(1)
            return None

    # ------------------------------------------------------------------ #
    #  Resolve cour (portowane z kitsu_api.resolve_cour)
    # ------------------------------------------------------------------ #

    def _resolve_cour(self, kitsu_api, cours, season, episode,
                       premiered, spremiered, absolute_episode):
        from datetime import date as dt_date
        abs_ep = absolute_episode

        ep_date = None
        if premiered:
            try:
                ep_date = datetime.strptime(premiered[:10], '%Y-%m-%d').date()
            except Exception:
                pass

        season_start = None
        if spremiered:
            try:
                season_start = datetime.strptime(spremiered[:10], '%Y-%m-%d').date()
            except Exception:
                pass

        cour = None
        local_ep = None

        if ep_date:
            cour, offset = kitsu_api.find_cour_by_date(cours, ep_date)
            if cour:
                tmdb_ep = int(episode) if episode else None
                if (tmdb_ep and season_start and cour['start_date']
                        and season_start <= cour['start_date']):
                    season_offset = sum(
                        c['ep_count'] for c in cours
                        if c['start_date'] and c['ep_count']
                        and season_start <= c['start_date'] < cour['start_date']
                    )
                    local_ep = tmdb_ep - season_offset
                elif abs_ep:
                    local_ep = abs_ep - offset
                else:
                    cour = None

                if local_ep and (local_ep < 1 or (cour and cour['ep_count'] and local_ep > cour['ep_count'])):
                    cour = None

        if not cour:
            if not abs_ep:
                abs_ep = int(episode) if episode else 1
            cour, local_ep = kitsu_api.map_episode(cours, abs_ep)

        return cour, local_ep

    def _is_anime_by_imdb(self, imdb, content_type):
        try:
            if imdb:
                return source_utils.is_anime(content_type, 'imdb', imdb)
        except Exception:
            pass
        return True

    def _is_anime_by_tvdb(self, tvdb, imdb):
        try:
            if tvdb:
                return source_utils.is_anime('show', 'tvdb', tvdb)
            if imdb:
                return source_utils.is_anime('show', 'imdb', imdb)
        except Exception:
            pass
        return True

    def _decrypt(self, hashed):
        try:
            return base64.b64decode(hashed.encode('ascii')).decode('ascii')
        except Exception:
            return ""
