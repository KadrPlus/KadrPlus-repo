# -*- coding: utf-8 -*-
"""
FanFilm - źródło: player.pl (VOD PL)
Copyright (C) 2025 FF Team

Odtwarza tylko darmowe treści (payable=False) — archiwum TVP,
polskie filmy i seriale, bajki, dokumenty.
Nie wymaga logowania, konto Android TV jest generowane losowo.
"""

import re
import json
import random
from urllib.parse import urlencode, parse_qs

import requests as _requests

from ptw.libraries import cleantitle
from ptw.libraries.log_utils import fflog
from ptw.debug import fflog_exc


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['pl']
        self.base_url  = 'https://player.pl/'
        self.api_url   = 'https://player.pl/playerapi/'
        self.platform  = 'ANDROID_TV'
        self.UA = (
            'playerTV/2.2.2 (455) (Linux; Android 8.0.0; Build/sdk_google_atv_x86) '
            'net/sdk_google_atv_x86userdebug 8.0.0 OSR1.180418.025 6695156 testkeys'
        )
        self.device_uid = self._code_gen(16)
        self.uid        = self._code_gen(32)

    def _code_gen(self, length):
        base = '0123456789abcdef'
        return ''.join(random.choice(base) for _ in range(length))

    def _headers(self):
        cid = (
            f"androidTV_{self._code_gen(8)}-{self._code_gen(4)}"
            f"-{self._code_gen(4)}-{self._code_gen(4)}-{self._code_gen(12)}"
        )
        return {
            'User-Agent':      self.UA,
            'accept-encoding': 'gzip',
            'api-correlationid': cid,
            'api-deviceuid':     self.device_uid,
            'api-deviceinfo':    'sdk_google_atv_x86;unknown;Android;8.0.0;Unknown;2.2.2 (455);',
        }

    def _cookies(self):
        return {'uid': self.uid}

    def _is_available(self, item):
        if item.get('payable', False):
            return False
        try:
            schedules = [s for s in item.get('displaySchedules', []) if s.get('active')]
            if schedules and schedules[0].get('type') == 'SOON':
                return False
        except Exception:
            pass
        return True

    def _get_quality(self, item):
        if item.get('uhd'):
            return '4K'
        quality = 'SD'
        for typ in ['android_tv', 'pc', 'smart_tv', 'playstation', 'mobile', 'apple_tv']:
            imgs = item.get('images', {}).get(typ, [])
            if imgs and 'mainUrl' in imgs[0]:
                match = re.search(r'dstw=(\d+)&dsth=(\d+)', imgs[0]['mainUrl'])
                if match:
                    h = int(match.group(2))
                    if   h >= 1080: quality = '1080p'
                    elif h >= 720:  quality = '720p'
                    elif h >= 480:  quality = '480p'
                    elif h >= 360:  quality = '360p'
                    if quality != 'SD':
                        break
        return quality

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        return self._search_movie(title, localtitle, year, aliases)

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        return (tvshowtitle, localtvshowtitle, aliases), year

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        titles = self._extract_titles(url, title)
        if not titles:
            return []
        year = None
        if isinstance(url, tuple) and len(url) == 2:
            year = str(url[1]) if url[1] else None
        series_id = self._find_series(titles, year=year)
        if not series_id:
            return []
        return self._get_episodes(series_id, int(season), int(episode), episode_title=title)

    def sources(self, rows, hostDict=None, hostprDict=None):
        if not rows:
            return []
        sources = []
        for el in rows:
            try:
                item_type = el.get('type', 'VOD')
                info  = ''
                info2 = ''
                if item_type == 'EPISODE':
                    season_n  = el.get('season', {}).get('number', 0)
                    episode_n = el.get('episode', 0)
                    info2     = el.get('season', {}).get('serial', {}).get('title', '')
                    ep_title  = el.get('title', '')
                    if ep_title:
                        info = f'S{season_n:02d}E{episode_n:02d} - {ep_title}'
                sources.append({
                    'source':    '',
                    'quality':   self._get_quality(el),
                    'language':  'pl',
                    'url':       f"PLAYERPL|{el.get('id')}|{item_type}",
                    'info':      info,
                    'info2':     info2,
                    'direct':    False,
                    'debridonly': False,
                })
            except Exception:
                fflog_exc(1)
        fflog(f'[vodpl] przekazano źródeł: {len(sources)}')
        return sources

    def resolve(self, url):
        if not url.startswith('PLAYERPL|'):
            return url
        try:
            _, item_id, item_type = url.split('|')

            item_data = _requests.get(
                f"{self.api_url}product/vod/{item_id}",
                headers=self._headers(),
                cookies=self._cookies(),
                params={'4K': 'true', 'platform': self.platform},
                timeout=10, verify=False,
            ).json()

            tid = (item_data.get('shareUrl', '')
                   .replace(self.base_url, '')
                   .replace(',', '_').replace('-', '_').replace('/', '_'))

            playlist_data = _requests.get(
                f"{self.api_url}item/{item_id}/playlist",
                headers=self._headers(),
                cookies=self._cookies(),
                params={
                    'type': 'MOVIE', 'page': tid,
                    '4K': 'true', 'platform': self.platform, 'version': '3.1',
                },
                timeout=10, verify=False,
            ).json()

            if playlist_data.get('code'):
                fflog(f'[vodpl] błąd playlist: {playlist_data.get("code")}', 1, 1)
                return None

            video       = playlist_data.get('movie', {}).get('video', {})
            sources_api = video.get('sources', {})
            protections = video.get('protections', {})

            if sources_api.get('dash'):
                stream = sources_api['dash']['url']
                if protections.get('widevine'):
                    lic = protections['widevine']['src']
                    hea = urlencode({'User-Agent': self.UA, 'Referer': self.base_url, 'Content-Type': ''})
                    adaptive_data = {
                        'protocol': 'mpd', 'mimetype': 'application/dash+xml',
                        'manifest': stream, 'licence_type': 'com.widevine.alpha',
                        'licence_url': lic, 'licence_header': hea,
                        'post_data': 'R{SSM}', 'response_data': '',
                    }
                    return f"DRMCDA|{repr(adaptive_data)}"
                # DASH bez DRM
                adaptive_data = {
                    'protocol': 'mpd', 'mimetype': 'application/dash+xml',
                    'manifest': stream, 'licence_type': '', 'licence_url': '',
                    'licence_header': '', 'post_data': '', 'response_data': '',
                }
                return f"DRMCDA|{repr(adaptive_data)}"

            if sources_api.get('hls'):
                return sources_api['hls']['url']

        except Exception:
            fflog_exc(1)
        return None

    def _search_movie(self, title, localtitle, year, aliases):
        # Tylko localtitle + title — BEZ iterowania przez aliasy.
        # Aliasy z TMDB mogą mieć 20+ tytułów → każdy to osobne zapytanie × 15s timeout.
        search_titles = []
        for t in [localtitle, title]:
            if t and t not in search_titles:
                search_titles.append(t)
        # Maksymalnie 2 zapytania — localtitle i title wystarczą do dopasowania
        search_titles = search_titles[:2]

        cleaned = [cleantitle.get(t) for t in search_titles]
        # Zbuduj rozszerzony zbiór do dopasowania (tytuł + aliasy PL)
        match_cleaned = set(cleaned)
        if aliases:
            for a in aliases:
                t = a.get('title') or a.get('originalname', '')
                if t:
                    match_cleaned.add(cleantitle.get(t))

        results = []
        _timeout_count = 0

        for q in search_titles:
            try:
                resp = _requests.get(
                    self.api_url + 'item/search',
                    headers=self._headers(),
                    cookies=self._cookies(),
                    params={'4K': 'true', 'platform': self.platform, 'keyword': q, 'episodes': 'true'},
                    timeout=8, verify=False,
                )
                if resp.status_code != 200:
                    continue
                for item in resp.json():
                    el = item.get('element')
                    if not el or el.get('type') != 'VOD' or not self._is_available(el):
                        continue
                    match_title = el.get('title', '')
                    if not match_title or cleantitle.get(match_title) not in match_cleaned:
                        continue
                    if year:
                        y = el.get('year')
                        if y:
                            try:
                                if abs(int(year) - int(y)) > 1:
                                    continue
                            except Exception:
                                pass
                    if el not in results:
                        results.append(el)
                if results:
                    break  # znaleziono — nie pytaj kolejnych tytułów
            except Exception:
                fflog_exc(1)
                _timeout_count += 1
                if _timeout_count >= 1:
                    fflog('[vodpl] player.pl nie odpowiada — przerywam')
                    break  # serwer niedostępny — nie marnuj czasu na kolejne zapytania

        fflog(f'[vodpl] znaleziono filmów: {len(results)}')
        return results if results else None

    def _extract_titles(self, url, default_title):
        titles = []
        try:
            if isinstance(url, tuple) and len(url) == 2 and isinstance(url[0], tuple):
                t0, t1, aliases = (url[0] + (None,) * 3)[:3]
                for t in [t0, t1]:
                    if t and t not in titles:
                        titles.append(t)
                if aliases:
                    for a in aliases:
                        if isinstance(a, dict):
                            t = a.get('title') or a.get('originalname', '')
                            if t and t not in titles:
                                titles.append(t)
            elif isinstance(url, str):
                params = parse_qs(url)
                for k in ('titles', 'tvshowtitle', 'localtvshowtitle'):
                    val = params.get(k, [None])[0]
                    if val and val not in titles:
                        titles.append(val)
            elif isinstance(url, dict) and 'titles' in url:
                for t in url['titles']:
                    if t and t not in titles:
                        titles.append(t)
        except Exception:
            fflog_exc(1)
        if not titles and default_title:
            titles.append(default_title)
        return list({t.lower(): t for t in titles}.values())

    def _find_series(self, titles, year=None):
        cleaned = [cleantitle.get(t) for t in titles]
        for t in titles:
            try:
                resp = _requests.get(
                    self.api_url + 'item/search',
                    headers=self._headers(),
                    cookies=self._cookies(),
                    params={'4K': 'true', 'platform': self.platform, 'keyword': t, 'episodes': 'false'},
                    timeout=8, verify=False,
                )
                if resp.status_code != 200:
                    continue
                for item in resp.json():
                    el = item.get('element')
                    if not el or el.get('type') != 'SERIAL' or not self._is_available(el):
                        continue
                    if cleantitle.get(el.get('title', '')) not in cleaned:
                        continue
                    if year and el.get('year'):
                        try:
                            if abs(int(year) - int(el['year'])) > 1:
                                continue
                        except Exception:
                            pass
                    fflog(f'[vodpl] znaleziono serial: {el.get("title")}')
                    return el.get('id')
            except Exception:
                fflog_exc(1)
                fflog('[vodpl] player.pl nie odpowiada — przerywam serial search')
                break  # serwer niedostępny — nie marnuj czasu na kolejne tytuły
        return None

    def _get_episodes(self, series_id, season, episode, episode_title=None):
        try:
            resp = _requests.get(
                f"{self.api_url}product/vod/serial/{series_id}/season/list",
                headers=self._headers(), cookies=self._cookies(),
                params={'4K': 'true', 'platform': self.platform},
                timeout=10, verify=False,
            )
            if resp.status_code != 200:
                return []
            seasons = resp.json()
            target_season = next((s for s in seasons if s.get('number') == season), None)
            if not target_season:
                return []

            resp = _requests.get(
                f"{self.api_url}product/vod/serial/{series_id}/season/{target_season['id']}/episode/list",
                headers=self._headers(), cookies=self._cookies(),
                params={'4K': 'true', 'platform': self.platform},
                timeout=10, verify=False,
            )
            if resp.status_code != 200:
                return []
            episodes = resp.json()

            # Dopasowanie po tytule (jak beta) — dokładniejsze
            if episode_title:
                results = [
                    ep for ep in episodes
                    if ep.get('title', '').lower() == episode_title.lower()
                    and self._is_available(ep)
                ]
                if results:
                    fflog(f'[vodpl] odcinek dopasowany po tytule: {episode_title!r}')
                    return results

            # Fallback: numer odcinka
            results = [ep for ep in episodes if ep.get('episode') == episode and self._is_available(ep)]
            fflog(f'[vodpl] odcinki S{season:02d}E{episode:02d}: {len(results)}')
            return results

        except Exception:
            fflog_exc(1)
            return []
