"""
    FanFilm Add-on
    Copyright (C) 2018 CherryTeam

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# import requests
from ptw.libraries import cleantitle
from ptw.libraries import source_utils, client
from ptw.libraries.log_utils import fflog
from ptw.debug import fflog_exc

try:
    import urllib.parse as urllib
except:
    pass


class source:

    def __init__(self):
        fflog(f'.',0,1)
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["iitv.info"]

        self.base_link = "https://iitv.info/"
        # self.search_link = "https://iitv.info/szukaj"  # niepotrzebny
        self.session = None
        # self.session = requests.Session()


    def contains_word(self, str_to_check, word):
        if str(word).lower() in str(str_to_check).lower():
            return True
        return False


    def contains_all_words(self, str_to_check, words):
        for word in words:
            if not self.contains_word(str_to_check, word):
                return False
        return True


    def search(self, titles, season, episode):
        # fflog(f'{titles=} {season=} {episode=}',1,1)
        if not self.session:
            import requests
            self.session = requests.Session()

        try:
            headers = {
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
                        "Referer": self.base_link,
            }

            result0 = self.session.get(self.base_link, headers=headers)

            if not result0:
                fflog(f'{result0=}',1,1)

            result0 = result0.text

            results = []

            titles = list(filter(None, titles))  # usunięcie pustych
            titles = list(dict.fromkeys(titles))  # pozbycie się duplikatów

            for title in titles:
                # fflog(f'{title=}',1,1)

                if not title:
                    continue

                if result0 is None:
                    continue

                if not results:
                    query = "S%02dE%02d" % (int(season), int(episode))
                    fflog(f'odcinek {query=}',1,1)

                    result = client.parseDOM(result0, "ul", attrs={"id": "allSeries"})
                    results = client.parseDOM(result, "li")

                fflog(f'{len(results)=}',1,1)
                for result in results:
                    # fflog(f'\n{result=}',1,1)
                    try:
                        found_title = client.parseDOM(result, "a", ret="title")[0]
                        # fflog(f'{found_title=}',1,1)
                        words = title.split(" ")
                        if self.contains_all_words(found_title, words):
                            fflog(f'pasuje serial {found_title=}',1,1)
                            link_serial = client.parseDOM(result, "a", ret="href")[0]
                            serial_content = self.session.get(self.base_link + link_serial, headers=headers)
                            if not serial_content:
                                fflog(f'{serial_content=}',1,1)
                            serial_content = serial_content.text
                            serial_content = client.parseDOM(serial_content, "div", attrs={"class": "episodesLinksWrap"})
                            link_odcinki = client.parseDOM(serial_content, "a", ret="href")
                            nazwa_odcinki = client.parseDOM(serial_content, "a")
                            for link_odcinek, nazwa_odcinkek in zip(link_odcinki, nazwa_odcinki):
                                if nazwa_odcinkek.lower() == query.lower():
                                    fflog(f'dopasowano odcinek {nazwa_odcinkek=}  {link_odcinek=}',1,1)
                                    return link_odcinek
                                else:
                                    # fflog(f'to nie ten odcinek {nazwa_odcinkek=}',1,1)
                                    pass
                        else:
                            # fflog(f'to nie ten serial {found_title=}  {words=}',1,1)
                            pass
                    except Exception:
                        fflog_exc(1)
                        pass

            fflog(f'nie znaleziono takiego serialu',1,1)
        except Exception as e:
            fflog_exc(1)
            pass


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # fflog(f'{imdb=} {tvdb=} {tvshowtitle=} {localtvshowtitle=} {year=} {aliases=}',1,1)
        return [
                tvshowtitle,
                localtvshowtitle,
                cleantitle.normalize(cleantitle.getsearch(tvshowtitle)),
                cleantitle.normalize(cleantitle.getsearch(localtvshowtitle)), 
               ]


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # fflog(f'{url=}  {imdb=} {tvdb=} {title=} {premiered} {season=} {episode=}',1,1)
        return self.search(url, season, episode)


    def sources(self, url, hostDict, hostprDict):
        if not self.session:
            import requests
            self.session = requests.Session()

        sources = []

        try:
            if url is None:
                return sources

            headers = {
                       "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
                       "Referer": self.base_link,
                       "Referer": self.base_link + url,
            }

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
                "Accept": "*/*",
                "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
                "X-Requested-With": "XMLHttpRequest",
                "Connection": "keep-alive",
                "Referer": self.base_link + url,
                "TE": "Trailers",
            }

            output = self.session.get(self.base_link + url, headers=headers)
            if not output:
                fflog(f'{output=}',1,1)
            output = output.text

            output = client.parseDOM(output, "ul", attrs={"class": "singleTab"})
            links = client.parseDOM(output, "a", ret="data-href")

            # fflog(f'{len(links)=}',1,1)
            for link in links:
                try:
                    result = self.check_link(link, hostDict, headers)
                    if not result:
                        continue
                    sources.append({
                                    "source": result[0],
                                    "quality": result[1],
                                    "language": "pl",
                                    "url": result[2],
                                    "info": "",
                                    "info2": url.replace("epizod,", "").replace(".html", ""),
                                    "direct": False,
                                    "debridonly": False,
                                  })
                except Exception:
                    fflog_exc(1)
                    continue
            # return sources
        except Exception as e:
            fflog_exc(1)
            # return sources
            pass
        fflog(f'Przekazano źródeł: {len(sources)}',1,1)
        return sources


    def check_link(self, linkE, testDict, headers):
        # fflog(f'{linkE=}',1,1)
        result = self.session.get(self.base_link + linkE, headers=headers)
        if result is None or result.status_code >= 400:
            fflog(f'{result=}',1,1)
        result = result.text
        link = client.parseDOM(result, "a", ret="href")
        if link:
            link = link[0]
        else:
            link = ""
        valid, host = source_utils.is_host_valid(link, testDict)
        if not valid:
            # fflog(f'not valid  {host=}  {link=}',1,1)
            return 0
        q = source_utils.check_sd_url(link)
        # fflog(f'dozwolony  {host=}  {link=}  {q=}',1,1)
        return host, q, link


    def resolve(self, url):
        return url
