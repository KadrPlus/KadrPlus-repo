# -*- coding: utf-8 -*-
"""
FanFilm - źródło: lokalna lista M3U (bez fallbacku)
Wsparcie dla: plików lokalnych, URL, wielu list, różnych trybów wyszukiwania
"""

import time
import re
import unicodedata
import os
import xbmcaddon
import urllib.request
import urllib.parse
import urllib.error

import hashlib
import json
# from ast import literal_eval
from ptw.libraries import cache
from ptw.libraries import cleantitle, source_utils
from ptw.debug import fflog, fflog_exc


class source:

    def __init__(self):
        self.priority = 1
        self.language = ['pl']
        self.useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0'
        self.m3u_sources = []  # lista źródeł M3U: {'type': 'file'/'url', 'path': ścieżka/URL}
        self.search_mode = 'first'  # 'first' - pierwsze znalezione, 'all' - wszystkie pasujące
        self.all_found_urls = []  # TU JEST KLUCZ: przechowuje wszystkie URL znalezione w trybie "all"
        self.all_entries = []


    @staticmethod
    def get_data_hash(data_obj):
        # 1. Normalizacja: sort_keys=True jest KLUCZOWE
        # separator pozbywa się zbędnych spacji, co ujednolica string
        normalized_json = json.dumps(data_obj, sort_keys=True, separators=(',', ':'))
        return hashlib.sha256(normalized_json.encode('utf-8')).hexdigest()


    def _get_m3u_sources(self):
        """Pobiera listę źródeł M3U z ustawień FanFilm."""
        try:
            addon = xbmcaddon.Addon()
            sources = []
            
            # Pobierz tryb wyszukiwania
            self.search_mode = addon.getSetting('lista_m3u.search_mode') or '0'
            
            # Konwersja z wartości enum (0/1) na tekst
            if self.search_mode == '0':
                self.search_mode = 'first'
            elif self.search_mode == '1':
                self.search_mode = 'all'
            else:
                self.search_mode = 'all'  # domyślnie


            # Pojedynczy plik M3U
            if addon.getSetting('lista_m3u.file.enable') == 'true':
                single_path = addon.getSetting('lista_m3u.file') or ''
                if single_path and single_path.strip():
                    sources.append({'type': 'file', 'path': single_path.strip()})

            if addon.getSetting('lista_m3u.file2.enable') == 'true':
                single_path = addon.getSetting('lista_m3u.file2') or ''
                if single_path and single_path.strip():
                    sources.append({'type': 'file', 'path': single_path.strip()})


            # Wiele plików M3U
            multi_files = addon.getSetting('lista_m3u.files') or ''
            if multi_files and multi_files.strip():
                for file_path in multi_files.split('|'):
                    file_path = file_path.strip()
                    if file_path and not file_path.startswith('!') and not file_path.endswith('/'):
                        sources.append({'type': 'file', 'path': file_path})


            # URL do list M3U
            url = addon.getSetting('lista_m3u.server').rstrip('/').strip() or ''
            if url and (url.startswith('http://') or url.startswith('https://')):
                username = addon.getSetting('lista_m3u.username').strip() or ''
                password = addon.getSetting('lista_m3u.password').strip() or ''
                url = f'{url}/get.php?username={username}&password={password}&type=m3u_plus'
                # fflog(f'{url=}', 1,1)
                sources.append({'type': 'url', 'path': url})

            urls = addon.getSetting('lista_m3u.urls') or ''
            if urls and urls.strip():
                for url in urls.split('|'):
                    url = url.strip()
                    if url and (url.startswith('http://') or url.startswith('https://')):
                        sources.append({'type': 'url', 'path': url})

            sources = [source for x, source in enumerate(sources) if source not in sources[:x]]  # eliminacja dubli
            if sources:
                fflog(f'lista_m3u: {len(sources)} źródła M3U, tryb: {self.search_mode}', 1, 1)
            else:
                fflog(f'{len(sources)=}', 1,1)
            # fflog(f'{len(sources)=}  {sources=}', 1,1)

            try:
                prev_hash_sources = cache.cache_get("lista_m3u.settings_sources")["value"]
            except:
                prev_hash_sources = ''
            curr_hash_sources = self.get_data_hash(sources)
            if curr_hash_sources != prev_hash_sources:
                fflog(f'wykryto zmianę ustawień źródeł - nastąpi wyczyszczenie cache wpisów', 1,1)
                cache.cache_insert("lista_m3u.all_entries", '')
                cache.cache_insert("lista_m3u.settings_sources", curr_hash_sources)
                time.sleep(0.1)

            return sources
            
        except Exception as e:
            fflog(f'lista_m3u: błąd odczytu ustawień: {e}', 1, 1)
            fflog_exc(1)
            return []


    def _download_from_url(self, url, timeout=40):
        """Pobiera zawartość M3U z URL."""
        try:
            req = urllib.request.Request(
                url,
                headers={
                    'User-Agent': self.useragent,
                    'Accept': '*/*',
                    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                    'Connection': 'keep-alive'
                }
            )
            with urllib.request.urlopen(req, timeout=timeout) as response:
                content = response.read()
                # Spróbuj różne kodowania
                try:
                    return content.decode('utf-8')
                except UnicodeDecodeError:
                    try:
                        return content.decode('latin-1')
                    except UnicodeDecodeError:
                        return content.decode('utf-8', errors='ignore')
                        
        except urllib.error.URLError:
            fflog_exc(1)
            return None
        except Exception:
            fflog_exc(1)
            return None


    def _is_cyrillic(self, text):
        """Sprawdza czy tekst zawiera cyrylicę."""
        # fflog('_is_cyrillic',1,1)
        if not text:
            return False
        
        # Zakresy Unicode dla cyrylicy
        cyrillic_ranges = [
            (0x0400, 0x04FF),  # Cyrillic
            (0x0500, 0x052F),  # Cyrillic Supplement
            (0x2DE0, 0x2DFF),  # Cyrillic Extended-A
            (0xA640, 0xA69F),  # Cyrillic Extended-B
        ]
        
        for char in text:
            code = ord(char)
            for start, end in cyrillic_ranges:
                if start <= code <= end:
                    # fflog('koniec _is_cyrillic',1,1)
                    return True
        # fflog('koniec _is_cyrillic',1,1)
        return False


    def _transliterate_cyrillic(self, text):
        """Transliteracja tekstu cyrylickiego na łaciński."""
        # fflog('_transliterate_cyrillic',1,1)
        
        if not text:
            return text
        
        # Jeśli nie ma cyrylicy, zwróć oryginał
        if not self._is_cyrillic(text):
            return text
        
        # Słownik transliteracji rosyjskiej
        cyrillic_map = {
            'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd',
            'е': 'e', 'ё': 'yo', 'ж': 'zh', 'з': 'z', 'и': 'i',
            'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n',
            'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't',
            'у': 'u', 'ф': 'f', 'х': 'kh', 'ц': 'ts', 'ч': 'ch',
            'ш': 'sh', 'щ': 'shch', 'ъ': '', 'ы': 'y', 'ь': '',
            'э': 'e', 'ю': 'yu', 'я': 'ya',
            'А': 'a', 'Б': 'b', 'В': 'v', 'Г': 'g', 'Д': 'd',
            'Е': 'e', 'Ё': 'yo', 'Ж': 'zh', 'З': 'z', 'И': 'i',
            'Й': 'y', 'К': 'k', 'Л': 'l', 'М': 'm', 'Н': 'n',
            'О': 'o', 'П': 'p', 'Р': 'r', 'С': 's', 'Т': 't',
            'У': 'u', 'Ф': 'f', 'Х': 'kh', 'Ц': 'ts', 'Ч': 'ch',
            'Ш': 'sh', 'Щ': 'shch', 'Ъ': '', 'Ы': 'y', 'Ь': '',
            'Э': 'e', 'Ю': 'yu', 'Я': 'ya'
        }
        
        result = []
        for char in text:
            if char in cyrillic_map:
                result.append(cyrillic_map[char])
            else:
                result.append(char)
        # fflog('koniec _transliterate_cyrillic',1,1)
        return ''.join(result)


    def _normalize_m3u_title(self, title):
        """Normalizacja tytułu z M3U."""
        # fflog('_normalize_m3u_title',1,1)
        if not title:
            return '', None
        
        # 1. Wyodrębnij rok z tytułu
        year_match = re.search(r'\((\d{4})\)', title)
        year = (year_match.group(1)) if year_match else None
        
        # 2. Usuń rok z tytułu
        if year:
            # title = re.sub(r'\s*\(\d{4}\)\s*', '', title)
            # title = re.sub(fr'\s*\({year}\)\s*', '', title)
            title = title.replace(year, '').replace('()', '').strip()
            # year = int(year)
        
        # 3. Zamień podkreślniki na spacje
        title = title.replace('_', ' ')
        
        # 4. Transliteruj TYLKO cyrylicę
        title = self._transliterate_cyrillic(title)
        
        # 5. Użyj oryginalnego cleantitle.get()
        title_clean = cleantitle.get(title)
        # fflog('koniec _normalize_m3u_title',1,1)
        return title_clean, year


    def _normalize_search_title(self, title):
        """Normalizacja tytułu do wyszukiwania."""
        # fflog('_normalize_search_title',1,1)
        if not title:
            return ''
        
        # Transliteruj TYLKO jeśli zawiera cyrylicę
        title = self._transliterate_cyrillic(title)
        # fflog('koniec _normalize_search_title',1,1)
        return cleantitle.get(title)


    def _parse_m3u(self, content, source_name=""):
        """Parsowanie listy M3U."""
        # fflog('_parse_m3u',1,1)
        entries = []
        lines = content.splitlines()
        
        for i in range(len(lines)):
            if lines[i].startswith('#EXTINF'):
                m = re.search(r'tvg-name="([^"]+)"', lines[i])
                title = m.group(1) if m else None
                
                # Jeśli nie ma tvg-name, spróbuj z końca linii
                if not title:
                    parts = lines[i].split(',')
                    if len(parts) > 1:
                        title = parts[-1].strip()
                
                if not title:
                    continue
                
                # Rok z tvg-name
                year_match = re.search(r'\((\d{4})\)', lines[i])
                year = int(year_match.group(1)) if year_match else None
                
                url = lines[i + 1].strip() if i + 1 < len(lines) else None
                
                if title and url:
                    # Normalizuj
                    title_clean, m3u_year = self._normalize_m3u_title(title)
                    
                    # Priorytet: rok z tvg-name, potem z tytułu
                    final_year = int(year) if year is not None else m3u_year

                    m = re.search(r'group-title="([^"]+)"', lines[i])
                    group_title = m.group(1) if m else ''
                    # if not group_title:
                        # fflog(f'{lines[i]=}',1,1)

                    # m = re.search(r'tvg-id="([^"]+)"', lines[i])
                    # tvg_id = m.group(1) if m else ''

                    entries.append({
                        'group_title': group_title,
                        'original_title': title,
                        'title_clean': title_clean,
                        'year': final_year,
                        'url': url,
                        # 'source': source_name,  # to było tylko informacyjnie, czy plik lokalny, czy zdalny
                        # 'tvg_id':, tvg_id,  # czasami powtórzony tytuł jest
                    })
                    # fflog(f'{entries[-1]=}',1,1)
        # fflog('koniec _parse_m3u',1,1)
        return entries


    def get_cached_m3u(self):
        """Pobiera wszystkie listy M3U ze wszystkich źródeł."""
        # fflog('get_cached_m3u',1,1)
        try:
            self.m3u_sources = self._get_m3u_sources()

            if not self.m3u_sources:
                return None

            if self.all_entries:
                return self.all_entries
            else:
                try:
                    # self.all_entries = literal_eval(cache.cache_get("lista_m3u.all_entries")["value"])
                    self.all_entries = json.loads(cache.cache_get("lista_m3u.all_entries")["value"])
                    fflog('pobrano z cache',1,1)
                    return self.all_entries
                except:
                    pass
            
            all_entries = []

            # fflog(f'{len(self.m3u_sources)=}',1,1)
            for source_info in self.m3u_sources:

                source_type = source_info['type']
                source_path = source_info['path']
                # source_name = f"{source_type}:{os.path.basename(source_path) if source_type == 'file' else 'url'}"
                source_name = ""
                
                content = None
                
                if source_type == 'file':
                    # Plik lokalny
                    if not os.path.exists(source_path):
                        continue
                    
                    try:
                        with open(source_path, "r", encoding="utf-8") as f:
                            content = f.read()
                    except UnicodeDecodeError:
                        try:
                            with open(source_path, "r", encoding="latin-1") as f:
                                content = f.read()
                        except Exception:
                            continue
                    except Exception:
                        continue
                
                elif source_type == 'url':
                    # URL
                    content = self._download_from_url(source_path)
                    if not content:
                        continue
                
                if content:
                    entries = self._parse_m3u(content, source_name)
                    all_entries.extend(entries)
            
            # if all_entries:
            fflog(f'lista_m3u: Załadowano {len(all_entries)} wpisów M3U', 1, 1)
            # fflog('koniec get_cached_m3u',1,1)
            if 1:
                fflog(f'odrzucanie kanałów TV',1,1)
                tv_keywords = ['telewizja', ' tv', 'tv ', 'sport', 'news', 'music', 'radio', 'live',
                               'wydarzenia24', 'informac', 'regionalne', 
                               'ogólne', 'tematyczne',
                               'sport', 'extra', 'piłka', 'eurosport', 'hokej',
                               # 'tvp', 'tvn', 'polsat',
                               # 'kids',
                               'xxx', 'for adults',
                               ]
                all_entries = [entry for entry in all_entries if all(kw not in entry.get('group_title', '').lower() for kw in tv_keywords)]
                all_entries = [entry for entry in all_entries if '.' in entry['url'][-5:-3]]
            self.all_entries = all_entries
            fflog(f'{len(all_entries)=}',1,1)
            if all_entries:
                try:
                    # cache.cache_insert("lista_m3u.all_entries", repr(all_entries))  # wstawienie do bazy
                    cache.cache_insert("lista_m3u.all_entries", json.dumps(all_entries))  # wstawienie do bazy
                    fflog('zapisano do cache',1,1)
                except:
                    pass
            return all_entries
            
        except Exception as e:
            fflog(f'lista_m3u: Błąd w get_cached_m3u: {e}', 1, 1)
            fflog_exc(1)
            return None


    def _search_items(self, title, year=None, season=None, episode=None):
        """Wyszukiwanie filmu we wszystkich listach M3U."""
        # fflog('_search_items',1,1)
        entries = self.get_cached_m3u()
        # fflog(f'{len(entries)=}',1,1)
        if not entries:
            return [] if self.search_mode == 'all' else None
        
        search_title_clean = self._normalize_search_title(title)  # szukany tytuł
        if episode:
            search_title_clean += f"s{season:>02}e{episode:>02}"
        # fflog(f'{search_title_clean=}',1,1)
        found_urls = []
        
        # 1. Najpierw próbuj dokładne dopasowanie z rokiem
        for e in entries:
            # fflog(f'1) {e=}',1,1)
            if search_title_clean == e['title_clean']:
                if year and e['year']:
                    if int(year) == e['year']:
                        if self.search_mode == 'first':
                            return (e['url'], e['original_title'], e['group_title'])
                        else:
                            found_urls.append((e['url'], e['original_title'], e['group_title']))
                else:
                    if self.search_mode == 'first':
                        return (e['url'], e['original_title'], e['group_title'])
                    else:
                        found_urls.append((e['url'], e['original_title'], e['group_title']))
        
        if found_urls and self.search_mode == 'first':
            return found_urls[0]
        
        # 2. Jeśli nie znaleziono z rokiem, spróbuj BEZ roku
        if year:
            for e in entries:
                # fflog(f'2) {e=}',1,1)
                if search_title_clean == e['title_clean']:
                    if self.search_mode == 'first':
                        return (e['url'], e['original_title'], e['group_title'])
                    else:
                        found_urls.append((e['url'], e['original_title'], e['group_title']))
        
        if found_urls and self.search_mode == 'first':
            return found_urls[0]
        
        # 3. Próbuj częściowe dopasowanie
        for e in entries:
            # fflog(f'3) {e=}',1,1)
            if search_title_clean in e['title_clean'] or len(e['title_clean']) > 3 and e['title_clean'] in search_title_clean:
                if not episode and re.search(r's\d{2}e\d{2,4}$', e['title_clean']):
                    continue
                if episode and not re.search(r's\d{2}e\d{2,4}$', e['title_clean']):
                    continue
                if year and e['year']:
                    if int(year) == e['year']:
                        # fflog(f"{e['title_clean']=}  {search_title_clean=}",1,1)
                        if self.search_mode == 'first':
                            return (e['url'], e['original_title'], e['group_title'])
                        else:
                            found_urls.append((e['url'], e['original_title'], e['group_title']))
                else:
                    if self.search_mode == 'first':
                        return (e['url'], e['original_title'], e['group_title'])
                    else:
                        found_urls.append((e['url'], e['original_title'], e['group_title']))
        # fflog('prawie koniec _search_items',1,1)
        if found_urls:
            if self.search_mode == 'first':
                return found_urls[0]
            else:
                return found_urls
        
        return [] if self.search_mode == 'all' else None


    def search(self, title, localtitle, aliases, year, season=None, episode=None):
        """Główna metoda wyszukiwania"""
        try:
            # DEBUG: podsumowanie danych z TMDB
            fflog(f'lista_m3u: Szukam filmu: "{title}" / "{localtitle}", rok: {year}', 1, 1)
            
            # Lista kandydatów
            candidates = []
            
            # 1. Tytuł lokalny (polski)
            if localtitle:
                candidates.append(localtitle)
            
            # 2. Tytuł oryginalny
            if title:
                candidates.append(title)
            
            # 3. WSZYSTKIE aliasy z TMDB (wszystkie języki)
            if aliases and isinstance(aliases, list):
                for alias in aliases:
                    if isinstance(alias, dict):
                        alias_title = alias.get('title') or alias.get('originalname')
                        if alias_title and alias_title not in candidates:
                            # fflog(f'{alias_title=}',1,1)
                            alias_title = alias_title.replace(year, '').strip()
                            # fflog(f'{alias_title=}',1,1)
                            candidates.append(alias_title)
            
            # Usuń duplikaty
            unique_candidates = []
            seen = set()
            for candidate in candidates:
                if candidate and candidate not in seen:
                    seen.add(candidate)
                    unique_candidates.append(candidate)
            
            # Próbuj każdego kandydata
            all_found_urls = []  # Zbierz wszystkie URL dla trybu "all"

            fflog(f'{len(unique_candidates)=}',1,1)
            for candidate in unique_candidates:
                # fflog(f'{candidate=}',1,1)
                result = self._search_items(candidate, year, season, episode)
                # fflog(f'{result=}',1,1)
                if result:
                    if self.search_mode == 'first':
                        fflog(f'lista_m3u: ✓ Znaleziono URL', 1, 1)
                        return result
                    else:
                        # W trybie "all" result to lista URL
                        if isinstance(result, list):
                            for url in result:
                                if url and url not in all_found_urls:
                                    all_found_urls.append(url)
            
            if self.search_mode == 'all' and all_found_urls:
                # Zapisz wszystkie znalezione URL do zmiennej instancji
                self.all_found_urls = all_found_urls
                fflog(f'lista_m3u: Znaleziono {len(all_found_urls)} źródeł', 1, 1)
                
                # Zwróć pierwszy URL (reszta będzie w sources())
                return all_found_urls[0] if all_found_urls else None
            
            return None
            
        except Exception:
            fflog_exc(1)


    def movie(self, imdb, title, localtitle, aliases, year):
        return self.search(title, localtitle, aliases, year)


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return (tvshowtitle, localtvshowtitle), year, aliases


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        title = url[0][0]
        localtitle = url[0][1]
        year = url[1]
        aliases = url[2]
        aliases = None
        return self.search(title, localtitle, aliases, year, season, episode)


    def sources(self, url, hostDict, hostprDict):
        try:
            # fflog('sources',1,1)
            if not url:
                return []
            
            # W trybie "all" używamy wszystkich zapisanych URL
            if self.search_mode == 'all' and hasattr(self, 'all_found_urls') and self.all_found_urls:
                all_urls = self.all_found_urls
            else:
                # W trybie "first" lub jeśli nie ma zapisanych źródeł
                all_urls = [url] if url else []
            
            sources_list = []
            
            for movie_url in all_urls:
                # fflog(f'{movie_url=}',1,1)
                if isinstance(movie_url, tuple):
                    movie_url, title, group_title = movie_url
                else:
                    title = ''

                source_info = ""
                if self.search_mode == 'all' and 0:
                    for source_item in self.m3u_sources:
                        # fflog(f'{source_item=}',1,1)
                        if movie_url.startswith('http') and source_item['type'] == 'url':
                            if source_item['path'] in movie_url or movie_url in source_item['path']:
                                source_info = "M3U URL"
                                break
                        elif source_item['type'] == 'file':
                            if source_item['path'] and os.path.exists(source_item['path']):
                                source_info = "M3U FILE"
                
                host_match = re.search(r'https?://(?:www\.)?([^:/]+)', movie_url)
                host_name = host_match.group(1) if host_match else ''
                host_name = host_name.rsplit('.', 2)[-2] if '.' in host_name else host_name

                quality = '1080p'  # na sztywno
                unsure = ["quality"]
                if title:
                    # fflog(f'do sprawdzania jakości: {title + f" | {group_title}"}',1,1)
                    quality = source_utils.get_qual(title + f" | {group_title}")
                    # fflog(f'{quality=}  {title=}',1,1)
                    if not quality or quality == 'SD' and 'SD' not in title:
                        if 'FHD' in title:
                            quality = '1080p'
                        elif ' HD' in title:
                            quality = '720p'
                        else:
                            quality = '1080p'  # na sztywno
                        pass
                    else:
                        unsure = None
                    pass

                info = ''
                language = 'pl'
                if title and 0:  # nie zawsze jest pl w nazwie
                    language = source_utils.get_lang_by_type(title)
                    # fflog(f'{language=}  {title=}',1,1)
                    language, info = language
                    pass

                if 0:
                    if self.search_mode == 'all':
                        # info += f" | {host_name} ({source_info})"
                        info += f" | {host_name}"
                    else:
                        info += f" | {host_name}"
                if 1:
                    title += f' | {group_title}'
                    title += f' | {movie_url.rpartition("/")[-1]}'

                source_entry = {
                    # 'source': source_info,
                    'source': host_name,
                    'quality': quality,
                    'language': language,
                    'url': movie_url,
                    'info': info.strip(' |'),
                    'filename': title,
                    'direct': True,
                    'debridonly': False,
                }
                
                # Dodaj informację o źródle w nazwie (dla użytkownika)
                # przeniosłem to wyżej
                # if self.search_mode == 'all':
                    # source_entry['info'] = f"{host_name} ({source_info})"
 
                if unsure:
                    source_entry['unsure'] = unsure
                    pass
 
                sources_list.append(source_entry)
            
            # Wyczyść zapisane URL po użyciu
            if hasattr(self, 'all_found_urls'):
                self.all_found_urls = []
            # fflog('koniec sources',1,1)
            return sources_list
            
        except Exception:
            fflog_exc(1)
            return []


    def resolve(self, url):
        if 1:
            return url + "|User-Agent=vlc&verifypeer=false"
        return url
