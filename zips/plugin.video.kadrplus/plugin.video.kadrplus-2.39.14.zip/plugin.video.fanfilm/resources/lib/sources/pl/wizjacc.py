import json
import re
import urllib3
from html import unescape
from urllib.parse import quote_plus, urljoin, quote, urlencode

from ptw.libraries import source_utils, client, cleantitle
from ptw.debug import fflog_exc, fflog

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]

        # self.domains = ["wizja.cc"]
        self.base_link = "https://wizja.cc"
        self.search_link = "/search_elastic?s=%s"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }
        self.session = None


    def movie(self, imdb, title, localtitle, aliases, year):
        return self.do_search(title, localtitle, year, "movie", aliases)


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return self.do_search(tvshowtitle, localtvshowtitle, year, "show", aliases)


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # fflog(f'{url=}',1,1)
        if not url:
            # fflog(f'{url=}',1,1)
            return None

        if not self.session:
            import requests
            self.session = requests.Session()

        try:
            tvshow_id = url.split('/')[-1]
            # fflog(f'{tvshow_id=}',1,1)
            page_content = self.session.get(url, headers=self.headers, timeout=30).text
            # season_match = re.search(fr'<a href="#episodes" onclick="showEpisodes\((\d{{1,2}})\)" title="Sezon {season}">', page_content)
            season_match = re.search(fr'<option value="(\d{{1,2}})">Sezon {season}</option>', page_content)
            season_id = season_match[1] if season_match else ""
            if season_id:
                # fflog("Pobieranie odcinków",1,1)
                season_url = f'https://wizja.cc/shows/{tvshow_id}/seasons/{season_id}/episodes'
                # fflog(f"{season_url=}",1,1)
                page_content = self.session.get(season_url, headers=self.headers, timeout=30).json()
                # fflog(f'{page_content=}',1,1)
                episodes = page_content.get("episodes", [])
                if episodes:
                    try:
                        episode_d = episodes[int(episode)-1]
                    except Exception:
                        # fflog_exc(1)
                        fflog('nie ma takiego odcinka',1,1)
                        return
                    episode_id = episode_d.get("id")
                    episode_slug = episode_d.get("video_slug")
                    episode_url = url.replace('/details/', '/').replace(f'/{tvshow_id}', f'/{episode_slug}/{episode_id}',1)
                    # fflog(f'{episode_url=}',1,1)
                    return episode_url
                else:
                    fflog('brak odcinków dla tego sezonu',1,1)
                    return
            else:
                fflog('nie ma takiego sezonu',1,1)
                return
        except Exception:
            fflog_exc(1)
            pass


    def do_search(self, title, localtitle, year, content_type, aliases=None):  # kod tej metody wzięty z telewizjady
        # fflog(f'{title=}  {localtitle=}  {year=}  {aliases=}',1,1)
        try:
            # Priorytet: polskie tytuły jako główne, angielskie jako fallback
            titles_to_search = []

            # Dla polskiego tytułu spróbujmy różnych wariantów
            if localtitle and localtitle.strip():
                # Oryginalny polski tytuł
                titles_to_search.append(localtitle.strip())

                # Zamień kropkę na dwukropek (często różnica między bazami)
                with_colon = localtitle.replace('.', ':').strip()
                if with_colon != localtitle:
                    titles_to_search.append(with_colon)

                # Uproszczony (bez znaków specjalnych)
                simplified = localtitle.replace('.', '').replace(':', '').strip()
                if simplified not in [localtitle, with_colon]:
                    titles_to_search.append(simplified)

            if title and title.strip() and title != localtitle:
                titles_to_search.append(title.strip())

            # fflog(f'{titles_to_search=}',1,1)
            titles_to_search = titles_to_search[:4]  # ograniczenie
            # fflog(f'{titles_to_search=}',1,1)

            if not self.session:
                import requests
                self.session = requests.Session()

            # Przeszukaj każdy tytuł
            for idx, search_title in enumerate(titles_to_search):
                try:
                    fflog(f"[{idx+1}/{len(titles_to_search)}] Szukam: '{search_title}'",1,1)

                    # wyszukiwanie
                    search_url = self.base_link + self.search_link % quote_plus(search_title)
                    # fflog(f"URL wyszukiwania: {search_url}",1,1)

                    result = self.session.get(search_url, headers=self.headers, timeout=30)
                    if not result or result.status_code != 200:
                        fflog(f"Błąd HTTP: {result.status_code if result else 'None'}")
                        continue

                    result = result.text
                    # fflog(f'{result=}',1,1)

                    if not result:
                        fflog(f"[{idx+1}/{len(titles_to_search)}] Nie udało się pobrać wyników",1,1)
                        continue

                    search_results = []

                    watch_links = re.findall(r'href="([^"]*\/details\/[^"]*\d+)"', result)
                    fflog(f"Znaleziono {len(watch_links)} linków ",1,1)

                    for link in watch_links:
                        # fflog(f'{link=}',1,1)

                        if not f'/{content_type}s/' in link:
                            continue
                        # if content_type == "movie":
                            # if not '/movies/' in link:
                                # continue
                            # elif not '/shows/' in link:
                                # continue

                        if not link.startswith("http"):
                            full_url = urljoin(self.base_link, link)
                        else:
                            full_url = link

                        # Szukaj tytułu dla tego linku - może być w <a> lub w <h3><a>
                        title_patterns = [
                            rf'<a[^>]*href="{re.escape(link)}"[^>]*>([^<]+)</a>',
                            rf'href="{re.escape(link)}"[^>]*>([^<]+)</a>',
                        ]

                        found_title = ""
                        for pattern in title_patterns:
                            title_match = re.search(pattern, result)
                            if title_match:
                                found_title = unescape(title_match.group(1).strip())
                                # fflog(f'1) {found_title=}',1,1)
                                break

                        if not found_title:
                            # Fallback - wyciągnij z URL
                            found_title = link.split('/')[-2].replace('.html', '').replace('-', ' ').title()
                            # fflog(f'2) {found_title=}',1,1)

                        # Szukaj roku w pobliżu tego linku (w obrębie 1000 znaków)
                        found_year = None
                        if 0:  # nie ma roku w wwynikach wyszukiwania
                            link_pos = result.find(link)
                            if link_pos >= 0:
                                start_search = max(0, link_pos - 500)
                                end_search = min(len(result), link_pos + 500)
                                region = result[start_search:end_search]

                                # Szukaj span z label-year
                                year_match = re.search(r'<span[^>]*class="[^"]*label-year[^"]*"[^>]*>\s*(\d{4})\s*</span>', region)
                                if year_match:
                                    try:
                                        found_year = int(year_match.group(1))
                                    except:
                                        pass

                        # fflog(f"Znaleziony film: '{found_title}' ({found_year}) -> {full_url}",1,1)

                        if found_title:
                            search_results.append({
                                "url": full_url,
                                "title": found_title,
                                "year": found_year
                            })

                    fflog(f"[{idx+1}/{len(titles_to_search)}] Znaleziono {len(search_results)} wyników",1,1)

                    # Sprawdź każdy wynik
                    for result_idx, item in enumerate(search_results):
                        try:
                            found_url = item["url"]
                            found_title = item["title"]
                            found_year = item.get("year")

                            # fflog(f"[{idx+1}/{len(titles_to_search)}][{result_idx+1}] Sprawdzam: '{found_title}' (rok: {found_year})",1,1)

                            # Sprawdź dopasowanie roku
                            year_match = True
                            if year and found_year:
                                if content_type == "movie":
                                    # Dla filmów tolerancja 1 rok
                                    year_match = abs(int(year) - found_year) <= 1
                                else:
                                    # Dla seriali większa tolerancja
                                    year_match = found_year >= int(year) - 1 and found_year <= int(year) + 5

                                # fflog(f"[{idx+1}/{len(titles_to_search)}][{result_idx+1}] Porównanie roku: szukany {year} vs znaleziony {found_year} = {year_match}",1,1)

                                if not year_match:
                                    fflog(f"[{idx+1}/{len(titles_to_search)}][{result_idx+1}] Rok nie pasuje - pomijam",1,1)
                                    continue

                            # Sprawdź dopasowanie tytułu
                            search_clean = cleantitle.get_simple(search_title)
                            found_clean = cleantitle.get_simple(found_title)

                            if search_clean in found_clean or found_clean in search_clean:
                                # fflog(f'[{idx+1}/{len(titles_to_search)}] ZNALEZIONO DOPASOWANIE: {found_url} dla "{search_title}" -> "{found_title}" ({found_year})',1,1)
                                return found_url
                            else:
                                # fflog(f"[{idx+1}/{len(titles_to_search)}][{result_idx+1}] Tytuł nie pasuje: '{search_clean}' vs '{found_clean}'",1,1)
                                pass

                        except Exception:
                            # fflog(f'[{idx+1}/{len(titles_to_search)}][{result_idx+1}] Błąd przetwarzania wyniku',1,1)
                            fflog_exc(1)
                            continue

                    fflog(f"[{idx+1}/{len(titles_to_search)}] Brak dopasowań dla {search_title=}",1,1)

                except Exception:
                    # fflog(f'[{idx+1}/{len(titles_to_search)}] Błąd ogólny dla "{search_title}"',1,1)
                    fflog_exc(1)
                    continue

            fflog("Przeszukano wszystkie tytuły - nic nie znaleziono",1,1)
            return None

        except Exception:
            fflog_exc(1)
            return None


    def sources(self, url, hostDict, hostprDict):
        # fflog(f'{url=}',1,1)
        sources = []
        if not url:
            return sources

        if not self.session:
            import requests
            self.session = requests.Session()

        try:
            # fflog(f"Pobieranie źródeł z {url}",1,1)

            result = self.session.get(url, headers=self.headers, timeout=30)
            if result is None or result.status_code >= 400:
                fflog(f'{result=}',1,1)
                return sources

            text = result.text

            match = re.search(r'atob\(["\']([A-Za-z0-9+/=]+)["\']\)', text)

            if match:
                base64_string = match.group(1)
                # fflog(f"Znaleziony ciąg: {base64_string}",1,1)

                import base64
                result_url = base64.b64decode(base64_string).decode('utf-8')
                # fflog(f'{result_url=}',1,1)

                host = source_utils.top_domain(result_url)
                host = host.rpartition(".")[0]

                filename = result_url.split("/")
                if "/serial" in result_url:
                    filename = f'{filename[-3]} {filename[-2]}'
                else:
                    filename = filename[-2]
                    if result_url.endswith('m3u8'):
                        filename = filename.replace('.mp4', '', 1)
                
                source_item = {
                    # "source": '',  # 'vizja' (będzie można podpiąć pod wyjątki dla ISA)
                    "source": host,
                    "quality": "1080p",
                    "language": "pl",
                    "url": result_url,
                    "info": '',
                    "direct": True,
                    "debridonly": False,
                    "filename": filename,
                    # "info2": filename,
                }
                fflog(f'przekazano 1 źródło',1,1)
                return [source_item]  # 1 źródło

            else:
                fflog('nie znaleziono źródeł',1,1)
                return
        except Exception:
            fflog_exc()
            return sources


    def resolve(self, url):
        # fflog(f'{url=}',1,1)
        return url

