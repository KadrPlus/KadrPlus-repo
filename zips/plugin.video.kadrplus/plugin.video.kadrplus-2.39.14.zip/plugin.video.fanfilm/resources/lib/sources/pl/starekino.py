# -*- coding: UTF-8 -*-
"""
FanFilm - źródło: stare-kino.pl
Copyright (C) 2025 FF Team

Przeniesione z FanFilm Beta i dostosowane do architektury ptw.
Filmy przedwojenne (przed 1960) dostępne przez YouTube, Ninatekę i Filmotekę Narodową.
"""

import re
from urllib.parse import urlencode

import requests as _requests

from ptw.libraries.client import replaceHTMLCodes

from ptw.libraries.log_utils import fflog
from ptw.debug import fflog_exc


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.list_url = "https://stare-kino.pl/filmy-przedwojenne-online/"
        self.headers = {'User-Agent': 'Mozilla/5.0'}
        self.sess = _requests.Session()

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        # Filtr kraju: tylko filmy polskie (jak beta: 'PL' in getCountryCodes())
        country_codes = {(a.get('country') or '').upper() for a in (aliases or []) if a.get('country')}
        if country_codes and 'PL' not in country_codes:
            return None

        try:
            if int(year) >= 1960:
                return None
        except (TypeError, ValueError):
            return None
        return (localtitle or title, int(year))

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        return None

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        return None

    def sources(self, url, hostDict=None, hostprDict=None):
        sources = []
        if not url:
            return sources

        try:
            search_title, search_year = url[0], url[1]

            req = self.sess.get(self.list_url, headers=self.headers, timeout=30)
            if req.status_code != 200:
                return sources

            search_title = re.sub(r'[.,!?;:\']', '', search_title.lower().replace('\xa0', ' '))

            # Dwa wzorce HTML stosowane na stronie
            pattern1 = r'<a\s+href=["\']([^"\']+)["\'][^>]*>.*?<em>(.*?)</em>.*?</a>([^<]*)'
            pattern2 = r'<em><a\s+href=["\']([^"\']+)["\'][^>]*>(.*?)</a></em>([^<]*)'

            matches = re.findall(pattern1, req.text, re.DOTALL | re.IGNORECASE)
            matches += re.findall(pattern2, req.text, re.DOTALL | re.IGNORECASE)

            for link_url, movie_title, description in matches:
                if not link_url.startswith('http'):
                    continue

                movie_title = replaceHTMLCodes(movie_title.strip())
                if not movie_title:
                    continue

                title_norm = re.sub(r'[.,!?;:\']', '', movie_title.lower().replace('\xa0', ' '))

                if search_title not in title_norm and title_norm not in search_title:
                    continue

                # Rok z opisu "(1935)"
                year_match = re.search(r'\((\d{4})\)', description)
                if year_match:
                    film_year = int(year_match.group(1))
                    if abs(film_year - search_year) > 1:
                        continue

                # Info z opisu
                desc_lower = description.lower()
                info_parts = []
                if 'restauracja' in desc_lower: info_parts.append('restauracja')
                if 'fragment' in desc_lower: info_parts.append('fragment')
                if 'dubbing' in desc_lower or 'lektor' in desc_lower: info_parts.append('dubbing')
                if 'napisy' in desc_lower: info_parts.append('napisy')
                if 'wersja' in desc_lower: info_parts.append('wersja alt')
                info = ', '.join(info_parts)

                # Pomiń cyfrowa.tvp.pl (wymaga specjalnego resolvera)
                if 'cyfrowa.tvp.pl' in link_url:
                    continue

                # YouTube
                if 'youtu.be' in link_url or 'youtube.com' in link_url:
                    video_id = None
                    if 'youtu.be' in link_url:
                        m = re.search(r'youtu\.be/([a-zA-Z0-9_-]+)', link_url)
                        video_id = m.group(1) if m else None
                    else:
                        m = re.search(r'[?&]v=([a-zA-Z0-9_-]+)', link_url)
                        video_id = m.group(1) if m else None
                    if video_id:
                        video_id = video_id.split('?')[0].split('&')[0]
                        sources.append({
                            'source': 'youtube',
                            'quality': 'SD',
                            'language': 'pl',
                            'url': f'https://www.youtube.com/watch?v={video_id}',
                            'info': info,
                            'direct': False,
                            'debridonly': False,
                            'premium': False,
                        })

                # Ninateka
                elif 'ninateka.pl' in link_url:
                    sources.append({
                        'source': 'ninateka',
                        'quality': 'HD',
                        'language': 'pl',
                        'url': link_url,
                        'info': info,
                        'direct': False,
                        'debridonly': False,
                        'premium': False,
                    })

                # Inne (fn.org.pl, cda.pl itp.)
                else:
                    host_match = re.search(r'https?://(?:www\.)?([^/]+)', link_url)
                    host_name = host_match.group(1).split('.')[0] if host_match else 'unknown'
                    if 'repozytorium.fn.org.pl' in link_url:
                        host_name = 'Filmoteka Narodowa'

                    sources.append({
                        'source': host_name,
                        'quality': 'SD',
                        'language': 'pl',
                        'url': link_url,
                        'info': info,
                        'direct': False,
                        'debridonly': False,
                        'premium': False,
                    })

            fflog(f'[starekino] znaleziono źródeł: {len(sources)}')
            return sources

        except Exception:
            fflog_exc(1)
            return sources

    def resolve(self, url):
        # Resolve linków z repozytorium.fn.org.pl
        if 'repozytorium.fn.org.pl' in url:
            try:
                response = _requests.get(url, headers=self.headers, timeout=30)
                if response.status_code != 200:
                    return None
                match = re.search(r'file:\s*encodeURI\(["\']([^"\']+)["\']\)', response.text)
                if match:
                    file_url = match.group(1)
                    if not file_url.startswith('http'):
                        file_url = 'https://repozytorium.fn.org.pl/' + file_url.lstrip('/')
                    return file_url
                return None
            except Exception:
                fflog_exc(1)
                return None

        # Resolve linków z Ninateki
        if 'ninateka.pl' in url:
            try:
                slug = url.rstrip('/').split('/')[-1]
                api_url = 'https://ninateka.pl/api/products/vods/search/VOD'
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0',
                    'Referer': 'https://ninateka.pl',
                    'Accept': 'application/json, text/plain, */*'
                }
                params = {'lang': 'POL', 'platform': 'BROWSER', 'keyword': slug.replace('-', ' ')}

                response = _requests.get(api_url, headers=headers, params=params, timeout=15)
                if response.status_code != 200:
                    return None

                results = response.json().get('items', [])
                if not results:
                    return None

                item = results[0]
                eid = item['id']
                tenant = item['tenant']['uid']

                play_url = f'https://ninateka.pl/api/products/{eid}/videos/playlist'
                playlist_params = {'videoType': 'MOVIE', 'platform': 'BROWSER', 'tenant': tenant}

                playlist_response = _requests.get(play_url, headers=headers, params=playlist_params, timeout=15)
                if playlist_response.status_code != 200:
                    return None

                data = playlist_response.json()

                if 'sources' in data and 'DASH' in data['sources'] and data['sources']['DASH']:
                    stream_url = data['sources']['DASH'][0]['src']
                    if stream_url.startswith('//'):
                        stream_url = 'https:' + stream_url

                    adaptive_data = {
                        'protocol': 'mpd',
                        'mimetype': 'application/dash+xml',
                        'manifest': stream_url,
                        'licence_type': '',
                        'licence_url': '',
                        'licence_header': '',
                        'post_data': '',
                        'response_data': '',
                    }

                    if (drm := data.get('drm')) and (widevine := drm.get('WIDEVINE')):
                        adaptive_data['licence_type'] = 'com.widevine.alpha'
                        adaptive_data['licence_url'] = widevine['src']
                        adaptive_data['licence_header'] = urlencode({
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0',
                            'Referer': 'https://ninateka.pl',
                            'Content-Type': ''
                        })
                        adaptive_data['post_data'] = 'R{SSM}'

                    return f"DRMCDA|{repr(adaptive_data)}"

                return None
            except Exception:
                fflog_exc(1)
                return None

        return url
