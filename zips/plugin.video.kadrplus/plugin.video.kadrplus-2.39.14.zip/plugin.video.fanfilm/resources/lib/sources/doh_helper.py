# -*- coding: utf-8 -*-
"""
DoH (DNS-over-HTTPS) + TLS fingerprint helper dla scraperów FanFilm.

Łączy dwa mechanizmy obejścia Cloudflare:
1. DoH — podmienia resolucję DNS na cloudflare-dns.com (jak filmpalast.ex)
   Podmieniana jest tylko gniazdo TCP, URL/Host/SNI pozostają niezmienione.
2. TLS fingerprint — używa cipher suite Firefoxa zamiast domyślnego Pythona
   Cloudflare rozpoznaje Pythona po TLS fingerprint (ja3 hash) i blokuje.
   Cipher suite pochodzi z cfscrape/user_agent/browsers.json (Firefox).
   NIE używa verify=False — bezpieczne na Androidzie/Python 3.11+
"""

import ssl
import socket
import threading
import requests
import requests.adapters
import urllib3

urllib3.disable_warnings()

# Cipher suite Firefoxa (z cfscrape/user_agent/browsers.json)
_FIREFOX_CIPHERS = ':'.join([
    'TLS_AES_128_GCM_SHA256',
    'TLS_CHACHA20_POLY1305_SHA256',
    'TLS_AES_256_GCM_SHA384',
    'ECDHE-ECDSA-AES128-GCM-SHA256',
    'ECDHE-RSA-AES128-GCM-SHA256',
    'ECDHE-ECDSA-CHACHA20-POLY1305',
    'ECDHE-RSA-CHACHA20-POLY1305',
    'ECDHE-ECDSA-AES256-GCM-SHA384',
    'ECDHE-RSA-AES256-GCM-SHA384',
    'ECDHE-ECDSA-AES256-SHA',
    'ECDHE-ECDSA-AES128-SHA',
    'ECDHE-RSA-AES128-SHA',
    'ECDHE-RSA-AES256-SHA',
    'DHE-RSA-AES128-SHA',
    'DHE-RSA-AES256-SHA',
    'AES128-SHA',
    'AES256-SHA',
    'DES-CBC3-SHA',
])

_doh_cache = {}
_lock = threading.Lock()


def doh_resolve(host):
    """Pobierz IP dla hosta przez DNS-over-HTTPS (Cloudflare)."""
    parts = host.split('.')
    domain = '.'.join(parts[-2:]) if len(parts) >= 2 else host

    with _lock:
        if domain in _doh_cache:
            return _doh_cache[domain]

    try:
        r = requests.get(
            'https://cloudflare-dns.com/dns-query',
            params={'name': domain, 'type': 'A'},
            headers={'accept': 'application/dns-json'},
            timeout=8, verify=False
        )
        if r.status_code == 200:
            data = r.text
            idx = data.find('"data":"')
            if idx >= 0:
                ip = data[idx + 8: data.find('"}', idx)]
                if ip and ip.replace('.', '').isdigit():
                    with _lock:
                        _doh_cache[domain] = ip
                    return ip
    except Exception:
        pass
    return None


def _make_firefox_ssl_context():
    """Utwórz SSLContext z cipher suite Firefoxa, bez weryfikacji certyfikatu."""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        ctx.set_ciphers(_FIREFOX_CIPHERS)
        return ctx
    except Exception:
        return None


class _FirefoxHTTPSAdapter(requests.adapters.HTTPAdapter):
    """
    HTTPAdapter który:
    1. Używa cipher suite Firefoxa (TLS fingerprint)
    2. Podmienia resolucję DNS na DoH (socket.getaddrinfo monkeypatch)

    URL, nagłówki Host i SNI pozostają niezmienione.
    NIE ustawia verify=False globalnie.
    """

    def __init__(self, ssl_context=None, *args, **kwargs):
        self._ssl_context = ssl_context or _make_firefox_ssl_context()
        super().__init__(*args, **kwargs)

    def init_poolmanager(self, *args, **kwargs):
        if self._ssl_context:
            kwargs['ssl_context'] = self._ssl_context
        super().init_poolmanager(*args, **kwargs)

    def proxy_manager_for(self, proxy, **kwargs):
        if self._ssl_context:
            kwargs['ssl_context'] = self._ssl_context
        return super().proxy_manager_for(proxy, **kwargs)

    def send(self, request, **kwargs):
        from urllib.parse import urlsplit
        host = urlsplit(request.url).hostname
        ip = doh_resolve(host) if host else None

        if not ip:
            return super().send(request, **kwargs)

        # Monkeypatch socket.getaddrinfo tylko na czas tego połączenia
        _orig = socket.getaddrinfo

        def _patched(h, port, *args, **kw):
            if h == host:
                return _orig(ip, port, *args, **kw)
            return _orig(h, port, *args, **kw)

        socket.getaddrinfo = _patched
        try:
            return super().send(request, **kwargs)
        finally:
            socket.getaddrinfo = _orig


def make_doh_session():
    """Zwróć requests.Session z DoH + TLS fingerprint Firefoxa."""
    session = requests.Session()
    adapter = _FirefoxHTTPSAdapter()
    session.mount('https://', adapter)
    # http nie wymaga TLS ale też dodajemy DoH przez osobny adapter
    class _HttpDoHAdapter(requests.adapters.HTTPAdapter):
        def send(self, request, **kwargs):
            from urllib.parse import urlsplit
            host = urlsplit(request.url).hostname
            ip = doh_resolve(host) if host else None
            if not ip:
                return super().send(request, **kwargs)
            _orig = socket.getaddrinfo
            def _patched(h, port, *args, **kw):
                if h == host:
                    return _orig(ip, port, *args, **kw)
                return _orig(h, port, *args, **kw)
            socket.getaddrinfo = _patched
            try:
                return super().send(request, **kwargs)
            finally:
                socket.getaddrinfo = _orig
    session.mount('http://', _HttpDoHAdapter())
    # NIE ustawiamy session.verify=False — verify jest obsługiwane przez ssl_context
    return session
