# Kadr+ compatibility constants for newer FanFilm scrapers.

class _Obj(dict):
    def __getattr__(self, name):
        if name not in self:
            self[name] = _Obj()
        return self[name]
    def __setattr__(self, name, value):
        self[name] = value

const = _Obj()

# CDA defaults used by newer FanFilm cda scraper.
const.sources.cda.debug = False
const.sources.cda.duration_epsilon = 0.20
const.sources.cda.episode_duration_epsilon = 0.35
const.sources.cda.min_size_mb = 20
const.sources.cda.show_premium_free = 'FREE'
const.sources.franchise_names = []
const.sources.franchise_names_sep = ' / '
const.sources_dialog.cda_drm = True

# Kadr+ 2.40.68 defaults for FanFilm-style Polish sources
const.sources.ekinotv.domain = 'https://ekino.ws'
const.sources.wrzucaj.debug = False
const.dev.sources.force_all_sources = False
