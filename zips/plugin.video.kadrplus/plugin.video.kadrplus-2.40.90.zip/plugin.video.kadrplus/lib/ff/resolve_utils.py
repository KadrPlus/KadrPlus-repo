from urllib.parse import urlencode
try:
    from lib.ff.source_utils import DEFAULT_UA
except Exception:
    DEFAULT_UA = 'Mozilla/5.0'

def build_isa_url(url, referer, origin=None, ua=DEFAULT_UA, cookie=None):
    parts=[]
    if referer: parts.append('Referer=%s' % referer)
    if origin: parts.append('Origin=%s' % origin)
    if ua: parts.append('User-Agent=%s' % ua)
    if cookie: parts.append('Cookie=%s' % cookie)
    return 'isa+%s|%s' % (url, '&'.join(parts)) if parts else 'isa+' + url

def build_drmff(manifest, widevine_url=None, lic_referer=None, ua=DEFAULT_UA):
    data={'protocol':'mpd','mimetype':'application/dash+xml','manifest':manifest,'licence_type':'','licence_url':'','licence_header':'','post_data':'','response_data':''}
    if widevine_url:
        data.update({'licence_type':'com.widevine.alpha','licence_url':widevine_url,'licence_header':urlencode({'User-Agent':ua,'Referer':lic_referer or '', 'Content-Type':''}),'post_data':'R{SSM}'})
    return 'DRMFF|%r' % data
