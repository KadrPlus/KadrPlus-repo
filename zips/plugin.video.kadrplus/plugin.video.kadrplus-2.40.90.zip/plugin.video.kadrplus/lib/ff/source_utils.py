# Kadr+ compatibility layer for FanFilm source_utils.
try:
    from ptw.libraries.source_utils import *  # noqa
except Exception:
    pass

try:
    DEFAULT_UA
except NameError:
    DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"

try:
    CHROME_UA
except NameError:
    CHROME_UA = DEFAULT_UA

try:
    FIREFOX_UA
except NameError:
    FIREFOX_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0"

class ShowData(dict):
    def __init__(self, *args, **kwargs):
        # FanFilm sometimes calls ShowData(title, localtitle, aliases, year).
        # dict.__init__ cannot accept that, so map positional values explicitly.
        super().__init__()
        keys = ["title", "localtitle", "aliases", "year", "imdb", "tmdb", "tvdb", "season", "episode"]
        if len(args) == 1 and isinstance(args[0], dict):
            self.update(args[0])
        elif args:
            for key, value in zip(keys, args):
                self[key] = value
        self.update(kwargs)
        # FanFilm scrapers use both localtitle and local_title naming styles.
        if "localtitle" in self and "local_title" not in self:
            self["local_title"] = self.get("localtitle")
        if "local_title" in self and "localtitle" not in self:
            self["localtitle"] = self.get("local_title")
        if "originaltitle" in self and "original_title" not in self:
            self["original_title"] = self.get("originaltitle")
        if "original_title" in self and "originaltitle" not in self:
            self["originaltitle"] = self.get("original_title")
        self.__dict__ = self

ShowDataDict = dict

def show_data_asdict(data):
    if data is None:
        return {}
    if isinstance(data, dict):
        return dict(data)
    try:
        return dict(data.__dict__)
    except Exception:
        return {}


# --- Kadr+ 2.40.64 FanFilm 2026 PL scraper compatibility helpers ---
# These wrappers fill the small API surface used by newer FanFilm PL scrapers.
try:
    import re as _ff_re
    import unicodedata as _ff_unicodedata
except Exception:
    pass

def detect_script(s, mode=0):
    try:
        from unicodedata import category
        def _detect_char_script(c):
            v = ord(c or ' ')
            if not (c and category(c)[0] == 'L'):
                return ''
            if 0x20 <= v < 0x370:
                return False
            if 0x370 <= v <= 0x3ff:
                return 'gr'
            if 0x400 <= v <= 0x52f:
                return 'rus'
            return True
        s = str(s or '').strip()
        if not s:
            return None
        if mode == 2:
            r = [_detect_char_script(s[i]) for i in [0, -1] if s]
        else:
            r = [_detect_char_script(ch) for ch in s if category(ch)[0] == 'L']
        if r.count('gr'):
            return 'gr'
        if r.count('rus'):
            return 'rus'
        return any(r)
    except Exception:
        return False

def _ff_get_original_title(aliases):
    try:
        for a in aliases or []:
            name = a.get('originalname') or a.get('original_title') or ''
            if name and not detect_script(name):
                return name
    except Exception:
        pass
    return ''

def search_queries(title, local_title):
    seen = set()
    for q in (local_title, title):
        q = str(q or '').strip()
        key = q.lower()
        if q and key not in seen:
            seen.add(key)
            yield q

def search_queries_extended(title, local_title):
    seen = set()
    variants = []
    for q in (local_title, title):
        if q:
            variants += [str(q), str(q).replace(':', ' '), str(q).replace('-', ' ')]
    for q in variants:
        q = _ff_re.sub(r'\s+', ' ', q).strip()
        key = q.lower()
        if q and key not in seen:
            seen.add(key); yield q

def format_episode_key(season, episode, with_wildcard=False):
    try:
        s = int(season); e = int(episode)
        return f's{s:02d}e{e:02d}' if not with_wildcard else f's{s:02d}e{e:02d}*'
    except Exception:
        return f's{season}e{episode}'

def build_alias_list(title, local_title, aliases, year=None):
    vals=[]
    def add(v):
        v=str(v or '').strip()
        if year:
            v=v.replace(str(year),'').strip(' -()[]')
        if v and not detect_script(v) and v.lower() not in [x.lower() for x in vals]:
            vals.append(v)
    add(title); add(local_title); add(_ff_get_original_title(aliases))
    try:
        for a in aliases or []:
            add(a.get('title') or a.get('name') or a.get('originalname'))
    except Exception:
        pass
    return vals

def prepare_alias_search_list(aliases, year=''):
    return build_alias_list('', '', aliases, year)

def year_matches(text, expected_year, tolerance=1):
    try:
        years = [int(y) for y in _ff_re.findall(r'\b(?:19|20)\d{2}\b', str(text or ''))]
        if not years:
            return True
        return any(abs(y - int(expected_year)) <= int(tolerance) for y in years)
    except Exception:
        return True

def extract_cookie(cookie, cookie_name):
    try:
        import json as _json
        cookie_re = _ff_re.escape(cookie_name)
        if _ff_re.search(r'"name"\s*:\s*"%s"' % cookie_re, cookie):
            try:
                for c in _json.loads(cookie):
                    if c.get('name') == cookie_name:
                        return c.get('value','')
            except Exception:
                return ''
        return _ff_re.sub(rf'^.*\b{cookie_re}=([^;]*)(?:;.*|$)', r'\1', str(cookie or '')).strip(' "\'')
    except Exception:
        return ''

def setting_cookie(setting_name, cookie_name):
    try:
        from lib.ff.settings import settings
        return extract_cookie(settings.getString(setting_name), cookie_name)
    except Exception:
        return ''

def sources_with_links(sources):
    out=[]
    for s in sources or []:
        try:
            url = getattr(s, 'url', None) or s.get('url','')
            if s.get('local') or '://' in url or str(url).startswith('DRMFF'):
                out.append(s)
        except Exception:
            pass
    return out

# FanFilm scrapers call is_anime(ffitem); older Kadr ptw helper has a different signature.
def is_anime(ffitem, *args, **kwargs):
    try:
        from const import const
        show_item = getattr(ffitem, 'show_item', None)
        kw = getattr(show_item or ffitem, 'keywords', None) or {}
        return bool(getattr(const.sources, 'check_anime', 'anime') in kw or 'anime' in kw)
    except Exception:
        return False

# Kadr+ 2.40.65 compatibility: FanFilm cdahd calls source_utils.get_original_title.
def get_original_title(aliases):
    try:
        return _ff_get_original_title(aliases)
    except Exception:
        return ''

# --- Kadr+ 2.40.68 FanFilm PL deep-port compatibility ---
try:
    DEFAULT_UA
except NameError:
    DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140 Safari/537.36"
try:
    FF_UA
except NameError:
    FF_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0"
try:
    FRANCHISE_CC
except NameError:
    FRANCHISE_CC = frozenset({'uk','au','us','pl','de','fr','nl','se','dk','fi','cz','hu','ro','tr','ru','jp','kr','cn','pt','ch','za','nz','ca','es'})

try:
    import re as _ff_re
    from urllib.parse import urlparse as _ff_urlparse
except Exception:
    pass

def quality_from_resolution(width=0, height=0):
    try:
        width=int(width or 0); height=int(height or 0)
        if width >= 3840 or height >= 2160: return '4K'
        if width >= 1920 or height >= 1080: return '1080p'
        if width >= 1280 or height >= 720: return '720p'
    except Exception: pass
    return 'SD'

def parse_label_language(label, filename='', has_subs=False):
    txt=(str(label or '')+' '+str(filename or '')).lower()
    if any(x in txt for x in ['dubbing','pldub']): return 'pl','Dubbing'
    if any(x in txt for x in ['napisy','subbed','plsub']): return 'pl','Napisy'
    if any(x in txt for x in ['lektor','lector']): return 'pl','Lektor'
    if 'eng' in txt and 'pl' not in txt: return 'en',''
    return 'pl','Lektor'

def parse_source_quality_lang(filename):
    try: q=check_sd_url(filename)
    except Exception: q='SD'
    lang, info = parse_label_language('', filename)
    return q, lang, info

_RE_EP_FILENAME = _ff_re.compile(r'((S[\dO]{1,2})?[.,-]?E[\dO]{2,4}|\bcz\.|\bodc\.|\bep\.|episode|odcinek|\b\d+x\d{2}\b)', _ff_re.I)
def is_episode_filename(filename):
    return bool(_RE_EP_FILENAME.search(str(filename or '')))

def parse_filename_title(filename):
    s=str(filename or '')
    s=_ff_re.sub(r'\.(mkv|mp4|avi|webm|mov)$','',s,flags=_ff_re.I)
    norm=s.replace('.', ' ').replace('_',' ')
    y=_ff_re.search(r'\b((?:19|20)\d{2})\b', norm)
    ep=_ff_re.search(r'[Ss](\d{1,2})\s*[Ee](\d{1,4})|\b(\d{1,2})x(\d{2,4})\b|\b[Ee][Pp]?\s*(\d{1,4})\b', norm)
    cut=len(norm)
    if y: cut=min(cut,y.start())
    if ep: cut=min(cut,ep.start())
    title=norm[:cut].strip(' -()[]') or norm.strip()
    season=episode=None
    if ep:
        if ep.group(1): season=int(ep.group(1)); episode=int(ep.group(2))
        elif ep.group(3): season=int(ep.group(3)); episode=int(ep.group(4))
        else: season=1; episode=int(ep.group(5))
    return {'title': title, 'year': int(y.group(1)) if y else None, 'season': season, 'episode': episode}

def build_alias_cleans(titles):
    vals=set()
    try:
        for t in filter(None, titles):
            for part in [t]+_ff_re.split(r'\s+-\s+|:\s+', str(t)):
                c=cleantitle.get_simple(part)
                if c and len(c)>=2: vals.add(c)
    except Exception: pass
    return vals

def match_parsed_title(title, alias_cleans):
    try:
        parsed=parse_filename_title(title).get('title') or title
        c=cleantitle.get_simple(parsed)
        if c in alias_cleans: return True
        return any(c and (c in a or a in c) for a in alias_cleans if len(a)>=3)
    except Exception: return False

def extract_alias_country_codes(aliases, base_title=''):
    out=set()
    try:
        for a in aliases or []:
            country=(a.get('country') or '').lower()
            if country in FRANCHISE_CC: out.add(country)
    except Exception: pass
    return out

def check_parsed_title_cc(parsed_title, search_title, expected_cc):
    # return None when OK; string when rejected (FanFilm convention)
    try:
        if not expected_cc: return None
        low=str(parsed_title or '').lower()
        found={cc for cc in expected_cc if _ff_re.search(r'\b%s\b' % _ff_re.escape(cc), low)}
        return None if not found or found & set(expected_cc) else 'country variant conflict'
    except Exception: return None

def confirm_transfer_dialog(*args, **kwargs):
    return True


# --- Kadr+ 2.40.69 additional FanFilm PL compatibility ---
def _levenshtein(a, b):
    a=str(a or ''); b=str(b or '')
    if a==b: return 0
    if not a: return len(b)
    if not b: return len(a)
    prev=list(range(len(b)+1))
    for i, ca in enumerate(a, 1):
        cur=[i]
        for j, cb in enumerate(b, 1):
            cur.append(min(cur[-1]+1, prev[j]+1, prev[j-1]+(ca!=cb)))
        prev=cur
    return prev[-1]

def get_quality_from_filename(name):
    try:
        return check_sd_url(str(name or ''))
    except Exception:
        s=str(name or '').lower()
        if '2160' in s or '4k' in s: return '4K'
        if '1080' in s: return '1080p'
        if '720' in s: return '720p'
        return 'SD'

def is_asian_content(item):
    try:
        kw=getattr(item,'keywords',None) or getattr(getattr(item,'show_item',None),'keywords',None) or {}
        txt=' '.join([str(x).lower() for x in (kw.keys() if hasattr(kw,'keys') else kw)])
        if any(x in txt for x in ['korean','japanese','china','chinese','asian','k-drama','j-drama','drama']): return True
        cc=[]
        try: cc=item.vtag.getCountryCodes()
        except Exception: pass
        return any(str(x).upper() in ('JP','KR','CN','TH','TW','HK') for x in cc)
    except Exception: return False

def confirm_transfer_dialog(filename, charge='', remaining=''):
    return True

def extract_alias_country_codes(aliases, title=''):
    out=[]
    try:
        for a in aliases or []:
            c=a.get('country') or a.get('iso_3166_1') or ''
            if c and c not in out: out.append(str(c).lower())
    except Exception: pass
    return out

def build_alias_cleans(values):
    out=set()
    try:
        import re, unicodedata
        for v in values or []:
            s=unicodedata.normalize('NFKD', str(v or '')).encode('ascii','ignore').decode('ascii').lower()
            s=re.sub(r'[^a-z0-9]+',' ',s).strip()
            if s: out.add(s)
    except Exception: pass
    return out

def match_parsed_title(parsed_title, alias_cleans):
    try:
        p=next(iter(build_alias_cleans([parsed_title])), '')
        return not alias_cleans or p in alias_cleans or any(p == a or p in a or a in p for a in alias_cleans)
    except Exception: return True

def check_parsed_title_cc(parsed_title, item_title, expected_cc):
    return False

# --- Kadr+ 2.40.80: CDA/eKino FanFilm parity helpers ---
# The CDA/eKino FanFilm scrapers expect build_relevant_franchises() to return
# dict[str, list[str]]. Kadr+'s older ptw helper returned a list, which caused
# AttributeError: 'list' object has no attribute 'values' and aborted CDA search.
try:
    import re as _k80_re
except Exception:
    _k80_re = None

try:
    _CC_NONALNUM_RE
except NameError:
    _CC_NONALNUM_RE = _k80_re.compile(r'[^a-z0-9 ]') if _k80_re else None
try:
    _EP_MARKER_RE
except NameError:
    _EP_MARKER_RE = _k80_re.compile(r'^s\d{1,2}e\d{2,4}$') if _k80_re else None

def build_relevant_franchises(titles, franchise_names=None, franchise_names_sep=None):
    """FanFilm-compatible conservative franchise pattern builder.
    Returns dict[str, list[str]], never list.
    """
    try:
        titles_l = [str(t or '').lower() for t in (titles or []) if str(t or '').strip()]
        names = franchise_names or {}
        sep = franchise_names_sep or r'\W+'
        if isinstance(sep, (list, tuple, set)):
            sep = r'\W+'
        out = {}
        if isinstance(names, dict):
            iterable = names.items()
        else:
            iterable = [(str(n), [str(n)]) for n in (names or [])]
        for key, vals in iterable:
            if not key:
                continue
            vals = vals if isinstance(vals, (list, tuple, set)) else [vals]
            key_l = str(key).lower()
            val_l = [str(v or '').lower() for v in vals if str(v or '').strip()]
            if not any(key_l in t or any(v in t for v in val_l) for t in titles_l):
                continue
            pats = []
            for v in vals:
                words = str(v or '').split()
                if not words:
                    continue
                try:
                    pats.append(str(sep).join(map(_k80_re.escape, words)) if _k80_re else ' '.join(words))
                except Exception:
                    pats.append(str(v))
            if pats:
                out[str(key)] = pats
        return out
    except Exception:
        return {}

def detect_country_variant_conflict(filename_words_lower, titles):
    """FanFilm-compatible country/remake guard used by CDA/eKino.
    Returns conflicting cc string or None.
    """
    try:
        if not filename_words_lower:
            return None
        if isinstance(filename_words_lower, str):
            words = (_CC_NONALNUM_RE.sub(' ', filename_words_lower.lower()).split()
                     if _CC_NONALNUM_RE else filename_words_lower.lower().split())
        else:
            words = [str(w or '').lower() for w in filename_words_lower]
        ep_idx = next((i for i, w in enumerate(words) if _EP_MARKER_RE and _EP_MARKER_RE.match(w)), None)
        if ep_idx is None or ep_idx == 0:
            return None
        cc_in_pre_ep = {w for w in words[:ep_idx] if w in FRANCHISE_CC}
        if not cc_in_pre_ep:
            return None
        expected = set()
        for title in titles or []:
            tw = (_CC_NONALNUM_RE.sub(' ', str(title or '').lower()).split()
                  if _CC_NONALNUM_RE else str(title or '').lower().split())
            if len(tw) >= 2 and tw[-1] in FRANCHISE_CC:
                expected.add(tw[-1])
        if not expected:
            return None
        conflicts = cc_in_pre_ep - expected
        return next(iter(conflicts)) if conflicts else None
    except Exception:
        return None

def check_parsed_title_cc(parsed_title, search_title, expected_cc):
    try:
        if not expected_cc:
            return None
        parsed_words = set((_CC_NONALNUM_RE.sub(' ', str(parsed_title or '').lower()).split()
                            if _CC_NONALNUM_RE else str(parsed_title or '').lower().split()))
        search_words = set((_CC_NONALNUM_RE.sub(' ', str(search_title or '').lower()).split()
                            if _CC_NONALNUM_RE else str(search_title or '').lower().split()))
        for word in parsed_words - search_words:
            if word in FRANCHISE_CC and word not in set(expected_cc):
                return word
        return None
    except Exception:
        return None
