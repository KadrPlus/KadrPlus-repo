# -*- coding: utf-8 -*-
"""
Kadr+ port of FanFilm 2026 obejrzyj_filmy.py family.
Providers: obejrzyj.to, filmyonline.cc, premiumsmart.eu

This module exposes legacy Kadr+ source API while using the newer FanFilm
API-based search/episode logic:
- /api/v1/search/<query>?loader=searchPage
- /api/v1/titles/<base64 service|type|id>?loader=titlePage
- /api/v1/titles/<media_id>/seasons/<s>/episodes/<e>?loader=episodePage
"""
from __future__ import annotations

import json
import re
from base64 import b64encode
from json import JSONDecodeError
from urllib.parse import quote, urlparse, unquote

try:
    from lib.ff import requests
except Exception:
    import requests

from ptw.libraries import source_utils, cleantitle, control
from ptw.debug import fflog, fflog_exc


class ObejrzyjFilmyBase(object):
    priority = 1
    language = ['pl']
    PROVIDER = 'obejrzyjto'
    URL = 'https://obejrzyj.to/'
    HAS_TMDB_SUPPORT = True

    INFO_HIT = {
        'lektor': 'lektor',
        'napisy': 'napisy',
        'dubbing': 'dubbing',
    }

    def __init__(self):
        self._session = None
        self._csrf_token = None

    @property
    def session(self):
        if self._session is None:
            self._session = requests.Session()
            try:
                self._session.headers.update({
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0',
                    'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
                    'Accept': 'application/json, text/plain, */*',
                    'Referer': self.URL,
                })
            except Exception:
                pass
            self._init_session()
        return self._session

    def _init_session(self):
        try:
            self._session.get(self.URL, timeout=(8, 15))
        except Exception:
            pass

    def request(self, url, _retried=False):
        try:
            resp = self.session.get(url, headers={'accept': 'application/json', 'referer': self.URL}, timeout=(10, 20))
            fflog(f'[{self.PROVIDER.upper()}] request: {url} -> {getattr(resp, "status_code", None)}', 0)
            if resp.status_code == 200:
                return resp.json()
            return {}
        except JSONDecodeError:
            fflog(f'[{self.PROVIDER.upper()}] JSON error for {url!r}')
            return {}
        except Exception:
            fflog_exc(1)
            return {}

    def make_id(self, tid, type=None, service=None):
        if tid and type and service:
            return b64encode(f'{service}|{type}|{tid}'.encode()).decode('ascii')
        return str(tid or '')

    def _aliases(self, aliases):
        vals=[]
        def add(v):
            v=str(v or '').strip()
            if v and v.lower() not in [x.lower() for x in vals] and not source_utils.czy_litery_krzaczki(v):
                vals.append(v)
        try:
            for a in aliases or []:
                if isinstance(a, dict):
                    add(a.get('title') or a.get('name') or a.get('originalname') or a.get('original_title'))
                else:
                    add(a)
        except Exception:
            pass
        return vals

    def _query(self, title):
        title = re.sub(r'(?:^|(?<=\s))(?:I{1,3}[VX]?|[VX]I{0,3}|\d+)(?:(?=\s|$))', '', str(title or ''))
        title = re.sub(r'\b\w\b', '', title)
        title = re.sub(r'\s+', ' ', title).strip()
        if '/' in title:
            title = max(title.split('/'), key=lambda t: len(t.strip()))
        return title.strip()

    def _search(self, query, tmdb=None, imdb=None):
        query = str(query or '').strip()
        if not query:
            return []
        fflog(f'[{self.PROVIDER.upper()}] query: {query!r}', 0)
        try:
            data = self.request(f"{self.URL}api/v1/search/{quote(query, safe='')}?loader=searchPage")
            raw = data.get('results') or []
        except Exception:
            fflog_exc(1)
            return []
        fflog(f'[{self.PROVIDER.upper()}] search: {len(raw)} results', 0)
        try:
            tmdb_int = int(tmdb) if tmdb else None
        except Exception:
            tmdb_int = None
        imdb = str(imdb or '').strip() or None
        if tmdb_int or imdb:
            filtered=[]
            for item in raw:
                if tmdb_int and item.get('tmdb_id') == tmdb_int:
                    filtered.append(item); continue
                if imdb and item.get('imdb_id') == imdb:
                    filtered.append(item); continue
            return filtered
        return raw

    def _title_candidates(self, title, localtitle, aliases):
        out=[]
        def add(v):
            v=str(v or '').strip()
            if v and v.lower() not in [x.lower() for x in out]:
                out.append(v)
        add(localtitle); add(title)
        for a in self._aliases(aliases): add(a)
        return out

    def _obtain_media(self, mtype, title, localtitle, aliases, year, imdb='', tmdb=''):
        # New FanFilm path: ID lookup first.
        if self.HAS_TMDB_SUPPORT:
            for service, mid in [('tmdb', tmdb), ('imdb', imdb)]:
                if not mid:
                    continue
                media_id = self.make_id(mid, type=mtype, service=service)
                try:
                    data = self.request(f'{self.URL}api/v1/titles/{media_id}?loader=titlePage')
                    if data.get('title'):
                        return data['title']
                except Exception:
                    fflog_exc(1)
        # Fallback: search. For movies with TMDB support use FanFilm cleaned query;
        # for series or sites without IDs keep full title to preserve sequel/season words.
        candidates = self._title_candidates(title, localtitle, aliases)
        for q in candidates:
            search_q = q if (mtype == 'series' or not self.HAS_TMDB_SUPPORT) else self._query(q)
            found = self._search(search_q, tmdb=tmdb if self.HAS_TMDB_SUPPORT else None, imdb=imdb if self.HAS_TMDB_SUPPORT else None)
            if not found and not self.HAS_TMDB_SUPPORT:
                found = self._search(search_q)
            for media in found:
                try:
                    if self.HAS_TMDB_SUPPORT:
                        if tmdb and media.get('tmdb_id') and str(media.get('tmdb_id')) != str(tmdb):
                            continue
                        if imdb and media.get('imdb_id') and str(media.get('imdb_id')) != str(imdb):
                            continue
                    else:
                        # exact-ish match and year/type filter for filmyonline.
                        names = [media.get('name') or '', media.get('original_title') or '']
                        if not any(cleantitle.get(n) == cleantitle.get(x) for n in names for x in candidates):
                            continue
                        if year and media.get('year') and str(media.get('year')) != str(year):
                            continue
                    media_id = media.get('id')
                    data = self.request(f'{self.URL}api/v1/titles/{media_id}?loader=titlePage')
                    if data.get('title'):
                        return data['title']
                except Exception:
                    fflog_exc(1)
        return {}

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        tmdb = kwargs.get('tmdb') or kwargs.get('tmdb_id') or ''
        data = self._obtain_media('movie', title, localtitle, aliases, year, imdb=imdb, tmdb=tmdb)
        if not data:
            fflog(f'[{self.PROVIDER.upper()}] movie not found: {title!r}')
            return None
        payload = {'type':'movie', 'id': data.get('id'), 'titles': [v for k in ('name','original_title') if (v:=data.get(k))]}
        return json.dumps(payload)

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        tmdb = kwargs.get('tmdb') or kwargs.get('tmdb_id') or ''
        data = self._obtain_media('series', tvshowtitle, localtvshowtitle, aliases, year, imdb=imdb, tmdb=tmdb)
        if not data:
            fflog(f'[{self.PROVIDER.upper()}] show not found: {tvshowtitle!r}')
            return None
        payload = {'type':'series', 'id': data.get('id'), 'titles': [v for k in ('name','original_title') if (v:=data.get(k))]}
        return json.dumps(payload)

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        if not url:
            return None
        try:
            payload = json.loads(url) if isinstance(url, str) and url.startswith('{') else {'type':'series','id':url}
        except Exception:
            payload = {'type':'series','id':url}
        payload.update({'type':'episode','season':str(season), 'episode':str(episode), 'episode_title': title or ''})
        return json.dumps(payload)

    def _load_payload(self, url):
        try:
            if isinstance(url, str) and url.startswith('{'):
                return json.loads(url)
        except Exception:
            pass
        return {'type':'movie','id':url}

    def sources(self, url, hostDict, hostprDict, from_cache=False):
        result=[]
        if not url:
            return result
        payload = self._load_payload(url)
        media_id = payload.get('id')
        if not media_id:
            return result
        videos=[]
        try:
            if payload.get('type') == 'episode':
                s,e = payload.get('season'), payload.get('episode')
                data = self.request(f'{self.URL}api/v1/titles/{media_id}/seasons/{s}/episodes/{e}?loader=episodePage')
                ep = data.get('episode') or {}
                videos = [v for v in ep.get('videos', []) if v.get('category') == 'full']
            else:
                data = self.request(f'{self.URL}api/v1/titles/{media_id}?loader=titlePage')
                title = data.get('title') or {}
                videos = [v for v in title.get('videos', []) if v.get('category') == 'full']
        except Exception:
            fflog_exc(1)
            videos=[]
        for item in videos:
            try:
                src = item.get('src') or ''
                if not src:
                    continue
                name = item.get('name') or self.source_name(item) or '?'
                lower_name = f"{name} {item.get('language_type','')}".lower()
                quality = item.get('quality') or 'HD'
                lang = self.video_language(item)
                info = self.info_from_item(item, lower_name)
                result.append({
                    'source': self.source_name(item) or name.split(None,1)[0] or '?',
                    'quality': quality.lower() if str(quality)[:3].isdigit() else str(quality).upper(),
                    'language': lang,
                    'url': src,
                    'info': info,
                    'direct': False,
                    'debridonly': False,
                    'filename': '',
                    'premium': False,
                })
            except Exception:
                fflog_exc(1)
        fflog(f'[{self.PROVIDER.upper()}] sources: {len(result)}')
        return result

    def resolve(self, url, **kwargs):
        return url

    def source_name(self, item):
        try:
            return urlparse(item.get('src') or '').hostname or ''
        except Exception:
            return ''

    def video_language(self, item):
        lang = (item.get('language') or '').lower()
        lang_type = (item.get('language_type') or '').lower()
        if re.search(r'\b(lektor|dubbing|polski|pl)\b', lang_type):
            return 'pl'
        if re.search(r'\b(napisy|sub)\b', lang_type):
            return 'en'
        return lang or 'pl'

    def info_from_item(self, item, lower_name):
        vals=[]
        for key,val in self.INFO_HIT.items():
            try:
                if isinstance(key, str):
                    hit = key in lower_name
                else:
                    hit = key.search(lower_name)
                if hit and val and val not in vals:
                    vals.append(val)
            except Exception:
                pass
        lang_type = (item.get('language_type') or '').replace('_',' ').strip()
        if lang_type and lang_type.lower() not in [v.lower() for v in vals]:
            vals.append(lang_type)
        return ' '.join(vals).strip()


class PremiumSmartBase(ObejrzyjFilmyBase):
    PROVIDER = 'premiumsmart'
    URL = 'https://premiumsmart.eu/'

    def _init_session(self):
        try:
            self._session.headers.update({
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
                'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
                'DNT': '1',
            })
            resp = self._session.get(self.URL, timeout=(10, 20))
            if resp.status_code == 200:
                m = re.search(r'window\.bootstrapData\s*=\s*({.*});', resp.text, re.S)
                if m:
                    try:
                        self._csrf_token = json.loads(m.group(1)).get('csrf_token')
                    except Exception:
                        pass
                if not self._csrf_token:
                    m = re.search(r'"csrf_token"\s*:\s*"([^"]+)"', resp.text)
                    if m: self._csrf_token = m.group(1)
                if not self._csrf_token and 'XSRF-TOKEN' in self._session.cookies:
                    self._csrf_token = unquote(self._session.cookies['XSRF-TOKEN'])
        except Exception:
            fflog_exc(1)

    def request(self, url, _retried=False):
        try:
            headers={'accept':'application/json','referer':self.URL}
            if self._csrf_token:
                headers['X-XSRF-TOKEN']=self._csrf_token
            resp = self.session.get(url, headers=headers, timeout=(10,20))
            fflog(f'[{self.PROVIDER.upper()}] request: {url} -> {resp.status_code}', 0)
            if resp.status_code == 200:
                return resp.json()
            if resp.status_code in (401,403,419) and not _retried:
                self._session=None; self._csrf_token=None
                return self.request(url, _retried=True)
        except JSONDecodeError:
            fflog(f'[{self.PROVIDER.upper()}] JSON error for {url!r}')
        except Exception:
            fflog_exc(1)
        return {}

# Loader compatibility: resources.lib.sources scans every .py file and expects
# class source. This helper module must not be exposed as a real provider.
class source(object):
    priority = -1
    language = ['pl']
