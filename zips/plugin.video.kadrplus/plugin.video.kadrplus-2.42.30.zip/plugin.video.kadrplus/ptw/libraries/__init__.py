# -*- coding: utf-8 -*-
"""Small shared helpers used by legacy source modules.

The old source bundle imports ``cfScraper`` and ``custom_base_link`` directly
from this package.  Keeping these helpers lightweight prevents a broken legacy
provider from blocking the rest of the source loader.
"""

try:
    from ptw.libraries import cfscrape

    class _KadrCloudScraper(cfscrape.CloudScraper):
        """CloudScraper with a finite network timeout for legacy providers."""

        def request(self, method, url, *args, **kwargs):
            kwargs.setdefault("timeout", 15)
            return super().request(method, url, *args, **kwargs)

    cfScraper = _KadrCloudScraper.create_scraper()
except Exception:
    try:
        import requests

        class _TimeoutSession(requests.Session):
            def request(self, method, url, *args, **kwargs):
                kwargs.setdefault("timeout", 15)
                return super().request(method, url, *args, **kwargs)

        cfScraper = _TimeoutSession()
    except Exception:
        cfScraper = None


def enabledCheck(module_name):
    """Compatibility helper retained for older source modules."""
    try:
        from ptw.libraries import control
        return control.setting("provider." + str(module_name)) != "false"
    except Exception:
        return True


def custom_base_link(scraper):
    """Return an optional user-defined URL for a legacy provider."""
    try:
        from ptw.libraries import control
        name = str(scraper or "").rsplit(".", 1)[-1]
        url = (control.setting("url." + name) or "").strip()
        if url.startswith(("http://", "https://")):
            return url.rstrip("/")
    except Exception:
        pass
    return None
