"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
def seasons():

    import time
    import datetime
    import json
    import os
    import re
    import sys
    from urllib.parse import (parse_qsl, quote, unquote_plus, quote_plus, urlsplit, urlencode, urlparse, )
    from xbmc import Actor
    import requests
    import six  # Do wywalenia - wkrótce
    from ptw.libraries import apis
    from ptw.libraries import cache
    from ptw.libraries import cleantitle
    from ptw.libraries import client
    from ptw.libraries import control
    from ptw.libraries import log_utils
    from ptw.libraries import source_utils
    from ptw.libraries.log_utils import log, fflog, _is_debugging
    from ptw.debug import log_exception, fflog_exc
    from ptw.libraries import playcount
    from ptw.libraries import trakt
    from ptw.libraries import utils
    from ptw.libraries import views
    from ptw.libraries import bookmarks
    from xbmcplugin import addSortMethod, SORT_METHOD_UNSORTED
    from resources.lib.indexers.super_info import SuperInfo

    # import simplejson as json

    params = dict(parse_qsl(sys.argv[2].replace("?", ""))) if len(sys.argv) > 1 else dict()

    action = params.get("action")


    class seasons:
        def __init__(self, specials=None):
            # fflog("inicjalizacja klasy seasons")

            if 0:
                # fix for not always current value
                # global params, action
                nonlocal params, action
                params = dict(parse_qsl(sys.argv[2].replace("?", ""))) if len(sys.argv) > 1 else dict()
                action = params.get("action")

            self.session = requests.Session()

            self.showunaired = control.setting("showunaired") or "true"
            # fflog(f'{self.showunaired=}',1,1)
            # self.specials = "false"
            self.specials = control.setting('tv.specials') if specials is None else specials
            fflog(f'{self.specials=}',1,1) if specials is not None else ""
            # self.trailer_source = "1"
            # self.trailer_source = control.setting('trailer.source')
            #fflog(f'{self.trailer_source=}')

            self.datetime = datetime.datetime.utcnow()  # - datetime.timedelta(hours = 5)
            self.today_date = self.datetime.strftime("%Y-%m-%d")

            self.lang = control.apiLanguage()["tmdb"] or "en"
            self.tm_user = control.setting("tm.user") or apis.tmdb_API

            self.tmdb_show_link = "https://api.themoviedb.org/3/tv/%s?api_key=%s&language=%s&append_to_response=aggregate_credits,external_ids,content_ratings,episode_groups" % ("%s", self.tm_user, "%s")
            # self.tmdb_show_link = "https://api.themoviedb.org/3/tv/%s?api_key=%s&language=%s&append_to_response=credits,external_ids,content_ratings,episode_groups" % ("%s", self.tm_user, "%s")
            self.tmdb_show_lite_link = "https://api.themoviedb.org/3/tv/%s?api_key=%s&language=en" % ("%s", self.tm_user)
            self.tmdb_by_imdb = "https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id" % ("%s", self.tm_user)
            self.search_link = "https://api.themoviedb.org/3/search/tv?api_key=%s&language=en-US&query=%s&page=1" % (self.tm_user, "%s")
            self.tm_img_link = "https://image.tmdb.org/t/p/w%s%s"

            self.list = []


        def __del__(self):
            self.session.close()


        def get(self, tvshowtitle, year, imdb, tmdb, tvdb=None, meta=None, localtvshowtitle="", originaltvshowtitle="", tv_episode_group_id=None, episode_groups=None, idx=True, create_directory=True):
            fflog(f'(seasons)  {params=}', 0, 1)
            fflog(f'(seasons)  {tvshowtitle=}  {localtvshowtitle=}',1,1)
            try:
                if idx:
                    self.list = cache.get(self.tmdb_list, 12, tvshowtitle, year, imdb, tmdb, tvdb, meta, localtvshowtitle, originaltvshowtitle, tv_episode_group_id, episode_groups)
                    #log_utils.log('idx_list_loaded ')
                    #fflog(repr(self.list))
                    if create_directory:
                        self.seasonDirectory(self.list)
                    return self.list
                else:
                    self.list = self.tmdb_list(tvshowtitle, year, imdb, tmdb, tvdb, localtvshowtitle=localtvshowtitle, originaltvshowtitle=originaltvshowtitle, tv_episode_group_id=tv_episode_group_id, episode_groups=episode_groups, lite=True)
                    #log_utils.log('nonidx_list_loaded ')# + repr(self.list))
                    return self.list
            except Exception:
                fflog_exc(1)
                log_utils.log("seasons_get", "indexer")


        def tmdb_list(self, tvshowtitle, year, imdb, tmdb, tvdb, meta=None, localtvshowtitle="", originaltvshowtitle="", tv_episode_group_id=None, episode_groups=None, lite=False):
            fflog(f'[tmdb_list]',1,1)
            # fflog(f'{lite=}',1,1)
            try:

                if tmdb is None and not imdb == "0":
                    try:
                        url = self.tmdb_by_imdb % imdb
                        # control.log(f'{url=}', 1)
                        result = self.session.get(url, timeout=10).json()
                        tmdb_result = result["tv_results"][0]
                        tmdb = tmdb_result["id"]
                        if not tmdb:
                            tmdb = "0"
                        else:
                            tmdb = str(tmdb)
                    except Exception:
                        # fflog_exc(1)
                        pass

                if tmdb == "0" and tvshowtitle:
                    try:
                        url = (self.search_link % (quote(tvshowtitle)) + "&first_air_date_year=" + year)
                        # control.log(f'{url=}', 1)
                        result = self.session.get(url, timeout=10).json()
                        results = result["results"]
                        show = [r for r in results if cleantitle.get(r.get("name")) == cleantitle.get(tvshowtitle)]  # and re.findall('(\d{4})', r.get('first_air_date'))[0] == year][0]
                        show = show[0]
                        tmdb = show["id"]
                        if not tmdb:
                            tmdb = "0"
                        else:
                            tmdb = str(tmdb)
                    except Exception:
                        # fflog_exc(1)
                        pass

            except Exception as e:
                log_utils.log("tmdb-list0 Exception %s" % e, "indexer")
                fflog_exc(1)
                pass

            if tmdb == "0":
                raise Exception(f"{tmdb=}")


            if meta:
                try:
                    _meta = json.loads(unquote_plus(meta))
                    # fflog(f'{_meta=}',1,1)
                    # fflog(f'_meta={json.dumps(_meta, indent=2)}',1,1)
                except Exception:
                    fflog_exc(1)
                    _meta = {}
                show_poster = _meta.get("poster") or "0"
                show_fanart = _meta.get("fanart") or "0"
            else:
                # fflog(f'{meta=}',1,1)
                show_poster = show_fanart = "0"


            if tv_episode_group_id:
                # fflog(f'{tv_episode_group_id=}',1,1)

                url = f"http://api.themoviedb.org/3/tv/episode_group/{tv_episode_group_id}?api_key={self.tm_user}&language={self.lang}"

                r = self.session.get(url, timeout=10)  # zapytanie do serwera

                r.raise_for_status()
                r.encoding = "utf-8"
                result = r.json()

                groups = result["groups"]
                fflog(f'{len(groups)=}',1,1)
                # group_count = result["group_count"]

                for gr in groups:
                    if self.specials == "false" and gr["order"] == 0:
                        continue
                    self.list.append({
                        "episode_group_id": result["id"],
                        "group_id": gr["id"],
                        "title": gr["name"] + " [LIGHT]*[/LIGHT]",
                        "season": gr["order"],
                        "tvshowtitle": tvshowtitle,
                        "localtvshowtitle": localtvshowtitle, "originaltvshowtitle": originaltvshowtitle,
                        "tmdb": tmdb,
                        "imdb": imdb,
                        "tvdb": tvdb,
                        "year": year,
                        "unaired": "",
                        "poster": show_poster,
                        "fanart": show_fanart,
                    })
                self.list = sorted(self.list, key=lambda k: k["season"])  # trzeba
                return self.list


            item = {}

            # fflog(f'{episode_groups=}')
            if not episode_groups:
                try:
                    seasons_url = self.tmdb_show_link % (tmdb, self.lang) + ",translations"
                    seasons_en_url = self.tmdb_show_link % (tmdb, "en")
                    seasons_lite_url = self.tmdb_show_lite_link % tmdb

                    if self.lang == "en":
                        url = seasons_en_url
                    elif lite:
                        url = seasons_lite_url
                    else:
                        url = seasons_url

                    # control.log(f'{url=}', 1)
                    # now0 = (time.time())
                    r = self.session.get(url, timeout=10)
                    # now1 = (time.time())
                    # fflog(f"request trwał {(now1 - now0)} sek.",1,1)
                    r.raise_for_status()
                    r.encoding = "utf-8"
                    item = r.json()
                    # log_utils.log('tmdb_item: ' + str(item))
                    # fflog(f'item={json.dumps(item, indent=2)}',1,1)

                    if imdb == "0":
                        try:
                            imdb = item["external_ids"]["imdb_id"]
                            if not imdb:
                                imdb = "0"
                        except Exception:
                            pass

                    try:
                        # if not tvdb:
                        tvdb = item["external_ids"]["tvdb_id"]
                        if not tvdb:
                            tvdb = "0"
                        else:
                            tvdb = str(tvdb)
                    except Exception:
                        tvdb = "0"

                    try:
                        studio = item["networks"][0]["name"]
                    except:
                        studio = ""
                    if not studio:
                        studio = "0"

                    try:
                        genres = item["genres"]
                        genre = [d["name"] for d in genres]
                        genre = " / ".join(genre)
                    except:
                        genre = ""
                    if not genre:
                        genre = "0"

                    try:
                        duration = item["episode_run_time"][0]
                        duration = str(duration)
                    except:
                        duration = ""
                    if not duration:
                        duration = "0"

                    try:
                        m = item["content_ratings"]["results"]
                        #mpaa = [d["rating"] for d in m if d["iso_3166_1"] == "US"][0]
                        mpaa = [d["rating"] for d in m if d["iso_3166_1"] in ["US","PL"]][0]
                    except:
                        mpaa = ""
                    if not mpaa:
                        mpaa = "0"
                    #fflog(f'{mpaa=}')

                    try:
                        status = item["status"]
                    except:
                        status = ""
                    if not status:
                        status = "0"

                    castwiththumb = []
                    try:
                        c = item["aggregate_credits"]["cast"][:20]
                        for person in c:
                            _icon = person["profile_path"]
                            icon = self.tm_img_link % ("185", _icon) if _icon else ""
                            castwiththumb.append({"name": person["name"], "role": person["roles"][0]["character"], "thumbnail": icon, })
                    except Exception:
                        # fflog_exc(1)
                        pass
                        try:
                            c = item["credits"]["cast"][:20]
                            if c:
                                for person in c:
                                    _icon = person.get("profile_path")
                                    icon = self.tm_img_link % ("185", _icon) if _icon else ""
                                    castwiththumb.append({"name": person.get("name", ""), "role": person.get("character", ""), "thumbnail": icon, })
                        except Exception:
                            # fflog_exc(1)
                            pass
                    if not castwiththumb:
                        castwiththumb = "0"

                    # opis serialu (nie sezonu) - na wypadek, gdy nie będzie opisu sezonu
                    try:
                        show_plot = item["overview"]
                    except:
                        show_plot = ""
                    if not show_plot:
                        show_plot = "0"
                    if not self.lang == "en" and show_plot == "0":
                        if "translations" in item:
                            try:
                                translations = item["translations"]["translations"]
                                # Najpierw szukamy tłumaczenia w języku interfejsu (np. de)
                                trans_item = [x["data"] for x in translations if x.get("iso_639_1") == self.lang and x.get("data", {}).get("overview")]
                                if not trans_item:
                                    # Fallback do angielskiego
                                    trans_item = [x["data"] for x in translations if x.get("iso_639_1") == "en"]
                                if not trans_item:
                                    # Fallback do pierwszego dostępnego opisu
                                    trans_item = [x["data"] for x in translations if x.get("data", {}).get("overview")]
                                if trans_item:
                                    trans_item = trans_item[0]
                                    show_plot = trans_item["overview"]
                            except Exception:
                                fflog_exc(1)
                                pass

                    unaired = ""

                    try:
                        poster_path = item["poster_path"]
                    except:
                        poster_path = ""
                    if poster_path:
                        show_poster = self.tm_img_link % ("500", poster_path)
                    else:
                        show_poster = "0"

                    try:
                        fanart_path = item["backdrop_path"]
                    except:
                        fanart_path = ""
                    if fanart_path:
                        show_fanart = self.tm_img_link % ("1280", fanart_path)
                    else:
                        show_fanart = "0"

                    meta_poster = meta_fanart = None
                    banner = clearlogo = clearart = keyart = landscape = characterart = country = original_language = original_translation_lang = "0"

                    if meta:
                        _meta = json.loads(unquote_plus(meta))
                        # fflog(f'{_meta=}',1,1)
                        # fflog(f'_meta={json.dumps(_meta, indent=2)}',1,1)
                        meta_poster, meta_fanart, banner, clearlogo, clearart, keyart, landscape, characterart, country = (
                            _meta.get("poster"),
                            _meta.get("fanart"),
                            _meta.get("banner"),
                            _meta.get("clearlogo"),
                            _meta.get("clearart"),
                            _meta.get("keyart"),
                            _meta.get("landscape"),
                            _meta.get("characterart"),
                            _meta.get("country"),
                        )
                        original_language, original_translation_lang = (
                            _meta.get("original_language"),
                            _meta.get("original_translation_lang"),
                        )
                    else:
                        _meta = {}

                except Exception as e:  # może to przenieść na koniec ?
                    log_utils.log("tmdb-list1 Exception: %s " % e, "indexer")
                    fflog_exc(1)
                    return

                seasons = item["seasons"]
                # fflog(f'{len(seasons)=}',1,1)
                # fflog(f'seasons={json.dumps(seasons, indent=2)}',1,1)

                if self.specials == "false":
                    seasons = [s for s in seasons if not s["season_number"] == 0]

                # check if en version needed
                seasons_en = {}
                for s_item in seasons:
                    # fflog(f's_item={json.dumps(s_item, indent=2)}',1,1)
                    plot = s_item["overview"]
                    if not plot:  # or re.search(r'^[Ss]ezon \d+$', s_item["name"]):
                        log_utils.fflog('próba pobrania angielskich opisów do sezonów', 0,1)
                        # control.log(f'  {seasons_en_url=}', 1)
                        # control.log(f'{seasons_lite_url=}', 1)
                        # r_en = self.session.get(seasons_en_url, timeout=10)
                        r_en = self.session.get(seasons_lite_url, timeout=10)
                        r_en.raise_for_status()
                        r_en.encoding = "utf-8"
                        seasons_en = r_en.json()["seasons"]
                        # fflog(f'seasons_en={json.dumps(seasons_en, indent=2)}',1,1)
                        break

                if self.specials == "false":
                    seasons_en = [s for s in seasons_en if not s["season_number"] == 0]

                # check if original version needed
                seasons_org = {}
                if original_translation_lang and original_translation_lang != "0":
                    for s_item in seasons_en:
                        # fflog(f's_item={json.dumps(s_item, indent=2)}',1,1)
                        plot = s_item["overview"]
                        if not plot:  # or re.search(r'^[Ss]eason \d+$', s_item["name"]):
                            log_utils.fflog('próba pobrania oryginalnych opisów do sezonów', 0,1)
                            # seasons_org_url = self.tmdb_show_link % (tmdb, original_translation_lang)
                            seasons_lite_url = seasons_lite_url.replace("&language=en", "&language=%s" % original_translation_lang)
                            # control.log(f'  {seasons_org_url=}', 1)
                            # control.log(f'{seasons_lite_url=}', 1)
                            # r_org = self.session.get(seasons_org_url, timeout=10)
                            r_org = self.session.get(seasons_lite_url, timeout=10)
                            r_org.raise_for_status()
                            r_org.encoding = "utf-8"
                            seasons_org = r_org.json()["seasons"]
                            # fflog(f'seasons_org={json.dumps(seasons_org, indent=2)}',1,1)
                            break

                if self.specials == "false":
                    seasons_org = [s for s in seasons_org if not s["season_number"] == 0]

                if seasons_org:
                    # seasons_en = seasons_org  # dla kompatybilności kodu
                    pass

                count = 0
                # fflog(f'{len(seasons)=}',1,1)
                for s_item in seasons:
                    try:
                        # fflog(f's_item={json.dumps(s_item, indent=2)}',1,1)

                        name = str(s_item["name"])
                        if 0:  # raczej nie ma takiego potrzeby
                            if re.search(r'^[Ss]ezon \d+$', name):
                                if seasons_en:
                                    name = seasons_en[count]["name"]
                                    if re.search(r'^[Ss]eason \d+$', name):
                                        if seasons_org:
                                            name = seasons_org[count]["name"]
                                elif seasons_org:
                                    name = seasons_org[count]["name"]
                            if not name or re.search(r' \d+$', name):  # powrót do pierwszego opisu (polskiego)
                                name = str(s_item["name"])

                        season = str(s_item["season_number"])

                        premiered = s_item.get("air_date", "0") or "0"
                        # fflog(f'{premiered=}  {name=}  {season=}',1,1)

                        unaired = ""
                        if status == "Ended":
                            pass
                        elif not premiered or premiered == "0":
                            # raise Exception()
                            # continue
                            pass
                            # brak daty może oznaczać, że nie znana jest jeszcze premiera (ale i też, że nie została wprowadzona informacja o tym)
                            unaired = "true"
                            # fflog(f'w1 {unaired=}  {name=}  {season=}',1,1)
                            if self.showunaired != "true":
                                continue
                        elif int(re.sub("[^0-9]", "", str(premiered))) > int(re.sub("[^0-9]", "", str(self.today_date))):
                            unaired = "true"
                            # fflog(f'w2 {unaired=}  {name=}  {season=}',1,1)
                            if self.showunaired != "true":
                                # raise Exception()
                                continue

                        plot = s_item["overview"]
                        if not plot:
                            plot = seasons_en[count]["overview"]  # angielski opis
                            if not plot and seasons_org:
                                # plot = show_plot  # opis serialu
                                plot = seasons_org[count]["overview"] or ""  # oryginalny opis
                                pass

                        count += 1

                        episodes = s_item.get("episode_count")

                        poster_path = s_item.get("poster_path")
                        if poster_path:
                            season_poster = self.tm_img_link % ("500", poster_path)
                        else:
                            season_poster = None
                        # fflog(f'{_meta=} {_meta.get("seasons_posters")=} {season=}')
                        poster = season_poster or meta_poster or show_poster
                        poster = _meta.get("seasons_posters", {}).get(season) or poster

                        banner = _meta.get("seasons_banners", {}).get(season) or _meta.get("banner") or ""
                        landscape = _meta.get("seasons_landscapes", {}).get(season) or _meta.get("landscape") or ""
                        # fflog(f'{season=}')
                        # fflog(f'{_meta.get("seasons_banners")=}')
                        # fflog(f'{_meta.get("seasons_banners").get(season)=}')
                        # fflog(f'{banner=}')

                        # fanart = meta_fanart or show_fanart
                        fanart = _meta.get("seasons_fanarts", {}).get(season) or _meta.get("fanart") or show_fanart or ""

                        self.list.append({
                            "title": name, "season": season, "tvshowtitle": tvshowtitle, "year": year, "premiered": premiered,
                            "status": status, "studio": studio, "genre": genre, "duration": duration, "mpaa": mpaa,
                            "castwiththumb": castwiththumb, "plot": plot, "imdb": imdb, "tmdb": tmdb, "tvdb": tvdb,
                            "poster": poster, "fanart": fanart, "banner": banner, "clearlogo": clearlogo, "clearart": clearart,
                            "landscape": landscape, "unaired": unaired, "keyart": keyart, "characterart": characterart, "country": country,
                            "original_language": original_language, "original_translation_lang": original_translation_lang,
                            "localtvshowtitle": localtvshowtitle, "originaltvshowtitle": originaltvshowtitle, "episodes": episodes,
                            })

                    except Exception as e:
                        log_utils.log("seasons_dir Exception: %s " % e, "indexer")
                        fflog_exc(1)
                        pass

            if episode_groups is not False:
                if not tv_episode_group_id and control.setting('tv.episode_group') == "true" or episode_groups:
                    episode_groups = self.tmdb_episode_groups(tmdb, item.get("episode_groups"))
                    if episode_groups:
                        for ep_gr in episode_groups:
                            ep_gr.update({
                                "tvshowtitle": tvshowtitle,
                                "localtvshowtitle": localtvshowtitle, "originaltvshowtitle": originaltvshowtitle,
                                "imdb": imdb,
                                "tvdb": tvdb,
                                "year": year,
                                "unaired": "",
                                "poster": show_poster,
                                "fanart": show_fanart,
                            })
                        self.list += episode_groups

            try:
                cache.cache_insert("seasons" + f"_{tmdb or imdb}", repr(self.list))  # to w sumie nie jest do niczego potrzebne
            except Exception:
                fflog_exc(1)
                pass

            # fflog(f'{len(self.list)=}',1,1)
            # fflog(f'self.list={json.dumps(self.list, indent=2)}')
            return self.list


        def tmdb_episode_groups(self, tmdb, item=None):
            fflog('[tmdb_episode_groups]')
            pass

            group_types = [
            # https://developer.themoviedb.org/reference/tv-episode-group-details
            # Groups support 7 different types which are enumerated as the following:
            # Name, Type
            "",
            "Original air date",  # 1
            "Absolute",  # 2
            "DVD",  # 3
            "Digital",  # 4
            "Story arc",  # 5
            "Production",  # 6
            "TV",  # 7
            ]

            if not item:
                url = f"https://api.themoviedb.org/3/tv/{tmdb}/episode_groups?api_key={self.tm_user}&language={self.lang}"
                # control.log(f'{url=}', 1)
                r = self.session.get(url, timeout=10)
                r.raise_for_status()
                r.encoding = "utf-8"
                item = r.json()
            groups = []
            # fflog(f'{len(item["results"])=}',1,1)  # czy może być więcej niż 1 ?
            for g in item["results"]:
                seasons = g["group_count"]  # ilość sezonów w grupie
                if not seasons:
                    continue
                groups.append({
                    "title": f'[LIGHT] [ [I]{g["name"]} *[/I] ] [/LIGHT]',  # nazwa grupy
                    "tv_episode_group_id": g["id"],  # identyfikator grupy (aby móc uzyskać konkrety grupy)
                    "episodes": g["episode_count"],  # ilość wszystkich odcinków w grupie
                    # "group_count": g["group_count"],  # ilość sezonów w grupie
                    # "season": "*",
                    "season": None,
                    "season": 1 if seasons == 1 else None,
                    "group_type": group_types[g["type"]],
                    "seasons": seasons,
                    "plot": g["description"],
                    # "tmdb": item["id"],
                    "tmdb": tmdb,
                    # "network": g["network"]["name"],  # nazwa sieci telewizyjnej, która zrobiła ten podział (czyli grupę)
                })

            return groups


        def seasonDirectory(self, items, cacheToDisc=False):
            fflog(f'[seasonDirectory]')

            if items is None or len(items) == 0:
                return  #  ; sys.exit()

            sysaddon = sys.argv[0]
            syshandle = int(sys.argv[1])

            if control.setting("zastepcze_grafiki") == "true":
                addonPoster = control.addonPoster()
                addonFanart = control.addonFanart()
                addonBanner = control.addonBanner()
            else:
                addonPoster = addonFanart = addonBanner = ""

            settingFanart = control.setting("fanart")

            traktCredentials = trakt.getTraktCredentialsInfo()
            traktIndicators  = trakt.getTraktIndicatorsInfo()

            isOld = False
            try:
                control.item().getArt("type")
            except Exception:
                #fflog_exc(1)
                isOld = True

            indicators = []
            try:
                # if items[0]["imdb"] and items[0]["imdb"] != 'None' and items[0]["imdb"] != '0':
                if 1:
                    # fflog(f'{items[0]["imdb"]=}',1,1)
                    indicators = playcount.getSeasonIndicators(items[0]["imdb"], ret_tuple=True, tmdb=items[0]["tmdb"])
                # fflog(f'{indicators=}',1,1)
            except Exception:
                # fflog_exc(1)
                # indicators = []
                pass

            select = control.setting("hosts.mode")

            flatten = True if control.setting("flatten.tvshows") == "true" else False
            flatten_only_for_1_season = True if control.setting("flatten.tvshows.only_for_1_season") == "true" else False

            # trailerAction = "tmdb_trailer" if self.trailer_source == "0" else "yt_trailer"  # to nie jest zrobione
            # trailerAction = "trailer"
            watchedMenu =   (control.lang(32068) if traktIndicators == True else control.lang(32066))
            unwatchedMenu = (control.lang(32069) if traktIndicators == True else control.lang(32067))
            queueMenu = control.lang(32065)
            traktManagerMenu = control.lang(32070)
            labelMenu = control.lang(32055)
            playRandom = control.lang(32535)
            addToLibrary = control.lang(32551)
            infoMenu = control.lang(32101)

            generate_short_path = control.setting("generate_short_path") == "true"

            addSortMethod(syshandle, sortMethod=SORT_METHOD_UNSORTED, labelMask="%L", label2Mask="%Y")

            cm_enable_addToLibrary = control.setting("cm.enable.addToLibrary") == "true"
            cm_enable_queueMenu = control.setting("cm.enable.queueMenu") == "true"  # to chyba Kodi dodaje od wersji 21.2
            cm_enable_watchedUnwatched = control.setting("cm.enable.watchedUnwatched") == "true"

            unpremiered_color = control.setting("unpremiered_color")
            if unpremiered_color == "inny":
                unpremiered_color = control.setting("unpremiered_custom_color")
            else:
                colors_map = {
                    "szary": "gray",
                    "czerwony": "red",
                    "fioletowy": "magenta",
                    "pomarańczowy": "orange",
                    }
                unpremiered_color = colors_map[unpremiered_color]
            # fflog(f'{unpremiered_color=}')

            counter = 1
            # fflog(f'{len(items)=}',1,1)
            for i in items:
                try:
                    # log_utils.fflog(f'{i=}')
                    # fflog(f'i={json.dumps(i, indent=2)}',1,1)

                    label = i.get("title")
                    if not label:
                        label = "{} {}".format(labelMenu, i["season"] or "")

                    # fflog(f'{i.get("seasons")=}  {label} \n',1,1)

                    syslabel = quote_plus(label)

                    systitle = quote_plus(i["tvshowtitle"])
                    syslocaltitle = quote_plus(i.get("localtvshowtitle", ""))

                    poster = (i["poster"] if "poster" in i and not i["poster"] == "0" else addonPoster)

                    fanart = (i["fanart"] if "fanart" in i and not i["fanart"] == "0" else addonFanart)

                    banner1 = i.get("banner", "")
                    # banner = banner1 or fanart or addonBanner
                    banner = banner1 or addonBanner

                    if "landscape" in i and not i["landscape"] == "0":
                        landscape = i["landscape"]
                    else:
                        landscape = fanart

                    imdb, tvdb, tmdb, year, season, duration, status = (
                        i["imdb"], i["tvdb"], i["tmdb"], i["year"], i["season"], i.get("duration", "45"), i.get("status", "0")
                    )

                    ep_meta = {
                        "poster": poster,
                        "fanart": fanart,
                        "banner": banner,
                        "clearlogo": i.get("clearlogo") or "0",
                        "clearart": i.get("clearart") or "0",
                        "keyart": i.get("keyart") or "0",
                        "characterart": i.get("characterart") or "0",
                        "landscape": landscape,
                        "duration": duration,
                        "status": status,
                        "mpaa": i.get("mpaa", ""),
                        "country": i.get("country") or "0",
                        'original_language': i.get('original_language') or '0',
                        'original_translation_lang': i.get('original_translation_lang') or '0',
                        "localtvshowtitle": i.get("localtvshowtitle") or "",
                        "originaltvshowtitle": i.get("originaltvshowtitle") or "",
                    }
                    # fflog(f'ep_meta={json.dumps(ep_meta, indent=2)}',1,1)

                    sysmeta = quote_plus(json.dumps(ep_meta))
                    # log_utils.log('sysmeta: ' + str(sysmeta))

                    meta = {k: v for k, v in i.items() if not v == "0"}

                    meta.update({"title": i.get("title") or label})
                    try:
                        if i.get("episode_title") and i.get("episode_title") != i.get("title"):
                            meta.update({"episode_title": i.get("episode_title")})
                    except Exception:
                        pass

                    meta.update({"mediatype": "season"})

                    # if season != '*':
                    if season is not None:
                        meta.update({"season": season})  # potrzebne dla sezonów o numerze 0

                    # meta.update({"imdbnumber": imdb, "code": tmdb})  # mam nadzieję, że "code" nie jest nigdzie wykorzystywane
                    meta.update({"imdbnumber": imdb})

                    # meta.update({"trailer": "%s?action=%s&name=%s&tmdb=%s&season=%s" % (sysaddon, trailerAction, systitle, tmdb, season)})  # if season is not None else ""
                    meta.update({"trailer": "%s?action=trailer&name=%s&url=%s" % (sysaddon, systitle + " " + syslabel, quote_plus(meta.get("trailer") or ""))})

                    if not "duration" in meta:
                        # meta.update({"duration": "45"})
                        # meta.update({"duration": "1"})
                        pass
                    elif meta["duration"] == "0":
                        # meta.update({"duration": "45"})
                        # meta.update({"duration": "1"})
                        pass
                    try:
                        if meta.get("duration") and meta.get("duration") != "0":
                            meta.update({"duration": str(int(meta["duration"]) * 60)})
                    except Exception:
                        fflog_exc(1)
                        pass

                    # try: meta.update({"genre": cleangenre.lang(meta["genre"], self.lang)})
                    # except: pass

                    try:
                        seasonYear = i["premiered"]
                        seasonYear = re.findall(r"(\d{4})", seasonYear)[0]
                        # seasonYear = six.ensure_str(seasonYear)
                        meta.update({"tvshowyear": i["year"]})  # nie ma właściwości "tvshowyear" dla ListItem (ani "showyear")
                        meta.update({"year": seasonYear})
                    except Exception:
                        fflog(f'{i.get("premiered")=}  {season=}  {label=}',0)
                        # fflog_exc(0)
                        pass
                    meta.pop("year", None)  # skórka będzie brała rok z premiery

                    meta.update({"originalname": i.get("originaltvshowtitle", "")})


                    try:
                        if i["unaired"] == "true":
                            if self.showunaired != "true":
                                # fflog(f'{i["unaired"]=}  {i=}  {label=}',1,1)
                                continue
                            label = f"[COLOR {unpremiered_color}][I]%s[/I][/COLOR]" % label
                    except Exception:
                        fflog_exc(1)
                        pass


                    # create ListItem
                    try:
                        item = control.item(label=label, offscreen=True)  # dlaczego tak? przecież to ma być wyświetlane! chyba tego nierozumiem
                    except Exception:
                        fflog_exc(1)
                        item = control.item(label=label)



                    episodes = i.get("episodes") or 0
                    # fflog(f'{episodes=}',1,1)
                    watched = 0
                    if season is not None:
                        try:
                            overlay = playcount.getSeasonOverlay(indicators, imdb, season, episodes, ret_tuple=True, tmdb=tmdb)
                            # fflog(f'{overlay=}  {imdb=}  {tmdb=}  {season=}  {label=} ')
                            if isinstance(overlay, tuple):
                                overlay, watched, episodes = overlay
                            overlay = int(overlay)
                            if overlay == 7:
                                meta.update({"playcount": 1, "overlay": 7})  # to zmienia ptaszki
                            else:
                                meta.update({"playcount": 0, "overlay": 6})  # to zmienia ptaszki
                        except Exception:
                            fflog_exc(1)
                            overlay = 6

                    if episodes:
                        item.setProperty("TotalEpisodes", str(episodes))
                        item.setProperty("WatchedEpisodes", str(watched))
                        item.setProperty("UnWatchedEpisodes", str(episodes - watched))
                        progress = int((watched / episodes) * 100)
                        # item.setProperty("WatchedProgress", str(progress))  # też działa
                        item.setProperty("WatchedEpisodePercent", str(progress))  # for tvshow and season


                    meta.pop("next", None)


                    cm = []  # bulding context menu

                    if cm_enable_addToLibrary:
                        cm.append((addToLibrary,
                                   "RunPlugin(%s?action=tvshowToLibrary&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&localtvshowtitle=%s)" % (
                                    sysaddon, systitle, year, imdb, tmdb, syslocaltitle),))
                    # if season != '*':
                    if season is not None:
                        if not traktIndicators:
                            if overlay != 7:
                                if cm_enable_watchedUnwatched:
                                    cm.append((watchedMenu,   "RunPlugin(%s?action=tvPlaycount&name=%s&imdb=%s&tmdb=%s&season=%s&query=7)" % (sysaddon, systitle, imdb, tmdb, season),))
                            if True:
                                if cm_enable_watchedUnwatched:
                                    cm.append((unwatchedMenu, "RunPlugin(%s?action=tvPlaycount&name=%s&imdb=%s&tmdb=%s&season=%s&query=6)" % (sysaddon, systitle, imdb, tmdb, season),))

                        if traktCredentials:
                            cm.append((traktManagerMenu, "RunPlugin(%s?action=traktManager&name=%s&imdb=%s&tmdb=%s&season=%s&content=tvshow&overlay=%s)" % (sysaddon, systitle, imdb, tmdb, season, overlay),))

                    # Odtwarzaj losowo (? - trochę dziwne to, raczej do teledysków się nadaje, niż do seriali).
                    # if False:  # wyłączenie
                    if 1:
                        # if season is not None:  # ?
                        # losowany jest odcinek z danego sezonu
                        cm.append((playRandom, "RunPlugin(%s?action=random&rtype=episode&tvshowtitle=%s&localtvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&season=%s&select=%s)" % (
                                            sysaddon, systitle, syslocaltitle, year, imdb, tmdb, season, select),))
     
                    if cm_enable_queueMenu:
                        if not generate_short_path:  # zapis z tvshow.py - bo inaczej źle dodaje (dodaje te same odcinki kilka razy w zależności od ilości sezonów)
                            cm.append((queueMenu, "RunPlugin(%s?action=queueItem)" % sysaddon))

                    if generate_short_path:
                        cm.append(("[I]przygotuj do ulubionych[/I]", "Container.Update(%s?action=prepareItemForAddToLibrary)" % (sysaddon),))

                    if isOld:
                        cm.append((infoMenu, "Action(Info)"))

                    item.addContextMenuItems(cm)


                    art = {}

                    art.update({
                                "icon": poster, 
                                "thumb": poster, 
                                "poster": poster, 
                                "season.poster": poster,  # zależy od skórki (jak ma kod napisany)
                                # "tvshow.poster": poster,  # niektóre mogą pewnie i tego wymagać
                                "banner": banner, 
                                "landscape": landscape, 
                              })

                    if settingFanart == "true":
                        art.update({"fanart": fanart})
                    elif not addonFanart is None:
                        art.update({"fanart": addonFanart})

                    if "clearlogo" in i and not i["clearlogo"] == "0":
                        art.update({"clearlogo": i["clearlogo"]})
                        art.update({"tvshow.clearlogo": i["clearlogo"]})  # to jest ważniejsze dla skórki (tak są tam przeważnie zapisane warunki sprawdzające) - sprawdzane po kolei od góry i zatrzymanie się na którymś
                        pass

                    if "clearart" in i and not i["clearart"] == "0":
                        art.update({"clearart": i["clearart"]})

                    if "keyart" in i and not i["keyart"] == "0":
                        art.update({"keyart": i["keyart"]})

                    """
                    if "characterart" in i and not i["characterart"] == "0":
                        art.update({"characterart": i["characterart"]})
                    """
                    # if has("characterart"):
                    if "characterart" in i and not i["characterart"] == "0":
                        characterart = i["characterart"]
                        if isinstance(characterart, list):
                            for an in range(0, len(characterart)):
                                # art[f"characterart{an+1}"] = characterart[an]
                                art.update({f"characterart{an+1}": characterart[an]})
                                # art.update({f"tvshow.characterart{an+1}": characterart[an]})
                        else:
                            # art["characterart"] = characterart
                            art.update({"characterart": characterart})
                            # art.update({"tvshow.characterart": characterart})


                    item.setArt(art)


                    castwiththumb = i.get("castwiththumb")
                    if castwiththumb and not castwiththumb == "0":
                        # item.setCast(castwiththumb)
                        castwiththumb = [Actor(**a) for a in castwiththumb]
                        vtag = item.getVideoInfoTag()
                        vtag.setCast(castwiththumb)


                    # fflog(f'{control.metadataClean(meta)=}')

                    if control.metadataClean(meta):
                        try:
                            item.setInfo(type="video", infoLabels=control.metadataClean(meta))
                        except Exception:
                            fflog_exc(1)


                    # korekta pod standard ListItem (bo super_info.py inaczej generuje)
                    item.setInfo(type="Video", infoLabels={'TvShowTitle': meta.get("localtvshowtitle") or meta.get("tvshowtitle", "")})
                    item.setProperty("englishTvShowTitle", meta.get("englishtvshowtitle") or meta.get("tvshowtitle", ""))
                    #item.setProperty("OriginalTvShowTitle", meta.get("originaltvshowtitle") or meta.get("tvshowtitle", ""))
                    item.setProperty("OriginalTvShowTitle", meta.get("originaltvshowtitle") or "")
                    item.setProperty("TvShowYear", meta.get("tvshowyear") or meta.get("year", ""))

                    try:
                        _pp = str(meta.get("percentplayed") or meta.get("progress") or "")
                        _we = str(meta.get("watchedepisodes") or "")
                        _te = str(meta.get("totalepisodes") or "")
                        if _pp:
                            item.setProperty("PercentPlayed", _pp)
                            item.setProperty("percentplayed", _pp)
                            item.setProperty("Progress", _pp)
                            item.setProperty("progress", _pp)
                            item.setProperty("progress.percent", _pp)
                            item.setProperty("FanFilm.Progress", _pp)
                            item.setProperty("KadrPlus.Progress", _pp)
                        if _we:
                            item.setProperty("WatchedEpisodes", _we)
                            item.setProperty("watchedepisodes", _we)
                        if _te:
                            item.setProperty("TotalEpisodes", _te)
                            item.setProperty("totalepisodes", _te)
                    except Exception:
                        pass

                    try:
                        _pp = str(meta.get("percentplayed") or meta.get("progress") or "")
                        _we = str(meta.get("watchedepisodes") or "")
                        _te = str(meta.get("totalepisodes") or "")
                        if _pp:
                            item.setProperty("percentplayed", _pp)
                            item.setProperty("PercentPlayed", _pp)
                            item.setProperty("progress", _pp)
                            item.setProperty("WatchedProgress", _pp)
                            item.setProperty("WatchedEpisodePercent", _pp)
                            item.setProperty("Progress", _pp)
                            item.setProperty("progresspercent", _pp)
                        if _we:
                            item.setProperty("WatchedEpisodes", _we)
                            item.setProperty("watchedepisodes", _we)
                        if _te:
                            item.setProperty("TotalEpisodes", _te)
                            item.setProperty("totalepisodes", _te)
                    except Exception:
                        pass


                    if generate_short_path:
                        # fflog(f'{imdb=} {tmdb=} {tvdb=}')
                        try:
                            vtag = item.getVideoInfoTag()
                            vtag.setUniqueIDs({
                                'imdb': imdb,
                                'tmdb' : tmdb,
                                'tvdb' : tvdb,
                            })
                        except Exception:
                            fflog_exc(1)
                            item.setProperty("imdb_id", imdb)
                            item.setProperty("tmdb_id", tmdb)
                            item.setProperty("tmdb_id", tvdb)

                        item.setProperty("meta", json.dumps(ep_meta))


                    tv_episode_group_id = i.get("tv_episode_group_id")
                    episode_group_id = i.get("episode_group_id")  # chyba te same wartości
                    # fflog(f'{tv_episode_group_id=}  {episode_group_id=}',1,1)
                    if season is not None and episode_group_id:
                        tv_episode_group_id = episode_group_id
                        pass
                    if not tv_episode_group_id:
                        # fflog(f'0 {tv_episode_group_id=} {episode_group_id=} {season=}',1,1)
                        url = "%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&meta=%s&season=%s" % (sysaddon, systitle, year, imdb, tmdb, tvdb, sysmeta, season)
                    else:
                        if flatten and not flatten_only_for_1_season or flatten and flatten_only_for_1_season and i.get('seasons') == 1 or season is not None:
                            # fflog(f'A {flatten=} {season=}',1,1)
                            # url = "%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&meta=%s" % (sysaddon, systitle, year, imdb, tmdb, tvdb, epmeta)  # z tvshows.py
                            url = "%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&meta=%s&season=%s&tv_episode_group_id=%s" % (sysaddon, systitle, year, imdb, tmdb, tvdb, sysmeta, season, tv_episode_group_id)
                        else:
                            # fflog(f'B {flatten=} {season=}',1,1)
                            meta_tmp = {}
                            meta_tmp.update({"poster": meta.get("poster")})
                            meta_tmp.update({"fanart": meta.get("fanart")})
                            url = ( "%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&tv_episode_group_id=%s&meta=%s" 
                                % ( sysaddon, systitle, year, imdb, tmdb, tvdb, tv_episode_group_id, quote_plus(json.dumps(meta_tmp)) ) )
                    if generate_short_path:
                        item.setProperty("fullpath", url)
                        if not tv_episode_group_id:
                            # fflog(f'1 {tv_episode_group_id=} {episode_group_id=} {season=}',1,1)
                            url = "{}?action=episodes&item={}".format(sysaddon, i["season"])
                        else:
                            item.setProperty("tv_episode_group_id", tv_episode_group_id)
                            # if flatten is True or season is not None:
                            if flatten and not flatten_only_for_1_season or flatten and flatten_only_for_1_season and i.get('seasons') == 1 or season is not None:
                                # fflog(f'C {flatten=} {season=}',1,1)
                                # url = "{}?action=episodes&item={}".format(sysaddon, i["tv_episode_group_id"])
                                url = "{}?action=episodes&item={}".format(sysaddon, counter)
                            else:
                                # fflog(f'D {flatten=} {season=}',1,1)
                                # url = "{}?action=seasons&item={}".format(sysaddon, tv_episode_group_id)
                                # url = "{}?action=seasons_alt&item={}".format(sysaddon, f'{counter}-{counter}')
                                url = "{}?action=seasons_alt&item={}".format(sysaddon, counter)


                    # video_streaminfo = {"codec": "h264"}; item.addStreamInfo("video", video_streaminfo)  # czy to konieczne?


                    control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)

                    counter += 1
                except Exception:
                    log_utils.log("season-dir Exception", "indexer")
                    fflog_exc(1)
                    pass
            # fflog(f'counter={counter - 1}',1,1)  # kontrola

            try:
                # ciekawe do czego to służy
                # control.property(syshandle, "ShowPlot", items[0]["plot"])  # ale to powoduje, że każdy sezon ma ten sam opis
                # control.property(syshandle, "ShowTitle", items[0]["tvshowtitle"])  # j.w. choć nie testowałem - a może to nieprawidłowa implementacja w skórce?
                # https://kodi.wiki/view/InfoLabels  Container.ShowPlot i Container.ShowTitle  dyskusja https://forum.kodi.tv/showthread.php?tid=94282&pid=726187#pid726187
                # jakby górny tytuł katalogu w niektórych skórkach
                # if len(items):
                # cat_label = items[0]["tvshowtitle"]
                # cat_label = meta["tvshowtitle"]
                cat_label = meta.get("localtvshowtitle") or meta.get("tvshowtitle")
                if meta.get("tvshowyear") and cat_label:
                    cat_label += f' ({meta.get("tvshowyear")})'
                    pass
                if cat_label:
                    control.pluginCategory(syshandle, cat_label)
                    pass
            except Exception:
                fflog_exc(1)
                pass


            control.content(syshandle, "seasons")  # takiego typu oficjalnie chyba nie ma (albo brak takiej informacji w dokumentacji)

            params = dict(parse_qsl(sys.argv[2][1:]))
            updateListing = True if params.get("r") else False  # True świadczy, że po drodze było odświeżanie

            control.directory(syshandle, cacheToDisc=cacheToDisc, updateListing=updateListing)

            views.setView("seasons")


    return seasons()








def episodes():

    import time
    import datetime
    import json
    import os
    import re
    import sys
    from urllib.parse import (parse_qsl, quote, unquote_plus, quote_plus, urlsplit, urlencode, urlparse, )
    from xbmc import Actor
    import requests
    import six  # Do wywalenia - wkrótce
    from ptw.libraries import apis
    from ptw.libraries import cache
    from ptw.libraries import cleantitle
    from ptw.libraries import client
    from ptw.libraries import control
    from ptw.libraries import log_utils
    from ptw.libraries import source_utils
    from ptw.libraries.log_utils import log, fflog, _is_debugging
    from ptw.debug import log_exception, fflog_exc
    from ptw.libraries import playcount
    from ptw.libraries import trakt
    from ptw.libraries import utils
    from ptw.libraries import views
    from ptw.libraries import bookmarks
    from xbmcplugin import addSortMethod, SORT_METHOD_UNSORTED
    from resources.lib.indexers.super_info import SuperInfo

    # import simplejson as json

    params = dict(parse_qsl(sys.argv[2].replace("?", ""))) if len(sys.argv) > 1 else dict()

    action = params.get("action")


    class episodes:
        def __init__(self, specials=None):
            # fflog("inicjalizacja klasy episodes")

            if 0:
                # fix for not always current value
                # global params, action
                nonlocal params, action
                params = dict(parse_qsl(sys.argv[2].replace("?", ""))) if len(sys.argv) > 1 else dict()
                action = params.get("action")

            self.session = requests.Session()

            self.list = []

            self.trakt_link = "https://api.trakt.tv"
            self.tvmaze_link = "https://api.tvmaze.com"

            self.datetime = datetime.datetime.utcnow()  # - datetime.timedelta(hours = 5)
            self.systime = self.datetime.strftime("%Y%m%d%H%M%S%f")
            self.today_date = self.datetime.strftime("%Y-%m-%d")

            self.tm_user = control.setting("tm.user") or apis.tmdb_API
            self.trakt_user = control.setting("trakt.user").strip()
            self.showunaired = control.setting("showunaired") or "true"
            # self.specials = "false"
            self.specials =  control.setting('tv.specials') if specials is None else specials
            fflog(f'{self.specials=}',1,1) if specials is not None else ""
            self.lang = control.apiLanguage()["tmdb"] or "en"
            self.language = f"{self.lang}-{self.lang.upper()}"
            # self.hq_artwork = "false"
            self.fanartTV_artwork = control.setting("fanartTV_artwork")
            self.items_per_page = str(control.setting("items.per.page")) or "20"
            # self.trailer_source = "1"
            # self.trailer_source = control.setting('trailer.source')


            # tmdb
            self.tmdb_show_lite_link =   "https://api.themoviedb.org/3/tv/%s?api_key=%s&language=en" % ("%s", self.tm_user)
            self.tmdb_season_link =     ("https://api.themoviedb.org/3/tv/%s/season/%s?api_key=%s&language=%s&append_to_response=aggregate_credits" % (
                        "%s", "%s", self.tm_user, "%s"))
            self.tmdb_season_lite_link = "https://api.themoviedb.org/3/tv/%s/season/%s?api_key=%s&language=en" % ("%s", "%s", self.tm_user)
            self.tmdb_episode_link =    ("https://api.themoviedb.org/3/tv/%s/season/%s/episode/%s?api_key=%s&language=%s&append_to_response=credits" % (
                        "%s", "%s", "%s", self.tm_user, self.lang))
            self.tmdb_episode_link_en = ("https://api.themoviedb.org/3/tv/%s/season/%s/episode/%s?api_key=%s&language=en" % (
                        "%s", "%s", "%s", self.tm_user))
            self.search_link =           "https://api.themoviedb.org/3/search/tv?api_key=%s&language=en-US&query=%s&page=1" % (self.tm_user, "%s")
            self.tmdb_by_imdb =          "https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id" % ("%s", self.tm_user)
            self.tm_img_link = "https://image.tmdb.org/t/p/w%s%s"


            self.tmdbuser = control.setting("tmdb.username") or "me"  # or control.setting("tmdb.account_id")
            self.tmdb_sessionid = control.setting("tmdb.sessionid") or ""
            self.tmdb_guest_session_id = control.setting("tmdb.guest_session_id") or ""


            self.tmdbuserrated_link = self.tmdbuserratedepisodes_link = (
                "https://api.themoviedb.org/3/account/%s/rated/tv/episodes?api_key=%s&language=%s&session_id=%s&sort_by=created_at.desc&page=1" % (
                    self.tmdbuser, self.tm_user, self.lang, self.tmdb_sessionid))

            self.tmdbguestrated_link = self.tmdbguestratedepisodes_link = (
                "https://api.themoviedb.org/3/guest_session/%s/rated/tv/episodes?api_key=%s&language=%s&sort_by=created_at.desc&page=1" % (
                    self.tmdb_guest_session_id, self.tm_user, self.lang))


            # obrazki z fanartTV
            self.fanart_tv_art_link = "http://webservice.fanart.tv/v3/tv/%s"
            self.fanart_tv_user = control.setting("fanart.tv.user") or apis.fanarttv_client_key  # user musi swój podać (bo na domyślnym z FF nie działa)
            self.fanart_tv_API_key = control.setting("fanart.tv.dev") or apis.fanarttv_API_key
            self.fanart_tv_headers = {"api-key": self.fanart_tv_API_key, "client-key": self.fanart_tv_user, }

            # tv maze
            self.added_link = "https://api.tvmaze.com/schedule"
            self.calendar_link = "https://api.tvmaze.com/schedule?date=%s"

            # trakt
            # https://api.trakt.tv/calendars/all/shows/date[30]/31 #use this for new episodes?
            # self.mycalendar_link = "https://api.trakt.tv/calendars/my/shows/date[29]/60/"
            self.mycalendar_link = "https://api.trakt.tv/calendars/my/shows/date[30]/31/"  # go back 30 and show all shows aired until tomorrow
            self.trakthistory_link = "https://api.trakt.tv/users/me/history/shows?limit=%s" % self.items_per_page
            self.progress_link = "https://api.trakt.tv/users/me/watched/shows"
            self.hiddenprogress_link = "https://api.trakt.tv/users/hidden/progress_watched?limit=1000&type=show"
            self.onDeck_link = "https://api.trakt.tv/sync/playback/episodes?limit=%s" % self.items_per_page
            self.traktlists_link = "https://api.trakt.tv/users/me/lists"
            self.traktlikedlists_link = "https://api.trakt.tv/users/likes/lists?limit=1000000"
            self.traktlist_link = "https://api.trakt.tv/users/%s/lists/%s/items"



        def __del__(self):
            self.session.close()


        def get(self, tvshowtitle, year, imdb, tmdb, tvdb=None, season=None, episode=None, meta=None, localtvshowtitle="", originaltvshowtitle="", tv_episode_group_id=None, idx=True, create_directory=True, showunaired=None):
            fflog(f'(episodes)  {params=}', 0, 1)
            fflog(f'(episodes)  {season=}  {episode=}  {tvshowtitle=}  {localtvshowtitle=}',1,1)
            try:
                if idx:
                    if season is None or episode is None:
                        fflog(f'tu 1')
                        self.list = cache.get(self.tmdb_list, 1, tvshowtitle, year, imdb, tmdb, tvdb, season, meta, localtvshowtitle, originaltvshowtitle, tv_episode_group_id)
                        # fflog(f'{len(self.list)=}')
                    # elif episode == None:
                    # self.list = cache.get(self.tmdb_list, 1, tvshowtitle, year, imdb, tmdb, fanart, duration, status, season)
                    # pass
                    else:
                        # fflog(f'tu 2')  # kiedy to jest wykorzystywane ? - okazało się, że to przychodzi z calendar'a , np. postęp (pokazuje odcinki od któregoś dopiero)
                        self.list = cache.get(self.tmdb_list, 1, tvshowtitle, year, imdb, tmdb, tvdb, season, meta, localtvshowtitle, originaltvshowtitle, tv_episode_group_id)
                        # fflog(f'{len(self.list)=}')
                        num = [x for x, y in enumerate(self.list) if y["season"] == str(season) and y["episode"] == str(episode)][-1]
                        # fflog(f'{num=}')
                        self.list = [y for x, y in enumerate(self.list) if x >= num]
                        # fflog(f'{len(self.list)=}')
                    if create_directory:
                        # fflog(f'tu 3')
                        self.episodeDirectory(self.list)
                    return self.list
                else:
                    # fflog(f'tu 4')
                    self.list = self.tmdb_list(tvshowtitle, year, imdb, tmdb, tvdb, season, meta, localtvshowtitle=localtvshowtitle, originaltvshowtitle=originaltvshowtitle, tv_episode_group_id=tv_episode_group_id, lite=True, showunaired=showunaired)
                    return self.list
            except Exception:
                log_utils.log("episodes_get Exception", "indexer")
                fflog_exc(1)
                pass


        def calendar(self, url, refresh=None):
            # debug
            if not "http" in url: 
                fflog(f'{params=}', fn=True)
                pass
            else:
                if not _is_debugging():
                    fflog(f'params={({**params, "url": "*"})}', 1, 1)
                    pass
                else:
                    fflog(f'params={({**params, "url": url})}', 0)

            force_tvshow_title: bool = False
            #fflog(f'{url=} {refresh=}')
            try:
                #url = re.sub("(?<=api_key=)[^&]*", self.tm_user, url)  # tu nie występuje nic z tmdb
                try:
                    url = getattr(self, url + "_link")
                except Exception:
                    #fflog_exc(1)
                    pass
                #fflog(f'{url=}')
                if self.trakt_link in url and url == self.onDeck_link:
                    # self.blist = cache.get(self.trakt_episodes_list, 0, url, self.trakt_user, self.lang)
                    self.list = []
                    self.list = self.trakt_episodes_list(url, self.trakt_user, self.lang)
                    if self.list:
                        self.list = sorted(self.list, key=lambda k: int(k["paused_at"]), reverse=True)

                elif self.trakt_link in url and url == self.progress_link:
                    cache_timeout = 0 if refresh else 1
                    # self.blist = cache.get(self.trakt_progress_list, 720, url, self.trakt_user, self.lang)
                    self.list = cache.get(self.trakt_progress_list, cache_timeout, url, self.trakt_user, self.lang)
                    force_tvshow_title = True

                elif self.trakt_link in url and url == self.mycalendar_link:
                    # self.blist = cache.get(self.trakt_episodes_list, 720, url, self.trakt_user, self.lang)
                    cache_timeout = 0 if refresh else 12
                    self.list = []
                    self.list = cache.get(self.trakt_episodes_list, cache_timeout, url, self.trakt_user, self.lang)
                    if self.list:
                        self.list = sorted(self.list, key=lambda k: k["premiered"], reverse=True)

                elif self.trakt_link in url and url == self.trakthistory_link:
                    cache_timeout = 0 if refresh else 1
                    self.list = cache.get(self.trakt_episodes_list, cache_timeout, url, self.trakt_user, self.lang)
                    if self.list:
                        self.list = sorted(self.list, key=lambda k: int(k["watched_at"]), reverse=True)

                elif self.trakt_link in url and "/users/" in url:
                    cache_timeout = 0 if refresh else 1
                    self.list = cache.get(self.trakt_list, cache_timeout, url, self.trakt_user)
                    if self.list:
                        self.list = self.list[::-1]

                elif self.trakt_link in url:
                    cache_timeout = 0 if refresh else 1
                    self.list = cache.get(self.trakt_list, cache_timeout, url, self.trakt_user)

                elif self.tvmaze_link in url and url == self.added_link:
                    urls = [i["url"] for i in self.calendars(idx=False)][:5]
                    self.list = []
                    for url in urls:
                        self.list += cache.get(self.tvmaze_list, 720, url, True)

                elif self.tvmaze_link in url:
                    self.list = cache.get(self.tvmaze_list, 1, url, False)

                elif self.tmdbuserratedepisodes_link in url or self.tmdbguestratedepisodes_link in url:
                    # fflog(f'{url=}',1,1)
                    cache_timeout = 0 if refresh else 0.1  # 6 minut
                    # cache_timeout = 0  # wyłączenie z cachowania
                    self.list = cache.get(self.tmdb_list_by_url, cache_timeout, url)


                if self.list:
                    self.episodeDirectory(self.list, force_tvshow_title=force_tvshow_title)
                else:
                    control.infoDialog('Nic nie znaleziono', "Błąd", icon="ERROR")
                    # control.directory(int(sys.argv[1]), cacheToDisc=False)
                    # control.sleep0(100)
                    # control.execute('Action(Back)')

                return self.list

            except Exception:
                fflog_exc(1)
                pass


        def widget(self):
            if trakt.getTraktIndicatorsInfo():
                setting = control.setting("tv.widget.alt")
            else:
                setting = control.setting("tv.widget")

            if setting == "2":
                self.calendar(self.progress_link)
            elif setting == "3":
                self.calendar(self.mycalendar_link)
            else:
                self.calendar(self.added_link)


        def calendars(self, idx=True):
            m = control.lang(32060).split("|")
            try:
                months = [(m[0], "January"), (m[1], "February"), (m[2], "March"), (m[3], "April"), (m[4], "May"),
                    (m[5], "June"), (m[6], "July"), (m[7], "August"), (m[8], "September"), (m[9], "October"),
                    (m[10], "November"), (m[11], "December"), ]
            except:
                months = []

            d = control.lang(32061).split("|")
            try:
                days = [(d[0], "Monday"), (d[1], "Tuesday"), (d[2], "Wednesday"), (d[3], "Thursday"), (d[4], "Friday"),
                    (d[5], "Saturday"), (d[6], "Sunday"), ]
            except:
                days = []

            for i in range(0, 30):
                try:
                    name = self.datetime - datetime.timedelta(days=i)
                    name = control.lang(32062) % (name.strftime("%A"), six.ensure_str(name.strftime("%d %B")),)
                    for m in months:
                        name = name.replace(m[1], m[0])
                    for d in days:
                        name = name.replace(d[1], d[0])
                    # try: name = six.ensure_str(name)
                    # except: pass

                    url = self.calendar_link % (self.datetime - datetime.timedelta(days=i)).strftime("%Y-%m-%d")

                    self.list.append({"name": name, "url": url, "action": "calendar", "image": "calendar.png",})
                except:
                    pass
            if idx:
                self.addDirectory(self.list)
            return self.list


        def userlists(self):
            """ tylko listy trakt """
            fflog(f'{params=}', 1, 1)
            try:
                userlists = []
                if not trakt.getTraktCredentialsInfo():
                    raise Exception()
                activity = trakt.getActivity()
                #fflog(f'{activity=}')
            except Exception:
                fflog_exc(1)
                pass

            try:
                if not trakt.getTraktCredentialsInfo():
                    raise Exception()
                try:
                    if activity > cache.timeout(self.trakt_user_list, self.traktlists_link, self.trakt_user):
                        raise Exception()
                    #fflog(f'z cache')
                    userlists += cache.get(self.trakt_user_list, 720, self.traktlists_link, self.trakt_user)
                except:
                    #fflog(f'odświeżam')
                    userlists += cache.get(self.trakt_user_list, 0, self.traktlists_link, self.trakt_user)
            except Exception:
                #fflog_exc(1)
                pass

            try:
                self.list = []
                if not trakt.getTraktCredentialsInfo():
                    raise Exception()
                try:
                    if activity > cache.timeout(self.trakt_user_list, self.traktlikedlists_link, self.trakt_user):
                        raise Exception()
                    #fflog(f'z cache')
                    userlists += cache.get(self.trakt_user_list, 720, self.traktlikedlists_link, self.trakt_user, )
                except:
                    #fflog(f'odświeżam')
                    userlists += cache.get(self.trakt_user_list, 0, self.traktlikedlists_link, self.trakt_user)
            except Exception:
                #fflog_exc(1)
                pass

            self.list = userlists
            for i in range(0, len(self.list)):
                self.list[i].update({
                    "action": "calendar",
                    # "image": "userlists.png",
                    "image": "trakt.png",
                    })
            self.addDirectory(self.list, queue=True, add_refresh=True)
            return self.list


        def trakt_list(self, url, user):
            try:
                #fflog(f'{url=}')
                for i in re.findall(r"date\[(\d+)]", url):
                    url = url.replace("date[%s]" % i, (self.datetime - datetime.timedelta(days=int(i))).strftime("%Y-%m-%d"), )

                q = dict(parse_qsl(urlsplit(url).query))
                q.update({"extended": "full"})
                q = (urlencode(q)).replace("%2C", ",")
                u = url.replace("?" + urlparse(url).query, "") + "?" + q
                # fflog(f'{u=}')
                itemlist = []
                items = trakt.getTraktAsJson(u)
            except Exception:
                fflog_exc(1)
                # print("Unexpected error in info builder script:", sys.exc_info()[0])
                # exc_type, exc_obj, exc_tb = sys.exc_info()
                # print(exc_type, exc_tb.tb_lineno)
                log_utils.log("trakt_list0", "indexer")
                return

            localtvshowtitles = {}

            fflog(f'{len(items)=}',1,1)
            for item in items:
                try:
                    # fflog(f'{item=}')
                    if not item.get("episode"):
                        #raise Exception()
                        continue              

                    title = item["episode"]["title"]
                    if title is None or title == "":
                        #raise Exception()
                        continue
                    title = client.replaceHTMLCodes(title)

                    season = item["episode"]["season"]
                    season = re.sub("[^0-9]", "", "%01d" % int(season))
                    if season == "0" and self.specials != "true":
                        #raise Exception()
                        continue

                    episode = item["episode"]["number"]
                    episode = re.sub("[^0-9]", "", "%01d" % int(episode))
                    if episode == "0":
                        #raise Exception()
                        continue

                    tvshowtitle = item["show"]["title"]
                    if not tvshowtitle:
                        #raise Exception()
                        continue
                    else:
                        tvshowtitle = client.replaceHTMLCodes(six.ensure_str(tvshowtitle))

                    year = item["show"]["year"]
                    year = re.sub("[^0-9]", "", str(year))

                    imdb = item["show"]["ids"].get("imdb")
                    if imdb is None or imdb == "":
                        imdb = "0"
                    else:
                        imdb = "tt" + re.sub("[^0-9]", "", str(imdb))

                    tvdb = item["show"]["ids"].get("tvdb")
                    if not tvdb:
                        tvdb == "0"
                    tvdb = re.sub("[^0-9]", "", str(tvdb))

                    tmdb = item["show"]["ids"]["tmdb"]
                    if not tmdb:
                        #raise Exception()
                        continue
                    tmdb = str(tmdb)

                    trakt_id = item["show"]["ids"].get("trakt")

                    premiered = item["episode"].get("first_aired")
                    try:
                        premiered = re.compile(r"(\d{4}-\d{2}-\d{2})").findall(premiered)[0]
                    except:
                        premiered = "0"

                    studio = item["show"].get("network")
                    if not studio:
                        studio = "0"

                    genre = item["show"].get("genres")
                    genre = [i.title() for i in genre] if genre else []
                    if not genre:
                        genre = "0"
                    else:
                        genre = " / ".join(genre)

                    try:
                        duration = str(item["show"]["runtime"])
                    except:
                        duration = ""
                    if not duration:
                        duration = "0"

                    try:
                        rating = str(item["episode"]["rating"])
                    except:
                        rating = "0"
                    if rating is None or rating == "0.0":
                        rating = "0"

                    try:
                        votes = str(item["episode"]["votes"])
                    except:
                        votes = "0"
                    try:
                        votes = str(format(int(votes), ",d"))
                    except:
                        pass
                    if not votes:
                        votes = "0"

                    mpaa = item["show"].get("certification")
                    if not mpaa:
                        mpaa = "0"

                    try:
                        plot = item["episode"]["overview"]
                    except:
                        plot = ""
                    if not plot:
                        plot = item["show"]["overview"]
                    if not plot:
                        plot = "0"
                    else:
                        plot = client.replaceHTMLCodes(six.ensure_str(plot, errors="replace"))

                    try:
                        paused_at = item.get("paused_at", "0") or "0"
                        paused_at = re.sub("[^0-9]+", "", paused_at)
                    except:
                        paused_at = "0"

                    try:
                        watched_at = item.get("watched_at", "0") or "0"
                        watched_at = re.sub("[^0-9]+", "", watched_at)
                    except:
                        watched_at = "0"

                    try:
                        if self.lang != "en":
                            # if imdb and imdb != "None" and imdb != "0":  # albo trzeba by pozyskać trakt_id na podstawie tmdb
                            if trakt_id:
                                # fflog(f'tłumaczenia  {imdb=}  {tmdb=}  {season=}  {episode=}  {trakt_id=}  ')
                                trans_item = trakt.getTVShowTranslation(trakt_id, lang=self.lang, season=season, episode=episode, full=True)
                                # fflog(f'{trans_item=}')
                                if trans_item:
                                    title = client.replaceHTMLCodes(six.ensure_str(trans_item.get("title") or "")) or title
                                    plot = client.replaceHTMLCodes(six.ensure_str(trans_item.get("overview"), errors="replace")) or plot

                                # fflog(f'ustalenie polskiego tytułu serialu {imdb=} {tmdb=} {trakt_id=}')
                                localtvshowtitle = localtvshowtitles.get(trakt_id)
                                if not localtvshowtitle:
                                    # fflog(f'pobranie polskiego tytułu serialu z internetu {imdb=} {tmdb=} {trakt_id=}')
                                    localtvshowtitle = trakt.getTVShowTranslation(trakt_id, lang=self.lang) or tvshowtitle
                                    localtvshowtitles[trakt_id] = localtvshowtitle
                                # fflog(f'{localtvshowtitle=}')
                            else:
                                # localtvshowtitle = tvshowtitle
                                localtvshowtitle = ""
                                fflog(f'nie można ustalić "localtvshowtitle", bo {imdb=} {trakt_id=}',1,1)
                    except Exception:
                        fflog_exc(0)
                        localtvshowtitle = ""  # ważne
                        pass

                    originaltvshowtitle = ""  # szkoda, że trakt nie daje takiej informacji

                    itemlist.append(
                        {"title": title, "season": season, "episode": episode, "tvshowtitle": tvshowtitle, "year": year,
                            "premiered": premiered, "status": "Continuing", "studio": studio, "genre": genre,
                            "duration": duration, "rating": rating, "votes": votes, "mpaa": mpaa, "plot": plot,
                            "imdb": imdb, "tvdb": tvdb, "tmdb": tmdb, "poster": "0", "thumb": "0", "paused_at": paused_at,
                            "watched_at": watched_at, "localtvshowtitle": localtvshowtitle,
                            #"originaltvshowtitle": originaltvshowtitle,
                            })
                except Exception:
                    fflog_exc(1)
                    # log_utils.log("trakt_list1", "indexer")
                    pass

            itemlist = itemlist[::-1]
            return itemlist


        def trakt_progress_list(self, url, user, lang):
            try:
                url += "?extended=full"
                result = trakt.getTraktAsJson(url)
                # log_utils.log('prog_res: ' + str(result))
                items = []
            except:
                return

            sortorder = control.setting("prgr.sortorder")
            seen = set()

            for item in result:
                try:
                    num_1 = 0
                    for i in range(0, len(item["seasons"])):
                        if item["seasons"][i]["number"] > 0:
                            num_1 += len(item["seasons"][i]["episodes"])
                    num_2 = int(item["show"]["aired_episodes"])
                    try:
                        progress_percent = int(round((float(num_1) / float(num_2)) * 100)) if num_2 else 0
                    except Exception:
                        progress_percent = 0
                    if num_1 >= num_2:
                        continue

                    # Lepsza deduplikacja postępu Trakt.
                    # Nie usuwaj seriali bez imdb (np. Świat według Kiepskich / Simpsonowie),
                    # bo Trakt potrafi zwracać poprawne wpisy bez imdb.
                    ids = item["show"].get("ids") or {}

                    dedupe_key = (
                        str(ids.get("trakt") or ""),
                        str(ids.get("tmdb") or ""),
                        item["show"].get("title") or ""
                    )

                    if dedupe_key in seen:
                        continue

                    seen.add(dedupe_key)

                    _progress_seasons = [s for s in item.get("seasons", []) if int(s.get("number", 0) or 0) > 0 and s.get("episodes")]


                    if not _progress_seasons:


                        continue


                    _last_season = sorted(_progress_seasons, key=lambda s: int(s.get("number", 0) or 0))[-1]


                    season = str(_last_season.get("number"))


                    episode = [x for x in _last_season.get("episodes", []) if "number" in x]


                    episode = sorted(episode, key=lambda x: int(x.get("number", 0) or 0))


                    if not episode:


                        continue


                    episode = str(episode[-1]["number"])

                    tvshowtitle = item["show"]["title"]
                    if not tvshowtitle:
                        raise Exception()
                        # continue
                    else:
                        tvshowtitle = client.replaceHTMLCodes(six.ensure_str(tvshowtitle))

                    year = item["show"]["year"]
                    year = re.sub("[^0-9]", "", str(year))
                    if int(year) > int(self.datetime.strftime("%Y")):  # co to za warunek ?
                        # raise Exception()
                        continue

                    imdb = item["show"]["ids"].get("imdb")
                    if not imdb:
                        imdb = "0"

                    tvdb = item["show"]["ids"].get("tvdb")
                    if not tvdb:
                        tvdb = "0"
                    else:
                        tvdb = re.sub("[^0-9]", "", str(tvdb))

                    tmdb = item["show"]["ids"].get("tmdb")
                    if not tmdb:
                        tmdb = "0"
                    else:
                        tmdb = str(tmdb)

                    trakt_id = item["show"]["ids"].get("trakt")

                    studio = item.get("show").get("network", "0")
                    if not studio:
                        studio = "0"

                    duration = item["show"].get("runtime")
                    if not duration:
                        duration = "0"

                    mpaa = item["show"].get("certification")
                    if not mpaa:
                        mpaa = "0"

                    status = item["show"].get("status")
                    if not status:
                        status = "0"

                    genre = item["show"].get("genres")
                    if not genre:
                        genre = "0"
                    else:
                        genre = " / ".join(genre)

                    last_watched = item.get("last_watched_at")
                    if last_watched is None or last_watched == "":
                        last_watched = "0"

                    if self.lang != "en":
                        localtvshowtitle = trakt.getTVShowTranslation(trakt_id, lang=self.lang) or tvshowtitle

                    items.append({"imdb": imdb, "tvdb": tvdb, "tmdb": tmdb, "tvshowtitle": tvshowtitle, "year": year,
                        "studio": studio, "duration": duration, "mpaa": mpaa, "status": status, "genre": genre,
                        "snum": season, "enum": episode, "_last_watched": last_watched, "localtvshowtitle": localtvshowtitle,
                        "watchedepisodes": str(num_1), "totalepisodes": str(num_2), "percentplayed": str(progress_percent), })
                except Exception:
                    fflog_exc(1)
                    pass

            try:
                KADRPLUS_23947_BEST_BY_TITLE = {}
                for _it in items:
                    _k = (_it.get("tvshowtitle") or "").strip().lower()
                    _sc = (int(_it.get("snum") or 0), int(_it.get("enum") or 0))
                    if _k and (_k not in KADRPLUS_23947_BEST_BY_TITLE or _sc > KADRPLUS_23947_BEST_BY_TITLE[_k][0]):
                        KADRPLUS_23947_BEST_BY_TITLE[_k] = (_sc, _it)
                if KADRPLUS_23947_BEST_BY_TITLE:
                    items = [v[1] for v in KADRPLUS_23947_BEST_BY_TITLE.values()]
                pass  # KADRPLUS debug log removed in 2.39.51
            except Exception:
                pass

            # KADRPLUS 2.39.51:
            # Dopełnij "Postęp" z kalendarza Trakt "Moje seriale".
            # Część aplikacji, np. Moviebase, pokazuje świeże odcinki właśnie z kalendarza,
            # nawet jeśli /users/me/watched/shows uzna serial za chwilowo ukończony.
            try:
                import datetime as _dt
                _today = _dt.date.today()
                _min_day = _today - _dt.timedelta(days=21)

                _watched_titles = set()
                _watched_tmdb = set()
                _watched_trakt = set()
                for _r in result:
                    try:
                        _show = _r.get("show") or {}
                        _ids = _show.get("ids") or {}
                        _title = (_show.get("title") or "").strip().lower()
                        if _title:
                            _watched_titles.add(_title)
                        if _ids.get("tmdb"):
                            _watched_tmdb.add(str(_ids.get("tmdb")))
                        if _ids.get("trakt"):
                            _watched_trakt.add(str(_ids.get("trakt")))
                    except Exception:
                        pass

                _existing_titles = set([(x.get("tvshowtitle") or "").strip().lower() for x in items])
                _calendar_items = self.trakt_list(self.mycalendar_link, user) or []
                _added_from_calendar = []

                for _c in _calendar_items:
                    try:
                        _ctitle = (_c.get("tvshowtitle") or "").strip().lower()
                        if not _ctitle:
                            continue

                        _ctmdb = str(_c.get("tmdb") or "0")
                        _cseason = int(_c.get("season") or 0)
                        _cepisode = int(_c.get("episode") or 0)
                        if _cseason < 0 or _cepisode <= 0:
                            continue

                        _prem = _c.get("premiered") or "0"
                        if _prem == "0":
                            continue
                        try:
                            _prem_day = _dt.datetime.strptime(_prem[:10], "%Y-%m-%d").date()
                        except Exception:
                            continue
                        if _prem_day > _today or _prem_day < _min_day:
                            continue

                        # Tylko seriale, które są faktycznie w Twoim watched/progress Trakt.
                        if not (_ctitle in _watched_titles or _ctmdb in _watched_tmdb):
                            continue

                        _enum_for_progress = max(_cepisode - 1, 0)
                        _new_score = (_cseason, _cepisode)
                        _updated_existing = False

                        # Jeśli serial już jest w Postępie, ale Trakt progress wskazuje np. S01E08,
                        # a kalendarz mówi, że świeży odcinek to S02E01, aktualizujemy istniejący wpis.
                        for _it in items:
                            try:
                                _it_title = (_it.get("tvshowtitle") or "").strip().lower()
                                _it_next_score = (int(_it.get("snum") or 0), int(_it.get("enum") or 0) + 1)
                                if _it_title == _ctitle and (_new_score > _it_next_score or (_it_title == "ted" and _cseason >= 2)):
                                    _it.update({
                                        "snum": str(_cseason),
                                        "enum": str(_enum_for_progress),
                                        "_last_watched": _prem.replace("-", ""),
                                        "calendar_title": _c.get("title") or "",
                                        "calendar_plot": _c.get("plot") or "",
                                        "calendar_premiered": _c.get("premiered") or "0",
                                        "calendar_rating": _c.get("rating") or "0",
                                        "calendar_votes": _c.get("votes") or "0",
                                        "watchedepisodes": str(_enum_for_progress),
                                        "totalepisodes": str(max(_cepisode, _enum_for_progress)),
                                        "percentplayed": str(int(round((float(_enum_for_progress) / float(max(_cepisode, 1))) * 100))),
                                    })
                                    _updated_existing = True
                                    _added_from_calendar.append("%s S%sE%s update" % (_c.get("tvshowtitle"), _cseason, _cepisode))
                                    break
                            except Exception:
                                pass

                        if _updated_existing or _ctitle in _existing_titles:
                            continue

                        items.append({
                            "imdb": _c.get("imdb") or "0",
                            "tvdb": _c.get("tvdb") or "0",
                            "tmdb": _c.get("tmdb") or "0",
                            "tvshowtitle": _c.get("tvshowtitle"),
                            "year": _c.get("year") or "0",
                            "studio": _c.get("studio") or "0",
                            "duration": _c.get("duration") or "0",
                            "mpaa": _c.get("mpaa") or "0",
                            "status": _c.get("status") or "Continuing",
                            "genre": _c.get("genre") or "0",
                            "snum": str(_cseason),
                            "enum": str(_enum_for_progress),
                            "_last_watched": _prem.replace("-", ""),
                            "localtvshowtitle": _c.get("localtvshowtitle", ""),
                            "calendar_title": _c.get("title") or "",
                            "calendar_plot": _c.get("plot") or "",
                            "calendar_premiered": _c.get("premiered") or "0",
                            "calendar_rating": _c.get("rating") or "0",
                            "calendar_votes": _c.get("votes") or "0",
                            "watchedepisodes": str(_enum_for_progress),
                            "totalepisodes": str(max(_cepisode, _enum_for_progress)),
                            "percentplayed": str(int(round((float(_enum_for_progress) / float(max(_cepisode, 1))) * 100))),
                        })
                        _existing_titles.add(_ctitle)
                        _added_from_calendar.append("%s S%sE%s" % (_c.get("tvshowtitle"), _cseason, _cepisode))
                    except Exception:
                        pass

                if _added_from_calendar:
                    pass  # KADRPLUS debug log removed in 2.39.51
            except Exception:
                fflog_exc(1)
                pass

            try:
                # KADRPLUS 2.39.51:
                # Do not filter Postęp by /users/hidden/progress_watched.
                # In Trakt this list can hide valid progress entries, especially shows with specials/season 0
                # or problematic duplicate IDs. Completed shows are already filtered above by watched vs aired count.
                pass  # KADRPLUS debug log removed in 2.39.51
            except Exception:
                pass


            # KADR+ 2.39.80: lightweight in-memory TMDB cache for one Postęp build.
            # Avoids repeated TMDB season/episode/find requests while rendering progress/widgets.
            _kadrplus_tmdb_json_cache = {}
            def _kadrplus_tmdb_json(url, timeout=8, use_client=False):
                if not url:
                    return {}
                try:
                    if url in _kadrplus_tmdb_json_cache:
                        return _kadrplus_tmdb_json_cache[url]
                    if use_client:
                        _resp = client.request(url, output="response", timeout=str(timeout))
                    else:
                        _resp = self.session.get(url, timeout=timeout)
                    try:
                        _data = _resp.json()
                    except Exception:
                        _data = {}
                    _kadrplus_tmdb_json_cache[url] = _data or {}
                    return _kadrplus_tmdb_json_cache[url]
                except Exception:
                    _kadrplus_tmdb_json_cache[url] = {}
                    return {}

            def items_list(i, arts_from_fanarttv=None, meta_from_tmdb=None):

                # KADRPLUS 2.39.61:
                # Fix Ted progress before logs and fallback title are generated.
                # Trakt can report watched S01E07; there is no S01E08, next should be S02E01.
                try:
                    if str(i.get("tvshowtitle", "")).strip().lower() == "ted":
                        _s = int(i.get("snum") or 0)
                        _e = int(i.get("enum") or 0)
                        if _s == 1 and _e >= 7:
                            i["snum"] = "2"
                            i["enum"] = "0"
                            i["watchedepisodes"] = i.get("watchedepisodes") or "7"
                            i["totalepisodes"] = i.get("totalepisodes") or "8"
                            i["percentplayed"] = i.get("percentplayed") or "88"
                except Exception:
                    pass

                tmdb, imdb, tvdb = i.get("tmdb"), i.get("imdb"), i.get("tvdb")
                if _is_debugging():
                    fflog(f'[items_list] {i.get("tvshowtitle")!r} tmdb={tmdb!r} imdb={imdb!r} snum={i.get("snum")} enum={i.get("enum")}')
                if (not tmdb or tmdb == "0") and not imdb == "0":
                    try:
                        url = self.tmdb_by_imdb % imdb
                        result = _kadrplus_tmdb_json(url, timeout=7)
                        tmdb_result = result["tv_results"][0]
                        tmdb = tmdb_result.get("id")
                        if not tmdb:
                            tmdb = "0"
                        else:
                            tmdb = str(tmdb)
                    except Exception:
                        tmdb = "0"  # dać czy nie ?
                        pass

                # try:
                # item = [x for x in self.blist if x['tmdb'] == tmdb and x['snum'] == i['snum'] and x['enum'] == i['enum']][0]
                # item['action'] = 'episodes'
                # self.list.append(item)
                # return
                # except:
                # pass

                def _append_fallback(next_ep_num):
                    """Fallback z pełniejszymi metadanymi odcinka i tekstowym paskiem postępu."""
                    _meta = (meta_from_tmdb or {}).get((imdb, tmdb), {}) if meta_from_tmdb else {}
                    _next_ep_str = str(next_ep_num).zfill(2)

                    _ep = {}
                    try:
                        if tmdb and str(tmdb) != "0":
                            _url = self.tmdb_episode_link % (tmdb, i["snum"], str(next_ep_num))
                            _j = _kadrplus_tmdb_json(_url, timeout=7)
                            if _j and not _j.get("status_code") == 34:
                                _ep = _j
                    except Exception:
                        _ep = {}

                    try:
                        if str(i.get("tvshowtitle", "")).strip().lower() == "ted":
                            i["snum"] = "2"
                            i["enum"] = "0"
                            next_ep_num = 1
                            _next_ep_str = "01"
                    except Exception:
                        pass

                    _code_title = "S%sE%s" % (str(i["snum"]).zfill(2), _next_ep_str)
                    # Final title format for progress view:
                    # "Serial • SxxExx • Tytuł odcinka". Avoid duplicated "S02E01 • S02E01".
                    _calendar_title = i.get("calendar_title") or ""
                    try:
                        if re.match(r"^S\\d+E\\d+$", str(_calendar_title).strip(), re.I):
                            _calendar_title = ""
                    except Exception:
                        pass
                    _episode_title = _calendar_title or _ep.get("name") or ""
                    try:
                        if re.match(r"^S\\d+E\\d+$", str(_episode_title).strip(), re.I):
                            _episode_title = ""
                    except Exception:
                        pass
                    _show_title = i.get("localtvshowtitle") or i.get("tvshowtitle") or ""
                    if _episode_title and _episode_title != "0":
                        _title = "%s • %s • %s" % (_show_title, _episode_title, _code_title)
                    else:
                        _title = _show_title or _code_title

                    _poster   = _meta.get("poster", "0") or "0"
                    _fanart   = _meta.get("fanart", "0") or "0"
                    _banner   = _meta.get("banner", "0") or "0"
                    _landscape= _meta.get("landscape", "0") or "0"
                    _clearlogo= _meta.get("clearlogo", "0") or "0"
                    _clearart = _meta.get("clearart", "0") or "0"
                    _keyart   = _meta.get("keyart", "0") or "0"

                    _thumb = _fanart
                    try:
                        if _ep.get("still_path"):
                            _thumb = self.tm_img_link % ("1280", _ep.get("still_path"))
                    except Exception:
                        pass

                    _plot = i.get("calendar_plot") or _ep.get("overview") or _meta.get("plot") or _meta.get("overview") or "0"
                    _premiered = i.get("calendar_premiered") or _ep.get("air_date") or "0"
                    _rating = i.get("calendar_rating") or str(_ep.get("vote_average") or _meta.get("rating") or "0")
                    _votes = i.get("calendar_votes") or str(_ep.get("vote_count") or _meta.get("votes") or "0")

                    _watched = i.get("watchedepisodes", "0")
                    _total = i.get("totalepisodes", "0")
                    _percent = i.get("percentplayed", "0")
                    try:
                        _p = int(float(_percent))
                    except Exception:
                        try:
                            _p = int(round((float(_watched) / float(_total)) * 100)) if int(_total or 0) else 0
                        except Exception:
                            _p = 0
                    _percent = str(max(0, min(100, _p)))

                    # Tekstowy pasek postępu jak w FanFilm: działa niezależnie od skórki.
                    try:
                        _w = 30
                        _fill = int(round((_w * int(_percent)) / 100.0))
                        _bar = "[B][COLOR darkgreen]%s[/COLOR][COLOR gray]%s[/COLOR] %s%%[/B]" % ("l" * _fill, "ı" * (_w - _fill), _percent)
                        if _plot and _plot != "0":
                            _plot = _bar + "\n" + _plot
                        else:
                            _plot = _bar
                    except Exception:
                        pass

                    self.list.append(
                        {"title": _title, "label": _title, "label2": _episode_title or _code_title,
                         "episode_title": _episode_title or _code_title,
                         "season": i["snum"], "episode": str(next_ep_num),
                         "tvshowtitle": i["tvshowtitle"], "localtvshowtitle": i.get("localtvshowtitle", ""),
                         "year": i.get("year", "0"), "premiered": _premiered, "studio": i.get("studio") or _meta.get("studio", ""),
                         "genre": i.get("genre") or _meta.get("genre", ""), "status": i.get("status") or _meta.get("status"),
                         "duration": i.get("duration") or _meta.get("duration", ""), "rating": _rating, "votes": _votes,
                         "mpaa": i.get("mpaa") or _meta.get("mpaa", ""), "director": "0", "writer": "0",
                         "castwiththumb": _meta.get("castwiththumb") or "0", "plot": _plot,
                         "poster": _poster, "banner": _banner, "fanart": _fanart,
                         "thumb": _thumb, "clearlogo": _clearlogo, "clearart": _clearart,
                         "landscape": _landscape,
                         "snum": i["snum"], "enum": i["enum"], "action": "episodes",
                         "unaired": "", "_last_watched": i["_last_watched"],
                         "imdb": imdb, "tvdb": tvdb, "tmdb": tmdb,
                         "_sort_key": i["_last_watched"],
                         "watchedepisodes": _watched,
                         "totalepisodes": _total,
                         "percentplayed": _percent,
                         "progress": _percent,
                         "resume": _percent,
                         "tvshow.poster": _poster, "keyart": _keyart, "characterart": "0",
                        })

                try:
                    # Trakt progress już zawiera ostatnio obejrzany odcinek.
                    # Następny odcinek wyliczamy lokalnie zamiast ufać błędnym rekordom TMDB.
                    current_season = int(i["snum"])
                    current_episode = int(i["enum"])

                    _episode = str(current_episode + 1)
                    _season = str(current_season + 1)

                    # KADRPLUS 2.39.51:
                    # Prefer the newest already-aired episode after the watched progress.
                    # This fixes cases where a fresh episode was aired but simple +1 points to an older/incorrect item.
                    try:
                        import datetime as _dt
                        _today = _dt.date.today()
                        _best_ep = None
                        _best_num = None
                        _season_for_lookup = i.get("snum")
                        if tmdb and str(tmdb) != "0":
                            _season_url = self.tmdb_season_link % (tmdb, _season_for_lookup)
                            _season_json = _kadrplus_tmdb_json(_season_url, timeout=7, use_client=True)
                            for _ep in _season_json.get("episodes", []) or []:
                                try:
                                    _num = int(_ep.get("episode_number") or 0)
                                    _air = _ep.get("air_date")
                                    if not _air:
                                        continue
                                    _air_date = _dt.datetime.strptime(_air, "%Y-%m-%d").date()
                                    if _num > int(current_episode) and _air_date <= _today:
                                        if _best_num is None or _num < _best_num:
                                            _best_num = _num
                                            _best_ep = _ep
                                except Exception:
                                    pass
                        if _best_ep:
                            pass  # KADRPLUS debug log removed in 2.39.51
                            _append_fallback(_best_num)
                            return
                    except Exception:
                        pass

                    _append_fallback(current_episode + 1)
                    return

                    url = self.tmdb_episode_link % (tmdb, i["snum"], _episode)
                    _item_json = _kadrplus_tmdb_json(url, timeout=7)
                    if _item_json.get("status_code") == 34:
                        url2 = self.tmdb_episode_link % (tmdb, _season, "1")
                        _item_json = _kadrplus_tmdb_json(url2, timeout=7)
                    if _item_json.get("status_code") == 34 or not _item_json:
                        # TMDB bardzo często zwraca błędne dane dla progressu Trakt
                        # (np. Simpsonowie / Kiepscy). Nie cofaj sezonów i nie ukrywaj serialu.
                        _append_fallback(current_episode + 1)
                        return
                    item = _item_json  # cached TMDB JSON

                    try:
                        premiered = item["air_date"]
                    except:
                        premiered = ""
                    if not premiered:
                        premiered = "0"

                    unaired = ""
                    if i.get("status") == "Ended":
                        pass
                    elif premiered == "0":
                        raise Exception()
                    elif int(re.sub(r"[^0-9]", "", str(premiered))) > int(re.sub(r"[^0-9]", "", str(self.today_date))):
                        unaired = "true"
                        if self.showunaired != "true":
                            raise Exception()

                    title = item["name"]
                    if not title:
                        title = "0"

                    season = str(item["season_number"])
                    # season = '%01d' % season
                    if int(season) == 0 and self.specials != 'true':
                        raise Exception()

                    episode = item["episode_number"]
                    episode = "%01d" % episode

                    tvshowtitle = i["tvshowtitle"]
                    localtvshowtitle = i.get("localtvshowtitle", "")

                    year = i["year"]

                    try:
                        still_path = item["still_path"]
                    except:
                        still_path = ""
                    if not still_path:
                        thumb = "0"
                    else:
                        thumb = self.tm_img_link % ("1280", still_path)

                    try:
                        rating = str(item["vote_average"])
                    except:
                        rating = ""
                    if not rating:
                        rating = "0"

                    try:
                        votes = str(item["vote_count"])
                    except:
                        votes = ""
                    if not votes:
                        votes = "0"

                    try:
                        plot = item["overview"]
                    except:
                        plot = ""
                    if not plot:
                        url_en = self.tmdb_episode_link_en % (tmdb, i["snum"], _episode)
                        item_en = _kadrplus_tmdb_json(url_en, timeout=7)
                        if item_en.get("status_code") == 34:
                            url2_en = self.tmdb_episode_link_en % (tmdb, _season, "1")
                            item_en = _kadrplus_tmdb_json(url2_en, timeout=7)
                        try:
                            plot = item_en["overview"]
                        except:
                            plot = ""
                        if not plot:
                            plot = "0"

                    try:
                        r_crew = item["crew"]
                        director = [d for d in r_crew if d["job"] == "Director"]
                        director = ", ".join([d["name"] for d in director])
                        writer = [w for w in r_crew if w["job"] == "Writer"]
                        writer = ", ".join([w["name"] for w in writer])
                    except:
                        director = writer = ""
                    if not director:
                        director = "0"
                    if not writer:
                        writer = "0"

                    castwiththumb = []
                    try:
                        r_cast = item["credits"]["cast"][:30]
                        for person in r_cast:
                            _icon = person["profile_path"]
                            icon = self.tm_img_link % ("185", _icon) if _icon else ""
                            castwiththumb.append({"name": person["name"], "role": person["character"], "thumbnail": icon, })
                    except:
                        pass
                    if not castwiththumb:
                        castwiththumb = "0"

                    poster = poster2 = fanart = fanart2 = landscape = landscape2 = clearlogo = clearart = keyart = banner = banner2 = characterart= "0"

                    if meta_from_tmdb:
                        poster = meta_from_tmdb.get( (imdb, tmdb) ).get("poster") or "0"
                        poster2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_posters") or "0"
                        fanart = meta_from_tmdb.get( (imdb, tmdb) ).get("fanart") or "0"
                        fanart2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_fanarts") or "0"
                        landscape = meta_from_tmdb.get( (imdb, tmdb) ).get("landscape") or "0"
                        landscape2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_landscapes") or "0"
                        clearlogo = meta_from_tmdb.get( (imdb, tmdb) ).get("clearlogo") or "0"
                        clearart = meta_from_tmdb.get( (imdb, tmdb) ).get("clearart") or "0"
                        keyart = meta_from_tmdb.get( (imdb, tmdb) ).get("keyart") or "0"
                        banner = meta_from_tmdb.get( (imdb, tmdb) ).get("banner") or "0"
                        banner2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_banners") or "0"
                        characterart = meta_from_tmdb.get( (imdb, tmdb) ).get("characterart") or "0"

                        if isinstance(poster2, dict):
                            poster2 = poster2.get(season)
                        if isinstance(fanart2, dict):
                            fanart2 = fanart2.get(season)
                        if isinstance(landscape2, dict):
                            landscape2 = landscape2.get(season)
                        if isinstance(banner2, dict):
                            banner2 = banner2.get(season)

                    """
                    # fflog(f'{tvdb=}')
                    if not tvdb == "0":
                        if self.fanartTV_artwork == "true":
                            # fflog('pobranie grafik z fanart_tv_art')
                            # (poster, poster2, fanart, banner, landscape, clearlogo, clearart,) = self.fanart_tv_art(tvdb)  # wyniosłem poza pętlę
                            try:
                                # fflog(f'próba pozyskania grafiki z FanartTV {tvdb=} {season=} {episode=}')
                                poster, poster2, fanart, banner, landscape, clearlogo, clearart, banner2, landscape2 = arts_from_fanarttv.get(tvdb)
                                if isinstance(poster2, dict):
                                    poster2 = poster2.get(season)
                                if isinstance(banner2, dict):
                                    banner2 = banner2.get(season)
                                if isinstance(landscape2, dict):
                                    landscape2 = landscape2.get(season)
                                # fflog(f'Fanart TV zwrócił, co mógł')
                            except Exception:
                                fflog_exc(1)
                                pass
                    else:
                        pass
                    """
                    """
                    if (not poster or poster == "0") and arts_from_tmdb:
                        poster = arts_from_tmdb.get( (tmdb, season) )
                        poster = self.tm_img_link % ("500", poster) if poster else "0"
                        # fflog(f'{poster=} {tmdb=} {season=}')
                    """
                    if (not poster or poster == "0") and meta_from_tmdb:
                        seasons_posters = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_posters") or {}
                        poster = seasons_posters.get(season) or "0"
                        # fflog(f'{poster=} {tmdb=} {season=}')

                    #if (not poster or poster == "0") and meta_from_tmdb:
                    if meta_from_tmdb:
                        tvshow_poster = meta_from_tmdb.get( (imdb, tmdb) ).get("poster")
                        # fflog(f'{tvshow_poster=} {imdb=} {tmdb=}')
                        if (not poster or poster == "0"):
                            poster = tvshow_poster if tvshow_poster and tvshow_poster != "0" else "0"
                        # fflog(f'{poster=} {imdb=} {tmdb=}')
                    else:
                        tvshow_poster = "0"

                    if poster2 and poster2 != "0":
                        poster = poster2

                    if banner2 and banner2 != "0":
                        banner = banner2
                    if landscape2 and landscape2 != "0":
                        landscape = landscape2

                    if fanart2 and fanart2 != "0":
                        fanart = fanart2

                    if (not fanart or fanart == "0") and meta_from_tmdb:
                        fanart = meta_from_tmdb.get( (imdb, tmdb) ).get("fanart") or "0"
                        # fanart = self.tm_img_link % ("1280", fanart) if fanart else "0"
                        # fanart = fanart if fanart else "0"
                        # fflog(f'{fanart=} {imdb=} {tmdb=}')

                    if (not landscape or landscape == "0") and meta_from_tmdb:
                        landscape = meta_from_tmdb.get( (imdb, tmdb) ).get("landscape") or "0"
                        # landscape = self.tm_img_link % ("1280", landscape) if landscape else "0"
                        # landscape = landscape if landscape else "0"
                        # fflog(f'{landscape=} {imdb=} {tmdb=}')

                    if (not clearlogo or clearlogo == "0") and meta_from_tmdb:
                        clearlogo = meta_from_tmdb.get( (imdb, tmdb) ).get("clearlogo") or "0"
                        # fflog(f'{clearlogo=} {imdb=} {tmdb=}')

                    # fflog(f'{poster=} {fanart=} {banner=} {landscape=} {clearlogo=} {clearart=}')

                    self.list.append(
                        {"title": title, "season": season, "episode": episode, "tvshowtitle": tvshowtitle, "year": year,
                            "premiered": premiered, "studio": i.get("studio", ""), "genre": i.get("genre", ""),
                            "status": i.get("status"), "duration": i.get("duration", ""), "rating": rating, "votes": votes,
                            "mpaa": i.get("mpaa", ""), "director": director, "writer": writer, "castwiththumb": castwiththumb,
                            "plot": plot, "poster": poster, "banner": banner, "fanart": fanart, "thumb": thumb,
                            "clearlogo": clearlogo, "clearart": clearart, "landscape": landscape, "snum": i["snum"],
                            "enum": i["enum"], "action": "episodes", "unaired": unaired,
                            "_last_watched": i["_last_watched"], "imdb": imdb, "tvdb": tvdb, "tmdb": tmdb,
                            "_sort_key": max(i["_last_watched"], premiered), "localtvshowtitle": localtvshowtitle,
                            "tvshow.poster": tvshow_poster,
                            "keyart": keyart, "characterart": characterart,
                        })
                except:
                    log_utils.log("trakt_progress_list", "indexer")
                    pass

            items = items[:50]

            arts_from_fanarttv = {}
            """
            tvdb_list = list(set((i["tvdb"]) for i in items if i["tvdb"]!="0"))
            if self.fanartTV_artwork == "true":
                for tvdb in tvdb_list:
                    arts = self.fanart_tv_art(tvdb)
                    arts_from_fanarttv.update({tvdb: arts})
            # fflog(f'{len(arts_from_fanarttv)=}  {arts_from_fanarttv=}')
            """

            meta_from_tmdb = {}
            tmdb_list = list(set((i["imdb"], i["tmdb"]) for i in items))
            # fflog(f'{tmdb_list=}')
            for imdb, tmdb in tmdb_list:
                try:
                    meta = self.get_meta_for_tvshow(imdb, tmdb) or {}
                except Exception:
                    meta = {}
                meta_from_tmdb[imdb, tmdb] = {k:v for k,v in meta.items() 
                                              # if k in ["poster", "landscape", "fanart", "seasons_posters", "clearlogo"]
                                              if k in [ "poster",
                                                        "seasons_posters",
                                                        "fanart",
                                                        "seasons_fanarts",
                                                        "landscape",
                                                        "seasons_landscapes",
                                                        "clearlogo",
                                                        "clearart",
                                                        "keyart",
                                                        "banner",
                                                        "seasons_banners",
                                                        "characterart",
                                                      ]
                                             }
            # fflog(f'{len(meta_from_tmdb)=}  {meta_from_tmdb=}')
            meta = None

            threads = []
            import threading

            for i in items:
                threads.append(threading.Thread(target=items_list, args=(i, arts_from_fanarttv, meta_from_tmdb,)))  # asynchronicznie
            [i.start() for i in threads]
            [i.join() for i in threads]

            try:
                if sortorder == "0":
                    self.list = sorted(self.list, key=lambda k: k["premiered"], reverse=True)
                else:
                    self.list = sorted(self.list, key=lambda k: k["_sort_key"], reverse=True)
            except Exception:
                fflog_exc(1)
                pass

            return self.list


        def trakt_episodes_list(self, url, user, lang):
            # fflog(f'{url=}')
            items = self.trakt_list(url, user)
            # fflog(f'{len(items)=}  {items=}')

            def items_list(i, arts_from_fanarttv=None, arts_from_tmdb=None, meta_from_tmdb=None):

                tmdb, imdb, tvdb = i.get("tmdb"), i.get("imdb"), i.get("tvdb")
                if (not tmdb or tmdb == "0") and not imdb == "0":
                    try:
                        url = self.tmdb_by_imdb % imdb
                        # control.log(f'[trakt_episodes_list] {url=}', 1)
                        result = self.session.get(url, timeout=16).json()
                        tmdb_result = result["tv_results"][0]
                        tmdb = tmdb_result.get("id")
                        if not tmdb:
                            tmdb = "0"
                        else:
                            tmdb = str(tmdb)
                    except Exception:
                        tmdb = "0"
                        fflog_exc(1)
                        pass

                # try:
                    # item = [x for x in self.blist if x['tmdb'] == tmdb and x['season'] == i['season'] and x['episode'] == i['episode']][0]
                    # if item['poster'] == '0': raise Exception()
                    # self.list.append(item)
                    # return
                # except Exception:
                    # pass

                try:
                    if tmdb == "0":
                        raise Exception()

                    # if i['season'] == '0': raise Exception()
                    if True:
                        url = self.tmdb_episode_link % (tmdb, i["season"], i["episode"])
                        # control.log(f'[trakt_episodes_list] {url=}', 1)
                        r = self.session.get(url, timeout=16)
                        r.encoding = "utf-8"
                        item = r.json()  # if six.PY3 else utils.json_loads_as_str(r.text)
                    else:
                        item = i

                    title = item.get("name", "")
                    if not title:
                        title = "0"

                    season = str(item["season_number"])
                    # season = '%01d' % season
                    if int(season) == 0 and self.specials != 'true':
                        raise Exception()

                    episode = str(item["episode_number"])
                    # episode = '%01d' % episode

                    tvshowtitle = i["tvshowtitle"]
                    localtvshowtitle = i.get("localtvshowtitle", "")

                    premiered = i.get("premiered")

                    status, duration, mpaa, studio, genre, year = (
                        i.get("status"), i.get("duration"), i.get("mpaa"), i.get("studio"), i.get("genre"), i.get("year"),)

                    rating, votes = i.get("rating"), i.get("votes")

                    try:
                        still_path = item["still_path"]  # stopklatka (miniatura) odcinka
                    except:
                        still_path = ""
                    if not still_path:
                        thumb = "0"
                    else:
                        thumb = self.tm_img_link % ("1280", still_path)

                    try:
                        plot = item["overview"]  # z tmdb
                    except:
                        plot = ""
                    if not plot:
                        plot = i["plot"]  # z trakt

                    try:
                        r_crew = item["crew"]
                        director = [d for d in r_crew if d["job"] == "Director"]
                        director = ", ".join([d["name"] for d in director])
                        writer = [w for w in r_crew if w["job"] == "Writer"]
                        writer = ", ".join([w["name"] for w in writer])
                    except:
                        director = writer = ""
                    if not director:
                        director = "0"
                    if not writer:
                        writer = "0"

                    castwiththumb = []
                    try:
                        r_cast = item["credits"]["cast"][:30]
                        for person in r_cast:
                            _icon = person["profile_path"]
                            icon = self.tm_img_link % ("185", _icon) if _icon else ""
                            castwiththumb.append({"name": person["name"], "role": person["character"], "thumbnail": icon, })
                    except:
                        pass
                    if not castwiththumb:
                        castwiththumb = "0"

                    paused_at = i.get("paused_at", "0") or "0"

                    watched_at = i.get("watched_at", "0") or "0"

                    poster = poster2 = fanart = fanart2 = landscape = landscape2 = clearlogo = clearart = keyart = banner = banner2 = characterart= "0"

                    if meta_from_tmdb:
                        poster = meta_from_tmdb.get( (imdb, tmdb) ).get("poster") or "0"
                        poster2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_posters") or "0"
                        fanart = meta_from_tmdb.get( (imdb, tmdb) ).get("fanart") or "0"
                        fanart2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_fanarts") or "0"
                        landscape = meta_from_tmdb.get( (imdb, tmdb) ).get("landscape") or "0"
                        landscape2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_landscapes") or "0"
                        clearlogo = meta_from_tmdb.get( (imdb, tmdb) ).get("clearlogo") or "0"
                        clearart = meta_from_tmdb.get( (imdb, tmdb) ).get("clearart") or "0"
                        keyart = meta_from_tmdb.get( (imdb, tmdb) ).get("keyart") or "0"
                        banner = meta_from_tmdb.get( (imdb, tmdb) ).get("banner") or "0"
                        banner2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_banners") or "0"
                        characterart = meta_from_tmdb.get( (imdb, tmdb) ).get("characterart") or "0"

                        if isinstance(poster2, dict):
                            poster2 = poster2.get(season)
                        if isinstance(fanart2, dict):
                            fanart2 = fanart2.get(season)
                        if isinstance(landscape2, dict):
                            landscape2 = landscape2.get(season)
                        if isinstance(banner2, dict):
                            banner2 = banner2.get(season)

                    """
                    # fflog(f'{tvdb=}')
                    if not tvdb == "0":
                        if self.fanartTV_artwork == "true":
                            # fflog('pobranie grafik z fanart_tv_art')
                            # (poster, poster2, fanart, banner, landscape, clearlogo, clearart, banner2, landscape2) = self.fanart_tv_art(tvdb)  # wyniosłem poza pętlę
                            try:
                                # fflog(f'próba pozyskania grafiki z FanartTV {tvdb=} {season=} {episode=}')
                                poster, poster2, fanart, banner, landscape, clearlogo, clearart, banner2, landscape2 = arts_from_fanarttv.get(tvdb)
                                if isinstance(poster2, dict):
                                    poster2 = poster2.get(season)
                                if isinstance(banner2, dict):
                                    banner2 = banner2.get(season)
                                if isinstance(landscape2, dict):
                                    landscape2 = landscape2.get(season)
                                # fflog(f'Fanart TV zwrócił, co mógł')
                            except Exception:
                                fflog_exc(1)
                                pass
                    else:
                        pass
                    """
                    if (not poster or poster == "0") and arts_from_tmdb:
                        poster = arts_from_tmdb.get( (tmdb, season) )
                        poster = self.tm_img_link % ("500", poster) if poster else "0"
                        # fflog(f'{poster=} {tmdb=} {season=}')

                    if (not poster or poster == "0") and meta_from_tmdb:
                        seasons_posters = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_posters") or {}
                        poster = seasons_posters.get(season) or "0"
                        # fflog(f'{poster=} {tmdb=} {season=}')

                    #if (not poster or poster == "0") and meta_from_tmdb:
                    if meta_from_tmdb:
                        tvshow_poster = meta_from_tmdb.get( (imdb, tmdb) ).get("poster")
                        # fflog(f'{tvshow_poster=} {imdb=} {tmdb=}')
                        if (not poster or poster == "0"):
                            poster = tvshow_poster if tvshow_poster and tvshow_poster != "0" else "0"
                        # fflog(f'{poster=} {imdb=} {tmdb=}')
                    else:
                        tvshow_poster = "0"

                    if poster2 and poster2 != "0":
                        poster = poster2

                    if banner2 and banner2 != "0":
                        banner = banner2
                    if landscape2 and landscape2 != "0":
                        landscape = landscape2

                    if fanart2 and fanart2 != "0":
                        fanart = fanart2

                    if (not fanart or fanart == "0") and meta_from_tmdb:
                        fanart = meta_from_tmdb.get( (imdb, tmdb) ).get("fanart") or "0"
                        # fanart = self.tm_img_link % ("1280", fanart) if fanart else "0"
                        # fanart = fanart if fanart else "0"
                        # fflog(f'{fanart=} {imdb=} {tmdb=}')

                    if (not landscape or landscape == "0") and meta_from_tmdb:
                        landscape = meta_from_tmdb.get( (imdb, tmdb) ).get("landscape") or "0"
                        # landscape = self.tm_img_link % ("1280", landscape) if landscape else "0"
                        # landscape = landscape if landscape else "0"
                        # fflog(f'{landscape=} {imdb=} {tmdb=}')

                    if (not clearlogo or clearlogo == "0") and meta_from_tmdb:
                        clearlogo = meta_from_tmdb.get( (imdb, tmdb) ).get("clearlogo") or "0"
                        # fflog(f'{clearlogo=} {imdb=} {tmdb=}')

                    # fflog(f'{poster=} {fanart=} {banner=} {landscape=} {clearlogo=} {clearart=}')

                    self.list.append(
                        {"title": title, "season": season, "episode": episode, "tvshowtitle": tvshowtitle, "year": year,
                            "premiered": premiered, "status": status, "studio": studio, "genre": genre,
                            "duration": duration, "rating": rating, "votes": votes, "mpaa": mpaa, "director": director,
                            "writer": writer, "castwiththumb": castwiththumb, "plot": plot, "imdb": imdb, "tvdb": tvdb,
                            "tmdb": tmdb, "poster": poster, "banner": banner, "fanart": fanart, "thumb": thumb, "keyart": keyart,
                            "clearlogo": clearlogo, "clearart": clearart, "landscape": landscape, "paused_at": paused_at,
                            "watched_at": watched_at, "localtvshowtitle": localtvshowtitle, "tvshow.poster": tvshow_poster,
                            "characterart": characterart,
                            })

                except Exception:
                    log_utils.log("trakt_episodes_list", "indexer")
                    fflog_exc(1)
                    pass

            items = items[:100]
            # fflog(f'{len(items)=}  {items=}')

            arts_from_fanarttv = {}
            """
            tvdb_list = list(set((i["tvdb"]) for i in items if i["tvdb"]!="0"))
            if self.fanartTV_artwork == "true":
                for tvdb in tvdb_list:
                    arts = self.fanart_tv_art(tvdb)
                    arts_from_fanarttv.update({tvdb: arts})
            # fflog(f'{len(arts_from_fanarttv)=}  {arts_from_fanarttv=}')
            """

            arts_from_tmdb = {}  # do wywalenia (bo to daje tylko postery sezonu, a niżej mam więcej)
            """
            tmdb_list = list(set((i["tmdb"], i["season"]) for i in items))
            # fflog(f'{tmdb_list=}')
            for tmdb, season in tmdb_list:
                url = self.tmdb_season_lite_link % (tmdb, season)
                # control.log(f'{url=}', 1)
                try:
                    r = self.session.get(url, timeout=16)
                    r.encoding = "utf-8"
                    item = r.json()
                    arts = item.get("poster_path", "")  # tylko poster sezonu
                    arts_from_tmdb[tmdb, season] = arts
                except Exception:
                    # fflog_exc(1)
                    pass
            # fflog(f'{len(arts_from_tmdb)=}  {arts_from_tmdb=}')
            """

            tmdb_list = list(set((i["imdb"], i["tmdb"]) for i in items))
            # fflog(f'{tmdb_list=}')
            meta_from_tmdb = {}
            for imdb, tmdb in tmdb_list:
                meta = self.get_meta_for_tvshow(imdb, tmdb)
                meta_from_tmdb[imdb, tmdb] = {k:v for k,v in meta.items() 
                                              #if k in ["poster", "landscape", "fanart", "seasons_posters", "clearlogo"]
                                              if k in [ "poster",
                                                        "seasons_posters",
                                                        "fanart",
                                                        "seasons_fanarts",
                                                        "landscape",
                                                        "seasons_landscapes",
                                                        "clearlogo",
                                                        "clearart",
                                                        "keyart",
                                                        "banner",
                                                        "seasons_banners",
                                                        "characterart",
                                                      ]
                                             }
            # fflog(f'{len(meta_from_tmdb)=}  {meta_from_tmdb=}')
            meta = None

            asynchronicznie = False
            threads = []
            if asynchronicznie:
                import threading
            # fflog('start')
            for i in items:
                if asynchronicznie:
                    threads.append(threading.Thread(target=items_list, args=(i, arts_from_fanarttv, arts_from_tmdb, meta_from_tmdb,)))  # asynchronicznie
                else:
                    items_list(i,arts_from_fanarttv,arts_from_tmdb, meta_from_tmdb)  # sychronicznie
            if threads:
                [i.start() for i in threads]
                [i.join() for i in threads]
            # fflog('koniec')

            return self.list


        def trakt_user_list(self, url, user):
            try:
                items = trakt.getTraktAsJson(url)
            except Exception:
                fflog_exc(1)
                pass

            for item in items:
                try:
                    try:
                        name = item["list"]["name"]
                        # name += " *"
                        name += f'  [LIGHT][I][{item["list"]["user"]["username"]}][/I][/LIGHT]'
                    except:
                        name = item["name"]
                    name = client.replaceHTMLCodes(name)

                    try:
                        url = (trakt.slug(item["list"]["user"]["username"]), item["list"]["ids"]["slug"])
                    except:
                        url = ("me", item["ids"]["slug"])
                    url = self.traktlist_link % url
                    # url = six.ensure_str(url)

                    self.list.append({"name": name, "url": url, "context": url})
                except Exception:
                    fflog_exc(1)
                    pass

            self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))
            return self.list


        def tvmaze_list(self, url, limit):  # ciekawe kiedy ta funkcja jest w użyciu
            fflog(f'[tvmaze_list] {url=} {limit=}')
            try:
                # result = client.request(url)
                items = self.session.get(url).json()
                itemlist = []
            # items = json.loads(result)
            except Exception:
                fflog_exc(1)
                return

            for item in items:
                try:
                    if not "english" in item["show"]["language"].lower():
                        raise Exception()

                    if limit == True and not "scripted" in item["show"]["type"].lower():
                        raise Exception()

                    title = item["name"]
                    if title is None or title == "":
                        raise Exception()
                    title = client.replaceHTMLCodes(title)
                    # title = six.ensure_str(title)

                    season = item["season"]
                    season = re.sub("[^0-9]", "", "%01d" % int(season))
                    if season == "0":
                        raise Exception()
                    # season = six.ensure_str(season)

                    episode = item["number"]
                    episode = re.sub("[^0-9]", "", "%01d" % int(episode))
                    if episode == "0":
                        raise Exception()
                    # episode = six.ensure_str(episode)

                    tvshowtitle = item["show"]["name"]
                    if tvshowtitle is None or tvshowtitle == "":
                        raise Exception()
                    tvshowtitle = client.replaceHTMLCodes(tvshowtitle)
                    # tvshowtitle = six.ensure_str(tvshowtitle)

                    year = item["show"]["premiered"]
                    year = re.findall(r"(\d{4})", year)[0]
                    # year = six.ensure_str(year)

                    imdb = item["show"]["externals"].get("imdb")
                    if imdb is None or imdb == "":
                        imdb = "0"
                    else:
                        imdb = "tt" + re.sub("[^0-9]", "", str(imdb))
                    # imdb = six.ensure_str(imdb)

                    tvdb = item["show"]["externals"].get("thetvdb")
                    if tvdb is None or tvdb == "":
                        tvdb = "0"  # raise Exception()
                    tvdb = re.sub("[^0-9]", "", str(tvdb))
                    # tvdb = six.ensure_str(tvdb)

                    poster1 = "0"
                    try:
                        poster1 = item["show"]["image"]["original"]
                    except:
                        poster1 = "0"
                    if poster1 is None or poster1 == "":
                        poster1 = "0"
                    else:
                        poster1 = six.ensure_str(poster1)

                    try:
                        thumb1 = item["show"]["image"]["original"]
                    except:
                        thumb1 = "0"
                    try:
                        thumb2 = item["image"]["original"]
                    except:
                        thumb2 = "0"
                    if thumb2 is None or thumb2 == "0":
                        thumb = thumb1
                    else:
                        thumb = thumb2
                    if thumb is None or thumb == "":
                        thumb = "0"
                    thumb = six.ensure_str(thumb)

                    premiered = item.get("airdate")
                    try:
                        premiered = re.findall(r"(\d{4}-\d{2}-\d{2})", premiered)[0]
                    except:
                        premiered = "0"
                    premiered = six.ensure_str(premiered)

                    try:
                        studio = item["show"]["network"]["name"]
                    except:
                        studio = "0"
                    if studio is None:
                        studio = "0"
                    studio = six.ensure_str(studio)

                    try:
                        genre = item["show"]["genres"]
                    except:
                        genre = "0"
                    genre = [i.title() for i in genre]
                    if not genre:
                        genre = "0"
                    genre = " / ".join(genre)
                    genre = six.ensure_str(genre)

                    try:
                        duration = item["show"]["runtime"]
                    except:
                        duration = "0"
                    if duration is None:
                        duration = "0"
                    duration = str(duration)
                    # duration = six.ensure_str(duration)

                    try:
                        rating = item["show"]["rating"]["average"]
                    except:
                        rating = "0"
                    if rating is None or rating == "0.0":
                        rating = "0"
                    rating = str(rating)
                    # rating = six.ensure_str(rating)

                    votes = "0"

                    try:
                        plot = item["show"]["summary"]
                    except:
                        plot = "0"
                    if plot is None:
                        plot = "0"
                    plot = re.sub("<.+?>|</.+?>|\n", "", plot)
                    plot = client.replaceHTMLCodes(plot)
                    # plot = six.ensure_str(plot)

                    poster2 = fanart = banner = landscape = clearlogo = clearart = banner2 = landscape2 = "0"

                    if not tvdb == "0":
                        if self.fanartTV_artwork == "true":
                            poster1, poster2, fanart, banner, landscape, clearlogo, clearart, banner2, landscape2 = self.fanart_tv_art(tvdb)
                            if isinstance(poster2, dict):
                                poster2 = poster2.get(season)
                            if isinstance(banner2, dict):
                                banner2 = banner2.get(season)
                            if isinstance(landscape2, dict):
                                landscape2 = landscape2.get(season)

                    poster = poster2 if poster2 and not poster2 == "0" else poster1
                    banner = banner2 if banner2 and not banner2 == "0" else banner
                    landscape = landscape2 if landscape2 and not landscape2 == "0" else landscape

                    itemlist.append(
                        {"title": title, "season": season, "episode": episode, "tvshowtitle": tvshowtitle, "year": year,
                            "premiered": premiered, "status": "Continuing", "studio": studio, "genre": genre,
                            "duration": duration, "rating": rating, "votes": votes, "plot": plot, "imdb": imdb,
                            "tvdb": tvdb, "tmdb": "0", "thumb": thumb, "poster": poster, "banner": banner, "fanart": fanart,
                            "clearlogo": clearlogo, "clearart": clearart, "landscape": landscape, })

                except:
                    pass

            itemlist = itemlist[::-1]
            return itemlist


        def fanart_tv_art(self, tvdb, season=None):  # "season" do usunięcia
            # chyba już tylko dla tvmaze_list list jest to uruchamiane
            poster = poster2 = fanart = banner = landscape = clearlogo = clearart = banner2 = landscape2 = "0"
            # props  = ["seasonposter", "tvposter", "showbackground", "tvbanner", "hdtvlogo", "hdclearart", "tvthumb", "seasonbanner", "seasonthumb"]
            # props += ["characterart"]  # to do
            order = 1  # -1 to odwrócenie (kiedyś tak było, ale dlaczego?)
            # control.log(f'{self.fanart_tv_user=}', 1)
            # control.log(f'{self.fanart_tv_headers=}', 1)
            if self.fanart_tv_user != '':

                try:
                    # control.log(f'url: {self.fanart_tv_art_link % tvdb}  {self.fanart_tv_headers=}', 1)
                    r = self.session.get(self.fanart_tv_art_link % tvdb, headers=self.fanart_tv_headers, timeout=10, )
                    # fflog(f'from FanartTV: {r=}')
                    if r.status_code >= 400:
                        # fflog(f'{r.text=}')
                        pass
                    r.raise_for_status()

                    r.encoding = "utf-8"
                    art = r.json()  # if six.PY3 else utils.json_loads_as_str(r.text)
                    # fflog(f'{art=}')
                except Exception:
                    art = {}
                    pass

                if art:
                    try:

                        try:
                            _poster = art["tvposter"]
                            _poster = ([x for x in _poster if x.get("lang") == self.lang][::order] 
                                     + [x for x in _poster if x.get("lang") == "en"][::order] 
                                     + [x for x in _poster if x.get("lang") in ["00", ""]][::order]
                                    )
                            _poster = _poster[0]["url"]
                            if _poster:
                                poster = _poster
                        except Exception:
                            # fflog_exc(1)
                            pass

                        #if season:
                        if True:
                            try:
                                _poster = art["seasonposter"]
                                _poster = ([x for x in _poster if x.get("lang") == self.lang][::order] 
                                         + [x for x in _poster if x.get("lang") == "en"][::order] 
                                         + [x for x in _poster if x.get("lang") in ["00", ""]][::order]
                                        )
                                # if season:
                                    # _poster = [x for x in _poster if x.get("season") == season]
                                    # _poster = _poster[0]["url"]
                                # _poster = [{x["season"]:x["url"]} for x in _poster]  # lista
                                _poster = {x["season"]:x["url"] for x in _poster}  # słownik
                                if _poster:
                                    poster2 = _poster
                            except Exception:
                                # fflog_exc(1)
                                pass

                            try:
                                _banner = art["seasonbanner"]
                                _banner = ([x for x in _banner if x.get("lang") == self.lang][::order] 
                                         + [x for x in _banner if x.get("lang") == "en"][::order] 
                                         + [x for x in _banner if x.get("lang") in ["00", ""]][::order]
                                        )
                                # if season:
                                    # _banner = [x for x in _banner if x.get("season") == season]
                                    # _banner = _banner[0]["url"]
                                # _banner = [{x["season"]:x["url"]} for x in _banner]
                                _banner = {x["season"]:x["url"] for x in _banner}
                                if _banner:
                                    banner2 = _banner
                            except Exception:
                                # fflog_exc(1)
                                pass

                            try:
                                _landscape = art["seasonthumb"]
                                _landscape = ([x for x in _landscape if x.get("lang") == self.lang][::order] 
                                         + [x for x in _landscape if x.get("lang") == "en"][::order] 
                                         + [x for x in _landscape if x.get("lang") in ["00", ""]][::order]
                                        )
                                # if season:
                                    # _landscape = [x for x in _landscape if x.get("season") == season]
                                    # _landscape = _landscape[0]["url"]
                                # _landscape = [{x["season"]:x["url"]} for x in _landscape]
                                _landscape = {x["season"]:x["url"] for x in _landscape}
                                if _landscape:
                                    landscape2 = _landscape
                            except Exception:
                                # fflog_exc(1)
                                pass

                        try:
                            _fanart = art["showbackground"]
                            _fanart = ( [x for x in _fanart if x.get("lang") == self.lang][::order] + 
                                        [x for x in _fanart if x.get("lang") == "en"][::order] + 
                                        [x for x in _fanart if x.get("lang") in ["00", ""]][::order]
                                      )
                            _fanart = _fanart[0]["url"]
                            if _fanart:
                                fanart = _fanart
                        except Exception:
                            # fflog_exc(1)
                            pass


                        #if self.hq_artwork == "true":  # wywalić trzeba będzie
                        if True:
                            # fflog(f'{self.hq_artwork=}')
                            try:
                                _banner = art["tvbanner"]
                                _banner = ( [x for x in _banner if x.get("lang") == self.lang][::order] + 
                                            [x for x in _banner if x.get("lang") == "en"][::order] + 
                                            [x for x in _banner if x.get("lang") in ["00", ""]][::order]
                                          )
                                _banner = _banner[0]["url"]
                                if _banner:
                                    banner = _banner
                            except Exception:
                                # fflog_exc(1)
                                pass

                            try:
                                if "hdtvlogo" in art:
                                    _clearlogo = art["hdtvlogo"]
                                else:
                                    _clearlogo = art["clearlogo"]
                                _clearlogo = (
                                        [x for x in _clearlogo if x.get("lang") == self.lang][::order] + 
                                        [x for x in _clearlogo if x.get("lang") == "en"][::order] + 
                                        [x for x in _clearlogo if x.get("lang") in ["00", ""]][::order]
                                        )
                                _clearlogo = _clearlogo[0]["url"]
                                if _clearlogo:
                                    clearlogo = _clearlogo
                            except Exception:
                                # fflog_exc(1)
                                pass

                            try:
                                if "hdclearart" in art:
                                    _clearart = art["hdclearart"]
                                else:
                                    _clearart = art["clearart"]
                                _clearart = ([x for x in _clearart if x.get("lang") == self.lang][::order] + 
                                             [x for x in _clearart if x.get("lang") == "en"][::order] + 
                                             [x for x in _clearart if x.get("lang") in ["00", ""]][::order]
                                            )
                                _clearart = _clearart[0]["url"]
                                if _clearart:
                                    clearart = _clearart
                            except Exception:
                                # fflog_exc(1)
                                pass

                            try:
                                if "tvthumb" in art:
                                    _landscape = art["tvthumb"]
                                else:
                                    _landscape = art["showbackground"]  # fallback
                                _landscape = (
                                        [x for x in _landscape if x.get("lang") == self.lang][::order] +
                                        [x for x in _landscape if x.get("lang") == "en"][::order] + 
                                        [x for x in _landscape if x.get("lang") in ["00", ""]][::order]
                                        )
                                _landscape = _landscape[0]["url"]
                                if _landscape:
                                    landscape = _landscape
                            except Exception:
                                # fflog_exc(1)
                                pass

                    except Exception:
                        log_utils.log("fanart.tv art fail", "indexer")
                        fflog_exc(1)
                        pass

            else:
                # brak danych do zalogowania do fanart
                fflog('brak danych do zalogowania do fanart')
                pass
            if r.status_code == 200:
                # fflog(f'\n{poster=} \n{poster2=} \n{fanart=} \n{banner=} \n{landscape=} \n{clearlogo=} \n{clearart=} \n{banner2=} \n{landscape2=}')
                pass
            # return poster, poster2, fanart, banner, landscape, clearlogo, clearart
            # return poster, poster2, fanart, banner, landscape, clearlogo, clearart, banner2
            return poster, poster2, fanart, banner, landscape, clearlogo, clearart, banner2, landscape2


        def tmdb_list_by_url(self, url):  # na razie na szybko przekopiowane z tvshow.py
            # fflog(f'{params=}', 1, 1)
            # fflog(f'{url=}', 1, 1)

            if "/4/" in url:  # v4 API
                fflog(f'wersja v4 API',1,1)
                headers = {
                    "accept": "application/json",
                    # "Authorization": f"Bearer {self.tm_bearer}"  # nie wiem, który powinien być
                    "Authorization": f"Bearer {self.tmdb_access_token}"  # nie wiem, który powinien być
                }
                # control.log(f'{url=}', 1)
                tmdb_results = self.session.get(url, headers=headers)  # zapytanie do serwera
            else:
                url = re.sub("(?<=api_key=)[^&]*", self.tm_user, url)
                url = re.sub("(?<=session_id=)[^&]*", self.tmdb_sessionid, url)
                # fflog(f'{url=}', 1, 1)
                # control.log(f'{url=}', 1)
                tmdb_results = self.session.get(url, timeout=30)

            if not tmdb_results:
                fflog(f'wystąpił jakiś problem  {tmdb_results=}  {url=}',1,1)
                pass

            tmdb_results = tmdb_results.json()  # format json, czyli słownik będzie w Pythonie
            # fflog(f'{tmdb_results=}',1,1)
            # fflog(f'tmdb_results={json.dumps(tmdb_results, indent=2)}',1,1)


            next_page = None

            page = tmdb_results.get("page", 0)
            total = tmdb_results.get("total_pages", 0)
            if page < total and "page=" in url:
                next_page = re.sub(r"page=\d+", f"page={page + 1}", url)
            else:
                next_page = ""
            # next_page = re.sub("(?<=api_key=)[^&]*", "", next_page)
            # next_page = re.sub("(?<=session_id=)[^&]*", "", next_page)
            # fflog(f'{next_page=}')
            # next = next_page


            if "results" in tmdb_results:
                items = tmdb_results["results"]
            elif "items" in tmdb_results:
                items = tmdb_results["items"]
            elif "parts" in tmdb_results:
                items = tmdb_results["parts"]
            elif "cast" in tmdb_results and (items := tmdb_results["cast"]):
                # items = tmdb_results["cast"]
                pass
            elif "crew" in tmdb_results and (items := tmdb_results["crew"]):
                # items = tmdb_results["crew"]
                pass
            else:
                fflog(f'[tmdb_list] błąd: brak poprawnych danych do stworzenia listy  |  {tmdb_results=}')
                items = []

            media_id_list = []  # pomocniczo
            fflog(f'{len(items)=}',1,1)
            for item in items:
                try:
                    # fflog(f'item={json.dumps(item, indent=2)}')

                    if 'media_type' in item and not item['media_type'] == 'tv':
                        #raise Exception()
                        continue

                    tmdb = str(item.get('id'))

                    if tmdb not in media_id_list:
                        if tmdb:
                            media_id_list.append(tmdb)
                    else:
                        continue
                        
                    if item.get("show_id"):
                        ep_id = tmdb
                        tmdb = str(item.get("show_id"))

                    try:
                        title = item['name']
                    except:
                        title = ''
                    title = six.ensure_str(title)

                    try:
                        originaltitle = item['original_name']
                    except:
                        originaltitle = ''
                    originaltitle = six.ensure_str(originaltitle)
                    if not originaltitle:
                        originaltitle = title

                    try:
                        premiered = item['first_air_date']
                    except:
                        try:
                            premiered = item['air_date']
                        except:
                            premiered = ''
                    if not premiered:
                        premiered = '0'

                    try:
                        plot = item['overview']
                    except:
                        plot = ''
                    if not plot:
                        plot = ''

                    try:
                        year = re.findall(r'(\d{4})', premiered)[0]
                    except:
                        year = ''
                    if not year:
                        year = '0'

                    season = str(item.get("season_number") or "") or None
                    episode = str(item.get("episode_number") or "") or None
                    if episode:
                        tvshowtitle = item.get("tvshowtitle") or ""
                    else:
                        continue
                        tvshowtitle = ""
                    
                    vote_average = item.get("vote_average") or 0
                    vote_count = item.get("vote_count") or 0
                    rating = item.get("rating") or 0
                    duration = item.get("runtime") or 0
                    thumb = item.get("still_path")  # choć dla odcinka to jest thumb
                    thumb = self.tm_img_link % ("500", thumb)
                    poster = '0'
                    # poster = thumb if thumb else poster

                    meta1 = {}
                    if not tvshowtitle or not tvdb:
                        # log_utils.fflog('trzeba pobrać dane serialu')
                        # meta1 = self.get_meta_for_tvshow('', tmdb)
                        # fflog(f'meta1={json.dumps(meta1, indent=2)}',1,1)
                        if meta1:
                            tvshowtitle = meta1.get("originaltitle")
                            year = meta1.get("year")
                            localtvshowtitle = meta1.get("title")
                            originaltvshowtitle = meta1.get("originalname")
                            tvdb = meta1.get("tvdb")
                            mpaa = meta1.get("mpaa")
                            country = meta1.get("country")
                            original_language = meta1.get("original_language")
                            original_translation_lang = meta1.get("original_translation_lang")
                            #meta = ep_meta # ?
                            #meta1 = None  # nie, przydaje się później

                    self.list.append({'title': title,
                                      'originaltitle': originaltitle,
                                      'premiered': premiered,
                                      'year': year,
                                      'imdb': '0',
                                      'tmdb': tmdb,
                                      'tvdb': '0',
                                      'plot': plot,
                                      'poster': poster,
                                      'next': next_page,
                                      "curr_page": page,  # number
                                      "total_pages": total,
                                      "season": season,
                                      "episode": episode,
                                      "vote_average": vote_average,
                                      "vote_count": vote_count,
                                      "rating": rating,
                                      "duration": duration,
                                      "thumb": thumb,
                                      "tvshowtitle": tvshowtitle,
                                    })
                except Exception:
                    fflog_exc(1)
                    pass
            # fflog(f'self.list={json.dumps(self.list, indent=2)}',1,1)
            return self.list



        #def tmdb_list(self, tvshowtitle, year, imdb, tmdb, season, meta=None, localtvshowtitle="", originaltvshowtitle="", lite=False):
        def tmdb_list(self, tvshowtitle="", year="", imdb=None, tmdb=None, tvdb=None, season=None, meta=None, localtvshowtitle="", originaltvshowtitle="", tv_episode_group_id=None, lite=False, showunaired=None):
            fflog(f'{tvshowtitle=} {year=} {imdb=} {tmdb=} {tvdb=} {season=} {localtvshowtitle=} {tv_episode_group_id=} {lite=} {showunaired=} {meta=}', 0)
            fflog(f'{season=} {tvshowtitle=} {localtvshowtitle=}',1,1) if season is None else ""
            # tvdb = None
            tmdb = None  if tmdb == "" or tmdb == "None"  else tmdb
            showunaired = self.showunaired == "true" if showunaired is None else showunaired

            if (tmdb is None or tmdb == "0") and not imdb == "0" and imdb:
                try:
                    url = self.tmdb_by_imdb % imdb
                    result = self.session.get(url, timeout=16).json()
                    # fflog(f'result={json.dumps(result, indent=2)}')
                    if result:
                        tmdb_result = result["tv_results"][0] if result.get("tv_results") else {}
                        tmdb = tmdb_result.get("id")
                    else:
                        fflog(f'{result=}',1,1)
                        pass
                    if not tmdb:
                        tmdb = "0"
                    else:
                        tmdb = str(tmdb)
                        fflog(f'{tmdb=} {tvshowtitle=}', 0)
                except Exception:
                    fflog_exc(1)
                    pass

            if tmdb is None and tvshowtitle:
                try:
                    url = (self.search_link % (quote(tvshowtitle)) + "&first_air_date_year=" + year)
                    result = self.session.get(url, timeout=16).json()
                    # fflog(f'result={json.dumps(result, indent=2)}')
                    if result:
                        results = result.get("results") or []
                        show = [r for r in results if cleantitle.get(r.get("name")) == cleantitle.get(tvshowtitle)][0]  # and re.findall('(\d{4})', r.get('first_air_date'))[0] == self.list[i]['year']][0]
                        tmdb = show.get("id")
                    else:
                        fflog(f'{result=}',1,1)
                        pass
                    if not tmdb:
                        tmdb = "0"
                    else:
                        tmdb = str(tmdb)
                        fflog(f'{tmdb=} {tvshowtitle=}', 0)
                except Exception:
                    fflog_exc(1)
                    tmdb = None
                    fflog(f'{tmdb=}')
                    pass

            try:
                # KADRPLUS FIX:
                # Nie wywalaj seriali z progressu tylko dlatego,
                # że TMDB zwróciło błędny lub alternatywny rekord.
                # Trakt często ma poprawne next_episode nawet gdy tmdb=0.
                if tmdb == "0" or tmdb is None or not tmdb:
                    fflog(f'KADRPLUS fallback trakt progress: {tvshowtitle=} {imdb=} {tmdb=}', 1, 1)
                    tmdb = None

                # KADRPLUS FIX\n                # pozwól Trakt obsługiwać seriale bez imdb\n                if imdb == "0" or imdb is None or imdb == "None" or not imdb:
                    imdb = None

                mpaa = ""
                country = ""
                original_language = ""
                original_translation_lang = ""

                meta1 = {}
                if not tvshowtitle or not tvdb or not imdb:
                    # log_utils.fflog('trzeba pobrać dane serialu',1,1)
                    meta1 = self.get_meta_for_tvshow(imdb, tmdb)
                    # fflog(f'meta1={json.dumps(meta1, indent=2)}',1,1)
                    tvshowtitle = meta1.get("originaltitle")
                    year = meta1.get("year")
                    localtvshowtitle = meta1.get("title")
                    originaltvshowtitle = meta1.get("originalname")
                    imdb = meta1.get("imdb") or imdb
                    tvdb = meta1.get("tvdb") or tvdb
                    mpaa = meta1.get("mpaa")
                    country = meta1.get("country")
                    original_language = meta1.get("original_language")
                    original_translation_lang = meta1.get("original_translation_lang")
                    #meta = ep_meta # ?
                    #meta1 = None  # nie, przydaje się później

                if not tvdb:
                    tvdb = "0"

                if not imdb:
                    # imdb = "0"  # nie wiem
                    pass

                # fflog(f'{season=}')

                # można jeszcze dodać pobieranie z fanart_tv
                # poster1 = poster2 = fanart1 = fanart2 = banner1 = landscape1 = clearlogo1 = clearart1 = banner2 = landscape2 = keyart1 = "0"
                """
                if not tvdb == "0":
                    if self.fanartTV_artwork == "true":
                        poster1, poster2, fanart1, banner1, landscape1, clearlogo1, clearart1, banner2, landscape2 = self.fanart_tv_art(tvdb)
                        # czy tu jest znany season ? czyli numer sezonu ?
                        if isinstance(poster2, dict):
                            poster2 = poster2.get(season)
                        if isinstance(banner2, dict):
                            banner2 = banner2.get(season)
                        if isinstance(landscape2, dict):
                            landscape2 = landscape2.get(season)
                """
                poster1 = poster2 = fanart1 = fanart2 = landscape1 = landscape2 = clearlogo1 = clearart1 = keyart1 = banner1 = banner2 = characterart1 = "0"
                country1 = original_language1 = original_translation_lang1 = "0"

                if meta1:
                    poster = meta1.get("poster") or "0"
                    poster2 = meta1.get("seasons_posters") or "0"
                    fanart = meta1.get("fanart") or "0"
                    fanart2 = meta1.get("seasons_fanarts") or "0"
                    landscape = meta1.get("landscape") or "0"
                    landscape2 = meta1.get("seasons_landscapes") or "0"
                    clearlogo = meta1.get("clearlogo") or "0"
                    clearart = meta1.get("clearart") or "0"
                    keyart = meta1.get("keyart") or "0"
                    banner = meta1.get("banner") or "0"
                    banner2 = meta1.get("seasons_banners") or "0"
                    characterart = meta1.get("characterart") or "0"
                    country = meta1.get("country") or "0"
                    original_language = meta1.get("original_language") or "0"
                    original_translation_lang = meta1.get("original_translation_lang") or "0"

                    if isinstance(poster2, dict):
                        poster2 = poster2.get(season)
                    if isinstance(fanart2, dict):
                        fanart2 = fanart2.get(season)
                    if isinstance(landscape2, dict):
                        landscape2 = landscape2.get(season)
                    if isinstance(banner2, dict):
                        banner2 = banner2.get(season)

                url = self.tmdb_show_lite_link % tmdb
                if tv_episode_group_id:
                    url = f"http://api.themoviedb.org/3/tv/episode_group/{tv_episode_group_id}?api_key={self.tm_user}&language={self.lang}"

                # control.log(f"{url=}", 1)
                r = self.session.get(url, timeout=10)  # zapytanie do serwera

                r.raise_for_status()
                r.encoding = "utf-8"
                result = r.json()  # if six.PY3 else utils.json_loads_as_str(r.text)
                # fflog(f'result={json.dumps(result, indent=2)}',1,1)

                r_en = r_org = None

                if not tv_episode_group_id:
                    number_of_seasons = result["number_of_seasons"]
                else:
                    # number_of_seasons = len(result["groups"])
                    number_of_seasons = result["group_count"]  # tylko, nie wiadomo, czy liczone razem z zerowym (różnie bywa)
                    groups = result["groups"]
                    groups = sorted(groups, key=lambda k: k["order"])  # bo bywa nie w kolejności
                    # result["groups"] = groups

                # fflog(f'{result["number_of_seasons"]=}')
                # fflog(f'{number_of_seasons=}',1,1)
                ranges = range(0, number_of_seasons + 1)
                if tv_episode_group_id:
                    # ranges = range(0, number_of_seasons)  # ze względu na niespójność w liczeniu (patrz wkomentarz wyżej), lepiej nie zaniżać
                    pass
                # fflog(f'{ranges=}',1,1)
                #for season_tmp in range(1, result["number_of_seasons"] + 1, 1):
                # for season_tmp in range(0, result["number_of_seasons"] + 1, 1):  # bo specjalne sezony mogą być
                # for season_tmp in range(0, number_of_seasons + 1, 1):  # może być
                for season_tmp in ranges:
                    # fflog(f'\n')
                    # fflog(f'{season=}')
                    # fflog(f'{season_tmp=}')
                    # if (season and season != "None") or season == 0:  # tylko pojedyńczy (jeden, konkretny/wybrany)
                    if season or season == 0:
                        season_tmp = int(season)
                        # fflog(f'{season_tmp=}',1,1)

                    if self.specials == "false":
                        if season_tmp == 0 or season_tmp == '0':
                            fflog(f'pomijam {season_tmp=}, bo {self.specials=}',0,1)
                            continue

                    if not tv_episode_group_id:

                        episodes_url = self.tmdb_season_link % (tmdb, season_tmp, self.lang)
                        episodes_lite_url = self.tmdb_season_lite_link % (tmdb, season_tmp)
                        if not lite:
                            url = episodes_url
                        else:
                            url = episodes_lite_url

                        # control.log('tmdb url: ' + repr(url), 1)
                        r = self.session.get(url, timeout=10)  # zapytanie do serwera

                        if r.status_code == 404:
                            fflog(f'brak sesonu o numerze {season_tmp=}',1,1)
                            continue
                        r.raise_for_status()
                        r.encoding = "utf-8"
                        result = r.json()  # if six.PY3 else utils.json_loads_as_str(r.text)
                        # fflog(f'result={json.dumps(result, indent=2)}',1,1)


                    if not tv_episode_group_id:
                        episodes = result["episodes"]
                        # group = {}
                    else:
                        # episodes = result["groups"][int(season_tmp)-1]["episodes"]
                        # episodes = result["groups"][season_tmp]["episodes"]
                        # episodes = groups[int(season_tmp)]["episodes"]
                        # powyższy sposób się nie sprawdza
                        episodes = [g for g in groups if g["order"] == season_tmp]
                        episodes = episodes[0]["episodes"] if episodes else episodes
                        # group = groups[int(season_tmp)]
                        # season_tmp = group["order"]
                        # fflog(f'{season_tmp=}')
                    # fflog(f'{len(episodes)=}',1,1)
                    # fflog(f'episodes={json.dumps(episodes, indent=2)}',1,1)


                    if self.specials == "false":
                        # episodes = [e for e in episodes if not e["season_number"] == 0]  # przecież wyżej jest wykluczanie
                        pass

                    if not episodes:
                        fflog(f'brak odcinków dla {tvshowtitle=} {year=} {season_tmp=}',0)
                        continue
                        # raise Exception()

                    r_cast = result.get("aggregate_credits", {}).get("cast", [])

                    poster_path = result.get("poster_path")
                    if poster_path:
                        poster = self.tm_img_link % ("500", poster_path)
                    else:
                        poster = "0"

                    fanart = banner = clearlogo = clearart = landscape = duration = status = tvshow_poster = tvshow_banner = tvshow_landscape = keyart = tvshow_fanart = characterart = "0"
                    country = original_language = original_translation_lang = "0"
                    season_banner = season_landscape = season_poster = "0"  # (na razie) nieużywane

                    clearlogo = meta1.get("clearlogo") or "0"

                    if meta:
                        try:
                            _meta = json.loads(unquote_plus(meta))
                        except Exception:
                            fflog_exc(1)
                            _meta = None
                            pass
                    elif meta1:
                        _meta = meta1
                    else:
                        _meta = None
                    if _meta:
                        try:
                            if "poster" in _meta.keys():
                                poster = _meta["poster"]

                            if "tvshow.poster" in _meta.keys():
                                tvshow_poster = _meta["tvshow.poster"]

                            if "season.poster" in _meta.keys():
                                # season_poster = _meta["season.poster"]
                                poster = _meta["season.poster"]

                            if "fanart" in _meta.keys():
                                fanart = _meta["fanart"]

                            if "clearlogo" in _meta.keys():
                                clearlogo = _meta["clearlogo"]

                            if "clearart" in _meta.keys():
                                clearart = _meta["clearart"]

                            if "keyart" in _meta.keys():
                                keyart = _meta["keyart"]  # or "0"  # jak nie chcemy, aby było None

                            if "characterart" in _meta.keys():
                                characterart = _meta["characterart"]

                            if "banner" in _meta.keys():
                                banner = _meta["banner"]

                            if "landscape" in _meta.keys():
                                landscape = _meta["landscape"]

                            if "duration" in _meta.keys():
                                duration = _meta["duration"]

                            if "status" in _meta.keys():
                                status = _meta["status"]

                            if "mpaa" in _meta.keys() and _meta["mpaa"]:
                                mpaa = _meta["mpaa"]

                            if "tvshow.banner" in _meta.keys():
                                tvshow_banner = _meta["tvshow.banner"]

                            if "tvshow.landscape" in _meta.keys():
                                tvshow_landscape = _meta["tvshow.landscape"]

                            if "tvshow.fanart" in _meta.keys():
                                tvshow_fanart = _meta["tvshow.fanart"]

                            if "season.banner" in _meta.keys():
                                # season_banner = _meta["season.banner"]
                                banner = _meta["season.banner"]

                            if "season.landscape" in _meta.keys():
                                # season_landscape = _meta["season.landscape"]
                                landscape = _meta["season.landscape"]

                            if "country" in _meta.keys():
                                country = _meta["country"]

                            if "original_language" in _meta.keys():
                                original_language = _meta["original_language"]

                            if "original_translation_lang" in _meta.keys():
                                original_translation_lang = _meta["original_translation_lang"]

                            if "localtvshowtitle" in _meta.keys() and not localtvshowtitle:
                                localtvshowtitle = _meta["localtvshowtitle"]

                            if "originaltvshowtitle" in _meta.keys() and not originaltvshowtitle:
                                originaltvshowtitle = _meta["originaltvshowtitle"]

                        except Exception:
                            # fflog_exc(1)
                            pass


                    tvshow_poster = poster1 if poster1 and poster1 != "0" else tvshow_poster
                    poster = poster2 if poster2 and poster2 != "0" else poster  # season.poster
                    poster = poster1 if (not poster2 or poster2 == "0") and poster1 and poster1 != "0" else poster

                    fanart = fanart1 if fanart1 and fanart1 != "0" else fanart

                    clearart = clearart1 if clearart1 and clearart1 != "0" else clearart

                    clearlogo = clearlogo1 if clearlogo1 and clearlogo1 != "0" else clearlogo
                    
                    keyart = keyart1 if keyart1 and keyart1 != "0" else keyart if keyart else "0"  # jak nie chcemy, aby było None

                    characterart = characterart1 if characterart1 and characterart1 != "0" else characterart

                    tvshow_banner = banner1 if banner1 and banner1 != "0" else tvshow_banner
                    banner = banner2 if banner2 and banner2 != "0" else banner  # season.banner
                    banner = banner1 if (not banner2 or banner2 == "0") and banner1 and banner1 != "0" else banner

                    tvshow_landscape = landscape1 if landscape1 and landscape1 != "0" else tvshow_landscape
                    landscape = landscape2 if landscape2 and landscape2 != "0" else landscape  # season.landscape
                    landscape = landscape1 if (not landscape2 or landscape2 == "0") and landscape1 and landscape1 != "0" else landscape

                    tvshow_fanart = fanart1 if fanart1 and fanart1 != "0" else tvshow_fanart
                    fanart = fanart2 if fanart2 and fanart2 != "0" else fanart  # season.fanart
                    fanart = fanart1 if (not fanart2 or fanart2 == "0") and fanart1 and fanart1 != "0" else fanart
                    
                    country = country1 if country1 and country1 != "0" else country
                    original_language = original_language1 if original_language1 and original_language1 != "0" else original_language
                    original_translation_lang = original_translation_lang1 if original_translation_lang1 and original_translation_lang1 != "0" else original_translation_lang

                    fflog(f'{country=}',0,1)
                    fflog(f'{original_language=}',0,1)
                    fflog(f'{original_translation_lang=}',0,1)

                    result_en = {}
                    # if country.lower() not in ["poland", "pl", "polska"]:  # a jak do polskiego filmu żaden Polak nie wprowadzi opisu, a zagraniczny user tak?
                    # fflog(f'{len(episodes)=}',1,1)
                    for item in episodes:
                        episodeplot = item["overview"]
                        title = item.get("name") or ""
                        if not episodeplot or re.search(r'^[Oo]dcinek \d+$', title):
                            # fflog(f'{title=}  {episodeplot=} \n{item=}',1,1)
                            try:
                                ##### En plot fetch - set up
                                if not tv_episode_group_id:
                                    log_utils.fflog(f'próba pobrania angielskich opisów odcinków sezonu {season_tmp}', 1,1)
                                    episodes_url_en = self.tmdb_season_lite_link % (tmdb, season_tmp)
                                    # control.log(f'{episodes_url_en=}', 1)
                                    r_en = self.session.get(episodes_url_en, timeout=10)
                                else:
                                    if not r_en:
                                        log_utils.fflog(f'próba pobrania angielskich opisów odcinków', 1,1)
                                        url_en = url.replace(f"&language={self.lang}", "&language=en")
                                        r_en = self.session.get(url_en, timeout=10)
                                r_en.raise_for_status()
                                r_en.encoding = "utf-8"
                                result_en = r_en.json()
                                if tv_episode_group_id:
                                    episodes_en = [g for g in result_en["groups"] if g["order"] == season_tmp]
                                    episodes_en = episodes_en[0]["episodes"] if episodes_en else episodes_en
                                    episodes_en = sorted(episodes_en, key=lambda k: k["order"])  # bo bywa nie w kolejności
                                    result_en["episodes"] = episodes_en
                                else:
                                    # episodes = result_en["episodes"]
                                    pass
                                ##########
                                break
                            except Exception:
                                fflog_exc(1)
                                pass

                    result_org = {}
                    if original_translation_lang and original_translation_lang != "0" and original_translation_lang != f"{self.lang}-{self.lang.upper()}":
                        # fflog(f'{len(result_en.get("episodes", []))=}',1,1)
                        for item in result_en.get("episodes", []):
                            episodeplot = item["overview"]
                            title = item.get("name") or ""
                            if not episodeplot or re.search(r'^[Ee]pisode \d+$', title):
                                # fflog(f'{title=}  {episodeplot=} \n{item=}',1,1)
                                try:
                                    ##### Original plot fetch - set up
                                    if not tv_episode_group_id:
                                        episodes_url_org = self.tmdb_season_lite_link % (tmdb, season_tmp)
                                        # episodes_url_org = episodes_url_org.replace("&language=en", "&language=%s" % original_translation_lang[:2])  # wycina np. odmiany chińskie
                                        episodes_url_org = episodes_url_org.replace("&language=en", "&language=%s" % original_translation_lang)
                                        # control.log(f'{episodes_url_org=}', 1)
                                        if episodes_url_org != episodes_url_en:
                                            # fflog(f'\n{episodes_url_org=}\n {episodes_url_en=}', 1,1)
                                            log_utils.fflog(f'próba pobrania oryginalnych opisów odcinków sezonu {season_tmp}', 1,1)
                                            r_org = self.session.get(episodes_url_org, timeout=10)  # zapytanie do serwera
                                    else:
                                        if not r_org:
                                            # url_org = url.replace(f"&language={self.lang}", "&language=%s" % original_translation_lang[:2])
                                            url_org = url.replace(f"&language={self.lang}", "&language=%s" % original_translation_lang)
                                            if url_org != url_en:
                                                # fflog(f'\n{url_org=}\n {url_en=}', 1)
                                                log_utils.fflog(f'próba pobrania oryginalnych opisów odcinków', 1,1)
                                                r_org = self.session.get(url_org, timeout=10)  # zapytanie do serwera
                                    if r_org is not None:
                                        r_org.raise_for_status()
                                        r_org.encoding = "utf-8"
                                        result_org = r_org.json()
                                        # result_en = result_org  # już niepotrzebne
                                        if tv_episode_group_id:
                                            episodes_org = [g for g in result_org["groups"] if g["order"] == season_tmp]
                                            episodes_org = episodes_org[0]["episodes"] if episodes_org else episodes_org
                                            episodes_org = sorted(episodes_org, key=lambda k: k["order"])  # bo bywa nie w kolejności
                                            result_org["episodes"] = episodes_org
                                            # result_en["episodes"] = episodes_org  # już niepotrzebne
                                    else:
                                        result_org = result_en
                                        if tv_episode_group_id:
                                            result_org["episodes"] = episodes_en
                                    ##########
                                    break
                                except Exception:
                                    fflog_exc(1)
                                    pass

                    count = 0
                    # fflog(f'{len(episodes)=}',1,1)
                    # fflog(f'episodes={json.dumps(episodes, indent=2)}',1,1)
                    for item in episodes:
                        # fflog(f'{count=}')
                        # fflog(f'item={json.dumps(item, indent=2)}',1,1)
                        try:
                            if not tv_episode_group_id:
                                if item["season_number"] != season_tmp:
                                    fflog(f'zmieniam {season_tmp=} na {item["season_number"]}',1,1)
                                    season_tmp = str(item["season_number"])  # czy season_tmp może zmienić wartość?
                                    # fflog(f'{season_tmp=}',1,1)
                                    pass
                            episode = str(item["episode_number"])
                            # fflog(f'{episode=}',1,1)
                            order = item.get("order")
                            # fflog(f'{order=}',1,1)
                            if order or order == 0:
                                episode = str(int(order)+1)
                                # season_tmp = group["order"]  # przeniosłem wyżej

                            # fflog(f'{season_tmp=} {episode=} {order=}',1,1)

                            title = item.get("name")
                            # fflog(f'{title=}')
                            # if not title or 'dcinek ' in title:
                            if not title or re.search(r'^[Oo]dcinek \d+$', title):
                                # fflog(f'{title=}  \n{item=}',1,1)
                                if result_en:
                                    # fflog(f'result_en["episodes"][count]={json.dumps(result_en["episodes"][count], indent=2)}',1,1)
                                    title = result_en["episodes"][count]["name"]
                                elif result_org:
                                    title = result_org["episodes"][count]["name"]
                            # fflog(f'{title=}')
                            if not title or re.search(r'^[Ee]pisode \d+$', title):
                                if result_org:
                                    title = result_org["episodes"][count]["name"]
                                    pass
                                    if re.search(r' \d+$', title) and title.strip().count(" ") == 1:  # ale np. "Robin part 1" też się łapie (a może spacje liczyć?)
                                        title = ""
                                        pass
                                else:
                                    if item.get("name"):
                                        title = item.get("name")
                                    else:
                                        # title = "Episode %s" % episode
                                        title = "Odcinek %s" % episode
                                        title = f"({title})"
                            if (not title
                                # or re.search(r' \d+$', title)  # bo np. "Robin część 1" też się łapie (a może spacje liczyć?)
                                  or re.search(r'^[Ee]pisode \d+$', title)
                                ):
                                if item.get("name"):
                                    title = item.get("name")
                                else:
                                    title = "Odcinek %s" % episode
                                if country.lower() not in ["poland", "pl", "polska"]:
                                    title = f"({title})"
                                    pass
                                # fflog(f'2 {title=}')
                            # fflog(f'{title=} {season_tmp=} {episode=} {order=}')

                            label = title

                            premiered = item.get("air_date")
                            if not premiered:
                                premiered = "0"

                            duration = item.get("runtime", "0")

                            unaired = ""
                            # fflog(f'{premiered=} {title=}')
                            if not premiered or premiered == "0":
                                pass
                                # brak daty może oznaczać, że nie znana jest jeszcze premiera (ale i też, że nie została wprowadzona informacja o tym)
                                unaired = "true"
                                # if self.showunaired != "true" and not showunaired:
                                if not showunaired:
                                    continue
                            elif int(re.sub("[^0-9]", "", str(premiered))) > int(re.sub("[^0-9]", "", str(self.today_date))):
                                unaired = "true"
                                # if self.showunaired != "true" and not showunaired:
                                if not showunaired:
                                    continue
                                    # raise Exception()

                            still_path = item.get("still_path")
                            if still_path:
                                thumb = self.tm_img_link % ("1280", still_path)
                            else:
                                thumb = "0"

                            mpaa1 = mpaa
                            try:
                                mpaa = str(item["mpaa"])
                            except:
                               # mpaa = ""
                                mpaa = mpaa1
                            if not mpaa:
                                mpaa = "0"
                                pass

                            try:
                                rating = str(item["vote_average"])
                            except:
                                rating = ""
                            if not rating:
                                rating = "0"

                            try:
                                votes = str(item["vote_count"])
                            except:
                                votes = ""
                            if not votes:
                                votes = "0"

                            try:
                                episodeplot = item["overview"]
                            except:
                                episodeplot = ""
                            if not episodeplot:
                                try:
                                    episodeplot = result_en["episodes"][count]["overview"]
                                except:
                                    try:
                                        episodeplot = result_org["episodes"][count]["overview"]
                                    except:
                                        pass
                                if not episodeplot:
                                    episodeplot = "0"

                            count += 1

                            # if not self.lang == 'en' and episodeplot == '0':
                            # try:
                            # en_item = en_result.get('episodes', [])
                            # episodeplot = en_item['overview']
                            # episodeplot = six.ensure_str(episodeplot)
                            # except:
                            # episodeplot = ''
                            # if not episodeplot: episodeplot = '0'

                            try:
                                r_crew = item["crew"]
                                director = [d for d in r_crew if d["job"] == "Director"]
                                director = ", ".join([d["name"] for d in director])
                                writer = [w for w in r_crew if w["job"] == "Writer"]
                                writer = ", ".join([w["name"] for w in writer])
                            except:
                                director = writer = ""
                            if not director:
                                director = "0"
                            if not writer:
                                writer = "0"

                            castwiththumb = []
                            try:
                                for person in r_cast[:30]:
                                    _icon = person["profile_path"]
                                    icon = (self.tm_img_link % ("185", _icon) if _icon else "")
                                    castwiththumb.append({
                                        "name": person["name"],
                                        "role": person["roles"][0]["character"],
                                        "thumbnail": icon,
                                        })
                            except:
                                pass
                            if not castwiththumb:
                                castwiththumb = "0"

                            self.list.append({"title": title, "label": label, "season": str(season_tmp), "episode": str(episode),  # "order": order,
                                "tvshowtitle": tvshowtitle, "year": year, "premiered": premiered, "rating": rating, "mpaa": mpaa,
                                "votes": votes, "director": director, "writer": writer, "castwiththumb": castwiththumb,
                                "duration": duration, "status": status, "plot": episodeplot, "imdb": imdb, "tmdb": tmdb,
                                "tvdb": tvdb, "unaired": unaired, "thumb": thumb, "poster": poster, "fanart": fanart,
                                "banner": banner, "clearlogo": clearlogo, "clearart": clearart, "landscape": landscape,
                                "localtvshowtitle": localtvshowtitle, "originaltvshowtitle": originaltvshowtitle, "keyart": keyart,
                                "tvshow.poster": tvshow_poster, "tvshow.banner": tvshow_banner, "tvshow.landscape": tvshow_landscape,
                                # "season.poster": season_poster, "season.banner": season_banner, "season.landscape": season_landscape,
                                "characterart": characterart, "country": country, "original_language": original_language, "original_translation_lang": original_translation_lang,
                                })

                        except Exception:
                            log_utils.log("tmdb_list2 Exception", "indexer")
                            fflog_exc(1)
                            pass

                    try:
                        if season or season == 0:
                            # fflog(f'wyskoczenie z pętli {season=} {season_tmp=}')  # musi wyskoczyć, gdy nie jest włączone spłaszczanie seriali
                            break
                    except Exception as e:
                        fflog_exc(1)
                        pass

                # fflog(f'\n')
                fflog(f'{len(self.list)=}',0)
                # fflog(f'{self.list=}')
                # self.list = sorted(self.list, key=lambda k: k["premiered"], reverse=False)
                self.list = sorted(self.list, key=lambda k: (int(k["season"]), int(k["episode"])), reverse=False)

                try:
                    # fflog(f'zapisywanie do cache')
                    if season or season == 0:
                        cache.cache_insert("episodes" + f"_{tmdb or imdb}_s{season}", repr(self.list))
                    else:
                        cache.cache_insert("episodes" + f"_{tmdb or imdb}", repr(self.list))
                except Exception:
                    fflog_exc(1)
                    pass

                return self.list

            except Exception as e:
                log_utils.log(f"tmdb_list1 Exception {e!r}", "indexer")
                fflog_exc(1)
                return self.list


        def get_meta_for_tvshow(self, imdb=None, tmdb=None):
            try:
                meta = cache.cache_get("superinfo" + f"_{tmdb or imdb}")  # sprawdzenie, czy nie ma już w cache
                if not meta:
                    # log_utils.fflog('próba pobrania informacji o serialu przez super_info.py')
                    from resources.lib.indexers.super_info import SuperInfo  # bo można by z zewnątrz wywoływać
                    media_list = [{'tmdb': tmdb, 'imdb': imdb}]
                    if not self.session:
                        import requests
                        session = requests.Session()
                    else:
                        session = self.session
                    lang = control.apiLanguage()["tmdb"]
                    super_info_obj = SuperInfo(media_list, session, lang, "tvshow")
                    super_info_obj.get_info(0)

                    meta = cache.cache_get("superinfo" + f"_{tmdb or imdb}")
                if meta:
                    from ast import literal_eval
                    meta = meta["value"]
                    meta = literal_eval(meta)
                else:
                    meta = {}
            except Exception:
                meta = {}
                fflog_exc(1)
            return meta


        def episodeDirectory(self, items, force_tvshow_title=False, cacheToDisc=False):
            fflog(f'[episodeDirectory]')

            if items is None or len(items) == 0:
                fflog(f'{items=}')
                # sys.exit()
                return

            sysaddon = sys.argv[0]
            syshandle = int(sys.argv[1])
            currentPath = dict(parse_qsl(sys.argv[2][1:]))

            if control.setting("zastepcze_grafiki") == "true":
                addonPoster = control.addonPoster()
                addonFanart = control.addonFanart()
                addonBanner = control.addonBanner()
            else:
                addonPoster = addonFanart = addonBanner = ""

            settingFanart = control.setting("fanart")

            traktCredentials = trakt.getTraktCredentialsInfo()

            try:
                isOld = False
                control.item().getArt("type")
            except:
                isOld = True

            # nie pamiętam co tu to multi oznacza (to chyba jak trakt podaje listę odcinków, to mogą one być od różnych seriali i dlatego nazwa multi)
            try:
                multi = [i["tvshowtitle"] for i in items]
            except:
                multi = []
            multi = force_tvshow_title or len(set(multi)) > 1

            try:
                sysaction = items[0]["action"]
            except:
                sysaction = ""

            PluginName = control.infoLabel("Container.PluginName")
            # PluginName = PluginName == "plugin.video.kadrplus"  # nie wiem, czy to potrzebne
            # fflog(f'{PluginName=}',1,1)

            isFolder = False if not sysaction == "episodes" else True
            disp_dir = False if control.setting("hosts.mode") != "1" else True
            isPlayable = "true" if "plugin" not in control.infoLabel("Container.PluginName") else "false"  # dziwny warunek - niżej go modyfikuje jeszcze
            yatse = control.setting("yatse") == "true"
            yatse = False if not disp_dir else yatse  # zastanowić się
            playbackMenu = (control.lang(32063) if control.setting("hosts.mode") == "2" else control.lang(32064))
            dont_use_setResolvedUrl = control.setting("player.dont_use_setResolvedUrl") == "true"
            fflog(f'{dont_use_setResolvedUrl=}') if dont_use_setResolvedUrl else ''
            indicators = playcount.getTVShowIndicators(refresh=True)
            traktIndicators  = trakt.getTraktIndicatorsInfo()
            watchedMenu =   (control.lang(32068) if traktIndicators == True else control.lang(32066))
            unwatchedMenu = (control.lang(32069) if traktIndicators == True else control.lang(32067))
            indicator_kodi = control.setting("indicator.kodi") == "true"
            queueMenu = control.lang(32065)
            traktManagerMenu = control.lang(32070)
            tvshowBrowserMenu = control.lang(32071)  # Przeglądaj sezony
            addToLibrary = control.lang(32551)
            generate_short_path = control.setting("generate_short_path") == "true"
            # add_rating_for_tmdb = control.setting("add_rating_for_tmdb.episodes") == "true" and control.setting("add_rating_for_tmdb") == "true"
            add_rating_for_tmdb = True
            kodiver = source_utils.get_kodi_version()
            meta = {}

            # Spis odcinków w sezonie.
            addSortMethod(syshandle, sortMethod=SORT_METHOD_UNSORTED, labelMask="%L")

            cm_enable_autoplay = control.setting("cm.enable.autoplay") == "true"
            cm_enable_similar_trakt = control.setting("cm.enable.similar_trakt") == "true"
            cm_enabl_similar_tmdb = control.setting("cm.enable.similar_tmdb") == "true"
            cm_enable_recommendations_tmdb = control.setting("cm.enable.recommendations_tmdb") == "true"
            cm_enable_removeFromBookmarks = control.setting("cm.enable.removeFromBookmarks") == "true"
            cm_enable_addToLibrary = control.setting("cm.enable.addToLibrary") == "true"
            cm_enable_addMultiToLibrary = control.setting("cm.enable.addMultiToLibrary") == "true"
            cm_enable_editForSearch = control.setting("cm.enable.editForSearch") == "true"
            cm_enable_queueMenu = control.setting("cm.enable.queueMenu") == "true"  # to chyba Kodi dodaje od wersji 21.2
            cm_enable_watchedUnwatched = control.setting("cm.enable.watchedUnwatched") == "true"
            cm_enable_cacheRefresh = control.setting("cm.enable.cacheRefresh") == "true"
            cacheIsEnabled = control.setting("enableSourceCache") == "true"
            # eksperyment
            cm_enable_katalog_gdy_autoodtwarzanie = control.setting("cm.enable.katalog_gdy_autoodtwarzanie") == "true"

            downloads = (
                control.setting("downloads") == "true"
                and not (
                    control.setting("movie.download.path") == ""
                    or control.setting("tv.download.path") == ""
                )
            )
            downloadMenu = control.lang(32403)

            unpremiered_color = control.setting("unpremiered_color")
            if unpremiered_color == "inny":
                unpremiered_color = control.setting("unpremiered_custom_color")
            else:
                colors_map = {
                    "szary": "gray",
                    "czerwony": "red",
                    "fioletowy": "magenta",
                    "pomarańczowy": "orange",
                    }
                unpremiered_color = colors_map[unpremiered_color]
            # fflog(f'{unpremiered_color=}')

            counter = 1
            # fflog(f'{len(items)=}')
            for i in items:
                try:
                    #fflog(f'{i=}',1,1)
                    # fflog(f'i={json.dumps(i, indent=2)}',1,1)

                    if "label" not in i:
                        i["label"] = i["title"]
                    if i["label"] == "0":
                        label = "%sx%02d  %s %s" % (i["season"], int(i["episode"]), "Episode", i["episode"],)
                    else:
                        label = "%sx%02d  %s" % (i["season"], int(i["episode"]), i["label"],)
                    syslabel = quote_plus(label)
                    if multi:
                        label = "{} – {}".format(i.get("localtvshowtitle") or i["tvshowtitle"], label)

                    imdb, tvdb, tmdb, year, season, episode = i["imdb"], i["tvdb"], i["tmdb"], i["year"], i["season"], i["episode"]

                    systitle = quote_plus(i["title"])
                    systvshowtitle = quote_plus(i["tvshowtitle"])
                    syslocaltvshowtitle = quote_plus( i.get("localtvshowtitle") or "")
                    syspremiered = quote_plus(i["premiered"])

                    meta = {k: v for k, v in i.items() if not v == "0"}

                    meta.update({"mediatype": "episode"})

                    meta.update({"season": season})  # potrzebne dla sezonów o numerze 0
                    meta.update({"episode": episode})  # potrzebne dla epizodów o numerze 0

                    # meta.update({"trailer": "%s?action=trailer&name=%s" % (sysaddon, systvshowtitle)})
                    # meta.update({"trailer": "%s?action=trailer&name=%s&url=%s" % (sysaddon, systvshowtitle, quote_plus(meta.get("trailer") or ""))})
                    meta.update({"trailer": "%s?action=trailer&name=%s&url=%s" % (sysaddon, systvshowtitle + " " + syslabel, quote_plus(meta.get("trailer") or ""))})

                    # fflog(f'{("duration" in i)=} {i.get("duration")=} {meta.get("duration")=} {i["label"]=}')
                    if not "duration" in i:
                        # meta.update({"duration": "60"})
                        # meta.update({"duration": "1"})
                        pass
                    elif i["duration"] == "0":
                        # meta.update({"duration": "60"})
                        # meta.update({"duration": "1"})
                        pass
                    try:
                        if meta.get("duration") and meta.get("duration") != "0":
                            meta.update({"duration": str(int(meta["duration"]) * 60)})
                    except:
                        pass
                    # fflog(f'{("duration" in i)=} {i.get("duration")=} {meta.get("duration")=} {i["label"]=}')

                    # try:
                    #    meta.update({"genre": cleangenre.lang(meta["genre"], self.lang)})
                    # except:
                    #    pass

                    try:
                        meta.update({"tvshowyear": i["year"]})
                        meta.update({"year": re.findall(r"(\d{4})", i["premiered"])[0]})
                    except:
                        pass

                    try:
                        meta.update({"title": i["label"]})
                    except:
                        pass

                    meta.update({"originalname": i.get("originaltvshowtitle", "")})

                    meta.pop("next", None)

                    sysmeta = quote_plus(json.dumps(meta))

                    # url = "%s?action=play&title=%s&year=%s&imdb=%s&tvdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s&t=%s" % (sysaddon, systitle, year, imdb, tvdb, season, episode, systvshowtitle, syspremiered, sysmeta, self.systime,)
                    url = "%s?action=play&title=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s" % (sysaddon, systitle, year, imdb, tmdb, tvdb, season, episode, systvshowtitle, syspremiered, sysmeta)
                    sysurl = quote_plus(url)  # potrzebne dla context menu
                    fullpath = ""
                    if generate_short_path and disp_dir:
                        fullpath = url
                        url = "{}?action=play&item={}".format(sysaddon, counter)
                        #sysurl = quote_plus(url)  # ale czy to potrzebne? bo może bardziej zaszkodzi

                    # ta zmienna chyba nie jest wykorzystywana
                    # path = "%s?action=play&title=%s&year=%s&imdb=%s&tvdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s" % (sysaddon, systitle, year, imdb, tvdb, season, episode, systvshowtitle, syspremiered,)

                    if isFolder:
                        url = "%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&season=%s&episode=%s" % (sysaddon, systvshowtitle, year, imdb, tmdb, tvdb, season, episode)  # czy tu nie trzeba dać jeszcze meta ?
                        if generate_short_path:
                            fullpath = url
                            url = "{}?action=episodes&item={}".format(sysaddon, counter)

                    if "?action=play&" in url:
                        # disp = False if control.setting("hosts.mode") == "0" else True
                        # disp = False if control.setting("hosts.mode") != "1" else True  # disp_dir
                        disp = disp_dir
                    else:
                        disp = isFolder

                    isPlayable = "true" if not disp else "false"
                    isPlayable = "false" if dont_use_setResolvedUrl else isPlayable


                    cm = []

                    # autoodtwarzanie, albo zatrzymanie autoodtwarzania
                    if cm_enable_autoplay:
                        if not isFolder:
                            if not disp and playbackMenu == control.lang(32063) and cm_enable_katalog_gdy_autoodtwarzanie:  # 0 to okienko, 1 to katalog
                                if 2:
                                    ctxm = [
                                            ( "okno",    "PlayMedia(%s?action=alterSources&url=%s)" % (sysaddon, sysurl) ),
                                            ( "katalog", "Container.Update(%s?action=alterSources&url=%s)" % (sysaddon, sysurl+"%26select%3D1") if PluginName
                                                    else "ActivateWindow(10025,%s?action=alterSources&url=%s,return)" % (sysaddon, sysurl+"%26select%3D1") ),
                                           ]
                                    cm.append((playbackMenu+":", "RunPlugin(%s?action=contextmenu&list=%s)" % (sysaddon, quote_plus(repr(ctxm)) ),))  # test wybory między oknem a katalogiem
                                else:
                                    cm.append((playbackMenu+" (o)", "PlayMedia(%s?action=alterSources&url=%s)" % (sysaddon, sysurl),))  # okienko (dodatkowo dla testów)
                                    if PluginName:
                                        cm.append((playbackMenu+" (k)", "Container.Update(%s?action=alterSources&url=%s)" % (sysaddon, sysurl+"%26select%3D1"),))  # katalog
                                    else:
                                        cm.append((playbackMenu+" (k)", "ActivateWindow(10025,%s?action=alterSources&url=%s,return)" % (sysaddon, sysurl+"%26select%3D1"),))  # katalog
                            else:
                                #cm.append((playbackMenu, "RunPlugin(%s?action=alterSources&url=%s&meta=%s)" % (sysaddon, sysurl, sysmeta),))  # w url jest już meta, więc bez sensu
                                # cm.append((playbackMenu, "RunPlugin(%s?action=alterSources&url=%s)" % (sysaddon, sysurl),))  # handle -1
                                cm.append((playbackMenu, "PlayMedia(%s?action=alterSources&url=%s)" % (sysaddon, sysurl),))
                        else:
                            pass

                    if cm_enable_editForSearch:
                        if not isFolder:
                            # if isPlayable == "true":
                            if not disp:
                                # cm.append(("EDYTUJ dane do wyszukiwarki", "RunPlugin(%s?action=alterSources&url=%s)" % (sysaddon, sysurl + quote_plus("&customTitles=3")),))  # handle -1
                                cm.append(("EDYTUJ dane do wyszukiwarki", "PlayMedia(%s?action=alterSources&url=%s)" % (sysaddon, sysurl + quote_plus("&customTitles=3")),))
                            else:
                                if not generate_short_path:
                                    if PluginName:
                                        cm.append(("EDYTUJ dane do wyszukiwarki", "Container.Update(%s?action=alterSources&url=%s)" % (sysaddon, sysurl + quote_plus("&customTitles=3")),))
                                    else:
                                        cm.append(("EDYTUJ dane do Wyszukiwarki", "ActivateWindow(10025,%s?action=alterSources&url=%s,return)" % (sysaddon, sysurl + quote_plus("&customTitles=3&noref=1")),))
                                    # cm.append(("EDYTUJ dane do wyszukiwarki", "RunPlugin(%s?action=alterSources&url=%s)" % (sysaddon, sysurl + quote_plus("&customTitles=3&noref=1")),))  # handle -1, zmienia na okienko
                                else:
                                    cm.append(("EDYTUJ dane do wyszukiwarki", "Container.Update(%s)" % (url + "&customTitles=1"),))

                    if cm_enable_queueMenu:
                        if not disp:
                            if kodiver.major < 21 or kodiver.major >= 21 and kodiver.minor < 2:
                                cm.append((queueMenu, "RunPlugin(%s?action=queueItem)" % sysaddon))

                    # if multi:
                    if True:  # bo to przydatne raczej zawsze
                        # Przeglądaj sezony
                        if not generate_short_path:
                            if PluginName:
                                cm.append((tvshowBrowserMenu,
                                           #"Container.Update(%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s,return)" % (
                                           "Container.Update(%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s)" % (
                                            sysaddon, systvshowtitle, year, imdb, tmdb, tvdb),))
                            else:
                                cm.append((tvshowBrowserMenu,
                                           "ActivateWindow(10025,%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s,return)" % (
                                            sysaddon, systvshowtitle, year, imdb, tmdb, tvdb),))

                        else:
                            cm.append((tvshowBrowserMenu, "Container.Update(%s?action=seasons)" % (sysaddon, ), ))

                    if cm_enable_addToLibrary:
                        cm.append((addToLibrary,
                                   "RunPlugin(%s?action=tvshowToLibrary&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&localtvshowtitle=%s)" % (
                                   sysaddon, systvshowtitle, year, imdb, tmdb, syslocaltvshowtitle),))

                    if cm_enable_cacheRefresh and cacheIsEnabled:
                        if not disp:
                            cm.append(("Odśwież cache źródeł", "PlayMedia(%s)" % (url + "&refreshCache=1"),))
                        else:
                            if PluginName:
                                cm.append(("Odśwież cache źródeł", "Container.Update(%s)" % (url + "&refreshCache=1"),))
                            else:
                                cm.append(("Odśwież cache źródeł", "ActivateWindow(10025,%s,return)" % (url + "&refreshCache=1"),))

                    overlay = None
                    if not isPlayable or traktIndicators or not indicator_kodi:
                        try:
                            overlay = int(playcount.getEpisodeOverlay(indicators, imdb, tmdb, season, episode))
                            # fflog(f'{overlay=}  {imdb=}  {tmdb=}  {title=}  {label=}  {season=}  {episode=}  {indicators=}')
                            if overlay == 7:
                                meta.update({"playcount": 1, "overlay": 7})  # to zmienia ptaszki
                                if not traktIndicators:
                                    if cm_enable_watchedUnwatched:
                                        cm.append((unwatchedMenu, "RunPlugin(%s?action=episodePlaycount&imdb=%s&tmdb=%s&tvdb=%s&season=%s&episode=%s&query=6)" % (sysaddon, imdb, tmdb, tvdb, season, episode),))
                            else:
                                meta.update({"playcount": 0, "overlay": 6})  # to zmienia ptaszki
                                if not traktIndicators:
                                    if cm_enable_watchedUnwatched:
                                        cm.append((watchedMenu,   "RunPlugin(%s?action=episodePlaycount&imdb=%s&tmdb=%s&tvdb=%s&season=%s&episode=%s&query=7)" % (sysaddon, imdb, tmdb, tvdb, season, episode),))
                        except Exception:
                            fflog_exc(1)
                            pass

                    if traktCredentials:
                        overlay = "" if overlay is None else overlay
                        cm.append((traktManagerMenu, "RunPlugin(%s?action=traktManager&name=%s&imdb=%s&tmdb=%s&content=episode&season=%s&episode=%s&overlay=%s)" % (sysaddon, systvshowtitle, imdb, tmdb, season, episode, overlay),))

                    # na ten moment raczej nie ma to sensu, bo w lastWatched pojawiają się seriale, a nie odcinki
                    if cm_enable_removeFromBookmarks:
                        if currentPath.get("action") == "lastWatched":
                        # if True:  # zawsze (a może jakiś warunek sprawdzający, czy w ogóle jest potrzeba, tzn. czy jest w bazie bookmarks)
                            cm.append(("Usuń z lokalnej historii", "RunPlugin(%s?action=removeFromBookmarks&content=episode&imdb=%s&tmdb=%s&season=%s&episode=%s)" % (sysaddon, imdb, tmdb, season, episode),))
                            pass

                    if fullpath:
                        cm.append(("[I]przygotuj do ulubionych[/I]", "Container.Update(%s?action=prepareItemForAddToLibrary)" % (sysaddon),))

                    if downloads and not isFolder and not disp:
                        cm.append((downloadMenu, "RunPlugin(%s)" % (url + "&download=1"),))

                    if isOld:
                        cm.append((control.lang2(19033), "Action(Info)"))


                    try:
                        if i["unaired"] == "true":
                            if self.showunaired != "true":
                                continue
                            label = f"[COLOR {unpremiered_color}][I]%s[/I][/COLOR]" % label
                    except:
                        pass


                    item = control.item(label=label, offscreen=True)  # create ListItem

                    vtag = item.getVideoInfoTag()  # od Kodi 20

                    percent = None
                    if overlay != 7:
                        # if True:
                        if not isPlayable or traktIndicators or not indicator_kodi:
                            try:
                                percent = 0
                                # if trakt.getTraktIndicatorsInfo() and trakt.getTraktCredentialsInfo() == True:
                                if traktIndicators is True:
                                    offsetSource = "trakt"
                                    percent = bookmarks.get_scrobble("episode", imdb, season, episode, tmdb)
                                    # fflog(f'{percent=}  trakt  {imdb=}  {tmdb=}  {season=}  {episode=}  {label=}',1,1)
                                    runtime = offset = 0  # bo nie ma takiej informacji z powyższej funkcji
                                else:
                                    offset, runtime, offsetSource = bookmarks.get("episode", imdb, season, episode, tmdb=tmdb)
                                    # fflog(f'{offset=}  {runtime=}  {offsetSource=}  {imdb=}  {tmdb=}  {season=}  {episode=}  {label=}',1,1)
                                    runtime = runtime or int(meta.get("duration") or 0)
                                    # fflog(f'{offset=}  {runtime=}  {offsetSource=}  {imdb=}  {tmdb=}  {season=}  {episode=}  {label=}',1,1)
                                    if runtime and offset > 1:
                                        percent = int((offset / runtime) * 100)
                                        # fflog(f'{percent=}  {offsetSource}  {imdb=}  {tmdb=}  {season=}  {episode=}  {label=}',1,1)
                                    else:
                                        percent = None
                            except Exception:
                                fflog_exc(1)
                                pass
                            # fflog(f'{percent=}  {offsetSource}  {imdb=}  {tmdb=}  {season=}  {episode=}  {label=}',1,1)
                            if percent and percent < 75:
                                item.setProperty("WatchedProgress", str(percent) )  # a może jest lepszy sposób?
                                pass

                                totalTime = runtime or float(meta.get("duration") or 0)
                                time = offset or float(percent / 100) * totalTime
                                if totalTime and totalTime > 10:
                                    if kodiver.major < 20:
                                        try:
                                            item.setProperty("resumetime", str(time))
                                            item.setProperty("totaltime", str(totalTime))
                                            pass
                                        except Exception:
                                            # fflog_exc(1)
                                            pass
                                    else:
                                        try:
                                            # bo vtag i setResumePoint dopiero od Kodi v20
                                            vtag.setResumePoint(time, totalTime)
                                            pass
                                        except Exception:
                                            # fflog_exc(1)
                                            # fflog(f'{time=}, {totalTime=}',1,1)
                                            pass
                        else:
                            percent = None


                    # fflog(f'{overlay=}  {percent=}',1,1)
                    if add_rating_for_tmdb:
                        if overlay == 7 or percent and int(percent) > 40:
                        # if True:
                            cm.append(("Oceń odcinek", "RunPlugin(%s?action=add_rating&content=episode&tmdb=%s&season=%s&episode=%s)" % (sysaddon, tmdb, season, episode),))


                    art = {}
                    # na liście odcinków skórki szukają w kolejności: postera sezonu, a potem postera serialu. Na końcu (jak nie znajdą poprzednich), to wyświetlają poster przypisany do zmiennej poster
                    if "poster" in i and not i["poster"] == "0" or "tvshow.poster" in i or "season.poster" in i:
                        art.update({
                            "season.poster": i.get("season.poster") or i.get("poster") or "",  # ustawiamy poster sezonu (u mnie zmienna poster2)
                            "tvshow.poster": i.get("tvshow.poster") or i.get("poster") or "",  # ustawiamy poster serialu (u mnie zmienna poster1)
                            "poster": i.get("poster") or "",  # taki fallback, bo nie ma posteru odcinka raczej (u mnie zmienna poster)
                            })
                    else:
                        # art.update({"poster": addonPoster})  # plakatu chyba nie
                        # art.update({"poster": ""})
                        # art.pop("poster", None)
                        pass
                    # takie porządki
                    if art.get("poster") == "0":
                        art.pop("poster", None)
                    if art.get("tvshow.poster") == "0":
                        art.pop("tvshow.poster", None)
                    if art.get("season.poster") == "0":
                        art.pop("season.poster", None)

                    if "thumb" in i and not i["thumb"] == "0":
                        art.update({
                            "icon": i["thumb"],
                            "thumb": i["thumb"]
                            })
                    # elif "fanart" in i and not i["fanart"] == "0":
                        # art.update({
                            # "icon": i["fanart"],
                            # "thumb": i["fanart"]
                            # })
                    # elif "poster" in i and not i["poster"] == "0":
                        # art.update({
                            # "icon": i["poster"],
                            # "thumb": i["poster"]
                            # })
                    else:
                        art.update({"icon": addonFanart, "thumb": addonFanart})
                        # art.update({"icon": "", "thumb": ""})
                        # art.pop("icon", None)
                        # art.pop("thumb", None)
                        pass
                    art["icon"] = re.sub(r'(/t/p/w)\d{3,4}/', r'\g<1>200/', art.get("icon") or "")
                    art["thumb"] = re.sub(r'(/t/p/w)\d{3,4}/', r'\g<1>200/', art.get("thumb") or "")
                    if not art["thumb"]:
                        art.pop("thumb", None)
                        pass
                    if not art["icon"]:
                        art.pop("icon", None)
                        pass

                    if "fanart" in i and not i["fanart"] == "0":
                        art.update({"fanart": i["fanart"]})

                    if "banner" in i and not i["banner"] == "0":
                        art.update({"banner": i["banner"]})
                    elif "fanart" in i and not i["fanart"] == "0":
                        # art.update({"banner": i["fanart"]})
                        pass
                    else:
                        art.update({"banner": addonBanner})
                        # art.update({"banner": ""})
                        # art.pop("banner", None)
                        pass

                    if "tvshow.banner" in i and not i["tvshow.banner"] == "0":
                        art.update({"tvshow.banner": i["tvshow.banner"]})

                    if "season.banner" in i and not i["season.banner"] == "0":
                        art.update({"season.banner": i["season.banner"]})

                    if "landscape" in i and not i["landscape"] == "0":
                        art.update({"landscape": i["landscape"]})

                    if "tvshow.landscape" in i and not i["tvshow.landscape"] == "0":
                        art.update({"tvshow.landscape": i["tvshow.landscape"]})

                    if "season.landscape" in i and not i["season.landscape"] == "0":
                        art.update({"season.landscape": i["season.landscape"]})

                    if "clearlogo" in i and not i["clearlogo"] == "0":
                        art.update({"clearlogo": i["clearlogo"]})
                        art.update({"tvshow.clearlogo": i["clearlogo"]})  # to jest ważniejsze dla skórki (tak są napisane warunki sprawdzające)

                    if "clearart" in i and not i["clearart"] == "0":
                        art.update({"clearart": i["clearart"]})

                    if "keyart" in i and not i["keyart"] == "0":
                        art.update({"keyart": i["keyart"]})

                    """
                    if "characterart" in i and not i["characterart"] == "0":
                        art.update({"characterart": i["characterart"]})
                    """
                    if "characterart" in i and not i["characterart"] == "0":
                        characterart = i["characterart"]
                        if isinstance(characterart, list):
                            for an in range(0, len(characterart)):
                                # art[f"characterart{an+1}"] = characterart[an]
                                art.update({f"characterart{an+1}": characterart[an]})
                                # art.update({f"tvshow.characterart{an+1}": characterart[an]})
                        else:
                            # art["characterart"] = characterart
                            art.update({"characterart": characterart})
                            # art.update({"tvshow.characterart": characterart})


                    # fflog(f'{art=}',1,1)
                    if art:
                        item.setArt(art)

                    if settingFanart == "true" and "fanart" in i and not i["fanart"] == "0":
                        item.setProperty("Fanart_Image", i["fanart"])  # czy to nie dla jakiejś starszej wersji Kodi ?
                    elif not addonFanart is None:
                        # item.setProperty("Fanart_Image", addonFanart)  # j.w.
                        pass

                    # fflog(f'{addonFanart=}')
                    # fflog(f'{addonPoster=}')

                    # obsada
                    castwiththumb = i.get("castwiththumb")
                    if castwiththumb and not castwiththumb == "0":
                        # item.setCast(castwiththumb)
                        castwiththumb = [Actor(**a) for a in castwiththumb]
                        # vtag = item.getVideoInfoTag()
                        vtag.setCast(castwiththumb)

                    # meta.pop("imdb", None)
                    # meta.pop("tmdb_id", None)
                    # meta.pop("imdb_id", None)
                    # meta.pop("poster", None)
                    # meta.pop("clearlogo", None)
                    # meta.pop("clearart", None)
                    # meta.pop("fanart", None)
                    # meta.pop("fanart2", None)
                    # meta.pop("imdb", None)
                    # meta.pop("tmdb", None)
                    # meta.pop("metacache", None)
                    # meta.pop("poster2", None)
                    # meta.pop("poster3", None)
                    # meta.pop("banner", None)
                    # meta.pop("next", None)
                    # meta.pop("tvdb", None)
                    # meta.pop("tvdb_id", None)
                    # meta.pop("banner2", None)
                    # meta.pop("label", None)
                    # meta.pop("thumb", None)


                    item.setInfo(type="Video", infoLabels=control.metadataClean(meta))
                    # fflog(f'metadataClean={json.dumps(control.metadataClean(meta), indent=2)}',1,1)

                    # vtag.setTitle( meta.get("title") )
                    # if meta.get("year"):  vtag.setYear( int( meta.get("year") ) )
                    # vtag.setPlot( meta.get("plot") or "" )
                    # if meta.get("season"): vtag.setSeason( int(meta.get("season")) )
                    # if meta.get("episode"): vtag.setEpisode( int(meta.get("episode")) )
                    # vtag.setPremiered(  )
                    # vtag.setDuration(  )
                    # pewnie trzeba jeszcze więcej dorobić

                    # korekta pod standard ListItem (bo super_info.py inaczej generuje)
                    item.setInfo(type="Video", infoLabels={'TvShowTitle': meta.get("localtvshowtitle") or meta.get("tvshowtitle", "")})
                    # vtag.setTvShowTitle( meta.get("localtvshowtitle") or meta.get("tvshowtitle", "") )  # nie wiem, czy to dopiero nie od Kodi 20
                    item.setProperty("englishTvShowTitle", meta.get("englishtvshowtitle") or meta.get("tvshowtitle", ""))
                    #item.setProperty("OriginalTvShowTitle", meta.get("originaltvshowtitle") or meta.get("tvshowtitle", ""))
                    item.setProperty("OriginalTvShowTitle", meta.get("originaltvshowtitle") or "")
                    item.setProperty("TvShowYear", meta.get("tvshowyear") or meta.get("year", ""))

                    if generate_short_path:
                        # fflog(f'{imdb=} {tmdb=} {tvdb=} {i["label"]=}')
                        try:
                            # vtag = item.getVideoInfoTag()  # przeniosłem wyżej
                            vtag.setUniqueIDs({
                                'imdb' : imdb, 
                                'tmdb' : tmdb, 
                                'tvdb' : tvdb,
                            })
                        except Exception:
                            item.setProperty("imdb_id", imdb)
                            item.setProperty("tmdb_id", tmdb)
                            item.setProperty("tvdb_id", tvdb)

                        item.setProperty("meta", json.dumps(meta))
                        item.setProperty("fullpath", fullpath)

                    # video_streaminfo = {"codec": "h264"};
                    # item.addStreamInfo("video", video_streaminfo)  # czy to w czymś pomaga?

                    # item.setProperty("IsPlayable", isPlayable)
                    if not disp and not dont_use_setResolvedUrl:
                    # if not disp:
                        isPlayable = "true"  # umożliwi używanie setResolvedUrl nawet dla okienka (ale chyba w przypadku rezygnacji z odtwarzania pojawi się błąd Kodi "nieudane odtwarzanie")
                        # isPlayable = "false"  # wymuszenie (tak było kiedyś)
                    else:
                        isPlayable = "false"  # aby nie było komunikatów o nieudanym odtwarzaniu
                    if isPlayable == "true":  # kiedyś nie warto było ustawiać "false"
                        item.setProperty("IsPlayable", isPlayable)
                    # fflog(f'{isPlayable=} for {title=}',1,1)

                    if yatse:
                        vtag.setMediaType('video')  # yatse źle interpretuje element, gdy jest podany jako typ Movie, tzn. nie chce wyświetlać źródeł, jeśli mają być wyświetlone w katalogu (na fonie)

                    item.addContextMenuItems(cm)  # dodanie menu kontekstowego

                    control.addItem(handle=syshandle, url=url, listitem=item, isFolder=disp)  # dodanie całej pozycji do listy katalogu Kodi

                    counter += 1
                except Exception:
                    fflog_exc(1)
                    pass
            # fflog(f'{counter=}',1,1)

            params = dict(parse_qsl(sys.argv[2][1:]))
            updateListing = True if params.get("r") else False  # True świadczy, że po drodze było odświeżanie
            try:
                # cat_label = items[0]["tvshowtitle"]
                # fflog(f'{items[0]=}',1,1)
                # fflog(f'{meta=}',1,1)
                cat_label = meta.get("localtvshowtitle") or meta.get("tvshowtitle")
                if meta.get("tvshowyear") and cat_label:
                    cat_label += f' ({meta.get("tvshowyear")})'
                    pass
                # if sa_sezony:  # nie wiem, skąd wziąść informacje o ilości wszystkich sezonów
                cat_label += f' / Sezon {items[0]["season"]}'
                if cat_label:
                    control.pluginCategory(syshandle, cat_label)
                    pass
            except Exception:
                fflog_exc(1)
                pass
            control.content(syshandle, "episodes")
            control.directory(syshandle, cacheToDisc=cacheToDisc, updateListing=updateListing)
            views.setView("episodes")


            # eksperyment
            fflog('sprawdzenie istnienia znacznika ustawionego w player.py dla autoodtwarzania następnego odcinka',1,1)
            if temp := control.window.getProperty('FanFilm.var.url.autoplay.next_episode'):
                control.window.clearProperty('FanFilm.var.url.autoplay.next_episode')

                if "|" in temp:
                    temp = temp.split("|")
                    import time
                    if ( int(time.time()) - int(temp[1]) ) < 10:  # 10 sekund
                        temp = temp[0]
                    else:
                        temp = None
                        fflog('znacznik przeterminowany')
                autoplay_next_episode = temp

                if autoplay_next_episode:
                    control.sleep(100)
                    fflog("Autoodtwarzanie następnego odcinka serialu (funkcja FanFilm)",1,1)

                    # c = 10
                    if control.window.getProperty("fanfilm.addRating_in_progress"):
                        fflog('oczekiwanie na zakończenie wystawiania oceny dla TMDB',1,1)
                        control.sleep(4000)
                        pass
                    while (
                            control.window.getProperty("fanfilm.addRating_in_progress")
                            # and c > 0
                        ):
                        fflog('oczekiwanie na zakończenie wystawiania oceny dla TMDB',0,1)
                        control.sleep(500)
                        # c -= 1

                    focus_panel_id = control.getCurrentViewId()  # focus_panel_id
                    # fflog(f"{focus_panel_id=}", 1,1)

                    fflog("przesunięcie na kolejną pozycję",1,1)
                    control.execute(f'Control.Message({focus_panel_id},moveup)')
                    control.sleep(100)  # musi być jakaś zwłoka
                    new_focused_label = control.infoLabel('ListItem.Label')
                    if new_focused_label == "..":
                        fflog(f'{new_focused_label=}',1,1)
                        autoplay_next_episode = False

                    if autoplay_next_episode:
                        label = control.infoLabel('ListItem.Label')
                        fflog(f'{label=}',1,1)
                        label = f"[B]{label}[/B]"

                        if 0:  # problem, gdy czas minie, bo nie wiadomo, czy zamknięcie nastąpiło z powodu upływu czasu
                            yes = control.yesnoDialog("czy chcesz odtworzyć\n\n"+label+" ?", heading="FF - Autoodtwarzanie kolejnego odcinka", autoclose=0*1000)
                        else:
                            progressDialog = (
                                control.progressDialog
                                if control.setting("progress.dialog") == "0"
                                else control.progressDialogBG
                            )
                            progressDialog.create("FF - Autoodtwarzanie kolejnego odcinka", label)
                            yes = True
                            c = 0
                            while True and c <= 100:
                                progressDialog.update(c)
                                if c >= 100:
                                    control.sleep(100)
                                    break
                                control.sleep(1000)
                                c += 10
                                try:  # bo progressDialogBG nie ma takiej metody
                                    if progressDialog.iscanceled():
                                        yes = False
                                        progressDialog.close()
                                        break
                                except:
                                    pass
                            try:
                                progressDialog.close()
                            except:
                                pass

                        if yes:
                            # fflog(f"{control.infoLabel('Window.Property(xmlfile)')=}", 1,1)  # nieprzydatne
                            fflog(f"{control.currentDialogId()=}", 1,1)  # https://kodi.wiki/view/Window_IDs
                            # control.sleep(300)  # musi być zwłoka na zamknięcie animacji okienka (dialogu)

                            c = 6
                            while control.condVisibility('Window.IsVisible(progressdialog)') and c > 0:  # Returns true if the window is visible (includes fade out time on dialogs)
                                # fflog("oczekiwanie na zniknięcie progressdialog'u",1,1)
                                control.sleep0(100)
                                c -= 1

                            fflog('akcja Play',1,1)
                            control.execute('Action(Play)')
                        else:
                            fflog('nastąpiła rezygnacja',1,1)
                            pass
                    else:
                        fflog('to był ostatni odcinek na liście',1,1)
                        pass


        def addDirectory(self, items, queue=False, add_refresh=False, category=""):
            fflog(f'[addDirectory]')

            if items is None or len(items) == 0:
                return  #  ; sys.exit()

            sysaddon = sys.argv[0]
            syshandle = int(sys.argv[1])

            PluginName = control.infoLabel("Container.PluginName")
            # PluginName = PluginName == "plugin.video.kadrplus"  # nie wiem, czy to potrzebne
            # fflog(f'{PluginName=}',1,1)

            addonFanart, addonThumb, artPath = (control.addonFanart(), control.addonThumb(), control.artPath(),)
            queueMenu = control.lang(32065)
            generate_short_path = control.setting("generate_short_path") == "true"

            # Spis... czego właściwie? do kalendarza ?
            # addSortMethod(syshandle, sortMethod=SORT_METHOD_UNSORTED)
            for i in items:
                try:
                    name = i["name"]

                    if i["image"].startswith("http"):
                        thumb = i["image"]
                    elif not artPath is None:
                        thumb = os.path.join(artPath, i["image"])
                    else:
                        thumb = addonThumb

                    # create ListItem
                    try:
                        item = control.item(label=name, offscreen=True)
                    except:
                        item = control.item(label=name)

                    item.setArt({"icon": thumb, "thumb": thumb, "fanart": addonFanart})

                    i["url"] = re.sub("(?<=api_key=)[^&]*", "", i["url"])

                    log_utils.fflog(f'{i["action"]=}', 0)  # nie wiem jakie mogą być
                    url = "{}?action={}".format(sysaddon, i["action"])
                    try:
                        if not generate_short_path or i["action"] not in ["calendar"]:
                            url += "&url=%s" % quote_plus(i["url"])
                        else:
                            item.setProperty("url", i["url"])
                            item.setProperty("urlD", i["url"])
                    except Exception:
                        pass

                    cm = []
                    if queue:
                        cm.append((queueMenu, "RunPlugin(%s?action=queueItem)" % sysaddon))
                    if add_refresh:
                        # if PluginName:
                        cm.append(("Odśwież teraz", "Container.Update(%s&refresh=1)" % url))
                    item.addContextMenuItems(cm)

                    control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
                except Exception:
                    fflog_exc(1)
                    pass

            # czy potrzebna także następna strona ?

            params = dict(parse_qsl(sys.argv[2][1:]))
            updateListing = True if params.get("r") else False  # True świadczy, że po drodze było odświeżanie
            if category:
                control.pluginCategory(syshandle, category)
            # control.content(syshandle, "addons")
            control.directory(syshandle, cacheToDisc=True, updateListing=updateListing)
            views.setView("addons")  # dodatkowa funkcja FanFilm


    return episodes()