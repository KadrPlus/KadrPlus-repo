# -*- coding: utf-8 -*-
"""
Kadr+ - źródło: ogladaj.cc (tylko filmy)
Portowane z FanFilm 2026-04-26 do architektury ptw.

Flow:
  1. POST /engine/ajax/controller.php?mod=search  (IMDB ID → URL strony)
  2. GET strona filmu                              (iframe csst.online/embed/{id})
  3. GET secvideo1.online/embed/{id}/             (Playerjs file=[360p]url,[720p]url,[1080p]url)
  4. GET get_file URL → 302 → CDN URL (MP4 360p/720p/1080p)
"""

from __future__ import annotations

import re
from urllib.parse import urlencode, parse_qs, quote_plus

import requests as _requests

from ptw.libraries.log_utils import fflog
from ptw.debug import fflog_exc

_BASE       = 'https://ogladaj.cc'
_SEARCH_URL = _BASE + '/engine/ajax/controller.php?mod=search'
_SECVIDEO   = 'https://secvideo1.online'
_UA         = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0'

_HEADERS = {
    'User-Agent': _UA,
    'Referer': _BASE + '/',
    'X-Requested-With': 'XMLHttpRequest',
}

_GUEST_HASH_CACHE: list = []


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['pl']
        self.domains  = ['ogladaj.cc']

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        try:
            if not imdb:
                return None
            return urlencode({'imdb': imdb})
        except Exception:
            fflog_exc(1)
            return None

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        return None  # tylko filmy

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        return None  # tylko filmy

    def sources(self, url, hostDict=None, hostprDict=None):
        result = []
        try:
            if not url:
                return result

            imdb = (parse_qs(url).get('imdb') or [''])[0]
            if not imdb:
                return result

            sess = _requests.Session()
            sess.headers.update({'User-Agent': _UA})

            # 1. Guest hash
            user_hash = self._get_guest_hash(sess)
            if not user_hash:
                fflog('[ogladajcc] brak dle_login_hash')
                return result

            # 2. Szukaj po IMDB ID
            fflog(f'[ogladajcc] query: {imdb!r}')
            resp = sess.post(
                _SEARCH_URL,
                data={'query': imdb, 'user_hash': user_hash},
                headers=_HEADERS,
                timeout=10,
            )
            m = re.search(r'href="((?:https://ogladaj\.cc)?/film/[^"]+)"', resp.text)
            if not m:
                fflog('[ogladajcc] search: 0 results')
                return result
            film_url = m.group(1)
            if film_url.startswith('/'):
                film_url = _BASE + film_url
            fflog('[ogladajcc] search: 1 result')

            # 3. Strona filmu → iframe csst/fsst
            film_html = sess.get(film_url, headers={'User-Agent': _UA}, timeout=10).text

            seen_ids = set()
            for embed_match in re.finditer(r'(?:csst|fsst)\.online/embed/([0-9]+)/', film_html):
                csst_id = embed_match.group(1)
                if csst_id in seen_ids:
                    continue
                seen_ids.add(csst_id)

                # Wykryj język z kontekstu przed iframe (~500 znaków)
                ctx = film_html[max(0, embed_match.start() - 500):embed_match.start()].lower()
                if 'dubbing' in ctx:
                    lang, info = 'pl', 'dubbing'
                elif 'lektor' in ctx:
                    lang, info = 'pl', 'lektor'
                elif 'napisy' in ctx or 'subtitle' in ctx:
                    lang, info = 'en', 'napisy'
                else:
                    lang, info = 'pl', ''

                fflog(f"[ogladajcc] csst_id={csst_id} info={info or '?'}")

                # 4. Embed secvideo1.online → Playerjs file
                embed_url = f'{_SECVIDEO}/embed/{csst_id}/'
                try:
                    embed_html = sess.get(
                        embed_url,
                        headers={'User-Agent': _UA, 'Referer': film_url},
                        timeout=10,
                    ).text
                except Exception:
                    fflog_exc(1)
                    continue

                # Format 1: [360p]url,[720p]url,...
                fm = re.search(r'file\s*:\s*"(\[\d+p\]https?://[^"]+)"', embed_html, re.S)
                if fm:
                    files = self._parse_playerjs_files(fm.group(1))
                    for quality in ('1080p', '720p', 'SD'):
                        if quality in files:
                            result.append({
                                'source':    'ogladaj',
                                'url':       files[quality],
                                'quality':   quality,
                                'language':  lang,
                                'info':      info,
                                'direct':    False,
                                'debridonly': False,
                            })
                            break
                    continue

                # Format 2: file:"https://.../_NNNp.mp4/" (single URL)
                for single_m in re.finditer(r'file\s*:\s*"(https?://[^"]+)"', embed_html):
                    file_url = single_m.group(1).rstrip('/')
                    q_m = re.search(r'[_-](\d+p)\.', file_url)
                    raw_q   = q_m.group(1) if q_m else 'SD'
                    quality = raw_q if raw_q in ('1080p', '720p') else 'SD'
                    result.append({
                        'source':    'ogladaj',
                        'url':       file_url,
                        'quality':   quality,
                        'language':  lang,
                        'info':      info,
                        'direct':    False,
                        'debridonly': False,
                    })
                    fflog(f'[ogladajcc] single-url quality={quality} csst_id={csst_id}')
                    break

                if not result:
                    fflog(f'[ogladajcc] brak Playerjs file dla csst_id={csst_id}')

            if not result:
                fflog(f'[ogladajcc] brak iframe csst/fsst na {film_url}')

        except Exception:
            fflog_exc(1)

        fflog(f'[ogladajcc] sources: {len(result)}')
        return result

    def resolve(self, url):
        """Podąż za redirect get_file → CDN MP4."""
        try:
            sess = _requests.Session()
            sess.headers.update({'User-Agent': _UA, 'Referer': _SECVIDEO + '/'})
            resp = sess.get(url, allow_redirects=False, timeout=10)
            if resp.status_code in (301, 302):
                cdn_url = resp.headers.get('Location', '')
                if cdn_url:
                    return f'{cdn_url}|Referer={_SECVIDEO}/&User-Agent={quote_plus(_UA)}'
        except Exception:
            fflog_exc(1)
        return url

    # ── helpers ────────────────────────────────────────────────────────────

    @staticmethod
    def _get_guest_hash(sess):
        if _GUEST_HASH_CACHE:
            return _GUEST_HASH_CACHE[0]
        html = sess.get(_BASE + '/', headers={'User-Agent': _UA}, timeout=10).text
        m = re.search(r"dle_login_hash\s*=\s*'([a-f0-9]+)'", html)
        if m:
            _GUEST_HASH_CACHE.append(m.group(1))
            return m.group(1)
        return ''

    @staticmethod
    def _parse_playerjs_files(file_str):
        """Parsuje '[360p]url,[720p]url,...' → {'360p': url, ...}"""
        result = {}
        for m in re.finditer(r'\[(\d+p)\](https?://[^,\[]+)', file_str):
            result[m.group(1)] = m.group(2).rstrip('/')
        return result
