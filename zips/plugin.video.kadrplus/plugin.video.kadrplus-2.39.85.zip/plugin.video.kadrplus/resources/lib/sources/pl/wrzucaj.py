# -*- coding: UTF-8 -*-
"""
Scraper dla wrzucaj.pl
Oparty na scraperze z FanFilm Beta (MIT license, created in cooperation with wrzucaj.pl owner).

Dwa providery:
  wrzucaj   - wyszukiwanie wideo (wrzucaj.pl/videos), bezpośrednie CDN URL
  wrzucaj2  - wyszukiwanie plików (/ajax/search), resolving przez file_details (tylko zalogowani)
"""
import re
import json
import time
import hashlib
from urllib.parse import quote_plus, unquote_plus, urlparse, parse_qs, quote
from html import unescape

import xbmcgui
from ptw.libraries import control, source_utils, cleantitle
from ptw.libraries import cache
from ptw.debug import fflog, fflog_exc

import urllib3
urllib3.disable_warnings()

COOKIE_EXPIRATION_HOURS = 3
_CACHE_KEY_PREFIX = 'wrzucaj_session'
_FF_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0'

# KADR+ 2.39.77: matching helpers ported/simplified from new FanFilm wrzucaj.
_RE_EXT_STRIP = re.compile(r'\.\w{2,4}$')
_RE_GROUP_TAG = re.compile(r'^\s*\[[^\]]+\]\s*')
_RE_TITLE_TRAIL = re.compile(
    r'\s+(?:MULTi|MULTI|PLDUB|PLSUB|WEB[- ]?DL|WEBRip|BluRay|BDRip|BRRip|Blu\b|HDTV|'
    r'TELESYNC|HDCAM|TS\b|CAM\b|HDR|SDR|UHD|4K|2160p|1080p|720p|480p|'
    r'BD\b|DVD|PROPER|REPACK|RETAIL|EXTENDED|x264|x265|HEVC|AVC).*$',
    re.IGNORECASE,
)
_RE_ARTICLE = re.compile(r'^(the|a|an)\s+', re.I)
_RE_ROMAN = re.compile(r'\b(?:i|ii|iii|iv|v|vi|vii|viii|ix|x)\b', re.I)

def _levenshtein(a, b):
    if a == b:
        return 0
    la, lb = len(a), len(b)
    if abs(la - lb) > 2:
        return abs(la - lb)
    if la == 0:
        return lb
    if lb == 0:
        return la
    if la < lb:
        a, b, la, lb = b, a, lb, la
    prev = list(range(lb + 1))
    for i in range(1, la + 1):
        curr = [i] + [0] * lb
        for j in range(1, lb + 1):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            curr[j] = min(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
        prev = curr
    return prev[lb]

def _roman_to_int(s):
    vals = {'i': 1, 'v': 5, 'x': 10}
    total = prev = 0
    for ch in reversed(s.lower()):
        v = vals.get(ch, 0)
        if v < prev:
            total -= v
        else:
            total += v
            prev = v
    return total or s

def _is_episode_filename(filename):
    return bool(re.search(r'(?i)(?:s\d{1,2}\s*[.\-_ ]?e\d{1,3}|\b\d{1,2}x\d{1,3}\b|\bodc(?:inek)?\.?\s*\d{1,3}\b)', filename or ''))



def _parse_qs_single(url_str):
    return {k: v[0] for k, v in parse_qs(urlparse(url_str).query).items()}


def _size_to_mb(val, unit):
    unit = unit.upper()
    if unit == 'TB': return int(val * 1024 * 1024)
    if unit == 'GB': return int(val * 1024)
    if unit == 'MB': return int(val)
    return int(val / 1024)


def _format_size(size_mb):
    if size_mb <= 0: return ''
    return '{:.2f} GB'.format(size_mb / 1024) if size_mb >= 1024 else '{} MB'.format(size_mb)


# =============================================================================
# HTTP klient — wspólny dla obu providerów
# =============================================================================

class _WrzucajClient:

    LOGIN_URL        = 'https://wrzucaj.pl/account/login'
    SEARCH_URL       = 'https://wrzucaj.pl/ajax/search'
    ACCOUNT_URL      = 'https://wrzucaj.pl/account'
    ACCOUNT_EDIT_URL = 'https://wrzucaj.pl/account/edit'

    RE_BADGE        = re.compile(r'badge-roundless\">\s*([^<]+)<')
    RE_FILE_URL     = re.compile(r'href="(https://wrzucaj\.pl/([a-f0-9]{12,32})/([^"]+))"')
    RE_FILESIZE     = re.compile(r'(?:Filesize|Rozmiar pliku):\s*([\d.]+)\s*([TGMK]B)', re.IGNORECASE)
    RE_NUMERIC_ID   = re.compile(r'showFileInformation\((\d+)')
    RE_CDN_PLAYER   = re.compile(r'"(https://s\d+\.wrzucaj\.pl/[a-f0-9]{12,32}/[^"]+\?download_token=[a-f0-9]+)"')
    RE_CDN_DOWNLOAD = re.compile(r"openUrl\('(https://(?:s\d+\.)?wrzucaj\.pl/[a-f0-9]{12,32}/[^']+\?download_token=[a-f0-9]+)'")
    RE_FILESIZE_DETAIL = re.compile(r'(?:Filesize|Rozmiar[^<]{0,20}):(?:&nbsp;|\s)+([\d.]+)(?:&nbsp;|\s)+([TGMK]B)', re.IGNORECASE)
    RE_TRANSFER_GB  = re.compile(r'tile-stats[^>]*tile-green[^>]*>.*?data-end="([\d.]+)".*?(?:Available transfer|Dostępny transfer)', re.DOTALL | re.IGNORECASE)
    RE_HISTORY_ROW  = re.compile(
        r'<td>(\d{2}\.\d{2}\.\d{4} - \d{2}:\d{2}:\d{2})</td>.*?href="(https://wrzucaj\.pl/([a-f0-9]{12,32})/[^"]+)"',
        re.DOTALL
    )

    def __init__(self):
        import requests as req
        self.session = req.Session()
        self.session.verify = False
        self.session.headers.update({
            'User-Agent':      _FF_UA,
            'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'Referer':         'https://wrzucaj.pl/',
        })

    def set_cookies(self, cookie_str):
        self.session.cookies.clear()
        for part in cookie_str.split('; '):
            if '=' in part:
                name, value = part.split('=', 1)
                self.session.cookies.set(name, value)

    def get_cookies(self):
        return '; '.join('{}={}'.format(n, v) for n, v in self.session.cookies.items())

    def login(self, username, password):
        self.session.get(self.LOGIN_URL, verify=False)
        resp = self.session.post(
            self.LOGIN_URL,
            data={'username': username, 'password': password, 'rememberme': '1', 'submitme': '1'},
            headers={'Referer': self.LOGIN_URL},
            verify=False, allow_redirects=True,
        )
        # Sprawdzamy różne wskaźniki udanego logowania
        logged = (
            'LOGGED_IN = true' in resp.text
            or bool(self.session.cookies.get('wB'))
            or bool(self.session.cookies.get('wrzucaj_session'))
            or 'logout' in resp.text.lower()
            or 'wyloguj' in resp.text.lower()
            or '/account/logout' in resp.text
        )
        fflog(f'[wrzucaj] login status={resp.status_code} logged={logged} cookies={list(self.session.cookies.keys())}', 1)
        return logged

    def check_premium(self):
        try:
            page = self.session.get(self.ACCOUNT_URL, verify=False, timeout=10).text
            m = self.RE_BADGE.search(page)
            if m and 'PREMIUM' in m.group(1).upper():
                return 'premium'
        except Exception:
            fflog_exc(1)
        return 'free'

    def search_files(self, query, max_results=100):
        params = {
            'sEcho': '1', 'iColumns': '2', 'sColumns': '',
            'iDisplayStart': '0', 'iDisplayLength': str(max_results),
            'sSearch': '', 'bRegex': 'false',
            'bSearchable_0': 'true', 'bSearchable_1': 'true',
            'iSortingCols': '0', 'filterText': query, 'filterType': 'videos',
        }
        try:
            resp = self.session.get(
                self.SEARCH_URL, params=params,
                headers={
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json, text/javascript, */*; q=0.01',
                    'Referer': 'https://wrzucaj.pl/search',
                },
                verify=False, timeout=15,
            )
            fflog('[wrzucaj2] search HTTP {} len={}'.format(resp.status_code, len(resp.text)), 1)
            if not resp.text.strip():
                return []
            results = []
            for row in resp.json().get('aaData', []):
                if not isinstance(row, (list, tuple)) or not row:
                    continue
                m = self.RE_FILE_URL.search(row[0])
                if not m:
                    continue
                file_size_mb = 0
                sm = self.RE_FILESIZE.search(row[0])
                if sm:
                    file_size_mb = _size_to_mb(float(sm.group(1)), sm.group(2))
                results.append({
                    'file_id': m.group(2),
                    'dl_page_url': m.group(1),
                    'filename': unescape(m.group(3)).strip(),
                    'file_size_mb': file_size_mb,
                })
            fflog('[wrzucaj2] search {!r} → {} wynikow'.format(query, len(results)), 1)
            return results
        except Exception:
            fflog_exc(1)
            return []

    def get_file_details(self, dl_page_url):
        result = {'cdn_url': None, 'filesize_mb': 0}
        try:
            resp = self.session.get(dl_page_url, verify=False, timeout=20)
            m = self.RE_NUMERIC_ID.search(resp.text)
            if not m:
                fflog('[wrzucaj2] brak numericId dla {!r}'.format(dl_page_url), 1)
                return result
            numeric_id = m.group(1)
            resp2 = self.session.post(
                '{}/ajax/file_details'.format(self.ACCOUNT_URL),
                data={'u': numeric_id, 'p': 'true'},
                headers={
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json, text/javascript, */*; q=0.01',
                    'Referer': quote(dl_page_url, safe=':/?#[]@!$&\'()*+,;=%'),
                },
                verify=False, timeout=20,
            )
            data = resp2.json()
            html = data.get('html', '')
            cdn_m = self.RE_CDN_PLAYER.search(html) or self.RE_CDN_DOWNLOAD.search(html)
            if cdn_m:
                result['cdn_url'] = cdn_m.group(1)
            sm = self.RE_FILESIZE_DETAIL.search(html)
            if sm:
                result['filesize_mb'] = _size_to_mb(float(sm.group(1)), sm.group(2))
        except Exception:
            fflog_exc(1)
        return result

    def get_transfer_and_history(self):
        """Zwraca (remaining_mb, history_dict)"""
        try:
            html = self.session.get(self.ACCOUNT_EDIT_URL, verify=False, timeout=15).text
            # transfer
            tm = self.RE_TRANSFER_GB.search(html)
            remaining_mb = int(float(tm.group(1)) * 1024) if tm else -1
            # historia (pliki pobrane w ciągu 6h - bez kosztu transferu)
            history = {}
            idx = html.find('id="downloadHistory"')
            if idx >= 0:
                from datetime import datetime, timedelta
                cutoff = datetime.now() - timedelta(hours=5, minutes=55)
                for rm in self.RE_HISTORY_ROW.finditer(html[idx:idx+30000]):
                    date_str, url, file_id = rm.group(1), rm.group(2), rm.group(3)
                    try:
                        dt = datetime.strptime(date_str, '%d.%m.%Y - %H:%M:%S')
                        if dt >= cutoff and file_id not in history:
                            history[file_id] = url
                    except ValueError:
                        pass
            fflog('[wrzucaj2] transfer={}MB history={} pliki'.format(remaining_mb, len(history)), 1)
            return remaining_mb, history
        except Exception:
            fflog_exc(1)
            return -1, {}


# =============================================================================
# Wspólna baza — logowanie z cache
# =============================================================================

class _WrzucajBase:

    PROVIDER = ''

    RE_FILENAME_YEAR     = re.compile(r'^(.+?)\s*\((\d{4})\)')
    RE_FILENAME_EP       = re.compile(r'[Ss](\d{1,2})[Ee](\d{1,2})')
    RE_FILENAME_YEAR_BARE = re.compile(
        r'^(.+?)\s+(\d{4})\s+(?:V\d+\s+)?'
        r'(?:MULTi|MULTI|PLDUB|PLSUB|WEB|BluRay|BDRip|BRRip|Blu\b|HDTV|'
        r'TELESYNC|HDCAM|TS\b|CAM\b|HDR|SDR|UHD|4K|2160p|1080p|720p|480p|'
        r'BD\b|DVD|PROPER|REPACK|RETAIL|EXTENDED|x264|x265|HEVC|AVC)',
        re.IGNORECASE,
    )

    def __init__(self):
        self.priority    = 1
        self.language    = ['pl']
        self._logged_in  = False
        self._tier       = 'free'
        self._client     = None
        self._session_initialized = False

    def _ensure_session(self):
        if self._session_initialized:
            return
        self._session_initialized = True
        self._client = _WrzucajClient()
        username = control.setting('wrzucaj.username').strip()
        password = control.setting('wrzucaj.password').strip()
        if not username or not password:
            fflog('[{}] brak danych logowania'.format(self.PROVIDER), 1)
            return
        try:
            pass_hash = hashlib.md5(password.encode()).hexdigest()[:8]
            cache_key = '{}_{}_{}'.format(_CACHE_KEY_PREFIX, username, pass_hash)
            cached = cache.cache_get(cache_key)
            if cached is not None:
                try:
                    # cache_get zwraca row: {'key':..., 'value':..., 'date':...}
                    row = dict(cached) if not isinstance(cached, dict) else cached
                    data = json.loads(row.get('value', '{}'))
                    cookie_str = data.get('cookies', '')
                    tier = data.get('tier', 'free')
                    ts = int(row.get('date', 0))
                    if cookie_str and (time.time() - ts) < COOKIE_EXPIRATION_HOURS * 3600:
                        self._client.set_cookies(cookie_str)
                        self._logged_in = True
                        self._tier = tier
                        fflog('[{}] sesja z cache, tier={}'.format(self.PROVIDER, tier), 1)
                        return
                except Exception:
                    pass
            # świeże logowanie
            fflog('[{}] loguję...'.format(self.PROVIDER), 1)
            if self._client.login(username, password):
                tier = self._client.check_premium()
                session_data = json.dumps({
                    'cookies': self._client.get_cookies(),
                    'tier': tier,
                })
                cache.cache_insert(cache_key, session_data)
                self._logged_in = True
                self._tier = tier
                fflog('[{}] zalogowano, tier={}'.format(self.PROVIDER, tier), 1)
            else:
                fflog('[{}] logowanie nieudane'.format(self.PROVIDER), 1)
        except Exception:
            fflog_exc(1)

    def _parse_filename(self, filename):
        norm = _RE_EXT_STRIP.sub('', filename or '').replace('.', ' ').replace('_', ' ')
        year_m = self.RE_FILENAME_YEAR.match(norm)
        ep_m   = self.RE_FILENAME_EP.search(norm)
        if year_m:
            title, year = year_m.group(1).strip(), int(year_m.group(2))
        elif ep_m:
            title, year = norm[:ep_m.start()].strip(), None
        else:
            bare_m = self.RE_FILENAME_YEAR_BARE.match(norm)
            title  = bare_m.group(1).strip() if bare_m else norm
            year   = int(bare_m.group(2)) if bare_m else None
        title = _RE_TITLE_TRAIL.sub('', title).strip()
        return {
            'title': title,
            'year': year,
            'season': int(ep_m.group(1)) if ep_m else None,
            'episode': int(ep_m.group(2)) if ep_m else None,
        }


    def _title_matches(self, candidate, alias_cleans):
        title = _RE_GROUP_TAG.sub('', candidate or '').strip()
        parts = [p.strip() for p in title.replace(': ', ' - ').split(' - ') if p.strip()]
        if not parts:
            return False

        for part in parts:
            variants = set([part])
            stripped = _RE_ARTICLE.sub('', part)
            if stripped != part:
                variants.add(stripped)

            all_variants = set()
            for v in variants:
                all_variants.add(v)
                roman_conv = _RE_ROMAN.sub(lambda m: str(_roman_to_int(m.group(0))), v)
                if roman_conv != v:
                    all_variants.add(roman_conv)

            for cv in all_variants:
                clean = cleantitle.get_simple(cv)
                if not clean:
                    continue
                if clean in alias_cleans:
                    return True
                if len(clean) >= 3 and any(_levenshtein(clean, a) <= 2 for a in alias_cleans if a):
                    return True

        # FanFilm fallback: PL + EN titles sometimes appear glued together,
        # e.g. "Maszyna do zabijania War Machine".
        full_clean = cleantitle.get_simple(' '.join(parts))
        def _ac_matches(segment):
            return segment in alias_cleans or (
                len(segment) >= 4 and any(_levenshtein(segment, a) <= 2 for a in alias_cleans if a)
            )
        for ac in alias_cleans:
            if not ac or len(ac) < 4:
                continue
            if full_clean.startswith(ac):
                rest = full_clean[len(ac):]
                if rest and _ac_matches(rest):
                    return True
            if full_clean.endswith(ac):
                prefix = full_clean[:-len(ac)]
                if prefix and _ac_matches(prefix):
                    return True
        return False


    def _build_alias_cleans(self, title, localtitle):
        alias_cleans = set()
        for t in filter(None, (title, localtitle)):
            c = cleantitle.get_simple(t)
            if c:
                alias_cleans.add(c)
            for sep in (' - ', ': ', '-'):
                for part in t.split(sep):
                    cp = cleantitle.get_simple(part.strip())
                    if cp and len(cp) >= 3:
                        alias_cleans.add(cp)
            if ': ' in t:
                head, _, tail = t.partition(': ')
                cr = cleantitle.get_simple(tail + ' ' + head)
                if cr:
                    alias_cleans.add(cr)
        return alias_cleans


    def _url_with_headers(self, cdn_url):
        return '{}|User-Agent={}&Referer=https://wrzucaj.pl/'.format(cdn_url, _FF_UA)

    def resolve(self, url):
        return url


# =============================================================================
# provider: wrzucaj  (wideo — bezpośrednie CDN URL)
# =============================================================================

class source(_WrzucajBase):
    """Provider wrzucaj — wyszukiwanie przez /videos, zwraca bezpośrednie CDN URL."""

    PROVIDER = 'wrzucaj'

    RE_VIDEO_CARD = re.compile(r'href="(/watch/(\d+)/([^"]+))"')
    RE_SOURCE_TAG = re.compile(
        r'<source\s[^>]*src="([^"]+)"[^>]*size="(\d+)"[^>]*label="([^"]+)"',
        re.DOTALL,
    )

    def __init__(self):
        super().__init__()
        self._subtitle_map = {}

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        local = localtitle if localtitle and localtitle.lower() != title.lower() else ''
        fflog('[wrzucaj] movie: {!r}'.format(title), 1)
        return 'https://wrzucaj.pl/videos?search={}&_title={}&_year={}&_local={}'.format(
            quote_plus(title), quote_plus(title), year or '', quote_plus(local))

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        local = localtvshowtitle if localtvshowtitle and localtvshowtitle.lower() != tvshowtitle.lower() else ''
        return json.dumps({'title': tvshowtitle, 'local': local, 'year': year or ''})

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        try:
            show = json.loads(url)
        except Exception:
            return None
        local = show.get('local', '')
        fflog('[wrzucaj] episode: {!r} S{}E{}'.format(show['title'], season, episode), 1)
        return 'https://wrzucaj.pl/videos?search={}&_title={}&_year={}&_season={}&_episode={}&_local={}'.format(
            quote_plus(show['title']), quote_plus(show['title']), show.get('year', ''),
            int(season), int(episode), quote_plus(local))

    def sources(self, url, hostDict, hostprDict):
        result = []
        try:
            if not url: return result
            self._ensure_session()
            if not self._logged_in:
                fflog('[wrzucaj] nie zalogowano', 1)
                return result

            params     = _parse_qs_single(str(url))
            query      = params.get('search', '')
            item_title = unquote_plus(params.get('_title', ''))
            item_local = unquote_plus(params.get('_local', ''))
            item_year  = params.get('_year') or None
            want_s     = int(params['_season'])  if '_season'  in params else None
            want_e     = int(params['_episode']) if '_episode' in params else None

            if not query: return result
            fflog('[wrzucaj] query={!r} year={} s={} e={} tier={}'.format(query, item_year, want_s, want_e, self._tier), 1)

            alias_cleans = self._build_alias_cleans(item_title, item_local)

            queries = []
            for _q in (query, item_local, re.sub(r"[:'\"]+", '', query).strip()):
                if _q and _q.lower() not in [x.lower() for x in queries]:
                    queries.append(_q)
            if item_year and want_s is None:
                _qy = '{} {}'.format(query, item_year)
                if _qy.lower() not in [x.lower() for x in queries]:
                    queries.append(_qy)

            seen_ids = set()
            for q in queries:
                try:
                    clean = re.sub(r"[:'\"]+", '', q).strip()
                    page  = self._client.session.get(
                        'https://wrzucaj.pl/videos?search={}'.format(quote_plus(clean)),
                        verify=False, timeout=15
                    ).text
                    cards = [
                        {'file_id': fid, 'watch_url': 'https://wrzucaj.pl' + path, 'filename': unescape(fname).strip()}
                        for path, fid, fname in self.RE_VIDEO_CARD.findall(page)
                    ]
                    fflog('[wrzucaj] search {!r} → {} wynikow'.format(q, len(cards)), 1)
                except Exception:
                    fflog_exc(1)
                    continue

                for card in cards:
                    if card['file_id'] in seen_ids: continue
                    parsed = self._parse_filename(card['filename'])

                    title_parts = [p.strip() for p in parsed['title'].split(' - ') if p.strip()]
                    if alias_cleans and not any(self._title_matches(p, alias_cleans) for p in title_parts):
                        fflog('[wrzucaj] pomiń (tytuł) {!r}'.format(card['filename']), 1)
                        continue
                    if item_year and parsed['year'] and abs(int(item_year) - parsed['year']) > 1:
                        fflog('[wrzucaj] pomiń (rok) {!r}'.format(card['filename']), 1)
                        continue
                    if want_s is None and _is_episode_filename(card['filename']):
                        if item_year and re.search(r'\\b{}\\b'.format(re.escape(str(item_year))), card['filename']):
                            pass
                        else:
                            fflog('[wrzucaj] pomiń (plik wygląda jak odcinek filmu) {!r}'.format(card['filename']), 1)
                            continue
                    if want_s is not None and (parsed['season'] != want_s or parsed['episode'] != want_e):
                        fflog('[wrzucaj] pomiń (odcinek) {!r}'.format(card['filename']), 1)
                        continue

                    fflog('[wrzucaj] pasuje: {!r}'.format(card['filename']), 1)
                    seen_ids.add(card['file_id'])
                    result.extend(self._expand(card['watch_url'], card['file_id'], card['filename']))

            fflog('[wrzucaj] zwracam {} zródeł'.format(len(result)), 1)
        except Exception:
            fflog_exc(1)
        return result

    def _expand(self, watch_url, file_id, filename=''):
        sources = []
        try:
            page = self._client.session.get(watch_url, verify=False, timeout=20).text
        except Exception:
            fflog_exc(1)
            return sources

        tag_sources = self.RE_SOURCE_TAG.findall(page)
        if not tag_sources:
            fflog('[wrzucaj] brak <source> dla {}'.format(file_id), 1)
            return sources

        # napisy
        sub_urls = []
        for track in re.findall(r'<track\b[^>]*/?>(?:</track>)?', page, re.IGNORECASE):
            if 'subtitles' not in track.lower() and 'captions' not in track.lower():
                continue
            sm = re.search(r'\bsrc=["\']([^"\']+)["\']', track, re.IGNORECASE)
            if sm: sub_urls.append(sm.group(1))

        for cdn_url, size_str, label in tag_sources:
            size    = int(size_str) if size_str.isdigit() else 0
            quality = '4K' if size >= 2160 else '1080p' if size >= 1080 else '720p' if size >= 720 else 'SD'

            src_premium = quality == '4K'
            if src_premium and self._tier != 'premium':
                continue

            label_lower = label.lower()
            language    = 'pl'
            if 'dubbing' in label_lower or 'pldub' in label_lower:
                audio = 'Dubbing'
            elif 'napisy' in label_lower or ('sub' in label_lower and 'eng' not in label_lower):
                audio = 'Napisy'
            elif re.search(r'\beng?\b', label_lower) and 'lektor' not in label_lower:
                language = 'en'
                audio    = ''
            else:
                audio = 'Lektor'

            info = ' | '.join(x for x in (audio, 'Premium' if src_premium else '') if x)
            sources.append({
                'source':    'Oglądaj',
                'url':       self._url_with_headers(cdn_url),
                'quality':   quality,
                'language':  language,
                'info':      info,
                'direct':    True,
                'debridonly': False,
            })
            fflog('[wrzucaj] CDN {}p info={!r}'.format(size, info), 1)
        return sources

    def resolve(self, url):
        return url


# =============================================================================
# provider: wrzucaj2  (pliki — /ajax/search + file_details)
# =============================================================================
