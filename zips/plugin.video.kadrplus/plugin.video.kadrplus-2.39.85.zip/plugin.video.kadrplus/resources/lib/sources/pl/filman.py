# -*- coding: utf-8 -*-
"""
    FanFilm Add-on
    Copyright (C) 2025 :)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import base64
import re
from typing import Dict, List, Optional
from urllib.parse import quote, quote_plus, unquote_plus
from html import unescape
from collections import defaultdict

import json

from ptw.libraries import source_utils, control, cache, cleantitle, utils
from ptw.libraries.client import parseDOM
from ptw.libraries.log_utils import log, fflog
from ptw.debug import log_exception, fflog_exc



# fflog('moduł',1,1)
class source:
    # fflog('klasa',1,1)
    def __init__(self):
        # fflog('init',1,1)
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["filman.cc"]  # niewykorzystywane obecnie
        self.base_link = "https://filman.cc"
        self.login_link = "https://filman.cc/logowanie"
        self.search_link = "https://filman.cc/search?phrase={title}"
        self.full_init = False

    def _setting_str(self, key, default=""):
        """Kompatybilne pobieranie ustawień: stary control.settings + nowe nazwy z FanFilm."""
        try:
            value = control.settings.getString(key)
        except Exception:
            try:
                value = control.setting(key)
            except Exception:
                value = default
        if value is None:
            return default
        return str(value).strip(' "\'')

    def _setting_bool(self, key, default=False):
        try:
            return bool(control.settings.getBool(key))
        except Exception:
            try:
                return control.setting(key) == "true"
            except Exception:
                return default

    def _cookie_dict_from_string(self, cookies_str):
        result = {}
        for part in (cookies_str or "").split(";"):
            part = part.strip()
            if not part or "=" not in part:
                continue
            k, v = part.split("=", 1)
            k = k.strip()
            v = v.strip()
            if k:
                result[k] = v
        return result


    def init(self):
        if self.full_init:
            return
        self.full_init = True

        # self.year = 0

        # Mnożniki jednostek czasu w sekundach
        self.TIME_UNITS = {
            "_": 1,
            "bez": 1,
            "minutę": 60,
            "minuty": 60,
            "minut": 60,
            "godzinę": 3600,
            "godziny": 3600,
            "godzin": 3600,
            "dzień": 86400,
            "dni": 86400,
            "tydzień": 604800,
            "tygodnie": 604800,
            "tygodni": 604800,
            "miesiąc": 2592000,
            "miesiące": 2592000,
            "miesięcy": 2592000,
            "rok": 31536000,
            "lata": 31536000,
            "lat": 31536000
        }

        self.username = self._setting_str("filman.username")
        self.password = self._setting_str("filman.password")

        # KADRPLUS 2.39.53 / FanFilm compatibility:
        # Nowe FanFilm używa filman.user_agent, stare Kadr+ używało filman_web.USER_AGENT.
        self.USER_AGENT = (
            self._setting_str("filman.user_agent")
            or self._setting_str("filman_web.USER_AGENT")
            or "FilmanKodi/1.0 (compatible; Firefox/146.0)"
        )

        # Używaj sesji z ciasteczek jeśli włączono stary tryb lub wpisano nowe cookies z FanFilm.
        self.USER_SESSION = self._setting_bool("filman.other_sess_mode")
        if self._setting_str("filman.cookies_bkd") or self._setting_str("filman.cookies_user_id") or self._setting_str("filman.cookies_cf"):
            self.USER_SESSION = True

        self.HEADERS = {
            "Host": "filman.cc",
            "User-Agent": self.USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
            "DNT": "1",
            "Upgrade-Insecure-Requests": "1",
        }

        cookies = ""
        if self.USER_SESSION:
            # Stare ustawienie Kadr+: pełny document.cookie albo sam BKD_REMEMBER.
            cookies = self._setting_str("filman_web.cookies")
            if cookies:
                if "=" not in cookies:
                    cookies = "BKD_REMEMBER=" + cookies
                else:
                    cookies = re.sub('PHPSESSID=[^;]*;?', '', cookies).strip(' ;')

            # Nowe ustawienia zgodne z FanFilm 2026.
            bkd = self._setting_str("filman.cookies_bkd")
            uid = self._setting_str("filman.cookies_user_id")
            cf_new = self._setting_str("filman.cookies_cf")
            if bkd:
                cookies += ("; " if cookies else "") + "BKD_REMEMBER=" + bkd
            if uid:
                cookies += ("; " if cookies else "") + "USER_ID=" + uid

            # Stare i nowe cf_clearance.
            cf = cf_new or self._setting_str("filman_web.cookies.cf")
            cookies += ("; cf_clearance=" + cf) if cf else ""

            cookies = cookies.strip("; ")
            if cookies:
                cache.cache_insert("filman_cookie", cookies, control.sourcescacheFile)
            else:
                fflog('brak ciasteczek Filman w ustawieniach',1,1)

        import requests
        # Disable InsecureRequestWarning
        requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)

        self.session = requests.Session()
        self.session.cookies = requests.cookies.RequestsCookieJar()
        self.initialized = False

        self.initialize_session()


    def initialize_session(self):
        """Initialize the session by fetching the home and login pages."""
        # fflog('Initialize the session',1,1)
        try:
            self.session.headers.update(self.HEADERS)
            if not self.USER_SESSION:
                fflog('request do strony głównej i logowania',1,1)
                response = self.get_response(self.base_link)  # Initialize session
                # POPRAWKA: get_response zwraca (text, cookies) lub (False, None)
                if response is False or (isinstance(response, tuple) and response[0] is False):
                    fflog(f'błąd odpowiedzi przy inicjalizacji sesji',1,1)
                    return
                self.get_response(self.login_link)  # Get login page
                pass
            self.initialized = True
        except Exception:
            fflog_exc(1)


    def login(self):
        """Login to the service."""
        fflog('try login to website',1,1)
        try:
            if not self.initialized:
                self.initialize_session()

            if not self.username or not self.password:
                msg = "brak danych do zalogowania"
                fflog(f'{msg}',1,1)
                return None

            login_data = {"login": self.username, "password": self.password, "remember": "on", "submit": ""}
            response_text, cookies_str = self.get_response(self.login_link, data=login_data, method="post")
            # fflog(f'{cookies_str=}',1,1)
            # fflog(f'{response_text=}',1,1)

            if "yloguj" in response_text:
                fflog("Zalogowano poprawnie",1,1)
                cookies = "; ".join([f"{x}={y}" for x, y in self.session.cookies.get_dict().items()])
                cache.cache_insert("filman_cookie", cookies, control.sourcescacheFile)
                return True
            if "nieprawidłowy kod Cap" in response_text:  # w <div id="flash">
                msg = "nieprawidłowa Captcha"
                fflog(msg,1,1)
                if not control.window.getProperty("blocked_sources_extend") == 'break':
                    control.infoDialog("Błąd podczas logowania\n" + msg, 'Filman WWW', "WARNING")
            else:
                fflog('wystąpił jakiś problem')
                # fflog(f'{response_text=}',1,1)
                pass
            fflog("Nie zalogowano",1,1)
            return False
        except Exception:
            fflog_exc(1)


    def is_logged_in(self):
        """Check if user is logged in."""
        try:
            cookies_str = cache.cache_get("filman_cookie", control.sourcescacheFile)
            if cookies_str:
                cookies_str = cookies_str.get("value")
                # fflog(f'{cookies_str=}',1,1)
                cookies = self._cookie_dict_from_string(cookies_str)
                # fflog(f'{cookies=}',1,1)
                self.session.cookies.update(cookies)
                login_status = self.check_login_status()
                if login_status:
                    fflog('użytkownik zalogowany',0,1)
                    # może uaktualnić ciasteczka w bazie jak sesja użytkownika ?
                    return True
                elif login_status is False:
                    # Clear the cookies if the login status check fails
                    fflog('usunięcie zapisanego ciasteczka z bazy cache',1,1)
                    cache.remove_partial_key("filman_cookie")
                    self.session.cookies.clear()
                    if not self.USER_SESSION:
                        # Attempt to login again
                        fflog(f'próba ponownego zalogowania',1,1)
                        return self.login()
            else:
                if not self.USER_SESSION:
                    fflog('trzeba zalogować',1,1)
                    return self.login()
                    pass
            return None
        except Exception:
            fflog_exc(1)


    def check_login_status(self):
        """Check login status."""
        try:
            response = self.session.get(self.base_link, headers=self.HEADERS, verify=False)
            # POPRAWKA: sprawdzamy status_code zamiast bool(response) bo 4xx/5xx daje False
            if response.status_code >= 400:
                fflog(f'błąd HTTP {response.status_code}',1,1)
                if not control.window.getProperty("blocked_sources_extend") == 'break':
                    control.infoDialog("nieprawidłowa odpowiedź serwera: " + str(response.status_code), 'Filman WWW', "WARNING")
                return None
            # fflog(f'{self.HEADERS=}',1,1)
            # fflog(f'{response.text=}',1,1)
            if "yloguj" in response.text:
                fflog('zalogowany',0,1)
                if not self.USER_SESSION:
                    user = parseDOM(response.text, "a", attrs={"id": "dropdown"})[0]
                    user = re.sub("<[^>]+>", "", user).strip()
                    fflog(f'{user}',0,1)
                    user = user.replace("Zalogowany jako: ", "")
                    # fflog(f'{user=}',1,1)
                    if user != self.username:
                        fflog('trzeba przelogować',1,1)
                        return False
                # może uaktualnić ciasteczka w bazie jak sesja użytkownika ?
                return True
            else:
                fflog('niezalogowany',1,1)
                return False
        except Exception:
            fflog_exc(1)
            return False


    def search(self, title, localtitle, year, premiered, aliases=None, imdb="", results=None):  # zrezygnować z rekurencji
        """Search for a movie."""
        fflog(f'{title=}, {localtitle=}, {year=} {premiered=}')

        if isinstance(year, tuple):
            year, year_alt = year
        else:
            year_alt = ""

        self.init()

        try:
            # if not self.login():
            if not self.is_logged_in():
                fflog("Login failed",1,1)
                if not control.window.getProperty("blocked_sources_extend") == 'break':
                    control.infoDialog("Logowanie nieudane", 'Filman WWW', "WARNING")
                return None

            # fflog("user is logged in",1,1)

            # wyodrębnienie oryginalnego tytułu
            # fflog(f'{len(aliases)=}  {aliases=}',1,1)
            originalname = [a for a in aliases if "originalname" in a]
            originalname = originalname[0]["originalname"] if originalname else ""
            # fflog(f'{originalname=}',1,1)
            originalname = "" if source_utils.czy_litery_krzaczki(originalname) else originalname

            aliases2 = None

            # Cache normalized titles to avoid redundant processing
            normalized_titles = set()  # set unika duplikatów
            # normalized_titles = []

            # for t in [title, localtitle]:
            for t in [originalname, localtitle, title]:
                normalized_titles.add(t)  # bez przekształceń
                normalized_titles.add(cleantitle.normalize(t))  # polskie diakrytyczne
                normalized_titles.add(cleantitle.getsearch(t))
                normalized_titles.add(cleantitle.getsearch(t.split("–")[0].replace("-", " ")))

            # normalized_titles = list(filter(None, normalized_titles))  # przy okazji zmiana z set na listę
            normalized_titles = set(filter(None, normalized_titles))

            # fflog(f'{len(normalized_titles)=}',1,1)
            # fflog(f'{normalized_titles=}',1,1)

            anime = source_utils.is_anime("movie", "imdb", imdb)
            # fflog(f'{anime=}',1,1)

            aliases2 = self.prepare_aliases(aliases, year, anime)
            # fflog(f'aliases2={json.dumps(aliases2, indent=2)}',1,1)

            all_normalized_titles = normalized_titles.copy()
            all_normalized_titles = list(all_normalized_titles) + aliases2
            # fflog(f'{len(all_normalized_titles)=}',1,1)
            # fflog(f'{all_normalized_titles=}',1,1)

            # normalized_titles = list(normalized_titles)  # zamiana set na list

            # i = 1
            _ = len(normalized_titles)
            for a in aliases2:
                # fflog(f'{i=} {a=}',1,1)
                # fflog(f'{a=}',1,1)
                # normalized_titles += [a]  # dodanie
                # normalized_titles.append(a)  # to samo co wyżej (potem i tak może nastąpić redukacja ilości elementów)
                normalized_titles.add(a)  # w set nie doda tego, co już jest
                # if i >= 4:  # ograniczenie, ale patrz wyżej
                if len(normalized_titles) >= _ + 4:  # ograniczenie
                    break
                # i += 1
            # fflog(f'{normalized_titles=}',1,1)

            normalized_titles = [t.lower() for t in normalized_titles]
            normalized_titles = list(dict.fromkeys(normalized_titles))
            # fflog(f'{normalized_titles=}',0,1)
            normalized_titles = sorted(normalized_titles, key=len)
            fflog(f'{normalized_titles=}',0,1)

            all_normalized_titles = [t.lower() for t in all_normalized_titles]
            all_normalized_titles = list(dict.fromkeys(all_normalized_titles))

            if 0:
                all_normalized_titles = normalized_titles  # test, bo może nie potrzeba
                pass
            # fflog(f'{len(all_normalized_titles)=}',1,1)
            # fflog(f'{all_normalized_titles=}',1,1)       

            # previous_year = str(int(year))
            previous_year = str(int(year) - 1)  # tylko, że wówczas "Predator: pray" źle rozpoznaje, choć pomaga na "Nocne graffiti" - już rozwiązałem to inaczej

            if results is None:  # bo miała być rekurencja kiedyś

                results = []
                
                monitor = control.monitor

                should_break = False
                # should_break1 = should_break2 = should_break3 = False
                
                min_ratio = 0.94
                max_levenshtein = 4

                # fflog(f'{len(normalized_titles)=}',1,1)
                for normalized_title in normalized_titles:

                    if should_break:
                        break

                    # fflog(f'\n{normalized_title=}',1,1)

                    if monitor.abortRequested():
                        fflog(f'przerwanie wyszukiwania (z powodu sygnału zamknięcia Kodi)',1,1)
                        return sys.exit()
                    if control.window.getProperty("blocked_sources_extend") == 'break':
                        fflog(f'przerwanie dalszego wyszukiwania',1,1)
                        break

                    url = self.search_link.format(title=quote_plus(normalized_title))
                    fflog(f'{url=}   ({unquote_plus(url)})',0,1)

                    content, _ = self.get_response(url)  # REQUEST do serwera

                    # results.append((normalized_title, content))
                    results = [(normalized_title, content)]  # dla kompatybilności z istniejącym kodem

                    films = []
                    # fflog(f'{len(results)=}',1,1)
                    # fflog(f'{results=}',1,1)
                    for title, content in results:
                        if should_break:
                            break
                        # fflog(f'\n{title=}',1,1)
                        try:
                            posters = re.findall(r'<div class="poster">(.*?)</div>', content, re.DOTALL)  # nie zawiera w sobie roku
                            # posters = re.findall(r'<div class="col-xs-6 col-sm-2">(.*?)</div>', content, re.DOTALL)  # zawiera w sobie i tytuł i rok
                            # posters = parseDOM(result, 'div', attrs={'class': "col-xs-6 col-sm-2"})  # zawiera w sobie i tytuł i rok
                            film_years = re.findall(r'<div class="film_year">(.*?)</div>', content, re.DOTALL)
                            # film_titles = re.findall(r'<div class="film_title">(.*?)</div>', content, re.DOTALL)
                            zgodnosc = len(posters) == len(film_years)
                            # fflog(f'{zgodnosc=}  |  {len(posters)=}  {len(film_years)=}',1,1)
                            
                            if not posters:
                                # fflog(f'brak danych do analizy  {len(posters)=}',1,1)
                                continue
                                pass

                            fflog(f'do analizy  {len(posters)=}',0,1)
                            for i,result in enumerate(posters):
                                if should_break:
                                    break
                                # fflog(f'\n{i=} {result=}',1,1)
                                # fflog(f'\n{i=}',1,1)
                                src = re.findall(r'<img src="(.*?)"', result)[0].replace("thumb", "big")
                                href = re.findall(r'<a href="(.*?)"', result)[0]
                                if "/m/" not in href:
                                    # fflog(f'to nie film {title=}',1,1)
                                    continue
                                    pass
                                film_title = re.findall(r' (?:title|alt)="(.*?)"', result)[0]
                                film_year = film_years[i]  # jeśli idzie to w parze z posters, to będzie ok

                                if src.startswith("//"):
                                    src = "https:" + src

                                # fflog(f'{len(all_normalized_titles)=}',1,1)
                                # for title in normalized_titles:
                                for title in all_normalized_titles:

                                    # if should_break:
                                        # break

                                    # fflog(f'\n{title=}',1,1)

                                    film = {
                                        # "href": href.replace("/movies/", "/m/"),
                                        "href": href,
                                        "title": unescape(utils.decode_title_from_latin1(utils.escape_special_characters(film_title))),
                                        # "title": film_title,
                                        "year": film_year,
                                    }
                                    if not( "/m/" in film["href"] and film["year"] in [str(year), premiered, previous_year, year_alt]):
                                        # fflog(f'1 nie pasuje ani {year=} ani {premiered=}  {film=}',1,1)
                                        continue
                                    else:
                                        # fflog(f'1 może pasować, bo {year=} lub {premiered=}  {film=}',1,1)
                                        pass

                                    title_parts = film["title"].split(" / ")
                                    # fflog(f'\n{title_parts=}')

                                    primary_words = cleantitle.normalize(title_parts[0].strip()).lower()
                                    # fflog(f'{title=}  {primary_words=}')
                                    # ratio_primary = 
                                    # levenshtein_primary = 
                                    film.update(
                                        {
                                            "ratio": round(utils.calculate_similarity_ratio(title, primary_words), 2),
                                            "levenshtein": utils.calculate_levenshtein_distance(title, primary_words),
                                            "title_to_calculate": title,
                                        }
                                    )
                                    if  min_ratio < film["ratio"]  and  film["levenshtein"] <= max_levenshtein :
                                        fflog(f'1 dodaję           {film=}  |  {title=}',0,1)
                                        films.append(film)
                                        if 0:
                                            # if ratio_primary == 1 or levenshtein_primary == 0:
                                            if film["ratio"] == 1 or film["levenshtein"] == 0:  # tylko, że mogą być filmy o takich samych tytułach w oryginale, ale polski nie będzie pasował
                                                if film["year"] in [str(year), premiered]:  # nie jest to najlepsze
                                                    should_break1 = True
                                                    if len(title_parts) == 1:  # może to i niegłupie ?
                                                        fflog(f'to może być ten {film=} | {year=} ({premiered=})',0,1)
                                                        # should_break = True
                                                        # break
                                                        pass

                                    if len(title_parts) > 1:
                                        # fflog(f'{len(title_parts)=}',1,1)
                                        words = cleantitle.normalize(title_parts[1].strip()).lower()  # a jeszcze może być oryginalny na końcu
                                        # fflog(f'{title=}  {words=}')
                                        secondary_film = film.copy()
                                        # ratio_secondary = 
                                        # levenshtein_secondary = 
                                        secondary_film.update(
                                            {
                                                "ratio": round(utils.calculate_similarity_ratio(title, words), 2),
                                                "levenshtein": utils.calculate_levenshtein_distance(title, words),
                                                "title_to_calculate": title,
                                            }
                                        )
                                        if  min_ratio < secondary_film["ratio"]  and  secondary_film["levenshtein"] <= max_levenshtein :
                                            fflog(f'2 dodaję {secondary_film=}  |  {title=}',0,1)
                                            films.append(secondary_film)
                                            if 0:
                                                if secondary_film["ratio"] == 1 or secondary_film["levenshtein"] == 0:
                                                    if secondary_film["year"] in [str(year), premiered]:  # patrz na problemy opisane wyżej
                                                        should_break2 = True
                                                        if len(title_parts) == 2:
                                                            fflog(f'to może być ten {secondary_film=} | {year=} ({premiered=})',0,1)
                                                            # should_break = True
                                                            # break
                                                            pass

                                    if len(title_parts) > 2:
                                        # fflog(f'{len(title_parts)=}',1,1)
                                        words = cleantitle.normalize(title_parts[2].strip()).lower()  # 3 ostatni
                                        # fflog(f'{title=}  {words=}')
                                        third_film = film.copy()
                                        third_film.update(
                                            {
                                                "ratio": round(utils.calculate_similarity_ratio(title, words), 2),
                                                "levenshtein": utils.calculate_levenshtein_distance(title, words),
                                                "title_to_calculate": title,
                                            }
                                        )
                                        if  min_ratio < third_film["ratio"]  and  third_film["levenshtein"] <= max_levenshtein :
                                            fflog(f'3 dodaję {third_film=}  |  {title=}',0,1)
                                            films.append(third_film)
                                            if 0:
                                                if third_film["year"] in [str(year), premiered]:  # patrz na problemy opisane wyżej
                                                    if third_film["ratio"] == 1 or third_film["levenshtein"] == 0:
                                                        fflog(f'to może być ten {third_film=} | {year=} ({premiered=})',0,1)
                                                        should_break = True
                                                        break
                                                        pass

                                    fflog(f'\n',0,1)
                        except Exception:
                            fflog_exc(1)
                            # fflog(f'{result=}')
                            pass

                    # fflog(f'{should_break=}',1,1)
                    fflog(f'{len(films)=}',0,1)

                    if films:
                        films = self.summarize_films(films)
                        # films = sorted(films, key=lambda x: (x["ratio"], -x["levenshtein"], x["year"]), reverse=True)
                        films = sorted(films, key=lambda x: (x["ratio"], -x["levenshtein"], x["year"], x["count"]), reverse=True)
                        # fflog(f'{len(films)=} films={json.dumps(films, indent=2)}',1,1)

                        def approve_or_reject(year):
                            fflog(f'comparing with {year=}',1,1)
                            # fflog(f'{len(films)=}',1,1)
                            for film in films:
                                # fflog(f'{film=}',1,1)
                                try:
                                    # if  min_ratio < film["ratio"] <= 1.0  and  film["levenshtein"] <= max_levenshtein :  # nie wiem, co lepsze
                                    # if  0.94 < film["ratio"] <= 1.0  and  film["levenshtein"] <= 4 :  # nie wiem, co lepsze
                                    if 1:  # bo wcześniej taki warunek określiłem
                                        # if "/m/" in film["href"] and str(year) in film["href"]:
                                        # if "/m/" in film["href"] and str(year) in film["year"]:
                                        if "/m/" in film["href"] and film["year"] in [str(year), premiered]:
                                            # fflog(f'dopasowano {film=} | {year=} ({premiered=})',1,1)
                                            fflog(f'dopasowano {film["title"]=} | {year=} ({premiered=})',1,1)
                                            # return film["href"]
                                            return (film["href"], film["title"])
                                        else:
                                            # fflog(f'1 nie pasuje ani {year=} ani {premiered=}  {film=}',1,1)
                                            pass
                                    else:
                                        # fflog(f'1 chyba jednak nie ten film {film=}',1,1)
                                        pass
                                except Exception:
                                    fflog_exc(1)
                            """
                            for film in films:
                                # fflog(f'{film=}',1,1)
                                try:
                                    normalized_search_title = cleantitle.normalize(utils.decode_title_from_latin1(title)).lower()
                                    normalized_film_title = cleantitle.normalize(film["title"]).lower()
                                    if normalized_film_title.startswith(normalized_search_title):
                                        # if "/m/" in film["href"] and str(year) in film["href"]:
                                        if "/m/" in film["href"] and film["year"] in str(year):
                                            fflog(f'pasuje {film=} {year=}',1,1)
                                            # return film["href"]
                                            return (film["href"], film["title"])
                                        else:
                                            # fflog(f'2 nie pasuje {film=} {year=}')
                                            pass
                                    else:
                                        # fflog(f'2 chyba nie ten film {film=}')
                                        pass
                                except Exception as e:
                                    fflog_exc(e, title="Error processing startswith check")
                            """
                        items = approve_or_reject(year)
                        if not items:
                            items = approve_or_reject(year_alt or previous_year)
                        if items:
                            return items

            fflog('nic nie dopasowano',1,1)
            """
            if int(self.year) - int(year) < 1:
                previous_year = str(int(year) - 1)
                fflog(f'bedzie powtórka na {previous_year=}')
                control.sleep(500)
                return self.search(title, localtitle, previous_year, premiered, aliases=aliases, imdb=imdb, results=results)  # rekurencja może się zapętlić
            """
        except Exception:
            fflog_exc(1)
            return None


    def summarize_films(self, films):
        # grupowanie
        summary = defaultdict(lambda: {"items": [], "titles_calc": []})

        for film in films:
            # key = (film["title"], film["year"], film["ratio"], film["levenshtein"])  # grupowanie po (title, year, ratio, levenshtein)
            key = (film["href"], film["ratio"], film["levenshtein"])  # grupowanie po (href, ratio, levenshtein)
            summary[key]["items"].append(film)
            summary[key]["titles_calc"].append(film["title_to_calculate"])

        def order_by_title(title, phrases):
            # sortujemy frazy wg pozycji w tytule (jeśli brak, to na końcu)
            title_lower = title.lower()
            def position(phrase):
                idx = title_lower.find(phrase.lower())
                return idx if idx != -1 else 9999
            return sorted(phrases, key=position)

        result = []  # budowanie wyników
        # for (title, year, ratio, levenshtein), data in summary.items():
        for (href, ratio, levenshtein), data in summary.items():
            # base = copy.deepcopy(data["items"][0])  # nie potrzeba deepcopy, bo słownik nie zawiera zagnieżdzonych pól
            base = data["items"][0].copy()  # baza – kopia pierwszego (w sensie ilości wystąpień) elementu
            base["count"] = len(data["items"])
            title = data["items"][0]["title"]
            base.pop("title_to_calculate", None)
            base["titles_to_calculate"] = " | ".join( order_by_title(title, data["titles_calc"]) )
            result.append(base)

        return result


    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        """Search for a movie."""
        # fflog(f'{imdb=} {title=} {localtitle=} {year=} {kwargs=} {aliases=}',1,1)
        # return self.sources( ('https://filman.cc/m/IQMza4W5RVPhE8jfpsK2XvHxA', 'Matrix / The Matrix'), [], [])  # do testów tylko
        # self.year = int(year)
        premiered = kwargs.get("premiered", "")
        premiered = "".join(re.findall(r"\d{4}", premiered))
        year_alt = kwargs.get("year_alt")
        year = (year, year_alt) if year_alt else year
        # fflog(f'szukanie filmu {title=} {localtitle=} {year=} {premiered=} {aliases=}',1,1)
        return self.search(title, localtitle, year, premiered, aliases, imdb)


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        """Search for a TV show."""
        # fflog(f'{imdb=} {tvdb=} {tvshowtitle=} {localtvshowtitle=} {year=} {aliases=}',1,1)
        year_alt = kwargs.get("year_alt")
        year = (year, year_alt) if year_alt else year
        # poniższe, to nazewnictwo xulka
        pl_alias = next((alias for alias in aliases if alias.get("country") == "original"), None)
        pl_title = pl_alias.get("originalname", "") if pl_alias else ""
        # return (tvshowtitle, localtvshowtitle, pl_title), year
        return (tvshowtitle, localtvshowtitle, pl_title, aliases), year


    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        """Search for a TV show episode."""
        # fflog(f'{url=} {imdb=} {tvdb=} {title=} {premiered=} {season=} {episode=} {kwargs=}',1,1)
        # Extract title components from the URL
        original_title = url[0][0]
        local_title = url[0][1]
        pl_alias = url[0][2]
        aliases = url[0][3]

        # Extract the year from the URL
        # self.year = int(url[1])
        # self.year = url[1]
        year = url[1]
        fflog(f'{year=}  ({premiered=})',1,1)

        if tvdb:
            anime = source_utils.is_anime("show", "tvdb", tvdb)
        else:
            anime = source_utils.is_anime("show", "imdb", imdb)

        # Format the episode number to the standard format "sXXeXX"
        ep_no = self._format_episode_number(season, episode)

        absolute_episode = kwargs.get("absolute_episode")

        # Perform the episode search with the extracted and formatted parameters
        return self.search_ep(original_title, local_title, year, pl_alias, aliases, ep_no, anime, absolute_episode)


    def prepare_aliases(self, aliases, year, anime=None):
        """ może się przydać do dopasowywania tytułów """
        # fflog(f'{len(aliases)}  {aliases=}')
        if isinstance(year, tuple):
            year, year_alt = year
        else:
            year_alt = ""
        my_language_order = ["pl", "us", "en", "uk", "gb", "au", "it", "fr", "de" ]  # aby dać niektóre na początek
        language_order = {key: i for i, key in enumerate(my_language_order)}
        if not anime:
            aliases = sorted(aliases, key=lambda d:(language_order.get(d["country"], 99),) )  # bo nie zawsze pomaga, czasami jp romaji jest najlepsze
        # fflog(f'{len(aliases)}  {aliases=}')
        aliases1 = [
            (a.get("title") or a.get("originalname") or "")
            + " ("
            + a.get("country", "")
            + ")"
            for a in aliases
            # if a.get("country") in ("us", "en", "uk", "gb", "au", "pl", "jp", "original")
        ]
        # fflog(f'{len(aliases1)}  {aliases1=}')
        aliases2 = [a.rpartition(" (")[0] for a in aliases1]  # country out
        aliases2 = [a.replace(year, "").replace("()", "").rstrip() for a in aliases2]  # year out
        aliases2 = [a for a in aliases2 if not source_utils.czy_litery_krzaczki(a)]  # krzaczki out
        aliases2 = [alias for i, alias in enumerate(aliases2) if alias.lower() not in [x.lower() for x in aliases2[:i]]]  # kolejne duplikaty są usuwane niezależnie od wielkości liter
        # fflog(f'{len(aliases2)}  {aliases2=}')
        return aliases2


    def _format_episode_number(self, season, episode):
        """Format season and episode numbers to the standard 'sXXeXX' format."""
        season_str = str(season).zfill(2)
        episode_str = str(episode).zfill(2)
        return f"s{season_str}e{episode_str}"


    def search_ep(self, title, localtitle, year, pl_alias, aliases, ep_no: str, anime=None, absolute_episode=0, year_flag=False, results=None) -> Optional[str]:
        """Search for a TV show episode."""
        # fflog(f'{title=} {localtitle=} {year=} {pl_alias=} {ep_no=} {anime=} {absolute_episode=} {aliases=}',1,1)
        self.init()
        try:
            # if not self.login():
            if not self.is_logged_in():
                fflog("Login failed")
                if not control.window.getProperty("blocked_sources_extend") == 'break':
                    control.infoDialog("Logowanie nieudane", 'Filman WWW', "WARNING")
                return None

            # fflog("user is logged in",1,1)
            """
            if isinstance(year, tuple):
                year, year_alt = year
            else:
                year_alt = ""
            """
            # wyodrębnienie oryginalnego tytułu
            # fflog(f'{len(aliases)=}  {aliases=}',1,1)
            originalname = [a for a in aliases if "originalname" in a]
            originalname = originalname[0]["originalname"] if originalname else ""
            # fflog(f'{originalname=}',1,1)
            originalname = "" if source_utils.czy_litery_krzaczki(originalname) else originalname
            # pl_alias to chyba originalname (tak chyba xulek nazwał)

            # fflog(f'{title=} {localtitle=} {pl_alias=} {originalname=}',1,1)
            # normalized_titles = self._get_normalized_titles([title, localtitle, pl_alias, originalname])
            normalized_titles = self._get_normalized_titles([originalname, localtitle, title])
            fflog(f'{normalized_titles=}',0,1)
            # fflog(f'{type(normalized_titles)=}',1,1)


            aliases2 = self.prepare_aliases(aliases, year, anime)

            all_normalized_titles = normalized_titles.copy()
            all_normalized_titles = list(all_normalized_titles) + aliases2
            # fflog(f'{len(all_normalized_titles)=}',1,1)
            # fflog(f'{all_normalized_titles=}',1,1)

            i = 1
            for a in aliases2:
                normalized_titles += [a]  # dodanie
                # normalized_titles.add(a)
                if i >= 4:  # ograniczenie
                    break
                i += 1

            normalized_titles = [t.lower() for t in normalized_titles]
            normalized_titles = list(dict.fromkeys(normalized_titles))
            # fflog(f'{normalized_titles=}',1,1)
            # normalized_titles = sorted(normalized_titles, key=len)
            # fflog(f'{normalized_titles=}',0,1)

            all_normalized_titles = [t.lower() for t in all_normalized_titles]
            all_normalized_titles = list(dict.fromkeys(all_normalized_titles))

            if 0:
                all_normalized_titles = normalized_titles  # test, bo może nie potrzeba
                pass
            # fflog(f'{len(all_normalized_titles)=}',1,1)
            # fflog(f'{all_normalized_titles=}',1,1)  

            # if 0:  # ewentualnie wypisać wyjątki, dla których to potrzeba, bo uważam, że lepiej jak tytuł jest jak najdłuższy, tzn. zawiera także dodatkowe tytuły, czyli np. także originalny, wtedy powinna być większa precyzja, ale różnie może być z tłumaczeniami
            if "allo allo" in normalized_titles:
                normalized_titles = sorted(normalized_titles, key=len)  # nie wiem, czy warto szukać wg najkrótszego

            if results is None:
                # results = self._fetch_search_results(normalized_titles)  # wczytywanie na zaś
                # fflog(f'{results=}',1,1)
                pass

            # _fetch_search_results
            results = []
            monitor = control.monitor

            fflog(f'{normalized_titles=}',1,1)

            for normalized_title in normalized_titles:
                fflog(f'search for {normalized_title=}',1,1)

                if monitor.abortRequested():
                    fflog(f'przerwanie wyszukiwania (z powodu sygnału zamknięcia Kodi)')
                    return sys.exit()
                if control.window.getProperty("blocked_sources_extend") == 'break':
                    fflog(f'przerwanie dalszego wyszukiwania')
                    break

                url = self.search_link.format(title=quote_plus(normalized_title))
                # fflog(f'{url=}   {unquote_plus(url)}',1,1)

                content, _ = self.get_response(url)  # REQUEST do serwera

                if not content:
                    continue

                # results.append((normalized_title, content))
                results = [(normalized_title, content)]  # dla kompatybilności z istniejącym kodem

                tvshows = self._process_search_results(results, title, year, all_normalized_titles)  # tu ewentualnie rozszerzyć zakres roku
                # fflog(f'{len(tvshows)=}',1,1)
                # fflog(f'{tvshows=}',1,1)

                if tvshows:
                    for tvshow in tvshows:  # 1 szansa
                        url = self._extract_episode_url(tvshow, ep_no, absolute_episode)
                        fflog(f'1 {url=}',1,1)
                        if url:
                            return url

                    for tvshow in tvshows:  # 2 szansa
                        url = self._extract_episode_url(tvshow, ep_no, absolute_episode, check_startswith=True, search_title=title)
                        if url:
                            fflog(f'2 {url=}',1,1)
                            return url

            fflog('nic nie znaleziono',1,1)
            """ rezygnacja z tej rekurencji
            if not year_flag:
                pass
                # fflog(f'będzie powtórka dla roku {str(int(year) - 1)}',1,1)
                # return self.search_ep(title, localtitle, str(int(year) - 1), pl_alias, aliases, ep_no, anime, absolute_episode, year_flag=True, results=results)  # rekurencja
            """
            return None
        except Exception:
            fflog_exc(1)
            return None


    def _get_normalized_titles(self, raw_titles: List[str]) -> list:
        normalized_titles = {cleantitle.normalize(t).lower() for t in raw_titles if t}
        normalized_titles.update({cleantitle.getsearch(t).lower() for t in raw_titles if t})
        normalized_titles.update({cleantitle.getsearch(t.split("–")[0].replace("-", " ")).lower() for t in raw_titles if t})
        normalized_titles = [t.lower() for t in normalized_titles]
        normalized_titles = list(dict.fromkeys(normalized_titles))  # czy może być list zamiast set ?
        fflog(f'{normalized_titles=}',0,1)
        return normalized_titles


    def _fetch_search_results(self, normalized_titles: set) -> List[tuple]:
        results = []
        for normalized_title in normalized_titles:  # wykonuje requesty do serwera
            url = self.search_link.format(title=quote_plus(normalized_title))
            fflog(f'{url=}',1,1)
            content, _ = self.get_response(url)  # request do serwera
            results.append((normalized_title, content))
        return results


    def _process_search_results(self, results: List[tuple], title: str, year: int, all_normalized_titles=None) -> List[Dict[str, str]]:
        """ ocenia znalezione pozycje z zadanymi tytułami """
        tvshows = []
        should_break = False
        title = title.lower()

        if isinstance(year, tuple):
            year, year_alt = year
        else:
            year_alt = 0

        for normalized_title, content in results:
            fflog(f'A \n\n\n {normalized_title=}',0,1)
            # fflog(f'{content=}',1,1)

            if should_break:
                break

            if not all_normalized_titles:
                all_normalized_titles = [normalized_title]

            try:
                # Wzór wyrażenia regularnego do wyciągnięcia bloków "poster" wraz z rokiem
                pattern = r'(<div class="poster">.*?</div>)\s*<div class="film_year">(\d{4})</div>'  # sposób na element będący rodzeństwem (sibling)

                # Znajdź wszystkie pasujące bloki wraz z rokiem
                matches = re.findall(pattern, content, re.DOTALL)
                fflog(f'{len(matches)=}',0,1)
                # fflog(f'{matches=}',1,1)

                # Przetwarzaj wyniki
                for result, film_year in matches:

                    if should_break:
                        break

                    tvshow = self._extract_tvshow_info(result)
                    # fflog(f'\n\n{tvshow["title"]=}  {tvshow["href"]=}\n',1,1)

                    if "/s/" not in tvshow['href']:
                        fflog(f'to nie serial {tvshow=}',0,1)
                        continue

                    tvshow.update({"year": film_year})

                    # if not tvshow or str(year) != self._fix_year(title, film_year):  # ewentualnie rozszerzyć zakres roku
                    # if not tvshow or str(year) != self._fix_year(tvshow["title"], film_year):  # ewentualnie rozszerzyć zakres roku
                    if not tvshow or self._fix_year(tvshow["title"], film_year) not in [str(year), str(year_alt)]:
                        fflog(f'rok nie pasuje {tvshow=}  (zadany {year=} {year_alt=})',0,1)
                        continue

                    # for normalized_title in [normalized_title]:  # dla kompatybilności
                    for normalized_title in all_normalized_titles:

                        # fflog(f'\n{normalized_title=}',1,1)

                        primary_words, ratio_primary, levenshtein_primary = self._calculate_similarity(
                            tvshow["title"].split("/")[0].strip().lower(), normalized_title)
                        tvshow = tvshow.copy()
                        tvshow.update({"ratio": ratio_primary, "levenshtein": levenshtein_primary})
                        # fflog(f'{tvshow=}',1,1)
                        tvshows.append(tvshow)  # dodanie do listy wstępnie zakwalifikowanych
                        if ratio_primary == 1 or levenshtein_primary == 0:
                            # fflog(f'{normalized_title=}  {tvshow["title"]=}',1,1)
                            if "allo allo" not in tvshow["title"].lower():  # wyjątek, na który trafiłem
                                should_break = True
                                break
                                pass

                        if len(tvshow["title"].split("/")) > 1:
                            secondary_tvshow = self._process_secondary_title(tvshow, normalized_title)
                            # fflog(f'{secondary_tvshow=}',1,1)
                            tvshows.append(secondary_tvshow)  # dodanie do listy wstępnie zakwalifikowanych
                            if secondary_tvshow["ratio"] == 1 or secondary_tvshow["levenshtein"] == 0:
                                # fflog(f'{normalized_title=}  {secondary_tvshow["title"]=}',1,1)
                                if "allo allo" not in secondary_tvshow["title"].lower():  # wyjątek, na który trafiłem
                                    should_break = True
                                    break
                                    pass

            except Exception:
                fflog_exc(1)
        fflog(f'{should_break=}',0,1)
        fflog(f'{len(tvshows)=}',0,1)
        # fflog(f'{all_normalized_titles=}',1,1)
        # fflog(f'tvshows={json.dumps(tvshows, indent=2)}',1,1)
        tvshows = sorted(tvshows, key=lambda x: (x["ratio"], -x["levenshtein"]), reverse=True)  # najlepiej dopasowane na początek
        if "allo allo" in all_normalized_titles:  # taki wyjątek
            tvshows = sorted(tvshows, key=lambda x: (-x["ratio"], x["levenshtein"], x["title"]), reverse=False)  # najlepiej dopasowane na początek (dla Allo Allo potrzebne, choć uważam, że lepiej jak tytuł jest jak najdłuższy, tzn. zawiera także dodatkowe tytuły, czyli np. także originalny)
        # fflog(f'{tvshows=}',1,1)
        # fflog(f'tvshows={json.dumps(tvshows, indent=2)}',1,1)
        return tvshows

    
    def _fix_year(self, title: str, year: str):
        """ korekta roku dla niektórych tytułów (bo Filman dał inny niż jest na TMDB)"""
        title = title.lower()
        # fflog(f'{title=}  {year=}',1,1)
        if "gra o tron" == title and year == "2015":  # Filman dał 2015
            fflog(f'korekta roku na 2011 dla {title=}',1,1)
            year = "2011"  # tak jest na tmdb
        elif "mr. robot" == title and year == "2018":
            fflog(f'korekta roku na 2015 dla {title=}',1,1)
            year = "2015"
        elif "allo allo" in title and year == "1982":  # jakby Filmweb nie zadziałał (chodzi o rok)
            fflog(f'korekta roku na 1984 dla {title=}',1,1)
            year = "1984"
        # fflog(f'{title=}  {year=}',1,1)
        return year


    def _extract_tvshow_info(self, result: str) -> Dict[str, str]:
        try:
            src = re.findall(r'<img src="(.*?)"', result)[0].replace("thumb", "big")
            href = re.findall(r'<a href="(.*?)"', result)[0]
            tvshow_title = re.findall(r' (?:title|alt)="(.*?)"', result)[0]

            if src.startswith("//"):
                src = "https:" + src

            tvshow = {
                "href": href,
                "title": utils.decode_title_from_latin1(utils.escape_special_characters(tvshow_title)),
                # "year": ,
            }
            return tvshow
        except IndexError:
            return {}
        except Exception:
            fflog_exc(1)
            return {}
            pass


    def _calculate_similarity(self, tvshow_title: str, search_title: str) -> tuple:
        search_title = cleantitle.normalize(search_title)
        title_parts = tvshow_title.split("/")
        primary_words = cleantitle.normalize(title_parts[0].strip().lower())
        ratio_primary = utils.calculate_similarity_ratio(search_title, primary_words)
        levenshtein_primary = utils.calculate_levenshtein_distance(search_title, primary_words)
        return primary_words, ratio_primary, levenshtein_primary


    def _process_secondary_title(self, tvshow: Dict[str, str], search_title: str) -> Dict[str, str]:
        search_title = cleantitle.normalize(search_title)
        words = cleantitle.normalize(tvshow["title"].split("/")[1].strip().lower())
        secondary_tvshow = tvshow.copy()
        secondary_tvshow.update(
            {
                "ratio": utils.calculate_similarity_ratio(search_title, words),
                "levenshtein": utils.calculate_levenshtein_distance(search_title, words),
            }
        )
        return secondary_tvshow


    def _extract_episode_url(self, tvshow: Dict[str, str], ep_no: str, absolute_episode: int = 0, check_startswith: bool = False, search_title: str = "") -> Optional[str]:
        try:
            if check_startswith:
                try:
                    search_title = utils.decode_title_from_latin1(search_title)
                except:
                    fflog_exc(0)
                    fflog(f'{search_title=}',0,1)
                    pass
                normalized_search_title = cleantitle.normalize(search_title).lower()
                normalized_tvshow_title = cleantitle.normalize(tvshow["title"]).lower()
                if not normalized_tvshow_title.startswith(normalized_search_title):
                    # fflog(f'return None, bo {normalized_tvshow_title=} {normalized_search_title=}',1,1)
                    return None

            # fflog(f'{tvshow["href"]=}',1,1)
            if "/s/" in tvshow["href"]:
                content2, _ = self.get_response(tvshow["href"])
                pattern = re.compile(r"<span>Sezon (\d+)</span>.*?<ul>(.*?)</ul>", re.DOTALL)
                episode_pattern = re.compile(r'<a href="(.*?)">\[s(\d+)e(\d+)\] (.*?)</a>')

                seasons = pattern.findall(content2)
                episodes_dict = {}
                for season, episodes_html in seasons:
                    for match in episode_pattern.findall(episodes_html):
                        url, season_number, episode_number, title = match
                        season_number = int(season_number)
                        episode_number = int(episode_number)
                        epno = f"s{season_number:02d}e{episode_number:02d}"
                        episodes_dict[epno] = {"url": url}
                # fflog(f'{episodes_dict=}',1,1)

                if ep_no in episodes_dict.keys():
                    # return episodes_dict[ep_no]["url"]
                    return (episodes_dict[ep_no]["url"], tvshow["title"]+ f"  {ep_no}")

                if absolute_episode:
                    # fflog(f'{absolute_episode=}',1,1)
                    ep_no_a = self._format_episode_number(1, absolute_episode)
                    # fflog(f'{ep_no_a=} {episodes_dict.keys()=} \n{}',1,1)
                    if ep_no_a in episodes_dict.keys():
                        # return episodes_dict[ep_no_a]["url"]
                        return (episodes_dict[ep_no_a]["url"], tvshow["title"]+ f"  {ep_no_a}")
                    else:
                        pass
                        # ep_no_a = self._format_episode_number(ep_no[1:3], absolute_episode)
                        ep_no_a = ep_no[:4] + str(absolute_episode)
                        # fflog(f'{ep_no_a=} {episodes_dict.keys()=} \n{}',1,1)
                        if ep_no_a in episodes_dict.keys():
                            # return episodes_dict[ep_no_a]["url"]
                            return (episodes_dict[ep_no_a]["url"], tvshow["title"]+ f"  {ep_no_a}")

        except Exception:
            fflog_exc(1)
        return None


    def sources(self, url, host_dict, hostpr_dict):
        """Get movie or episode sources."""
        # fflog(f'{url=}    {host_dict=}  {hostpr_dict=}',1,1)
        try:
            # fflog(f'{url=}',1,1)
            if isinstance(url, tuple):
                url, title = url
            else:
                title = year = ""

            sources = []

            if not url:
                return sources

            self.init()

            headers = {"referer": "https://filman.cc/", "user-agent": self.USER_AGENT}

            # Funkcja do tworzenia linku Kodi
            def create_kodi_link(url, headers):
                # Kodowanie wartości nagłówków
                encoded_headers = {key: quote(value, safe="") for key, value in headers.items()}
                # Łączenie zakodowanych nagłówków w format Kodi
                options = "&".join([f"{key}={value}" for key, value in encoded_headers.items()])
                kodi_link = f"{url}|{options}"
                # fflog(f'{kodi_link=}',1,1)
                return kodi_link

            if not self.is_logged_in():
                fflog("Login failed",1,1)
                if not control.window.getProperty("blocked_sources_extend") == 'break':
                    control.infoDialog("Logowanie nieudane", 'Filman WWW', "WARNING")
                return sources
            else:
                # fflog("wszystko ok",1,1)
                pass

            results = self.get_videos(url)
            # fflog(f'{results=}',1,1)
            # fflog(f'{len(results)=} results={json.dumps(results, indent=2)}',1,1)
            results = self.sort_by_ago(results)
            # fflog(f'{len(results)=} results={json.dumps(results, indent=2)}',1,1)
            
            display_when_added = control.settings.getString("filman.display_when_added") == "true"
            # display_titles = control.settings.getString("filman.display_titles") == "true"
            display_titles = True
            filename_in_2nd_line = control.setting("sources.filename_in_2nd_line") == "true"
            
            for result in results:
                # fflog(f'{result=}')
                valid, host = source_utils.is_host_valid(result["url"], host_dict)
                premium = result.get("premium")
                if premium or valid or "wolfstraam" in host:
                    if result.get("host"):
                        host = result["host"]
                    host = host.rsplit(".", 1)[0]
                    sources.append(
                        {
                            "provider": " (premium)" if premium or "wolfstraam" in host else "",
                            "source": host,
                            "url": create_kodi_link(result["url"], headers) if premium or "wolfstraam" in host else result["url"],
                            "quality": result["quality"],
                            "language": result["lang"],
                            "info": result["sound"] + (f'  ({result["ago"]})' if display_when_added and not filename_in_2nd_line else ""),
                            "info2": (title if display_titles else "") + (f'  ({result["ago"]})' if display_when_added else "").replace('  (_)', ''),
                            "filename": title,
                            "direct": False if not premium and not "wolfstraam" in host else True,
                            "debridonly": False,
                        }
                    )
                else:
                    pass
                    fflog(f'not {valid=} {host=} {result=}',1,1)
            # fflog(f'{len(sources)=} sources={json.dumps(sources, indent=2)}',1,1)
            fflog(f'przekazano źródeł: {len(sources)}',1,1)
            return sources
        except Exception:
            fflog_exc(1)
            return sources


    def resolve(self, url):
        """Resolve URL."""
        return url


    def get_response(self, url, headers=None, data=None, method="get"):
        """Make HTTP request."""
        if headers is None:
            headers = self.HEADERS
        # fflog(f'{headers=}',1,1)
        cookies_str = "; ".join([f"{c.name}={c.value}" for c in self.session.cookies])
        # fflog(f'{cookies_str=}',1,1)
        try:
            response = (
                self.session.post(url, headers=headers, data=data, verify=False)  # post
                if method == "post"
                else self.session.get(url, headers=headers, verify=False)  # get
            )
            # POPRAWKA: nie używamy 'if not response:' bo requests zwraca False dla 4xx/5xx
            # zamiast sprawdzać bool, logujemy tylko błędy HTTP
            if response.status_code >= 400:
                fflog(f'błąd HTTP {response.status_code} {url=}')
                return False, None
            cookies_str = "; ".join([f"{c.name}={c.value}" for c in self.session.cookies])
            return response.text, cookies_str
        except Exception:
            fflog_exc(1)


    def get_videos(self, url: str) -> List[Dict[str, str]]:
        """Get list of videos from the URL."""
        # fflog(f'{url=}',1,1)
        content, _ = self.get_response(url)
        # content = self.get_url_req(url)
        out = []

        try:
            table_content = parseDOM(content, "table", attrs={"id": "links"})
            if not table_content:
                fflog(f'{table_content=}',1,1)
                fflog(f'{content=}',0,1)
                return out

            result = parseDOM(table_content[0], "tbody")
            if not result:
                fflog(f'{result=}',1,1)
                return out

            rows = self._get_rows(result[0])
            fflog(f'{len(rows)=}',1,1)
            for row in rows:
                # fflog(f'{row=}',1,1)
                try:
                    video_info = self._extract_video_info(row)
                    if video_info:
                        out.append(video_info)
                    else:
                        fflog(f'{video_info=}',1,1)
                        pass
                except Exception:
                    fflog_exc(1)
        except Exception:
            fflog_exc(1)

        return out


    def _get_rows(self, content: str) -> List[str]:
        row_pattern = re.compile(r'<tr class="[^"]*version[^"]*">(.+?)</tr>', re.DOTALL)
        return row_pattern.findall(content)


    def _extract_video_info(self, row: str) -> Dict[str, str]:
        # fflog(f'{row=}',1,1)
        iframe_pattern = re.compile(r'data-iframe="([^"]+)"')
        href_pattern = re.compile(r'<a href="([^"]+)" target="_blank" data-mp4="true">')
        td_pattern = re.compile(r"<td[^>]*>(.*?)</td>")

        iframe_match = iframe_pattern.findall(row)
        href_match = href_pattern.findall(row)
        td_values = td_pattern.findall(row)
        # fflog(f'{len(td_values)=}  {td_values=}',1,1)

        if iframe_match:
            # fflog(f'{iframe_match=}',1,1)
            hrefok = self._decode_base64_url(iframe_match[0])
            sound, quality = self._extract_td_values(td_values, 1, 2)
        elif href_match:
            # fflog(f'{href_match=}',1,1)
            hrefok = self._decode_base64_url(href_match[0])
            sound, quality = self._extract_td_values(td_values, -3, -2)
        else:
            hrefok = None
            fflog(f'{hrefok=} {iframe_match=} {href_match=}',1,1)

        if hrefok:
            sound, lang = self._process_sound(sound)
            # fflog(f'{sound=} {lang=}',1,1)
            ago = re.sub(".*dodane (.*?temu).*", r"\1", td_values[0])
            # fflog(f'{ago=}',1,1)
            if ago.lower() == lang.lower():
                ago = "bez limitów"
                ago = "_"
            # fflog(f'{ago=}',1,1)
            host = re.search(r' alt="(.*?)"', td_values[0]);  host = host[1] if host else ""
            premium = True if "bez limitów" in row else False
            return {"host": host, "url": hrefok, "quality": quality, "sound": sound, "lang": lang, "ago": ago, "premium": premium}

        return {}


    def _decode_base64_url(self, encoded_url: str) -> str:
        decoded_iframe = base64.b64decode(encoded_url).decode("utf-8").replace("\\/", "/")
        # fflog(f'{decoded_iframe=}',1,1)
        # POPRAWKA: wolfstraam też może być w JSON - wyciągamy src zamiast zwracać cały string
        iframe = re.findall(r"src['\"]:['\"](https?://[^'\"]+)", decoded_iframe)
        if iframe:
            return iframe[0]
        # Fallback: spróbuj zwykłego src bez https - na wypadek innych formatów
        iframe = re.findall(r"src['\"]:['\"](.+?)['\"]", decoded_iframe)
        if iframe:
            return iframe[0]
        # Ostatni fallback: zwróć cały string (np. bezpośredni URL)
        return decoded_iframe


    def _extract_td_values(self, td_values: List[str], sound_idx: int, quality_idx: int) -> (str, str):
        sound = td_values[sound_idx].strip()
        quality = td_values[quality_idx].strip()
        # fflog(f'{quality=}',1,1)
        # quality = source_utils.check_sd_url(quality)
        return sound, quality


    def _process_sound(self, sound: str) -> (str, str):
        # sound = sound.replace("Napisy_Tansl", "napisy").replace("ENG", "en")
        sound = sound.replace("_", " ").replace("ENG", "en")
        lang = "en" if "en" in sound else "pl"
        sound = " " if lang == "en" else sound
        sound = sound.replace("PL", "").strip()
        return sound, lang


    def get_url_req(self, url, ref="https://filman.cc/", allow=True):
        """Make HTTP request with cookies."""
        try:
            cookies_str = cache.cache_get("filman_cookie", control.sourcescacheFile)
            if cookies_str:
                cookies_str = cookies_str.get("value")
                cookies = dict(cookie.split("=") for cookie in cookies_str.split("; "))
                self.session.cookies.update(cookies)

            headers = {
                "Host": "filman.cc",
                "User-Agent": self.USER_AGENT,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
                "Referer": ref,
                "Upgrade-Insecure-Requests": "1",
            }

            self.session.headers.update(headers)
            response = self.session.get(url, verify=False, allow_redirects=allow)

            if "Security Check" in response.text:
                response = self.session.get(url, headers=headers)
                cookies = "; ".join([f"{x}={y}" for x, y in self.session.cookies.get_dict().items()])
                cache.cache_insert("filman_cookie", cookies, control.sourcescacheFile)

            return response.text if allow else response.content
        except Exception:
            fflog_exc(1)


    # stworzone przez ChatGPT
    def parse_time_string(self, time_str):
        """
        Przekształca słowny opis czasu w liczbę sekund temu.
        Obsługuje zarówno "1 rok temu", jak i "rok temu".
        """
        match = re.match(r"(?:\b(\d+)\b\s+)?(\w+)", time_str)
        if not match:
            return float('inf')  # Nieznany format – wrzucamy na koniec
        value, unit = match.groups()
        value = int(value) if value else 1  # Domyślnie 1, jeśli brak liczby
        # fflog(f'{value=}  {unit=}  {time_str=}',1,1)
        multiplier = self.TIME_UNITS.get(unit, None)
        if multiplier is None:
            return float('inf')
        return value * multiplier


    def sort_by_ago(self, data, key="ago"):
        """
        Sortuje listę słowników według czasu w polu 'key' (np. 'ago').
        """
        # fflog(f'data={json.dumps(data, indent=2)}',1,1)
        try:
            # return sorted(data, key=lambda x: self.parse_time_string(x[key]))
            return sorted(data, key=lambda x: (self.parse_time_string(x[key]), -int(x['quality'].replace('p',''))) )
        except Exception:
            fflog_exc(1)
            return data
            pass

