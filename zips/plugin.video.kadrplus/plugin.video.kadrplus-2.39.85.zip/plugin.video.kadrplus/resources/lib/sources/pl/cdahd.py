"""
    FanFilm Add-on
    Copyright (C) 2025

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
"""

import urllib.parse as urlparse
import json
import re
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from html import unescape

from ptw.libraries import cleantitle, source_utils, control
from ptw.libraries import client
from ptw.debug import fflog_exc, fflog


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["cda-hd.cc"]
        self.base_link = "https://cda-hd.cc"
        self.search_link = "/?s=%s"
        self.headers = {}
        self.session = None


    def init(self, get_cookies_from_file=None):
        """Inicjalizacja sesji i nagłówków. Osobna metoda bo __init__ jest wywoływane
        nawet gdy źródła są z cache i sesja nie jest potrzebna."""
        if not self.session:
            try:
                from resources.lib.sources.doh_helper import make_doh_session
                self.session = make_doh_session()
                fflog('[cdahd] sesja DoH OK', 1)
            except Exception:
                import requests
                self.session = requests.Session()
                self.session.verify = False
                fflog('[cdahd] sesja requests (fallback)', 1)

        self.cdahd_files = control.setting("cdahd.files") == "true"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/142.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Sec-GPC": "1",
            "DNT": "1",
            "TE": "trailers",
            "Referer": "https://cda-hd.cc/",
        }

        if UA := control.setting("cdahd.ua").strip().strip('"\''):
            self.headers.update({"User-Agent": UA})

        cf = ""
        user_cookies = control.setting("cdahd.cookies").strip().strip('"\'')

        if user_cookies:
            self.headers.update({"Cookie": user_cookies})

        if get_cookies_from_file:
            fflog(f'{get_cookies_from_file=}', 1, 1)

            if dest := control.setting("cdahd.ua.file"):
                if control.existsPath(dest):
                    with control.openFile(dest) as f:
                        content = f.read()
                    content = content.replace('\ufeff', '')  # BOM
                    ua = content.strip().strip('"\'')
                    fflog(f'{ua=}', 1, 1)
                    if ua:
                        control.setSetting("cdahd.ua", ua)
                        self.headers.update({"User-Agent": ua})
                else:
                    fflog(f'nie można połączyć się z plikiem UserAgenta {dest=}', 1, 1)
            else:
                fflog(f'brak ścieżki do pliku UserAgenta', 1, 1)

            if dest := control.setting("cdahd.cf.file"):
                if control.existsPath(dest):
                    with control.openFile(dest) as f:
                        content = f.read()
                    content = content.replace('\ufeff', '').strip().strip('"\'')  # BOM
                    cookies_raw = ""
                    if content.startswith("[") or content.startswith("{"):
                        parsed = json.loads(content)
                        if isinstance(parsed, list):
                            cookies_raw = "; ".join(f'{c["name"]}={c["value"]}' for c in parsed)
                        elif isinstance(parsed, dict):
                            cookies_raw = "; ".join(f'{c["name"]}={c["value"]}' for c in [parsed])
                    else:
                        cookies_raw = content
                    if cookies_raw:
                        if "=" in cookies_raw:
                            cookiesD = {x[0].strip(): x[1].strip() for x in [c.split("=") for c in cookies_raw.strip("; ").split(";")]}
                            cf = cookiesD.get('cf_clearance', '')
                        else:
                            cf = cookies_raw
                        fflog(f'{cf=}', 1, 1)
                        if cf:
                            control.setSetting("cdahd.cf", cf)
                else:
                    fflog(f'nie można połączyć się z plikiem ciasteczka {dest=}', 1, 1)
            else:
                fflog(f'brak ścieżki do pliku ciasteczka', 1, 1)

            control.setting = control.addon().getSetting  # odświeżenie cache

        if not cf:
            cf = control.setting("cdahd.cf").strip().strip('"\'')

        cookies = ("; cf_clearance=" + cf).strip("; ") if cf else ""
        if cookies:
            self.headers.update({'Cookie': cookies})


    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        year_alt = kwargs.get("year_alt")
        year = (year, year_alt) if year_alt else year
        return self.do_search(title, localtitle, year, aliases)


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        year_alt = kwargs.get("year_alt")
        year = (year, year_alt) if year_alt else year
        return self.do_search(tvshowtitle, localtvshowtitle, year, aliases)


    def do_search(self, title, localtitle, year, aliases=None, recurency=None):
        if isinstance(year, tuple):
            year, year_alt = year
        else:
            year_alt = ""

        try:
            if aliases:
                originalname = [a for a in aliases if "originalname" in a]
                originalname = originalname[0]["originalname"] if originalname else ""
                originalname = "" if source_utils.czy_litery_krzaczki(originalname) else originalname

                aliases1 = [
                    (a.get("title") or a.get("originalname") or "")
                    + " (" + a.get("country", "") + ")"
                    for a in aliases
                ]
                aliases2 = [a.rpartition(" (")[0] for a in aliases1]
                aliases2 = [a.replace(year, "").replace("()", "").rstrip() for a in aliases2]
                aliases2 = [a for a in aliases2 if not source_utils.czy_litery_krzaczki(a)]
                aliases2 = [alias for i, alias in enumerate(aliases2) if alias.lower() not in [x.lower() for x in aliases2[:i]]]
            else:
                originalname = ""
                aliases2 = []

            titles = list(filter(None, [localtitle, originalname, title]))
            titles = list(dict.fromkeys(titles))
            titles += aliases2

            seen = set()
            unique_titles = []
            for t in titles:
                if t:
                    normalized = cleantitle.get_simple(t)
                    if normalized not in seen:
                        unique_titles.append(t)
                        seen.add(normalized)
            titles = unique_titles[:4]

            titles_for_compare = [t.replace("⁄", "").replace(" ", "") for t in titles]

            if not recurency:
                self.init()

            headers = self.headers
            cookies = headers.get('Cookie')
            cookiesD = {x[0].strip(): x[1].strip() for x in [c.split("=") for c in cookies.strip("; ").split(";")]} if cookies else {}

            for title in titles:
                try:
                    if not title:
                        continue

                    url = urlparse.urljoin(self.base_link, self.search_link)
                    url = url % urlparse.quote_plus(cleantitle.query(title))
                    fflog(f'[cdahd] [do_search]  {url=}', 1, 1)

                    result = self.session.get(url, cookies=cookiesD, headers=headers, verify=False, timeout=7)
                    if result is None or result.status_code >= 400:
                        fflog(f'{result=}', 1, 1)
                        is_cf = self.check_if_cf(result, recurency or not self.cdahd_files)
                        if is_cf or (result is not None and result.status_code in (403, 429, 503)):
                            fflog('[cdahd] Cloudflare/403 active - skipped safely', 1, 1)
                            return []
                        if not control.window.getProperty("blocked_sources_extend") == 'break':
                            if recurency:
                                control.infoDialog("nieprawidłowa odpowiedź serwera: " + str(result.status_code), 'CDA-HD.cc', "WARNING")
                            if not recurency and is_cf and self.cdahd_files:
                                fflog(f'spróbuję pobrać ciasteczko z pliku i powtórzyć szukanie', 1, 1)
                                self.init(get_cookies_from_file=True)
                                return self.do_search(title, localtitle, (year, year_alt), aliases, recurency=True)
                            return
                        continue

                    result = result.text

                    if "rak wynik" in result:
                        fflog(f"Brak wyników dla {title=}", 1, 1)
                        continue
                    elif "ykryto niezgodność wartości" in result:
                        fflog(f"Wykryto niezgodność wartości {title=} {url=}", 1, 1)
                        continue

                    try:
                        result = client.parseDOM(result, "div", attrs={"class": "peliculas"})[0]
                        res = client.parseDOM(result, "div", attrs={"class": "item_1 items"})[0]
                        rows = client.parseDOM(res, "div", attrs={"class": "item"})
                    except Exception:
                        if "<title>Just a moment...</title>" in result:
                            fflog('[cdahd] Cloudflare active - skipped safely', 1, 1)
                            return []
                        fflog(f'wystąpił jakiś błąd przy parsowaniu wyników', 1, 1)
                        fflog_exc(0)
                        continue

                    for row in rows:
                        rok = client.parseDOM(row, "span", attrs={"class": "year"})[0]
                        tytul = client.parseDOM(row, "h2")[0].replace(f" ({rok})", "").rstrip()
                        tytul = unescape(tytul)
                        tytuly = tytul.split(" / ")
                        title1 = tytuly[0].replace("⁄", "").replace(" ", "")
                        title2 = tytuly[-1].replace("⁄", "").replace(" ", "")
                        if (
                            (str(year) in str(rok) or year_alt and str(year_alt) in str(rok))
                            and any(t in titles_for_compare for t in (title1, title2))
                        ):
                            url = client.parseDOM(row, "a", ret="href")[0]
                            fflog(f'pasuje {url=}', 1, 1)
                            return url

                except Exception:
                    fflog_exc(1)
                    continue

            fflog("nic nie znaleziono")
        except Exception:
            fflog_exc(1)
            return


    def check_if_cf(self, result, recurency=None):
        is_cf = False
        if not isinstance(result, str):
            if hasattr(result, 'status_code') and result.status_code == 403:
                is_cf = True
            try:
                result = result.text
            except Exception:
                result = ''
        if not is_cf and "<title>Just a moment...</title>" in result:
            is_cf = True
        if is_cf:
            fflog(f'strona schowana obecnie za Cloudflare', 1, 1)
            if not control.window.getProperty("blocked_sources_extend") == 'break':
                if recurency:
                    control.infoDialog(
                        "CDA-HD.cc zablokowane przez Cloudflare.\n"
                        "Otwórz cda-hd.cc w przeglądarce, poczekaj aż się załaduje,\n"
                        "skopiuj ciasteczko cf_clearance i wklej w Ustawienia → CDA-HD.cc",
                        'CDA-HD.cc — Cloudflare', "WARNING"
                    )
        return is_cf


    def episode(self, url, imdb, tvdb, title, premiered, season, episode, recurency=None):
        if not url:
            fflog(f'{url=}', 1, 1)
            return

        if not recurency:
            self.init()

        headers = self.headers
        cookies = headers.get('Cookie')
        cookiesD = {x[0].strip(): x[1].strip() for x in [c.split("=") for c in cookies.strip("; ").split(";")]} if cookies else {}

        result = self.session.get(url, cookies=cookiesD, headers=headers, verify=False)
        if result is None or result.status_code >= 400:
            fflog(f'{result=}', 1, 1)
            is_cf = self.check_if_cf(result, recurency or not self.cdahd_files)
            if is_cf and not recurency and self.cdahd_files:
                fflog(f'spróbuję pobrać ciasteczko z pliku i powtórzyć szukanie', 1, 1)
                self.init(get_cookies_from_file=True)
                return self.episode(url, imdb, tvdb, title, premiered, season, episode, recurency=True)
            return
        result = result.text

        # cda-hd.cc ma błąd w HTML (<div>\n</li>) który psuje parseDOM episodów
        # dlatego szukamy przez ul.episodios zamiast div.episodiotitle
        seasons = client.parseDOM(result, "ul", attrs={"class": "episodios"})
        episodes = client.parseDOM(seasons, "a", ret="href")
        for episode_url in episodes:
            if f"sezon-{season}-odcinek-{episode}-" in episode_url:
                fflog(f'pasujący odcinek to {episode_url=}', 1, 1)
                return episode_url
        fflog("brak pasującego odcinka", 1, 1)


    def sources(self, url, hostDict, hostprDict, recurency=None):
        sources = []
        if url is None:
            fflog(f'{url=}', 1, 1)
            return sources

        url0 = url
        try:
            if not recurency:
                self.init()
            headers = self.headers
            cookies = headers.get('Cookie')
            cookiesD = {x[0].strip(): x[1].strip() for x in [c.split("=") for c in cookies.strip("; ").split(";")]} if cookies else {}

            result = self.session.get(url, cookies=cookiesD, headers=headers, verify=False)
            if result is None or result.status_code >= 400:
                fflog(f'problem, bo {result=}', 1, 1)
                is_cf = self.check_if_cf(result, recurency or not self.cdahd_files)
                if is_cf and not recurency and self.cdahd_files:
                    fflog(f'spróbuję pobrać ciasteczko z pliku i powtórzyć szukanie', 1, 1)
                    self.init(get_cookies_from_file=True)
                    return self.sources(url, hostDict, hostprDict, recurency=True)
                return sources
            result = result.text

            if "/episode/" in url:
                serial = True
                result = client.parseDOM(result, "div", attrs={"class": "player2"})
                results_player = client.parseDOM(result, "div", attrs={"class": "embed2"})
                results_player = client.parseDOM(results_player, "div")
                results_player = list(filter(None, results_player))
                results_navi = client.parseDOM(result, "div", attrs={"class": "navplayer2"})
                results_navi = client.parseDOM(results_navi, "a", attrs={"href": ""})
                results_navi = list(filter(None, results_navi))
            else:
                serial = False
                results_player = client.parseDOM(result, "div", attrs={"id": "player2"})
                results_player = client.parseDOM(results_player, "div", attrs={"class": "movieplay"})
                results_player = list(filter(None, results_player))
                results_navi = client.parseDOM(result, "div", attrs={"class": "player_nav"})
                results_navi = client.parseDOM(results_navi, "a")
                results_navi = list(filter(None, results_navi))

            if len(results_navi) != len(results_player):
                results_navi = [item for item in results_navi if not item.endswith('Reklama')]

            if len(results_navi) != len(results_player):
                fflog(f'nie można kontynuować, bo {len(results_navi)=} != {len(results_player)=}', 1, 1)
                fflog(f'results_navi={json.dumps(results_navi, indent=2)}', 0, 1)
                fflog(f'results_player={json.dumps(results_player, indent=2)}', 0, 1)
                return sources

            try:
                quality = client.parseDOM(result, "span", attrs={"class": "calidad2"})[0]
            except:
                quality = ""

            i = -1
            for item in results_navi:
                try:
                    i += 1
                    jezyk = re.sub("<[^>]+>", "", item)
                    jezyk, info = self.get_lang_by_type(jezyk)

                    url = results_player[i]
                    try:
                        url = client.parseDOM(url, "a", ret="href")[0]
                    except:
                        try:
                            domain = client.parseDOM(url, "div", ret="domain")[0]
                            encoded_vid = client.parseDOM(url, "div", ret="id")[0]
                            decoded_vid = self.decode_id(encoded_vid)
                            url = f"https://{domain}/e/{decoded_vid}"
                        except Exception:
                            try:
                                url = client.parseDOM(url, "iframe", ret="src")[0]
                                url = url.replace("player.cda-hd.co/", "hqq.to/")
                            except Exception:
                                try:
                                    if not 'src="https://player.cda-hd.co/player/hash.php?hash=' in url:
                                        raise Exception()
                                    hash = re.search(r"hash=(\d+)", url)[1]
                                    url = f"https://hqq.to/e/{hash}"
                                except Exception:
                                    fflog(f"can't find proper url for this source  |  {url=}", 1, 1)
                                    continue

                    valid, host = source_utils.is_host_valid(url, hostDict)
                    host = host.rsplit(".", 1)[0]

                    unsure = None
                    if "wysoka" in quality.lower() or quality == "HD":
                        jakosc = "1080p"
                        unsure = ["quality"]
                    elif "rednia" in quality.lower():
                        jakosc = "SD"
                    elif "niska" in quality.lower() or quality == "CAM":
                        jakosc = "CAM"
                    else:
                        jakosc = "HD" if serial else "SD"

                    info2 = url0.rstrip("/").rsplit("/")[-1]

                    sources.append({
                        "source": host,
                        "quality": jakosc,
                        "language": jezyk,
                        "url": url,
                        "info": info,
                        "info2": info2,
                        "direct": False,
                        "debridonly": False,
                    })
                    if unsure:
                        sources[-1].update({"unsure": unsure})

                except:
                    fflog_exc(1)
                    continue

            fflog(f'przekazano źródeł: {len(sources)}')
            return sources

        except Exception:
            fflog_exc(1)
            return sources


    def get_lang_by_type(self, lang_type):
        lang = lang_type.lower()
        if "dubbing" in lang:
            return ("pl", "Dubbing Kino") if "kino" in lang else ("pl", "Dubbing")
        elif "lektor" in lang:
            return "pl", "Lektor"
        elif "napisy" in lang:
            return "pl", "Napisy"
        elif "pl" in lang:
            return "pl", None
        return "en", None


    def decode_id(self, id_hex):
        s1 = ''.join(chr(int(id_hex[i:i+2], 16) ^ 0x02) for i in range(0, len(id_hex), 2))
        return ''.join(format(ord(ch) ^ 0x04, 'x') for ch in s1)


    def resolve(self, url):
        return url
