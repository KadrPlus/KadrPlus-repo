# -*- coding: utf-8 -*-

"""
    FanFilm Add-on
    Copyright (C) 2015 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

from ptw.libraries import control
from ptw.libraries import log_utils
from ptw.libraries.log_utils import log, fflog
from ptw.debug import log_exception, fflog_exc
from ptw.libraries import trakt

# niektóre nie mają imdb
# imdb = imdb or tmdb


def _kadrplus_ensure_bookmarks_table(dbcur):
    """
    Kadr+ 2.40.20: defensywne utworzenie i migracja tabeli bookmarks.
    Starsze profile potrafią mieć tabelę bez kolumn `season`/`episode`, co powodowało
    `sqlite3.OperationalError: no such column: season` przy odtwarzaniu seriali.
    """
    try:
        dbcur.execute(
            "CREATE TABLE IF NOT EXISTS bookmarks ("
            "timeInSeconds TEXT, "
            "type TEXT, "
            "imdb TEXT, "
            "season TEXT, "
            "episode TEXT, "
            "playcount INTEGER, "
            "overlay INTEGER, "
            "UNIQUE(imdb, season, episode)"
            ");"
        )
        try:
            dbcur.execute("PRAGMA table_info(bookmarks);")
            _cols = [str(_r[1]) for _r in dbcur.fetchall()]
            _wanted = [
                ("timeInSeconds", "TEXT"),
                ("type", "TEXT"),
                ("imdb", "TEXT"),
                ("season", "TEXT"),
                ("episode", "TEXT"),
                ("playcount", "INTEGER DEFAULT 0"),
                ("overlay", "INTEGER DEFAULT 6"),
            ]
            for _name, _decl in _wanted:
                if _name not in _cols:
                    try:
                        dbcur.execute("ALTER TABLE bookmarks ADD COLUMN %s %s;" % (_name, _decl))
                    except Exception:
                        pass
        except Exception:
            pass
    except Exception:
        pass



def _kadrplus_row_value(row, columns, name, default=None):
    try:
        if row is None:
            return default
        if columns and name in columns:
            return row[columns.index(name)]
    except Exception:
        pass
    return default


def get(media_type, imdb, season=None, episode=None, local=False, tmdb=None, threshold=92):  # tmdb nie dorobione jeszcze
    # fflog(f'{media_type=} {imdb=} {local=} {season=} {episode=} {tmdb=} {threshold=}',1,1)

    imdb = None if imdb == "0" or imdb == "None" else imdb
    tmdb = None if tmdb == "0" or tmdb == "None" else tmdb

    offset = 0
    runtime = 0
    # imdb = imdb or tmdb
    # imdb = tmdb or imdb
    source = None

    # threshold = threshold * 100 if threshold <= 1 else threshold
    # fflog(f'{threshold=}',1,1)
    threshold = 92  # tu nie przeszkadza duży, nawet może i lepiej

    if (
        local == False
        #and control.setting('resume.source') == '1'  # nie ma takiego settingsu
        and trakt.getTraktIndicatorsInfo()
        and trakt.getTraktCredentialsInfo() == True
        ):
        try:
            fflog(f'from trakt', 0)
            source = 'trakt'
            #control.sleep(500)
            if media_type == 'episode':
                # Looking for a Episode progress
                traktInfo = trakt.getTraktAsJson('https://api.trakt.tv/sync/playback/episodes?extended=full')
                fflog(f'{traktInfo=}') if not traktInfo else ""
                for i in traktInfo:
                    if imdb == i['show']['ids']['imdb'] or tmdb == i['show']['ids']['tmdb']:
                        # Checking Episode Number
                        if int(season) == i['episode']['season'] and int(episode) == i['episode']['number']:
                            runtime = int(i['episode']['runtime']) * 60
                            fflog(f"{i['progress']=}",0)
                            seekable = 1 < i['progress'] < threshold
                            fflog(f'{seekable=}',0)
                            if seekable:
                                # Calculating Offset to seconds
                                offset = float(i['progress'] / 100) * int(i['episode']['runtime']) * 60
                            else:
                                offset = 0
            else:
                # Looking for a Movie Progress
                traktInfo = trakt.getTraktAsJson('https://api.trakt.tv/sync/playback/movies?extended=full')  # full aby mieć runtime, tylko czemu szuka wszystkich filmów, a nie tylko jednego ?
                fflog(f'{traktInfo=}') if not traktInfo else ""
                for i in traktInfo:
                    if imdb == i['movie']['ids']['imdb'] or tmdb == i['movie']['ids']['tmdb']:
                        runtime = int(i['movie']['runtime']) * 60
                        fflog(f"{i['progress']=}",0)
                        seekable = 1 < i['progress'] < threshold
                        fflog(f'{seekable=}',0)
                        if seekable:
                            # Calculating Offset to seconds
                            offset = float(i['progress'] / 100) * int(i['movie']['runtime']) * 60
                        else:
                            offset = 0
            fflog(f'{offset=}  {runtime=}', 0)
            if offset > 0:  # chociaż ten warunek też jest dalej sprawdzany
                return offset, runtime, source  # więc może tego tu nie być
                pass
        except Exception:
            fflog_exc(1)
            offset = 0

    # else:
    if True:
        if offset == 0:  # ten warunek jest ważny
            fflog(f'from local machine', 0)
            source = 'local'

            # runtime = 0  # pomyśleć nad tym

            # imdb = imdb or tmdb
            # imdb = tmdb or imdb
            if not isinstance(imdb, (tuple, list)):
                if imdb and tmdb:
                    id_db = [imdb, tmdb]
                else:
                    id_db = [imdb or tmdb]
            else:
                id_db = imdb

            id_db = list(filter(None, id_db))  # usunięcie pustych
            id_db = list(dict.fromkeys(id_db))  # pozbycie się duplikatów
            
            try:
                control.makeFile(control.dataPath)
                dbcon = database.connect(control.bookmarksFile)
                dbcur = dbcon.cursor()
                _kadrplus_ensure_bookmarks_table(dbcur)

                for iddb in id_db:
                    if iddb:
                        # sql_select = "SELECT * FROM bookmarks WHERE (imdb = '%s' OR imdb = '%s')" % (iddb, iddb)
                        sql_select = "SELECT * FROM bookmarks WHERE imdb = '%s'" % iddb
                        if media_type == "episode":
                            sql_select += " AND season = '%s' AND episode = '%s'" % (season, episode)
                        else:
                            sql_select += " AND type = '%s'" % media_type
                        _kadrplus_ensure_bookmarks_table(dbcur)
                        dbcur.execute(sql_select)
                        match = dbcur.fetchone()
                        if match:
                            offset = match[0]
                            offset = float(offset)
                            break
                        else:
                            offset = 0
                        fflog(f'{offset=}', 0)

            except Exception as e:
                log_utils.log("bookmarks_get %s" % e, "module")
                fflog_exc(1)
                offset = 0

    #return offset
    # return offset, runtime
    return offset, runtime, source


def reset(current_time, total_time, media_type, imdb, season="", episode="", threshold=0.92, tmdb=None):
    """ nie wiem, czemu to się nazywa reset (ja bym dał coś z set w nazwie) """
    # fflog(f'[reset] {current_time=} {total_time=} {imdb=} {tmdb=} {season=} {episode=} {threshold=}')
    tmdb = None  if tmdb == "0" or tmdb == "None"  else tmdb
    imdb = None  if imdb == "0" or imdb == "None"  else imdb
    if not tmdb:
        # if not imdb or imdb == "0" or imdb == "None":
        if not imdb:
            fflog(f'nieprawidłowy parametr {imdb=}',1,1)
            return False
    try:
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()

        threshold = float(threshold / 100) if threshold > 1 else threshold
        # fflog(f'{threshold=}',1,1)

        _playcount = 0

        overlay = 6

        timeInSeconds = str(current_time)

        # taki pomysł
        if threshold == 0.92:
            # fflog(f'{threshold=}',1,1)
            if media_type == "movie":
                total_time -= 60 * 10 if total_time > 60*20 else 0 # korekta na napisy końcowe
                pass
            else:  # seriale
                total_time -= 60 * 5  if total_time > 60*10 else 0 # korekta na napisy końcowe
                pass
            if total_time > 60 * 5:
                fflog(f'{threshold=}',1,1)
                pass
           
        ok = int(current_time) > 120 and (current_time / total_time) < threshold

        watched = (current_time / total_time) >= threshold
        # fflog(f'{watched=}',1,1)

        if tmdb and imdb:
            sql_select = "SELECT * FROM bookmarks WHERE (imdb = '%s' or imdb = '%s')" % (imdb, tmdb)
        elif tmdb:
            sql_select = "SELECT * FROM bookmarks WHERE imdb = '%s'" % tmdb
        elif imdb:  # aby nie było pustego, czy też None
            sql_select = "SELECT * FROM bookmarks WHERE imdb = '%s'" % imdb
        else:
            sql_select = ""
        if sql_select:
            if media_type == "episode":
                sql_select += " AND season = '%s' AND episode = '%s'" % (season, episode)
            else:
                sql_select += " AND type = '%s'" % media_type
        else:
            fflog(f'błąd, bo {sql_select=}',1,1)
            return False

        if tmdb and imdb:
            sql_update = "UPDATE bookmarks SET timeInSeconds = '%s' WHERE (imdb = '%s' OR imdb = '%s')" % (timeInSeconds, imdb, tmdb)
        elif tmdb:
            sql_update = "UPDATE bookmarks SET timeInSeconds = '%s' WHERE imdb = '%s'" % (timeInSeconds, tmdb,)
        elif imdb:
            sql_update = "UPDATE bookmarks SET timeInSeconds = '%s' WHERE imdb = '%s'" % (timeInSeconds, imdb,)
        if media_type == "episode":
            sql_update += " AND season = '%s' AND episode = '%s'" % (season, episode)
        else:
            sql_update += " AND type = '%s'" % media_type

        if media_type == "movie":
            if tmdb and imdb:
                sql_update_watched = (
                    "UPDATE bookmarks SET timeInSeconds = '%s', playcount = %s, overlay = %s WHERE (imdb = '%s' OR imdb = '%s')" % (timeInSeconds, "%s", "%s", imdb, tmdb)
                )
                sql_update_watched += " AND type = '%s'" % media_type
            elif tmdb:
                sql_update_watched = (
                    "UPDATE bookmarks SET timeInSeconds = '%s', playcount = %s, overlay = %s WHERE imdb = '%s'" % (timeInSeconds, "%s", "%s", tmdb)
                )
                sql_update_watched += " AND type = '%s'" % media_type
            else:
                sql_update_watched = (
                    # "UPDATE bookmarks SET timeInSeconds = '0', playcount = %s, overlay = %s WHERE imdb = '%s'" % ("%s", "%s", imdb)
                    "UPDATE bookmarks SET timeInSeconds = '%s', playcount = %s, overlay = %s WHERE imdb = '%s'" % (timeInSeconds, "%s", "%s", imdb)
                )
        elif media_type == "episode":
            if tmdb and imdb:
                sql_update_watched = (
                    "UPDATE bookmarks SET timeInSeconds = '%s', playcount = %s, overlay = %s WHERE (imdb = '%s' OR imdb = '%s') AND season = '%s' AND episode = '%s'" % (timeInSeconds, "%s", "%s", imdb, tmdb, season, episode)
                )
            elif tmdb:
                sql_update_watched = (
                    "UPDATE bookmarks SET timeInSeconds = '%s', playcount = %s, overlay = %s WHERE imdb = '%s' AND season = '%s' AND episode = '%s'" % (timeInSeconds, "%s", "%s", tmdb, season, episode)
                )
            else:
                sql_update_watched = (
                    # "UPDATE bookmarks SET timeInSeconds = '0', playcount = %s, overlay = %s WHERE imdb = '%s' AND season = '%s' AND episode = '%s'" % ("%s", "%s", imdb, season, episode)
                    "UPDATE bookmarks SET timeInSeconds = '%s', playcount = %s, overlay = %s WHERE imdb = '%s' AND season = '%s' AND episode = '%s'" % (timeInSeconds, "%s", "%s", imdb, season, episode)
                )

        if media_type == "movie":
            sql_insert = (
                "INSERT INTO bookmarks (timeInSeconds, type, imdb, season, episode, playcount, overlay) Values ('%s', '%s', '%s', '', '', '%s', '%s')"
                % (timeInSeconds, media_type, imdb or tmdb, _playcount, overlay)
            )
        elif media_type == "episode":
            sql_insert = (
                "INSERT INTO bookmarks (timeInSeconds, type, imdb, season, episode, playcount, overlay) Values ('%s', '%s', '%s', '%s', '%s', '%s', '%s')"
                % (
                    timeInSeconds,
                    media_type,
                    imdb or tmdb,
                    season,
                    episode,
                    _playcount,
                    overlay,
                )
            )

        if media_type == "movie":
            sql_insert_watched = (
                "INSERT INTO bookmarks (timeInSeconds, type, imdb, season, episode, playcount, overlay) Values ('%s', '%s', '%s', '', '', '%s', '%s')"
                % (timeInSeconds, media_type, imdb or tmdb, "%s", "%s")
            )
        elif media_type == "episode":
            sql_insert_watched = (
                "INSERT INTO bookmarks (timeInSeconds, type, imdb, season, episode, playcount, overlay) Values ('%s', '%s', '%s', '%s', '%s', '%s', '%s')"
                % (timeInSeconds, media_type, imdb or tmdb, season, episode, "%s", "%s")
            )

        if not sql_select:
            fflog(f'błąd, bo {sql_select=}',1,1)
            return False
        _kadrplus_ensure_bookmarks_table(dbcur)
        dbcur.execute(sql_select)
        match = dbcur.fetchone()
        try:
            _kadrplus_cols = [d[0] for d in (dbcur.description or [])]
        except Exception:
            _kadrplus_cols = []
        # fflog(f'{match=} {imdb=}',1,1)
        fflog(f'{match=}  {ok=}  {watched=}  {current_time=}  {total_time=}  {imdb=}  {tmdb=}',1,1)
        if match:
            fflog('update',1,1)
            if ok:
                # fflog(f'{sql_update=}',1,1)
                _kadrplus_ensure_bookmarks_table(dbcur)
                dbcur.execute(sql_update)
            elif watched:
                try:
                    _playcount = int(_kadrplus_row_value(match, _kadrplus_cols, 'playcount', 0) or 0) + 1
                except Exception:
                    _playcount = 1
                overlay = 7
                if 0:  # nie wiem, na który wariant się zdecydować
                    # fflog(f'{sql_update_watched % (_playcount, overlay)=}',1,1)
                    _kadrplus_ensure_bookmarks_table(dbcur)
                    dbcur.execute(sql_update_watched % (_playcount, overlay))
                else:  # aby osatnio oglądany pojawiał się na końcu w tabeli
                    is_ok = _delete_record(media_type, imdb, season, episode, tmdb=tmdb)  # przydaje się, aby osatnio oglądany pojawiał się na końcu w tabeli
                    if is_ok is False:
                        # fflog(f'{sql_update_watched % (_playcount, overlay)=}',1,1)
                        _kadrplus_ensure_bookmarks_table(dbcur)
                        dbcur.execute(sql_update_watched % (_playcount, overlay))
                    else:
                        fflog('insert',1,1)
                        _kadrplus_ensure_bookmarks_table(dbcur)
                        dbcur.execute(sql_insert_watched % (_playcount, overlay))
        else:
            fflog('insert',1,1)
            if ok:
                # fflog(f'{sql_insert=}',1,1)
                _kadrplus_ensure_bookmarks_table(dbcur)
                dbcur.execute(sql_insert)
            elif watched:
                _playcount = 1
                overlay = 7
                # fflog(f'{sql_insert_watched % (_playcount, overlay)=}',1,1)
                _kadrplus_ensure_bookmarks_table(dbcur)
                dbcur.execute(sql_insert_watched % (_playcount, overlay))
        dbcon.commit()
    except Exception:
        log_utils.log("bookmarks_reset", "module")
        fflog_exc(1)
        return False
        pass


def set_scrobble(current_time, total_time, _content, imdb="", _tvdb="", season="", episode="", last_time=0, action="", threshold=92, tmdb=None):
    #fflog(f'[set_scrobble] {current_time=} {total_time=} {imdb=} {season=} {episode=} {threshold=} {tmdb=}')
    try:
        threshold = threshold * 100 if threshold <= 1 else threshold
        # fflog(f'{threshold=}',1,1)

        # taki pomysł
        if threshold == 92:
            # fflog(f'{threshold=}',1,1)
            if _content == "movie":
                total_time -= 60 * 10 if total_time > 60*20 else 0 # korekta na napisy końcowe
                pass
            else:  # seriale
                total_time -= 60 * 5  if total_time > 60*10 else 0 # korekta na napisy końcowe
                pass
            fflog(f'{threshold=}',1,1)

        if current_time <= 120 and last_time:
            current_time = last_time
        if not (current_time == 0 or total_time == 0):
            percent = float((current_time / total_time)) * 100
        else:
            percent = 0
        # fflog(f'{percent=}')

        if action == "start" and percent < 99:
            trakt.scrobbleMovie(
                imdb, percent, action="start", tmdb=tmdb
            ) if _content == "movie" else trakt.scrobbleEpisode(
                imdb, season, episode, percent, action="start", tmdb=tmdb
            )
            #if control.setting("trakt.scrobble.notify") == "true":  # nie ma takiego ustawienia
            if True:
                #control.sleep(1000)
                control.infoDialog("Trakt: Scrobble Start", time=1)
                fflog("Trakt: Scrobble Start")
            return

        #if int(current_time) > 120 and 2 < percent < 92:
        if percent < threshold:  # zatrzymanie wideo powinno także zatrzymać progress w dashboardzie, niezależnie od procentu (poniżej granicy finish)
            trakt.scrobbleMovie(
                imdb, percent, action="pause", tmdb=tmdb
            ) if _content == "movie" else trakt.scrobbleEpisode(
                imdb, season, episode, percent, action="pause", tmdb=tmdb
            )
            #if control.setting("trakt.scrobble.notify") == "true":  # nie ma takiego ustawienia
            if True:
                #control.sleep(1000)
                control.infoDialog("Trakt: Scrobble Paused", time=1)
                fflog("Trakt: Scrobble Paused")
        elif percent >= threshold:
            trakt.scrobbleMovie(
                imdb, percent, action="stop", tmdb=tmdb
            ) if _content == "movie" else trakt.scrobbleEpisode(
                imdb, season, episode, percent, action="stop", tmdb=tmdb
            )
            #if control.setting("trakt.scrobble.notify") == "true":  # nie ma takiego ustawienia
            if True:
                #control.sleep(1000)
                control.infoDialog("Trakt: Scrobbled (finish)", time=1)
                fflog("Trakt: Scrobbled (finish)")
    except Exception:
        fflog_exc(1)
        log_utils.log("Scrobble - Exception", "module")
        control.infoDialog("Scrobble Failed")


def get_scrobble( _content, imdb, season="", episode="", tmdb=None):
    if _content == "movie":
        percent = trakt.getMovieProgress(imdb, tmdb)
        return percent
    else:
        percent = trakt.getEpisodeProgress(imdb, season, episode, tmdb)
        return percent


def _indicators(out=None, media_type=None):
    # fflog(f'{out=}  {media_type=}',1,1)
    control.makeFile(control.dataPath)
    dbcon = database.connect(control.bookmarksFile)
    dbcur = dbcon.cursor()
    dbcur.execute(
        "CREATE TABLE IF NOT EXISTS bookmarks ("
        "timeInSeconds TEXT, "
        "type TEXT, "
        "imdb TEXT, "  # czasami może być numer tmdb, ale dla kompatybilności w kolumnie o nazwie imdb
        "season TEXT, "
        "episode TEXT, "
        "playcount INTEGER, "
        "overlay INTEGER, "
        # "tmdb TEXT, "  # na końcu, dla kompatybilności ze starym kodem
        "UNIQUE(imdb, season, episode)"  # przydałoby się jeszcze dodać kolumnę "type", bo dla tmdb numery są liczone niezależnie dla każdego typu (dla imdb chyba nie, więc nie było potrzeby)
        ");"                             # tylko, że nie można zmienić UNIQUE dla istniejącej tabeli
    )
    # if 0:
        # dbcur.execute("PRAGMA table_info(bookmarks);")  # zwraca metadane tabeli, m.in. nazwy kolumn
        # # fflog(f'{dbcur.fetchall()=}',1,1)
        # columns = [row[1] for row in dbcur.fetchall()]
        # if "tmdb" not in columns:
            # dbcur.execute("ALTER TABLE bookmarks ADD COLUMN tmdb TEXT;")  # dodanie kolumny
            # fflog("Dodano kolumnę 'tmdb' do tabeli 'bookmarks'.")
            # # dbcon.commit()  # zapisanie zmian
    dbcon.commit()  # zapisanie zmian (jeśli utworzono tabelę)
    sql_select = "SELECT * FROM bookmarks WHERE overlay = 7"
    if media_type:
        sql_select += " AND type = '%s'" % media_type
    _kadrplus_ensure_bookmarks_table(dbcur)
    dbcur.execute(sql_select)
    match = dbcur.fetchall()
    # fflog(f'{match=}',1,1)
    if match:
        if not out:
            # return [i[2] for i in match]  # tylko identyfikatory imdb
            indicators = [i[2] for i in match]  # tylko identyfikatory imdb
            # fflog(f'{indicators=}',1,1)
            indicators = [i for i in indicators if i and i not in ["None", '0']]  # dodatkowe filtrowanie
        else:
            if out == 'all':
                # return [i for i in match]  # wszystkie kolumny
                indicators = [i for i in match]  # wszystkie kolumny
                # fflog(f'{indicators=}',1,1)
                indicators = [i for i in indicators if i[2] and i[2] not in ["None", '0']]  # dodatkowe filtrowanie
            elif 'episode' in out or media_type == 'episode':
                # return [(i[2], (i[3],i[4])) for i in match]  # (imdb, (season, episode))
                # return [(i[2], i[3], i[4]) for i in match]  # (imdb, season, episode)
                indicators = [(i[2], i[3], i[4]) for i in match]  # (imdb, season, episode)
                # fflog(f'{indicators=}',1,1)
                indicators = [i for i in indicators if i[0] and i[0] not in ["None", '0']]  # dodatkowe filtrowanie
        # fflog(f'{indicators=}',1,1)
        return indicators
    else: return []  # czy lepiej None?


def _get_watched(media_type, imdb, season=None, episode=None, tmdb=None):
    tmdb = None  if tmdb == "0" or tmdb == "None"  else tmdb
    imdb = None  if imdb == "0" or imdb == "None"  else imdb
    if not tmdb:
        # if not imdb or imdb == "0" or imdb == "None":
        if not imdb:
            fflog(f'nieprawidłowy parametr {imdb=}',1,1)
            return 6  # bo trzeba zwrócić liczbę
    control.makeFile(control.dataPath)
    dbcon = database.connect(control.bookmarksFile)
    dbcur = dbcon.cursor()
    if imdb and tmdb:
        sql_select = "SELECT * FROM bookmarks WHERE (imdb = '%s' OR imdb = '%s') AND overlay = 7" % (imdb, tmdb)
    elif tmdb:
        sql_select = "SELECT * FROM bookmarks WHERE imdb = '%s' AND overlay = 7" % tmdb
    else:
        sql_select = "SELECT * FROM bookmarks WHERE imdb = '%s' AND overlay = 7" % imdb
    # sql_select = "SELECT * FROM bookmarks WHERE imdb = '%s'" % imdb
    if media_type == "episode":
        # sql_select += " AND season = '%s' AND episode = '%s'" % (season, episode)
        if season:
            sql_select += " AND season = '%s'" % season
        if episode:
            sql_select += " AND episode = '%s'" % episode
    else:
        sql_select += " AND type = '%s'" % media_type  # ważne dla tmdb
        pass
    _kadrplus_ensure_bookmarks_table(dbcur)
    dbcur.execute(sql_select)
    match = dbcur.fetchone()
    # dbcon.commit()  # nie trzeba, bo nie ma zmian (tylko odczyt)
    # fflog(f'{match=}',1,1)
    if match:
        # if match[6] == 7:
            # return 7
        # else
            # return 6
        return 7  # tu typ liczbowy (a nie string)
    else:
        return 6
        # return 0


def _update_watched(media_type, new_value, id_db, season=None, episode=None):
    """ chyba ta funkcja nie jest nigdzie wykorzystywana """
    fflog(f'funkcja nie jest gotowa',1,1)
    # if not id_db or id_db == "0" or id_db == "None":
        # fflog(f'nieprawidłowy parametr {id_db=}',1,1)
        # return
    # dbcon = database.connect(control.bookmarksFile)
    # dbcur = dbcon.cursor()
    # # sql_update = "UPDATE bookmarks SET overlay = %s WHERE imdb = '%s'" % (new_value, id_db,)
    # sql_update = "UPDATE bookmarks SET overlay = %s WHERE (imdb = '%s' OR imdb = '%s')" % (new_value, id_db, id_db)
    # if media_type == "episode":
        # # sql_update += " AND season = '%s' AND episode = '%s'" % (season, episode)
        # if season:
            # sql_select += " AND season = '%s'" % season
        # if episode:
            # sql_select += " AND episode = '%s'" % episode
    # else:
        # sql_delete += " AND type = '%s'" % media_type
    # dbcur.execute(sql_update)
    # dbcon.commit()


def _delete_record(media_type, id_db, season=None, episode=None, tmdb=None):
    fflog(f'{media_type=}  {id_db=}  {tmdb=}  {season=}  {episode=}',1,1)
    dbcon = database.connect(control.bookmarksFile)
    dbcur = dbcon.cursor()
    tmdb  = None  if tmdb == "0" or tmdb == "None"  else tmdb
    media_type = "movie" if not media_type else media_type
    if not tmdb:
        if not isinstance(id_db, (tuple, list)):
            id_db = [id_db]
    else:
        id_db = [id_db, tmdb]
    # fflog(f'{id_db=}',1,1)
    for iddb in id_db:
        try:
            if iddb:  # != ''
                sql_delete = "DELETE FROM bookmarks WHERE (imdb = '%s' OR imdb = '%s')" % (iddb, iddb)
            else:
                sql_delete = "DELETE FROM bookmarks WHERE imdb = '%s'" % iddb
            if media_type == "episode":
                sql_delete += " AND season = '%s' AND episode = '%s'" % (season, episode)
            elif media_type == "tvshow":
                sql_delete += " AND type <> '%s'" % "movie"
            else:
                sql_delete += " AND type = '%s'" % media_type
            _kadrplus_ensure_bookmarks_table(dbcur)
            dbcur.execute(sql_delete)
            dbcon.commit()
        except Exception:
            fflog_exc(1)
            return False
            pass


def last_position():
    # from local database
    control.makeFile(control.dataPath)
    dbcon = database.connect(control.bookmarksFile)
    dbcur = dbcon.cursor()
    sql_select = "SELECT type, imdb, season, episode FROM bookmarks WHERE rowid = (SELECT MAX(rowid) FROM bookmarks);"
    _kadrplus_ensure_bookmarks_table(dbcur)
    dbcur.execute(sql_select)
    match = dbcur.fetchone()
    # dbcon.commit()  # nie potrzeba
    return match


def last_positions(limit=10):
    try:  # bo może nie być tabeli
        # from local database
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        # sql_select = "SELECT type, imdb, season, episode FROM bookmarks"
        sql_select = "SELECT type, imdb, season, episode FROM bookmarks ORDER BY rowid DESC LIMIT %s" % limit
        _kadrplus_ensure_bookmarks_table(dbcur)
        dbcur.execute(sql_select)
        match = dbcur.fetchall()
        # fflog(f'{len(match)=}  {match=}',1,1)
        # match = match[::-1][:limit]
        # fflog(f'{len(match)=}  {match=}',1,1)
        return match
    except Exception:
        fflog_exc(1)
        pass
