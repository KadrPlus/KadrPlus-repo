# -*- coding: utf-8 -*-
"""
Kadr+ title matching helpers.

Small, dependency-free helpers for PL scrapers.  They are intentionally
conservative: exact/normalized/title-part matches are preferred, fuzzy matching
is used only above a high threshold, and very short titles are protected from
false positives.
"""
from __future__ import annotations

import re
from difflib import SequenceMatcher

try:
    from ptw.libraries import cleantitle
except Exception:  # pragma: no cover
    cleantitle = None

_STOPWORDS = set("the a an i ii iii iv v vi vii viii ix x oraz and of de la le les der die das el los las".split())
_BAD_SUFFIXES = (
    "online", "lektor", "lektor pl", "dubbing", "dubbing pl", "napisy", "napisy pl",
    "pl", "hd", "fhd", "uhd", "4k", "serial", "film", "cały film", "caly film",
)


def _ascii(text: str) -> str:
    try:
        return cleantitle.normalize(text or "") if cleantitle else str(text or "")
    except Exception:
        return str(text or "")


def normalize(text: str) -> str:
    text = _ascii(text or "").lower()
    text = re.sub(r"&#\d+;", " ", text)
    text = text.replace("&amp;", " and ").replace("&", " and ")
    text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
    text = re.sub(r"\b(s\d{1,2}e\d{1,3}|\d{1,2}x\d{1,3})\b", " ", text, flags=re.I)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    # Remove harmless source-quality suffixes from the end only.
    changed = True
    while changed and text:
        changed = False
        for suf in _BAD_SUFFIXES:
            if text.endswith(" " + suf):
                text = text[: -len(suf)].strip()
                changed = True
    return text


def compact(text: str) -> str:
    return normalize(text).replace(" ", "")


def tokens(text: str) -> list[str]:
    return [t for t in normalize(text).split() if t and t not in _STOPWORDS]


def _alias_title(alias) -> str:
    if isinstance(alias, str):
        return alias
    if not isinstance(alias, dict):
        return ""
    for key in ("title", "name", "originalname", "original_name", "originaltitle", "original_title", "localtitle"):
        val = alias.get(key)
        if val:
            return str(val)
    return ""


def title_variants(title=None, localtitle=None, aliases=None, max_items: int = 12) -> list[str]:
    """Return ordered search/title variants: PL/local first, original next, aliases next."""
    raw = []
    for val in (localtitle, title):
        if val and str(val).strip():
            raw.append(str(val).strip())
    for alias in aliases or []:
        val = _alias_title(alias)
        if val:
            raw.append(val.strip())

    out = []
    seen = set()

    def add(v):
        v = re.sub(r"\s+", " ", str(v or "")).strip(" /-|\t\r\n")
        if not v:
            return
        key = compact(v)
        if key and key not in seen:
            seen.add(key)
            out.append(v)

    for val in raw:
        add(val)
        # Sites often store "Polish title / Original title" or only one side.
        for sep in (" / ", "/", " | ", "|"):
            if sep in val:
                for part in val.split(sep):
                    add(part)
        # Some sites drop subtitles after colon; useful as last-resort variant.
        if ":" in val:
            add(val.split(":", 1)[0])
        if " - " in val:
            add(val.split(" - ", 1)[0])

    return out[:max_items]


def score(candidate: str, wanted: str) -> int:
    c = normalize(candidate)
    w = normalize(wanted)
    if not c or not w:
        return 0
    if c == w or compact(candidate) == compact(wanted):
        return 100

    ct = tokens(candidate)
    wt = tokens(wanted)
    if not ct or not wt:
        return 0

    # Avoid very short false positives like "it" or "from".
    min_len = min(len("".join(ct)), len("".join(wt)))
    if min_len < 4:
        return 100 if compact(candidate) == compact(wanted) else 0

    set_c, set_w = set(ct), set(wt)
    inter = len(set_c & set_w)
    union = len(set_c | set_w) or 1
    jacc = inter / float(union)

    contains = False
    if len(w) >= 5 and (w in c or c in w):
        # Only accept contains when most meaningful tokens overlap.
        contains = inter >= max(1, min(len(set_c), len(set_w)) - 1)

    ratio = SequenceMatcher(None, c, w).ratio()
    token_ratio = inter / float(max(len(set_c), len(set_w)) or 1)
    result = int(max(ratio * 100, jacc * 100, token_ratio * 96))
    if contains:
        result = max(result, 92)
    return min(result, 99)


def matches(candidate: str, wanted: str, threshold: int = 84) -> bool:
    return score(candidate, wanted) >= threshold


def matches_any(candidate: str, wanted_titles, threshold: int = 84) -> bool:
    if isinstance(wanted_titles, str):
        wanted_titles = [wanted_titles]
    for title in wanted_titles or []:
        if matches(candidate, title, threshold=threshold):
            return True
    return False


def best_match(candidates, wanted_titles, threshold: int = 84):
    best = None
    best_score = 0
    if isinstance(wanted_titles, str):
        wanted_titles = [wanted_titles]
    for candidate in candidates or []:
        cand_title = candidate.get("title") if isinstance(candidate, dict) else str(candidate)
        for wanted in wanted_titles or []:
            sc = score(cand_title, wanted)
            if sc > best_score:
                best = candidate
                best_score = sc
    return best if best_score >= threshold else None


def episode_tokens(season, episode) -> list[str]:
    try:
        s = int(season)
        e = int(episode)
    except Exception:
        return []
    return [
        f"s{s:02d}e{e:02d}", f"s{s}e{e}", f"{s}x{e:02d}", f"{s}x{e}",
        f"sezon {s} odcinek {e}", f"sezon {s} ep {e}", f"odcinek {e}", f"odc {e}",
    ]


def episode_matches(text, season, episode) -> bool:
    n = normalize(text)
    c = compact(text)
    for pat in episode_tokens(season, episode):
        if normalize(pat) in n or compact(pat) in c:
            return True
    try:
        e = int(episode)
        # title ending with just the episode number is common in RSS/loose uploads.
        if re.search(r"(^|\D)%d(\D|$)" % e, str(text or "")):
            return True
    except Exception:
        pass
    return False
