# -*- coding: utf-8 -*-

"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
def player():

    import base64
    import codecs
    import gzip
    import json
    import os
    import re
    import sys
    from urllib.parse import quote_plus, unquote_plus, parse_qsl

    import six
    import xbmc

    from ptw.libraries import bookmarks
    from ptw.libraries import cleantitle
    from ptw.libraries import control
    from ptw.libraries import playcount
    from ptw.libraries import trakt
    from ptw.libraries.source_utils import get_kodi_version

    from ptw.libraries.log_utils import log, fflog
    from ptw.debug import log_exception, fflog_exc


    class player(xbmc.Player):
        def __init__(self):
            super().__init__()
            self.PREVcurrentTime = None
            self.currentTime = None
            self.totalTime = None
            self.runtime = None  # traktowy totaltime
            self.content = None
            self.title = None
            self.localtitle = None
            self.englishtitle = None
            self.originaltitle = None
            self.tvshowtitle = None
            self.year = None
            self.name = None
            self.season = None
            self.episode = None
            self.DBID = None
            self.imdb = None
            self.tmdb = None
            self.tvdb = None
            self.ids = None
            self.offset = None
            self.is_active = True
            self.playback_started = None
            self.offsetSource = None
            self.watched_before = None
            # self.addRating_in_progress = None


        # większość wywowałań tej funkcji wstawia zamiast tmdb "tvdb"
        def run(self, title, year, season, episode, imdb, tvdb, tmdb, url, subs=None, meta=None, handle=None, hosting=None, customPlayer=None):
            fflog(f'{title=} {year=} {season=} {episode=} {imdb=} {tvdb=} {tmdb=} {handle=} {hosting=} \n{url=} \n{meta=}',0,1)

            if self.isPlayingVideo():
                fflog('try to stop the previous playback',1,1)
                self.stop()
                control.sleep(2500)

            if control.window.getProperty("fanfilm.addRating_in_progress"):
                fflog('oczekiwanie na zakończenie wystawiania oceny dla TMDB',1,1)
                control.sleep(5000)
                pass
            while (
                    control.window.getProperty("fanfilm.addRating_in_progress")
                ):
                fflog('oczekiwanie na zakończenie wystawiania oceny dla TMDB',0,1)
                control.sleep(1000)

            if customPlayer is None:
                params2 = dict(parse_qsl(sys.argv[2][1:]))
                # fflog(f'{params2=}', 1)
                source = params2.get("source")
                try:
                    source = json.loads(source)  # to się tylko sprawdzi, gdy źródła w folderze (nie w okienku)
                    source = source[0]  # tak dziwnie to jest stworzone (źródło w liście)
                    customPlayer = source.get("customPlayer")
                except Exception:
                    # fflog_exc(1)  # bo będzie alert w logu, gdy zmienna nieustawiona i źródła w okienku
                    pass
            fflog(f'{customPlayer=}', 1)
            # customPlayer = True  # test only

            try:
                # te 2 linijki muszą być, bo inaczej Kodi potrafi się zawiesić
                control.execute('Dialog.Close(notification,true)')
                control.sleep0(300)

                if 0:
                    fflog(f"{control.infoLabel('ListItem.Label')=}", 1,1)
                    fflog(f"{control.infoLabel('ListItem.Property(IsPlayable)')=}", 1,1)
                    fflog(f"{control.condVisibility('ListItem.IsFolder')=}", 1,1)
                    fflog(f"{control.infoLabel('Container.PluginName')=}", 1,1)

                if not customPlayer:
                    fflog("przygotowywanie do odtwarzania")
                    control.dialog.notification('Kadr+', control.lang(33060), time=1500, sound=False)
                    control.sleep(400)

                    self.currentTime = 0
                    self.totalTime = 0
                    self.runtime = 0
                    self.playback_started = None

                    self.content = "movie" if season is None or episode is None else "episode"

                    localtitle = originalname = tvshowtitle = ""
                    if isinstance(title, tuple):
                        title, localtitle, originalname, tvshowtitle = title
                    self.englishtitle = title  # angielski
                    self.localtitle = localtitle
                    self.originaltitle = originalname
                    self.tvshowtitle = tvshowtitle
                    self.title = title = localtitle or title
                    self.year = year
                    self.name = (
                        quote_plus(title) + quote_plus(" (%s)" % year)
                        if self.content == "movie"
                        else quote_plus(title) + quote_plus(" S%01dE%01d" % (int(season), int(episode)))
                    )
                    self.name = unquote_plus(self.name)  # to jakieś awaryjne do wyszukania informacji z bilioteki, ale jak tytuł jest w meta, to do playera idzie z meta

                    self.season = "%01d" % int(season) if self.content == "episode" else None
                    self.episode = "%01d" % int(episode) if self.content == "episode" else None

                    self.DBID = None  # jakiś reset zmiennej chyba

                    self.imdb = imdb  if imdb is not None and imdb != "None"  else "0"
                    self.tmdb = tmdb  if tmdb is not None and tmdb != "None"  else "0"
                    self.tvdb = tvdb  if tvdb is not None and tvdb != "None"  else "0"

                    #self.ids = {"imdb": self.imdb, "tmdb": self.tmdb}  # brak tvdb
                    self.ids = {"imdb": self.imdb, "tvdb": self.tvdb, "tmdb": self.tmdb}
                    self.ids = dict((k, v) for k, v in self.ids.items() if not v == "0")  # znacznik dla wtyczki script.trakt, aby mogła rozpoznawać filmy

                    # self.offset, self.runtime, self.offsetSource = bookmarks.get(self.content, imdb, season, episode)
                    self.offset, self.runtime, self.offsetSource = bookmarks.get(self.content, imdb, season, episode, tmdb=tmdb)
                    # self.offset, self.runtime, self.offsetSource = bookmarks.get(self.content, imdb, season, episode, threshold=(0.85 if self.content == "movie" else 0.75))

                    #fflog(f"{self.imdb=} {self.tmdb=} {self.ids=} {self.offset=}", 1)
                    fflog(f"{self.ids=}   {self.offset=}   {self.offsetSource=}   {self.content=}  {imdb=}  {tmdb=}  {season=}  {episode=}  {self.runtime=}", 1)


                    poster, thumb, fanart, clearlogo, clearart, discart, keyart, landscape, banner, icon, characterart, meta = self.getMeta(meta)
                    # fflog(f'\n   {poster=} \n    {thumb=} \n   {fanart=} \n{clearlogo=} \n {clearart=} \n  {discart=} \n   {keyart=} \n{landscape=} \n   {banner=} \n     {icon=} \n{characterart=} \n{meta=}', 1)

                    if isinstance(url, tuple):
                        url, subs = url

                    fflog(f'{control.setting("player.strip_headers_from_link")=}', 0)  # to jakby też (patrz komentarz poniżej)
                    if control.setting("player.strip_headers_from_link") == "true":
                        url = url.split("|")[0]

                    fflog(f'{url=}', 0)  # dziwne, ale to pomaga uzwględnić zmianę powyższego ustawienia bez konieczności ponownego szukania źródeł (tylko musi być chyba zmienna w logu)

                    # Create a playable item with a path to play.
                    item = control.item(path=url, offscreen=True)  # offscreen=True means that the item is not meant for displaying (only to pass info to the Kodi player)

                    if subs:
                        fflog(f'{subs.keys()=}', 1)
                        fflog(f'{subs=}', 0)
                        item.setSubtitles(list(subs.values()))

                    if self.content == "movie":
                        item.setArt(
                            {
                                "icon": icon,
                                "thumb": thumb,
                                "poster": poster,
                                "fanart": fanart,
                                "clearlogo": clearlogo,
                                "clearart": clearart,
                                "discart": discart,
                                "keyart": keyart,
                                "landscape": landscape,
                                "banner": banner,
                            }
                        )
                    else:
                        poster1 = poster2 = poster
                        if isinstance(poster, tuple):
                            poster1, poster2 = poster
                            poster = poster2

                        banner1 = banner2 = banner
                        if isinstance(banner, tuple):
                            banner1, banner2 = banner
                            # banner = banner2 if banner1 == banner2 else banner1
                            banner = banner2

                        landscape1 = landscape2 = landscape
                        if isinstance(landscape, tuple):
                            landscape1, landscape2 = landscape
                            # landscape = landscape2 if landscape1 == landscape2 else landscape1
                            landscape = landscape2

                        fanart1 = fanart2 = fanart
                        if isinstance(fanart, tuple):
                            fanart1, fanart2 = fanart
                            # fanart = fanart2 if fanart1 == fanart2 else fanart1
                            fanart = fanart2

                        # fflog(f'\n   {icon=} \n    {thumb=} \n  {poster1=} \n  {poster2=} \n   {fanart=} \n  {fanart1=} \n  {fanart2=} \n{clearlogo=} \n {clearart=} \n   {keyart=} \n{landscape=} \n{landscape1=} \n{landscape2=} \n   {banner=} \n  {banner1=} \n  {banner2=} \n     {icon=} \n{characterart=}', 1)
                        item.setArt(
                            {
                                "icon": icon,
                                "thumb": thumb,
                                "tvshow.poster": poster1,
                                "season.poster": poster2,
                                "fanart": fanart,
                                "clearlogo": clearlogo,
                                # "tvshow.clearlogo": clearlogo,  # opcjonalnie (jak nie będzie poprzednie wystarczało)
                                "clearart": clearart,
                                "keyart": keyart,
                                "landscape": landscape,
                                "banner": banner,
                                # nie wiem, czy podział tu (w odtwarzaczu) na season i tvshow ma sens
                                "season.banner": banner2,
                                "season.landscape": landscape2,
                                "season.fanart": fanart2,
                                "tvshow.banner": banner1,
                                "tvshow.landscape": landscape1,
                                "tvshow.fanart": fanart1,
                            }
                        )
                        # fflog(f'{characterart=}')  # z ciekawości
                        if characterart:
                            if isinstance(characterart, list):
                                for an in range(0, len(characterart)):
                                    item.setArt({f"characterart{an+1}": characterart[an]})
                                    item.setArt({f"tvshow.characterart{an+1}": characterart[an]})  # nie wiem, czy to działa i czy to w ogóle potrzebne
                                    pass
                            else:
                                item.setArt({"characterart": characterart})
                                item.setArt({"tvshow.characterart": characterart})  # nie wiem, czy to działa i czy to w ogóle potrzebne
                                pass

                    try:
                        if ":" in str(meta.get("duration") or ""):
                            meta["duration"] = time_to_seconds(meta["duration"])
                        item.setInfo(type="video", infoLabels=control.metadataClean(meta))
                    except Exception:
                        fflog_exc(1)
                        fflog(f'{control.metadataClean(meta)=}')
                        pass

                    vtag = item.getVideoInfoTag()
                    castwiththumb = meta.get("castwiththumb")
                    if castwiththumb:
                        castwiththumb = [xbmc.Actor(**a) for a in castwiththumb]
                        vtag.setCast(castwiththumb)

                    if hosting is None:
                        params2 = dict(parse_qsl(sys.argv[2][1:]))
                        # fflog(f'{params2=}', 1)
                        source = params2.get("source")
                        try:
                            source = json.loads(source)  # to się tylko sprawdzi, gdy źródła w folderze (nie w okienku)
                            source = source[0]  # tak dziwnie to jest stworzone (źródło w liście)
                            # provider = source.get("provider")
                            hosting = source.get("source") or source.get("provider")
                        except Exception:
                            fflog_exc(1)
                            # provider = ""
                            hosting = ""
                    # fflog(f'{provider=} {hosting=}', 1)
                    fflog(f'{hosting=}', 1)

                    ia = False

                    if not url.startswith('DRM'):
                        # if params2.get("ia"):  # źródła z okienka tego nie ma
                        if "&ia=1" in sys.argv[2]:
                            ia = True
                        fflog(f'{url=}', 0)
                        if url.startswith('ia://'):
                            ia = True
                            url = url[5:]
                        if not ia and control.setting("player.ia") == "true" and control.condVisibility("System.AddonIsEnabled(inputstream.adaptive)"):
                            if url.startswith("http") and ".m3u" in url:  # czy nie dodać także ".m3u8" ?
                                ia = True
                            elif url.startswith("http") and ".mpd" in url:
                                ia = True
                            else:
                                fflog('IA nie będzie, bo brak ".m3u(8)" lub ".mpd" w adresie {url=}', 1)
                                pass
                        if "&ia=0" in sys.argv[2]:
                            ia = False

                        if ia:
                            disallowed_words = control.setting('player.ia_not_for').strip()
                            # fflog(f'{disallowed_words=}', 0)
                            # disallowed_words = re.split(" *[ ,|] *", disallowed_words)  # nie wiem, czy spacja nie występuje w nazwie hostingu (raczej chyba nie)
                            disallowed_words = disallowed_words.replace('|', ',').rstrip(',')
                            disallowed_words = disallowed_words.split(',')  # string into list
                            disallowed_words = [w.strip().replace('"', '') for w in disallowed_words]  # clean a little
                            disallowed_words = list(filter(None, disallowed_words))  # eliminate empty
                            disallowed_words = list(dict.fromkeys(disallowed_words))  # eliminate duplicates
                            fflog(f'{disallowed_words=}', 0)
                            if disallowed_words and hosting and hosting.lower() in disallowed_words:
                                if "&ia=1" in sys.argv[2]:
                                    fflog(f'nie zostanie zastosowany wyjątek dla {hosting=}')
                                else:
                                    ia = False
                                    fflog(f'IA nie zostanie użyte, bo {hosting=} jest na liście wyjątków  {disallowed_words}', 1)

                    if ia and not control.condVisibility("System.AddonIsEnabled(inputstream.adaptive)"):
                        ia = False
                        fflog(f'IA nie zostanie użyty, bo system nie wykrył aktywnej wtyczki "inputstream.adaptive"')
                        import xbmcgui
                        control.dialog.notification('Kadr+', control.lang(33061), xbmcgui.NOTIFICATION_WARNING, time=3000)
                        control.sleep(1000)

                    if ia:
                        fflog('using Inputstream Adaptive to play stream')
                        kodiver = get_kodi_version().major
                        # fflog(f'{kodiver=}')
                        listitem = item
                        stream_url = url
                        ia = True
                        if kodiver > 16 and ('.mpd' in stream_url or ia):
                            if kodiver < 19:
                                listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
                            else:
                                listitem.setProperty('inputstream', 'inputstream.adaptive')
                            if '.mpd' in stream_url:
                                if kodiver < 21:
                                    listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
                                listitem.setMimeType('application/dash+xml')
                            else:  # hls lub m3u
                                if kodiver < 21:
                                    listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
                                listitem.setMimeType('application/x-mpegURL')
                            listitem.setContentLookup(False)
                            if '|' in stream_url:
                                stream_url, strhdr = stream_url.split('|')
                                if kodiver < 22:
                                    fflog('ustawiam inputstream.adaptive.stream_headers',1,1)
                                    listitem.setProperty('inputstream.adaptive.stream_headers', strhdr)
                                if kodiver > 19 and kodiver < 22:
                                    fflog('ustawiam inputstream.adaptive.manifest_headers',1,1)
                                    listitem.setProperty('inputstream.adaptive.manifest_headers', strhdr)
                                    pass
                                if kodiver < 21:  # nie zadziałało mi
                                    fflog('ustawiam inputstream.adaptive.license_key',1,1)
                                    listitem.setProperty('inputstream.adaptive.license_key ', f'|{strhdr}||')  # https://github.com/xbmc/inputstream.adaptive/issues/1788#issuecomment-2703910048
                                    listitem.setProperty('inputstream.adaptive.license_type ', 'none')
                                    pass
                                if kodiver > 20 and kodiver < 22:
                                    fflog('ustawiam inputstream.adaptive.drm_legacy',1,1)
                                    listitem.setProperty('inputstream.adaptive.drm_legacy', f'none||{strhdr}')  # https://github.com/xbmc/inputstream.adaptive/issues/1788#issuecomment-2703910048
                                    pass
                                if kodiver > 21:
                                    if not listitem.getProperty('inputstream.adaptive.drm_legacy'):
                                        fflog('ustawiam inputstream.adaptive.common_headers',1,1)
                                        listitem.setProperty('inputstream.adaptive.common_headers', strhdr)
                                        pass
                                listitem.setPath(stream_url)
                            # item = listitem  # nie wiem, czy potrzeba

                        # url = stream_url  # nie wiem, czy potrzeba
                        # item = listitem  # nie wiem, czy potrzeba

                    if url.startswith('DRM'):
                        item = drm_item(url, item=item)
                        if not item:
                            self.is_active = False
                            control.sleep(500)
                            fflog(f'exit from FF player script because {item=}')
                            # raise Exception()
                            return False
                    else:
                        # item.setPath(url)  # niepotrzebne
                        pass

                else:
                    item = control.item(path=url, offscreen=True)

                if not customPlayer:
                    fflog("trying to start playback")
                else:
                    fflog("trying to run custom playback")

                handle = int(sys.argv[1]) if not handle else handle
                handle = handle if isinstance(handle, int) else -1
                #if "plugin" in control.infoLabel("Container.PluginName") and control.setting("hosts.mode") != "1" or int(sys.argv[1]) < 0:
                # POPRAWKA: filman_api przez setResolvedUrl nie działa gdy wywołane z wątku bocznego
                # Kodi ignoruje setResolvedUrl i sam próbuje otworzyć plugin:// URL jako stream
                _hosting_lower = (hosting or "").lower()
                _force_direct_play = _hosting_lower in ("filman_api", "doodstram", "doodstream")
                if handle < 0 or _force_direct_play or control.setting("player.dont_use_setResolvedUrl") == "true" or url.endswith(".strm"):
                    fflog(f'{handle=}')
                    if url.endswith(".strm"):
                        fflog(f'case for strm file')
                        if control.condVisibility('Window.IsActive(busydialog)'):
                            if handle > -1:
                                fflog('dodanie pustego katalogu przed odtwarzaniem',0)
                                control.directory(handle)
                                pass
                        control.player.play(url)
                    else:
                        fflog(f'not setResolved method')
                        url = item.getPath()  # może pomóc na niektóre dziwne twory (jak np. drmcda|{...})
                        control.player.play(url, item)  # xbmc.Player().play(url, item)
                        # if handle > -1:  # aby nie było busy loadera podczas odtwarzania
                            # fflog(f'dodanie pustego katalogu, bo {handle=} > -1',1)
                            # control.directory(handle)  # tylko, że co 3-cie odtwarzanie pojawia się okienko o nieudanym odtwarzaniu i potrafi przerwać nawet, jeśli materiał się odtwarza
                            # # control.idle()  # to tylko ukrycie - bez sensu, bo i tak powróci okienko o nieudanym odtwarzaniu
                            # pass
                else:
                    fflog(f'setResolvedUrl method')
                    # fflog(f'url = {item.getPath()}',1,1)
                    control.resolve(handle, True, item)  # setResolvedUrl(handle, True, item)


                if customPlayer:
                    self.is_active = False
                    fflog(f'url = {item.getPath()}',1,1)
                    control.sleep(1000)
                    fflog(f'exit from FF player script because {customPlayer=}')
                    return True


                # control.sleep(100)
                control.busy()
                control.sleep(100)
                fflog(f'waiting for player to start')

                # fflog(f'{dir(self)=}',1,1)

                monitor = control.monitor
                for i in (r := list(range(0, 10*90))):  # 90 sekund na rozpoczęcie odtwarzania
                    if monitor.abortRequested():
                        fflog('Kodi exit signal appeared')
                        # return sys.exit()
                        sys.exit()
                        return
                    if self.isPlayingVideo() or not self.is_active:
                        fflog(f'{self.isPlayingVideo()=}  {self.is_active=}')
                        break
                    control.sleep(100)  # delay if loop
                    if self.playback_started:
                        self.playback_started = None
                        if i > 0:
                            fflog(f'{i=}')
                            # fflog(f'{r=}')
                            pass
                        r += range(r[-1]+1, r[-1]+1+i)
                        if i > 0:
                            # fflog(f'{r=}')
                            pass
                        # control.busy()
                    #fflog(f'waiting ... {i=}')
                # fflog(f'{i=}' + (f' (waited {round((i+1)/10,1)} sec.)' if i else ''))
                fflog(f'{i=}')
                control.idle(2)
                control.sleep(100)

                if not self.isPlayingVideo():
                    fflog(control.lang(33062))
                    import xbmcgui
                    control.dialog.notification('Kadr+', control.lang(33062), xbmcgui.NOTIFICATION_ERROR, time=3000, sound=True)
                    # self.stop()
                    self.is_active = False
                    fflog(f'exit from player script')
                    return

                # fflog(f'odtwarzanie')
                """
                if url.endswith(".strm"):
                    c = 3
                    while control.condVisibility('Window.IsActive(busydialog)') and c > 0:
                        control.sleep0(100)
                        c -= 1
                    if control.condVisibility('Window.IsActive(busydialog)'):
                        # fflog('wymuszenie zamknięcia BusyDialog')
                        # control.execute('Dialog.Close(busydialog,true)')
                        pass
                """
                # if control.condVisibility('System.AddonIsEnabled(script.trakt)'):
                control.window.setProperty("script.trakt.ids", json.dumps(self.ids))  # znacznik dla wtyczki script.trakt, aby mogła rozpoznawać filmy

                self.keepPlaybackAlive()  # podtrzymywanie, aby skrypt się nie zakończył

                # control.sleep(200)
                control.window.clearProperty("script.trakt.ids")

                if self.is_active:
                    self.onPlayBackStopped()  # bo czasami się nie odpala (jak się za szybko klika), a ważne gdy trakt

                # eksperyment
                # if 1:
                if (self.totalTime and self.content == "episode" and float(self.currentTime / self.totalTime) >= 0.66):
                    PluginName = control.infoLabel('Container.PluginName')
                    fflog(f"{PluginName=}", 0,1)
                    if PluginName:
                        # control.sleep(100)
                        if control.setting("autoplay.next_episode") == "true" and control.setting("hosts.mode") == "2" and self.episode:
                            fflog("Autoodtwarzanie następnego odcinka serialu jest włączone (funkcja FanFilm)",1,1)
                            # fflog(f'    {self.ids=}',1,1)
                            # fflog(f' {self.season=}   {season=}',1,1)
                            # fflog(f'{self.episode=}  {episode=}',1,1)
                            # if PluginName:
                            # sprawdzić Container.PluginName
                            # jeśli nie ma, to, zapamiętać numer odcinka + ids
                            # jeśli jest, to porównać obecny numer odcinka z poprzednio zapamiętanym
                            # tylko jak to długo ma być ważne?
                            # fflog('ustawienie znacznika autoodtwarzania następnego odcinka serialu',1,1)
                            import time
                            control.window.setProperty('FanFilm.var.url.autoplay.next_episode', f"1|{int(time.time())}")  # z czasem ważności
                        else:
                            if 0:
                                fflog(f'jakiś warunek nie spełniony do kontynuacji następnego odcinka')
                                fflog(f"{control.infoLabel('Container.PluginName')=}", 1,1)
                                fflog(f'{control.setting("autoplay.next_episode")=}',1,1)
                                fflog(f'{control.setting("hosts.mode")=}',1,1)
                                fflog(f'{self.episode=}  {episode=}',1,1)
                    else:
                        fflog(f"{PluginName=}", 1,1)
                        pass
                else:
                    if self.totalTime:
                        fflog(f'{self.totalTime=} {self.content=} {self.currentTime=}  {float(self.currentTime / self.totalTime)}',1,1)
                    else:
                        fflog(f'{self.totalTime=} {self.content=} {self.currentTime=}',1,1)
                    pass

                add_rating_for_tmdb = control.setting("add_rating_for_tmdb") == "true" and (
                    control.setting("add_rating_for_tmdb.movies") == "true" if self.content == "movie"
                    else control.setting("add_rating_for_tmdb.episodes") == "true" )
                if add_rating_for_tmdb and not self.watched_before:
                    fflog('włączona jest opcja oceniania materiału po obejrzeniu, który nie był wcześniej obejrzany',1)
                    fflog(f'{self.content=}  {self.tmdb=}  {self.season=}  {self.episode=}  percent={(self.currentTime / self.totalTime)*100} ',1) if self.totalTime else ""  # aby nie było dzielenia przez 0
                    if self.tmdb and self.totalTime:  # aby nie było dzielenia przez 0
                        if (self.currentTime / self.totalTime) >= 0.66 or 0:  # dla seriali krótkich trzeba mniejszy próg, ale i ocenę można wystawić wcześniej, bo nie zawsze chcemy oglądać do końca
                            # czy da się sprawdzić, czy już ten materiał był oceniony?  chociaż ocenę można zmienić
                            # self.addRating_in_progress = True  # nie użyte
                            control.window.setProperty("fanfilm.addRating_in_progress", "1")
                            control.busy()
                            control.sleep(100)
                            if 0:
                                # asynchroniczne wywołanie funkcji
                                control.execute(
                                    "RunPlugin(%s?action=add_rating&content=%s&tmdb=%s&season=%s&episode=%s)" % 
                                        (sys.argv[0], self.content, self.tmdb, self.season, self.episode)
                                               )
                                pass
                            else:  # wersja synchroniczna
                                from ptw.libraries.tmdb import add_rating
                                add_rating(self.content, self.tmdb, self.season, self.episode)
                                pass
                                control.window.setProperty("fanfilm.addRating_took_place", "1")  # ustawienie znacznika
                            pass
                            control.window.clearProperty("fanfilm.addRating_in_progress")
                        else:
                            fflog(f'ale nie osiągnięto minimalnego wymagalnego procentu obejrzenia (66%)',1)
                    else:
                        fflog(f'ale ocenienie niemożliwe, bo {self.tmdb=} lub {self.totalTime=}',1)

                # control.sleep(100)
                fflog(f'end of player script\n')

            except Exception:
                control.infoDialog(control.lang(33063), heading="Kadr+", icon="ERROR", time=2900)
                # log("player_fail", "module")
                # fflog("player fail")
                #from ptw.debug import log_exception, fflog_exc
                fflog_exc(1)
                return False


        def getMeta(self, meta):
            from ast import literal_eval
            if control.infoLabel('ListItem.DBID'):

                if self.content == "movie":
                    meta1 = meta
                    try:
                        fflog(f'[getMeta] case 2f', 1)

                        meta = control.jsonrpc(
                            '{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "originaltitle", "year", "genre", "studio", "country", "runtime", "rating", "votes", "mpaa", "director", "writer", "plot", "plotoutline", "tagline", "thumbnail", "art", "file"]}, "id": 1}'
                            % (self.year, str(int(self.year) + 1), str(int(self.year) - 1))
                        )
                        # fflog(f'{meta=}')
                        meta = six.ensure_text(meta, errors="ignore")
                        meta = json.loads(meta)["result"]["movies"]
                        # fflog(f'{meta=}')
                        t1 = cleantitle.get(self.title)
                        t2 = cleantitle.get(self.originaltitle)
                        t3 = cleantitle.get(self.englishtitle)
                        # fflog(f'{t1=} {t2=} {t3=}')
                        meta = [
                            i
                            for i in meta
                            if self.year == str(i["year"])
                            and (
                                cleantitle.get(i["title"]) in [t1, t2, t3]
                                or cleantitle.get(i["originaltitle"]) in [t1, t2, t3]
                                )
                        ]
                        meta = meta[0] if meta else {}

                        for k, v in meta.items():
                            if type(v) == list:
                                try:
                                    meta[k] = str(" / ".join([six.ensure_str(i) for i in v]))
                                except:
                                    meta[k] = ""
                            else:
                                try:
                                    meta[k] = str(six.ensure_str(v))
                                except:
                                    meta[k] = str(v)

                        if not "plugin" in control.infoLabel("Container.PluginName"):
                            self.DBID = meta["movieid"]

                        #poster = thumb = meta["thumbnail"]
                        #poster = thumb = eval(meta["art"])["poster"]
                        poster = literal_eval(meta["art"]).get("poster", "")
                        thumb = literal_eval(meta["art"]).get("thumb", "") or poster  # or meta["thumbnail"]
                        fanart = literal_eval(meta["art"]).get("fanart", "")
                        clearlogo = literal_eval(meta["art"]).get("clearlogo", "")
                        clearart = literal_eval(meta["art"]).get("clearart", "")
                        discart = literal_eval(meta["art"]).get("discart", "")
                        keyart = literal_eval(meta["art"]).get("keyart", "")
                        landscape = literal_eval(meta["art"]).get("landscape", "")
                        banner = literal_eval(meta["art"]).get("banner", "")
                        icon = literal_eval(meta["art"]).get("icon", "") or poster

                        #return poster, thumb, "", "", "", "", "", "", "", meta
                        return poster, thumb, fanart, clearlogo, clearart, discart, keyart, landscape, banner, icon, "", meta
                    except Exception:
                        fflog_exc(1)
                        meta = meta1
                        pass

                elif self.content == "episode":
                    meta1 = meta
                    try:
                        fflog(f'[getMeta] case 2s', 1)

                        meta = control.jsonrpc(
                            '{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "year", "thumbnail", "art", "file"]}, "id": 1}'
                            % (self.year, str(int(self.year) + 1), str(int(self.year) - 1))
                        )
                        meta = six.ensure_text(meta, errors="ignore")
                        meta = json.loads(meta)["result"]["tvshows"]
                        # fflog(f'{meta=}')
                        t = cleantitle.get(self.title)
                        # fflog(f'{t=}')
                        t1 = cleantitle.get(self.title)
                        t2 = cleantitle.get(self.originaltitle)
                        t3 = cleantitle.get(self.englishtitle)
                        t4 = cleantitle.get(self.tvshowtitle)
                        # fflog(f'{t1=} {t2=} {t3=} {t4=}')
                        meta = [
                            i
                            for i in meta
                            if( self.year == str(i["year"])
                                and t == cleantitle.get(i["title"])
                                or cleantitle.get(i["title"]) in [t1, t2, t3, t4]
                                #or cleantitle.get(i["originaltitle"]) in [t1, t2, t3, t4]
                            )
                        ][0]

                        # fflog(f'{meta=}')
                        tvshowid = meta["tvshowid"]
                        #poster = meta["thumbnail"]  # nie wiem, czy to dobrze
                        #poster = meta["art"].get("tvshow.poster", "")
                        poster1 = meta["art"].get("poster", "")
                        fanart1 = meta["art"].get("fanart", "")
                        clearlogo1 = meta["art"].get("clearlogo", "")
                        clearart1 = meta["art"].get("clearart", "")
                        keyart1 = meta["art"].get("keyart", "")
                        landscape1 = meta["art"].get("landscape", "")
                        banner1 = meta["art"].get("banner", "")
                        icon1 = meta["art"].get("icon", "") or poster1
                        characterart1 = meta["art"].get("characterart", "")

                        meta = control.jsonrpc(
                            '{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params":{ "tvshowid": %d, "filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["title", "season", "episode", "showtitle", "firstaired", "runtime", "rating", "director", "writer", "plot", "thumbnail", "art", "file"]}, "id": 1}'
                            % (tvshowid, self.season, self.episode)
                        )
                        meta = six.ensure_text(meta, errors="ignore")
                        meta = json.loads(meta)["result"]["episodes"][0]
                        # fflog(f'{meta=}')
                        for k, v in meta.items():
                            if type(v) == list:
                                try:
                                    meta[k] = str(" / ".join([six.ensure_str(i) for i in v]))
                                except:
                                    meta[k] = ""
                            else:
                                try:
                                    meta[k] = str(six.ensure_str(v))
                                except:
                                    meta[k] = str(v)

                        if not "plugin" in control.infoLabel("Container.PluginName"):
                            self.DBID = meta["episodeid"]
                        # fflog(f'{meta=}')
                        # fflog(f'{literal_eval(meta["art"])=}')
                        #thumb = meta["thumbnail"]
                        poster = literal_eval(meta["art"]).get("season.poster", "") or poster1
                        thumb = literal_eval(meta["art"]).get("thumb", "") or poster
                        fanart = literal_eval(meta["art"]).get("season.fanart", "") or fanart1
                        clearlogo = literal_eval(meta["art"]).get("season.clearlogo", "") or clearlogo1
                        clearart = literal_eval(meta["art"]).get("season.clearart", "") or clearart1
                        keyart = literal_eval(meta["art"]).get("season.keyart", "") or keyart1
                        landscape = literal_eval(meta["art"]).get("season.landscape", "") or landscape1
                        banner = literal_eval(meta["art"]).get("season.banner", "") or banner1
                        icon = literal_eval(meta["art"]).get("season.icon", "") or icon1
                        characterart = literal_eval(meta["art"]).get("season.characterart", "") or characterart1

                        #return poster, thumb, "", "", "", "", "", "", "", meta
                        # return (poster1, poster), thumb, fanart, clearlogo, clearart, "", keyart, landscape, banner, icon, characterart, meta
                        return (poster1,poster), thumb, (fanart1,fanart), clearlogo, clearart, "", keyart, (landscape1,landscape), (banner1,banner), icon, characterart, meta
                    except Exception:
                        fflog_exc(1)
                        meta = meta1
                        pass

            if meta:
                try:
                    fflog(f'[getMeta] case 1', 1)
                    poster = meta["poster"] if "poster" in meta.keys() else ""
                    poster1 = meta["tvshow.poster"] if "tvshow.poster" in meta.keys() else ""
                    poster2 = meta["season.poster"] if "season.poster" in meta.keys() else ""
                    thumb = meta["thumb"] if "thumb" in meta.keys() else "" or poster
                    fanart = meta["fanart"] if "fanart" in meta.keys() else ""
                    clearlogo = meta["clearlogo"] if "clearlogo" in meta.keys() else ""
                    clearart = meta["clearart"] if "clearart" in meta.keys() else ""
                    discart = meta["discart"] if "discart" in meta.keys() else ""
                    keyart = meta["keyart"] if "keyart" in meta.keys() else ""
                    landscape = meta["landscape"] if "landscape" in meta.keys() else ""
                    banner = meta["banner"] if "banner" in meta.keys() else ""
                    icon = meta["icon"] if "icon" in meta.keys() else "" or thumb
                    characterart = meta["characterart"] if "characterart" in meta.keys() else ""
                    if not "plugin" in control.infoLabel("Container.PluginName"):  # tylko dla zewnętrznych ?
                        # pomaga, bo jak są źle ustawione, to FF sobie je jakoś sam dobiera (pytanie, czy to tylko tak w Kodi 21 ?)
                        if 0:  # może to zależy od skórki i dodatkowych dodatków ? Bo nie zawsze to się sprawdza
                            meta.pop("poster", None);  meta.pop("thumb", None);
                            poster = thumb = ""  # a może wszystkie czyścić ?
                            pass
                    if poster2:
                        poster = (poster1 or poster, poster2)
                    # fflog(f'\n   {poster=} \n    {thumb=} \n   {fanart=} \n{clearlogo=} \n {clearart=} \n  {discart=} \n   {keyart=} \n{landscape=} \n   {banner=} \n     {icon=} \n{meta=}', 1)
                    return poster, thumb, fanart, clearlogo, clearart, discart, keyart, landscape, banner, icon, characterart, meta
                except Exception:
                    fflog_exc(1)
                    meta = {}
                    pass

            # fallback
            fflog(f'[getMeta] case 3', 1)
            poster, thumb, fanart, clearlogo, clearart, discart, keyart, landscape, banner, icon, characterart = (
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                #{"title": self.name},
            )
            if not meta:
                meta = {}
            if not meta.get("title"):
                meta.update({"title": self.name})

            return poster, thumb, fanart, clearlogo, clearart, discart, keyart, landscape, banner, icon, characterart, meta


        def keepPlaybackAlive(self):
            fflog('start keepPlaybackAlive method')

            pname = "%s.player.overlay" % control.addonInfo("id")
            control.window.clearProperty(pname)

            if self.content == "movie":
                overlay = playcount.getMovieOverlay(playcount.getMovieIndicators(), self.imdb, self.tmdb)
            elif self.content == "episode":
                overlay = playcount.getEpisodeOverlay(
                                                    playcount.getTVShowIndicators(),
                                                    self.imdb,
                                                    self.tmdb,
                                                    self.season,
                                                    self.episode,
                                                    )
            else:
                overlay = "6"  # 6 to w trakcie (7 to obejrzany)

            tcounter = 0
            also_locally = True  # ma znaczenie, gdy używamy Trakt

            if overlay == "7":  # obejrzany do konca już wcześniej był
                self.watched_before = True
                fflog(f'materiał był już obejrzany',1,1)  # tak dla testów
                while self.isPlayingVideo():
                    try:
                        self.currentTime = self.getTime()
                        self.totalTime = self.getTotalTime()
                        if self.totalTime:
                            tcounter += 1
                            if tcounter % 157 == 0:  # co jakiś czas zapisanie pozycji wideo do bazy w razie crashu Kodi; tu przyda się także, gdy user cofnie film
                                tcounter = 0
                                if not trakt.getTraktIndicatorsInfo():  # na razie jest takie ograniczenie w funkci w playcount.py
                                    if self.PREVcurrentTime != self.currentTime:
                                        self.PREVcurrentTime = self.currentTime
                                        fflog(f'zapisanie pozycji wideo do bazy w razie crashu Kodi',1,1)
                                        if self.content == "movie":
                                            playcount.markMovieDuringPlayback(self.imdb, "7", self.currentTime, self.totalTime, threshold=0.85, tmdb=self.tmdb)
                                            pass
                                        else:
                                            playcount.markEpisodeDuringPlayback(self.imdb, self.tvdb, self.season, self.episode, "7", self.currentTime, self.totalTime, threshold=0.75, tmdb=self.tmdb)
                                            pass
                                    else:
                                        fflog(f'brak zmiany pozycji od ostatniego zapisu do bazy (materiał zapauzowany?)',1,1)
                                        pass
                    except Exception:
                        fflog_exc(0)
                        pass
                    xbmc.sleep(2000)

            elif self.content == "movie":
                while self.isPlayingVideo():
                    try:
                        self.currentTime = self.getTime()
                        self.totalTime = self.getTotalTime()  # może być 0 czasami
                        fflog(f'{self.currentTime=} {self.totalTime=}',0,1)
                        if self.totalTime:
                            watched = self.currentTime / self.totalTime >= 0.85  # sprawdzenie, czy "obejrzany" (jak powyżej 85%)
                            pvalue = control.window.getProperty(pname)  # odczytanie ostatniego znacznika

                            tcounter += 1
                            # delete = (tcounter - 1) < 157
                            if tcounter % 157 == 0:  # co jakiś czas zapisanie pozycji wideo do bazy w razie crashu Kodi
                                # tcounter = 0
                                tcounter = 157
                                if not trakt.getTraktIndicatorsInfo() or also_locally:  # na razie jest takie ograniczenie w funkci w playcount.py
                                    if self.PREVcurrentTime != self.currentTime:
                                        self.PREVcurrentTime = self.currentTime
                                        pvalue = ""  # to wymusza
                                        fflog(f'wymuszenie zapisania pozycji wideo do bazy w razie crashu Kodi',1,1)
                                    else:
                                        fflog(f'brak zmiany pozycji od ostatniego zapisu do bazy (materiał zapauzowany?)',1,1)
                                        pass

                            if watched == True and not pvalue == "7":
                                fflog(f'mark as watched  {self.imdb=} {self.tmdb=} {pvalue=}',1,1)
                                control.window.setProperty(pname, "7")  # ustawienie znacznika
                                playcount.markMovieDuringPlayback(self.imdb, "7", self.currentTime, self.totalTime, also_locally, threshold=0.85, tmdb=self.tmdb)
                            elif watched == False and not pvalue == "6":
                                fflog(f'mark as unwatched  {self.imdb=} {self.tmdb=} {pvalue=}',1,1)
                                control.window.setProperty(pname, "6")  # ustawienie znacznika
                                playcount.markMovieDuringPlayback(self.imdb, "6", self.currentTime, self.totalTime, also_locally, threshold=0.85, tmdb=self.tmdb, delete=(tcounter < 2))
                    except Exception:
                        fflog_exc(0)
                        pass
                    xbmc.sleep(2000)

            elif self.content == "episode":
                while self.isPlayingVideo():
                    try:
                        self.currentTime = self.getTime()
                        self.totalTime = self.getTotalTime()  # może być 0 czasami
                        fflog(f'{self.currentTime=} {self.totalTime=}',0,1)
                        if self.totalTime:
                            watched = self.currentTime / self.totalTime >= 0.75  # dla seriali mniejszy, bo odcinki są krótsze (a może odejmować od końca np. 5 minut)
                            pvalue = control.window.getProperty(pname)

                            tcounter += 1
                            # delete = (tcounter - 1) < 157
                            # fflog(f'{delete=} {tcounter=}',1,1)
                            if tcounter % 157 == 0:  # co jakiś czas zapisanie pozycji wideo do bazy w razie crashu Kodi
                                tcounter = 0
                                tcounter = 157
                                if not trakt.getTraktIndicatorsInfo() or also_locally:  # na razie jest takie ograniczenie w funkci w playcount.py
                                    if self.PREVcurrentTime != self.currentTime:
                                        self.PREVcurrentTime = self.currentTime
                                        pvalue = ""  # to wymusza
                                        fflog(f'wymuszenie zapisania pozycji wideo do bazy w razie crashu Kodi',1,1)
                                    else:
                                        fflog(f'brak zmiany pozycji od ostatniego zapisu do bazy (materiał zapauzowany?)',1,1)
                                        pass

                            if watched == True and not pvalue == "7":
                                fflog(f'mark as watched  {self.imdb=} {self.tmdb=} {pvalue=} {tcounter=}',1,1)
                                control.window.setProperty(pname, "7")
                                playcount.markEpisodeDuringPlayback(self.imdb, self.tvdb, self.season, self.episode, "7", self.currentTime, self.totalTime, also_locally, threshold=0.75, tmdb=self.tmdb)
                            elif watched == False and not pvalue == "6":
                                fflog(f'mark as unwatched  {self.imdb=} {self.tmdb=} {pvalue=} {tcounter=}',1,1)
                                control.window.setProperty(pname, "6")
                                playcount.markEpisodeDuringPlayback(self.imdb, self.tvdb, self.season, self.episode, "6", self.currentTime, self.totalTime, also_locally, threshold=0.75, tmdb=self.tmdb, delete=(tcounter < 2))
                    except Exception:
                        fflog_exc(0)
                        pass
                    xbmc.sleep(2000)

            fflog('end of keepPlaybackAlive method')
            control.window.clearProperty(pname)


        def libForPlayback(self):
            """ oznacza w Bibliotece, że obejrzany """
            try:
                if self.DBID is not None:

                    if self.content == "movie":
                        rpc = (
                            '{"jsonrpc": "2.0", "method": "VideoLibrary.SetMovieDetails", "params": {"movieid" : %s, "playcount" : 1 }, "id": 1 }'
                            % str(self.DBID)
                        )
                    elif self.content == "episode":
                        rpc = (
                            '{"jsonrpc": "2.0", "method": "VideoLibrary.SetEpisodeDetails", "params": {"episodeid" : %s, "playcount" : 1 }, "id": 1 }'
                            % str(self.DBID)
                        )
                    else:
                        return

                    control.jsonrpc(rpc)

                    # if control.setting("crefresh") == "true":
                        # fflog('action refresh',1,1)
                        # control.refresh()
                        # pass
            except Exception:
                fflog_exc(1)
                pass


        def onPlayBackStarted(self):
            fflog('playback started')
            self.playback_started = True
            #control.execute("Dialog.Close(notification,true)")
            if True:
                try:
                    fflog( "# file " + self.getPlayingFile(), 0)
                    # self.is_active = True  # nie wiem, czy to tu potrzebne
                except Exception:
                    fflog( "# failed get what I'm playing #", 0)


        def onAVStarted(self):  # czasami dopiero po ponad 1 sekundzie odpala
            fflog('player has video and audiostream')
            #fflog(f"{self.getTotalTime()=}", 1)

            if (
                control.setting("bookmarks") == "true"
                and int(self.offset) > 120
                and self.isPlayingVideo()
                and abs(int(self.offset) - self.getTime()) > 10 # 10 sekund tolerancji
            ):
                """
                if control.setting("bookmarks.auto") == "true":  # nie ma takiego settingsu
                    self.seekTime(float(self.offset))
                else:
                """
                control.execute("Dialog.Close(all,true)")
                control.sleep0(200)

                self.pause()
                control.sleep0(100)

                if self.totalTime and self.totalTime > 30 and self.totalTime - self.offset < 5:
                    self.offset -= 10
                    pass

                minutes, seconds = divmod(float(self.offset), 60)
                hours, minutes = divmod(minutes, 60)
                label = f"{int(hours):02}:{int(minutes):02}:{int(seconds):02}"

                label = control.lang2(12022).format(label)
                fflog('waiting for decision if continue from last point or start from begin')
                if (
                    #control.setting("resume.source") == "1"  # nie ma takiego settingsu
                    trakt.getTraktIndicatorsInfo()
                    and trakt.getTraktCredentialsInfo() == True
                ):
                    yes = control.yesnoDialog(
                        label + ("[CR]  (Trakt scrobble)" if self.offsetSource=='trakt' else '[CR]  (local FanFilm bookmarks)'),
                        yeslabel=control.lang2(13404),
                        nolabel=control.lang2(12021),
                    )
                else:  # lokalnie
                    yes = control.yesnoDialog(
                        label,
                        yeslabel=control.lang2(13404),
                        nolabel=control.lang2(12021),
                    )

                if yes:
                    minutes, seconds = divmod(float(self.offset), 60)
                    hours, minutes = divmod(minutes, 60)
                    #fflog(f'user decided jump to {float(self.offset)=} sec. ({(float(self.offset)/60)} min.)')
                    fflog(f"user decided jump to {int(hours):02}:{int(minutes):02}:{int(seconds):02}  |  {float(self.offset)=} sec.")
                    self.seekTime(float(self.offset))

                    control.sleep0(500)
                    self.currentTime = self.getTime()
                    fflog(f'{self.currentTime=}',0,1)
                    c = 0
                    while self.currentTime < 2 and c < 5*5:
                        c += 1
                        control.sleep(200)
                        self.currentTime = self.getTime()
                    fflog(f'{self.currentTime=}',0,1)

                self.pause()
                control.sleep(100)

            else:
                if self.isPlayingVideo():
                    if (
                        trakt.getTraktCredentialsInfo()
                        #and control.setting("trakt.scrobble") == "true"
                        and trakt.getTraktIndicatorsInfo()
                        and self.external_scrobble_is_disabled()
                    ):
                        #self.currentTime = self.getTime()
                        #self.totalTime = self.getTotalTime()
                        #fflog(f'bookmarks set_scrobble (trakt)')
                        bookmarks.set_scrobble(
                            self.currentTime,
                            #self.totalTime,
                            self.runtime or self.totalTime,
                            self.content,
                            self.imdb,
                            self.tvdb,
                            self.season,
                            self.episode,
                            self.offset,
                            action="start",
                            threshold=(0.85 if self.content == "movie" else 0.75),
                            tmdb=self.tmdb,
                        )            
            #self.idleForPlayback()  # nie ma takiej funkcji tu

            # Automatyczne pobieranie napisów z OpenSubtitles (nowe REST API)
            if self.imdb and self.imdb != "0" and control.setting("opensubtitles.enable") == "true":
                try:
                    from ptw.libraries import subtitles
                    subtitles.get(
                        name=self.name or "",
                        imdb=self.imdb,
                        season=self.season or "",
                        episode=self.episode or "",
                    )
                except Exception:
                    fflog_exc(1)


        def onPlayBackStopped(self, force_watched=False):
            if self.is_active == False:  # powinno oznaczać, że już funkcja została wykonana
                return

            fflog('player has been stopped')  # czasami się nie chce pojawiać

            self.is_active = False

            control.window.setProperty('FanFilm.flag.play_took_place', '1')
            control.log('ustawiono flagę play_took_place',1)

            if self.totalTime:
                percent = float(self.currentTime / (self.runtime or self.totalTime)) * 1
            else:
                percent = 0
            fflog(f'\n{self.currentTime=:9.3f}\n  {self.totalTime=:9.3f}\n    {self.runtime=:9.3f}\n{         percent=:9.2%}')

            # Kadr+ 2.40.32:
            # Marker ostatnio obejrzanego odcinka dla Postępu.
            try:
                _kadr_total = float(self.runtime or self.totalTime or 0)
                _kadr_current = float(self.currentTime or 0)
                if (self.content == "episode" and self.season and self.episode and (force_watched or (_kadr_total > 0 and (_kadr_current / _kadr_total) >= 0.75))):
                    control.window.setProperty('FanFilm.last_watched_episode', json.dumps({
                        'imdb': str(self.imdb or '0'),
                        'tmdb': str(self.tmdb or '0'),
                        'season': str(self.season or '0'),
                        'episode': str(self.episode or '0'),
                    }))
                    control.log('zapisano marker last_watched_episode', 1)
            except Exception:
                pass

            """
            if (self.totalTime == 0
                or self.currentTime == 0
               ):
                fflog(f'nie rejestruję czasu')
                #control.sleep(1000)  # czemu taki długi czas ?
                control.sleep(100)  # eksperyment
                return  # a co z trakt ? Czy nie trzeda dać sygnału stop ? trzeba
            """
            _kadr_total_for_bookmark = self.totalTime or self.runtime
            if _kadr_total_for_bookmark and self.currentTime > 120:  # 2 minuty
                ok = (int(self.currentTime) > 120
                        and (
                            self.content == "movie" and float(self.currentTime / _kadr_total_for_bookmark) < 0.85
                         or self.content == "episode" and float(self.currentTime / _kadr_total_for_bookmark) < 0.75
                         )
                     )
                if ( ok
                     and not self.watched_before  # zastanowić się nad tym (jak usunę, to nie zwiększy się ilość obejrzeń, ale jak nie usunę, to nie przesunie się na sam dół i nie będzie w "ostatnio oglądanych")
                    ):
                    bookmarks._delete_record(self.content, self.imdb, self.season, self.episode, tmdb=self.tmdb)  # przydaje się, aby osatnio oglądany pojawiał się na końcu w tabeli
                    control.sleep(100)
                #fflog(f'bookmarks (re)set | {self.imdb=} {self.tmdb=} {self.currentTime=}')
                bookmarks.reset(
                    self.currentTime,
                    _kadr_total_for_bookmark,  # tylko do ustalenia, od ilu procent liczyć jako obejrzany
                    self.content,
                    self.imdb,
                    self.season,
                    self.episode,
                    threshold=(0.85 if self.content == "movie" else 0.75),
                    tmdb=self.tmdb,
                )

            # dla trakt musi pójść sygnał pause albo stop, dlatego dalsza część kodu musi być wykonana

            # rejestrację czasu w trakt wykonuje też wtyczka z repo Kodi script.trakt i może ona nadpisywać to co tu jest wysyłane (chociaż zależy od ustawień tam) 
            if (
                trakt.getTraktCredentialsInfo()
                #and control.setting("trakt.scrobble") == "true"
                and trakt.getTraktIndicatorsInfo()
                # można ewentualnie zrobić wykrywanie aktywnej takiej wtyczki i jej ustawień (tam też jest offset od ilu rejestrować), tylko wówczas jak coś zmieni się w tamtej wtyczce to tu może przestać działać, więc może lepiej niezależnie zapisywać
                #and (not external_script_trakt_enabled or int(external_scrobble_start_offset)*60 > self.currentTime and external_scrobble_movie != "true" if self.content == "movie" else external_scrobble_episode != "true") 
                and self.external_scrobble_is_disabled()
            ):
                #fflog(f'bookmarks set_scrobble (trakt)')
                bookmarks.set_scrobble(
                    self.currentTime,
                    #self.totalTime,
                    self.runtime or self.totalTime,
                    self.content,
                    self.imdb,
                    None,
                    self.season,
                    self.episode,
                    self.offset,
                    threshold=(0.85 if self.content == "movie" else 0.75),
                    tmdb=self.tmdb,
                )

            _kadr_total_for_watched = self.totalTime or self.runtime
            if (force_watched or (_kadr_total_for_watched
                and (
                    self.content == "movie" and float(self.currentTime / _kadr_total_for_watched) >= 0.85
                 or self.content == "episode" and float(self.currentTime / _kadr_total_for_watched) >= 0.75
                 )
                )):
                fflog(f'mark as watched')
                self.libForPlayback()

            if control.setting("crefresh") == "true":
                fflog('action refresh',1,1)
                control.refresh()

            fflog('end of onPlayBackStopped method',1,1)


        def onPlayBackEnded(self):  # materiał doszedł do końca
            fflog('playback Ended')
            self.onPlayBackStopped(force_watched=True)
            # self.libForPlayback()
            # if control.setting("crefresh") == "true":
                # fflog('action refresh',1,1)
                # control.refresh()
            fflog('end of onPlayBackEnded method',1,1)


        def onPlayBackError(self):  # nie wiem, kiedy to się pojawia  # Will be called when playback stops due to an error. 
            fflog('playback ERROR')
            self.is_active = False  # wyzerowanie flagi
            self.onPlayBackStopped()  # nie wiem, czy trzeba to ręcznie, czy Kodi sam trigernie ten callback (ale ponieważ zrobiłem, że funkcja może się nie wykonać ze względu na flagę, to lepiej ją wywołam)


        def onPlayBackSeek(self, time, offset):
            fflog('playback Seek')
            if self.isPlayingVideo():
                if (
                    trakt.getTraktCredentialsInfo()
                    #and control.setting("trakt.scrobble") == "true"
                    and trakt.getTraktIndicatorsInfo()
                    and self.external_scrobble_is_disabled()
                ):
                    #self.currentTime = self.getTime()  # ewentualnie (time / 1000)
                    self.currentTime = time / 1000
                    #self.totalTime = self.getTotalTime()
                    #fflog(f'{time=} {offset=}')
                    #fflog(f'{self.totalTime=} {self.currentTime=}')
                    #fflog(f'bookmarks set_scrobble (trakt)')
                    bookmarks.set_scrobble(
                        self.currentTime,
                        #self.totalTime,
                        self.runtime or self.totalTime,
                        self.content,
                        self.imdb,
                        None,
                        self.season,
                        self.episode,
                        self.offset,
                        action="start",
                        threshold=(0.85 if self.content == "movie" else 0.75),
                        tmdb=self.tmdb,
                    )


        def onPlayBackResumed(self):
            fflog('playback Resumed')
            if self.isPlayingVideo():
                if (
                    trakt.getTraktCredentialsInfo()
                    #and control.setting("trakt.scrobble") == "true"
                    and trakt.getTraktIndicatorsInfo()
                    and self.external_scrobble_is_disabled()
                ):
                    #self.currentTime = self.getTime()
                    #self.totalTime = self.getTotalTime()
                    #fflog(f'{self.totalTime=} {self.currentTime=}')
                    #fflog(f'bookmarks set_scrobble (trakt)')
                    bookmarks.set_scrobble(
                        self.currentTime,
                        #self.totalTime,
                        self.runtime or self.totalTime,
                        self.content,
                        self.imdb,
                        None,
                        self.season,
                        self.episode,
                        self.offset,
                        action="start",
                        threshold=(0.85 if self.content == "movie" else 0.75),
                        tmdb=self.tmdb,
                    )


        def onPlayBackPaused(self):
            fflog('playback Paused')
            if self.isPlayingVideo():
                if (
                    trakt.getTraktCredentialsInfo()
                    #and control.setting("trakt.scrobble") == "true"
                    and trakt.getTraktIndicatorsInfo()
                    and self.external_scrobble_is_disabled()
                ):
                    #self.currentTime = self.getTime()
                    #self.totalTime = self.getTotalTime()
                    #fflog(f'{self.totalTime=} {self.currentTime=}')
                    #if self.currentTime > 
                    #fflog(f'bookmarks set_scrobble (trakt)')
                    bookmarks.set_scrobble(
                        self.currentTime,
                        #self.totalTime,
                        self.runtime or self.totalTime,
                        self.content,
                        self.imdb,
                        None,
                        self.season,
                        self.episode,
                        self.offset,
                        threshold=(0.85 if self.content == "movie" else 0.75),
                        tmdb=self.tmdb,
                    )


        def external_scrobble_is_disabled(self):
            external_scrobble_is_disabled = not(trakt.getTraktAddonMovieInfo() if self.content == "movie" else trakt.getTraktAddonEpisodeInfo())
            """ bo okazało się, że już taka funkcja jest
            external_script_trakt_id = "script.trakt"
            #fflog(f'sprawdzam, cz zewnętrzna wtyczka "{external_script_trakt_id}" jest aktywna')
            #control.sleep(100)
            #external_script_trakt_exists = control.condVisibility(f"System.HasAddon({external_script_trakt_id})")
            #if external_script_trakt_exists:
            external_script_trakt_enabled = control.condVisibility(f"System.AddonIsEnabled({external_script_trakt_id})")
            if external_script_trakt_enabled:
                external_scrobble_movie = control.addon(external_script_trakt_id).getSetting("scrobble_movie")
                external_scrobble_episode = control.addon(external_script_trakt_id).getSetting("scrobble_episode")

            external_scrobble_is_disabled = (
                    #not (external_script_trakt_exists and external_script_trakt_enabled)
                    not external_script_trakt_enabled
                    or (
                        external_scrobble_movie != "true" if self.content == "movie"
                        else external_scrobble_episode != "true"
                       )
                )
            """
            #fflog(f'{external_scrobble_is_disabled=}')
            return external_scrobble_is_disabled


        # def get_host_name(self, url):
            # """ chyba jednak nie będę używał """
            # m = re.search('https?://([A-Za-z_0-9.-]+).*', url)
            # if m:
                # return m.group(1).split('.')[-2]
            # else:
                # return ""


    def time_to_seconds(time_str):
        if ':' in str(time_str):
            time_parts = time_str.split(':')
            if len(time_parts) == 3:
                hours, minutes, seconds = map(int, time_parts)
                return hours * 3600 + minutes * 60 + seconds
            elif len(time_parts) == 2:
                minutes, seconds = map(int, time_parts)
                return minutes * 60 + seconds
            else:
                raise ValueError("Nieprawidłowy format czasu.")
        else:
            # raise ValueError("Czas musi zawierać dwukropek.")
            return time_str


    def drm_item(url, item=None):
        """
        DRM support by Lantash.

        InputStream old properties – deprecated (Kodi 18-22).
        See: https://github.com/xbmc/inputstream.adaptive/wiki/Integration-DRM
        """
        # import xbmc
        # fflog( f'{xbmc.getInfoLabel("System.BuildVersion")=}', 1,1)
        # fflog( f'{control.infoLabel("System.BuildVersion")=}', 1,1)
        # kodiver = xbmc.getInfoLabel("System.BuildVersion")[:2]  # str
        kodiver = kodi_version = get_kodi_version().major  # można tym zastąpić # int

        from ast import literal_eval
        stream_data = url.split('|')[-1]
        stream_data = literal_eval(stream_data)
        # fflog(f'stream_data={json.dumps(stream_data, indent=2)}',1,1)

        if "&ia=0" in sys.argv[2]:
            fflog(f'rezygnacja z ISA',1,1)
            item.setPath(stream_data['manifest'])
            return item

        if 1:
            try:
                import inputstreamhelper
                if stream_data.get('licence_url'):
                    is_helper = inputstreamhelper.Helper(stream_data["protocol"], 'com.widevine.alpha')
                else:
                    is_helper = inputstreamhelper.Helper(stream_data["protocol"])
                # fflog(f'{is_helper=}',1,1)  # np. Helper(mpd, drm=None)
                # fflog(f'{dir(is_helper)=}',1,1)  # ['_check_drm', '_check_widevine', '_enable_inputstream', '_first_run', '_get_lib_version', '_has_inputstream', '_inputstream_enabled', '_inputstream_version', '_install_inputstream', '_install_widevine_from_repo', '_supports_hls', '_supports_widevine', '_update_widevine', 'check_inputstream', 'cleanup', 'disable', 'drm', 'enable', 'get_current_wv', 'info_dialog', 'inputstream_addon', 'install_and_finish', 'install_widevine', 'install_widevine_from', 'protocol', 'remove_widevine', 'rollback_libwv']
                # fflog(f'{is_helper.inputstream_addon=}',1,1)  # 'inputstream.adaptive'
                # fflog(f'{is_helper.check_inputstream()=}',1,1)  # True
                if not is_helper.check_inputstream():  # kontrola
                    fflog(f'wystąpił problem:  {is_helper.check_inputstream()=}',1,1)
                    return None
                else:
                    # fflog(f'wsio OK',1,1)
                    pass
            except Exception:
                fflog_exc(1)
                pass

        if item is None:
            item = control.item(path=stream_data['manifest'], offscreen=True)
        else:
            item.setPath(stream_data['manifest'])
        # fflog(f'{item.getPath()=}',1,1)

        if not control.condVisibility("System.AddonIsEnabled(inputstream.adaptive)"):
            fflog(f'UWAGA: system nie wykrył aktywnej wtyczki "inputstream.adaptive"',1,1)
            import xbmcgui
            control.dialog.notification('Kadr+', 'BŁĄD: ' + control.lang(33061), xbmcgui.NOTIFICATION_ERROR, time=4000, sound=True)
            control.sleep(3000)
            return item
            pass

        fflog(f'ustawienie odpowiednich właściwości dla ISA',1,1)

        # item.setProperty('inputstream', is_helper.inputstream_addon)  # 'inputstream.adaptive'
        item.setProperty('inputstream', 'inputstream.adaptive')  # jak nie ma inputstreamhelper'a

        item.setMimeType(f'{stream_data["mimetype"]}')

        if stream_data.get('licence_url'):
            # kolejność jest ważna
            license_config = [
                              'com.widevine.alpha',  # powinno być raczej z pola licence_type
                              # stream_data.get('licence_type') or 'com.widevine.alpha',  # or 'none'  # nie testowałem jeszcze
                              stream_data['licence_url'],
                              stream_data['licence_header'],
                              stream_data['post_data'],
                              stream_data['response_data'],
                             ]
            # fflog(f'license_config={json.dumps(license_config, indent=2)}',1,1)
        else:
            license_config = ''

        # fflog(f'{kodi_version=}',1,1)
        if kodi_version < 21:  # nie przetestowałem jeszcze do końca na Kodi v20, bo mi się obecnie Kodi 20.5 na Windowsie zamyka przy próbie ostworzenia takiego materiału
            item.setProperty('inputstream.adaptive.manifest_type', stream_data['protocol'])

            if license_config:
                item.setProperty('inputstream.adaptive.license_type', license_config[0])

            license_config = license_config[1:]
            license_config = '|'.join(license_config)  # Four blocks (req | header | body | response) are expected in license URL
            # fflog(f'{license_config=}',1,1)
            item.setProperty('inputstream.adaptive.license_key', license_config)

        if kodi_version >= 21 and kodi_version < 23:  # czy nie trzeba zrobić ograniczenia, aby to nie działało dla K22 ? Chyba, że to nie przeszkadza - na razie przynajmniej nie - patrz komentarz niżej
            # if license_config:  # python nie rzuca błędu, więc opcjonalne (tak jak wyżej)
            license_config = license_config[:3]
            license_config = list(filter(None, license_config))
            license_config = '|'.join(license_config)
            # license_config = license_config.strip('|')
            # fflog(f'{license_config=}',1,1)
            # license_config = license_config.replace('|R{SSM}', '').strip('|')  # bo to robi jakiś problem w Kodi 21 (nie wiem o co chodzi, komunikat "mailformed")
            item.setProperty('inputstream.adaptive.drm_legacy', license_config)
            pass

        if kodi_version >= 22:
        # if kodi_version >= 21:  # też mi działało (przynajmniej na moim Windowsie, ale to może być jakaś indywidualna sprawa, bo wcześniej miałem Kodi v22 alpha i może ono zainstalowało jakąś nowszą wersję ISA, co obsługuje te polecenia)
            # fflog(f'{item.getProperty('inputstream.adaptive.drm_legacy')=}',1,1)
            if not item.getProperty('inputstream.adaptive.drm_legacy'):
                # if stream_data.get('licence_url'):
                if stream_data:
                    # poniższy fragment jest na podstawie przykładu ze strony internetowej, ale samo to nie chciało mi działać w K22 Alpha 1 (z sierpnia 2025) bez ustawienia drm_legacy, choć na październikowej już działa
                    drm_configs = {
                        "com.widevine.alpha": {  # chyba licence_type (Key System for DRM Name)
                            "license": {
                                "server_url":  stream_data.get('licence_url') or '',
                                "req_headers": stream_data.get('licence_header') or '',
                            }
                        }
                    }
                    item.setProperty('inputstream.adaptive.drm', json.dumps(drm_configs))

        # i jeszcze na koniec
        item.setContentLookup(False)
        item.setProperty('IsPlayable', 'true')

        return item


    return player()
