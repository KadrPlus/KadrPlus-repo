from urllib.parse import urlencode
try:
    from lib.ff.source_utils import DEFAULT_UA
except Exception:
    DEFAULT_UA = 'Mozilla/5.0'

def build_isa_url(url, referer, origin=None, ua=DEFAULT_UA, cookie=None):
    parts=[]
    if referer: parts.append('Referer=%s' % referer)
    if origin: parts.append('Origin=%s' % origin)
    if ua: parts.append('User-Agent=%s' % ua)
    if cookie: parts.append('Cookie=%s' % cookie)
    return 'isa+%s|%s' % (url, '&'.join(parts)) if parts else 'isa+' + url

def build_drmff(manifest, widevine_url=None, lic_referer=None, ua=DEFAULT_UA):
    data={'protocol':'mpd','mimetype':'application/dash+xml','manifest':manifest,'licence_type':'','licence_url':'','licence_header':'','post_data':'','response_data':''}
    if widevine_url:
        data.update({'licence_type':'com.widevine.alpha','licence_url':widevine_url,'licence_header':urlencode({'User-Agent':ua,'Referer':lic_referer or '', 'Content-Type':''}),'post_data':'R{SSM}'})
    return 'DRMFF|%r' % data


# --- Kadr+ 2.42.11: free-proxy rotation fallback for cloudnestra resolver ---
def request_with_proxy_rotation(attempt, attempts=12, parallel=6):
    """Small fail-closed proxy rotation helper.

    FanFilm new uses this for Cloudnestra/vsembed. We keep it conservative in
    Kadr+: if public proxy lists are unavailable, it simply returns None and the
    caller falls back without breaking playback.
    """
    try:
        import re, time
        from concurrent.futures import ThreadPoolExecutor, as_completed
        from random import shuffle
        from lib.ff import requests
        from lib.ff import cache, control
        try:
            from lib.ff.log_utils import fflog
        except Exception:
            def fflog(*a, **k): pass
        proxy_re = re.compile(r'^\d{1,3}(?:\.\d{1,3}){3}:\d{2,5}$')
        sources = [
            'https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&protocol=http&proxy_format=ipport&format=text',
            'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
        ]
        proxies = []
        try:
            row = cache.cache_get('ff_free_proxies', control.providercacheFile)
            if row and row.get('value') and (time.time() - row.get('date', 0)) < 1800:
                proxies = [p for p in row.get('value','').split(',') if p]
        except Exception:
            proxies = []
        if not proxies:
            for url in sources:
                try:
                    resp = requests.Session().get(url, timeout=10)
                    proxies = [ln.strip() for ln in (resp.text or '').splitlines() if proxy_re.match(ln.strip())]
                    if proxies:
                        break
                except Exception:
                    continue
            try:
                if proxies:
                    cache.cache_insert('ff_free_proxies', ','.join(proxies), control.providercacheFile)
            except Exception:
                pass
        if not proxies:
            return None
        shuffle(proxies)
        proxies = proxies[:int(attempts or 12)]
        def _run(proxy):
            try:
                return proxy, attempt({'http': 'http://%s' % proxy, 'https': 'http://%s' % proxy})
            except Exception:
                return proxy, None
        with ThreadPoolExecutor(max_workers=int(parallel or 6)) as ex:
            futs = [ex.submit(_run, p) for p in proxies]
            for fut in as_completed(futs):
                proxy, result = fut.result()
                if result is not None:
                    try: fflog('proxy rotation: success via %s' % proxy)
                    except Exception: pass
                    for f in futs:
                        f.cancel()
                    return result
    except Exception:
        return None
    return None
