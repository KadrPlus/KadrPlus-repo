# Kadr+ compatibility layer for FanFilm settings.
try:
    from ptw.libraries import control
except Exception:
    control = None

_SETTING_ALIASES = {
    'ekino.domain': 'ekinotv.domain',
    'ekino.phpsessid': 'ekinotv.phpsessid',
    'ekino.cookies_auth': 'ekinotv.cookies_auth',
    'ekino.user_agent': 'ekinotv.user_agent',
    'ekinopremium.premium_mode': 'ekinotv.premium_mode',
    'ekinopremium.client_key': 'ekinotv.client_key',
}

def get_setting(name, default=None):
    try:
        if control:
            # For setting ids that were removed from Kadr+ UI, read their Kadr+ alias first.
            # This avoids Kodi warnings and keeps FanFilm-style code working.
            if name in _SETTING_ALIASES:
                value = control.setting(_SETTING_ALIASES[name])
                if value not in (None, ''):
                    return value
            value = control.setting(name)
            return default if value is None or value == "" else value
    except Exception:
        pass
    return default

def get_bool(name, default=False):
    value = get_setting(name, None)
    if value is None:
        return default
    return str(value).lower() in ("true", "1", "yes", "tak", "on")

def get_int(name, default=0):
    try:
        return int(get_setting(name, default))
    except Exception:
        return default

def get_float(name, default=0.0):
    try:
        return float(get_setting(name, default))
    except Exception:
        return default

def set_setting(name, value):
    try:
        if control and hasattr(control, "addon"):
            return control.addon.setSetting(name, str(value))
    except Exception:
        pass

class _SettingsCompat(object):
    def get(self, name, default=None):
        return get_setting(name, default)

    def get_setting(self, name, default=None):
        return get_setting(name, default)

    def getBool(self, name, default=False):
        return get_bool(name, default)

    def get_bool(self, name, default=False):
        return get_bool(name, default)

    def getInt(self, name, default=0):
        return get_int(name, default)

    def get_int(self, name, default=0):
        return get_int(name, default)

    def getFloat(self, name, default=0.0):
        return get_float(name, default)

    def get_float(self, name, default=0.0):
        return get_float(name, default)

    def set(self, name, value):
        return set_setting(name, value)

    def set_setting(self, name, value):
        return set_setting(name, value)

    def setString(self, name, value):
        return set_setting(name, value)

    def setBool(self, name, value):
        return set_setting(name, 'true' if value else 'false')

    def setInt(self, name, value):
        return set_setting(name, int(value))

    def getString(self, name, default=""):
        return str(get_setting(name, default) or "")

    def get_string(self, name, default=""):
        return str(get_setting(name, default) or "")

    def getBoolean(self, name, default=False):
        return get_bool(name, default)

    def get_boolean(self, name, default=False):
        return get_bool(name, default)

    def getInteger(self, name, default=0):
        return get_int(name, default)

    def get_integer(self, name, default=0):
        return get_int(name, default)

# FanFilm-style imports use: from lib.ff.settings import settings
settings = _SettingsCompat()

# Common aliases used by FanFilm-style code
setting = get_setting
bool_setting = get_bool
int_setting = get_int
float_setting = get_float
