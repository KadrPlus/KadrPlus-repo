import time

def xsleep(seconds=0):
    try: time.sleep(float(seconds))
    except Exception: pass
