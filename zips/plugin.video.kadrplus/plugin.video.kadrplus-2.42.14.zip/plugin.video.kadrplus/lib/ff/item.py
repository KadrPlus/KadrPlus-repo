# Kadr+ compatibility FFItem for FanFilm scrapers.
class _FFVTag:
    def __init__(self, item=None):
        self.item = item or {}
    def getYear(self):
        return self.item.get('year') or self.item.get('premiered_year') or ''
    def getDuration(self):
        return self.item.get('duration') or 0
    def getCountryCodes(self):
        v = self.item.get('country_codes') or self.item.get('countries') or self.item.get('country') or ['PL']
        if isinstance(v, str): return [v.upper()] if v else []
        try: return [str(x).upper() for x in v]
        except Exception: return ['PL']
    def getPremieredAsW3C(self):
        return self.item.get('premiered') or self.item.get('date') or ''
    def getFirstAiredAsW3C(self):
        return self.item.get('premiered') or self.item.get('date') or ''
    def getEnglishTitle(self):
        try:
            for a in self.item.get('aliases') or []:
                country = str(a.get('country') or a.get('iso_3166_1') or '').upper()
                lang = str(a.get('lang') or a.get('language') or '').lower()
                title = a.get('title') or a.get('name') or a.get('english_title') or ''
                if title and (country in ('US','GB','UK') or lang == 'en'):
                    return title
        except Exception:
            pass
        return self.item.get('title') or self.item.get('originaltitle') or ''
    def getEnglishTvShowTitle(self):
        return self.getEnglishTitle()
    def getOriginalTitle(self):
        return self.item.get('originaltitle') or self.item.get('original_title') or self.item.get('title') or ''

class FFItem(dict):
    def __init__(self, *args, **kwargs):
        super().__init__()
        if len(args) == 1 and isinstance(args[0], dict):
            self.update(args[0])
        elif args:
            keys = ['title','localtitle','aliases','year','imdb','tmdb_id','tvdb','season','episode']
            for key, value in zip(keys, args): self[key]=value
        self.update(kwargs)
        if 'tmdb' in self and 'tmdb_id' not in self: self['tmdb_id']=self.get('tmdb')
        if 'tmdb_id' in self and 'tmdb' not in self: self['tmdb']=self.get('tmdb_id')
        if 'localtitle' in self and 'local_title' not in self: self['local_title']=self.get('localtitle')
        if 'local_title' in self and 'localtitle' not in self: self['localtitle']=self.get('local_title')
        self.__dict__=self
        if not getattr(self, 'vtag', None): self.vtag=_FFVTag(self)
        if self.get('show_item') and isinstance(self.get('show_item'), dict) and not isinstance(self.get('show_item'), FFItem):
            self.show_item=FFItem(self.get('show_item'))
        if self.get('season_item') and isinstance(self.get('season_item'), dict) and not isinstance(self.get('season_item'), FFItem):
            self.season_item=FFItem(self.get('season_item'))
    def get(self, key=None, default=None):
        if key is None: return self
        return super().get(key, default)
    @classmethod
    def from_dict(cls, data): return cls(data or {})
    @property
    def title(self): return self.get('title') or self.get('localtitle') or self.get('tvshowtitle') or ''
    @title.setter
    def title(self, v): self['title']=v
    @property
    def date(self): return self.get('premiered') or self.get('date') or ''
    @date.setter
    def date(self, v): self['date']=v
    def absolute_episode_number(self):
        try:
            return int(self.get('absolute_episode') or 0) or int(self.get('episode') or 0)
        except Exception: return 0
