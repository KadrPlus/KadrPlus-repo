# Kadr+ compatibility layer for newer FanFilm scrapers.
try:
    import requests
except Exception:
    requests = None
try:
    from ptw.libraries import cache, cleantitle, control, client, source_utils
except Exception:
    pass




# Kadr+ 2.42.10: expose local compatibility source_utils to FanFilm-new scrapers.
# `from lib.ff import source_utils` must return lib/ff/source_utils.py, not the
# older ptw.libraries.source_utils module, otherwise helpers like
# quality_from_resolution/get_netflix_ep_id are missing.
try:
    import importlib as _kadr_importlib
    source_utils = _kadr_importlib.import_module(__name__ + '.source_utils')  # noqa: F401
except Exception:
    pass
