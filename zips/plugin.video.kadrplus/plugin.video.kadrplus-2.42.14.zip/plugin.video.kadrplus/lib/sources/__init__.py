# Kadr+ minimal compatibility for selected FanFilm-style sources.
try:
    from typing import TypedDict, NotRequired
except Exception:
    TypedDict = dict
    NotRequired = object
class SourceItem(dict):
    pass
SourceTitleAlias = dict
class Provider(object):
    priority = 1
    language = ['pl']
class SourceModule(object):
    def __init__(self, name=None, provider=None, group=None):
        self.name=name; self.provider=provider; self.group=group
def single_call(fn=None, *a, **kw):
    def deco(f):
        return f
    return deco(fn) if callable(fn) else deco
