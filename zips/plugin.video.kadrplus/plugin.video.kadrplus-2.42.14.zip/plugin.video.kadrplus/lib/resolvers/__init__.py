# -*- coding: utf-8 -*-
"""Kadr+ local resolvers adapted from FanFilm new.

These resolvers are tried before resolveurl. They are intentionally small and
fail closed: if nothing matches or resolving fails, caller falls back to the
normal resolveurl path.
"""
from urllib.parse import urlparse

try:
    from lib.ff.log_utils import fflog, fflog_exc
except Exception:
    def fflog(*a, **k): pass
    def fflog_exc(*a, **k): pass


def _host_of(url):
    try:
        return (urlparse(url).hostname or '').lower()
    except Exception:
        return ''


def _resolver_classes():
    out = []
    for modname, clsname in (
        ('doodstream', 'DoodStreamResolver'),
        ('wrzucaj', 'WrzucajResolver'),
    ):
        try:
            module = __import__('lib.resolvers.%s' % modname, fromlist=[clsname])
            cls = getattr(module, clsname)
            out.append(cls)
        except Exception as e:
            try:
                fflog('[local resolvers] import failed %s: %s' % (modname, e))
                fflog_exc()
            except Exception:
                pass
    return out


def resolve_local(url):
    """Return resolved URL or None. Caller should fall back to resolveurl."""
    if not url:
        return None
    host = _host_of(url)
    for cls in _resolver_classes():
        try:
            inst = cls()
            if not inst.valid_url(url, host):
                continue
            host_id = inst.get_host_and_id(url)
            if not host_id:
                continue
            matched_host, media_id = host_id
            fflog('[local resolvers] %s matched %r' % (cls.__name__, url))
            stream = inst.get_media_url(matched_host, media_id)
            if stream:
                return stream
            fflog('[local resolvers] %s returned empty for %r' % (cls.__name__, url))
            return None
        except Exception as e:
            try:
                fflog('[local resolvers] %s failed for %r: %s' % (getattr(cls, '__name__', cls), url, e))
                fflog_exc()
            except Exception:
                pass
            return None
    return None


def get_local_domains():
    out = []
    for cls in _resolver_classes():
        try:
            for d in getattr(cls, 'domains', ()) or ():
                d = str(d or '').lower()
                if d and d != '*' and d not in out:
                    out.append(d)
        except Exception:
            pass
    return out
