# -*- coding: utf-8 -*-
import re
from urllib.parse import quote_plus

try:
    from lib.ff.source_utils import wrzucaj_embed_sources
except Exception:
    def wrzucaj_embed_sources(*a, **k): return []


class ResolverError(Exception):
    pass


class WrzucajResolver(object):
    name = 'Wrzucaj'
    domains = ['wrzucaj.pl']
    pattern = re.compile(r'(?://|\.)(wrzucaj\.pl)/embed/([0-9]+)', re.I)

    def valid_url(self, url, host=None):
        return bool(self.get_host_and_id(url))

    def get_host_and_id(self, url):
        m = self.pattern.search(str(url or ''))
        if not m:
            return None
        return m.group(1).lower(), m.group(2)

    def _headers(self, headers):
        return '|' + '&'.join('%s=%s' % (k, quote_plus(v)) for k, v in headers.items())

    def get_media_url(self, host, media_id):
        web_url = self.get_url(host, media_id)
        variants = wrzucaj_embed_sources(web_url, ua='Mozilla/5.0')
        if variants:
            headers = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://wrzucaj.pl/'}
            return variants[0]['url'] + self._headers(headers)
        raise ResolverError('File Not Found or Removed')

    def get_url(self, host, media_id):
        return 'https://%s/embed/%s/v' % (host, media_id)
