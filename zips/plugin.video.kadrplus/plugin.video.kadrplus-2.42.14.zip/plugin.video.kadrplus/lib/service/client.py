# -*- coding: utf-8 -*-
"""Minimal Kadr+ service client shim for FanFilm DRM scrapers.

FanFilm CDA resolver expects ``lib.service.client.service_client.url``
to point at the local HTTP service used as Widevine license proxy.
Kadr+ already has its own httpserver.py running on the configured port,
so this shim exposes the same attribute without porting the whole FanFilm
service stack.
"""

class ServiceClient(object):
    @property
    def url(self):
        port = '8663'
        try:
            from ptw.libraries import control
            port = control.setting('http_server.port') or port
        except Exception:
            pass
        return 'http://127.0.0.1:%s/' % port

    def set_media_files(self, data):
        """FanFilm compatibility: push generated .m3u8 files to Kadr+ httpserver."""
        try:
            import requests
            requests.post(self.url.rstrip('/') + '/media', json=data or {}, timeout=3)
            return True
        except Exception:
            try:
                from ptw.debug import fflog_exc
                fflog_exc(1)
            except Exception:
                pass
            return False

service_client = ServiceClient()
