# -*- coding: utf-8 -*-
"""
Kadr+ port of FanFilm 2026 obejrzyj_filmy.py family.
Providers: obejrzyj.to, filmyonline.cc, premiumsmart.eu

This module exposes legacy Kadr+ source API while using the newer FanFilm
API-based search/episode logic:
- /api/v1/search/<query>?loader=searchPage
- /api/v1/titles/<base64 service|type|id>?loader=titlePage
- /api/v1/titles/<media_id>/seasons/<s>/episodes/<e>?loader=episodePage
"""
from __future__ import annotations

import json
import re
from base64 import b64encode
from json import JSONDecodeError
from urllib.parse import quote, urlparse, unquote, parse_qsl, urlsplit

try:
    from lib.ff import requests
except Exception:
    import requests

from ptw.libraries import source_utils, cleantitle, control
from ptw.debug import fflog, fflog_exc


class ObejrzyjFilmyBase(object):
    priority = 1
    language = ['pl']
    PROVIDER = 'obejrzyjto'
    URL = 'https://obejrzyj.to/'
    HAS_TMDB_SUPPORT = True

    # Obejrzyj.to exposes hosters through its JSON API.  Some buttons use
    # a wrapper/intermediate domain in ``src`` while the visible button name
    # is the real hoster (for example Filemoon).  Kadr+ must keep the real
    # provider label and, when possible, unwrap the wrapper URL before handing
    # it to resolveurl.
    WRAPPER_HOST_HINTS = (
        'boosteradx.',
        'boosterad.',
    )
    KNOWN_HOST_LABELS = (
        # (needle, display-domain).  Needles are matched against every scalar
        # value from the Obejrzyj.to video object, not only against ``src``.
        # This is important because Obejrzyj.to sometimes returns a wrapper
        # domain (boosteradx) in ``src`` while the visible hoster on /watch/<id>
        # is stored in another field or only in the button/watch metadata.
        ('filemoon', 'filemoon.to'),
        ('fmoon', 'filemoon.to'),
        ('moonplayer', 'filemoon.to'),
        ('ultrastream', 'ultrastream.online'),
        ('ultra stream', 'ultrastream.online'),
        ('voe', 'voe.sx'),
        ('dood', 'dood.to'),
        ('do0d', 'dood.to'),
        ('streamtape', 'streamtape.com'),
        ('mixdrop', 'mixdrop.co'),
        ('vidmoly', 'vidmoly.to'),
        ('vidoza', 'vidoza.net'),
        ('streamwish', 'streamwish.to'),
        ('filelions', 'filelions.to'),
    )

    URL_VALUE_KEYS = (
        'src', 'url', 'link', 'href', 'embed', 'embed_url', 'embedUrl',
        'file', 'player', 'player_url', 'playerUrl', 'redirect', 'watch',
    )

    INFO_HIT = {
        'lektor': 'lektor',
        'napisy': 'napisy',
        'dubbing': 'dubbing',
    }

    def __init__(self):
        self._session = None
        self._csrf_token = None
        self._watch_meta_cache = {}

    @property
    def session(self):
        if self._session is None:
            self._session = requests.Session()
            try:
                self._session.headers.update({
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0',
                    'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
                    'Accept': 'application/json, text/plain, */*',
                    'Referer': self.URL,
                })
            except Exception:
                pass
            self._init_session()
        return self._session

    def _init_session(self):
        try:
            self._session.get(self.URL, timeout=(5, 8))
        except Exception:
            pass

    def request(self, url, _retried=False):
        try:
            resp = self.session.get(url, headers={'accept': 'application/json', 'referer': self.URL}, timeout=(6, 10))
            fflog(f'[{self.PROVIDER.upper()}] request: {url} -> {getattr(resp, "status_code", None)}', 0)
            if resp.status_code == 200:
                return resp.json()
            return {}
        except JSONDecodeError:
            fflog(f'[{self.PROVIDER.upper()}] JSON error for {url!r}')
            return {}
        except Exception:
            fflog_exc(1)
            return {}

    def make_id(self, tid, type=None, service=None):
        if tid and type and service:
            return b64encode(f'{service}|{type}|{tid}'.encode()).decode('ascii')
        return str(tid or '')

    def _aliases(self, aliases):
        vals=[]
        def add(v):
            v=str(v or '').strip()
            if v and v.lower() not in [x.lower() for x in vals] and not source_utils.czy_litery_krzaczki(v):
                vals.append(v)
        try:
            for a in aliases or []:
                if isinstance(a, dict):
                    add(a.get('title') or a.get('name') or a.get('originalname') or a.get('original_title'))
                else:
                    add(a)
        except Exception:
            pass
        return vals

    def _query(self, title):
        title = re.sub(r'(?:^|(?<=\s))(?:I{1,3}[VX]?|[VX]I{0,3}|\d+)(?:(?=\s|$))', '', str(title or ''))
        title = re.sub(r'\b\w\b', '', title)
        title = re.sub(r'\s+', ' ', title).strip()
        if '/' in title:
            title = max(title.split('/'), key=lambda t: len(t.strip()))
        return title.strip()

    def _search(self, query, tmdb=None, imdb=None):
        query = str(query or '').strip()
        if not query:
            return []
        fflog(f'[{self.PROVIDER.upper()}] query: {query!r}', 0)
        try:
            data = self.request(f"{self.URL}api/v1/search/{quote(query, safe='')}?loader=searchPage")
            raw = data.get('results') or []
        except Exception:
            fflog_exc(1)
            return []
        fflog(f'[{self.PROVIDER.upper()}] search: {len(raw)} results', 0)
        try:
            tmdb_int = int(tmdb) if tmdb else None
        except Exception:
            tmdb_int = None
        imdb = str(imdb or '').strip() or None
        if tmdb_int or imdb:
            filtered=[]
            for item in raw:
                if tmdb_int and item.get('tmdb_id') == tmdb_int:
                    filtered.append(item); continue
                if imdb and item.get('imdb_id') == imdb:
                    filtered.append(item); continue
            return filtered
        return raw

    def _title_candidates(self, title, localtitle, aliases):
        out=[]
        def add(v):
            v=str(v or '').strip()
            if v and v.lower() not in [x.lower() for x in out]:
                out.append(v)
        add(localtitle); add(title)
        for a in self._aliases(aliases): add(a)
        return out

    def _obtain_media(self, mtype, title, localtitle, aliases, year, imdb='', tmdb=''):
        # New FanFilm path: ID lookup first.
        if self.HAS_TMDB_SUPPORT:
            for service, mid in [('tmdb', tmdb), ('imdb', imdb)]:
                if not mid:
                    continue
                media_id = self.make_id(mid, type=mtype, service=service)
                try:
                    data = self.request(f'{self.URL}api/v1/titles/{media_id}?loader=titlePage')
                    if data.get('title'):
                        return data['title']
                except Exception:
                    fflog_exc(1)
        # Fallback: search. For movies with TMDB support use FanFilm cleaned query;
        # for series or sites without IDs keep full title to preserve sequel/season words.
        candidates = self._title_candidates(title, localtitle, aliases)
        for q in candidates:
            search_q = q if (mtype == 'series' or not self.HAS_TMDB_SUPPORT) else self._query(q)
            found = self._search(search_q, tmdb=tmdb if self.HAS_TMDB_SUPPORT else None, imdb=imdb if self.HAS_TMDB_SUPPORT else None)
            if not found and not self.HAS_TMDB_SUPPORT:
                found = self._search(search_q)
            for media in found:
                try:
                    if self.HAS_TMDB_SUPPORT:
                        if tmdb and media.get('tmdb_id') and str(media.get('tmdb_id')) != str(tmdb):
                            continue
                        if imdb and media.get('imdb_id') and str(media.get('imdb_id')) != str(imdb):
                            continue
                    else:
                        # exact-ish match and year/type filter for filmyonline.
                        names = [media.get('name') or '', media.get('original_title') or '']
                        if not any(cleantitle.get(n) == cleantitle.get(x) for n in names for x in candidates):
                            continue
                        if year and media.get('year') and str(media.get('year')) != str(year):
                            continue
                    media_id = media.get('id')
                    data = self.request(f'{self.URL}api/v1/titles/{media_id}?loader=titlePage')
                    if data.get('title'):
                        return data['title']
                except Exception:
                    fflog_exc(1)
        return {}

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        tmdb = kwargs.get('tmdb') or kwargs.get('tmdb_id') or ''
        data = self._obtain_media('movie', title, localtitle, aliases, year, imdb=imdb, tmdb=tmdb)
        if not data:
            fflog(f'[{self.PROVIDER.upper()}] movie not found: {title!r}')
            return None
        payload = {
            'type':'movie',
            'id': data.get('id'),
            'titles': [v for k in ('name','original_title') if (v:=data.get(k))],
            'expected_duration': kwargs.get('duration') or kwargs.get('runtime') or '',
        }
        return json.dumps(payload)

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        tmdb = kwargs.get('tmdb') or kwargs.get('tmdb_id') or ''
        data = self._obtain_media('series', tvshowtitle, localtvshowtitle, aliases, year, imdb=imdb, tmdb=tmdb)
        if not data:
            fflog(f'[{self.PROVIDER.upper()}] show not found: {tvshowtitle!r}')
            return None
        payload = {
            'type':'series',
            'id': data.get('id'),
            'titles': [v for k in ('name','original_title') if (v:=data.get(k))],
            'expected_duration': kwargs.get('duration') or kwargs.get('runtime') or '',
        }
        return json.dumps(payload)

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        if not url:
            return None
        try:
            payload = json.loads(url) if isinstance(url, str) and url.startswith('{') else {'type':'series','id':url}
        except Exception:
            payload = {'type':'series','id':url}
        payload.update({'type':'episode','season':str(season), 'episode':str(episode), 'episode_title': title or ''})
        return json.dumps(payload)

    def _load_payload(self, url):
        try:
            if isinstance(url, str) and url.startswith('{'):
                return json.loads(url)
        except Exception:
            pass
        return {'type':'movie','id':url}

    def _episode_matches_request(self, ep, season, episode):
        """Return False only when the site explicitly says this is another episode."""
        try:
            req_s = int(season) if season is not None else None
            req_e = int(episode) if episode is not None else None
        except Exception:
            return True
        if not isinstance(ep, dict):
            return True
        def _ival(*keys):
            for k in keys:
                v = ep.get(k)
                if v is None:
                    continue
                try:
                    return int(v)
                except Exception:
                    m = re.search(r'\d+', str(v))
                    if m:
                        try:
                            return int(m.group(0))
                        except Exception:
                            pass
            return None
        got_s = _ival('season', 'season_number', 'seasonNumber')
        got_e = _ival('episode', 'number', 'episode_number', 'episodeNumber')
        if got_s is not None and req_s is not None and got_s != req_s:
            fflog(f'[{self.PROVIDER.upper()}] episode mismatch: requested S{req_s}E{req_e}, got season={got_s}', 0)
            return False
        if got_e is not None and req_e is not None and got_e != req_e:
            fflog(f'[{self.PROVIDER.upper()}] episode mismatch: requested S{req_s}E{req_e}, got episode={got_e}', 0)
            return False
        return True

    def _duration_to_minutes(self, value):
        """Convert API/video duration values to minutes, defensively."""
        try:
            if value is None or value == '':
                return 0
            if isinstance(value, (int, float)):
                n = int(value)
            else:
                text = str(value).strip().lower()
                if not text:
                    return 0
                text = text.replace(',', '.')
                # formats like 01:09:00 or 69:00
                if ':' in text:
                    parts = [int(float(x or 0)) for x in re.findall(r'\d+(?:\.\d+)?', text)]
                    if not parts:
                        return 0
                    sec = 0
                    for part in parts:
                        sec = sec * 60 + int(part)
                    return int(round(sec / 60.0)) if sec > 300 else int(sec)
                m = re.search(r'(\d+(?:\.\d+)?)', text)
                if not m:
                    return 0
                n = int(float(m.group(1)))
                if 'godz' in text or 'hour' in text or re.search(r'\bh\b', text):
                    # Keep simple hour-only labels useful but conservative.
                    if n <= 5 and 'min' not in text:
                        return n * 60
            if n > 300:
                return int(round(n / 60.0))
            return int(n)
        except Exception:
            return 0

    def _item_duration_minutes(self, item):
        """Find video runtime in the item or its nested objects."""
        try:
            keys = (
                'duration', 'runtime', 'length', 'time', 'minutes', 'duration_minutes',
                'durationMinutes', 'duration_seconds', 'durationSeconds', 'run_time', 'runTime'
            )
            for k in keys:
                if isinstance(item, dict) and item.get(k) not in (None, ''):
                    d = self._duration_to_minutes(item.get(k))
                    if d:
                        return d
            for key, val in self._iter_scalar_values(item):
                kl = str(key or '').lower()
                if any(x in kl for x in ('duration', 'runtime', 'length', 'minutes', 'seconds')):
                    d = self._duration_to_minutes(val)
                    if d:
                        return d
        except Exception:
            pass
        return 0

    def _duration_matches_payload(self, item, payload):
        """Reject only clear runtime mismatches (common bad Obejrzyj.to entries).

        Example from 2.40.93: an Obejrzyj.to item for S01E06 showed 46 min,
        while the requested episode runtime was 69 min.  That item opened a
        different title.  We keep a generous tolerance so short metadata drift
        does not remove valid mirrors.
        """
        try:
            expected = self._duration_to_minutes((payload or {}).get('expected_duration'))
            got = self._item_duration_minutes(item)
            if not expected or not got or expected < 20 or got < 20:
                return True
            tolerance = max(14, int(round(expected * 0.25)))
            if abs(expected - got) > tolerance:
                fflog(f'[{self.PROVIDER.upper()}] skipping video by duration mismatch: expected={expected} got={got}', 0)
                return False
        except Exception:
            pass
        return True

    def _iter_scalar_values(self, obj, depth=0, prefix=''):
        """Yield (key_path, string_value) from nested API objects defensively."""
        if depth > 5:
            return
        try:
            if isinstance(obj, dict):
                for k, v in obj.items():
                    key = f'{prefix}.{k}' if prefix else str(k)
                    for x in self._iter_scalar_values(v, depth + 1, key):
                        yield x
            elif isinstance(obj, (list, tuple)):
                for i, v in enumerate(obj):
                    key = f'{prefix}[{i}]' if prefix else f'[{i}]'
                    for x in self._iter_scalar_values(v, depth + 1, key):
                        yield x
            elif obj is not None:
                yield prefix, str(obj)
        except Exception:
            return

    def _host_label_from_text(self, text):
        try:
            text = unquote(str(text or '')).replace('\\/', '/').lower()
            text = text.replace('_', ' ').replace('-', ' ')
            for needle, label in self.KNOWN_HOST_LABELS:
                n = str(needle).lower().replace('_', ' ').replace('-', ' ')
                if n and n in text:
                    return label
            host = (urlparse(str(text).split('|', 1)[0]).hostname or '').lower()
            if host:
                for needle, label in self.KNOWN_HOST_LABELS:
                    if needle.replace(' ', '') in host or label.split('.')[0] in host:
                        return label
        except Exception:
            pass
        return ''

    def _display_source_name(self, item, url=''):
        """Prefer the visible player/hoster name over wrapper domains.

        Kadr+ 2.40.92: Obejrzyj.to may put a wrapper/intermediate URL in
        ``src`` (for example boosteradx.online) while the real button shown on
        the website is Filemoon/UltraStream.  Scan the entire video object first
        and use wrapper domains only as a last resort.
        """
        try:
            # 1) The selected URL itself can already be a real hoster.
            label = self._host_label_from_text(url)
            if label:
                return label

            # 2) Then scan all scalar fields returned by the API.  Skip pure
            # wrapper URLs so they do not win over button/host labels.
            for key, val in self._iter_scalar_values(item):
                if not val:
                    continue
                if self._is_wrapper_url(val):
                    continue
                label = self._host_label_from_text(val)
                if label:
                    return label

            # 3) If API did not expose the button label, ask the concrete
            # /watch/<video_id> page.  This keeps Filemoon/UltraStream visible
            # instead of advertising boosteradx as if it were a real hoster.
            meta = self._watch_page_meta(item)
            label = meta.get('label') if isinstance(meta, dict) else ''
            if label:
                return label

            # 4) Fall back to the visible name, but ignore language-only names.
            name = str(item.get('name') or item.get('title') or item.get('label') or '').strip()
            if name:
                first = re.split(r'\s+|[·•\-|/]', name, 1)[0].strip().lower()
                first = re.sub(r'[^a-z0-9_.-]+', '', first)
                if first and first not in ('lektor', 'napisy', 'dubbing', 'pl', 'full', 'watch', 'player', 'odtwarzacz'):
                    return first

            # 5) Last resort: host from URL/item src, but do not advertise
            # boosteradx as a working hoster.
            host = self.source_name({'src': url}) if url else self.source_name(item)
            if host and not self._is_wrapper_url('https://' + host):
                return host
            return host or '?'
        except Exception:
            return self.source_name({'src': url}) or self.source_name(item) or '?'

    def _is_wrapper_url(self, url):
        try:
            host = (urlparse(str(url or '').split('|', 1)[0]).hostname or '').lower()
            return any(x in host for x in self.WRAPPER_HOST_HINTS)
        except Exception:
            return False

    def _hoster_regex(self):
        return r'(?:filemoon\.(?:to|sx|in|su|art)|fmoon\.(?:sx|to)|ultrastream\.online|voe\.(?:sx|so)|dood\.(?:to|yt|watch|stream|pm)|do0d\.(?:com|to)|streamtape\.(?:com|to|net)|mixdrop\.(?:co|ag|is|sx)|vidmoly\.(?:to|me)|vidoza\.net|streamwish\.(?:to|com|com)|filelions\.(?:to|live|site))'

    def _decode_maybe_base64(self, value):
        try:
            import base64
            v = str(value or '').strip().strip('"\'')
            if len(v) < 12 or not re.match(r'^[A-Za-z0-9_\-+/=]+$', v):
                return ''
            padded = v + ('=' * ((4 - len(v) % 4) % 4))
            raw = base64.urlsafe_b64decode(padded.encode('ascii'))
            out = raw.decode('utf-8', 'ignore')
            if 'http' in out or any(n in out.lower() for n, _ in self.KNOWN_HOST_LABELS):
                return out
        except Exception:
            pass
        return ''

    def _hoster_url_from_text(self, text):
        if not text:
            return ''
        try:
            # Undo common JS/HTML escaping first and try a few decode rounds.
            variants = []
            base = str(text).replace('\\/', '/').replace('&amp;', '&')
            variants.append(base)
            cur = base
            for _ in range(3):
                nxt = unquote(cur)
                if nxt == cur:
                    break
                variants.append(nxt.replace('\\/', '/').replace('&amp;', '&'))
                cur = nxt

            # Query arguments and JS assignments often keep the real target URL
            # URL-encoded or base64-url encoded.
            for raw in list(variants):
                for v in re.findall(r'(?:url|src|target|file|link|redirect|u|r|to|go|data)\s*[=:]\s*["\']?([^"\'&<>\s]+)', raw, re.I):
                    if v:
                        variants.append(unquote(v).replace('\\/', '/'))
                        dec = self._decode_maybe_base64(v)
                        if dec:
                            variants.append(dec)
                for v in re.findall(r'["\']([A-Za-z0-9_\-+/=]{20,})["\']', raw):
                    dec = self._decode_maybe_base64(v)
                    if dec:
                        variants.append(dec)

            host_rx = self._hoster_regex()
            for raw in variants:
                m = re.search(r'https?://(?:www\.)?' + host_rx + r'[^\s"\'<>\\)]*', raw, re.I)
                if m:
                    return m.group(0).rstrip('.,;')
        except Exception:
            fflog_exc(1)
        return ''

    def _wrapper_video_code(self, url):
        """Extract the video/file code from boosteradx-style wrapper URLs.

        Obejrzy.to sometimes returns a wrapper such as:
        https://boosteradx.online/e/<file_code>/<slug>
        For Filemoon this <file_code> is also accepted by the Filemoon embed
        endpoint, while ResolveURL cannot resolve the boosteradx domain itself.
        """
        try:
            path = urlparse(str(url or '').split('|', 1)[0]).path or ''
            m = re.search(r'/(?:e|v|d)/([A-Za-z0-9_-]{6,})', path)
            return m.group(1) if m else ''
        except Exception:
            return ''

    def _direct_url_from_known_wrapper(self, url, label=''):
        """Convert known wrapper URLs into real hoster URLs when it is safe.

        This is intentionally conservative.  At the moment only Filemoon is
        converted, because Obejrzy.to's Filemoon wrapper uses the same file code
        as Filemoon (/e/<code>).  UltraStream wrappers are not guessed here,
        because their working links use hash tokens that are not guaranteed to
        be identical to the wrapper path.
        """
        try:
            if not self._is_wrapper_url(url):
                return ''
            label = str(label or '').lower()
            code = self._wrapper_video_code(url)
            if not code:
                return ''
            if 'filemoon' in label or 'fmoon' in label or 'moonplayer' in label:
                # Kadr+ 2.40.99: prefer the Filemoon embed endpoint (/e/),
                # because the /d/ page can trigger the Byse/captcha branch in
                # ResolveURL for some Obejrzy.to links.  sources.py now retries
                # the opposite Filemoon endpoint automatically if the first one
                # fails, so this is only the preferred first attempt.
                _base, _sep, _hdr = str(url or '').partition('|')
                direct = 'https://filemoon.to/e/' + code
                if _hdr:
                    # Keep Referer/User-Agent headers so sources.py can pass
                    # them to ResolveURL as url$$referer.
                    direct = direct + '|' + _hdr
                fflog(f'[{self.PROVIDER.upper()}] Filemoon wrapper mapped: {_base} -> {direct}', 0)
                return direct
        except Exception:
            fflog_exc(1)
        return ''

    def _headers_from_pipe(self, header_text):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
            'Referer': self.URL,
        }
        try:
            for k, v in parse_qsl(str(header_text or ''), keep_blank_values=True):
                if k and v:
                    kk = k.replace('_', '-').strip()
                    if kk.lower() in ('referer', 'user-agent', 'origin', 'accept', 'accept-language'):
                        headers[kk] = unquote(v)
        except Exception:
            pass
        return headers

    def _unwrap_wrapper_url(self, url):
        """Try to replace wrapper URL with the real hoster URL (Filemoon etc.)."""
        if not url or not self._is_wrapper_url(url):
            return url
        raw_url = str(url)
        base_url, sep, hdr = raw_url.partition('|')
        # Sometimes the real target is already URL-encoded in the wrapper URL.
        try:
            split = urlsplit(base_url)
            candidates = [base_url]
            for _k, _v in parse_qsl(split.query, keep_blank_values=True):
                if _v:
                    candidates.append(unquote(_v))
            for c in candidates:
                found = self._hoster_url_from_text(c)
                if found:
                    fflog(f'[{self.PROVIDER.upper()}] wrapper URL target from query: {found}', 0)
                    return found + (('|' + hdr) if hdr else '')
        except Exception:
            pass
        try:
            headers = self._headers_from_pipe(hdr)
            resp = self.session.get(base_url, headers=headers, timeout=(6, 10), allow_redirects=True)
            final = getattr(resp, 'url', '') or ''
            found = self._hoster_url_from_text(final) or self._hoster_url_from_text(getattr(resp, 'text', '') or '')
            if found:
                fflog(f'[{self.PROVIDER.upper()}] wrapper URL unwrapped: {base_url} -> {found}', 0)
                return found + (('|' + hdr) if hdr else '')
            # If booster redirects to any non-wrapper playable-looking URL, keep
            # that URL instead of the dead wrapper page.  This avoids exposing
            # boosteradx as a source when the site already redirected elsewhere.
            if final and final != base_url and not self._is_wrapper_url(final):
                fflog(f'[{self.PROVIDER.upper()}] wrapper URL redirected: {base_url} -> {final}', 0)
                return final + (('|' + hdr) if hdr else '')
            fflog(f'[{self.PROVIDER.upper()}] wrapper URL not unwrapped: {base_url} status={getattr(resp, "status_code", None)}', 0)
        except Exception:
            fflog_exc(1)
        return raw_url

    def _watch_url_from_item(self, item):
        try:
            vid = item.get('id') or item.get('video_id') or item.get('videoId')
            if vid and str(vid).isdigit():
                return self.URL.rstrip('/') + '/watch/' + str(vid)
        except Exception:
            pass
        return self.URL

    def _watch_page_meta(self, item):
        """Read lightweight /watch/<id> metadata when API exposes only a wrapper.

        The React/JS page is not used as a primary scraper, but its HTML title
        and inline bootstrap data often still contain the visible hoster label
        (Filemoon/UltraStream/VOE) or an encoded target URL.  Cache per video
        id so one item is not fetched more than once during a source scan.
        """
        try:
            watch_url = self._watch_url_from_item(item)
            if not watch_url or watch_url.rstrip('/') == self.URL.rstrip('/'):
                return {}
            if watch_url in self._watch_meta_cache:
                return self._watch_meta_cache.get(watch_url) or {}
            meta = {'url': '', 'label': '', 'watch_url': watch_url}
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
                'Referer': self.URL,
            }
            resp = self.session.get(watch_url, headers=headers, timeout=(6, 10), allow_redirects=True)
            text = (getattr(resp, 'text', '') or '')
            final = getattr(resp, 'url', '') or ''
            # Prefer an actual hoster URL if it is embedded/encoded anywhere.
            meta['url'] = self._hoster_url_from_text(final) or self._hoster_url_from_text(text)
            # Prefer <title> because it usually mirrors the visible button, e.g.
            # "Film - Filemoon".  Fall back to the full HTML when needed.
            title = ''
            m = re.search(r'<title[^>]*>(.*?)</title>', text, re.I | re.S)
            if m:
                try:
                    title = re.sub(r'\s+', ' ', m.group(1)).strip()
                except Exception:
                    title = m.group(1)
            meta['label'] = (
                self._host_label_from_text(title)
                or self._host_label_from_text(final)
                or self._host_label_from_text(text[:50000])
            )
            self._watch_meta_cache[watch_url] = meta
            if meta.get('label') or meta.get('url'):
                fflog(f'[{self.PROVIDER.upper()}] watch meta {watch_url}: label={meta.get("label")!r} url={meta.get("url")!r}', 0)
            return meta
        except Exception:
            fflog_exc(1)
            return {}

    def _candidate_urls_from_item(self, item):
        """Return playable URL candidates from a video object.

        Prefer real hoster URLs, keep wrapper URLs as a fallback, and attach the
        concrete /watch/<video_id> referer when available because boosteradx may
        reject generic root referers.
        """
        direct, wrappers, others = [], [], []

        def add(value):
            try:
                value = str(value or '').strip()
                if not value:
                    return
                value = value.replace('\\/', '/')
                if value.startswith('//'):
                    value = 'https:' + value
                if not value.startswith(('http://', 'https://')):
                    # Also extract embedded URLs from text fields.
                    found = self._hoster_url_from_text(value)
                    if found:
                        value = found
                    else:
                        return
                if value in direct or value in wrappers or value in others:
                    return
                if self._hoster_url_from_text(value):
                    direct.append(value)
                elif self._is_wrapper_url(value):
                    wrappers.append(value)
                else:
                    others.append(value)
            except Exception:
                pass

        # Keyed fields first; nested scan after that catches newer API shapes.
        try:
            for key in self.URL_VALUE_KEYS:
                if key in item:
                    add(item.get(key))
        except Exception:
            pass
        for key, val in self._iter_scalar_values(item):
            try:
                if any(k.lower() in key.lower() for k in self.URL_VALUE_KEYS) or 'http' in val:
                    add(val)
            except Exception:
                pass

        # If the API only gives a wrapper (or no useful URL), the public watch
        # page often carries the real hoster URL/label in metadata.  Try that
        # before exposing the wrapper as a playable source.
        if (wrappers and not direct) or (not direct and not wrappers):
            meta = self._watch_page_meta(item)
            found = meta.get('url') if isinstance(meta, dict) else ''
            if found:
                add(found)

        referer = self._watch_url_from_item(item)
        if direct or wrappers:
            out = direct + wrappers
        else:
            # Keep unknown external URLs only when there is no better candidate.
            # Do not add Obejrzyj watch/title pages as playable sources; they are
            # JS pages, not hoster embeds.
            out = [u for u in others if not (urlparse(str(u).split('|', 1)[0]).hostname or '').endswith('obejrzyj.to')]
        final = []
        for u in out:
            base, sep, hdr = u.partition('|')
            # Preserve existing headers, but add an exact watch-page referer for
            # wrapper domains and Obejrzyj-hosted watch URLs.
            if self._is_wrapper_url(base) or (urlparse(base).hostname or '').endswith('obejrzyj.to'):
                if 'referer=' not in hdr.lower():
                    hdr = (hdr + '&' if hdr else '') + 'Referer=' + quote(referer, safe=':/')
                candidate = base + (('|' + hdr) if hdr else '')
                unwrapped = self._unwrap_wrapper_url(candidate)
                unwrapped_base = str(unwrapped or '').split('|', 1)[0]
                if not unwrapped or self._is_wrapper_url(unwrapped_base):
                    # Kadr+ 2.40.95: Filemoon on Obejrzy.to may be exposed only
                    # as a boosteradx wrapper.  The website can play it in the
                    # browser, but ResolveURL cannot handle boosteradx directly.
                    # If the API/watch metadata identifies this button as
                    # Filemoon, map /e/<code> to filemoon.to/e/<code> and let
                    # the normal Filemoon resolver handle the real hoster.
                    label = self._display_source_name(item, '')
                    mapped = self._direct_url_from_known_wrapper(candidate, label=label)
                    if mapped:
                        final.append(mapped)
                        continue
                    fflog(f'[{self.PROVIDER.upper()}] skipping unresolved wrapper candidate: {base!r}', 0)
                    continue
                final.append(unwrapped)
            else:
                final.append(base + (('|' + hdr) if hdr else ''))
        return final

    def _dedupe_source_label(self, label):
        """Canonical host label used for Obejrzy.to duplicate cleanup."""
        try:
            label = self._host_label_from_text(label) or str(label or '')
            label = label.lower().strip()
            label = label.replace('www.', '')
            # Normalize common aliases to the same visible button/hoster.
            if 'ultrastream' in label:
                return 'ultrastream.online'
            if 'filemoon' in label or 'fmoon' in label or 'moonplayer' in label:
                return 'filemoon.to'
            if 'dood' in label or 'do0d' in label:
                return 'dood.to'
            if 'voe' in label:
                return 'voe.sx'
            return re.sub(r'[^a-z0-9.]+', '', label)
        except Exception:
            return str(label or '').lower().strip()

    def _source_dedupe_key(self, entry):
        """One visible Obejrzy.to button should become one Kodi source.

        Obejrzy.to sometimes exposes the same visible player twice in the API:
        once as a direct host URL and once via a wrapper/metadata variant.  The
        website shows one UltraStream button, but Kadr+ 2.40.97 could show two.
        Deduplicate by visible host + quality + language + audio/sub info.
        """
        try:
            source = self._dedupe_source_label(entry.get('source'))
            quality = str(entry.get('quality') or '').lower().strip()
            language = str(entry.get('language') or '').lower().strip()
            info = re.sub(r'\s+', ' ', str(entry.get('info') or '').lower()).strip()
            return (source, quality, language, info)
        except Exception:
            return (str(entry.get('source') or '').lower(), str(entry.get('quality') or '').lower())

    def _source_dedupe_score(self, entry):
        """Prefer the URL that is closest to the real hoster page.

        This keeps the working UltraStream/Filemoon candidate when the API also
        returns an older wrapper/duplicate candidate for the same visible button.
        """
        score = 0
        try:
            url = str(entry.get('url') or '')
            base = url.split('|', 1)[0]
            host = (urlparse(base).hostname or '').lower().replace('www.', '')
            label = self._dedupe_source_label(entry.get('source'))
            path = urlparse(base).path or ''
            if base and not self._is_wrapper_url(base):
                score += 100
            if host and (label.split('.')[0] in host or host in label):
                score += 80
            if label == 'ultrastream.online':
                if host == 'ultrastream.online':
                    score += 100
                if '#' in base:
                    score += 35
            elif label == 'filemoon.to':
                if 'filemoon' in host or 'fmoon' in host:
                    score += 100
                if '/d/' in path:
                    score += 25
                elif '/e/' in path:
                    score += 15
            if '|Referer=' in url or '|referer=' in url.lower():
                score += 5
            if entry.get('duration'):
                score += 3
        except Exception:
            pass
        return score

    def _update_expected_duration_from_episode(self, payload, ep):
        """Use episode-level runtime as a guard against wrong Obejrzy.to mirrors."""
        try:
            if (payload or {}).get('expected_duration'):
                return
            if not isinstance(ep, dict):
                return
            for k in ('duration', 'runtime', 'length', 'time', 'minutes', 'duration_minutes',
                      'durationMinutes', 'duration_seconds', 'durationSeconds', 'run_time', 'runTime'):
                v = ep.get(k)
                if v not in (None, ''):
                    d = self._duration_to_minutes(v)
                    if d:
                        payload['expected_duration'] = d
                        fflog(f'[{self.PROVIDER.upper()}] episode expected duration from API: {d} min', 0)
                        return
        except Exception:
            pass

    def sources(self, url, hostDict, hostprDict, from_cache=False):
        result=[]
        if not url:
            return result
        payload = self._load_payload(url)
        media_id = payload.get('id')
        if not media_id:
            return result
        videos=[]
        try:
            if payload.get('type') == 'episode':
                s,e = payload.get('season'), payload.get('episode')
                data = self.request(f'{self.URL}api/v1/titles/{media_id}/seasons/{s}/episodes/{e}?loader=episodePage')
                ep = data.get('episode') or {}
                if not self._episode_matches_request(ep, s, e):
                    return result
                try:
                    fflog(f'[{self.PROVIDER.upper()}] episode payload: id={ep.get("id")} name={ep.get("name")!r} season={s} episode={e}', 0)
                except Exception:
                    pass
                self._update_expected_duration_from_episode(payload, ep)
                videos = [v for v in ep.get('videos', []) if v.get('category') == 'full']
            else:
                data = self.request(f'{self.URL}api/v1/titles/{media_id}?loader=titlePage')
                title = data.get('title') or {}
                videos = [v for v in title.get('videos', []) if v.get('category') == 'full']
        except Exception:
            fflog_exc(1)
            videos=[]
        seen_urls = set()
        seen_source_keys = {}
        seen_source_scores = {}
        for item in videos:
            try:
                if not self._duration_matches_payload(item, payload):
                    continue
                urls = self._candidate_urls_from_item(item)
                if not urls:
                    continue
                name = item.get('name') or item.get('title') or item.get('label') or self.source_name(item) or '?'
                lower_name = f"{name} {item.get('language_type','')}".lower()
                quality = item.get('quality') or item.get('quality_label') or item.get('resolution') or 'HD'
                lang = self.video_language(item)
                info = self.info_from_item(item, lower_name)
                video_duration = self._item_duration_minutes(item)
                for src in urls:
                    base_src = str(src).split('|', 1)[0]
                    if base_src in seen_urls:
                        continue
                    display_source = self._display_source_name(item, base_src)
                    # Do not list a wrapper as the hoster unless no better label
                    # exists; it is an intermediate page and usually resolves to
                    # Filemoon/UltraStream/etc.
                    if self._is_wrapper_url(base_src) and display_source in ('?', self.source_name({'src': base_src})):
                        display_source = self._host_label_from_text(name) or self._host_label_from_text(str(item)) or display_source
                    if self._is_wrapper_url(base_src) and display_source in ('?', self.source_name({'src': base_src})):
                        fflog(f'[{self.PROVIDER.upper()}] skipping unlabeled wrapper src={base_src!r}, item_keys={list(item.keys())!r}', 0)
                        continue
                    seen_urls.add(base_src)
                    entry = {
                        'source': display_source,
                        'quality': quality.lower() if str(quality)[:3].isdigit() else str(quality).upper(),
                        'language': lang,
                        'url': src,
                        'info': info,
                        'direct': False,
                        'debridonly': False,
                        'filename': '',
                        'premium': False,
                        # Kadr+ 2.40.96: keep the visible host label available
                        # during resolve().  This is required when an older or
                        # cached source still carries a boosteradx URL; the
                        # resolver can safely map it only when the selected item
                        # was the Filemoon button.
                        'for_resolve': {'specific_source_data': {
                            'source': display_source,
                            'label': display_source,
                            'name': name,
                            'provider': self.PROVIDER,
                        }},
                        **({'duration': video_duration} if video_duration else {}),
                    }
                    key = self._source_dedupe_key(entry)
                    score = self._source_dedupe_score(entry)
                    if key in seen_source_keys:
                        old_idx = seen_source_keys[key]
                        old_score = seen_source_scores.get(key, -1)
                        if score > old_score:
                            fflog(f'[{self.PROVIDER.upper()}] replacing duplicate source key={key!r}: old_score={old_score} new_score={score} url={src!r}', 0)
                            result[old_idx] = entry
                            seen_source_scores[key] = score
                        else:
                            fflog(f'[{self.PROVIDER.upper()}] skipping duplicate source key={key!r}: score={score} old_score={old_score} url={src!r}', 0)
                        continue
                    seen_source_keys[key] = len(result)
                    seen_source_scores[key] = score
                    fflog(f'[{self.PROVIDER.upper()}] video src={src!r}, name={name!r}, display={display_source!r}, info={info!r}', 0)
                    result.append(entry)
            except Exception:
                fflog_exc(1)
        fflog(f'[{self.PROVIDER.upper()}] sources: {len(result)}')
        return result

    def resolve(self, url, **kwargs):
        # Kadr+ 2.40.96: Obejrzyj.to may persist an old/cached Filemoon
        # source as a boosteradx wrapper.  When playItem passes the selected
        # source label, map that wrapper directly to Filemoon before trying
        # to open boosteradx (which fails in Kodi/ResolveURL).
        try:
            specific = kwargs.get('specific_source_data') or kwargs.get('source') or {}
            if isinstance(specific, dict):
                hint = ' '.join([str(specific.get(k) or '') for k in ('source', 'label', 'name', 'provider')])
            else:
                hint = str(specific or '')
        except Exception:
            hint = ''

        mapped = self._direct_url_from_known_wrapper(url, label=hint)
        if mapped:
            return mapped

        unwrapped = self._unwrap_wrapper_url(url)
        unwrapped_base = str(unwrapped or '').split('|', 1)[0]
        if unwrapped and not self._is_wrapper_url(unwrapped_base):
            return unwrapped

        # Extra fallback for the most common old-cache case: user clicked a
        # Filemoon-labelled source, but older Kadr+ stored only boosteradx URL.
        # Do not apply this to UltraStream-labelled wrappers.
        if hint and 'ultrastream' not in hint.lower():
            mapped = self._direct_url_from_known_wrapper(url, label='filemoon')
            if mapped:
                return mapped
        return unwrapped

    def source_name(self, item):
        try:
            return urlparse(item.get('src') or '').hostname or ''
        except Exception:
            return ''

    def video_language(self, item):
        lang = (item.get('language') or '').lower()
        lang_type = (item.get('language_type') or '').lower()
        if re.search(r'\b(lektor|dubbing|polski|pl)\b', lang_type):
            return 'pl'
        if re.search(r'\b(napisy|sub)\b', lang_type):
            return 'en'
        return lang or 'pl'

    def info_from_item(self, item, lower_name):
        vals=[]
        for key,val in self.INFO_HIT.items():
            try:
                if isinstance(key, str):
                    hit = key in lower_name
                else:
                    hit = key.search(lower_name)
                if hit and val and val not in vals:
                    vals.append(val)
            except Exception:
                pass
        lang_type = (item.get('language_type') or '').replace('_',' ').strip()
        if lang_type and lang_type.lower() not in [v.lower() for v in vals]:
            vals.append(lang_type)
        return ' '.join(vals).strip()


class PremiumSmartBase(ObejrzyjFilmyBase):
    PROVIDER = 'premiumsmart'
    URL = 'https://premiumsmart.eu/'

    def _init_session(self):
        try:
            self._session.headers.update({
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
                'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
                'DNT': '1',
            })
            resp = self._session.get(self.URL, timeout=(10, 20))
            if resp.status_code == 200:
                m = re.search(r'window\.bootstrapData\s*=\s*({.*});', resp.text, re.S)
                if m:
                    try:
                        self._csrf_token = json.loads(m.group(1)).get('csrf_token')
                    except Exception:
                        pass
                if not self._csrf_token:
                    m = re.search(r'"csrf_token"\s*:\s*"([^"]+)"', resp.text)
                    if m: self._csrf_token = m.group(1)
                if not self._csrf_token and 'XSRF-TOKEN' in self._session.cookies:
                    self._csrf_token = unquote(self._session.cookies['XSRF-TOKEN'])
        except Exception:
            fflog_exc(1)

    def request(self, url, _retried=False):
        try:
            headers={'accept':'application/json','referer':self.URL}
            if self._csrf_token:
                headers['X-XSRF-TOKEN']=self._csrf_token
            resp = self.session.get(url, headers=headers, timeout=(10,20))
            fflog(f'[{self.PROVIDER.upper()}] request: {url} -> {resp.status_code}', 0)
            if resp.status_code == 200:
                return resp.json()
            if resp.status_code in (401,403,419) and not _retried:
                self._session=None; self._csrf_token=None
                return self.request(url, _retried=True)
        except JSONDecodeError:
            fflog(f'[{self.PROVIDER.upper()}] JSON error for {url!r}')
        except Exception:
            fflog_exc(1)
        return {}

# Loader compatibility: resources.lib.sources scans every .py file and expects
# class source. This helper module must not be exposed as a real provider.
class source(object):
    priority = -1
    language = ['pl']
