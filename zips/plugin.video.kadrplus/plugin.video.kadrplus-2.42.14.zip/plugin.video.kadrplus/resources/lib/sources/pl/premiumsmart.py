from resources.lib.sources.pl._obejrzyj_filmy_api import PremiumSmartBase

class source(PremiumSmartBase):
    PROVIDER = 'premiumsmart'
    URL = 'https://premiumsmart.eu/'
    HAS_TMDB_SUPPORT = True
