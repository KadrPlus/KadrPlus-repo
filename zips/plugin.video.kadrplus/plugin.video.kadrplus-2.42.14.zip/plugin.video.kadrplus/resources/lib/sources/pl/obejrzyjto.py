from resources.lib.sources.pl._obejrzyj_filmy_api import ObejrzyjFilmyBase

class source(ObejrzyjFilmyBase):
    PROVIDER = 'obejrzyjto'
    URL = 'https://obejrzyj.to/'
    HAS_TMDB_SUPPORT = True
