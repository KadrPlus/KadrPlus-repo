# -*- coding: UTF-8 -*-
"""
Kadr+ / FanFilm - źródło: zaluknij.cc
Cherry-pick 2.42.07: bezpieczne poprawki z FanFilm bez hurtowej podmiany pliku.
"""

from __future__ import annotations

import re
from requests.compat import urlparse
from urllib.parse import quote_plus
from typing import List, Optional, ClassVar, TYPE_CHECKING

from lib.ff import requests
from lib.ff import control, cache, cleantitle, utils
from lib.ff.client import parseDOM
from lib.ff.source_utils import setting_cookie, detect_script, search_queries_extended
from lib.ff.settings import settings
from lib.ff.log_utils import fflog, fflog_exc

if TYPE_CHECKING:
    from lib.sources import SourceItem, SourceTitleAlias


class source:
    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['pl']

    def __init__(self):
        self.base_link = 'https://zaluknij.cc'
        self.search_link = self.base_link + '/wyszukiwarka?phrase='
        self.search_title = set()

        # Googlebot UA omija część blokad Zaluknij; użytkownik może nadpisać w ustawieniach.
        googlebot_ua = 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'
        self.headers = {
            'Referer': self.base_link + '/',
            'user-agent': googlebot_ua,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
        }
        ua = (settings.getString('zaluknij.user_agent') or settings.getString('zaluknijcc.ua') or '').strip(' "\'')
        if ua:
            self.headers.update({'User-Agent': ua})

        self.session = requests.Session()

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str, **kwargs) -> Optional[str]:
        year_alt = kwargs.get('year_alt')
        if year_alt:
            year = (year, year_alt)
        return self._find(title, localtitle, year, 'movie', aliases)

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list[SourceTitleAlias], year: str, **kwargs) -> Optional[str]:
        years = year
        year_alt = kwargs.get('year_alt')
        premiered = kwargs.get('spremiered') or kwargs.get('premiered')
        if premiered:
            years = [year, year_alt, premiered]
        elif year_alt:
            years = (year, year_alt)
        return self._find(tvshowtitle, localtvshowtitle, years, 'tvshow', aliases)

    def episode(self, url: Optional[str], imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str, **kwargs) -> Optional[str]:
        absolute_episode = kwargs.get('absolute_episode') or 0
        return self._find_episode(url, season, episode, absolute_episode)

    def sources(self, url: Optional[str], hostDict: List[str], hostprDict: List[str]) -> 'List[SourceItem]':
        sources = []
        if not url:
            fflog('no sources')
            return sources

        filename = ''
        info2 = ''
        if isinstance(url, tuple):
            info2 = str(url[1] or '').strip()
            filename = info2
            url = url[0]

        out = []
        cookiesD = self._cookie_dict()
        headers = self.headers.copy()
        headers.update({'Referer': self.base_link})
        try:
            resp = self.session.get(url, headers=headers, cookies=cookiesD, timeout=60, verify=False)
        except Exception:
            fflog_exc()
            return sources

        if getattr(resp, 'status_code', 0) != 200:
            fflog(f'unexpected status code: {getattr(resp, "status_code", None)}')
            if getattr(resp, 'status_code', 0) == 403:
                fflog('likely Cloudflare challenge active')
            return sources

        html = resp.text
        result = parseDOM(html, 'tbody')
        new_variant = False
        if result:
            result = result[0]
            videos = parseDOM(result, 'tr')
        else:
            # Nowy układ Zaluknij: karty video zamiast tabeli tbody/tr.
            result = parseDOM(html, 'div', attrs={'class': r'row g-\d+'})
            if result:
                result = result[0]
                videos = parseDOM(result, 'div', attrs={'class': 'video-card link-to-video'})
                new_variant = True
            else:
                videos = []

        for vid in videos:
            if not new_variant:
                hosthrefquallang = re.findall(r'href\s*=\s*"([^"]+).*?<td>([^<]+).*?<td>([^<]+)', vid, re.DOTALL)
                for href, lang, qual in hosthrefquallang:
                    host = urlparse(href).netloc
                    out.append({'href': href, 'host': host, 'lang': lang, 'qual': qual})
            else:
                try:
                    hrefs = parseDOM(vid, 'a', attrs={'class': 'stretched-link'}, ret='href') or parseDOM(vid, 'a', ret='href')
                    if not hrefs:
                        continue
                    href = hrefs[0]
                    lang = (parseDOM(vid, 'span', attrs={'class': 'badge badge-version'}) or [''])[0]
                    qual = (parseDOM(vid, 'span', attrs={'class': 'badge badge-quality'}) or [''])[0]
                    host = urlparse(href).netloc
                    out.append({'href': href, 'host': host, 'lang': lang, 'qual': qual})
                except Exception:
                    fflog_exc()

        seen = set()
        for x in out:
            link = x.get('href')
            if not link or link in seen:
                continue
            seen.add(link)
            host = (x.get('host') or '').rsplit('.', 1)[0].rsplit('.', 1)[-1]
            lang = x.get('lang') or ''
            qual = str(x.get('qual') or '').lower()
            sources.append({
                'source': host,
                'quality': self._quality_from_label(qual),
                'language': 'pl',
                'url': link,
                'info': lang,
                'direct': False,
                'debridonly': False,
                'filename': filename,
                'premium': False,
                'info2': info2,
            })
        fflog(f'sources: {len(sources)}')
        return sources

    def resolve(self, url: str) -> Optional[str]:
        link = str(url).replace('\\/', '/')
        link = link.replace('//', '/').replace(':/', '://')
        fflog(f'{link=}')
        return link

    # ── helpers ────────────────────────────────────────────────────────────

    def _cookie_dict(self):
        cf_cookie = (
            setting_cookie(setting_name='zaluknij.cookies_cf', cookie_name='cf_clearance')
            or setting_cookie(setting_name='zaluknijcc.cf', cookie_name='cf_clearance')
            or (settings.getString('zaluknijcc.cf') or '').strip(' "\'')
        )
        if cf_cookie:
            try:
                cache.cache_insert('zaluknij_cookies', f'cf_clearance={cf_cookie}', control.providercacheFile)
            except Exception:
                pass
            return {'cf_clearance': cf_cookie}

        cached = cache.cache_get('zaluknij_cookies', control.providercacheFile)
        cookies = cached.get('value') if cached else ''
        cookiesD = {}
        if cookies:
            try:
                cookiesD = {x[0].strip(): x[1].strip() for x in [c.split('=', 1) for c in cookies.strip('; ').split(';') if '=' in c]}
            except Exception:
                cookiesD = {}
        return cookiesD

    def _quality_from_label(self, qual: str) -> str:
        q = (qual or '').lower()
        if '1080' in q:
            return '1080p'
        if '720' in q or q == 'wysoka':
            return '720p'
        if 'cam' in q or q == 'niska':
            return 'CAM'
        if '4k' in q or '2160' in q:
            return '4K'
        return 'SD'

    def _find(self, title, localtitle, year, type_, aliases=None):
        try:
            if not title:
                return

            # Zaluknij zwykle lepiej działa po polskim tytule, więc zachowujemy dotychczasową kolejność Kadr+.
            title, localtitle = localtitle, title
            title = (title or '').lower()
            localtitle = (localtitle or '').lower()

            if title == localtitle and aliases:
                originalname = [a for a in aliases if 'originalname' in a]
                originalname = originalname[0]['originalname'] if originalname else ''
                originalname = '' if detect_script(originalname) else originalname
                if originalname and originalname.lower() != title:
                    title = originalname.lower()
                else:
                    try:
                        alias_title = (aliases[0].get('title') or '').strip()
                        if alias_title:
                            title = alias_title.lower()
                    except Exception:
                        pass

            for query, strict in self._query_variants(title, localtitle):
                control.sleep(500)
                url = self._search(query, year, type_, validate_full_title=strict)
                if url is False:
                    return
                if url:
                    return url

        except Exception:
            fflog_exc()

    def _query_variants(self, title, localtitle):
        """Zwraca warianty szukania z FanFilm, ale z bezpieczną walidacją pełnego tytułu domyślnie."""
        seen = set()

        def add(q, strict=True):
            q = re.sub(r'\s+', ' ', str(q or '')).strip()
            key = (q.lower(), bool(strict))
            if q and key not in seen:
                seen.add(key)
                return (q, strict)
            return None

        # Bazowa logika Kadr+.
        for q in search_queries_extended(title, localtitle):
            item = add(q, True)
            if item:
                yield item

        bases = [str(x or '') for x in (title, localtitle) if x]
        for base in bases:
            variants = []
            variants.append(base.replace('.', ':'))
            variants.append(base.replace('–', '-').replace(' - ', ' '))
            variants.append(base.replace('.', ''))
            variants.append(base.replace(':', ''))
            variants.append(base.replace("'", ''))
            variants.append(base.replace('!', ''))
            variants.append(base.replace('?', ''))
            for v in variants:
                item = add(v, True)
                if item:
                    yield item

        # Ryzykowne fallbacki z FanFilm są pod przełącznikiem. Domyślnie wyłączone.
        try:
            allow_loose = not settings.getBool('zaluknijcc.validate_full_title', True)
        except Exception:
            allow_loose = False
        if allow_loose:
            for base in bases:
                if len(base) > 2:
                    item = add(base[:-1], False)
                    if item:
                        yield item
                for sep in (':', '.'):
                    if sep in base:
                        item = add(base.split(sep, 1)[0], False)
                        if item:
                            yield item

    def _find_episode(self, urls, season, episode, absolute_episode=0):
        if not urls:
            return
        if not isinstance(urls, list):
            urls = [urls]

        for url in urls:
            info2 = ''
            if isinstance(url, tuple):
                info2 = str(url[1] or '').strip()
                url = url[0]
            if not url:
                continue

            headers = self.headers.copy()
            headers.update({'Referer': self.base_link})
            try:
                html = self.session.get(url, headers=headers, cookies=self._cookie_dict(), timeout=60, verify=False)
            except Exception:
                fflog_exc()
                continue

            if getattr(html, 'status_code', 0) != 200:
                fflog(f'unexpected status code: {getattr(html, "status_code", None)}')
                if getattr(html, 'status_code', 0) == 403:
                    fflog('likely Cloudflare challenge active')
                continue

            sesres = parseDOM(html.text, 'ul', attrs={'id': 'episode-list'})
            if not sesres:
                continue
            sesres = sesres[0]
            sezony = re.findall(r'(<span>.*?</ul>)', sesres, re.DOTALL)

            episode_url = ''
            match_info = ''
            should_break = False
            for sezon in sezony:
                if should_break:
                    break
                sesx = parseDOM(sezon, 'span')
                mch = re.search(r'(\d+)', sesx[0], re.DOTALL) if sesx else None
                ses = mch[1] if mch else '0'
                eps = parseDOM(sezon, 'li')

                for ep in eps:
                    hrefs = parseDOM(ep, 'a', ret='href')
                    titles = parseDOM(ep, 'a')
                    if not hrefs or not titles:
                        continue
                    mch_ep = re.search(r's\d+e(\d+)', titles[0], re.IGNORECASE)
                    if not mch_ep:
                        continue
                    epis = mch_ep[1]
                    try:
                        if int(ses) == int(season) and int(epis) == int(episode):
                            episode_url = hrefs[0]
                            match_info = f's{int(ses):02d}e{int(epis):02d}'
                            should_break = True
                            break
                        # FanFilm fallback: część anime/seriali bywa numerowana absolutnie w 1. sezonie.
                        if absolute_episode and int(ses) == 1 and int(epis) == int(absolute_episode):
                            episode_url = hrefs[0]
                            match_info = f's{int(ses):02d}e{int(epis):02d}'
                            should_break = True
                            break
                    except Exception:
                        continue

                if not should_break and absolute_episode and self._safe_int(season) > 1:
                    for ep in eps:
                        hrefs = parseDOM(ep, 'a', ret='href')
                        titles = parseDOM(ep, 'a')
                        if not hrefs or not titles:
                            continue
                        mch_ep = re.search(r's\d+e(\d+)', titles[0], re.IGNORECASE)
                        if not mch_ep:
                            continue
                        epis = mch_ep[1]
                        try:
                            if int(epis) == int(absolute_episode) and int(ses) == int(season):
                                episode_url = hrefs[0]
                                match_info = f's{int(ses):02d}e{int(epis):02d}'
                                should_break = True
                                break
                        except Exception:
                            continue

            if episode_url:
                info = ' '.join(x for x in [info2, match_info] if x).strip()
                return (episode_url, info) if info else episode_url

    def _search(self, title, year, type_, validate_full_title=True):
        title = re.sub(r'\s+', ' ', str(title or '')).strip()
        if not title:
            return
        cache_key = (title.lower(), type_, bool(validate_full_title))
        if cache_key in self.search_title:
            return
        self.search_title.add(cache_key)

        fflog(f"query: {title!r} {type_=} {validate_full_title=}")

        original_title = title
        title = self.strip_prefix(title)
        title = re.sub(r'^[\s:–—-]+', '', title).strip() or original_title
        search_url = f'{self.search_link}{quote_plus(title)}'

        try:
            req = self.session.get(search_url, headers=self.headers.copy(), cookies=self._cookie_dict(), timeout=60, verify=False)
        except Exception:
            fflog_exc()
            return

        if getattr(req, 'status_code', 0) != 200:
            fflog(f'unexpected status code: {getattr(req, "status_code", None)}')
            if getattr(req, 'status_code', 0) == 403:
                fflog('likely Cloudflare challenge active')
            return False

        html = req.text
        links_blocks = []
        old_layout = parseDOM(html, 'div', attrs={'id': 'advanced-search'})
        if old_layout:
            cols = parseDOM(old_layout[0], 'div', attrs={'class': r'col-sm-\d+'})
            links_blocks.extend(cols)
        new_layout = parseDOM(html, 'div', attrs={'class': r'item\s+col-sm-\d+'})
        links_blocks.extend(new_layout)

        fflog(f'search: {len(links_blocks)} results')
        if not links_blocks:
            if '<body' not in html:
                fflog(f'{html=}', 1)
            else:
                fflog('an error occurred')
            return

        fout = []
        sout = []
        search_key = self.strip_prefix(original_title.lower())
        search_norm = self._norm_title(search_key)

        for link in links_blocks:
            try:
                hrefs = parseDOM(link, 'a', ret='href')
                if not hrefs:
                    continue
                href = hrefs[0]
                tytul_list = parseDOM(link, 'div', attrs={'class': 'title'}) or parseDOM(link, 'a')
                if not tytul_list:
                    continue
                tytul = self._clean_result_title(tytul_list[0])
                candidate_norm = self._norm_title(self.strip_prefix(tytul.lower()))

                title_match = False
                if not validate_full_title:
                    title_match = True
                elif search_norm and (search_norm == candidate_norm or search_norm in [self._norm_title(t) for t in tytul.lower().split('/')]):
                    title_match = True
                elif search_key and search_key in self.strip_prefix(tytul.lower()):
                    # Zachowanie Kadr+: pozwala złapać wyniki typu "Tytuł / Tytuł alternatywny".
                    title_match = True

                if not title_match:
                    continue
                item = {'title': tytul, 'url': href}
                if 'serial-online' in href or 'seasons' in href:
                    sout.append(item)
                else:
                    fout.append(item)
            except Exception:
                fflog_exc()

        results = fout if type_ == 'movie' else sout
        results.sort(key=lambda k: len(k['title']), reverse=True)
        if not results:
            return

        years = self._year_candidates(year, type_)
        out = []
        fallback = []
        for item in results:
            date = '0'
            if type_ == 'movie':
                m = re.search(r'(?:19|20)\d{2}', str(item.get('url') or '')[-16:])
                date = m.group(0) if m else '0'
            else:
                try:
                    control.sleep(500)
                    h = self.session.get(item['url'], headers=self.headers.copy(), cookies=self._cookie_dict(), timeout=60, verify=False).text
                    date_info = parseDOM(h, 'div', attrs={'class': 'info'})
                    if date_info:
                        lis = parseDOM(date_info, 'li')
                        date = lis[-1] if lis else '0'
                        m = re.search(r'(?:19|20)\d{2}', str(date))
                        date = m.group(0) if m else '0'
                except Exception:
                    date = '0'

            if not years:
                item['year'] = date if str(date).isdigit() else ''
                out.append(item)
                if type_ == 'movie':
                    break
            elif str(date).isdigit() and int(date):
                if int(date) in years:
                    item['year'] = date
                    out.append(item)
                    if type_ == 'movie':
                        break
                else:
                    fflog(f'year mismatch: {date=} {years=} {item=}')
            else:
                fallback.append(item)

        if not out and fallback:
            out = fallback[:1] if type_ == 'movie' else fallback

        if not out:
            return

        if type_ == 'movie':
            item = out[0]
            label = self._label_with_year(item)
            return (item['url'], label)

        # Dla seriali zachowujemy wiele kandydatów i sortujemy podobieństwem,
        # żeby episode() mogło sprawdzić kilka URL-i, gdy rok/tytuł jest niejednoznaczny.
        candidates = []
        for item in out:
            label = self._label_with_year(item)
            for part in str(label or '').split('/'):
                primary, ratio, lev = self._calculate_similarity(part, title)
                candidates.append((item['url'], label, {'ratio': ratio, 'levenshtein': lev, 'primary': primary}))
        candidates.sort(key=lambda x: (x[2]['ratio'], -x[2]['levenshtein']), reverse=True)

        dedup = []
        seen_urls = set()
        for cand in candidates:
            if cand[0] in seen_urls:
                continue
            seen_urls.add(cand[0])
            dedup.append((cand[0], cand[1]))
        return dedup

    def _year_candidates(self, year, type_):
        years = []
        if not year:
            return years
        year_alt = 0
        premiered = 0
        if isinstance(year, (tuple, list)):
            if len(year) >= 3:
                year, year_alt, premiered = year[0], year[1], year[2]
                m = re.search(r'(?:19|20)\d{2}', str(premiered or ''))
                premiered = int(m.group(0)) if m else 0
            elif len(year) >= 2:
                year, year_alt = year[0], year[1]
        try:
            year = int(year)
            years.append(year)
        except Exception:
            return []
        try:
            if year_alt:
                years.append(int(year_alt))
        except Exception:
            pass
        if premiered:
            years.append(int(premiered))
        if type_ == 'movie':
            years.extend([year - 1, year + 1])
        else:
            years.append(year + 1)
            if premiered:
                years.append(int(premiered) - 1)
        return list(dict.fromkeys([y for y in years if y]))

    def _clean_result_title(self, title):
        t = str(title or '')
        t = re.sub(r'\s*\(Edycja kolorowa\)\s*', '', t, flags=re.IGNORECASE)
        t = t.split('|')[0].strip()
        return re.sub(r'\s+', ' ', t)

    def _norm_title(self, title):
        try:
            return re.sub(r'\s+', ' ', cleantitle.normalize(str(title or '')).lower()).strip()
        except Exception:
            return re.sub(r'\s+', ' ', str(title or '').lower()).strip()

    def _label_with_year(self, item):
        label = item.get('title') or ''
        date = item.get('year') or ''
        if date and str(date).isdigit() and str(date) not in label:
            label += f' ({date})'
        return label

    def _calculate_similarity(self, tvshow_title, search_title):
        search_title = self._norm_title(search_title)
        primary_words = self._norm_title(str(tvshow_title or '').strip())
        try:
            ratio_primary = utils.calculate_similarity_ratio(search_title, primary_words)
            levenshtein_primary = utils.calculate_levenshtein_distance(search_title, primary_words)
        except Exception:
            ratio_primary = 0
            levenshtein_primary = 999
        return primary_words, ratio_primary, levenshtein_primary

    def _safe_int(self, v, default=0):
        try:
            return int(v)
        except Exception:
            return default

    def strip_prefix(self, s):
        return re.sub(r'(?i)^\s*(gwiezdne\s+wojny|star\s+wars)\s*[:\-–—]?\s*', '', str(s or '')).strip()
