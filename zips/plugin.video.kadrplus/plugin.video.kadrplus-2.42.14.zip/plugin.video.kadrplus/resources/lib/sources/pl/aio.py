# -*- coding: utf-8 -*-
"""
FanFilm – AIOStreams
Copyright (C) 2026 :)

"""

import re
# import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from ptw.libraries import control
from ptw.libraries import source_utils
from ptw.debug import fflog, fflog_exc


_QUALITY_MAP = [
    ("2160", "4K"), ("4k", "4K"), ("uhd", "4K"),
    ("1080", "1080p"),
    ("720",  "720p"),
    ("480",  "SD"), ("360", "SD"), ("sd", "SD")
]


def _parse_quality(title: str) -> str:
    t = title.lower()
    for keyword, qual in _QUALITY_MAP:
        if keyword in t:
            return qual
    return "HD"



class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl", "en"]
        self.session = None


    def init(self):
        try:
            instance_id = int(control.setting("aio.instance") or "0")
        except ValueError:
            instance_id = 0

        base_url      = (control.setting(f"aio.aio_url.{instance_id}") or "").strip().rstrip("/")
        self.username = (control.setting(f"aio.username.{instance_id}") or "").strip()
        self.password = (control.setting(f"aio.password.{instance_id}") or "").strip()

        if not base_url:
            # base_url = _PUBLIC_INSTANCES[0]
            fflog(f'brak wpisanego adresu URL w Ustawieniach',1,1)
            pass

        fflog(f"aiostreams: instance={instance_id} url={base_url}", 1, 1)
        self.search_link = f"{base_url}/api/v1/search"
        import requests
        self.session = requests.Session()


    def _get_session(self):
        if not self.session:
            # self.session = requests.Session()
            self.init()
        return self.session


    def _search(self, media_type: str, media_id: str) -> list:
        """
        Wywołuje /api/v1/search i zwraca listę wyników (SearchResult[]).
        media_type: 'movie' lub 'series'
        media_id:   imdb (film) lub imdb:season:episode (serial)
        """
        try:
            sess = self._get_session()
            params = {"type": media_type, "id": media_id}
            auth = (self.username, self.password) if self.username else None
            timeout = int(control.setting("scrapers.timeout.1"))

            fflog(f"aiostreams: GET {self.search_link} {params}", 0, 1)
            fflog(f"aiostreams: GET {params}", 1, 1)
            resp = sess.get(
                self.search_link,
                params=params,
                auth=auth,
                timeout=timeout,
                verify=False,
            )
            if not resp.ok:
                fflog(f"aiostreams: HTTP {resp.status_code}", 1, 1)
                if not control.window.getProperty("blocked_sources_extend") == 'break':
                    control.infoDialog(f"błąd HTTP {resp.status_code}", 'AIOStreams', "ERROR")
                return []

            data = resp.json()
            if not data.get("success"):
                err = data.get("error") or {}
                fflog(f"aiostreams: błąd API: {err.get('message')}", 1, 1)
                if not control.window.getProperty("blocked_sources_extend") == 'break':
                    control.infoDialog(f"{err.get('message')}", 'AIOStreams', "ERROR")
                return []

            results = (data.get("data") or {}).get("results") or []
            errors  = (data.get("data") or {}).get("errors") or []
            if errors:
                fflog(f"aiostreams: błędy źródeł: {errors}", 1, 1)

            fflog(f"aiostreams: znaleziono {len(results)} wyników", 1, 1)
            if results:
                # fflog(f"aiostreams: przykładowy wynik: {results[0]}", 1, 1)
                pass
            return results
        except Exception:
            fflog_exc(1)
            if not control.window.getProperty("blocked_sources_extend") == 'break':
                control.infoDialog("wystąpił jakiś błąd - sprawdź log", 'AIOStreams', "ERROR")
            return []


    def _map_resolution_to_quality(self, resolution: str) -> str:
        """Mapuje pole resolution z API do standardowych klas jakości."""
        if not resolution:
            return "HD"
        
        res_str = str(resolution).lower().replace("p", "").strip()
        
        try:
            res_int = int(''.join(filter(str.isdigit, res_str)))
            
            if res_int >= 2160:
                return "4K"
            elif res_int >= 1440:
                return "2K"
            elif res_int >= 1080:
                return "1080p"
            elif res_int >= 720:
                return "720p"
            else:
                return "SD"
        except (ValueError, AttributeError):
            pass
        
        for keyword, qual in _QUALITY_MAP:
            if keyword in res_str:
                return qual
        
        return "SD"


    def _results_to_sources(self, results: list, host_dict: list) -> list:
        """Konwertuje SearchResult[] na listę źródeł FanFilm."""
        import json

        sources = []

        clib = control.setting("aio.library.color.identify")
        clib = int(clib) if clib else 10
        if clib < 10:
            color = source_utils.getPremColor(str(clib))
        else:
            color = None

        trash_not_cached = control.setting("aio.trash_not_cached") == "true"
        usenet_not_trash = control.setting("aio.usenet_not_trash") == "true"
        display_addon_indexer = control.setting("aio.display_addon_indexer") == "true"
        filename_in_2nd_line = control.setting("sources.filename_in_2nd_line") == "true"
        extrainfo = control.setting("sources.extrainfo") == "true"
        max_sources = int(control.setting("aio.max_sources" or 0))

        czy_polski = source_utils.czy_polski()

        re_not_allowed_phrase = re.compile(r"\b(exe|zip|iso|mp3|rar|epub|wav|flac|trailer|tlr|pxg|soundtrack|ep|\d*kbps|sample)\b", flags=re.I)

        _service_map = {
             "realdebrid":  "RD",
             "alldebrid":   "AD",
             "premiumize":  "PM",
             "debridlink":  "DL",
             "torbox":      "TB",
             "easydebrid":  "ED",
             "offcloud":    "OC",
             "pikpak":      "PP",
            }

        for item in results:

            if max_sources and len(sources) >= max_sources:
                fflog(f'przerwanie z powodu osiągnięcia {max_sources=}',1,1)
                break

            try:
                # fflog(f'item = {json.dumps(item, indent=2)}',1,1)

                service = item.get("service") or ""

                item_type = item.get("type", "").lower()
                # item_type = "p2p"  # na test tylko
                if "p2p" in item_type:
                    # fflog(f'p2p item = {json.dumps(item, indent=2)}',1,1)
                    if not service:  # dopuszczamy p2p jeśli idzie przez debrid (np. TorBox)
                        continue
                    else:  # nie przetestowane jeszcze
                        pass
                if "info" in item_type:
                    continue
                    pass

                url = item.get("url") or item.get("externalUrl") or ""
                if not url:
                    continue
        
                pf = item.get("parsedFile") or {}
                # fflog(f'pf = {json.dumps(pf, indent=2)}',1,1)
                # if not pf.get("extension"):
                    # fflog(f'brak rozszerzenia item = {json.dumps(item, indent=2)}',1,1)
                    # continue
                    # pass

                filename = item.get("filename") or pf.get("title") or ""
                # if ".XVID" in filename:
                    # fflog(f'item = {json.dumps(item, indent=2)}',1,1)
                # poniższe może się przydać przy rozpoznawaniu dodatkowych danych
                # extension = pf.get("extension") or pf.get("container") or ""
                # if filename and extension and not filename.endswith(extension):
                    # filename += f".{extension}"
                    # pass

                if re_not_allowed_phrase.search( filename.replace("_", " ") ):
                    # fflog(f'odrzucam {filename=}',1,1)
                    continue

                resolution = pf.get("resolution") or ""  # zwraca tylko pionową
                quality = self._map_resolution_to_quality(resolution)
                # fflog(f'{resolution=}  {quality=}  |  {item.get("filename") or pf.get("title")}',1,1)
                parsed_quality = ""
                if not resolution:
                    parsed_quality = _parse_quality(item.get("filename") or "")
                    if parsed_quality != "HD":
                        quality = parsed_quality
                    else:
                        quality = "SD"
                # fflog(f'{resolution=}  {quality=}  {parsed_quality=}  |  {item.get("filename") or pf.get("title")}',1,1)

                _, info = source_utils.get_lang_by_type(filename)
                # język na podstawie danych z jsona
                langs = pf.get("languages") or []
                # if langs:
                    # fflog(f'{len(langs)=}  {langs=}   |   {filename=}',1,1)
                langs_lower = [l.lower() for l in langs]
                is_pl = any(l in ("pl", "pol", "polish") for l in langs_lower)
                # lang = "pl" if is_pl else "en"
                lang = "pl" if is_pl else "mul" if len(langs) == 1 and "Multi" in langs else "en"
                if lang != "pl" and czy_polski:
                    lang = "pl"

                info_parts = []

                info_parts.append(info)

                cached  = item.get("cached") or False

                debrid_tag = ""
                short = ""
                if service:
                    short = _service_map.get(service.lower().replace("-", "").replace("_", ""), service[:2].upper())
                    if item_type == "usenet":
                        # short = f"{short}-NZB"
                        short = f"{short}-[COLOR FF00AAFF]usenet[/COLOR]"
                    elif item_type == "p2p":
                        short = f"{short}-[COLOR red]p2p[/COLOR]"
                    debrid_tag = f"[I]{short} cached [/I]" if cached else f"{short}" + (" (not cached)" if trash_not_cached else "")
                    debrid_tag = f"[COLOR {color}]{debrid_tag}[/COLOR]" if color and cached else debrid_tag
                elif item_type == "usenet":
                    # debrid_tag = "[COLOR FF00AAFF]NZB[/COLOR]"
                    debrid_tag = "[COLOR FF00AAFF]usenet[/COLOR]"
                elif item_type == "p2p":
                    debrid_tag = "[COLOR red]p2p[/COLOR]"

                if not cached and 1:
                    # fflog(f'item = {json.dumps(item, indent=2)}',1,1)
                    if seeders := item.get("seeders"):
                        debrid_tag += f" [s:{seeders}]"
                    if age := item.get("age"):
                        debrid_tag += f" [a:-{age}]"
                        pass

                # if debrid_tag:
                    # info2 = f"{debrid_tag}  {filename}".strip()
                # else:
                    # info2 = filename.strip()
                info2 = debrid_tag

                # bitrate = item.get("bitrate")
                # if bitrate:
                    # bitrate_mb = bitrate / 1_000_000
                    # bitrate = f"~{bitrate_mb:.0f}".rstrip('0').rstrip('.') + "Mbps"
                    # if not "~M" in bitrate:
                        # info_parts.append(bitrate)

                size = item.get("size") or 0
                if size:
                    if size < 1024 * 1024 * 50:
                        continue
                    try:
                        size_gb = size / (1024 ** 3)
                        if int(size_gb):
                            # size = f"{size_gb:.2f} GB"
                            size = f"{size_gb:.2f}".rstrip('0').rstrip('.') + " GB"
                        else:
                            size_mb = size / (1024 ** 2)
                            # size = f"{size_mb:.2f} MB"
                            size = f"{size_mb:.2f}".rstrip('0').rstrip('.') + " MB"
                            # size = f"{f'{size_mb:.2f}'.rstrip('0').rstrip('.') } MB")
                        info_parts.append(size)
                    except Exception:
                        pass
                else:
                    # fflog(f'item = {json.dumps(item, indent=2)}',1,1)
                    continue  # czy słusznie?
                    pass

                info_parts = list(filter(None, info_parts))
                info = " | ".join(info_parts)
                # fflog(f'{info=}',1,1)

                if display_addon_indexer or not extrainfo:
                    addon    = item.get("addon") or ""
                    indexer  = item.get("indexer") or ""
                    host     = (addon or indexer or short or "").replace(" ", "_").replace("|", "_")
                else:
                    if filename_in_2nd_line:
                        host = ""
                    else:
                        host = short

                info2 = info2.replace(host, "").strip()

                sources.append({
                    "source":     host,
                    "quality":    quality,
                    "language":   lang,
                    "url":        url,
                    "info":       info,
                    "info2":      info2,
                    "size":       size,
                    "filename":   filename,
                    "direct":     True,
                    "debridonly": False,
                    "cached": cached,
                    "trash": "not cached" if not cached and trash_not_cached and (not usenet_not_trash if item_type == "usenet" else 1) else None,
                    "on_account": item.get("library") or False,  # tylko nie wiem, co to daje
                })

                #fflog(f"aiostreams: dodane źródło - {host=} | {quality=} | {lang=} | {info=} | {filename=}", 1, 1)
            except Exception:
                fflog_exc(1)
                continue

        return sources


    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        tmdb = kwargs.get("tmdb", "")
        return {"imdb": imdb, "tmdb": tmdb, "type": "movie"}


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        tmdb = kwargs.get("tmdb", "")
        return {"imdb": imdb, "tmdb": tmdb, "type": "series"}


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        if not url:
            return None
        url["season"]  = season
        url["episode"] = episode
        return url


    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            fflog(f'{url=}',1,1)
            if not url:
                return sources

            media_type = url.get("type", "movie")
            tmdb       = url.get("tmdb", "")
            imdb       = url.get("imdb", "")
            imdb = imdb if imdb not in ["None", "0", "-"] else None
            season     = url.get("season")
            episode    = url.get("episode")

            if not imdb and not tmdb:
                return sources

            if not imdb and tmdb:
                imdb = "tmdb:"+tmdb

            if media_type == "series" and season is not None:
                media_id = f"{imdb}:{season}:{episode}"
            else:
                media_id = imdb

            results = self._search(media_type, media_id)

            if not results:
                return sources

            sources = self._results_to_sources(results, hostDict + hostprDict)
            fflog(f"aiostreams: przekazano źródeł: {len(sources)}", 1, 1)
        except Exception:
            fflog_exc(1)
        return sources


    def resolve(self, url):
        fflog(f'{url=}',0,1)
        return url
