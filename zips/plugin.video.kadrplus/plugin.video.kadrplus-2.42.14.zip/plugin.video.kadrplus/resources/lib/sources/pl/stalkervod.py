import random

import re

from urllib.parse import urlsplit, quote, parse_qsl

from ptw.libraries import source_utils
from ptw.libraries import control, cache

from ptw.debug import fflog, fflog_exc


# import requests
# import urllib3
# urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import json

import base64


class source:

    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.monitor = None
        self.stclient = None
        self.new_mac  = None


    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        # fflog(f'{title=}  {localtitle=}  {year=}  {kwargs=}  {aliases=}',1,1)
        tmdb = kwargs.get("tmdb", "")
        return self.search(title, localtitle, year, tmdb, aliases=aliases)


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # fflog(f'{tvshowtitle=}  {localtvshowtitle=}  {year=}  {kwargs=}',1,1)
        # return self.search(tvshowtitle, localtvshowtitle, year, is_tvshow=True, tmdb=tmdb)  # tu się to nie sprawdzi
        return (tvshowtitle, localtvshowtitle, aliases), year


    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        # fflog(f'{url=}  {season=}  {episode=}  {kwargs=}',1,1)
        if not url:
            return None
        tvshowtitle = url[0][0]
        localtvshowtitle = url[0][1]
        aliases = url[0][2]
        year = url[1]
        tmdb = kwargs.get("tmdb", "")
        absolute_episode = kwargs.get("absolute_episode")
        return self.search(tvshowtitle, localtvshowtitle, year, tmdb, int(season), int(episode), absolute_episode, aliases)


    def search(self, title, localtitle, year, tmdb='', season=None, episode=None, absolute_episode=0, aliases=None):
        fflog(f'{title=}  {localtitle=}  {year=}  {tmdb=}  {season=}  {episode=}  {absolute_episode}  {aliases=}',1,1)
        try:

            if not self.monitor:
                self.monitor = control.monitor

            if aliases is None:
                aliases = []

            originalname = [a for a in aliases if "originalname" in a]
            originalname = originalname[0]["originalname"] if originalname else ""
            # originalname = "" if source_utils.czy_litery_krzaczki(originalname) else originalname  # co z rosyjskimi tytułami?

            original_first = True  # ewentualnie dorobić przełącznik w Ustawieniach
            if original_first:
                titles = [originalname, localtitle, title]
            else:
                titles = [localtitle, title, originalname]

            if 1:
                language_order = ["pl", "us", "en", "uk", "gb", "au", "it", "fr", "de" ]  # aby dać niektóre na początek - to są troche inne kody niż w Trexie
                language_order = {key: i for i, key in enumerate(language_order)}
                aliases = sorted(aliases, key=lambda d:(language_order.get(d["country"], 99),) )  # bo nie zawsze pomaga, czasami jp romaji jest najlepsze
                aliases1 = [
                    (a.get("title") or a.get("originalname") or "")
                    + " ("
                    + a.get("country", "")
                    + ")"
                    for a in aliases
                ]
                aliases2 = [a.rpartition(" (")[0] for a in aliases1]  # country out
                aliases2 = [a.replace(year, "").replace("()", "").rstrip() for a in aliases2]  # year out
                # aliases2 = [a for a in aliases2 if not source_utils.czy_litery_krzaczki(a)]  # krzaczki out
                aliases2 = [alias for i, alias in enumerate(aliases2) if alias.lower() not in [x.lower() for x in aliases2[:i]]]  # kolejne duplikaty są usuwane niezależnie od wielkości liter
                # fflog(f'{aliases2=}')
                titles += aliases2

            # titles = [t.lower() for t in titles]  # ta wyszukiwarka zwraca na to uwagę
            titles = list(filter(None, titles))  # usunięcie pustych
            titles = list(dict.fromkeys(titles))  # pozbycie się duplikatów
            fflog(f'{titles=}',1,1)
            # titles = ['powrót króla', 'POWRÓT KRÓLA']  # test

            if control.setting('stalkervod.not_check_languages') != 'true':
                languages = control.setting('stalkervod.languages').strip()
                if 1:
                    # import re
                    languages = re.split(" *[ ,|] *", languages)
                else:
                    languages = languages.replace("|", ",").rstrip(',')
                    languages = languages.split(',')  # string into list
                    languages = [l.strip().replace('"', '') for l in languages]  # clean a little
                languages = [l.upper() for l in languages]
                languages = list(filter(None, languages))  # eliminate empty
                languages = list(dict.fromkeys(languages))  # eliminate duplicates

                langs_target = control.setting('stalkervod.languages.target')
                fflog(f'{langs_target=}',1,1)
                if not episode and int(langs_target) not in [0, 1]:
                    languages = []
                if episode and int(langs_target) not in [0, 2]:
                    languages = []

                if 'PL' not in languages:
                    languages.insert(0, 'PL')  # a może ktoś nie chce po polsku?
                    # languages.append('PL')
                if 'POL' not in languages:
                    languages.insert(1, 'POL')  # a może ktoś nie chce po polsku?
                    # languages.append('POL')

                if 'MULTI' not in languages:
                    languages.append('MULTI')  # dyskusyjne
                    # languages.insert(2, 'MULTI')  # dyskusyjne
                if 'MUL' not in languages:
                    languages.append('MUL')  # dyskusyjne
                    # languages.insert(3, 'MUL')  # dyskusyjne

                fflog(f'{languages=}',1,1)

                language_order = {key: i for i, key in enumerate(languages)}
                # fflog(f'{language_order=}',1,1)
            else:
                languages = []

                language_order = ["PL", "POL", "MUL", "MULTI", "US", "EN", "ENG", ""]
                language_order = {key: i for i, key in enumerate(language_order)}

            self.stclient = stclient = StalkerClient()

            categories = {}
            if episode:
                params={'type': 'series', 'action': 'get_categories'}
            else:
                params={'type': 'vod', 'action': 'get_categories'}
            categories = self.stclient._call(params)
            fflog(f'{len(categories)=}',1,1)
            if not categories:
                fflog(f'nie otrzymano danych z serwera {categories=}',1,1)
                categories = []
            categories = {item['id']: item['title'] for item in categories}
            # fflog(f'{len(categories)=}',1,1)
            control.sleep(2000)  # przydaje się

            niechciane_kategorie = ['kabarety', 'silownia', 'siłownia', 'fitness', 'dieta', 'zdrowie',
                                'gry', 'komputer', 'przepisy', 'poradniki', 'gadżety', 'zapowiedzi',
                                'sport', 'karaoke', 'przewodnik', 'mecz', 'nba', 'piłka', 'eurosport', 'hokej', 'karate', 'teledyski',
                                'nauka jezykow', 'nauka języków', 'podcast', 'audiobooki',
                                'xxx', 'for adults', 'ppv',
                                ]

            videos = []  # filmy albo seriale
            filtered = []
            trash = None
            # len_titles = len(titles)
            searched_titles = []
            counter = 0

            # for search_title in titles:
            for idx, search_title in enumerate(titles):
                # if not search_title:
                    # continue
                    # pass

                if (
                       # ":" in search_title
                    # or "." in search_title
                    # or "-" in search_title
                    len(parts := [c.strip() for c in re.split(r"-|:|\.", search_title)]) > 1
                    ):
                    if 1:
                        # tylko czy tak jest zawsze? Zaobserwowałem, że to daje źródła w PL
                        # search_title = search_title.split(":")[0].strip()  # nie działa dla Mission Impossible
                        # search_title = search_title.replace(":", " -")
                        # parts = [c.strip() for c in search_title.split(':')]
                        # parts = [c.strip() for c in re.split(r"-|:|\.", search_title)]
                        search_title = max(parts, key=len)
                        fflog(f'dłuższy {search_title=}',1,1)
                        if search_title.lower() in ['film', 'movie']:  # dać więcej wyjątków
                            parts.remove(search_title)
                            search_title = max(parts, key=len)
                            fflog(f'dłuższy wyjątek 1 {search_title=}',1,1)
                        if (
                               search_title.lower() in [t.lower() for t in searched_titles]
                            or search_title.lower() in [t.lower() for t in titles]
                        ):
                            parts.remove(search_title)
                            search_title = max(parts, key=len)
                            fflog(f'dłuższy wyjątek 2 {search_title=}',1,1)
                    else:
                        pass
                        # by afrikolos
                        # # truncated = search_title.split(":")[0].strip()
                        # # parts = [c.strip() for c in search_title.split(':')]
                        # parts = [c.strip() for c in re.split(r"-|:|\.", search_title)]
                        # truncated = max(parts, key=len)
                        # if truncated.lower() in ['film', 'movie']:  # dać więcej wyjątków
                            # parts.remove(truncated)
                            # truncated = max(parts, key=len)
                        # insert_pos = idx
                        # if len(truncated) >= 3 and truncated not in titles and truncated not in searched_titles:
                            # titles.insert(insert_pos, truncated)
                        # search_title_with_space = re.sub(r'\s*:\s*', ' ', search_title).strip()
                        # # insert_pos = idx + 1
                        # insert_pos += 1
                        # if search_title_with_space not in titles and search_title_with_space not in searched_titles:
                            # titles.insert(insert_pos, search_title_with_space)
                            # insert_pos += 1
                        # if ' - ' in search_title:
                            # intermediate = search_title.split(' - ')[0].strip()
                            # if len(intermediate) >= 3 and intermediate not in titles and intermediate not in searched_titles:
                                # titles.insert(insert_pos, intermediate)
                                # insert_pos += 1

                if "." in search_title:  # teraz to już raczej się nie wykona, bo . jest usuwana wcześniej (przy podziale)
                    search_title = search_title.split(".")[0].strip()

                if search_title.startswith('The '):
                    search_title = search_title.replace('The ', '')
                    pass

                if search_title in searched_titles:
                    fflog(f'fraza {search_title} była już wyszukiwana')
                    continue

                counter += 1
                fflog(f'{counter=}',0,1)
                if counter > 5:
                    fflog(f'przerywam dalsze szukanie, bo {counter=}',1,1)
                    break

                searched_titles += [search_title]

                fflog(f'{search_title=}',1,1)

                if self.monitor.abortRequested():
                    fflog(f'przerwanie wyszukiwania (z powodu sygnału zamknięcia Kodi)')
                    return
                # wykrywanie sygnału przerwania wyszukiwania źródeł
                if control.window.getProperty("blocked_sources_extend") == 'break':
                    fflog(f'przerwanie dalszego wyszukiwania')
                    break

                control.sleep(200)  # nie wiem, czy to pomaga

                def search_videos(search_title, all_filtered):
                    videos = []
                    filtered = []
                    nonlocal trash

                    videos += stclient.get_videos(
                        category_id="*",
                        search=search_title,
                        media_type='series' if episode is not None else 'vod',
                        max_pages=4,
                    )

                    fflog(f'{len(videos)=}',1,1)
                    # fflog(f'{len(videos)=}  {json.dumps(videos, indent=2)}',1,1)
                    # fflog(f'{videos=}',1,1)

                    videos = [v for v in videos if v["id"] not in [x["id"] for x in all_filtered]]  # usuwanie kolejnych duplikatów
                    fflog(f'{len(videos)=}',1,1)

                    videos = [v for v in videos if all(kw not in (category_name := categories.get(v.get("category_id"), "")).lower() for kw in niechciane_kategorie)]
                    fflog(f'{len(videos)=}',1,1)

                    if videos:
                        
                        yinst = re.search(r'\b\d{4}\b', search_title)

                        if tmdb:  # chyba zawsze powinien być w ten identyfikator w FanFilm
                            filtered = [
                                v for v in videos
                                if ( (tmdb_id := str(v.get('tmdb_id', ''))) == tmdb
                                    or ( (not tmdb_id or tmdb_id == 'N/A') and re.search(rf'\b{re.escape(search_title)}\b', v["name"], flags=re.I) )  # taka bardzo prosta weryfikacja
                                   )
                            ]
                        else:
                            filtered = [
                                        v for v in videos
                                        if re.search(rf'\b{re.escape(search_title)}\b', v["name"], flags=re.I)  # taka bardzo prosta weryfikacja
                                       ]
                        # fflog(f'tmdb {len(filtered)=}',1,1)
                        if 1:  # chyba, że nie było problemów z tmdb oraz tmdb_id (ale tego nie da się sprawdzić bez przelecenia po wszystkich elementach)

                            if year:  # w FanFilm powinien być dostępny
                                filtered = [
                                    v for v in filtered
                                    if ( (tmdb and str(v.get('tmdb_id', '')) == tmdb)
                                        or ((yr := v.get('year', '')).startswith(year)
                                             or re.search(rf'\b{year}\b', v["name"])
                                             # or re.search(rf'\b{int(year)-1}\b', v["name"])  # ?
                                             or ( (not yr or yr == "N/A") 
                                                and (
                                                     (fyint := re.search(r'\b\d{4}\b', v["name"])) and fyint[0] == year and not yinst 
                                                     or not fyint
                                                    )
                                                )
                                            )
                                       )
                                ]
                                for f in filtered:
                                    tmdb_id = f.get('tmdb_id')
                                    yr = f.get('year', '')
                                    if (not yr or yr == "N/A") and (not tmdb_id or tmdb_id == "N/A"):
                                        f["name"] = "*" + f["name"]

                            if episode is not None:
                                filtered = [
                                    v for v in filtered
                                    if (1
                                        and v.get('has_files')
                                        # and v.get('is_series')
                                       )
                                ]
                        fflog(f'1) {len(filtered)=}',1,1)
                        # fflog(f'1 {len(filtered)=} {json.dumps(filtered, indent=2)}',1,1)

                        if filtered:
                            # lang_re = re.compile(r'\b([A-Z]{2}-[A-Z]{2}|[A-Z]{2,4}|MULTI)\b')
                            # lang_re = re.compile(r'\b(PO?L|MUL(TI)?|US|ENG?|[A-Z]{2}-[A-Z]{2}|[A-Z]{2,4})\b')
                            lang_re  = re.compile(r'\b(PO?L|MUL(TI)?|US|ENG?|[A-Z]{2}-[A-Z]{2})\b')
                            lang_re2 = re.compile(r'\b([A-Z]{2,4})\b')
                            # category = categories.get(v.get('category_id') or 0) or ''
                            if control.setting('stalkervod.not_check_languages') != 'true':
                                fflog('filtruje języki',1,1)
                                # if 1:  # debug
                                    # for v in filtered:
                                        # f = source_utils.get_lang_by_type(f"{v['name']} {categories.get(v.get('category_id') or 0) or ''}  {v.get('description', '')}")
                                        # fflog(f"{f=}   {v['name']} {categories.get(v.get('category_id') or 0) or ''}  {v.get('description', '')}",1,1)
                                filtered2 = [
                                    v for v in filtered
                                    if (1
                                        # and 'PL' in v.get('name', '')
                                        and(
                                            any(
                                                re.search(rf'\b{x}\b', v['name'] + ' ' + (categories.get(v.get('category_id') or 0) or ''))
                                                for x in languages
                                               )
                                            or source_utils.get_lang_by_type(f"{v['name']}  {categories.get(v.get('category_id') or 0) or ''}  {v.get('description', '')}")[0]
                                            )
                                       )
                                ]
                                fflog(f'2) {len(filtered2)=}',1,1)
                                if filtered2:
                                    # oznaczenie językami
                                    for f in filtered2:  # dla każdego tytułu
                                        combined_name = f['name'] + ' ' + (categories.get(f.get('category_id') or 0) or '')
                                        for i, x in enumerate(languages):  # sprawdź oddzielnie każdy język z tabeli zadanych języków
                                            # fflog(f'szukam języka {x=}',1,1)
                                            if re.search(rf'\b{x}\b', combined_name):
                                                # f.update(dict(lang=x))  # czasami są 2 kody języków (np. FR Heweliusz (PL) i to miesza
                                                m = lang_re.search(combined_name)  # znajdzie PL (a ten jest ważniejszy)
                                                m = lang_re2.search(combined_name) if not m else m  # znajdzie FR
                                                if m:
                                                    f.update(dict(lang=m[1]))
                                                    if x != m[1]:
                                                        i += 50
                                                    f.update(dict(lang_priority=i))
                                                    break  # następny tytuł (nie kod języka)
                                                else:
                                                    # fflog(f'nie wykryto szukanego języka {x=} w {combined_name=}',1,1)
                                                    pass
                                            elif dl := source_utils.get_lang_by_type(f"{combined_name}  {f.get('description', '')}")[0].upper():
                                                # fflog(f'{dl=}  (powinien być zwrócony język "PL" albo "MULTI")')
                                                # f.update(dict(lang="PL"))
                                                # f.update(dict(lang_priority=1))
                                                f.update(dict(lang=dl))
                                                f.update(dict(lang_priority=language_order.get(dl, 99) ))
                                                break
                                                pass
                                            else:
                                                # f.update(dict(lang=None))  # to chyba nie potrzebne
                                                # fflog(f'nie wykryto szukanego języka {x=} w {combined_name=}',1,1)
                                                pass
                                    filtered = filtered2
                                    # fflog(f'{len(filtered)=}  {json.dumps(filtered, indent=2)}',1,1)
                                    trash = False
                                else:
                                    # a może tylko angielskie zostawiać?
                                    [v.update({"trash": "language"}) for v in filtered]
                                    # fflog(f'{len(filtered)=}  {json.dumps(filtered, indent=2)}',1,1)
                                    trash = True
                            else:
                                fflog('nie filtruje języków',1,1)
                                # oznaczenie językami
                                for f in filtered:
                                    combined_name = f['name'] + ' ' + (categories.get(f.get('category_id') or 0) or '')
                                    m = lang_re.search(combined_name)
                                    m = lang_re2.search(combined_name) if not m else m
                                    if m:
                                        f.update(dict(lang=m[1]))
                                        f.update(dict(lang_priority=language_order.get(m[1], 99) ))
                                # fflog(f'{len(filtered)=}  {json.dumps(filtered, indent=2)}',1,1)

                        filtered = sorted(
                            filtered,
                            key=lambda x: (
                                            x.get('lang_priority', 99),
                                            '4K' in x['name'] + ' ' + (categories.get(x.get('category_id') or 0) or ''),
                                            'UHD' in x['name'] + ' ' + (categories.get(x.get('category_id') or 0) or ''),
                                            'ULTRA' in x['name'] + ' ' + (categories.get(x.get('category_id') or 0) or ''),
                                           ),
                            reverse=False
                        )

                        # for f in filtered:
                            # if not f.get('category'):
                                # f.update({'category': (categories.get(f.get('category_id') or 0) or '')})

                        # fflog(f'3 {len(filtered)=} {json.dumps(filtered, indent=2)}',1,1)

                        # może tylko na końcu warto
                        if filtered and (control.setting('stalkervod.only_first_avail_lang') == 'true' or episode):
                            lang = filtered[0].get('lang')
                            # fflog(f'tylko {lang=}',1,1)
                            if lang:
                                fflog(f'wybieram tylko dla {lang=}',1,1)
                                filtered = [f for f in filtered if f.get('lang') == lang]
                            else:
                                if episode:
                                    fflog(f'nie ma określonego języka, ale dla seriali tylko 2 pierwsze z listy',1,1)
                                    # filtered = [filtered[0]]  # tylko 1
                                    filtered = filtered[0:2]  # tylko 2 pierwsze (na wypadek jakby było 4k i SD
                                else:
                                    fflog(f'daje wszystkie, bo nie ma określonego języka',1,1)
                            # fflog(f'3l {len(filtered)=} {json.dumps(filtered, indent=2)}',1,1)
                            # fflog(f'3l {len(filtered)=}',1,1)

                    return filtered

                filtered += search_videos(search_title, filtered)

                if 1:
                    if re.search(r"[ąęłśżźćńó]", search_title, flags=re.I):
                        if search_title.upper() not in searched_titles:
                            searched_titles += [search_title.upper()]
                            fflog(f'search_title={search_title.upper()}',1,1)
                            filtered += search_videos(search_title.upper(), filtered)

                filtered = sorted(
                    filtered,
                    key=lambda x: (
                                    x.get('lang_priority', 99),
                                    '4K' in x['name'] + ' ' + (categories.get(x.get('category_id') or 0) or ''),
                                    'UHD' in x['name'] + ' ' + (categories.get(x.get('category_id') or 0) or ''),
                                    'ULTRA' in x['name'] + ' ' + (categories.get(x.get('category_id') or 0) or ''),
                                    # x.get('added', ''),  # chyba niepotrzebne
                                   ),
                    reverse=False
                )

                # fflog(f'{len(filtered)=} {trash=}',1,1)
                if filtered and not trash and 1:
                    if not original_first or counter > 2:
                        fflog(f'nie szukam dla kolejnego aliasu',1,1)
                        break  # przerwanie szukanie
                        pass


                # if 0:  # na górze włączyłem
                    # if (not filtered or trash):  # and len_titles == len(titles):  # and search_title == titles[-1]:  # ostatni
                        # # fflog(f'{len_titles=}  {len(titles)=}',1,1)
                        # # fflog(f'nic nie znaleziono, a to był ostatni tytuł do wyszukiwarki',1,1)
                        # if ":" in search_title:
                            # search_title = search_title.split(":")[0].strip()
                            # # search_title = search_title.replace(":", " -")
                            # # search_title = search_title.replace(": ", " - ")
                            # titles.append(search_title)
                            # fflog(f'jeszcze dodano do kolejki {search_title=}',1,1)
                            # # fflog(f'{len_titles=}  {len(titles)=}',1,1)
                            # control.sleep(500)  # nie wiem, czy to pomaga
                            # pass


            if filtered and (control.setting('stalkervod.only_first_avail_lang') == 'true' or episode):
                lang = filtered[0].get('lang')
                # fflog(f'tylko {lang=}',1,1)
                if lang:
                    fflog(f'wybieram tylko dla {lang=}',1,1)
                    filtered = [f for f in filtered if f.get('lang') == lang]
                else:
                    if episode:
                        fflog(f'nie ma określonego języka, ale dla seriali tylko 2 pierwsze z listy',1,1)
                        # filtered = [filtered[0]]  # tylko 1
                        filtered = filtered[0:2]  # tylko 2 pierwsze (na wypadek jakby było 4k i SD
                    else:
                        fflog(f'daje wszystkie, bo nie ma określonego języka',1,1)
                # fflog(f'3l {len(filtered)=} {json.dumps(filtered, indent=2)}',1,1)
                # fflog(f'3l {len(filtered)=}',1,1)


            if episode is not None:
                if filtered:  # powinien zostać się tylko 1 - a co, jak będzie więcej, np. wersje FullHD i 4K, albo PL i EN?
                    # fflog(f'3s {len(filtered)=} {json.dumps(filtered, indent=2)}',1,1)
                    fflog(f'3s {len(filtered)=}',1,1)
                    def find_episodes(filtered):
                        nonlocal season, episode
                        fflog(f"teraz szukam sezonów  (id={filtered[0]['id']})",1,1)
                        control.sleep(4000)  # nie wiem, czy to pomaga
                        seasons = stclient.get_all_episodes( filtered[0]['id'] )
                        if not seasons:
                            fflog(f'znaleziono sezonów: {len(seasons)}',1,1)
                            fflog(f"ponawiam szukanie sezonów",1,1)
                            control.sleep(4000)  # nie wiem, czy to pomaga
                            seasons = stclient.get_all_episodes( filtered[0]['id'] )
                        fflog(f'znaleziono sezonów: {len(seasons)}',1,1)
                        # fflog(f'{len(filtered)=}  {json.dumps(seasons, indent=2)}',1,1)
                        # wybranie konkretnego sezonu
                        filtered = [
                            v for v in seasons
                            if (1
                                and v.get('id', '').endswith(f":{season}")
                                and episode in v.get('series', [])  # sprawdzenie, czy taki odcinek istnieje - może rozbić na oddzielne filtrowanie?
                               )
                        ]
                        fflog(f'4 {len(filtered)=}',1,1)
                        # fflog(f'4 {len(filtered)=}  {json.dumps(filtered, indent=2)}',1,1)
                        if not filtered:
                            fflog(f'nie ma takiego sezonu ani odcinka',1,1)
                            # sprawdzić jeszcze dla absolute_episode
                            if season > 1 and len(seasons) == 1 and 1:  # nie przetestowane jeszcze
                                season = 1
                                episode = absolute_episode
                                fflog(f'próba znalezienia odcinka korzystając z numeracji absolutnej {absolute_episode=}',1,1)
                                # i ponowna filtracja
                                filtered = [
                                    v for v in seasons
                                    if (1
                                        and v.get('id', '').endswith(f":{season}")
                                        and episode in v.get('series', [])  # sprawdzenie, czy taki odcinek istnieje - może rozbić na oddzielne filtrowanie?
                                       )
                                ]
                                fflog(f'4a {len(filtered)=}',1,1)
                                # fflog(f'4a {len(filtered)=}  {json.dumps(filtered, indent=2)}',1,1)
                                if not filtered:
                                    fflog(f'nie ma takiego sezonu ani odcinka',1,1)
                        return filtered

                    # filtered = find_episodes(filtered)  # jeden
                    ftemp = []
                    for f in filtered[:2]:  # ograniczenie do dwóch

                        if self.monitor.abortRequested():
                            fflog(f'przerwanie wyszukiwania (z powodu sygnału zamknięcia Kodi)')
                            return
                        # wykrywanie sygnału przerwania wyszukiwania źródeł
                        if control.window.getProperty("blocked_sources_extend") == 'break':
                            fflog(f'przerwanie dalszego wyszukiwania')
                            break

                        ftemp += find_episodes([f])

                    filtered = ftemp


            fflog(f'Znaleziono pasujących: {len(filtered)=}',1,1)
            # fflog(f'return {len(filtered)=}  {json.dumps(filtered, indent=2)}',1,1)

            for f in filtered:
                if not f.get('category'):
                    f.update({'category': (categories.get(f.get('category_id') or 0) or '')})

            if episode is not None:
                return filtered, season, episode
            return filtered

        except Exception:
            fflog_exc(1)
            return None


    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if isinstance(url, tuple):
                url, season, episode = url
            else:
                # season = None
                episode = None
                episode = 0  # nie wiem, czy stalker przewiduje odcinki specjalne

            if not url:
                return sources

            # if not self.stclient:
                # fflog(f'potrzebna inicjacja klasy StalkerClient',1,1)
                # self.stclient = StalkerClient()

            host = source_utils.top_domain(control.setting('stalkervod.server_address').strip())
            if not re.search(r'(\d{1,3}\.){3}\d{1,3}', host):
                host = host.rsplit(".", 1)[0]

            # from ptw.libraries import client

            MD_sound_disallowed = control.setting("MD.sound.disallowed") == "true"

            for s in url:

                try:
                    # fflog(f's = {json.dumps(s, indent=2)}',1)
                    # category = categories.get(s.get('category_id') or 0) or ""
                    category = s.get('category') or ""
                    title = s.get('name')
                    if episode:
                        season_title = title
                        title = s.get('path').replace('_', ' ')
                        season_title = season_title.replace('eason', 'ezon')
                        title += f"   [{season_title}  odc. {episode}]"
                        # title += f"  S{season:0>2}E{episode:0>2}"
                        # title += f"  E{episode:0>2}"

                    # fflog(f"{title=}  {category=}  (s.get('category_id')=",1,1)

                    # title += f" | {s.get('added')}"  # debug

                    # host_name = 'VOD'
                    host_name = ''
                    
                    vod_url = repr({
                                    'id': s['id'],
                                    'cmd': s.get('cmd'),
                                    'series': episode,
                                   })

                    decoded_cmd = self.decode_xtream_data(s.get('cmd'))
                    # fflog(f'{decoded_cmd=}',1,1)

                    size = None
                    if len(url) <= 4 and True:
                        fflog(f'próba określenia wielkości pliku',1,1)
                        try:
                            control.sleep(random.uniform(0.01, 0.2)*1000)  # Krótka, losowa pauza
                            stream_url = self.resolve(vod_url, dont_check_macs=False, timeout=4)
                            # fflog(f'{stream_url=}',1,1)
                            if stream_url:
                                stream_url = stream_url.rsplit('|', 1)
                                headers = stream_url[-1]
                                stream_url = stream_url[0]
                                # fflog(f'{stream_url=}',1,1)
                                headers = dict(parse_qsl(headers)) if headers != stream_url else dict("")
                                # fflog(f'{headers=}',1,1)
                                # response = self.stclient.session.head(stream_url, allow_redirects=True, timeout=2)  # serwery mogą nieobsługiwać tej metody
                                headers2 = {**headers, 'Range': 'bytes=0-0'} # Pobierz tylko pierwszy bajt}
                                # fflog(f'{headers2=}',1,1)
                                size_bytes = 0
                                response = None
                                try:
                                    control.sleep(random.uniform(0.01, 0.2)*1000)  # Krótka, losowa pauza
                                    response = self.stclient.session.get(stream_url, timeout=5, allow_redirects=True, stream=True)
                                    # headers = client.request(stream_url, headers=headers, output="headers", timeout=5, close=True)
                                    # size_bytes = client.request(stream_url, headers=headers, output="file_size", timeout=5, close=True)
                                    # fflog(f'{response=}  {response.headers}',1,1)
                                    # fflog(f'{response.url=}',1,1)
                                    if response:
                                    # if headers:
                                        # size_bytes = response.headers.get('Content-Length')
                                        size_bytes = response.headers.get('Content-Range', '').split('/')[-1] or response.headers.get('Content-Length')
                                        # size_bytes = headers.get('Content-Range', '').split('/')[-1] or headers.get('Content-Length')
                                    else:
                                        fflog(f'{response=}  |  {title=} | {category=}',1,1)
                                        # fflog(f'błąd - response = {headers}  |  {title=} | {category=}',1,1)
                                        pass
                                except Exception:
                                    fflog_exc(1)
                                    pass
                                finally:
                                    if response is not None:
                                        response.close()
                                if size_bytes:
                                    # fflog(f'{size_bytes=}',1,1)
                                    size_bytes = int(size_bytes)
                                    if size_bytes:
                                        if size_bytes >= 1024**3:
                                            size = f"{size_bytes / (1024**3):.2f} GB"
                                        else:
                                            size = f"{size_bytes / (1024**2):.2f} MB"
                                        # fflog(f'{size=}  |  {title=} | {category=}',1,1)
                                        fflog(f'{size=}',1,1)
                            else:
                                fflog(f'{stream_url=}',1,1)
                        except Exception:
                            fflog_exc(1)
                            pass

                    # duration_min = int(s.get('time') or s.get('duration') or 0)  # w minutach
                    # duration_sec = duration_min * 60
                    # if size and duration_sec > 0:
                        # bitrate = "~" + str(round(size_bytes * 8 / (duration_sec * 1000**2), 2)) + " Mbps"  # w Mbps
                        # fflog(f'{bitrate=}',1,1)

                    if episode:
                        def_qual = control.setting('stalkervod.default_quality.tvshows')
                    else:
                        def_qual = control.setting('stalkervod.default_quality.movies')
                    # quality = '1080p' if s.get('hd') else 'SD'  # na sztywno
                    quality = def_qual if s.get('hd') else 'SD'  # na sztywno
                    unsure = ["quality"]
                    if title:
                        quality = source_utils.get_qual(title + f" {category}")
                        # fflog(f'{quality=}  {title=}',1,1)
                        if not quality or quality == 'SD':
                            # quality = '1080p'  # na sztywno
                            quality = def_qual if s.get('hd') else 'SD'
                            pass
                        else:
                            unsure = None
                        pass

                    info = ''
                    language = (s.get('lang') or "").lower()
                    if language == 'pol':
                        language = 'pl'
                    if MD_sound_disallowed:
                        category = re.sub(r'\b(kin)o\b', r'\g<1>0', category, flags=re.I)  # aby nie odrzucał gdy jest wybrany filtr odrzucania dźwięku z kina
                        pass
                    if title and 1:  # a co jak nie ma PL w nazwie?
                        _ , info = source_utils.get_lang_by_type(f"{title} {s.get('description', '')}  {category}")
                        # fflog(f"lang={repr(_)}  {info=}  {title=}  {s.get('description')=}  {category=}",1,1)
                        if not language:
                            language = _
                            pass

                    if host_name:
                        info += f" | {host_name}"

                    if category:
                        title += f" | {category}"

                    # decoded_cmd = self.decode_xtream_data(s.get('cmd'))  # wyżej przeniosłem
                    extension = decoded_cmd.get('target_container')
                    if isinstance(extension, str):
                        extension = extension.strip(' ]["')
                        # if extension:
                        if 'avi' in extension:
                            # title += f" | {extension}"
                            # title += f" | AVI"
                            info += f" | AVI"  # w downloaderze coś psuje
                            pass
                    else:  # dla odcinków nie działa
                        # fflog(f"{decoded_cmd=}  {extension=}  {s.get('cmd')=}",1,1)
                        # fflog(f'{json.dumps(s, indent=2)}',1)
                        pass

                    if size:
                        info += f" | {size}"
                        pass

                    sources.append({
                        'source': host,
                        'quality': quality,
                        'language': language,
                        'url': vod_url,
                        'info': info.strip(' |'),
                        'filename': title,
                        'direct': True,
                        'debridonly': False,
                        'premium': True,
                    })

                    if unsure:
                        sources[-1]['unsure'] = unsure
                        pass

                    if trash := s.get('trash'):
                        sources[-1]['trash'] = trash

                    if size:
                        sources[-1]['size'] = size

                except Exception:
                    fflog_exc(1)
                    pass

            # fflog(f'sources = {json.dumps(sources, indent=2)}',1)
            fflog(f'Przekazano: {len(sources)} źródeł')
            return sources

        except Exception:
            fflog_exc(1)
            return sources


    def resolve(self, url, dont_check_macs=None, timeout=None):
        """Zwraca URL """

        if isinstance(url, str):
            from ast import literal_eval
            video = literal_eval(url)
        # fflog(f'{video=}',1,1)
        # fflog(f'video={json.dumps(video, indent=2)}',1,1)

        if not self.stclient:
            fflog('potrzebna inicjacja klasy StalkerClient',0,1)
            self.stclient = stclient = StalkerClient()
        else:
            stclient = self.stclient

        timeout = stclient.timeout if not timeout else timeout

        stream_url = stclient.get_vod_stream_url(
            video_id=video['id'],
            cmd=video.get('cmd'),
            series=video.get('series') or 0,
            timeout=timeout
        )

        if self.new_mac:
            mac = self.new_mac
            if mac != stclient.mac_address:
                stream_url = re.sub("(?<=mac=)[^&]*", mac, stream_url)  # wymiana MAC
        else:
            mac = stclient.mac_address
            if not dont_check_macs:
                macs = control.setting('stalkervod.macs_alt').strip()
                macs = re.split(" *[ ,|] *", macs)
                macs.insert(0, stclient.mac_address)
                macs = [l.upper() for l in macs]
                macs = list(filter(None, macs))  # usunięcie pustych
                macs = list(dict.fromkeys(macs))  # pozbycie się duplikatów
                # fflog(f'{macs=}',1,1)
                if macs:
                    mac = ""
                    if dont_check_macs is None:
                        import sys
                        if control.setting('stalkervod.ask_for_mac_before_play') == 'true' or "askmac=1" in sys.argv[2]:
                            fflog(f'ręczny wybór MAC',1,1)
                            labels = [f"[LIGHT]{i+0})[/LIGHT]   {m}" for i, m in enumerate(macs)]
                            selected = control.selectDialog(labels, 'wybierz adres MAC', autoclose=10000)
                            fflog(f'{selected=}',1,1)
                            if selected != -1:
                                mac = macs[selected]
                                stream_url = re.sub("(?<=mac=)[^&]*", mac, stream_url)
                    if not mac:
                        result = None
                        from ptw.libraries import client
                        for mac in macs:
                            if mac == stclient.mac_address:
                                continue
                            fflog(f'testowanie streamu',1,1)
                            # fflog(f'testowanie  {stream_url=}',1,1)
                            result = client.request(stream_url, output="geturl", timeout=timeout)  # wpierw test obecnego (lub poprzedniego)
                            if result:
                                # fflog(f'{result=}',1,1)
                                # return {"url":stream_url, "check_link":False}
                                break
                            fflog(f'wymiana MAC',1,1)
                            stream_url = re.sub("(?<=mac=)[^&]*", mac, stream_url)  # wymiana mac
                            if macs[-1] == mac:  # ostatni mac
                                if 0:
                                    result = client.request(stream_url, output="geturl", timeout=timeout)  # wpierw test obecnego
                                    if not result:
                                        fflog(f'ostatni MAC  {result=}',1,1)
                                        stream_url = ''
                                        # return ''
                                        pass
                                else:
                                    fflog('nie testuje już stream-u',1,1)
                                    result = True
                                    pass
                        if result:
                            self.new_mac = re.search("(?<=mac=)[^&]*", stream_url)[0]
                            # self.stclient.session.headers.update({'Cookie': f'mac={self.new_mac}'})
                            pass

        if stream_url:
            # stream_url += f"|User-Agent=vlc&verifypeer=false"
            stream_url += f"|User-Agent={quote('Mozilla/5.0 (QtEmbedded; Linux)')}"
            # mac = re.search("(?<=mac=)[^&]*", stream_url)[0]
            # stream_url += f"|User-Agent={quote('Mozilla/5.0 (QtEmbedded; Linux)')}&Cookie="+quote(f'mac={mac}')
        fflog(f'{stream_url=}',0,1)
        return stream_url


    @staticmethod
    def decode_xtream_data(encoded_str):
        try:
            # Dodajemy ewentualne brakujące znaki '=' (padding)
            missing_padding = len(encoded_str) % 4
            if missing_padding:
                encoded_str += '=' * (4 - missing_padding)
                
            # Dekodowanie z Base64 do bajtów
            decoded_bytes = base64.b64decode(encoded_str)
            
            # Konwersja bajtów na słownik JSON
            return json.loads(decoded_bytes)
        except Exception as e:
            fflog_exc(1)
            return f"Błąd dekodowania: {e}"



import math
import hashlib

class StalkerClient:


    def __init__(self):
        self.server_address = control.setting('stalkervod.server_address').strip()
        if not self.server_address:
            raise Exception('brak adresu serwera w Ustawieniach')
        self.portal_url = self.server_address.rstrip('/')
        if self.portal_url.endswith('/c'):
            # context_path = '/server/load.php'  # taki wariant przeważnie pasuje
            context_path = '/portal.php' if control.setting('stalkervod.alternative_context_path')=='true' else '/server/load.php'
            # self.portal_url = self.portal_url.replace('/c', '') + context_path  # to chyba złe jednak
            self.portal_url = self.portal_url + context_path
        else:
            portal_base_url = self.__get_portal_base_url()
            # context_path = '/portal.php'  # taki wariant przeważnie pasuje
            context_path = '/portal.php' if control.setting('stalkervod.alternative_context_path')=='false' else '/server/load.php'  # odwrotnie
            # self.portal_url = portal_base_url + '/stalker_portal' + context_path  # to chyba nie koniecznie zawsze się sprawdza
            self.portal_url = portal_base_url + '' + context_path
        # fflog(f'{self.portal_url=}',1,1)

        self.mac_address = control.setting('stalkervod.mac_address').strip().upper()
        if not self.mac_address:
            # fflog('brak adresu MAC w Ustawieniach')
            raise Exception('brak adresu MAC w Ustawieniach')

        # self.mac_address2 = control.setting('stalkervod.mac_address.2').strip()
        # self.mac_address3 = control.setting('stalkervod.mac_address.3').strip()

        self.serial = ''  # pozyskiwać z ustawień
        self.serial = self.serial or self.mac_address.replace(':', '') or ''
        # self.serial = self.serial or self.generate_serial(self.mac_address)

        self.timeout = 30

        self.token = None
        try:
            self.token = cache.cache_get("stalkervod_token")["value"]
            # fflog(f'1) {self.token=}',1,1)
        except Exception:
            # fflog_exc(1)
            pass

        import requests
        self.session = requests.Session()

        self.session.headers.update({
            'Cookie': f'mac={self.mac_address}',
            'SN': self.serial,
            'X-User-Agent': 'Model: MAG250; Link: WiFi',
            'User-Agent': 'Mozilla/5.0 (QtEmbedded; Linux)',
            # 'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3',
            'Referrer': self.server_address
        })
        # fflog(f'self.session.headers={json.dumps(dict(self.session.headers), indent=2)}',1,1)


    def generate_serial(self, mac=''):
        """
        Generate a 13-character serial based on the MD5 hash of the MAC address.

        Parameters:
            mac (str): MAC address.

        Returns:
            str: Generated serial.
        """
        # Create an MD5 hash of the MAC address
        # mac = self.__addon.getSetting('mac_address')
        md5_hash = hashlib.md5(mac.encode()).hexdigest()
        
        # Use the first 13 characters of the hash as the serial
        serial = md5_hash[:13].upper()  # Convert to uppercase for consistency
        
        #logger.debug(f"Generated serial from MAC {mac}: {serial}")
        return serial


    def generate_device_id(self, mac_exact=''):
        """
        Generate a 64-character hexadecimal device ID based on the MAC address.

        Returns:
            str: Generated device ID.
        """
        #mac_exact = self.mac.strip()
        # mac_exact = self.__addon.getSetting('mac_address')
        sha256_hash = hashlib.sha256(mac_exact.encode()).hexdigest().upper()
        #logger.debug(f"Generated device_id using MAC {mac_exact}: {sha256_hash}")
        return sha256_hash


    def __get_portal_base_url(self):
        """Get portal base url"""
        split_url = urlsplit(self.server_address)
        return split_url.scheme + '://' + split_url.netloc



    def authenticate(self, check_mac_expire_date=True):
        params = {
            'type': 'stb',
            'action': 'handshake',
            'token': ''
        }

        r = self.session.get(
                self.portal_url,
                params=params,
                timeout=self.timeout
        )
        # fflog(f'{r.status_code=}  {r.url=}',1,1)
        # fflog(f'{r.text=}',1,1)
        if not r:
            control.setSetting('stalkervod.expire_date', "[I]nieważne ? [/I]")
            if not control.window.getProperty("blocked_sources_extend") == 'break':
                control.infoDialog(f"błąd serwera: {r.status_code}", 'stalkervod', "ERROR")

        r.raise_for_status()

        try:
            data = r.json()
        except Exception:
            fflog(str(r.text), 1,1)
            raise RuntimeError('[stalkervod.py] [authenticate] Handshake: odpowiedź nie jest JSON')

        js = data.get('js', {})
        if not js:
            # fflog(f'{r.text=}',1,1)
            pass

        token = js.get('token')

        # fflog(f'1) {token=}',1,1)

        if not token:
            token = data.get('token')
            # fflog(f'2) {token=}',1,1)

        if not token:
            # fflog(f'3) {token=}',1,1)
            return

        fflog(f'pozyskano nowy token',1,1)
        self.token = token
        # control.setSetting('stalkervod.token', token)
        cache.cache_insert("stalkervod_token", token)  # wstawienie do bazy
        self.session.headers['Authorization'] = f'Bearer {self.token}'
        # fflog(f'self.session.headers={json.dumps(dict(self.session.headers), indent=2)}',1,1)
        if check_mac_expire_date and 1:
            fflog(f'jeszcze nastąpi próba sprawdzenia ważności konta',1,1)
            self.check_expiry()
            pass


    def _call(self, params, recurency=None, timeout=None):
        fflog(f'{recurency=}',1,1) if recurency else ''
        timeout = self.timeout if not timeout else timeout

        if not self.token:
            # fflog(f'{self.token=}',1,1)
            self.authenticate()

        fflog(f'{params=}',0,1)
        r = self.session.get(
                self.portal_url,
                params=params,
                timeout=timeout
        )
        # fflog(f'{r.status_code=}  {r.url=}',1,1)

        if 'Authorization failed' in r.text or r.status_code == 403:
            fflog(f"błąd połączenia  {r.status_code=}  {'Authorization failed' if 'Authorization failed' in r.text else ''}",1,1)
            self.token = None
            fflog(f'skasowanie tokena z cache',1,1)
            cache.cache_remove("stalkervod_token")
            if not recurency:
                fflog('ponawiam próbę',1,1)
                return self._call(params, recurency=True, timeout=timeout)
            else:
                fflog(f'nie ponawiam próby, bo {recurency=}',1,1)
                pass

        if not r:
            if not control.window.getProperty("blocked_sources_extend") == 'break':
                control.infoDialog(f"błąd serwera: {r.status_code}", 'stalkervod', "ERROR")

        r.raise_for_status()

        try:
            ret = r.json()
        except:
            fflog(f'{r.text=}',1,1)
            fflog('odpowiedź nie jest JSON',1,1)
            # raise RuntimeError('[stalkervod.py] [_call] odpowiedź nie jest JSON')
            ret = {}
        # fflog(f'ret = {json.dumps(ret, indent=2)}',1,1)
        ret1 = ret['js']
        # ret1 = ret.get('js', {})
        if not ret1:
            fflog('wystąpił problem',1,1)
            fflog(f'{r.text=}',1,1)
            fflog(f'{ret1=}',1,1)
            fflog(f'ret = {json.dumps(ret, indent=2)}',1,1)
            fflog(f'nie otrzymano danych z serwera',1,1)
            if not control.window.getProperty("blocked_sources_extend") == 'break':
                control.infoDialog("nie otrzymano danych z serwera", 'stalkervod', "WARNING")
            ret1 = {}
            raise Exception('[stalkervod.py] [_call] nie otrzymano danych z serwera')
        return ret1


    # def _search(self, media_type, category_id, search, page, max_pages):
    def get_videos(
        self,
        category_id,
        page=1,
        search='',
        fav=0,
        max_pages=3,
        media_type='vod'
    ):
        params = {
            'type': media_type,  # 'vod' or 'series'
            'action': 'get_ordered_list',
            'category': category_id,
            'sortby': 'added',
            'fav': fav,
            'p': page,
        }

        if search.strip():
            params['search'] = search.strip()

        result = self._call(params)  # pierwsza strona
        if not result:
            fflog(f'nie otrzymano danych z serwera {result=}',1,1)
            return []
        # fflog(f'result = {json.dumps(result, indent=4)}',1,1)
        videos = result.get('data')
        if not videos:
            fflog(f'brak danych {videos=}',1,1)
            return []
            pass

        total_items = result['total_items']
        per_page = result['max_page_items']
        total_pages = int(math.ceil(float(total_items) / float(per_page)))
        fflog(f'{total_items=}  {per_page=}  {total_pages=}',1,1)
        for p in range(page + 1, min(page + max_pages, total_pages + 1)):
            params['p'] = p  # strona
            result = self._call(params)  # kolejne strony
            if result:
                videos.extend(result.get('data') or [])
            else:
                fflog(f'2) nie otrzymano danych z serwera {result=}',1,1)
                break
                pass

        fflog(f'{len(videos)=}',1,1)
        return videos


    def get_vod_stream_url(
        self,
        video_id="",
        cmd="",
        series=0,
        use_cmd=True,
        timeout=None,
    ):
        timeout = self.timeout if not timeout else timeout
        if not cmd and video_id:
            use_cmd=False

        if not use_cmd and video_id:
            fflog('wariant 1 (z id)',0,1)
            response = self._call_raw(
               {
                'type': 'vod',
                'action': 'create_link',
                'cmd': f'/media/{video_id}.mpg',
                'series': str(series)
               },
               timeout=timeout
            )

            if response.status_code == 200:
                data = response.json().get('js', {})
                stream_url = data.get('cmd')
            else:
                stream_url = None
        else:
            stream_url = None

        if not stream_url and cmd:
            fflog('wariant 2 (z cmd)',0,1)
            data = self._call({
                'type': 'vod',
                'action': 'create_link',
                'cmd': cmd,
                'series': str(series)
            })
            stream_url = data.get('cmd')

        if not stream_url:
            raise RuntimeError('Nie udało się uzyskać URL streamu')
        # fflog(f'data={json.dumps(data, indent=2)}',1,1)
        if ' ' in stream_url:  # może być "ffmpeg " na początku
            # fflog(f'spacja w adresie {stream_url=}',1,1)
            stream_url = stream_url.split(' ', 1)[1]
            pass

        return stream_url


    def _call_raw(self, params, recurency=None, timeout=None):
        fflog(f'{recurency=}',1,1) if recurency else ''
        timeout = self.timeout if not timeout else timeout

        if not self.token:
            self.authenticate()

        r = self.session.get(
            self.portal_url,
            params=params,
            timeout=timeout
        )
        # fflog(f'{r.status_code=}  {r.url=}',1,1)
        if 'Authorization failed' in r.text or r.status_code == 403:
            fflog(f'wyczyszczenie tokena z cache',1,1)
            self.token = None
            cache.cache_remove("stalkervod_token")
            if not recurency:
                return self._call_raw(params, recurency=True, timeout=timeout)

        if not r:
            if not control.window.getProperty("blocked_sources_extend") == 'break':
                control.infoDialog(f"błąd serwera: {r.status_code}", 'stalkervod', "ERROR")

        if not r:
            fflog(f'{r.text=}',1,1)
        return r


    def get_all_episodes(self, movie_id, max_pages=10):  # max_pages - to może mieć znaczenie dla seriali z większą ilością sezonów czy odcinków (jeszcze nie wiem)
        params = {
            'type': 'series',
            'action': 'get_ordered_list',
            'movie_id': movie_id,
            'p': 1
        }
        result = self._call(params)  # pierwsza strona

        episodes = result['data']
        total_items = result['total_items']
        per_page = result['max_page_items']
        total_pages = int((total_items + per_page - 1) / per_page)

        for p in range(2, min(total_pages + 1, max_pages + 1)):
            params['p'] = p
            result = self._call(params)  # kolejne strony
            episodes.extend(result['data'])

        return episodes


    def check_expiry(self, paste_into_settings=True):
        try:
            # fflog('Sprawdzam datę ważności głównego MACa', 1, 1)
            data_waznosci = None
            # fflog(f'self.session.headers={json.dumps(dict(self.session.headers), indent=2)}',1,1)

            # account_info
            try:
                fflog('1 sposób',1,1)
                params = {'type': 'account_info', 'action': 'get_main_info', 'JsHttpRequest': '1-xml'}
                r = self.session.get(self.portal_url, params=params, timeout=self.timeout)
                if r.status_code == 200:
                    info = r.json().get('js', {})
                    # fflog(f'1) info={json.dumps(info, indent=2)}',1,1)
                    # Różne pola: expire_date, exp_date, phone (czasem tam jest data)
                    temp = info.get('expire_date') or info.get('exp_date') or info.get('phone')
                    if temp and temp != "0000-00-00 00:00:00":
                        data_waznosci = temp
                else:
                    fflog(f'1) {r.status_code=}',1,1)
            except Exception:
                fflog_exc(1)
                pass

            # get_profile (chyba urządzenia)
            if 0:  # on chyba rzadko działa
                if not data_waznosci:
                    fflog('2 sposób',1,1)
                    try:
                        control.sleep(500)
                        params = {'type': 'stb', 'action': 'get_profile', 'JsHttpRequest': '1-xml'}
                        r = self.session.get(self.portal_url, params=params, timeout=self.timeout)
                        if r.status_code == 200:
                            info = r.json().get('js', {})
                            # fflog(f'2) info={json.dumps(info, indent=2)}',1,1)
                            temp = info.get('expire_date') or info.get('end_date') or info.get('expire_billing_date')
                            if temp and temp != "0000-00-00 00:00:00":
                                data_waznosci = temp
                        else:
                            fflog(f'2) {r.status_code=}',1,1)
                    except Exception:
                        fflog_exc(1)
                        pass

            # fflog(f'{data_waznosci=}',1,1)

            if paste_into_settings:
                if data_waznosci:
                    control.setSetting('stalkervod.expire_date', str(data_waznosci))
                    pass
                else:
                    # Opcjonalnie: info o braku daty, jeśli chcesz widziec że sprawdzilo
                    control.setSetting('stalkervod.expire_date', "Brak informacji")
                    pass

            fflog(f'{data_waznosci=}',1,1)
            return data_waznosci

        except Exception:
            fflog_exc(1)
            pass


    def mac_expire_date(self):
        fflog(f'checking ... ',1,1)
        try:
            macs = control.setting('stalkervod.macs_alt').strip()
            if 1:
                # import re
                macs = re.split(" *[ ,|] *", macs)
            else:
                macs = macs.replace("|", ",").rstrip(',')
                macs = macs.split(',')  # string into list
                macs = [l.strip().replace('"', '') for l in macs]  # clean a little
            macs.insert(0, control.setting('stalkervod.mac_address').strip())
            macs = [l.upper() for l in macs]
            macs = list(filter(None, macs))
            macs = list(dict.fromkeys(macs))
            # fflog(f'{macs=}',1,1)
            if not self.token:
                self.authenticate(check_mac_expire_date=False)
            results = ""
            for mac in macs:
                serial = mac.replace(':', '') or ''
                self.session.headers.update({
                    'Cookie': f'mac={mac}',
                    'SN': serial,
                })
                expire_date = self.check_expiry(paste_into_settings=False)
                results += f'\n{mac} - {expire_date}'
                if mac != macs[-1]:
                    control.sleep(200)
            # fflog(f'results={results}',1,1)
            control.dialog.ok('Daty ważności', results)
        except Exception:
            fflog_exc(1)
            control.dialog.ok('Daty ważności', "wystąpił jakiś błąd")
