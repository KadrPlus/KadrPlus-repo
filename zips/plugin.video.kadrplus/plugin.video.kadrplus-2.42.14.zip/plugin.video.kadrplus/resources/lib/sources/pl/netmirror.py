# -*- coding: utf-8 -*-
"""
FanFilm – source: netmirror (net52.cc)
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>

Search/metadata via mobile API on net52.cc (search.php, post.php, episodes.php).
A t_hash_t cookie (from verify.php) is required for nf/hs search and for
post/episodes.php on every ott; only pv search works without it.

Playback via tv.imgcdn.kim/newtv/player.php now requires a usertoken header -
without it the site answers status "otp" and hands back a fixed decoy clip
(same file for every id) instead of the real stream. A usertoken is minted for
free via newtv/otp.php's "111111" test/bypass OTP code - the official
NetMirrorTV Android app uses this exact code itself (confirmed by decompiling
its Hermes JS bundle), so it's not a secret we're exploiting, just an
undocumented but legitimate client credential. See _otp_bypass_token.
"""

from __future__ import annotations

import base64
import hashlib
import json
import re
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from html import unescape
from typing import TYPE_CHECKING, ClassVar, Literal, cast
try:
    from typing import NotRequired, TypeAlias, TypedDict
except Exception:
    try:
        from typing_extensions import NotRequired, TypeAlias, TypedDict
    except Exception:
        class TypedDict(dict):
            pass
        class _NotRequired:
            def __class_getitem__(cls, item):
                return item
        NotRequired = _NotRequired
        TypeAlias = str
from urllib.parse import parse_qs, urljoin

from const import const
from lib.ff import cleantitle, control, requests
import lib.ff.source_utils as source_utils
from lib.ff.source_utils import CHROME_UA
from lib.ff.item import FFItem
from lib.ff.resolve_utils import build_isa_url
from lib.ff.log_utils import fflog, fflog_exc
from lib.service.client import service_client

if TYPE_CHECKING:
    from lib.sources import SourceItem, SourceTitleAlias


# ─── Types ───────────────────────────────────────────────────────────────────────

Ott: TypeAlias = "Literal['pv', 'nf', 'hs']"
Quality: TypeAlias = "Literal['4K', '1080p', '720p', 'SD']"


class Caption(TypedDict):
    file: str
    label: str
    code: str


class SearchHit(TypedDict):          # search.php → searchResult[]
    id: str
    t: str
    y: NotRequired[str]              # year (pv exposes it; nf doesn't)
    r: NotRequired[str]              # "Series" for shows, else a runtime like "2h 9m"


class SeasonEntry(TypedDict):        # post.php → season[]
    s: str
    id: str


class EpisodeData(TypedDict):        # episodes.php → episodes[]
    id: str
    t: str
    s: str
    ep: str


class ShowResponse(TypedDict):       # post.php
    status: str
    season: NotRequired[list[SeasonEntry]]


class EpisodesResponse(TypedDict):   # episodes.php
    episodes: NotRequired[list[EpisodeData]]
    nextPageShow: NotRequired[int]


# ─── Constants ───────────────────────────────────────────────────────────────────

_BASE = 'https://net52.cc'
_NEWTV_BASE = 'https://tv.imgcdn.kim'

# Multi-platform OTT endpoints - PV first (FanFilm = Prime Video addon).
# Disney+ content is already reachable via 'hs' (Disney+ Hotstar), so a separate
# 'dp' ott is intentionally omitted - it would only add per-query requests.
_OT_PLATFORMS: list[tuple[Ott, str]] = [
    ('pv', 'pv/'),
    ('nf', ''),
    ('hs', 'hs/'),
]

# Mobiledetect domains for dynamic NewTV API base discovery (checknewtv.php).
# tv.imgcdn.kim rotates; the live base is whatever checknewtv.php hands back.
# Only the live mirrors are listed - the other ~20 documented domains all
# time out, and probing them would stall discovery for minutes on failure.
_NEWTV_DOMAINS: list[str] = [
    'mobiledetects.com', 'mobiledetect.app', 'mobidetect.art', 'mobidetect.cc',
]

# Best → worst, for ordering emitted sources. Quality is bucketed from the
# actual stream dimensions (pv serves non-standard crops like 1920x800), not a
# fixed resolution lookup — see source._quality_label.
_QUALITY_ORDER: list[Quality] = ['4K', '1080p', '720p', 'SD']

_AUDIO_NOISE = frozenset({'', 'und'})

# Non-Western dubs — for a PL/EN audience an English track plus these is
# still just an English source, not a meaningful MULTI.
_NON_WESTERN_LANGS = frozenset({
    'hin', 'hindi', 'tam', 'tamil', 'tel', 'telugu', 'kan', 'kannada',
    'mal', 'malayalam', 'ben', 'bengali', 'mar', 'marathi', 'pan', 'punjabi',
    'guj', 'gujarati', 'urd', 'urdu', 'ori', 'odia', 'asm', 'assamese', 'bho',
    'ind', 'tha', 'vie', 'fil', 'msa', 'mya', 'khm', 'lao',
    'jpn', 'kor', 'zho', 'chi',
    'ara', 'tur', 'fas', 'heb',
})

# One audio track exposes its language up to three ways (LANGUAGE, NAME, URI
# path) - collapse the synonyms to a single canonical code so a lone track is
# never mistaken for MULTI.
_AUDIO_LANG_MAP = {
    'pol': 'pl', 'pl': 'pl', 'polski': 'pl', 'polish': 'pl',
    'eng': 'en', 'en': 'en', 'english': 'en',
}


# ─── Caches ──────────────────────────────────────────────────────────────────────

# content_id:newtv:ott -> (cached_at, master_url, master_text, captions)
_master_cache: dict[str, tuple[float, str, str, list[Caption]]] = {}
_MASTER_TTL = 300  # 5 min — signed master URLs expire fast


def _store_master(key: str, entry: tuple[float, str, str, list[Caption]]) -> None:
    """Cache a master, evicting whatever already outlived the TTL."""
    _master_cache[key] = entry
    expired = [cached_key for cached_key, cached_entry in _master_cache.items()
               if entry[0] - cached_entry[0] >= _MASTER_TTL]
    for stale_key in expired:
        _master_cache.pop(stale_key, None)  # pop() so parallel writers can't KeyError


# Resolved NewTV API base (tv.imgcdn.kim rotates) — discovered via checknewtv.php.
_newtv_base = ''
_newtv_base_ts = 0.0
_NEWTV_BASE_TTL = 21600  # 6h

# t_hash_t cookie from verify.php.
_verify_cookie = ''
_verify_cookie_ts = 0.0
_VERIFY_TTL = 43200  # 12h

# usertoken from newtv/otp.php ("111111" is a documented test/bypass OTP code -
# the official NetMirrorTV app itself uses it to mint a real usertoken with no
# real phone/account, confirmed by decompiling its Hermes bundle). Without this
# header, player.php always answers status "otp" (a fixed decoy clip) instead
# of "ok" (the real stream) - see _otp_bypass_token / _newtv_playback.
_otp_token = ''
_otp_token_ts = 0.0
_OTP_TOKEN_TTL = 43200  # 12h, same embedded-timestamp shape as t_hash_t



def _set_window_property(key: str, value: str) -> None:
    try:
        win = getattr(control, 'window', None)
        if callable(win):
            win = win()
        if win and hasattr(win, 'setProperty'):
            win.setProperty(key, value)
    except Exception:
        fflog_exc()

# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    ffitem: FFItem
    priority: ClassVar[int] = 1
    language: ClassVar[list[str]] = ['en', 'pl']

    def __init__(self):
        self.domains = [_BASE.split('://', 1)[-1]]
        self.debug = False

    # ── public api ────────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> str | None:
        return self._encode_locator(self._search(title, want_series=False, year=year))

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list[SourceTitleAlias], year: str) -> str | None:
        return self._encode_locator(self._search(tvshowtitle, want_series=True, year=year))

    def episode(self, url: str | None, imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> str | None:
        pairs = self._decode_locator(url) if url else []
        if not pairs:
            return url
        user_agent = CHROME_UA
        verify = self._verify_token(self.debug)

        # NetMirror labels episodes with English titles.
        titles = [candidate for candidate in (self.ffitem.vtag.getEnglishTitle(), self.ffitem.vtag.getOriginalTitle()) if candidate] or [title]
        clean_targets = {cleantitle.get(candidate) for candidate in titles if candidate}
        clean_targets.discard(None)
        target_season_label, target_episode_label = f'S{season}', f'E{episode}'

        # Resolve the episode id on each ott concurrently, using that ott's show id.
        with ThreadPoolExecutor(max_workers=len(pairs)) as pool:
            done = list(pool.map(
                lambda pair: (pair[0], self._episode_id_for_ott(
                    pair[0], pair[1], season, episode, user_agent, verify,
                    clean_targets, target_season_label, target_episode_label, titles)),
                pairs,
            ))
        per_ott_ep: dict[Ott, str] = {ott: str(epid) for ott, epid in done if epid}
        # No real episode found (e.g. search matched a same-titled movie) → emit
        # nothing rather than letting sources() play the show/movie id.
        if not per_ott_ep:
            if self.debug:
                fflog(f'S{season}E{episode}: no episode id on any ott, dropping {url!r}')
            return None
        if self.debug:
            fflog(f'S{season}E{episode} → {per_ott_ep}')
        return self._encode_locator(per_ott_ep)

    def sources(self, url: str | None, hostDict: list[str], hostprDict: list[str]) -> list[SourceItem]:
        results: list[SourceItem] = []
        try:
            pairs = self._decode_locator(url) if url else []
            if not pairs:
                return results
            user_agent = CHROME_UA

            # Fetch every ott's master concurrently (each is an independent
            # player.php + m3u8 round-trip); parse/emit in pair order afterwards.
            with ThreadPoolExecutor(max_workers=len(pairs)) as pool:
                masters = list(pool.map(
                    lambda pair: (pair[0], pair[1], self._cached_master(pair[1], pair[0], user_agent)),
                    pairs,
                ))

            for ott, content_id, master_text in masters:
                if not master_text:
                    continue
                resolutions = self._video_resolutions(master_text)
                if not resolutions:
                    if self.debug:
                        fflog(f'ott={ott}: no video streams, skip')
                    continue
                audios = self._audio_langs(master_text)
                captions = self._cached_captions(content_id, ott)
                language, info = self._classify_audio(audios, captions)
                qualities = {self._quality_label(res) for res in resolutions}
                if self.debug:
                    fflog(f'ott={ott}: qualities={sorted(qualities)} audio={sorted(audios)}')
                for quality in _QUALITY_ORDER:
                    if quality not in qualities:
                        continue
                    results.append({
                        'provider':   'netmirror',
                        'source':     'netmirror',
                        'quality':    quality,
                        'language':   language,
                        'url':        f'nm:{ott}:{content_id}?q={quality}',
                        'info':       info,
                        'filename':   str(content_id),
                        'direct':     False,
                        'debridonly': False,
                        'debrid':     '',
                        'premium':    False,
                    })
        except Exception:
            fflog_exc()
        if self.debug:
            fflog(f'sources: {len(results)}')
        return results

    def resolve(self, url: str) -> str | None:
        try:
            if not url or not url.startswith('nm:'):
                return None
            body, _, query = url[3:].partition('?')
            quality = parse_qs(query).get('q', ['1080p'])[0]
            content_ott, _, content_id = body.partition(':')
            if not content_id:  # legacy single-id safety
                content_ott, content_id = 'pv', content_ott

            user_agent = CHROME_UA
            # master_text is non-empty only for a FRESH entry (cache hit within TTL
            # or a successful refetch) — guard on it so we never reuse a stale entry's
            # expired signed master_url after a failed refetch.
            master_text = self._cached_master(content_id, content_ott, user_agent)
            if not master_text:
                if self.debug:
                    fflog(f'no fresh master for id={content_id} (ott={content_ott})')
                return None
            cached = _master_cache.get(f'{content_id}:newtv:{content_ott}')
            master_url = cached[1] if cached else None
            if not master_url:
                return None

            captions = self._cached_captions(content_id, content_ott)
            if captions:
                try:
                    subtitle_urls = [caption['file'] for caption in captions if caption.get('file')]
                    _set_window_property('source.subtitles', json.dumps(subtitle_urls))
                    if self.debug:
                        fflog(f'{len(subtitle_urls)} subtitle(s) passed to player')
                except Exception:
                    fflog_exc()

            # Serve a master trimmed to the chosen quality; ISA pulls the variant,
            # audio, subs and segments straight from the CDN (absolute URLs, children
            # carry ENDLIST → VOD, seeking works). Quality not isolatable → hand over
            # the full master and let ISA adapt.
            trimmed = self._trim_master(master_text, quality)
            if trimmed:
                master_path = f'/nm_{hashlib.md5((master_url + quality).encode()).hexdigest()[:12]}.m3u8'
                service_client.set_media_files({master_path: trimmed})
                proxy_url = urljoin(service_client.url, '/media') + master_path
                if self.debug:
                    fflog(f'{quality} → trimmed master {master_path}')
                return build_isa_url(proxy_url, _BASE + '/', ua=user_agent)

            if self.debug:
                fflog(f'{quality} not isolated → full master (ABR)')
            return build_isa_url(master_url, _BASE + '/', ua=user_agent)
        except Exception:
            fflog_exc()
            return None

    # ── verify token (verify.php bypass) ──────────────────────────────────────

    @staticmethod
    def _verify_token(debug: bool = False) -> str | None:
        global _verify_cookie, _verify_cookie_ts
        if _verify_cookie and (time.time() - _verify_cookie_ts) < _VERIFY_TTL:
            return _verify_cookie
        try:
            user_agent = CHROME_UA
            resp = requests.post(
                f'{_BASE}/verify.php',
                data={'g-recaptcha-response': str(uuid.uuid4())},
                headers={
                    'User-Agent': user_agent,
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Origin': _BASE,
                    'Referer': _BASE + '/verify2',
                    'X-Requested-With': 'XMLHttpRequest',
                },
                allow_redirects=False,
                timeout=6,
            )
            if resp and 'set-cookie' in resp.headers:
                match = re.search(r't_hash_t=([^;]+)', resp.headers['set-cookie'])
                if match:
                    value = match.group(1)
                    _verify_cookie = value
                    _verify_cookie_ts = time.time()
                    if debug:
                        fflog(f'verify.php returned t_hash_t from {_BASE}')
                    return value
        except Exception:
            if debug:
                fflog_exc()
        return None

    @classmethod
    def _otp_bypass_token(cls, debug: bool = False) -> str | None:
        """usertoken via newtv/otp.php's "111111" test bypass (see module docstring)."""
        global _otp_token, _otp_token_ts
        if _otp_token and (time.time() - _otp_token_ts) < _OTP_TOKEN_TTL:
            return _otp_token
        try:
            base = cls._resolve_newtv_base()
            resp = requests.get(
                f'{base}/newtv/otp.php',
                headers={
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0 /OS.GatuNewTV v1.0',
                    'Otp': '111111',
                    'Cache-Control': 'no-cache, no-store, must-revalidate',
                    'Pragma': 'no-cache',
                    'Expires': '0',
                },
                timeout=8,
            )
            if resp and resp.status_code == 200:
                data = resp.json()
                if data.get('status') == 'ok' and data.get('usertoken'):
                    _otp_token = data['usertoken']
                    _otp_token_ts = time.time()
                    if debug:
                        fflog(f'otp.php returned usertoken from {base}')
                    return _otp_token
        except Exception:
            if debug:
                fflog_exc()
        return None

    # ── search ────────────────────────────────────────────────────────────────

    def _search(self, title: str, want_series: bool, year: str = '') -> dict[Ott, str]:
        """Find the title's content id on every ott. Returns {ott: id} (may be empty).

        NetMirror is an EN/Indian catalogue, so we query the single English title
        only (localized/alias variants are useless here). One concurrent request per
        ott (mobile path) — each ott is a distinct catalogue and we collect every one
        that has the title.

        ``want_series`` keeps a movie from standing in for a show (and vice versa):
        the pv catalogue is full of same-titled Indian films (e.g. a Tamil "The Boys"
        movie next to the real "The Boys" series) — see _pick_candidate.
        """
        if not title:
            return {}
        fflog(f'query: {title!r}')
        verify = self._verify_token(self.debug)
        target = cleantitle.get(title)

        with ThreadPoolExecutor(max_workers=len(_OT_PLATFORMS)) as pool:
            results = list(pool.map(
                lambda platform: self._search_once(platform[1], platform[0], title, verify, CHROME_UA),
                _OT_PLATFORMS,
            ))

        found: dict[Ott, str] = {}
        for (ott, _subpath), search_result in zip(_OT_PLATFORMS, results):
            if not search_result:
                continue
            candidates = [item for item in search_result
                          if cleantitle.get(unescape(item['t'])) == target]
            matched = self._pick_candidate(candidates, want_series, year)
            if not matched:
                continue
            match_year = matched.get('y', '')
            if year and not match_year:
                match_year = self._fetch_post_year(matched['id'], _subpath, ott, verify, CHROME_UA)
                if match_year != str(year):
                    if self.debug:
                        fflog(f"year mismatch via post.php: got={match_year!r} wanted={year!r}, skip ({ott})")
                    continue
            found[ott] = matched['id']
            if self.debug:
                fflog(f"matched {matched['t']!r} ({match_year or '?'}, {matched.get('r', '?')}) → id={matched['id']} ({ott})")
        if not found and self.debug:
            fflog(f'no {"series" if want_series else "movie"} hits for {title!r}')
        return found

    @staticmethod
    def _pick_candidate(candidates: list[SearchHit], want_series: bool, year: str) -> SearchHit | None:
        """Pick the best title-matched hit, honouring movie/series kind then year.

        pv advertises kind via ``r`` ("Series" vs a runtime); nf doesn't. When kind
        is advertised we require it to match — so a same-titled film never stands in
        for a series — otherwise we fall back to the bare title match. Year (``y``,
        pv only) breaks ties within the chosen kind.
        """
        if not candidates:
            return None
        typed = [candidate for candidate in candidates if candidate.get('r')]
        if typed:
            pool = [candidate for candidate in typed
                    if ('series' in candidate['r'].lower()) == want_series]
            if not pool:
                return None
        else:
            pool = candidates
        if year:
            by_year = [candidate for candidate in pool if str(candidate.get('y', '')) == str(year)]
            if by_year:
                pool = by_year
        return pool[0]

    @staticmethod
    def _fetch_post_year(content_id: str, subpath: str, ott: str,
                         verify: str | None, user_agent: str) -> str:
        """Call post.php for a candidate to get its year (nf/hs don't expose year in search).

        Returns the year string on success, empty string on any failure (fail-open).
        """
        try:
            referer = f'{_BASE}/mobile/{subpath}'
            resp = requests.get(
                f'{referer}post.php',
                params={'id': content_id, 'tm': int(time.time() * 1000)},
                headers=source._api_headers(referer, user_agent),
                cookies=source._api_cookies(verify, ott),
                timeout=8,
            )
            if resp and resp.status_code == 200:
                return resp.json().get('year', '')
        except Exception:
            pass
        return ''

    def _search_once(self, subpath: str, ott: str, query: str,
                     verify: str | None, user_agent: str) -> list[SearchHit] | None:
        """One mobile search.php request for one ott. Returns its searchResult list.

        nf/hs search needs t_hash_t (without it they ignore the query and return a
        generic catalogue); pv works without. Transient network/JSON errors are
        expected (flaky backend) and swallowed quietly — None means "nothing here".
        """
        referer = f'{_BASE}/mobile/{subpath}'
        try:
            resp = requests.get(
                f'{referer}search.php',
                params={'s': query, 't': int(time.time() * 1000)},
                headers=self._api_headers(referer, user_agent),
                cookies=self._api_cookies(verify, ott),
                timeout=10,
            )
            if resp and resp.status_code == 200:
                return resp.json().get('searchResult') or []
        except Exception:
            pass
        return None

    # ── episode lookup ────────────────────────────────────────────────────────

    def _episode_id_for_ott(self, ott: str, show_id: str, season: str, episode: str, user_agent: str,
                            verify: str | None, clean_targets: set[str | None],
                            target_season_label: str, target_episode_label: str, titles: list[str]) -> str | None:
        """Find the episode id for S/E within one ott's show id."""
        subpath = next((sp for platform, sp in _OT_PLATFORMS if platform == ott), '')

        # Netflix mapping – single-request fast path (nf ids are numeric).
        netflix_map = source_utils.get_netflix_ep_id(show_id, season, episode, titles) if ott == 'nf' and show_id.isdigit() else None
        if netflix_map:
            try:
                resp = requests.get(
                    f'{_BASE}/mobile/episodes.php',
                    params={'s': netflix_map[1], 'series': show_id, 'page': 1},
                    cookies=self._api_cookies(verify, 'nf'),
                    headers=self._api_headers(f'{_BASE}/mobile/', user_agent),
                    timeout=10,
                )
                if resp and resp.status_code == 200:
                    eps_data: EpisodesResponse = resp.json()
                    for episode_data in eps_data.get('episodes') or []:
                        if str(episode_data['id']) == netflix_map[0]:
                            if self.debug:
                                fflog(f'MATCH BY NETFLIX ID (fast): {netflix_map[0]}')
                            return netflix_map[0]
            except Exception:
                fflog_exc()

        found = self._episode_scan(f'/mobile/{subpath}', self._api_cookies(verify, ott), show_id, season,
                                   target_season_label, target_episode_label, user_agent, clean_targets, netflix_map)
        if found:
            return found
        # Legacy /pv/ path (no /mobile/ prefix, no ott cookie) — some shows live only here.
        if ott == 'pv':
            return self._episode_scan('/pv/', self._api_cookies(verify), show_id, season,
                                      target_season_label, target_episode_label, user_agent, clean_targets, None)
        return None

    def _episode_scan(self, path: str, cookies: dict[str, str], show_id: str, season: str,
                      target_season_label: str, target_episode_label: str, user_agent: str,
                      clean_targets: set[str | None], netflix_map: tuple[str, str] | None) -> str | None:
        """post.php + paginated episodes.php scan under ``net52{path}``.

        Returns on a netflix-id or episode-title match immediately; otherwise the
        SxEy number match found in the target season (after scanning its pages).
        """
        referer = f'{_BASE}{path}'
        try:
            resp = requests.get(
                f'{referer}post.php',
                params={'id': show_id, 'tm': int(time.time() * 1000)},
                cookies=cookies,
                headers=self._api_headers(referer, user_agent),
                timeout=10,
            )
            if not resp or resp.status_code != 200:
                return None
            post_data: ShowResponse = resp.json()
            if post_data['status'] != 'y':
                return None
            seasons_list: list[SeasonEntry] = post_data.get('season') or []
            if not seasons_list:
                return None

            ordered_seasons = sorted(seasons_list, key=lambda season_entry: 0 if str(season_entry['s']) == str(season) else 1)
            fallback_id = None
            for season_entry in ordered_seasons:
                season_id = season_entry['id']
                if not season_id:
                    continue
                page = 1
                while True:
                    resp = requests.get(
                        f'{referer}episodes.php',
                        params={'s': season_id, 'series': show_id, 'page': page},
                        cookies=cookies,
                        headers=self._api_headers(referer, user_agent),
                        timeout=10,
                    )
                    if not resp or resp.status_code != 200:
                        break
                    eps_data: EpisodesResponse = resp.json()
                    for episode_data in eps_data.get('episodes') or []:
                        episode_id_str = str(episode_data['id'])
                        if netflix_map and episode_id_str == netflix_map[0]:
                            if self.debug:
                                fflog(f'MATCH BY NETFLIX ID: {episode_id_str} ({referer})')
                            return episode_id_str
                        episode_title = episode_data['t']
                        if clean_targets and cleantitle.get(episode_title) in clean_targets:
                            if self.debug:
                                fflog(f'MATCH BY TITLE: {episode_title!r} → id={episode_id_str} ({referer}, s_id={season_id})')
                            return episode_id_str
                        if not fallback_id and str(season_entry['s']) == str(season):
                            if episode_data['s'] == target_season_label and episode_data['ep'] == target_episode_label:
                                fallback_id = episode_id_str
                    if not eps_data.get('nextPageShow') or page > 5:
                        break
                    page += 1

            if fallback_id and self.debug:
                fflog(f'MATCH BY NUMBER (fallback): {target_season_label}{target_episode_label} → id={fallback_id} ({referer})')
            return fallback_id
        except Exception:
            fflog_exc()
            return None

    # ── master playlist (NewTV fetch + cache) ─────────────────────────────────

    def _cached_master(self, content_id: str, content_ott: str, user_agent: str) -> str | None:
        now = time.time()
        key = f'{content_id}:newtv:{content_ott}'
        cached = _master_cache.get(key)
        if cached and (now - cached[0]) < _MASTER_TTL:
            return cached[2]
        master_url = self._newtv_playback(content_id, content_ott)
        if not master_url:
            return None
        try:
            resp = requests.get(
                master_url,
                headers={
                    'User-Agent': user_agent,
                    'Referer': _BASE + '/',
                    'Accept': '*/*',
                },
                timeout=12,
            )
            if resp and resp.status_code == 200 and resp.text.startswith('#EXTM3U'):
                master_text = resp.text
                captions = self._extract_captions_from_master(master_text)
                _store_master(key, (now, master_url, master_text, captions))
                return master_text
            if self.debug:
                fflog(f'master fetch failed: status {getattr(resp,"status_code",None)}')
        except Exception:
            fflog_exc()
        return None

    def _cached_captions(self, content_id: str, content_ott: str = 'pv') -> list[Caption]:
        """Read captions from the master cache (populated by _cached_master)."""
        key = f'{content_id}:newtv:{content_ott}'
        cached = _master_cache.get(key)
        return cached[3] if cached else []

    @staticmethod
    def _newtv_headers(content_ott: str, usertoken: str | None = None) -> dict[str, str]:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0 /OS.GatuNewTV v1.0',
            'X-Requested-With': 'NetmirrorNewTV v1.0',
            'Ott': content_ott,
            'Accept': 'application/json, text/plain, */*',
        }
        if usertoken:
            headers['Usertoken'] = usertoken
        return headers

    @classmethod
    def _resolve_newtv_base(cls, refresh: bool = False) -> str:
        """Discover the live NewTV API base via checknewtv.php.

        tv.imgcdn.kim rotates; the mobidetect domains hand back the current base
        as a base64 token_hash. All candidates are probed concurrently and the
        first valid base wins (a dead first domain no longer stalls the chain).
        Falls back to the hardcoded default.
        """
        global _newtv_base, _newtv_base_ts
        if not refresh and _newtv_base and (time.time() - _newtv_base_ts) < _NEWTV_BASE_TTL:
            return _newtv_base
        pool = ThreadPoolExecutor(max_workers=len(_NEWTV_DOMAINS))
        try:
            futures = [pool.submit(cls._probe_newtv_domain, domain) for domain in _NEWTV_DOMAINS]
            for future in as_completed(futures):
                base = future.result()
                if base:
                    _newtv_base = base
                    _newtv_base_ts = time.time()
                    return base
            return _newtv_base or _NEWTV_BASE
        finally:
            pool.shutdown(wait=False)  # don't block on slower domains once we have one

    @classmethod
    def _probe_newtv_domain(cls, domain: str) -> str | None:
        try:
            resp = requests.get(
                f'https://{domain}/checknewtv.php',
                headers=cls._newtv_headers('pv'),
                timeout=8,
            )
            if not resp or resp.status_code != 200:
                return None
            token_hash = resp.json().get('token_hash')
            if not token_hash:
                return None
            base = base64.b64decode(token_hash).decode().rstrip('/')
            return base if base.startswith('http') else None
        except Exception:
            return None

    def _newtv_playback(self, content_id: str, content_ott: str = 'pv') -> str | None:
        usertoken = self._otp_bypass_token(self.debug)

        def _try(base: str) -> str | None:
            try:
                resp = requests.get(
                    f'{base}/newtv/player.php',
                    params={'id': content_id},
                    headers=self._newtv_headers(content_ott, usertoken),
                    timeout=12,
                )
                if resp and resp.status_code == 200:
                    data = resp.json()
                    # status != 'ok' (e.g. 'otp') means the usertoken was rejected -
                    # the site still hands back a video_link, but it resolves to a
                    # fixed decoy clip (same file for every id) instead of real content.
                    if data.get('status') == 'ok' and data.get('video_link'):
                        return data['video_link']
            except Exception:
                fflog_exc()
            return None

        base = self._resolve_newtv_base()
        link = _try(base)
        if link:
            return link
        # Failed → host may have rotated; re-discover once and retry.
        fresh = self._resolve_newtv_base(refresh=True)
        return _try(fresh) if fresh != base else None

    # ── stream parsing (master m3u8 → quality / audio / captions) ─────────────

    @staticmethod
    def _video_resolutions(master_text: str) -> set[str]:
        return set(re.findall(r'#EXT-X-STREAM-INF[^\n]*RESOLUTION=(\d+x\d+)', master_text))

    @staticmethod
    def _quality_label(resolution: str) -> str:
        """Bucket an arbitrary ``WxH`` into a quality label (pv serves odd crops)."""
        try:
            width, height = (int(dim) for dim in resolution.split('x'))
        except (ValueError, TypeError):
            return 'SD'
        return source_utils.quality_from_resolution(width, height)

    @staticmethod
    def _audio_langs(master_text: str) -> set[str]:
        """One canonical language code per audio track.

        Picks a single label per ``TYPE=AUDIO`` line (LANGUAGE, else NAME, else
        the ``/a/<lang>/`` URI segment) so a single track contributes a single
        token - distinct tokens then genuinely mean distinct audio tracks.
        """
        langs: set[str] = set()
        for line in master_text.splitlines():
            if '#EXT-X-MEDIA:' not in line or 'TYPE=AUDIO' not in line:
                continue
            raw = ''
            for attr in ('LANGUAGE', 'NAME'):
                attr_match = re.search(attr + r'="([^"]*)"', line)
                if attr_match and attr_match.group(1):
                    raw = attr_match.group(1)
                    break
            if not raw:
                path_match = re.search(r'URI="[^"]*?/a/([^/]+)/', line)
                raw = path_match.group(1) if path_match else ''
            raw = raw.strip().lower()
            if raw:
                langs.add(_AUDIO_LANG_MAP.get(raw, raw))
        return langs

    @staticmethod
    def _classify_audio(audios: set[str], captions: list[Caption] | None = None) -> tuple[str, str]:
        meaningful = audios - _AUDIO_NOISE
        caption_codes = set()
        if captions:
            for caption in captions:
                code = caption.get('code', '').strip().lower()
                if code:
                    caption_codes.add(_AUDIO_LANG_MAP.get(code, code))

        if not meaningful:
            # Do not label an untagged NetMirror stream as English.  Many NM
            # masters omit EXT-X-MEDIA audio language tags even when the actual
            # stream has PL/MULTI audio.  Prefer Polish when Polish captions are
            # visible, otherwise mark as MULTI/unknown instead of EN so the user
            # can verify it manually.
            if 'pl' in caption_codes:
                language, info_parts = 'pl', ['NAPISY']
            else:
                language, info_parts = 'multi', ['JĘZYK ?']
        else:
            # Common variants in attributes or URI paths
            has_pol = any(variant in meaningful for variant in ('pol', 'pl', 'polski', 'polish'))
            has_eng = any(variant in meaningful for variant in ('eng', 'en', 'english'))

            if has_pol:
                language = 'pl'
                info_parts = ['LEKTOR']
                if len(meaningful) > 1:
                    info_parts.append('MULTI')
            elif has_eng:
                language = 'en'
                non_western = meaningful - {'en'} - _NON_WESTERN_LANGS
                info_parts = ['MULTI'] if non_western else []
            else:
                language = 'en'
                info_parts = ['MULTI']
        if captions:
            if caption_codes - {language} - _NON_WESTERN_LANGS:
                if 'NAPISY' not in info_parts:
                    info_parts.append('NAPISY')
        return (language, ' '.join(info_parts))

    @staticmethod
    def _extract_captions_from_master(master_text: str) -> list[Caption]:
        captions: list[Caption] = []
        for line in master_text.splitlines():
            if '#EXT-X-MEDIA:TYPE=SUBTITLES' not in line:
                continue
            name_match = re.search(r'NAME="([^"]*)"', line)
            lang_match = re.search(r'LANGUAGE="([^"]*)"', line)
            uri_match = re.search(r'URI="([^"]*)"', line)
            if not uri_match:
                continue
            file_url = uri_match.group(1)
            label = name_match.group(1) if name_match else ''
            code = lang_match.group(1).split('-')[0].lower() if lang_match else ''
            if file_url.startswith('//'):
                file_url = 'https:' + file_url
            captions.append({'file': file_url, 'label': label, 'code': code})
        return captions

    # ── master trimming (force a single quality) ─────────────────────────────

    def _trim_master(self, master_text: str, target_quality: str) -> str | None:
        """Master containing only the chosen-quality variant; audio/subs kept as-is.

        Variant, audio, subtitle and segment URLs are already absolute and the child
        playlists carry #EXT-X-ENDLIST (ISA plays them as VOD → seeking works), so we
        only drop the other STREAM-INF variants to pin the picked quality. Returns
        None when the quality isn't present (caller serves the full master).
        """
        if not master_text.startswith('#EXTM3U'):
            return None
        lines = master_text.splitlines()
        kept: list[str] = []
        kept_variant = False
        index = 0
        while index < len(lines):
            line = lines[index]
            if line.startswith('#EXT-X-STREAM-INF'):
                resolution_match = re.search(r'RESOLUTION=(\d+x\d+)', line)
                variant_url = lines[index + 1] if index + 1 < len(lines) else ''
                if (resolution_match and variant_url.startswith('http')
                        and self._quality_label(resolution_match.group(1)) == target_quality):
                    kept.append(line)
                    kept.append(variant_url)
                    kept_variant = True
                index += 2
                continue
            kept.append(line)
            index += 1
        return '\n'.join(kept) if kept_variant else None

    # ── helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _api_headers(referer: str, user_agent: str) -> dict[str, str]:
        return {
            'User-Agent': user_agent,
            'Accept': 'application/json, text/plain, */*',
            'Referer': referer,
            'X-Requested-With': 'XMLHttpRequest',
        }

    @staticmethod
    def _api_cookies(verify: str | None, ott: str | None = None) -> dict[str, str]:
        cookies = {'hd': 'on'}
        if ott:
            cookies['ott'] = ott
        if verify:
            cookies['t_hash_t'] = verify
        return cookies

    @staticmethod
    def _encode_locator(per_ott: dict[Ott, str]) -> str | None:
        """Pack the per-ott ids found for a title into one locator string.

        Nothing found → None, so callers don't repeat the empty check.
        """
        if not per_ott:
            return None
        return 'nm:' + ';'.join(f'{ott}:{content_id}' for ott, content_id in per_ott.items())

    @staticmethod
    def _decode_locator(url: str) -> list[tuple[Ott, str]]:
        """Unpack a locator into (ott, id) pairs. Tolerates the single legacy form."""
        body = url[3:].split('?', 1)[0] if url.startswith('nm:') else ''
        pairs: list[tuple[Ott, str]] = []
        for chunk in body.split(';'):
            ott, _, content_id = chunk.partition(':')
            if ott and content_id:
                pairs.append((cast('Ott', ott), content_id))
        return pairs
