# -*- coding: utf-8 -*-
"""Disabled legacy CDA WWW scraper.

Kadr+ uses resources.lib.sources.pl.cda as the only CDA provider.
This module is kept as a harmless stub for old profiles/import paths, but it
must not run searches because it duplicates cda.py and slows down source prep.
"""

from __future__ import annotations


class source:  # noqa: N801
    def __init__(self):
        self.priority = -1
        self.language = ['pl']
        self.domains = ['cda.pl']

    def movie(self, *args, **kwargs):
        return None

    def tvshow(self, *args, **kwargs):
        return None

    def episode(self, *args, **kwargs):
        return None

    def sources(self, *args, **kwargs):
        return []

    def resolve(self, url, *args, **kwargs):
        return None
