
import re

from urllib.parse import quote_plus

from ptw.libraries import cleantitle, title_matcher
from ptw.libraries.control import settings
from ptw.debug import fflog, fflog_exc

# import requests
# import urllib3
# urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class source:

    def __init__(self):
        self.priority = 1
        self.language = ["pl"]

        self.base_link = "https://filmy.live"
        self.search_link = "/search?q="
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0',
            # 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            # 'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'Referer': self.base_link,
        }
        self.session = None
        self.email = settings.getString("filmylive.email")
        self.password = settings.getString("filmylive.password")


    def do_login(self):
        if not self.email or not self.password:
            return False
        try:
            data = {
                "email": self.email,
                "password": self.password,
                "action": "submitform",
            }
            resp = self.session.post(
                f"{self.base_link}/user/do_login",
                data=data,
                headers={"Referer": f"{self.base_link}/user/login"},
                verify=False,
            )
            if 1:
                resp = self.session.get(self.base_link, headers=self.headers, timeout=30, verify=False)
                if "yloguj" in resp.text or "profile" in resp.text:
                    fflog("zalogowano pomyślnie",1,1)
                    # return True
                else:
                    fflog("logowanie nieudane",1,1)
                    fflog(f'{resp.text=}',0,1)
                    # return False
        except Exception:
            fflog_exc(1)


    def try_login(self):
        if not self.email or not self.password:
            return
        try:
            resp = self.session.get(self.base_link, headers=self.headers, timeout=30, verify=False)
            if "yloguj" in resp.text:
                fflog("użytkownik już zalogowany",1,1)
                return
            else:
                fflog("trzeba zalogować",1,1)
                self.do_login()
        except Exception:
            fflog_exc(1)


    def movie(self, imdb, title, localtitle, aliases, year):
        # fflog(f'{title=}  {localtitle=}  {year=}',1,1)
        return self.search(title, localtitle, year)


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # fflog(f'{tvshowtitle=}  {localtvshowtitle=}  {year=}',1,1)
        return self.search(tvshowtitle, localtvshowtitle, year, is_tvshow=True)


    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        # fflog(f'{url=}  {season=} {episode=}',1,1)
        if not url:
            return None
        url['season'] = season
        url['episode'] = episode
        return url


    def search(self, title, localtitle, year, is_tvshow=False):
        # fflog(f'{title=} {localtitle=} {year=} {is_tvshow=}',1,1)
        try:
            if not self.session:
                import requests
                self.session = requests.Session()
            self.try_login()

            titles = [localtitle, title] if localtitle else [title]

            for search_title in titles:
                if not search_title:
                    continue

                fflog(f'{search_title=},1,1')

                search_url = f'{self.base_link}{self.search_link}{quote_plus(search_title)}'
                response = self.session.get(search_url, headers=self.headers, timeout=30, verify=False)

                if not response or response.status_code != 200:
                    fflog(f'{response=}  {response.status_code=}',1,1)
                    continue

                html = response.text

                pattern_films = r'<div\s+class="movie-img">(.*?)</h3>\s*</div>\s*</div>'
                films = re.findall(pattern_films, html, re.DOTALL)
                fflog(f'{len(films)=}',1,1)

                for film in films:
                    if is_tvshow:
                        if '_tv"' not in film:
                            continue
                    else:
                        if '_movie"' not in film:
                            continue

                    pattern_film = r'<div\s+class="movie-title">.*?<a\s+href="([^"]+)">([^<]+)</a>'

                    matches = re.findall(pattern_film, film, re.DOTALL)
                    fflog(f'{len(matches)=}',1,1)

                    wanted_titles = title_matcher.title_variants(search_title, search_title, None, max_items=4)

                    for content_url, content_titles in matches:

                        content_titles = re.split(r' (\d{4})$', content_titles)
                        if len(content_titles) == 1:
                            content_titles = re.split(r' (\d{4})-\d{,4}$', content_titles[0])  # seriale
                        # content_titles = list(filter(None, content_titles))
                        if len(content_titles) > 1:
                            content_year = content_titles[1]
                            content_titles = content_titles[0]
                        else:
                            content_year = ""
                        # fflog(f'{content_titles=}  {content_year=}',1,1)
                        content_year = year if not content_year else content_year

                        if content_year == year:
                            content_titles = content_titles.split(' / ')

                            for content_title in content_titles:
                                if title_matcher.matches_any(content_title, wanted_titles, threshold=84):
                                    return {'url': content_url, 'year': content_year, 'title': content_title}

        except Exception:
            fflog_exc(1)


    def sources(self, url, hostDict, hostprDict):
        try:
            if not url:
                return []

            if not self.session:
                import requests
                self.session = requests.Session()
            self.try_login()

            season = url.get('season')
            episode = url.get('episode')

            content_url = url.get('url')
            response = self.session.get(content_url, headers=self.headers, timeout=30, verify=False)

            if not response or response.status_code != 200:
                fflog(f'{response.status_code=}',1,1)
                return []

            html = response.text
            sources = []

            if episode:
                seasons_pattern = f'<!-- Upcomming Movies -->.*?</div>\s*<script type = "text/javascript" >'
                seasons = re.findall(seasons_pattern, html, re.DOTALL)
                fflog(f'{len(seasons)=}',1,1)

                for seas in seasons:
                    
                    if not (label := re.search(rf'<span>(Sezon {season}\b[^<]*)</span>', seas)):
                        continue

                    label = label[1]
                    # fflog(f'{label=}',1,1)

                    pattern = r'<a href="([^?"]+\?key=[^"]*)">'
                    episodes_sources = re.findall(pattern, seas)
                    # fflog(f'{len(episodes_sources)=}',1,1)

                    link = episodes_sources[int(episode) - 1]

                    pattern = r'<figcaption class="figure-caption ">(.*?)</figcaption>'
                    episodes_title = re.findall(pattern, seas)
                    # fflog(f'{len(episodes_title)=}',1,1)

                    quality = '2160p' if '4K' in label else '1080p'

                    info = ''
                    if '4K' in label:
                        info += '  | AV1'
                        info = info.strip()
                        pass

                    label = re.sub(r' (4K|FullHD)\b', '', label, flags=re.I).strip()

                    filename = episodes_title[int(episode) - 1]
                    filename = f'{label}: {filename}'

                    sources.append( {
                        'source': 'filmy.live',
                        'quality': quality,
                        'language': 'pl',
                        'url': link,
                        'info': info,
                        'filename': filename,
                        'direct': True,
                        'debridonly': False,
                        # 'subtitles': ,
                    })

            else:  # filmy
                pattern = r'<a href="([^?"]+\?key=[^"]*)" class="[^"]*">(.+?)</a>'
                html_sources = re.findall(pattern, html)
                fflog(f'{len(html_sources)=}',1,1)
                # fflog(f'{len(html_sources)=}  {html_sources=}',1,1)
                for i, s in enumerate(html_sources):
                    link = s[0]
                    info = s[1]
                    # host = self._get_host(link)
                    # fflog(f'{host=}',1,1)
                    quality = '2160p' if '4K' in info else '1080p'  # 'FullHD'  - ciekawe, czy są inne jak SD czy CAM
                    # filename = url.get('title') or ''
                    # filename += ' ' + url.get('year') or ''
                    # filename = filename.strip()
                    filename = link
                    # filename = ''
                    if 0:  # wywołuje kolejne requesty do serwera - czy to nie spowoduje jakiegoś bana? Choć raczej tylko 2 (góra 3) źródła będą (chyba). Ale jak będa warianty typu napisy, dubbing?
                        if i > 0:
                            html = self.session.get(link, headers=self.headers, timeout=10, verify=False).text
                        filename = re.search("src: '(.+?)'", html)[1]
                        # fflog(f'{filename=}',1,1)
                        # link = {"url": link, "referer": link, "subtitles": ""}
                    else:
                        filename = ''
                        pass
                    filename = filename.rpartition("/")[-1]
                    filename = filename.rsplit("?")[0].replace(".html", "")
                    # fflog(f'{filename=}',1,1)
                    if not filename:
                        if '4K' in info:
                            info += '  | AV1'
                            pass
                    info = re.sub(r' (4K|FullHD)\b', '', info, flags=re.I).strip()
                    # subtitles = re.findall('<track kind="subtitles" src="(.*?)" srclang="(.*?)" label="(.*?)">', html)

                    sources.append( {
                        # 'source': 'filmy.live',
                        'source': '',
                        'quality': quality,
                        'language': 'pl',
                        'url': link,
                        'info': info,
                        'filename': filename,
                        'direct': True,
                        'debridonly': False,
                        # 'subtitles': ,
                    })

            fflog(f'Przekazano: {len(sources)} źródeł')
            return sources

        except Exception:
            fflog_exc(1)


    def resolve(self, url):
        try:
            # if isinstance(url, dict):
                # fflog(f'{url=}',1,1)
                # url = None
            # if "/watch/" in url:
            # content_url = url.get('content_url')
            if not self.session:
                import requests
                self.session = requests.Session()
            self.try_login()
            # import requests
            # response = requests.get(url, headers=self.headers, timeout=30, verify=False)
            response = self.session.get(url, headers=self.headers, timeout=30, verify=False)
            if not response or response.status_code != 200:
                fflog(f'{response.status_code=}',1,1)
                return
            html = response.text
            # Referer = url
            Referer = self.headers.get('Referer') or url or ''
            url = re.search("src: '(.+?)'", html)
            # fflog(f'{url=}',1,1)
            if url:
                url = url[1]
            else:
                fflog(f'wystąpił problem, bo {url=}',1,1)
                pass
            # fflog(f'{url=}',1,1)
            url += f'|Referer={quote_plus(Referer)}'
            subtitles = re.findall('<track kind="subtitles" src="(.*?)" srclang="(.*?)" label="(.*?)">', html)
            if subtitles:
                subs = {}
                for sub in subtitles:
                    subs.update({sub[2]: sub[0]})
                return url, subs
            else:
                return url
        except Exception:
            fflog_exc(1)
