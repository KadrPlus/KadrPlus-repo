# -*- coding: utf-8 -*-

import time
import re
import unicodedata
import os

import xbmcaddon
import xbmc, xbmcgui

import urllib.request
# import urllib.parse
import urllib.error
import http.cookiejar

import hashlib
import json
# from ast import literal_eval
from ptw.libraries import cache
from ptw.libraries import cleantitle, source_utils
from ptw.debug import fflog, fflog_exc



class source:

    def __init__(self):
        self.priority = 1
        self.language = ['pl']
        self.useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0'
        self.x_sources = []  # lista źródeł:  {'type': 'file'/'url', 'path': ścieżka/URL}
        self.search_mode = 'all'  # 'first' - pierwsze znalezione, 'all' - wszystkie pasujące
        self.all_found_urls = []  # TU JEST KLUCZ: przechowuje wszystkie URL znalezione w trybie "all"
        self.searched_params = {}
        self.all_entries = []
        self.all_entries_movies = []
        self.all_entries_tvshows = []
        self.url = ''
        self.opener = None
        self.monitor = None
        self.addon = None
        # self.timeout = None


    @staticmethod
    def get_data_hash(data_obj):
        # 1. Normalizacja: sort_keys=True jest KLUCZOWE
        # separator pozbywa się zbędnych spacji, co ujednolica string
        normalized_json = json.dumps(data_obj, sort_keys=True, separators=(',', ':'))
        return hashlib.sha256(normalized_json.encode('utf-8')).hexdigest()


    def _get_x_sources(self):
        """Pobiera listę źródeł z ustawień FanFilm."""
        try:
            if not self.addon:
                self.addon = addon = xbmcaddon.Addon()
            else:
                addon = self.addon

            sources = []
            
            # # Pobierz tryb wyszukiwania
            # self.search_mode = addon.getSetting('xtream2.search_mode') or '0'
            
            # # Konwersja z wartości enum (0/1) na tekst
            # if self.search_mode == '0':
                # self.search_mode = 'first'
            # elif self.search_mode == '1':
                # self.search_mode = 'all'
            # else:
                # # domyślnie
                # self.search_mode = 'first'
                # self.search_mode = 'all'


            url = addon.getSetting('xtream2.server').rstrip('/').strip() or ''
            if url and (url.startswith('http://') or url.startswith('https://')):
                username = addon.getSetting('xtream2.username').strip() or ''
                password = addon.getSetting('xtream2.password').strip() or ''
                url = f'{url}/player_api.php?username={username}&password={password}'
                # fflog(f'{url=}', 1,1)
                self.url = url
                sources.append({'type': 'url', 'path': url})

            sources = [source for x, source in enumerate(sources) if source not in sources[:x]]  # eliminacja dubli
            if sources:
                fflog(f'xtream2: {len(sources)}  tryb: {self.search_mode}', 1, 1)
            else:
                fflog(f'{len(sources)=}', 1,1)
            # fflog(f'{len(sources)=}  {sources=}', 1,1)

            try:
                prev_hash_sources = cache.cache_get("xtream2.settings_sources")["value"]
            except:
                prev_hash_sources = ''
            curr_hash_sources = self.get_data_hash(sources)
            if curr_hash_sources != prev_hash_sources:
                fflog(f'wykryto zmianę ustawień źródeł - nastąpi wyczyszczenie cache wpisów', 1,1)
                # cache.cache_insert("xtream2.all_entries.tvshows", '')
                cache.cache_remove("xtream2.all_entries.tvshows")
                # cache.cache_insert("xtream2.all_entries.movies", '')
                cache.cache_remove("xtream2.all_entries.movies")
                cache.cache_insert("xtream2.settings_sources", curr_hash_sources)
                time.sleep(0.1)

            return sources
            
        except Exception as e:
            fflog(f'xtream2: błąd odczytu ustawień: {e}', 1, 1)
            fflog_exc(1)
            return []


    def _download_from_url(self, url):
        """Pobiera zawartość z URL."""
        if not self.addon:
            self.addon = xbmcaddon.Addon()
        timeout = int(self.addon.getSetting("scrapers.timeout.1"))
        try:

            if not self.monitor:
                self.monitor = xbmc.Monitor()

            if not self.opener:
                # fflog('tworzę build_opener-a',1,1)
                # 1. Obsługa ciasteczek (odpowiednik sesji w requests)
                self.cookie_jar = http.cookiejar.CookieJar()
                
                # 2. Tworzymy "opener", który będzie używany do każdego zapytania
                self.opener = urllib.request.build_opener(
                    urllib.request.HTTPCookieProcessor(self.cookie_jar)
                )
                
                # 3. Dodajemy stałe nagłówki do openera
                self.opener.addheaders = [
                    ('User-Agent', self.useragent),
                    ('Accept', '*/*'),
                    ('Connection', 'keep-alive') # To przyspiesza kolejne zapytania
                ]
            else:
                # fflog('na szczęście build_opener już istnieje',1,1)
                pass

            if not url:
                fflog(f'błąd, bo {url=}',1,1)
                return None

            blocked = None
            if url.endswith("&action=get_series") or url.endswith("&action=get_vod_streams"):
                while xbmcgui.Window(10000).getProperty("xtream2_downloading_in_progress"):
                    if not blocked:  # jednorazowy komunikat
                        fflog('trwa blokada z powodu oczekiwania na zakończenie poprzedniego pobierania',1,1)
                    blocked = True
                    if self.monitor.abortRequested():
                        fflog(f'przerwanie wyszukiwania (z powodu sygnału zamknięcia Kodi)')
                        return
                    self.monitor.waitForAbort(1)  # 1 sekunda

            if blocked:
                fflog('karencja blokady',1,1)
                while xbmcgui.Window(10000).getProperty("xtream2_analizing_in_progress"):
                    if self.monitor.abortRequested():
                        fflog(f'przerwanie wyszukiwania (z powodu sygnału zamknięcia Kodi)')
                        return
                    self.monitor.waitForAbort(1)  # 1 sekunda
                blocked = False
                fflog('sprawdzenie, czy jest coś w cache',1,1)
                if "_series" in url:
                    if cache.cache_not_empty("xtream2.all_entries.tvshows"):
                        return True
                else:
                    if cache.cache_not_empty("xtream2.all_entries.movies"):
                        return True
                fflog('koniec blokady',1,1)

            if url.endswith("&action=get_series") or url.endswith("&action=get_vod_streams"):
                xbmcgui.Window(10000).setProperty("xtream2_downloading_in_progress", url)

            # fflog(f'{url=}',1,1)
            now1 = int(time.time())
            # req = urllib.request.Request(
                # url,
                # headers={
                    # 'User-Agent': self.useragent,
                    # 'Accept': '*/*',
                    # 'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                    # 'Connection': 'keep-alive'
                # }
            # )
            # with urllib.request.urlopen(req, timeout=timeout) as response:
            with self.opener.open(url, timeout=timeout) as response:  # Używamy self.opener zamiast urllib.request.urlopen
                if response.status != 200:
                    fflog(f'response.status={response.status}',1,1)
                if 1:
                    # fflog(f'{response.headers}',1,1)
                    content_length = response.headers.get('Content-Length')
                    if not content_length:
                        content_length = int(response.getheader('Content-Length', 0))
                    if content_length:
                        file_size_mb = int(content_length) / (1024 * 1024)
                        if file_size_mb > (0.03 * 1024 * 1024):
                            fflog(f'do pobrania {file_size_mb:.2f} MB',1,1)
                            pass
                    else:
                        # fflog('nieznany rozmiar do pobrania',1,1)
                        pass
                # fflog(f'trwa pobieranie ...',1,1)
                # content = response.read()
                content = b""
                chunks = []  # Lista na kawałki bajtów
                downloaded = 0
                chunk_size = 1024 * 256  # 256 KB na jeden odczyt
                last_log_time = time.time()
                while True:
                    if self.monitor.abortRequested():
                        fflog(f'przerwanie wyszukiwania (z powodu sygnału zamknięcia Kodi)')
                        return
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    # content += chunk  # mało wydajne w Pythonie
                    chunks.append(chunk) # To jest szybkie i bezpieczne
                    if 1:
                        downloaded += len(chunk)
                        current_time = time.time()
                        if current_time - last_log_time >= 5.0:  # Sprawdzamy, czy minęło 5 sekund od ostatniego logu
                            percent = (downloaded / content_length) * 100 if content_length > 0 else 0
                            if content_length:
                                fflog(f"dotychczas pobrano {downloaded / (1024*1024):.2f} MB ({percent:.1f}%)",1,1)
                            else:
                                fflog(f"dotychczas pobrano {downloaded / (1024*1024):.2f} MB",1,1)
                            last_log_time = current_time
                content = b"".join(chunks)
                del chunks
                len_content = len(content)
                if len_content > (0.03 * 1024 * 1024):
                    fflog(f'Pobrano {len_content / (1024*1024):.2f} MB',1,1)
                    pass
                elif len_content < 10:
                    # fflog(f'pobrano {len_content} bajty',1,1)
                    pass
                now2 = int(time.time())
                if now2 - now1 > 1:
                    fflog(f'pobieranie trwało {(now2 - now1)} sek.')
                if url.endswith("&action=get_series") or url.endswith("&action=get_vod_streams"):
                    xbmcgui.Window(10000).clearProperty("xtream2_downloading_in_progress")
                # return json.loads(response.read().decode('utf-8'))
                # Spróbuj różne kodowania
                try:
                    return content.decode('utf-8')
                except UnicodeDecodeError:
                    try:
                        return content.decode('latin-1')
                    except UnicodeDecodeError:
                        return content.decode('utf-8', errors='ignore')

        except urllib.error.HTTPError as e:
            fflog_exc()
            fflog(f'urllib.error.HTTPError: {e.code}  {e.reason}\n',1,1)
            fflog(f'{url=}\n',1,1)
            # import xbmcgui
            if not xbmcgui.Window(10000).getProperty("blocked_sources_extend") == 'break':
                xbmcgui.Dialog().notification('xtream2', f"błąd serwera: {e.code}", xbmcgui.NOTIFICATION_ERROR)
            if url.endswith("&action=get_series") or url.endswith("&action=get_vod_streams"):
                xbmcgui.Window(10000).clearProperty("xtream2_downloading_in_progress")
            return False
        except urllib.error.URLError as e:
            # To wywoła się TYLKO, gdy serwer w ogóle nie odpowiedział (brak sieci)
            fflog_exc()
            fflog(f'urllib.error.URLError: {e.reason}\n',1,1)
            fflog(f'{url=}\n',1,1)
            # import xbmcgui
            if not xbmcgui.Window(10000).getProperty("blocked_sources_extend") == 'break':
                xbmcgui.Dialog().notification('xtream2', f"błąd połączenia: {e.reason}", xbmcgui.NOTIFICATION_ERROR)
            if url.endswith("&action=get_series") or url.endswith("&action=get_vod_streams"):
                xbmcgui.Window(10000).clearProperty("xtream2_downloading_in_progress")
            return False
        except Exception:
            fflog_exc(1)
            fflog(f'{url=}\n',1,1)
            if url.endswith("&action=get_series") or url.endswith("&action=get_vod_streams"):
                xbmcgui.Window(10000).clearProperty("xtream2_downloading_in_progress")
            return False
        finally:
            if url.endswith("&action=get_series") or url.endswith("&action=get_vod_streams"):
                xbmcgui.Window(10000).clearProperty("xtream2_downloading_in_progress")
            pass


    def _is_cyrillic(self, text):
        """Sprawdza czy tekst zawiera cyrylicę."""
        # fflog('_is_cyrillic',1,1)
        if not text:
            return False
        
        # Zakresy Unicode dla cyrylicy
        cyrillic_ranges = [
            (0x0400, 0x04FF),  # Cyrillic
            (0x0500, 0x052F),  # Cyrillic Supplement
            (0x2DE0, 0x2DFF),  # Cyrillic Extended-A
            (0xA640, 0xA69F),  # Cyrillic Extended-B
        ]
        
        for char in text:
            code = ord(char)
            for start, end in cyrillic_ranges:
                if start <= code <= end:
                    # fflog('koniec _is_cyrillic',1,1)
                    return True
        # fflog('koniec _is_cyrillic',1,1)
        return False


    def _transliterate_cyrillic(self, text):
        """Transliteracja tekstu cyrylickiego na łaciński."""
        # fflog('_transliterate_cyrillic',1,1)
        
        if not text:
            return text
        
        # Jeśli nie ma cyrylicy, zwróć oryginał
        if not self._is_cyrillic(text):
            return text
        
        # Słownik transliteracji rosyjskiej
        cyrillic_map = {
            'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd',
            'е': 'e', 'ё': 'yo', 'ж': 'zh', 'з': 'z', 'и': 'i',
            'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n',
            'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't',
            'у': 'u', 'ф': 'f', 'х': 'kh', 'ц': 'ts', 'ч': 'ch',
            'ш': 'sh', 'щ': 'shch', 'ъ': '', 'ы': 'y', 'ь': '',
            'э': 'e', 'ю': 'yu', 'я': 'ya',
            'А': 'a', 'Б': 'b', 'В': 'v', 'Г': 'g', 'Д': 'd',
            'Е': 'e', 'Ё': 'yo', 'Ж': 'zh', 'З': 'z', 'И': 'i',
            'Й': 'y', 'К': 'k', 'Л': 'l', 'М': 'm', 'Н': 'n',
            'О': 'o', 'П': 'p', 'Р': 'r', 'С': 's', 'Т': 't',
            'У': 'u', 'Ф': 'f', 'Х': 'kh', 'Ц': 'ts', 'Ч': 'ch',
            'Ш': 'sh', 'Щ': 'shch', 'Ъ': '', 'Ы': 'y', 'Ь': '',
            'Э': 'e', 'Ю': 'yu', 'Я': 'ya'
        }
        
        result = []
        for char in text:
            if char in cyrillic_map:
                result.append(cyrillic_map[char])
            else:
                result.append(char)
        # fflog('koniec _transliterate_cyrillic',1,1)
        return ''.join(result)


    def _normalize_x_title(self, title, entry=None):
        """Normalizacja tytułu """
        if not title:
            return '', None

        # Zamień podkreślniki na spacje
        title = title.replace('_', ' ')

        # if 0:  # nie konieczne to dobre, bo usuwa rzymskie liczby
            # title = re.sub(r'\b(MULTI|[A-Z]{2}-[A-Z]{2}|[A-Z]{2,4})\b', '', title)
            # title = self.lang_re.sub('', title)
            # title = title.replace('[]', '').replace('[-]', '').strip(' |')
            # pass

        # fflog(f'entry = {json.dumps(entry, indent=2)}',1,1)

        # Wyodrębnij rok z tytułu
        year_match = re.search(r'\((\d{4})\)', title)
        year = (year_match.group(1)) if year_match else None
        if not year and entry:
            year = (entry.get("releasedate") or "")[:4] if not year else year
            year = (entry.get("releaseDate") or "")[:4] if not year else year  # widziałem dla seriali tak zapisane jeszcze "releaseDate"
        if not year:
            year_match = re.search(r'- (\d{4})$', title)
            year = (year_match.group(1)) if year_match else None            
        if not year:
            year_match = re.search(r'\D(\d{4})\D*$', title)
            year = (year_match.group(1)) if year_match else None            
        # if not year:
            # try:
                # fflog(f'{title=}',1,1)
                # fflog(f'entry = {json.dumps(entry, indent=2)}',1,1)
            # except Exception:
                # pass

        # Usuń rok z tytułu
        if year:
            # title = re.sub(r'\s*\(\d{4}\)\s*', '', title)
            # title = re.sub(fr'\s*\({year}\)\s*', '', title)
            # title = title.replace(year, '').replace('()', '').strip()
            title = title.split(year, 1)[0].rstrip(' (-')
            # year = int(year)
                
        # Transliteruj TYLKO cyrylicę
        title = self._transliterate_cyrillic(title)
        
        # cleantitle.get()
        title_clean = cleantitle.get(title)
        # if "ltered" in title_clean:  # debug
            # fflog(f'{title_clean=} {year=}  {title=}',1,1)
            # fflog(f'entry = {json.dumps(entry, indent=2)}',1,1)
        return title_clean, year


    def _normalize_search_title(self, title):
        """Normalizacja tytułu do wyszukiwania."""
        # fflog('_normalize_search_title',1,1)
        if not title:
            return ''
        
        # Transliteruj TYLKO jeśli zawiera cyrylicę
        title = self._transliterate_cyrillic(title)
        # fflog('koniec _normalize_search_title',1,1)
        return cleantitle.get(title)


    def get_cached_x(self, episode=None):
        """Pobiera wszystkie listy ze wszystkich źródeł."""
        # fflog('get_cached_x',1,1)
        try:
            if not self.x_sources:
                self.x_sources = self._get_x_sources()

            if not self.x_sources:
                return None

            if self.all_entries:
                return self.all_entries
            else:
                try:
                    if episode:
                        self.all_entries = json.loads(cache.cache_get("xtream2.all_entries.tvshows")["value"])
                    else:
                        self.all_entries = json.loads(cache.cache_get("xtream2.all_entries.movies")["value"])
                    fflog('pobrano z cache',1,1)
                    return self.all_entries
                except:
                    pass

            all_entries = []

            # fflog(f'{len(self.x_sources)=}',1,1)
            for source_info in self.x_sources:

                source_type = source_info['type']
                source_path = source_info['path']
                # source_name = f"{source_type}:{os.path.basename(source_path) if source_type == 'file' else 'url'}"
                source_name = ""
                
                content = None
                
                if source_type == 'file':
                    pass
                    # # Plik lokalny
                    # if not os.path.exists(source_path):
                        # continue
                    
                    # try:
                        # with open(source_path, "r", encoding="utf-8") as f:
                            # content = f.read()
                    # except UnicodeDecodeError:
                        # try:
                            # with open(source_path, "r", encoding="latin-1") as f:
                                # content = f.read()
                        # except Exception:
                            # continue
                    # except Exception:
                        # continue
                
                elif source_type == 'url':
                    # URL

                    # kategorie
                    if episode:
                        source_path += "&action=get_series_categories"
                    else:
                        source_path += "&action=get_vod_categories"
                    content = self._download_from_url(source_path)
                    if content and isinstance(content, str):
                        # entries = self._parse_x(content, source_name)
                        categories = json.loads(content)
                    else:
                        categories = []
                    if not categories:
                        fflog(f'problem, bo {categories=}',1,1)
                    fflog(f'{len(categories)=}',1,1)

                    # index (to może trwać dłużej)
                    source_path = source_info['path']
                    if episode:
                        source_path += "&action=get_series"
                    else:
                        source_path += "&action=get_vod_streams"
                    content = self._download_from_url(source_path)

                    if not content:
                        fflog(f'problem, bo {content=}',1,1)
                        if content is False or content is None:
                            # break
                            return
                        continue

                if content is True:
                    try:
                        if episode:
                            self.all_entries = json.loads(cache.cache_get("xtream2.all_entries.tvshows")["value"])
                        else:
                            self.all_entries = json.loads(cache.cache_get("xtream2.all_entries.movies")["value"])
                        fflog('pobrano z cache',1,1)
                        return self.all_entries
                    except Exception:
                        fflog_exc(1)
                        pass
                    return

                if content:
                    fflog(f'analizowanie indeksu (content)',1,1)
                    xbmcgui.Window(10000).setProperty("xtream2_analizing_in_progress", "1")
                    # entries = self._parse_x(content, source_name)
                    entries = json.loads(content)
                    del content
                    fflog(f'{len(entries)=}',1,1)
                    if 1:
                        cat_map = {d["category_id"]: d["category_name"] for d in categories}

                        niechciane_frazy = ['kabarety', 'silownia', 'siłownia', 'fitness', 'dieta', 'zdrowie',
                                            'gry', 'komputer', 'przepisy', 'poradniki', 'gadżety', 'zapowiedzi',
                                            'sport', 'karaoke', 'przewodnik', 'mecz', 'nba', 'piłka', 'eurosport', 'hokej', 'karate', 'teledyski',
                                            'nauka jezykow', 'nauka języków', 'podcast', 'audiobooki',
                                            'xxx', 'for adults', 'ppv',
                                            ]

                        keep = ['name', 'tmdb', 'stream_id', 'series_id', 'container_extension', 'direct_source']

                        entries = [
                            {
                                **{k: e[k] for k in keep if k in e},  # Kopiujemy tylko wybrane klucze
                                # dodajemy nowe pola
                                "category_name": category_name,
                                "title_clean": (_ := self._normalize_x_title(e.get("name"), e))[0],
                                "year": _[1],
                            } 
                            for e in entries
                                if e.get('container_extension') != 'mp3'
                                    and all(kw not in (category_name := cat_map.get(e.get("category_id"), "")).lower() for kw in niechciane_frazy)
                        ]

                        if 0:
                            entries_bez_tmdb = [e for e in entries if not e.get('tmdb')]
                            fflog(f'{len(entries_bez_tmdb)=}',1,1)
                            if entries_bez_tmdb:
                                fflog(f'entries_bez_tmdb={json.dumps(entries_bez_tmdb, indent=2)}',1,1)
                                pass

                    all_entries.extend(entries)
                    del entries
            
            # if all_entries:
            fflog(f'xtream2: Załadowano {len(all_entries)} wpisów ', 1, 1)
            self.all_entries = all_entries
            # if episode:
                # self.all_entries_tvshows = all_entries
            # else:
                # self.all_entries_movies = all_entries
            fflog(f'{len(all_entries)=}',1,1)
            if all_entries:
                try:
                    if episode:
                        cache.cache_insert("xtream2.all_entries.tvshows", json.dumps(all_entries))  # wstawienie do bazy
                    else:
                        cache.cache_insert("xtream2.all_entries.movies", json.dumps(all_entries))  # wstawienie do bazy
                    fflog('zapisano do cache',1,1)
                except:
                    pass
            xbmcgui.Window(10000).clearProperty("xtream2_analizing_in_progress")
            return all_entries
            
        except Exception as e:
            fflog(f'xtream2: Błąd w get_cached_x: {e}', 1, 1)
            fflog_exc(1)
            xbmcgui.Window(10000).clearProperty("xtream2_analizing_in_progress")
            return None


    def _search_items(self, title, year=None, season=None, episode=None, tmdb=None):
        """Wyszukiwanie filmu we wszystkich listach """
        # fflog(f'{title=}  {year=}  {season=}  {episode=}  {tmdb=}',1,1)
        entries = self.get_cached_x(episode=episode)
        # fflog(f'{len(entries)=}',1,1)
        if not entries:
            fflog(f'{entries=}',1,1)
            if entries is None:
                return None
            return [] if self.search_mode == 'all' else None

        if self.monitor.abortRequested():
            fflog(f'przerwanie wyszukiwania (z powodu sygnału zamknięcia Kodi)')
            return
        # wykrywanie sygnału przerwania wyszukiwania źródeł
        if xbmcgui.Window(10000).getProperty("blocked_sources_extend") == 'break':
            fflog(f'przerwanie dalszego wyszukiwania')
            return

        found_urls = []

        # tmdb = None  # testy tylko
        if tmdb:
            for e in entries:
                try:
                    if tmdb == e.get('tmdb'):
                        if episode:
                            found_urls.append((e['series_id'], e['name'], season, episode, e['category_name']))
                            if self.search_mode == 'first':
                                break
                        else:
                            found_urls.append((e['stream_id'], e['name'], e['container_extension'], e['category_name']))
                            if self.search_mode == 'first':
                                break
                except Exception:
                    fflog_exc(1)
                    pass

        if found_urls:
            # fflog('dopasowano wg identyfikatora tmdb',1,1)
            # fflog(f'0. {len(found_urls)=}  found_urls = {json.dumps(found_urls, indent=2)}',1,1)
            if 1:  # zastanowić się
                if self.search_mode == 'first':
                    return found_urls[0]
                else:
                    return found_urls

        if 1:
            # fflog('nie dopasowano wg identyfikatora tmdb - będą próby po nazwie',1,1)

            search_title_clean = self._normalize_search_title(title)  # szukany tytuł
            if episode:
                # search_title_clean += f"s{season:>02}e{episode:>02}"
                pass
            # fflog(f'{search_title_clean=}',1,1)

            # trzeba rok wyodrębnić
            # 1. Najpierw próbuj dokładne dopasowanie z rokiem
            for e in entries:
                try:
                    # fflog(f'1) {e=}',1,1)
                    # fflog(f"1) {e['title_clean']=}",1,1)
                    if search_title_clean == e['title_clean']:
                        # fflog(f"1) dopasowano tytuł {e['title_clean']=}",1,1)
                        if year and e['year']:
                            # fflog(f"1) kontrola roku {e['year']=} {e['title_clean']=}",1,1)
                            if year == e['year']:
                                # fflog(f"1) potwierdzono także rok {e['year']=} {e['title_clean']=}",1,1)
                                if episode:
                                    found_urls.append((e['series_id'], e['name'], season, episode, e['category_name']))
                                    if self.search_mode == 'first':
                                        break
                                else:
                                    found_urls.append((e['stream_id'], e['name'], e['container_extension'], e['category_name']))
                                    if self.search_mode == 'first':
                                        break
                            else:
                                # fflog(f"1) brak zgodnosci roku rok {e['year']=} {e['title_clean']=}",1,1)
                                pass

                        else:
                            # fflog(f"1) brak roku {e['year']=} {e['title_clean']=}",1,1)
                            if episode:
                                found_urls.append((e['series_id'], e['name'], season, episode, e['category_name']))
                                if self.search_mode == 'first':
                                    break
                            else:
                                found_urls.append((e['stream_id'], e['name'], e['container_extension'], e['category_name']))
                                if self.search_mode == 'first':
                                    break
                except Exception:
                    fflog_exc(1)
                    pass
            
            if found_urls:
                # fflog(f'1. {len(found_urls)=}  found_urls = {json.dumps(found_urls, indent=2)}',1,1)
                if self.search_mode == 'first':
                    return found_urls[0]
            
            # 2. Jeśli nie znaleziono z rokiem, spróbuj BEZ roku
            if year:  # nie wiem, czemu taki warunek Toov dał
            # if not found_urls:  # zastanowić się nad tym warunkiem
                # fflog(f'Próbowanie dopasowania z pominięciem roku',1,1)
                for e in entries:
                    try:
                        # fflog(f'2) {e=}',1,1)
                        # fflog(f"2) {e['title_clean']=}",1,1)
                        if search_title_clean == e['title_clean'] and (not e['year'] or int(e['year']) == int(year) - 1):
                            # fflog(f"2) dopasowano tytuł {e['title_clean']=}",1,1)
                            if episode:
                                found_urls.append((e['series_id'], e['name'], season, episode, e['category_name']))
                                if self.search_mode == 'first':
                                    break
                            else:
                                found_urls.append((e['stream_id'], e['name'], e['container_extension'], e['category_name']))
                                if self.search_mode == 'first':
                                    break
                    except Exception:
                        fflog_exc(1)
                        pass

            if found_urls:
                # fflog(f'2. {len(found_urls)=}  found_urls = {json.dumps(found_urls, indent=2)}',1,1)
                if self.search_mode == 'first':
                    return found_urls[0]
            
            # 3. Próbuj częściowe dopasowanie
            # if not found_urls:  # zastanowić się nad tym warunkiem
            if 1:
                # fflog(f'Próbowanie częściowego dopasowania',1,1)
                title1 = title.replace('The ', '').replace('A ', '').replace('An ', '')
                # fflog(f'{title1=}  {title=}  {search_title_clean=}',1,1)
                re_title1 = re.compile(rf'\b{re.escape(title1)}\b', flags=re.I)
                for e in entries:
                    try:
                        # fflog(f'3) {e=}',1,1)
                        # fflog(f"3) {e['title_clean']=}",1,1)
                        if search_title_clean in e['title_clean'] or len(e['title_clean']) > 3 and e['title_clean'] in search_title_clean:
                            if len(title1.split(' ')) == 1 and not re_title1.search(e["name"]):
                                continue
                            # fflog(f"3) dopasowano tytuł  {e['title_clean']=}  {e['name']=}",1,1)
                            # if 0:
                                # if not episode and re.search(r's\d{2}e\d{2,4}$', e['title_clean']):
                                    # # continue
                                    # pass
                                # if episode and not re.search(r's\d{2}e\d{2,4}$', e['title_clean']):
                                    # # continue
                                    # pass
                            if year and e['year']:
                                if year == e['year']:
                                    # fflog(f"3) dopasowano z rokiem {e['year']=}  {e['title_clean']=}  {search_title_clean=}",1,1)
                                    if episode:
                                        found_urls.append((e['series_id'], e['name'], season, episode, e['category_name']))
                                        if self.search_mode == 'first':
                                            break
                                    else:
                                        found_urls.append((e['stream_id'], e['name'], e['container_extension'], e['category_name']))
                                        if self.search_mode == 'first':
                                            break
                                else:
                                    # fflog(f"3) brak zgodnosci roku rok {e['year']=}  {e['title_clean']=}",1,1)
                                    pass

                            else:
                                # fflog(f"3) dopasowano bez roku {e['year']=}  {e['title_clean']=}  {search_title_clean=}",1,1)
                                if episode:
                                    found_urls.append((e['series_id'], e['name'], season, episode, e['category_name']))
                                    if self.search_mode == 'first':
                                        break
                                else:
                                    found_urls.append((e['stream_id'], e['name'], e['container_extension'], e['category_name']))
                                    if self.search_mode == 'first':
                                        break
                    except Exception:
                        fflog_exc(1)
                        pass

            if found_urls:
                # fflog(f'3. {len(found_urls)=}',1,1)
                # fflog(f'3. {len(found_urls)=}  found_urls = {json.dumps(found_urls, indent=2)}',1,1)
                if self.search_mode == 'first':
                    return found_urls[0]
                else:
                    return found_urls

        # jak nic nie znaleziono
        return [] if self.search_mode == 'all' else None


    def get_movie_info(self, stream_id):
        url = self.url
        url += f"&action=get_vod_info&vod_id={stream_id}"
        content = self._download_from_url(url)
        if not content:
            fflog(f'problem, bo {content=}',1,1)
            result = None
        else:
            # entries = self._parse_x(content, source_name)
            result = json.loads(content)
        return result


    def _get_episode(self, series_id, season, episode):
        url = self.url
        url += f"&action=get_series_info&series_id={series_id}"
        content = self._download_from_url(url)
        if not content:
            fflog(f'problem, bo {content=} a to jest serial, czyli nie znaleziono odcinków dla {series_id=}',1,1)
            # continue
            result = None
        else:
            # entries = self._parse_x(content, source_name)
            result = json.loads(content)
            if not result:
                fflog(f'problem, bo {content=} a to jest serial, czyli nie znaleziono odcinków dla {series_id=}',1,1)
                return result
            try:
                result = result['episodes'].get(str(season))
                if result:
                    e = {}
                    try:
                        if 0:
                            e = result[int(episode) - 1]  # jest jeszcze ryzyko, że odcinki nie będą po kolei
                        else:
                            for ep in result:
                                if int(ep.get('episode_num', 0)) == int(episode):
                                    e = ep
                                    break
                    except Exception:
                        fflog_exc(1)
                        # e = {}
                        # fflog(f'brak odcinka {episode=}',1,1)
                    if e:
                        # result = (e['id'], e['title'], e['container_extension'], 'series')
                        result = e
                        # fflog(f'xtream2: ✓ Znaleziono odcinek {e["episode_num"]=}  {e["season"]=}', 1, 1)
                    else:
                        fflog(f'brak odcinka {episode=}',1,1)
                        result = None
                else:
                    fflog(f'brak sezonu {season=}',1,1)
            except Exception:
                fflog_exc(1)
                # fflog(f"DUPA {content=}",1,1)
                # fflog(f"DUPA {result=}",1,1)
        return result


    def search(self, title, localtitle, aliases, year, season=None, episode=None, tmdb=None):
        """Główna metoda wyszukiwania"""
        try:
            # DEBUG: podsumowanie danych z TMDB
            fflog(f'xtream2: Szukam filmu: "{title}" / "{localtitle}", rok: {year}  {tmdb=}  {season=}  {episode=}', 1, 1)
            
            # Lista kandydatów
            candidates = []
            
            # 1. Tytuł lokalny (polski)
            if localtitle:
                candidates.append(localtitle)
            
            # 2. Tytuł oryginalny
            if title:
                candidates.append(title)
            
            # 3. WSZYSTKIE aliasy z TMDB (wszystkie języki)
            if aliases and isinstance(aliases, list):
                for alias in aliases:
                    if isinstance(alias, dict):
                        alias_title = alias.get('title') or alias.get('originalname')
                        if alias_title and alias_title not in candidates:
                            # fflog(f'{alias_title=}',1,1)
                            alias_title = alias_title.replace(year, '').strip()
                            # fflog(f'{alias_title=}',1,1)
                            candidates.append(alias_title)
            
            # Usuń duplikaty
            unique_candidates = []
            seen = set()
            for candidate in candidates:
                if candidate and candidate not in seen:
                    seen.add(candidate)
                    unique_candidates.append(candidate)
            
            # Próbuj każdego kandydata
            all_found_urls = []  # Zbierz wszystkie URL dla trybu "all"

            if not self.monitor:
                self.monitor = xbmc.Monitor()

            fflog(f'{len(unique_candidates)=}',1,1)
            for candidate in unique_candidates:

                if self.monitor.abortRequested():
                    fflog(f'przerwanie wyszukiwania (z powodu sygnału zamknięcia Kodi)')
                    return
                # wykrywanie sygnału przerwania wyszukiwania źródeł
                if xbmcgui.Window(10000).getProperty("blocked_sources_extend") == 'break':
                    fflog(f'przerwanie dalszego wyszukiwania')
                    break

                # fflog(f'{candidate=}',1,1)
                result = self._search_items(candidate, year, season, episode, tmdb)
                # fflog(f'{result=}',1,1)
                if result:
                    if self.search_mode == 'first':
                        fflog(f'xtream2: ✓ Znaleziono URL', 1, 1)
                        if episode:
                            # result = self._get_episode(result[0], season, episode)
                            pass
                        return result
                    else:
                        # W trybie "all" result to lista URL
                        if isinstance(result, list):
                            for url in result:
                                if url and url not in all_found_urls:
                                    if episode:
                                        # url = self._get_episode(url[0], season, episode)
                                        pass
                                    all_found_urls.append(url)
                else:
                    fflog(f'{result=}',1,1)
                    if result is None:
                        return
                    pass

                if tmdb:
                    # break
                    pass
            
            if self.search_mode == 'all' and all_found_urls:
                # Zapisz wszystkie znalezione URL do zmiennej instancji
                self.all_found_urls = all_found_urls
                self.searched_params = {"year": year, "tmdb": tmdb}
                fflog(f'xtream2: Znaleziono {len(all_found_urls)} potencjalnych źródeł', 1, 1)
                
                # Zwróć pierwszy URL (reszta będzie w sources())
                return all_found_urls[0] if all_found_urls else None
            
            return None
            
        except Exception:
            fflog_exc(1)


    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        tmdb = kwargs.get('tmdb')
        return self.search(title, localtitle, aliases, year, tmdb=tmdb)


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return (tvshowtitle, localtvshowtitle), year, aliases


    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        title = url[0][0]
        localtitle = url[0][1]
        year = url[1]
        aliases = url[2]
        aliases = None
        tmdb = kwargs.get('tmdb')
        return self.search(title, localtitle, aliases, year, season, episode, tmdb)


    # ===== DOZWOLONE JĘZYKI =====
    LANG_GROUPS = {
        'PL': ['PL', 'POL', 'LEK', 'NAPI'],
        'EN': ['EN', 'ENG', 'GBR', 'US', 'USA', 'UK', 'CA', 'AU', 'BRI', 'AME', 'UNITED'],
        'DE': ['DE', 'DEU', 'GER', 'AT', 'AUT'],
        'FR': ['FR', 'FRE', 'FRA', 'VF', 'VOSTFR'],
        'ES': ['ES', 'ESP', 'SPA', 'LAT'],
    }

    def _expand_lang_groups(self, languages):
        expanded = []
        seen_groups = set()
        for lang in languages:
            expanded.append(lang)
            for group_key, group_variants in self.LANG_GROUPS.items():
                if group_key in seen_groups:
                    continue
                if lang in group_variants:
                    seen_groups.add(group_key)
                    for v in group_variants:
                        if v not in expanded:
                            expanded.append(v)
                    break
        return list(dict.fromkeys(expanded))
    # ===== DOZWOLONE JĘZYKI =====


    def _parse_allowed_languages(self, tvseries, prefix='xtream2'):
        if not self.addon:
            self.addon = xbmcaddon.Addon()
        if self.addon.getSetting(f'{prefix}.languages.all') == 'true':
            return None
        languages = self.addon.getSetting(f'{prefix}.languages').strip()
        if not languages:
            return None
        languages = re.split(" *[ ,|] *", languages)
        languages = [l.upper() for l in languages if l.isalpha()]
        languages = list(dict.fromkeys(languages))
        langs_target = self.addon.getSetting(f'{prefix}.languages.target')
        fflog(f'{langs_target=}',1,1)
        episode = tvseries
        if not episode and int(langs_target) not in [0, 1]:
            languages = []
        if episode and int(langs_target) not in [0, 2]:
            languages = []
        if 'PL' not in languages: languages.insert(0, 'PL')
        if 'POL' not in languages: languages.insert(1, 'POL')
        if 'MULTI' not in languages: languages.append('MULTI')
        if 'MUL' not in languages: languages.append('MUL')
        return self._expand_lang_groups(languages)


    def sources(self, url, hostDict, hostprDict):
        try:
            sources_list = []

            # fflog('sources',1,1)
            if not url:
                fflog(f'{url=}',1,1)
                return []

            # fflog(f'{type(url)=}  {len(url)=}',1,1)

            if not self.url:
                self._get_x_sources()

            searched_params = self.searched_params
            fflog(f'{searched_params=}',1,1)

            # W trybie "all" używamy wszystkich zapisanych URL
            if self.search_mode == 'all' and hasattr(self, 'all_found_urls') and self.all_found_urls:
                all_urls = self.all_found_urls
            else:
                # W trybie "first" lub jeśli nie ma zapisanych źródeł
                fflog(f'brak zapisanych źródeł',1,1)
                all_urls = [url] if url else []

            fflog(f'{len(all_urls)=}',1,1)

            if not self.addon:
                self.addon = xbmcaddon.Addon()
            addon = self.addon

            all_languages = addon.getSetting('xtream2.languages.all') == 'true'
            if not all_languages:
                # languages = ["PL", "POL", "MUL", "MULTI", "US", "EN", "ENG", ""]
                # lang_re = re.compile(r'\b(MULTI|[A-Z]{2}-[A-Z]{2}|[A-Z]{2,4})\b')
                # lang_re = re.compile(r'\b(PL|POL|MUL|MULTI|US|EN|ENG)\b')
                # lang_re = re.compile(r'\b(PO?L|MUL(TI)?|US|ENG?)\b')  # ten jest OK
                # lang_re = re.compile(r'\b(PO?L|POLAND|POLISH|POLONIA|POLSKA|POLSKIE?|MUL(TI)?|US|ENG?)\b')
                # lang_re = re.compile(r'\b(PO?L(AND|ISH|ONIA|SK[AI]E?)?|MUL(TI)?|US|ENG?)\b')  # skompresowany (linijki wyżej)
                # lang_re = self.lang_re
                # lang_re2 = re.compile(r'\b([A-Z]{2,4})\b')
                tvseries = len(all_urls[0]) == 5
                allowed_langs = self._parse_allowed_languages(tvseries)
                if allowed_langs:
                    lang_pattern = '|'.join(re.escape(x) + (r'\w*' if len(x) >= 3 else '') for x in allowed_langs)
                    lang_re = re.compile(rf'\b({lang_pattern})\b', re.I)
                else:
                    lang_re = re.compile(r'\b(PO?L\w*|MUL(TI)?|US|ENG?\w*)\b', re.I)

            # polskie_oznaczenia1_re = re.compile(r'\b(POLAND|POLISH|POLONIA|POLSKA|POLSKIE?)\b')
            polskie_oznaczenia1_re = re.compile(r'\b(PO?L(AND|ISH|ONIA|SK[AI]E?))\b', re.I)  # skompresowany (linijki wyżej)
            # polskie_oznaczenia2_re = re.compile(r'\b(filmy|kinowe|romantyczne|komedie)\b', flags=re.I)  # na razie hipotetycznie

            MD_sound_disallowed = addon.getSetting("MD.sound.disallowed") == "true"

            if not self.monitor:
                self.monitor = xbmc.Monitor()

            for movie_url in all_urls:
                try:

                    if self.monitor.abortRequested():
                        fflog(f'przerwanie wyszukiwania (z powodu sygnału zamknięcia Kodi)')
                        return
                    # wykrywanie sygnału przerwania wyszukiwania źródeł
                    if xbmcgui.Window(10000).getProperty("blocked_sources_extend") == 'break':
                        fflog(f'przerwanie dalszego wyszukiwania')
                        break

                    # fflog(f'{movie_url=}',1,1)
                    group_title = ''
                    stream_id = ''
                    container_extension = ''
                    episode = season = None
                    if isinstance(movie_url, tuple):  # musi tak być
                        # fflog(f'{len(movie_url)=}',1,1)
                        if len(movie_url) == 5:
                            stream_id, title, season, episode, group_title = movie_url
                        else:
                            stream_id, title, container_extension, group_title = movie_url
                            episode = season = None
                    else:  # nie może tak być
                        fflog(f'jakiś problem, bo {type(movie_url)=} i będzie wyzerowany title',1,1)
                        title = ''

                    combined_name = title + f" | {group_title}"
                    combined_name_search = combined_name.replace('_', ' ')

                    language = ''
                    if not all_languages:
                        # m = lang_re.search(group_title)
                        m = lang_re.search(combined_name_search)
                        # if m and m[1].upper() not in languages:
                        if not m:
                            if not polskie_oznaczenia1_re.search(combined_name_search):  # and not polskie_oznaczenia2_re.search(combined_name):
                                fflog(f'odrzucam {title=}, bo {combined_name=}  (brak języka PL, EN lub MULTI)',0,1)
                                continue
                            else:
                                language = 'pl'
                                pass
                        elif m:
                            language = m[1].upper()
                            if language == 'EN': # EN nie podswietla sie w wynikach. 
                                language = 'eng' # ENG owszem trzeba zobaczyc Source.py
                            # fflog(f'finded {language=}',1,1)

                    # fflog(f'{movie_url=}',1,1)

                    time.sleep(0.1)
                    # dodatkowe requesty do serwera
                    if episode:
                        einfo = self._get_episode(stream_id, season, episode)
                        if not einfo:
                            fflog(f'brak takiego odcinka  {season=}  {episode=}',1,1)
                            continue
                        tv_stream_id = stream_id
                        tv_title = title
                        fflog(f'{tv_stream_id=}  {tv_title=}',1,1)
                        if einfo:
                            stream_id, title, container_extension = (einfo['id'], einfo['title'], einfo['container_extension'])
                        if re.search(r'^[Ss]\d+[ .-]?[Ee]\d+$', title):
                            title = tv_title + f"  {title}"
                    else:
                        einfo = self.get_movie_info(stream_id)
                        tv_stream_id = tv_title = ""

                    # fflog(f'einfo={json.dumps(einfo, indent=2)}',1,1)

                    if searched_params:
                        year = searched_params.get("year")
                        tmdb = searched_params.get("tmdb")
                        if einfo and einfo.get("info"):
                            if tmdb and (tmdb_id := einfo["info"].get("tmdb_id")) and str(tmdb_id) != tmdb:
                                fflog(f'odrzucam {title=}  bo {tmdb_id=} != {tmdb=}',0,1)
                                continue
                            if year and (releasedate := (einfo["info"].get("releasedate") or einfo["info"].get("releaseDate"))) and releasedate[:4] != year:
                                fflog(f'odrzucam {title=}  bo {releasedate=} != {year=}',0,1)
                                continue

                    movie_url = self.url
                    movie_url = movie_url.replace('player_api.php', 'series' if episode else 'movie')
                    movie_url = movie_url.replace('?username=', '/').replace('&password=', '/')
                    movie_url += f"/{stream_id}.{container_extension}"
                    # fflog(f'{movie_url=}',1,1)

                    source_info = ""
                    
                    host_match = re.search(r'https?://(?:www\.)?([^:/]+)', movie_url)
                    host_name = host_match.group(1) if host_match else ''
                    host_name = host_name.rsplit('.', 2)[-2] if '.' in host_name else host_name

                    unsure = None
                    quality = ''
                    # height = 0
                    width = 0
                    if einfo:
                        try:
                            # height = einfo['info']['video']['height']
                            width = einfo['info']['video']['width']
                            # fflog(f'{quality=}',1,1)
                            quality = source_utils.label_to_quality(str(width), by_width=True)
                            # fflog(f'{quality=}',1,1)
                        except Exception:
                            # fflog_exc(1)
                            pass
                            quality = ''
                    else:
                        fflog(f'{einfo=}',1,1)
                    # if not quality or quality == 'SD' and not width:
                    if not width or width < 320:
                        quality = '1080p'  # na sztywno
                        unsure = ["quality"]
                        if title:
                            # fflog(f'do sprawdzania jakości: {title + f" | {group_title}"}',1,1)
                            quality = source_utils.get_qual(title + f" | {group_title}")
                            # fflog(f'{quality=}  {title=}',1,1)
                            if not quality or quality == 'SD' and 'SD' not in title:
                                if 'FHD' in title:
                                    quality = '1080p'
                                elif ' HD' in title:
                                    quality = '720p'
                                else:
                                    quality = '1080p'  # na sztywno
                                    pass
                                pass
                            else:
                                unsure = None
                            pass

                    info = ''
                    tech_info = ''
                    size = ''
                    bitrate = ''
                    if einfo:
                        try:
                            codec_name = einfo['info']['video']['codec_name']
                            if codec_name not in 'h264 mjpeg':
                                tech_info += codec_name + ', '
                        except Exception:
                            # fflog_exc(1)
                            # fflog(f'{einfo=}',1,1)
                            pass

                        try:
                            codec_name = einfo['info']['audio']['codec_name']
                            if codec_name not in 'aac mpeg':  # bo to popularne
                                tech_info +=  codec_name + ''
                            if einfo['info']['audio']['channels'] != 2:
                                tech_info += " " + einfo['info']['audio']['channel_layout'].split('(')[0]
                        except Exception:
                            # fflog_exc(1)
                            # fflog(f'{einfo=}',1,1)
                            pass

                        try:
                            # fflog(f'einfo={json.dumps(einfo, indent=2)}',1,1)
                            # ogólny (mniej dokładny)
                            try:
                                duration_secs = float(einfo['info']['duration_secs'])
                                bitrate = int(einfo['info']['bitrate'])  # w kbps
                                # fflog(f'{bitrate=}  ({round(bitrate/1000, 2)} Mbps)',1,1)
                                size = bitrate * duration_secs / 8
                                # fflog(f'{size=}',1,1)
                                if size >= 1024**2:
                                    size = str(round(size / 1024**2, 2)) + " GB"
                                elif size:
                                    size = str(round(size / 1024**1, 2)) + " MB"
                                # fflog(f'1 {size=}  (mniej dokładny)',1,1)
                            except Exception:
                                # fflog_exc(1)
                                # fflog(f'einfo={json.dumps(einfo, indent=2)}',1,1)
                                pass
                            # na podstawie kodeków
                            try:
                                bit_rate_v = int(einfo['info']['video']['tags']['BPS'])  # w bps chyba
                            except:
                                bit_rate_v = int(einfo['info']['video']['bit_rate'])  # w bps chyba
                            try:
                                bit_rate_a = int(einfo['info']['audio']['tags']['BPS'])  # w bps chyba
                            except:
                                bit_rate_a = int(einfo['info']['audio']['bit_rate'])  # w bps chyba
                            # bitrate = (bit_rate_v + bit_rate_a) / 1000
                            # fflog(f'{bitrate=}  ({round(bitrate/1000, 2)} Mbps)',1,1)
                            try:
                                duration_v = float(einfo['info']['video']['duration'])
                            except:
                                duration_v = duration_secs
                            try:
                                duration_a = float(einfo['info']['audio']['duration'])
                            except:
                                duration_a = duration_v
                            size = bit_rate_v * duration_v / 8 + bit_rate_a * duration_a / 8
                            if size >= 1024**3:
                                size = str(round(size / 1024**3, 2)) + " GB"
                            elif size:
                                size = str(round(size / 1024**2, 2)) + " MB"
                            # fflog(f'2 {size=}',1,1)
                        except Exception:
                            # fflog_exc(1)
                            # fflog(f'einfo={json.dumps(einfo, indent=2)}',1,1)
                            pass


                        try:
                            language = einfo['info']['audio']['tags']['language']  # nie zawsze to jest
                            # info_for_lang = einfo['info']['audio']['disposition']  # tu może być info o napisach, dubingu
                            # fflog(f'{info_for_lang=}  {title=}',1,1)
                        except Exception:
                            # fflog_exc(1)
                            # fflog(f"{json.dumps(einfo['info'], indent=2)}",1,1)
                            pass

                    if MD_sound_disallowed:
                        group_title = re.sub(r'\b(kin)o\b', r'\g<1>0', group_title, flags=re.I)  # aby nie odrzucał gdy jest wybrany filtr odrzucania dźwięku z kina
                        pass

                    if language == 'pol':
                        language = 'pl'
                        pass
                    if language != 'pl': 
                        lang_detected, info_for_lang = source_utils.get_lang_by_type(title + f' | {group_title}')
                        info += info_for_lang + ' | '
                        if lang_detected:
                            language = lang_detected
                    if language != 'pl' and all_languages:
                        if polskie_oznaczenia1_re.search(combined_name):
                            language = 'pl'
                            
                    tech_info = tech_info.replace('  ', ' ').replace(' | | ', ' | ').strip(' |')
                    if tech_info:
                        # info += f" | ({tech_info})"
                        info += f" | [LIGHT]({tech_info})[/LIGHT]"

                    if size:
                        info += f" | {size}"
                        pass

                    if 1:  # do debugu się przydaje
                        title = title.strip(' |')
                        if 1:
                            title += f' | {group_title}'  # nazwa kategorii w jakiej zostało to umieszczone
                        title = title.strip(' |')
                        if 0:  # debug
                            title += f' | {movie_url.rpartition("/")[-1]}'  # nazwa pliku, ale to tylko numer

                    if re.search(r"\bMULTI\b", title,):
                        # info += " MULTI"
                        pass

                    title = title.replace(' | | ', ' | ').strip(' |')
                    title = title.replace('  ', ' ')

                    source_entry = {
                        # 'provider': 'dupa',  # tylko, że sie resolver nie wywoła
                        # 'source': source_info,
                        'source': host_name,
                        'quality': quality,
                        'language': language,
                        'url': movie_url,
                        'info': info.strip(' |'),
                        'info2': ' ',
                        'info2': title,
                        # 'filename': title,
                        'direct': True,
                        'debridonly': False,
                        'premium': True,
                    }
                    
                    # Dodaj informację o źródle w nazwie (dla użytkownika)
                    # przeniosłem to wyżej
                    # if self.search_mode == 'all':
                        # source_entry['info'] = f"{host_name} ({source_info})"
     
                    if unsure:
                        source_entry['unsure'] = unsure
                        pass

                    if size:
                        source_entry['size'] = size
     
                    sources_list.append(source_entry)

                except Exception:
                    fflog_exc(1)
            
            # Wyczyść zapisane URL po użyciu
            if hasattr(self, 'all_found_urls'):
                self.all_found_urls = []
            # fflog('koniec sources',1,1)
            fflog(f'{len(sources_list)=}',1,1)
            return sources_list
            
        except Exception:
            fflog_exc(1)
            return []


    def resolve(self, url):
        if 1:
            return url + "|User-Agent=vlc&verifypeer=false"
        return url


    def check_account(self):
        fflog(f'checking ... ',1,1)
        try:
            if not self.monitor:
                self.monitor = xbmc.Monitor()
            if not self.url:
                self._get_x_sources()
            content = self._download_from_url(self.url)
            if not content:
                fflog(f'problem, bo {content=}',1,1)
            else:
                content = json.loads(content)
            username = ''
            if content:
                # fflog(f'content={json.dumps(content, indent=2)}',1,1)
                server_time = content.get("server_info", {}).get("time_now")
                fflog(f'{server_time=}',1,1)
                content = content.get("user_info", {})
                from datetime import datetime
                exp_date = str(datetime.fromtimestamp(int(content.get('exp_date') or 0)))
                username = content.get('username')
                results = ''
                # results += f" username: {content.get('username')}"
                results += f" status: {content.get('status')}"
                results += f"\n exp_date: {exp_date}"
                results += f"\n max_connections: {content.get('max_connections')}"
                results += f"\n active_cons: {content.get('active_cons')}"
                results += f"\n is_trial: {content.get('is_trial')}"
                # fflog(f'\n{results}',1,1)
            else:
                results = "Problem z otrzymaniem danych"
            # import xbmcgui
            tytul_okna = '[LIGHT]Informacje o koncie[/LIGHT]'
            if username:
                tytul_okna += f" {username}"
            xbmcgui.Dialog().ok(tytul_okna, results)
        except Exception:
            fflog_exc(1)