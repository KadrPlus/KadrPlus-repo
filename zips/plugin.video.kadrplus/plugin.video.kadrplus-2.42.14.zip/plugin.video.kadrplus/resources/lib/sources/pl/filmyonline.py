from resources.lib.sources.pl._obejrzyj_filmy_api import ObejrzyjFilmyBase

class source(ObejrzyjFilmyBase):
    PROVIDER = 'filmyonline'
    URL = 'https://filmyonline.cc/'
    HAS_TMDB_SUPPORT = False
