# -*- coding: utf-8 -*-
"""
Kadr+ - źródło: DramaQueen (plugin.video.dramaqueen)
Portowane z FanFilm 2026-04-26 do architektury ptw.

Odczytuje linki z cache.db wtyczki DramaQueen (sqlite3).
Odtwarzanie przez plugin.video.dramaqueen w trybie ListLinks.
Wymaga zainstalowanej i skonfigurowanej wtyczki DramaQueen.
"""

import hashlib
import json
import os
import time
from sqlite3 import dbapi2 as sqlite
from urllib.parse import urlencode

import xbmcaddon
import xbmcvfs

from ptw.libraries import cleantitle, control, title_matcher
from ptw.libraries.log_utils import fflog
from ptw.debug import fflog_exc

DQ_PLUGIN = 'plugin.video.dramaqueen'

# Klucz cache MD5("get_json_()_{}") — stały klucz w DQ
_DQ_CACHE_KEY = hashlib.md5('get_json_()_{}'.encode()).hexdigest()

_CONTINUATION_SUFFIXES = ('part', 'season')

_DQ_COUNTRY_KEYS = {
    'KR': {'Drama Koreańska', 'Film Korea'},
    'JP': {'Drama Japońska', 'Film Japonia'},
    'CN': {'Dramy Inne', 'Filmy Pozostałe'},
    'TW': {'Dramy Inne', 'Filmy Pozostałe'},
    'HK': {'Dramy Inne', 'Filmy Pozostałe'},
}

# Kraje azjatyckie obsługiwane przez DQ
_ASIAN_COUNTRIES = set(_DQ_COUNTRY_KEYS.keys())


class source:
    def __init__(self):
        self.priority  = 1
        self.language  = ['pl']
        self.domains   = ['dramaqueen']
        self.available = True
        self._db_path  = None
        self.icon      = ''
        self._initialized = False

    def _init(self):
        if self._initialized:
            return self.available
        self._initialized = True

        try:
            if not control.condVisibility(f'System.AddonIsEnabled({DQ_PLUGIN})'):
                fflog('[dramaqueen] wtyczka DramaQueen nie jest włączona')
                self.available = False
                return False

            dq_addon      = xbmcaddon.Addon(DQ_PLUGIN)
            self.icon     = dq_addon.getAddonInfo('icon')
            data_dir      = xbmcvfs.translatePath(f'special://profile/addon_data/{DQ_PLUGIN}')
            self._db_path = os.path.join(data_dir, 'cache.db')
            return True
        except Exception as e:
            fflog(f'[dramaqueen] init error: {e}')
            self.available = False
            return False

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        if not self._init():
            return None
        try:
            fflog(f'[dramaqueen] szukam film "{title}" ({year})')
            results = self._search(title, localtitle, year, 'movie')
            if not results:
                fflog('[dramaqueen] brak wyników (film)')
                return None
            play_data = [
                self._make_play_data(show, ep)
                for show in results
                for ep in show.get('episodes', [])
                if ep.get('links')
            ]
            fflog(f'[dramaqueen] found {len(play_data)} movie source(s)')
            return play_data or None
        except Exception:
            fflog_exc(1)
            return None

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        if not self._init():
            return None
        try:
            fflog(f'[dramaqueen] szukam serial "{tvshowtitle}" ({year})')
            results = self._search(tvshowtitle, localtvshowtitle, year, 'drama')
            if not results:
                fflog('[dramaqueen] brak wyników (serial)')
                return None
            return results
        except Exception:
            fflog_exc(1)
            return None

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        if not self._init():
            return None
        try:
            if not url:
                return None
            shows     = url if isinstance(url, list) else [url]
            ep_target = int(episode)
            offset    = 0
            for show in shows:
                eps      = show.get('episodes', [])
                local_ep = ep_target - offset
                matched  = next(
                    (ep for ep in eps
                     if str(ep.get('episode', '')) == str(local_ep) and ep.get('links')),
                    None
                )
                if matched:
                    fflog(f'[dramaqueen] znaleziono odcinek {ep_target} (local={local_ep}) w "{show.get("title")}"')
                    return [self._make_play_data(show, matched)]
                offset += len(eps)
            fflog(f'[dramaqueen] brak odcinka {ep_target}')
            return None
        except Exception:
            fflog_exc(1)
            return None

    def sources(self, url, hostDict=None, hostprDict=None):
        src_list = []
        if not self.available:
            return src_list
        try:
            if not url:
                return src_list
            items = url if isinstance(url, list) else [url]
            for item in items:
                if not isinstance(item, dict) or not item.get('ep_links'):
                    continue
                plugin_url = f'plugin://{DQ_PLUGIN}/?' + urlencode({
                    'mode': 'ListLinks',
                    'name': item.get('ep_title', ''),
                    'data': repr(item),
                })
                src_list.append({
                    'source':    'DramaQueen',
                    'quality':   '1080p',
                    'language':  'pl',
                    'url':       plugin_url,
                    'info':      '',
                    'direct':    True,
                    'debridonly': False,
                    'icon':      self.icon,
                    'premium':   True,
                    'external':  True,
                })
        except Exception:
            fflog_exc(1)
        fflog(f'[dramaqueen] sources: {len(src_list)}')
        return src_list

    def resolve(self, url):
        return url

    # ── helpers ────────────────────────────────────────────────────────────

    @staticmethod
    def _is_continuation_suffix(suffix):
        return bool(suffix) and (suffix[0].isdigit() or suffix.startswith(_CONTINUATION_SUFFIXES))

    def _get_dq_data(self):
        if not self._db_path or not os.path.exists(self._db_path):
            fflog('[dramaqueen] cache.db nie znaleziony')
            return None
        try:
            uri  = f'file:{self._db_path}?mode=ro'
            conn = sqlite.connect(uri, uri=True, timeout=5)
            try:
                cur = conn.cursor()
                cur.execute('SELECT value, date FROM cache WHERE key=?', (_DQ_CACHE_KEY,))
                row = cur.fetchone()
            finally:
                conn.close()
        except Exception as e:
            fflog(f'[dramaqueen] błąd odczytu cache.db: {e}')
            return None

        if not row or not row[0]:
            fflog('[dramaqueen] brak danych w cache')
            return None

        age_h = (time.time() - row[1]) / 3600
        fflog(f'[dramaqueen] cache age {age_h:.1f}h')

        try:
            return json.loads(row[0])
        except Exception as e:
            fflog(f'[dramaqueen] JSON parse error: {e}')
            return None

    def _get_country_keys(self, aliases):
        """Zwraca dozwolone kategorie DQ wg kraju produkcji."""
        try:
            country_codes = set()
            for a in (aliases or []):
                c = (a.get('country') or '').upper()
                if c:
                    country_codes.add(c)
            if not country_codes:
                return None
            allowed = set()
            asian = country_codes & _ASIAN_COUNTRIES
            for code in asian:
                allowed |= _DQ_COUNTRY_KEYS[code]
            return allowed
        except Exception:
            return None

    def _get_all_shows(self, allowed_keys=None):
        data = self._get_dq_data()
        if not data:
            return []
        shows = []
        for key, items in data.items():
            if key == 'genres' or not isinstance(items, list):
                continue
            if allowed_keys is not None and key not in allowed_keys:
                continue
            for item in items:
                if item and isinstance(item, dict):
                    shows.append(item)
        return shows

    def _search(self, title, localtitle, year, content_type=None, aliases=None):
        search_titles = title_matcher.title_variants(title, localtitle, aliases, max_items=10)
        search_set = {cleantitle.get_simple(t) for t in search_titles if t}
        if not search_set:
            return []

        allowed_keys = self._get_country_keys(aliases)
        if allowed_keys is not None:
            fflog(f'[dramaqueen] filtr kraju → {allowed_keys or "pusty (kraj poza DQ)"}')

        results = []
        for show in self._get_all_shows(allowed_keys):
            if content_type and show.get('type') != content_type:
                continue
            show_title = show.get('title', '')
            show_clean = cleantitle.get_simple(show_title)
            exact  = show_clean in search_set
            prefix = not exact and any(
                len(s) >= 4 and show_clean.startswith(s)
                and self._is_continuation_suffix(show_clean[len(s):])
                for s in search_set
            )
            fuzzy = title_matcher.matches_any(show_title, search_titles, threshold=82)
            if not exact and not prefix and not fuzzy:
                continue
            try:
                if year and show.get('year') and abs(int(show['year']) - int(year)) > 1:
                    continue
            except (ValueError, TypeError):
                pass
            results.append(show)

        results.sort(key=lambda s: s.get('year') or 0)
        return results

    def _make_play_data(self, show, ep):
        return {
            'type':       show.get('type', 'drama'),
            'ep_title':   ep.get('ep_title', ''),
            'ep_players': ep.get('players', []),
            'ep_links':   ep.get('links', []),
        }
