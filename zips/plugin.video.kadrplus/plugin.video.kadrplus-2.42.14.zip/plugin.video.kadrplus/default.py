import re
"""
    FanFilm Add-on
    Copyright (C) 2025 - original author MrKnow

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
def router():
    # mogę modyfikować sys.argv[2], więc dlatego poniższe potrzebne
    # import sys
    global sys  # nie wiem, czy to dobrze

    # xbmc.log(f'\n\n',1)
    # xbmc.log(f'{sys.argv[0]=}  {sys.argv[1]=}  {sys.argv[2]=}',1)
    xbmc.log(f'\n\n{sys.argv=}',1)

    if 0:
        user_locals = {k: str(v) for k, v in locals().items() if not k.startswith('__')}
        xbmc.log(" user_locals = " + str(user_locals), 1)  # powinno być pusto

        user_globals = {k: str(v) for k, v in globals().items() if not k.startswith('__')}
        import json
        xbmc.log( "user_globals = " + json.dumps(user_globals, indent=2), 1)  # tylko 4 zmienne xbmc, xbmcout, sys, router(ta funkcja)

        del user_locals, user_globals, json


    try:
        from kover import autoinstall  # noqa: F401
    except:
        pass


    from ptw.libraries import control

    if True:
        import xbmcaddon
        addon = xbmcaddon.Addon()
        # control.setting = xbmcaddon.Addon().getSetting
        control.setting = addon.getSetting
        # control.setSetting = xbmcaddon.Addon().setSetting
        control.setSetting = addon.setSetting
    # xbmc.log(f'{control.setting=}', 1)

    if control.setting("additional_working_info") == "true" or (control.infoLabel('Container.FolderPath')).startswith("plugin://plugin.video.themoviedb.helper/"):
        if not control.condVisibility('Window.IsActive(notification)'):
            control.infoDialog('', time=1, sound=False)
            control.sleep(100)
            pass  # aby móc łatwo zakomentować powyższą linijkę


    from contextlib import contextmanager
    from urllib.parse import parse_qsl, urlencode

    from ast import literal_eval

    #control.setSetting('appearance.1', 'Incursion')  # już niepotrzebne

    # addon_id = control.addon().getAddonInfo('id')
    # addon_id = control.addonInfo('id')
    addon_id = control.addonId()

    if control.infoLabel('Container.PluginName'):
        FFlastpath = control.window.getProperty('FanFilm.var.lastpath')  # z pamięci
        FFlastpath = literal_eval(FFlastpath) if FFlastpath else {}  # tylko jak Kodi wczytuje folder z cachu, to ta zmienna się nie zmienia (bo plugin nie jest wywoływany)

        prev_lastpath = control.window.getProperty('FanFilm.var.prev_lastpath')
        prev_lastpath = literal_eval(prev_lastpath) if prev_lastpath else {}
    else:
        FFlastpath = {}
        prev_lastpath = {}

    folderpath  = control.infoLabel('Container.FolderPath')
    KFolderPath = dict(parse_qsl(folderpath.split('?')[-1]))  # taki niby referer, ale nie działa prawidłowo, jak odpalamy z widgetu

    # control.log(f'DUPA {sys.argv[0]=} {sys.argv[2]=}',1)
    parts = sys.argv[0].rstrip('/').split('/')
    # control.log(f'{len(parts)=}  {parts=}',1)
    if len(parts) > 3:
        control.log(f'{sys.argv[0]=} {sys.argv[2]=}',1)
        action = parts[3]
        if action == 'play':
            content = parts[4] if len(parts) > 4 else None
            tmdb = parts[5] if len(parts) > 5 else None
            season = parts[6] if len(parts) > 6 else None
            episode = parts[7] if len(parts) > 7 else None
            new_url = f"?action={action}"
            if content:
                new_url += f"&content={content}"
            if tmdb:
                if len(tmdb) > 8:
                    try:
                        # tmdb = str(int(tmdb[1:]))
                        tmdb = str( int(tmdb) - 100_000_000 )
                    except ValueError:
                        control.log(f"może to nie tmdb, a imdb ?  {tmdb=}", 1)
                        pass
                new_url += f"&tmdb={tmdb}"
            if season:
                new_url += f"&season={season}"
            if episode:
                new_url += f"&episode={episode}"
            sys.argv[2] = new_url + sys.argv[2].replace("?", "&", 1)
            sys.argv[0] = f"plugin://{addon_id}/"
            control.log(f'{sys.argv[0]=}  {sys.argv[2]=}',1)
        elif (action == 'movie' or action == 'tvshow'):
            action = parts[4] if len(parts) > 4 else None
            if action == 'search':
                content = parts[5] if len(parts) > 5 else None
                new_url = f"?action={parts[3]}{action}{content}"
                sys.argv[2] = new_url + sys.argv[2].replace("?", "&", 1)
                sys.argv[2] = sys.argv[2].replace("searchepg&query=", "Searchterm&name=").replace("searchext&query=", "Searchterm&name=")
                sys.argv[0] = f"plugin://{addon_id}/"
                control.log(f'{sys.argv[0]=}  {sys.argv[2]=}',1)
            else:
                control.log(f'nieobsługiwany przypadek  {action=}  |  {sys.argv=}',1)
                control.infoDialog('Wystąpił jakiś błąd\n sprawdź log', sound=True, icon="WARNING", time=3000)
                control.sleep(1000)
        else:
            control.log(f'nieobsługiwany przypadek  {action=}  |  {sys.argv=}',1)
            control.infoDialog('Wystąpił jakiś błąd\n sprawdź log', sound=True, icon="WARNING", time=3000)
            control.sleep(1000)
            pass

    currentPath = dict(parse_qsl(sys.argv[2][1:]))
    #control.log(f"{currentPath=}", 1)

    referer = KFolderPath if KFolderPath != currentPath else ''
    # control.log(f'{referer=} ', 1)


    generate_short_path = control.setting("generate_short_path") == "true"

    logsilent = control.setting("logsilent") == "true"

    odwolany_test = None

    # for debug
    if 0 and currentPath.get("action") not in ["service", "libepisodesservice"]:

        control.log(f"\n\n________________________________________________________________ ", 1)

        control.log(f"{control.infoLabel('Container.PluginName')=}", 1)  # może się przydać (użyte w sources.py do detekcji czy ma być katalog czy okienko) (chyba puste, gdy odpalamy pozycje z biblioteki)
        control.log(f" ", 1)

        control.log(f" {FFlastpath=}", 1)
        control.log(f"{KFolderPath=}  ({folderpath.split('?')[0]})", 1)
        control.log(f"{currentPath=}", 1)
        control.log(f'    {referer=} ', 1)
        control.log(f" ", 1)

        # https://alwinesch.github.io/modules__infolabels_boolean_conditions.html
        control.log(f"{control.infoLabel('Container.FolderPath')=}", 1)
        control.log(f" {control.infoLabel('ListItem.FolderPath')=}", 1)
        control.log(f" {control.infoLabel('ListItem.Path')=}", 1)
        control.log(f'{control.infoLabel("ListItem.FileNameAndPath")=}', 1)
        control.log(f'{control.infoLabel("ListItem.FileName")=}', 1)
        control.log(f" ", 1)

        control.log(f'{control.infoLabel("Container.NumPages")=}', 1)
        control.log(f'{control.infoLabel("Container.CurrentPage")=}', 1)
        control.log(f'{control.infoLabel("Container.NumItems")=}', 1)
        control.log(f'{control.infoLabel("Container.NumAllItems")=}', 1)
        control.log(f" ", 1)
        control.log(f'{control.infoLabel("Container.CurrentItem")=}', 1)
        control.log(f'{control.infoLabel("ListItem.CurrentItem")=}', 1)
        control.log(f'{control.infoLabel("ListItem.FileNameAndPath")=}', 1)
        control.log(f"{control.infoLabel('ListItem.Label')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Label2')=}", 1)

        control.log(f" ", 1)
        control.log(f"{control.infoLabel('ListItem.Title')=}", 1)
        control.log(f"{control.infoLabel('ListItem.OriginalTitle')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Property(englishTitle)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.TvShowTitle')=}", 1)
        control.log(f"{control.infoLabel('Container.showtitle')=}", 1)  # nie wiem kiedy to ma działać
        control.log(f"{control.infoLabel('ListItem.Property(englishTvShowTitle)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Property(OriginalTvShowTitle)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.UniqueID(imdb)')=}", 1)  # od Kodi 19 ?
        control.log(f"{control.infoLabel('ListItem.UniqueID(tmdb)')=}", 1)  # od Kodi 19 ?
        control.log(f"{control.infoLabel('ListItem.UniqueID(tvdb)')=}", 1)  # od Kodi 19 ?
        control.log(f"{control.infoLabel('ListItem.Property(imdb_id)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Property(tmdb_id)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Property(tvdb_id)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Property(meta)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Season')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Episode')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Premiered')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Year')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Property(TvShowYear)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Country')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Plot')=}", 1)
        control.log(f"{control.infoLabel('ListItem.MPAA')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Duration')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Overlay')=}", 1)
        control.log(f"{control.infoLabel('ListItem.PlayCount')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Votes')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Property(Popularity)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Property(TotalSeasons)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Property(TotalEpisodes)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Property(fullpath)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Property(url)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Property(IsPlayable)')=}", 1)
        #control.log(f"{control.infoLabel('ListItem.IsFolder')=}", 1)  # źle, bo to jest typu bool
        control.log(f"{control.condVisibility('ListItem.IsFolder')=}", 1)  # to jest poprawne
        #control.log(f"{control.infoLabel('ListItem.Thumb')=}", 1)  #  Deprecated but still available, returns the same as ListItem.Art(thumb).
        #control.log(f"{control.infoLabel('ListItem.Icon')=}", 1)
        # control.log(f"{control.infoLabel('ListItem.ActualIcon')=}", 1)
        control.log(f"{control.infoLabel('ListItem.DBID')=}", 1)
        control.log(f"{control.infoLabel('ListItem.DBTYPE')=}", 1)
        
        control.log(f"{control.infoLabel('ListItem.Thumb')=}", 1)  # Deprecated but still available, returns the same as ListItem.Art(thumb).
        control.log(f"{control.infoLabel('ListItem.Art(thumb)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(poster)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(season.poster)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(tvshow.poster)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(banner)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(clearlogo)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(clearart)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(fanart)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(landscape)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(keyart)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(discart)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(characterart)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(dupa)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Icon')=}", 1)
        control.log(f"{control.infoLabel('ListItem.ActualIcon')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(season.banner)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(season.landscape)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(tvshow.banner)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(tvshow.clearlogo)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(tvshow.fanart)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(season.fanart)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(season.clearlogo)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(season.clearart)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(season.keyart)')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Art(season.icon)')=}", 1)
        control.log(f" ", 1)

        # to coś nie działa, albo dziwnie działa
        #control.log(f"{control.window.getProperty('LatestMovie.1.Title')=}", 1)
        #control.log(f"{control.infoLabel('Window(Home).Property(LatestMovie.1.Title)')=}", 1)
        #control.log(f" ", 1)

        control.log(f"{control.infoLabel('Container.Content')=}", 1)

        control.log(f"{control.infoLabel('Window.Property(xmlfile)')=}", 1)

        control.log(f"{control.infoLabel('System.CurrentWindow')=}", 1)
        control.log(f"{control.infoLabel('System.CurrentControl')=}", 1)
        control.log(f"{control.infoLabel('System.CurrentControlID')=}", 1)

        # import xbmcgui
        # win_id = xbmcgui.getCurrentWindowId()
        win_id = control.currentWindowId
        control.log(f"{win_id=}", 1)

        # focus_panel_id = control.getCurrentViewId()
        # control.log(f"{focus_panel_id=}", 1)

        if 0:
            # import xbmc
            # xbmc.executebuiltin('SetFocus(9000,14000)')
            # https://kodi.wiki/view/List_of_built-in_functions#GUI_control_built-in's
            # https://xbmc.github.io/docs.kodi.tv/master/kodi-base/d0/d3e/page__list_of_built_in_functions.html#built_in_functions_7
            # xbmc.executebuiltin('Control.Message(50,moveup)')
            # xbmc.executebuiltin('Control.Move(50,1)')
            # xbmc.executebuiltin('SetFocus(50,2,absolute)')
            control.execute(f'SetFocus({focus_panel_id},2,absolute)')
            control.sleep(200)
            control.log(f"{control.infoLabel('ListItem.Label')=}", 1)


        #control.log(f"{control.condVisibility('Window.IsVisible(DialogVideoInfo.xml)')=}", 1)
        #control.log(f"{control.condVisibility('Window.IsVisible(DialogBusy.xml)')=}", 1)

        control.log(f" ", 1)



    if control.infoLabel('Container.PluginName') not in ["plugin.video.kadrplus", ""]:
        control.log(f"\n[FanFilm] {control.infoLabel('Container.PluginName')=}", 1)
        pass


    params = dict(parse_qsl(sys.argv[2].replace("?", "")))

    control.log(f'\n[FanFilm] początek {params=}', not(logsilent))


    action = params.get("action")

    name = params.get("name")
    title = params.get("title")
    localtitle = params.get("localtitle") or params.get("title")
    year = params.get("year")
    imdb = params.get("imdb")
    tmdb = params.get("tmdb")
    tvdb = params.get("tvdb")
    tvshowtitle = params.get("tvshowtitle")
    season = params.get("season")
    episode = params.get("episode")
    url = params.get("url")

    # control.log(f'[FanFilm] {action=} {params=}',1)
    handle = int(sys.argv[1])
    control.log(f"[FanFilm]  {handle=}  {action=}", 1) if handle < 0 else ""


    def przekierowanie(url2, item=None, replace=1):
        url2 = sys.argv[0] + url2
        # control.log(f'[FanFilm] [przekierowanie] {url2=}',1)
        if handle > -1:
            url2 += '&r=1' if '&r=1' not in url2 else ''  # aby nie pytał ponownie
            if item:
                # control.addItem(handle, sys.argv[0]+"?action=nothing", item, False)  # opcjonalnie do odświeżenia, ale tu mi potrzebne gdy generate_short_path 
                control.addItem(handle, url2, item, True)  # opcjonalnie do odświeżenia, ale tu mi potrzebne gdy generate_short_path 
            control.directory(handle, cacheToDisc=False)  # obowiązkowo i musi być False, bo przy True nie chce robić przekierowania, gdy wyświetla stronę z cachu
            control.sleep0(100)  # potrzebne jakieś drobne opóźnienie, bo czasami nie chce się uruchomić przekierowanie
            control.log("[FanFilm] [przekierowanie] przekierowanie (odświeżenie)", 0)  # tu dodatkowe polecenie jako zwłoka przed następnym
            # control.execute('Container.Update('+ url2 +')')
            control.update(url2, replace=replace)
        else:
            control.log(f'[FanFilm] [przekierowanie] {handle=}',1)
            control.update(url2, replace=replace)
            # if replace:
                # control.execute("Container.Update(%s, replace)" % url2)
            # else:
                # control.execute("Container.Update(%s)" % url2)
        # global action
        nonlocal action
        action = "nothing"


    def obsluga_wyboru_strony(url, total_pages):
        nonlocal action  # musi być przed użyciem zmiennej
        page = params.get("page")
        if not page:
            page = dict(parse_qsl(url))
            page = page.get("page")
            # control.log(f'[FanFilm] [obsluga_wyboru_strony] {page=}',1)
        if not page:
            page = params.get("curr_page")
        if not page:
            # return globals()["action"]
            # nonlocal action
            return action
        # curr_page = params.get("curr_page")
        import xbmcgui
        while True:
            s = xbmcgui.Dialog().input(f"wpisz numer strony\n(0 - {total_pages})", type=xbmcgui.INPUT_NUMERIC)
            if not s or 0 <= int(s) <= int(total_pages):
                break
            if not xbmcgui.Dialog().yesno('Niepoprawna wartość', (f"Wpisana wartość [B]{s}[/B] jest nieprawidłowa. \nCzy chcesz poprawić? \n[COLOR gray]dozwolony zakres to 1-{total_pages}[/COLOR]")):
                s = ''
                break
        if s:
            item = None
            url2 = ""
            if s != "0":
                params.update({"page": s})
                page = s
                # control.log(f'[FanFilm] [obsluga_wyboru_strony] {url=}',1)
                import re
                url = re.sub("((?<=[?/])|&)(page|total_pages|curr_page)[=/][^&]*", "", url).replace("?&", "?").rstrip("?&")
                # control.log(f'[FanFilm] [obsluga_wyboru_strony] {url=}',1)
                if page and "page" not in url:
                    q_or_a = "&" if "?" in url else "?"
                    url += f"{q_or_a}page={page}"
                # control.log(f'[FanFilm] [obsluga_wyboru_strony] {url=}',1)
                params.update({ "url": url })
                params.pop("total_pages", None)
                params.pop("curr_page", None)
                if params.get("targetAction"):
                    params.update({ "action": params.get("targetAction") })
                    params.pop("targetAction", None)
                url2 = '?' + urlencode(params)
                # control.log(f'[FanFilm] [obsluga_wyboru_strony] {url2=}',1)
                item = control.item(" trwa zmiana ... ")
                if generate_short_path:
                    url2 = re.sub("((?<=[?/])|&)(url)[=/][^&]*", "", url2).replace("?&", "?").rstrip("?&")
                    # control.log(f'[FanFilm] [obsluga_wyboru_strony] {url2=}',1)
                    if control.infoLabel('ListItem.Property(urlDNext)'):
                        # control.log(f'[FanFilm] [obsluga_wyboru_strony] urlDNext (property)',1)
                        item.setProperty("urlDNext", url2)
                    else:
                        # control.log(f'[FanFilm] [obsluga_wyboru_strony] url (property)',1)
                        item.setProperty("url", url2)
            else:
                pass  # jeszcze nie wiem co zrobić
                control.log(f'[FanFilm] [obsluga_wyboru_strony] {s=}',1)
            if url2:
                przekierowanie(url2, item, 0)
                # nonlocal action
                action = "nothing"
            else:
                # return "BackToMain|" + globals()["action"]
                return "BackToMain|" + action
        else:
            # nonlocal action
            action = ""
        return action


    if 0:
        control.log(f"{control.infoLabel('ListItem.Label')=}", 1)
        control.log(f"{control.infoLabel('ListItem.Property(IsPlayable)')=}", 1)
        control.log(f"{control.condVisibility('ListItem.IsFolder')=}", 1)
        control.log(f'{control.setting("hosts.mode")=}', 1)
        control.log(f'{params.get("select")=}', 1)
        control.log(f"{control.infoLabel('Container.PluginName')=}", 1)


    if not action:
        control.log("[FanFilm] start default action", not(logsilent))

        # if control.setting("ptwCheck") == "true":
            # control.log("[FanFilm] checking PTW version", not(logsilent))
            # from checker import PtwModuleChecker
            # PtwModuleChecker().checkVersion()

        if control.setting("resolverCheck") == "true":
            control.log("[FanFilm] checking ResolveUrl version", not(logsilent))
            from checker import ResolveUrlChecker
            ResolveUrlChecker().checkVersion()

        control.log("[FanFilm] preparing Menu", not(logsilent))
        from resources.lib.indexers import navigator
        navigator.navigator().root()
        control.log("[FanFilm] Menu is ready", not(logsilent))

        control.window.clearProperty('FanFilm.var.curr_item_p')  # tylko, że to nie zawsze się wykona


    elif action == "installBetaResolveUrl":
        beta = params.get("beta")
        beta = int(beta) if beta is not None else 1
        from checker import ResolveUrlChecker
        ResolveUrlChecker().installBetaVersion(beta)  


    elif action == "play":

        # c = 10
        if control.window.getProperty("fanfilm.addRating_in_progress"):
            control.log('oczekiwanie na zakończenie wystawiania oceny dla TMDB',1)
            control.sleep(5000)
            pass
        while (
                control.window.getProperty("fanfilm.addRating_in_progress")
                # and c > 0
            ):
            control.log('oczekiwanie na zakończenie wystawiania oceny dla TMDB',0)
            control.sleep(1000)
            # c -= 1

        # control.sleep0(600)  # bo nie kończy się wątek playitem
        control.sleep0(100)  # bo nie kończy się wątek playitem

        control.log(f'[FanFilm]  [default.py]  {action=}',1)

        # control.log(f'DUPA {control.infoLabel("ListItem.FileName")=}',1)
        FileName = control.infoLabel("ListItem.FileName")
        control.log(f'[FanFilm]  [default.py]  {FileName=}',1)

        premiered = params.get("premiered")
        meta = params.get("meta")
        select = params.get("select")
        originalname = params.get("originalname", "")
        epimdb = params.get("epimdb", "")
        customTitles = params.get("customTitles")
        #mediatype = params.get("mediatype", "")  # może potem będzie zbędne (może season i episode wystarczy)

        refreshCache = params.get("refreshCache")
        if refreshCache and refreshCache != '0':
            control.log(f"[FanFilm] ustawienie znacznika do wyczyszczenia cache dla wszystkich serwisów, bo {refreshCache=}", not(logsilent))
            control.window.setProperty('clear_SourceCache_for', 'all')

        if not params.get("title"):
            title = control.infoLabel('ListItem.Property(englishTitle)')
            title = control.infoLabel('ListItem.OriginalTitle') if not title else title

        if not params.get("localtitle"):
            localtitle = control.infoLabel('ListItem.Title')

        if not params.get("tvshowtitle"):
            tvshowtitle = control.infoLabel('ListItem.Property(englishTvShowTitle)')
            tvshowtitle = control.infoLabel('ListItem.TvShowTitle') if not tvshowtitle else tvshowtitle
            tvshowtitle = tvshowtitle if tvshowtitle else None

        if not params.get("year"):
            year = control.infoLabel('ListItem.Property(TvShowYear)')
            year = control.infoLabel('ListItem.Year') if not year else year

        if not params.get("imdb"):
            imdb = control.infoLabel('ListItem.Property(imdb_id)')  # starsze Kodi ( < 20)
            imdb = control.infoLabel('ListItem.UniqueID(imdb)') if not imdb else imdb
            imdb = imdb if imdb else None

        if not params.get("tmdb"):
            tmdb = control.infoLabel('ListItem.Property(tmdb_id)')  # starsze Kodi ( < 20)
            tmdb = control.infoLabel('ListItem.UniqueID(tmdb)') if not tmdb else tmdb
            tmdb = tmdb if tmdb else None

        if not params.get("tvdb"):
            tvdb = control.infoLabel('ListItem.Property(tvdb_id)')  # starsze Kodi ( < 20)
            tvdb = control.infoLabel('ListItem.UniqueID(tvdb)') if not tvdb else tvdb
            tvdb = tvdb if tvdb else None

        if not params.get("meta"):
            meta = control.infoLabel('ListItem.Property(meta)')
            meta = meta if meta else None

        if not params.get("season"):
            season = control.infoLabel('ListItem.Season')
            season = season if season else None

        if not params.get("episode"):
            episode = control.infoLabel('ListItem.Episode')
            episode = episode if episode else None

        if not params.get("premiered"):
            premiered = control.infoLabel('ListItem.Premiered')

        # wykrycie, czy wywołanie jest z zewnątrz
        # obcy = not control.infoLabel("ListItem.CurrentItem")  # nie sprawdził się przy refresh
        obcy = control.infoLabel("Container.NumPages")  # moze też być CurrentPage, NumItems, NumAllItems
        # startowa = True if obcy == "" else False  # może 'Container.PluginName' by wystarczył - trzeba potestować
        obcy = not int(obcy) if obcy else False
        # control.log(f'{obcy=}', 1)
        # nie sprawdza się do końca
        # próba korekty tej zmiennej
        if FFlastpath.get("action") == "playItem":  # nie wiem, czy nie trzeba też dołożyć "showItems"
            obcy = False
            # control.log(f'{obcy=}', 1)
        # ale powyjściu z wygaszacza pokazuje, że obcy, a akcja to play
        # control.log(f'{tmdb=}', 1)
        if (
            params.get("r")
            or not obcy and tmdb is None
            or tmdb is None and KFolderPath == currentPath
            or tmdb is None and FFlastpath == currentPath  # to może pomóc
            ):
            # control.log(f'z pamieci', 1)
            zmienne = control.window.getProperty('FanFilm.var.curr_item_p')  # z pamięci
            # control.log(f'{zmienne=}', 1)
            if zmienne:
                zmienne = literal_eval(zmienne)
                # globals().update(zmienne)  # opcjonalnie (to nie działa w locals, czyli wewnątrz funkcji)
        else:
            # control.log(f'do pamieci', 1)
            #zmienne = (title, localtitle, year, imdb, tvdb, tmdb, season, episode, tvshowtitle, premiered, meta, select, customTitles, originalname, epimdb)
            zmienne = {"title":title, "localtitle":localtitle, "year":year, "imdb":imdb, "tvdb":tvdb, "tmdb":tmdb,
                       "season":season, "episode":episode, "tvshowtitle":tvshowtitle, "premiered":premiered,
                       "meta":meta, "select":select, "originalname":originalname, "epimdb":epimdb}
            control.window.setProperty('FanFilm.var.curr_item_p', repr(zmienne))  # do pamięci

            # control.log(f' [ KONTROLA ] \n{title=} \n{localtitle=} \n{year=} \n{imdb=} \n{tvdb=} \n{tmdb=} \n{season=} \n{episode=} \n{tvshowtitle=} \n{premiered=} \n{meta=} \n{select=} \n{customTitles=} \n{originalname=}  \n{epimdb=}', 1)
        #control.log(f" {control.window.getProperty('imdb_id')=}", 1)

        folderpath = control.infoLabel('Container.FolderPath')
        select = control.setting("hosts.mode") if select is None else select
        control.log(f'[FanFilm]  [default.py]  {control.setting("hosts.mode")=}  {select=}', 1)
        # if select == "1" and folderpath.startswith("plugin://plugin.video.themoviedb.helper/"):  # może dałoby się zrobić bardziej uniwersalnie ?
        #if select == "1" and not control.infoLabel("Container.PluginName"):  # próba uniwersalności
        if select == "1" and "plugin.video.kadrplus" not in control.infoLabel("Container.PluginName"):  # próba uniwersalności
            select = "0"
        #elif select == "0" and handle > 0 and not folderpath.startswith("plugin://plugin.video.themoviedb.helper/"):
        #elif select == "0" and handle > 0 and control.infoLabel("Container.PluginName") and not control.infoLabel("ListItem.FolderPath"):
        elif (select == "0" or select == "2") and handle >= 0 and control.infoLabel("Container.PluginName") and not control.infoLabel("ListItem.FolderPath"):
            select = "1"  # pomaga wyświetlać katalogi, gdy user ustawił okienko  # tu nie, aby nie robić przekierowania (szkoda), bo warunki się zmieniają (te 2 na końcu), ale sources.py już to ustawia
            pass
            control.log(f'{control.infoLabel("Container.PluginName")=}', 0)
            control.log(f'{control.infoLabel("ListItem.FolderPath")=}', 0)
        # control.log(f"{select=}", 1)

        # powyższa ewentualna zmiana select chyba tylko potrzebna do warunku kolejnej linijki

        # if control.setting("generate_short_path") == "true" and (params.get("title") or params.get("tvshowtitle")) and select == "1" and not params.get("r"):
        if control.setting("generate_short_path") == "true" and (params.get("title") or params.get("tvshowtitle")) and select == "1" and not params.get("r") and control.infoLabel("Container.PluginName"):
            if KFolderPath.get("r"):
                control.log("aby nie powstała nieskończona pętla", not(logsilent))
                control.directory(handle, cacheToDisc=False)  # obowiązkowo
                control.sleep0(100)
                control.log("akcja wstecz", not(logsilent))
                control.execute('Action(Back)')
                action = "nothing"
            else:
                control.window.setProperty('FanFilm.var.before_r', repr(params))  # do pamięci
                """
                import json
                try:
                    meta = json.loads(meta)
                except:
                    meta = {}
                for k,v in params.items():
                    if k not in ["meta", "action"]:
                    #if k not in zmienne:
                        meta.update({k: v})

                # są potrzebne korekty pod FF
                if (val := meta.get("localtitle")):
                    meta.update({"title": val}); meta.pop('localtitle')
                if (val := meta.get("localtvshowtitle")):
                    meta.update({"tvshowtitle": val}); meta.pop('localtvshowtitle')
                # jeszce potrzeba korekt na thumb i poster

                meta = json.dumps(meta)
                zmienne.update({"meta": meta})
                control.window.setProperty('FanFilm.var.curr_item_p', repr(zmienne))  # do pamięci jeszcze raz
                """
                #sign = "-" if not control.infoLabel("ListItem.FolderPath") else ""  # to nic nie dało
                # control.addItem(handle, sys.argv[0]+"?action=play&r=1", control.item(" proszę czekać ..."), True)  # opcjonalnie
                control.addItem(handle, sys.argv[0]+"?action=nothing", control.item(" proszę czekać ..."), False)  # opcjonalnie
                control.directory(handle, cacheToDisc=False)  # obowiązkowo i musi być False, bo przy True nie chce robić przekierowania, gdy wyświetla stronę z cachu
                control.sleep0(100)
                control.log("przekierowanie (odświeżenie) z obcięciem parametrów", 0)  # tu dodatkowe polecenie jako zwłoka przed następnym
                control.execute('Container.Update(' + sys.argv[0]+f"?action={action}&r=1" + ')')
                action = "nothing"
        else:
            if select == "0":
                control.busy()
                control.sleep(500)

            from ptw.libraries import sources
            if customTitles:
                if zmienne:
                    zmienne.update({"customTitles": customTitles})
                sources.sources().alterSources(zmienne)
            else:
                #sources.sources().play(title, localtitle, year, imdb, tvdb, tmdb, season, episode, tvshowtitle, premiered, meta, select, originalname=originalname, epimdb=epimdb)
                if zmienne:
                    #sources.sources().play(*zmienne)
                    zmienne.update({"FileName": FileName})
                    control.log("przechodzę do metody play w klasie sources(.py)", 1)
                    sources.sources().play(**zmienne)
                else:
                    control.log("pojawił się problem", 1)
                    control.infoDialog('pojawił się problem', time=1, sound=True)
                    action = ""
                    pass

            if control.setting("srefresh") == "true":
                control.log(f"[deafult]  {action=}  {select=}  {FFlastpath.get('action')=}  {episode=}  {control.infoLabel('Container.PluginName')=}  {referer=}",1)
                allowed_last_actions = ["playItem"]
                if control.window.getProperty("fanfilm.addRating_took_place"):
                    control.window.clearProperty("fanfilm.addRating_took_place")
                    allowed_last_actions.append("play")
                # add_rating_for_tmdb = control.setting("add_rating_for_tmdb") == "true" and (
                    # control.setting("add_rating_for_tmdb.movies") == "true" if not episode
                    # else control.setting("add_rating_for_tmdb.episodes") == "true" )
                # if add_rating_for_tmdb:
                    # allowed_last_actions.append("play")  # "play" przydaje się, gdy włączone jest ocenianie
                control.log(f"[deafult]  {action=}  {allowed_last_actions=}",1,1)
                if action and FFlastpath.get('action') in allowed_last_actions and (select == "1" or episode):  # w serialach zawsze jest przejście przez katalog
                    control.log(f'[deafult] {action=}  odświeżam skórkę',1)
                    control.execute('ReloadSkin()')
                    control.log(f'[deafult] {action=}  poszło asynchronicznie',1)
                    control.log(f'[deafult] {action=}  teraz odczekuję chwilę',1)
                    control.sleep(300)  # na szybszych maszynach można spróbować 200
                    control.log(f'[deafult] {action=}  koniec elif-a',1)
            control.window.clearProperty("fanfilm.addRating_took_place")

            if select == "0":
                control.idle(2)
                pass



    elif action == "showItems":  # to chyba, gdy ze "śmieci" odtwarzamy
        if not (title := params.get("title")):    
            # title = control.infoLabel('ListItem.OriginalTitle')
            title = control.infoLabel('ListItem.Property(title)')
            if title:
                # control.log(f'do pamieci', 1)
                control.window.setProperty('FanFilm.var.title', title)  # do pamięci
            else:
                # control.log(f'z pamieci', 1)
                title = control.window.getProperty('FanFilm.var.title')  # z pamięci
        #control.log(f"{title=}", 1)
        from ptw.libraries import sources
        sources.sources().showItems(title, params.get("items"), params.get("trash"), season, episode)

        if control.setting("srefresh") == "true":
            control.log(f"[deafult]  {action=}  {FFlastpath.get('action')=}  {control.infoLabel('Container.PluginName')=}  {referer=}",1)
            if FFlastpath.get('action') in ["playItem"]:
                control.log(f'[deafult] {action=}   odświeżam skórkę',1)
                control.execute('ReloadSkin()')
                control.log(f'[deafult] {action=}   poszło asynchronicznie',1)
                control.log(f'[deafult] {action=}   teraz odczekuję chwilę',1)
                control.sleep(300)  # na szybszych maszynach można spróbować 200
                control.log(f'[deafult] {action=}   koniec elif-a',1)


    elif action == "telegramResults":
        title = params.get("title") or control.infoLabel('ListItem.Title') or None
        source = params.get("source") or control.infoLabel('ListItem.Property(source)') or None
        meta = params.get("meta") or control.infoLabel('ListItem.Property(meta)') or None
        try:
            from resources.lib.sources.tg import telegram
            telegram.source().directory_from_source(source, meta=meta, title=title)
        except Exception:
            from ptw.debug import fflog_exc
            fflog_exc(1)
            control.directory(handle, cacheToDisc=False)


    elif action == "playItem":
        title = params.get("title") or control.infoLabel('ListItem.Title') or None
        source = params.get("source") or control.infoLabel('ListItem.Property(source)') or None
        meta = params.get("meta") or control.infoLabel('ListItem.Property(meta)') or None

        auto_select_next_item_to_play = params.get("auto_select_next_item_to_play")
        if control.window.getProperty('FanFilm.var.url.auto_select_next_item_to_play'):
            temp = control.window.getProperty('FanFilm.var.url.auto_select_next_item_to_play')
            control.window.clearProperty('FanFilm.var.url.auto_select_next_item_to_play')
            if "|" in temp:
                temp = temp.split("|")
                import time
                if ( int(time.time()) - int(temp[1]) ) < 10:  # 10 sekund
                    temp = temp[0]
                else:
                    temp = None
            auto_select_next_item_to_play = temp

        # url = params.get("url")
        if not url:
            control.log(f'[deafult] {action=} brak url-a {url=}',1)
            from ptw.libraries import sources
            ok = sources.sources().playItem(title, source, meta, imdb, tmdb, season, episode, auto_select_next_item_to_play=auto_select_next_item_to_play)
            control.log(f'[deafult] {action=} {ok=}',1)
            if 1:
                if ok is not None:
                    odwolany_test = True
                    pass
                if ok is False:
                    control.log(f'[deafult] {action=} trzeba by dodać pusty katalog',1)
                    # trzeba dodać pusty katalog
                    # odwolany_test = True
                    control.log(f'[FanFilm] {action=} dodanie pustego katalogu', not(logsilent))  # potrzebne tylko, gdy akcja została wywoływana jako folder, a nie wygenerowała żadnej zawartości
                    updateListing = True if params.get("r") else False  # True świadczy, że po drodze było odświeżanie
                    control.directory(handle, cacheToDisc=False, updateListing=updateListing)  # w Kodi 19 może pojawiś się czasami WARNING w logach (że niepotrzebnie czasami taka operacja), ale w nowszych nie widziałem
                    # control.sleep0(100)
        else:
            # eksperyment
            control.log(f'[deafult] {action=} jest url (jakiś eksperyment)',1)
            hosting = params.get("hosting")
            customPlayer = params.get("customPlayer")
            season = None if season == "None" else season
            episode = None if episode == "None" else episode
            from ptw.libraries.player import player
            ok = player().run(title, year, season, episode, imdb, tvdb, tmdb, url, meta=meta, hosting=hosting, customPlayer=customPlayer)
            # ok is False świadczy o błędzie - nie doszło do odtworzenia (setResolvedUrl)


    elif action == "movieNavigator":
        from resources.lib.indexers import navigator
        navigator.navigator().movies()


    elif action == "movieliteNavigator":
        from resources.lib.indexers import navigator
        navigator.navigator().movies(lite=True)


    elif action == "mymovieNavigator":
        from resources.lib.indexers import navigator
        navigator.navigator().mymovies()


    elif action == "mymovieliteNavigator":
        from resources.lib.indexers import navigator
        navigator.navigator().mymovies(lite=True)


    elif action == "tvNavigator":
        from resources.lib.indexers import navigator
        navigator.navigator().tvshows()


    elif action == "tvliteNavigator":
        from resources.lib.indexers import navigator
        navigator.navigator().tvshows(lite=True)


    elif action == "mytvNavigator":
        from resources.lib.indexers import navigator
        navigator.navigator().mytvshows()

    elif action == "publicTraktListsNavigator":
        from resources.lib.indexers import navigator
        navigator.navigator().publicTraktListsNavigator()


    elif action == "downloadNavigator":
        from resources.lib.indexers import navigator
        navigator.navigator().downloads()


    elif action == "libraryNavigator":
        from resources.lib.indexers import navigator
        navigator.navigator().library()


    elif action == "toolNavigator":
        from resources.lib.indexers import navigator
        navigator.navigator().tools()



    elif action == "searchNavigator":
        from resources.lib.indexers import navigator
        navigator.navigator().search()


    elif action == "viewsNavigator":
        from resources.lib.indexers import navigator
        navigator.navigator().views()


    elif action == "cacheNavigator":
        from resources.lib.indexers import navigator
        navigator.navigator().cache()


    elif action == "clearLibCache":
        from resources.lib.indexers import navigator
        navigator.navigator().clearLibCache()


    elif action == "clearCache":
        from resources.lib.indexers import navigator
        navigator.navigator().clearCache()


    elif action == "clearCacheMeta":
        from resources.lib.indexers import navigator
        navigator.navigator().clearCacheMeta()


    elif action == "clearCacheProviders":
        from resources.lib.indexers import navigator
        navigator.navigator().clearCacheProviders()


    elif action == "clearCacheSearch":
        from resources.lib.indexers import navigator
        if navigator.navigator().clearCacheSearch(params.get("content")) is not False:
            control.refresh()


    elif action == "removeFromSearchHistory":
        from resources.lib.indexers import navigator
        if navigator.navigator().removeFromSearchHistory(params.get("term"), params.get("content")) is not False:
            control.refresh()

            
    elif action == "clearCacheAll":
        from resources.lib.indexers import navigator
        navigator.navigator().clearCacheAll()


    elif action == "clearCacheAllSilent":
        from resources.lib.indexers import navigator
        navigator.navigator().clearCacheAllSilent()


    elif action == "infoCheck":
        from resources.lib.indexers import navigator
        navigator.navigator().infoCheck("")


    elif action == "downloadManager":
        from ptw.libraries import downloader
        downloader.downloadManager()
        # after close modal window
        if not control.monitor.abortRequested():
            control.sleep(500)  # because of animation
            # handle = int(sys.argv[1])
            if handle > -1:
                control.directory(handle, cacheToDisc=False)
                control.sleep0(100)
                control.log(f"akcja wstecz (po {action})", 0)
                control.execute('Action(Back)')
                action = "nothing"


    elif action == "search_companies_by_name":
        pass
        from resources.lib.indexers import movies
        movies.movies().search_companies_by_name()


    # elif action == "movies" or action == "moviePage" or action == "multiPage" or action == "multi" or action == "collections":
    elif action in ["movies", "moviePage", "multiPage", "multi", "collections", "collectionsPage", "listPage"]:
        # control.log(f'{KFolderPath=}\n{FFlastpath=}\n{currentPath=}\n{referer=}\n{prev_lastpath=}',1)
        if not url:
            if "collectionsPage" in action or "listPage" in action:
                url = control.infoLabel('ListItem.Property(urlDNext)')
                nxt = ".next"
            else:
                url = control.infoLabel('ListItem.Property(url)')
                nxt = ""
            if url:
                # control.log(f'do pamieci {url=}', 1)
                control.window.setProperty('FanFilm.var.url'+nxt, url)  # do pamięci
            else:
                url = control.window.getProperty('FanFilm.var.url'+nxt)  # z pamięci
                # control.log(f'z pamieci {url=}', 1)
            if nxt:
                import re
                control.log(f'{nxt=}',1)
                url = re.sub("((?<=[?/])|&)page[=/][^&]", "", url).replace("?&", "?").rstrip("?&")
            page = params.get("page")
            # control.log(f'{page=}',1)
            if generate_short_path:
                if referer and referer.get("page") or not referer and prev_lastpath and prev_lastpath.get("page"):
                    page = page or 1  # to nie zawsze jest dobrze, bo np. dla list trakt
            if page and "page" not in url:
                q_or_a = "&" if "?" in url else "?"
                url += f"{q_or_a}page={page}"
        # control.log(f'{action=} {url=}', 1)
        if total_pages := params.get("total_pages") :
            action = obsluga_wyboru_strony(url, total_pages)
        if action and action != "nothing":
            if not action.startswith("BackToMain|"):
                refresh = params.get("refresh")
                category = dict(parse_qsl(url)).get("query") or ""
                # control.log(f'{action=} {category=}', 1)
                if not category:
                    item = params.get("item") or ""
                    # from urllib.parse import unquote
                    # item = unquote(item)
                    try:
                        category = item  if not item.isnumeric() or 1900 <= int(item) <= 2999  else ""
                    except:
                        pass
                    # control.log(f'{action=} {category=}', 1)
                from resources.lib.indexers import movies
                if "multi" in action:
                    movies.movies().multi(url, refresh=refresh, category=category)
                elif "collectionsPage" in action:
                    # movies.movies().collections(url, category=category)
                    movies.movies().collections(url, category=["Kolekcje", category])
                else:
                    sort_how = params.get("sort_how", "")
                    movies.movies().get(url, refresh=refresh, category=category, sort_how=sort_how)
            else:
                back_to = params.get("back_to", "")
                d_back_to = params.get("d_back_to", "")
                if back_to:
                    control.log(f' POWRÓT DO {back_to=}',1)
                    przekierowanie(f"?{back_to}")
                elif d_back_to:
                    control.log(f' POWRÓT DO {d_back_to=}',1)
                    przekierowanie(f"?{d_back_to}")
                else:
                    # from resources.lib.indexers import movies
                    if "multi" in action:
                        przekierowanie("?action=multiSearch")
                    elif "collectionsPage" in action:
                        #movies.movies().search("collection", "Kolekcje")  # tak nie, bo pod adresem kolejnej podstrony będzie inna zawartość
                        przekierowanie("?action=collectionSearch")
                    else:
                        przekierowanie("?action=movieNavigator")
                action = "nothing"


    elif action == "movieWidget":
        from resources.lib.indexers import movies
        movies.movies().widget()


    # elif action == "traktListsSearchnew":
        # q = params.get("q") or ""
        # from resources.lib.indexers import movies
        # movies.movies().search_new(s_type="trakt", q=q)


    # elif action == "traktListsSearch":
        # control.window.clearProperty('FanFilm.var.name')  # wyczyszcenie
        # from resources.lib.indexers import movies
        # movies.movies().search(s_type="trakt", category="Listy Trakt")


    elif action == "traktListsSearch":
        control.window.clearProperty('FanFilm.var.name')  # wyczyszcenie
        from resources.lib.indexers import movies
        movies.movies().search_trakt_lists()


    elif action == "personSearch":
        control.window.clearProperty('FanFilm.var.name')  # wyczyszcenie
        from resources.lib.indexers import movies
        movies.movies().search(s_type="person", category="Osoby")


    elif action == "personSearchnew":
        q = params.get("q") or ""
        from resources.lib.indexers import movies
        movies.movies().search_new(s_type="person", q=q, name=name)


    elif action == "multiSearch":
        control.window.clearProperty('FanFilm.var.name')  # wyczyszcenie
        from resources.lib.indexers import movies
        movies.movies().search(s_type="multi", category="Filmy i seriale")


    elif action == "multiSearchnew":
        q = params.get("q") or ""
        from resources.lib.indexers import movies
        movies.movies().search_new(s_type="multi", q=q, name=name)


    elif action == "collectionSearch":
        control.window.clearProperty('FanFilm.var.name')  # wyczyszcenie
        from resources.lib.indexers import movies
        # movies.movies().search(s_type="collection", category="Kolekcje")
        movies.movies().search("collection", "Kolekcje")


    elif action == "collectionSearchnew":
        q = params.get("q") or ""
        from resources.lib.indexers import movies
        movies.movies().search_new(s_type="collection", q=q)


    elif action == "movieSearch":
        control.window.clearProperty('FanFilm.var.name')  # wyczyszcenie
        from resources.lib.indexers import movies
        movies.movies().search(category="Filmy")


    elif action == "movieSearchnew":
        q = params.get("q") or ""
        askforyear = params.get("askforyear")
        from resources.lib.indexers import movies
        movies.movies().search_new(q=q, askforyear=askforyear, name=name)


    # elif action == "movieSearchterm" or action == "personSearchterm" or action == "multiSearchterm" or action == "collectionSearchterm":
    elif action in ["movieSearchterm", "personSearchterm", "multiSearchterm", "collectionSearchterm"]:
        if not params.get("name"):
            folderpath = control.infoLabel('Container.FolderPath') 
            referer = dict(parse_qsl(folderpath.split('?')[-1]))
            # if referer.get("action") == "movieSearch":
            if referer.get("action") in ["movieSearch", "personSearch", "multiSearch", "collectionSearch"]:
                name = control.infoLabel('ListItem().Label')  # z wybranej pozycji
                control.window.setProperty('FanFilm.var.name', name)  # do pamięci
                # control.log(f'do pamieci', 1)
            else:
                name = control.window.getProperty('FanFilm.var.name')  # z pamięci
                # control.log(f'z pamieci', 1)
        from resources.lib.indexers import movies
        if action == "movieSearchterm":
            discover = params.get("discover")
            movies.movies().search_term(name, discover=discover)
        elif action == "personSearchterm":
            movies.movies().search_term(name, s_type="person")
        elif action == "multiSearchterm":
            movies.movies().search_term(name, s_type="multi")
        elif action == "collectionSearchterm":
            movies.movies().search_term(name, s_type="collection")


    elif action == "movieSearchEPG":
        # control.log(f'{action=}',1)
        # name = params.get("query") if not name else name
        if not name:
            import re
            label = control.infoLabel('ListItem().Label')
            # control.log(f'{label=}',1)
            name = re.search(r"^(.+?)(?=( \[|  \||$))", label)
            name = name[0] if name else label
            # control.log(f'{label=}',1)
            # control.log(f'{params=}',1)
            if not params.get("year"):
                year = re.search(r"(?<=\[I\]\()\d{4}(?=r\.\)\[/I\])", label)
                year = year[0] if year else control.infoLabel('ListItem().Year')
            else:  # np. '0'
                year = ""
            # control.log(f'{action=} {name=} {year=}', 1)
        if name and name != "..":
            from resources.lib.indexers import movies
            movies.movies().search_epg(name, year)
        else:
            # bo nie zachowałem w pamięci
            control.directory(handle, cacheToDisc=False)  # obowiązkowo
            control.sleep0(100)
            control.log(f'{action=} akcja wstecz',1)
            control.execute('Action(Back)')
            action = "nothing"
            pass


    elif action == "prepareItemForAddToLibrary":
        item = {}
        item.update({"fullpath": control.infoLabel('ListItem.Property(fullpath)')})
        if item.get("fullpath"):
            item.update({"label": control.infoLabel('ListItem.Label')})
            item.update({"icon": control.infoLabel('ListItem.Icon')})
            item.update({"year": control.infoLabel('ListItem.Year')})
            #from resources.lib.indexers import movies
            #movies.movies().prepareItemForAddToLibrary([item])
            items = [item]  # dla komatybilności na razie zrobiłem
            # syshandle = int(sys.argv[1])
            addonFanart, addonThumb, artPath = (control.addonFanart(), control.addonThumb(), control.artPath(),)
            for i in items:
                label = i.get("label")
                url = i.get("fullpath")
                thumb = i.get("icon")
                item = control.item(label=label)  # create ListItem
                item.setArt({"icon": thumb, "thumb": thumb, "poster": thumb, "fanart": addonFanart, })
                item.setInfo(type="Video", infoLabels={'year': i.get("year")})
                control.addItem(handle=handle, url=url, listitem=item, isFolder=True)
            control.directory(handle, cacheToDisc=True)
        else:
            control.directory(handle, cacheToDisc=False)  # obowiązkowo
            control.sleep0(100)
            # control.log("akcja wstecz", 1)
            control.execute('Action(Back)')
            action = "nothing"


    elif action == "similar" or action == "tvsimilar":
        # content = params.get("content")
        # mediatype = params.get("mediatype")
        if not params.get("tmdb"):
            tmdb = control.infoLabel('ListItem.Property(tmdb_id)')  # starsze Kodi ( < 20)
            tmdb = control.infoLabel('ListItem.UniqueID(tmdb)') if not tmdb else tmdb
            tmdb = tmdb if tmdb else None
        if "tv" in action:
            from resources.lib.indexers import tvshows
            tvshows.tvshows().similar(tmdb)
        else:
            from resources.lib.indexers import movies
            movies.movies().similar(tmdb)


    elif action == "recommendations" or action == "tvrecommendations":
        # content = params.get("content")
        # mediatype = params.get("mediatype")
        if not params.get("tmdb"):
            tmdb = control.infoLabel('ListItem.Property(tmdb_id)')  # starsze Kodi ( < 20)
            tmdb = control.infoLabel('ListItem.UniqueID(tmdb)') if not tmdb else tmdb
            tmdb = tmdb if tmdb else None
        if "tv" in action:
            from resources.lib.indexers import tvshows
            tvshows.tvshows().recommendations(tmdb)
        else:
            from resources.lib.indexers import movies
            movies.movies().recommendations(tmdb)


    elif action == "collection":
        if not params.get("tmdb"):
            tmdb = control.infoLabel('ListItem.Property(collection_id)')
            # tmdb = control.infoLabel('ListItem.Property(tmdb)') if not tmdb else tmdb
            # tmdb = control.infoLabel('ListItem.UniqueID(tmdb)') if not tmdb else tmdb
            # tmdb = control.infoLabel('ListItem.Property(url)') if not tmdb else tmdb
            tmdb = tmdb if tmdb else None
            if generate_short_path:
                if tmdb:
                    control.window.setProperty('FanFilm.var.collection_id', tmdb)  # do pamięci
                else:
                    tmdb = control.window.getProperty('FanFilm.var.collection_id')  # z pamięci
            if not tmdb:
                control.log("BŁĄD: brak zmiennej collection_id", 1)
        from resources.lib.indexers import movies
        movies.movies().collection(tmdb)


    elif action == "customMovieCriteria":
        from resources.lib.indexers import movies
        movies.movies().custom()


    elif action == "movieGenres":
        from resources.lib.indexers import movies
        movies.movies().genres()


    elif action == "movieLanguages":
        from resources.lib.indexers import movies
        movies.movies().languages()


    elif action == "movieCertificates":
        from resources.lib.indexers import movies
        movies.movies().certifications()


    elif action == "movieYears":
        from resources.lib.indexers import movies
        movies.movies().years()


    elif action == "movieYearsTop":
        from resources.lib.indexers import movies
        movies.movies().years_top()


    elif action == "moviesAwards":
        from resources.lib.indexers import movies
        movies.movies().awards()


    elif action == "movieCompanies":
        from resources.lib.indexers import movies
        movies.movies().companies()


    elif action == "findMediaWithPerson":
        # control.log(f'{referer.get("action")=}',1)
        # if referer.get("action") not in ["movies", "tvshows"]:
        if not url and generate_short_path:
            # if referer.get("action") in ["moviePerson", "tvPerson", "searchPerson"]:  # już raczej niepotrzebne
            url = control.infoLabel('ListItem.Property(urlD)')  # tylko, że przy powrocie może wziąść url od filmu a nie od osoby
            if url:
                control.window.setProperty('FanFilm.var.url.findMediaWithPerson', url)  # do pamięci
            else:
                url = control.window.getProperty('FanFilm.var.url.findMediaWithPerson')  # z pamięci
        if url:
            yatse = control.setting("yatse") == "true"
            # yatse = True  # testy
            if yatse:
                if not generate_short_path:
                    from urllib.parse import quote_plus
                    # control.addItem(handle, sys.argv[0]+f"?action=movies&url={quote_plus(url.replace('/ask_', '/movie_'))}", control.item("znajdź powiązane filmy"), True)
                    control.addItem(handle, sys.argv[0]+f"?action=movies&url={quote_plus(url.replace('/ask_', '/movie_'))}&r=1", control.item("znajdź powiązane filmy"), True)
                    # control.addItem(handle, sys.argv[0]+f"?action=tvshows&url={quote_plus(url.replace('/ask_', '/tv_'))}", control.item("znajdź powiązane seriale"), True)
                    control.addItem(handle, sys.argv[0]+f"?action=tvshows&url={quote_plus(url.replace('/ask_', '/tv_'))}&r=1", control.item("znajdź powiązane seriale"), True)
                else:
                    item = control.item("znajdź powiązane filmy")
                    item.setProperty("url", url.replace("/ask_", "/movie_"))
                    # control.addItem(handle, sys.argv[0]+"?action=movies", item, True)
                    control.addItem(handle, sys.argv[0]+"?action=movies&r=1", item, True)

                    item = control.item("znajdź powiązane seriale")
                    item.setProperty("url", url.replace("/ask_", "/tv_"))
                    # control.addItem(handle, sys.argv[0]+"?action=tvshows", item, True)
                    control.addItem(handle, sys.argv[0]+"?action=tvshows&r=1", item, True)

                control.directory(handle, cacheToDisc=True, updateListing=False)
            else:
                selected = control.dialog.contextmenu(["powiązane filmy", "powiązane seriale", "wszystkie produkcje"])
                if selected > -1:
                    # control.log(f'{sys.argv[2]=}',1)
                    # sys_argv2 = sys.argv[2]
                    if selected == 0:
                        action = "movies"
                        url = url.replace("/ask_", "/movie_")
                        # sys_argv2 = sys_argv2.replace("%2fask_", "%2fmovie_")
                    elif  selected == 1:
                        action = "tvshows"
                        url = url.replace("/ask_", "/tv_")
                        # sys_argv2 = sys_argv2.replace("%2fask_", "%2ftv_")
                    elif  selected == 2:
                        action = "multi"
                        url = url.replace("/ask_", "/combined_")
                        # sys_argv2 = sys_argv2.replace("%2fask_", "%2fcombined_")

                    # sys_argv2 = sys_argv2.replace("action=findMediaWithPerson", f"action={action}")

                    # control.log(f'url: {f"?action={action}&url={url}"}',1)

                    control.addItem(handle, sys.argv[0]+"?action=nothing", control.item(" proszę chwilkę poczekać ..."), False)  # opcjonalnie
                    control.directory(handle, cacheToDisc=False, updateListing=False)  # obowiązkowo i musi być False, bo przy True nie chce robić przekierowania, gdy wyświetla stronę z cachu
                    control.sleep0(100)

                    if generate_short_path:
                        control.window.setProperty('FanFilm.var.url', url)  # do pamięci
                        control.log("przekierowanie (odświeżenie) z obcięciem parametrów", 0)  # tu dodatkowe polecenie jako zwłoka przed następnym
                        # control.execute( 'Container.Update(' + sys.argv[0] + f"?action={action}" + ')' )
                        control.execute( 'Container.Update(' + sys.argv[0] + f"?action={action}" + '&r=1)' )
                    else:
                        control.log("przekierowanie (odświeżenie)", 0)  # tu dodatkowe polecenie jako zwłoka przed następnym
                        # control.execute( 'Container.Update(' + sys.argv[0] + sys_argv2 + ')' )
                        # control.execute( 'Container.Update(' + sys.argv[0] + sys_argv2 + '&r=1)' )
                        # albo
                        from urllib.parse import quote_plus
                        # control.execute( 'Container.Update(' + sys.argv[0] + f"?action={action}&url={quote_plus(url)}" + ')' )
                        control.execute( 'Container.Update(' + sys.argv[0] + f"?action={action}&url={quote_plus(url)}" + '&r=1)' )
                else:
                    # control.addItem(handle, sys.argv[0]+"?action=nothing", control.item(" pusta zawartość "), False)  # do testów
                    pass
        else:
            control.log("PROBLEM: brak zmiennej url", 1)


    elif action == "searchActor":
        selected = control.dialog.contextmenu(["Aktorzy filmowi", "Aktorzy serialowi"])
        if selected > -1:
            if selected == 0:
                action = "moviePerson"
            elif  selected == 1:
                action = "tvPerson"
            control.execute( 'Container.Update(' + sys.argv[0] + f"?action={action}" + ')' )
            # control.execute( 'Container.Update(' + sys.argv[0] + f"?action={action}&media_type=ask" + ')' )
            # control.sleep0(100)
            # action = "nothing"


    elif action == "contextmenu":
        lst = params.get("list")
        lst = literal_eval(lst)
        selected = control.dialog.contextmenu([l[0] for l in lst])
        if selected > -1:
            control.execute( lst[selected][1] )


    elif action == "searchPerson":
        page = params.get("page")
        if page and not url:
            url = control.infoLabel('ListItem.Property(urlDNext)')
            if url:
                # control.log(f'do pamieci', 1)
                control.window.setProperty('FanFilm.var.url.searchPerson', url)  # do pamięci
            else:
                # control.log(f'z pamieci', 1)
                url = control.window.getProperty('FanFilm.var.url.searchPerson')  # z pamięci
            import re
            url = re.sub("((?<=[?/])|&)page[=/][^&]", "", url).replace("?&", "?").rstrip("?&")
        if page and "page" not in url:
            q_or_a = "&" if "?" in url else "?"
            url += f"{q_or_a}page={page}"
        # control.log(f'{action=} {url=}', 1)
        if total_pages := params.get("total_pages"):
            action = obsluga_wyboru_strony(url, total_pages)
            # control.log(f'{action=}', 1)
        if action and action != "nothing":
            if not action.startswith("BackToMain|"):
                department = params.get("department", "all")
                media_type = params.get("media_type", "ask")
                # category = params.get("category", "")
                category = dict(parse_qsl(url)).get("query") or ""
                from resources.lib.indexers import movies  # tam umieściłem, aby nie tworzyć nowego pliku
                movies.movies().person(url, department=department, media_type=media_type, category=category)
            else:
                pass
                przekierowanie("?action=personSearch")


    elif action == "moviePerson":
        page = params.get("page")
        if page and not url:
            url = control.infoLabel('ListItem.Property(urlDNext)')
            if url:
                # control.log(f'do pamieci', 1)
                control.window.setProperty('FanFilm.var.url.moviePerson', url)  # do pamięci
            else:
                # control.log(f'z pamieci', 1)
                url = control.window.getProperty('FanFilm.var.url.moviePerson')  # z pamięci
            import re
            url = re.sub("((?<=[?/])|&)page[=/][^&]", "", url).replace("?&", "?").rstrip("?&")
        if page and "page" not in url:
            q_or_a = "&" if "?" in url else "?"
            url += f"{q_or_a}page={page}"
        # control.log(f"{url=}", 1)
        if total_pages := params.get("total_pages") :
            action = obsluga_wyboru_strony(url, total_pages)
        if action and action != "nothing":
            if not action.startswith("BackToMain|"):
                # department = params.get("department", "Acting")
                # media_type = params.get("media_type", "movie")
                # content = params.get("content", "movie")
                from resources.lib.indexers import movies
                movies.movies().person(url)
                # movies.movies().person(url, department=department, media_type=content)
            else:
                przekierowanie("?action=moviePerson")


    elif action == "moviePersons":  # chyba niewywoływane stąd
        if not url:
            control.log("BŁĄD: brak zmiennej url", 1)
        """
        if not url:
            url = control.infoLabel('ListItem.Property(url)')
            if url:
                # control.log(f'do pamieci', 1)
                control.window.setProperty('FanFilm.var.url', url)  # do pamięci
            else:
                # control.log(f'z pamieci', 1)
                url = control.window.getProperty('FanFilm.var.url')  # z pamięci
            page = params.get("page")
            if page and "page" not in url:
                q_or_a = "&" if "?" in url else "?"
                url += f"{q_or_a}page={page}"
        # control.log(f'{action=} {url=}', 1)
        """
        if total_pages := params.get("total_pages") :
            action = obsluga_wyboru_strony(url, total_pages)
        if action and action != "nothing":
            if not action.startswith("BackToMain|"):
                from resources.lib.indexers import movies
                movies.movies().persons(url)
            else:
                przekierowanie("?action=moviePersons")


    elif action == "movieUserlists":
        from resources.lib.indexers import movies
        refresh = params.get("refresh")
        # refresh = 1  # zawsze
        movies.movies().userlists(refresh=refresh)


    elif action == "channels" or action == "movieSearchFromEPG":
        from resources.lib.indexers import channels
        # channels.channels().get()
        channels.get()


    elif action == "tvshows" or action == "tvshowPage":
        if not url:
            url = control.infoLabel('ListItem.Property(url)')
            if url:
                # control.log(f'do pamieci', 1)
                control.window.setProperty('FanFilm.var.url', url)  # do pamięci
            else:
                # control.log(f'z pamieci', 1)
                url = control.window.getProperty('FanFilm.var.url')  # z pamięci
            page = params.get("page")
            # control.log(f'{page=}',1)
            if generate_short_path:
                if referer and referer.get("page") or not referer and prev_lastpath and prev_lastpath.get("page"):
                    page = page or 1  # to nie zawsze jest dobrze, bo np. dla list trakt
            if page and "page" not in url:
                q_or_a = "&" if "?" in url else "?"
                url += f"{q_or_a}page={page}"
        # control.log(f'{action=} {url=}', 1)
        if total_pages := params.get("total_pages") :
            action = obsluga_wyboru_strony(url, total_pages)
        if action and action != "nothing":
            if not action.startswith("BackToMain|"):
                refresh = params.get("refresh")
                category = dict(parse_qsl(url)).get("query") or ""
                # control.log(f'{action=} {category=}', 1)
                if not category:
                    item = params.get("item") or ""
                    # from urllib.parse import unquote
                    # item = unquote(item)
                    try:
                        category = item  if not item.isnumeric() or 1900 <= int(item) <= 2999  else ""
                    except:
                        pass
                    # control.log(f'{action=} {category=}', 1)
                from resources.lib.indexers import tvshows
                tvshows.tvshows().get(url, refresh=refresh, category=category)
            else:
                back_to = params.get("back_to", "")
                d_back_to = params.get("d_back_to", "")
                if back_to:
                    control.log(f' POWRÓT DO {back_to=}',1)
                    przekierowanie(f"?{back_to}")
                elif d_back_to:
                    control.log(f' POWRÓT DO {d_back_to=}',1)
                    przekierowanie(f"?{d_back_to}")
                else:
                    przekierowanie("?action=tvNavigator")
                action = "nothing"


    elif action == "tvSearch":
        control.window.clearProperty('FanFilm.var.name')  # wyczyszcenie
        from resources.lib.indexers import tvshows
        tvshows.tvshows().search()


    elif action == "tvSearchnew":
        q = params.get("q") or ""
        askforyear = params.get("askforyear")
        from resources.lib.indexers import tvshows
        tvshows.tvshows().search_new(q=q, askforyear=askforyear, name=name)


    elif action == "tvSearchterm" or action == "tvshowSearchterm":
        discover = params.get("discover")
        if not params.get("name"):
            folderpath = control.infoLabel('Container.FolderPath') 
            referer = dict(parse_qsl(folderpath.split('?')[-1]))
            if referer.get("action") == "tvSearch":
                name = control.infoLabel('ListItem().Label')  # z wybranej pozycji
                control.window.setProperty('FanFilm.var.name', name)  # do pamięci
                # control.log(f'do pamieci', 1)
            else:
                name = control.window.getProperty('FanFilm.var.name')  # z pamięci
                # control.log(f'z pamieci', 1)
        from resources.lib.indexers import tvshows
        tvshows.tvshows().search_term(name, discover=discover)


    elif action == "tvPerson":
        page = params.get("page")
        if page and not url:
            url = control.infoLabel('ListItem.Property(urlDNext)')
            if url:
                # control.log(f'do pamieci', 1)
                control.window.setProperty('FanFilm.var.url.tvPerson', url)  # do pamięci
            else:
                # control.log(f'z pamieci', 1)
                url = control.window.getProperty('FanFilm.var.url.tvPerson')  # z pamięci
            import re
            url = re.sub("((?<=[?/])|&)page[=/][^&]", "", url).replace("?&", "?").rstrip("?&")
        if page and "page" not in url:
            q_or_a = "&" if "?" in url else "?"
            url += f"{q_or_a}page={page}"
        if total_pages := params.get("total_pages") :
            action = obsluga_wyboru_strony(url, total_pages)
        if action and action != "nothing":
            if not action.startswith("BackToMain|"):
                from resources.lib.indexers import tvshows
                tvshows.tvshows().person(url)
            else:
                przekierowanie("?action=tvPerson")


    elif action == "tvPersons":  # już chyba niewywoływane stąd
        if not url:
            control.log("BŁĄD: brak zmiennej url", 1)
        if total_pages := params.get("total_pages") :
            action = obsluga_wyboru_strony(url, total_pages)
        if action and action != "nothing":
            if not action.startswith("BackToMain|"):
                from resources.lib.indexers import tvshows
                tvshows.tvshows().persons(url)
            else:
                przekierowanie("?action=tvPersons")


    elif action == "customTvCriteria":
        from resources.lib.indexers import tvshows
        tvshows.tvshows().custom()


    elif action == "tvGenres":
        from resources.lib.indexers import tvshows
        tvshows.tvshows().genres()


    elif action == "tvNetworks":
        from resources.lib.indexers import tvshows
        tvshows.tvshows().networks()


    elif action == "tvLanguages":
        from resources.lib.indexers import tvshows
        tvshows.tvshows().languages()


    elif action == "tvCertificates":
        certification_country = params.get("certification_country")
        from resources.lib.indexers import tvshows
        tvshows.tvshows().certifications(certification_country)


    elif action == "tvYears":
        from resources.lib.indexers import tvshows
        tvshows.tvshows().years()


    elif action == "tvYearsTop":
        from resources.lib.indexers import tvshows
        tvshows.tvshows().years_top()


    elif action == "tvUserlists":
        from resources.lib.indexers import tvshows
        refresh = params.get("refresh")
        # refresh = 1  # zawsze
        tvshows.tvshows().userlists(refresh=refresh)


    elif action == "seasons" or action == "seasons_alt":
        meta = params.get("meta")
        localtvshowtitle = params.get("localtvshowtitle")
        originaltvshowtitle = params.get("originaltvshowtitle")
        tv_episode_group_id = params.get("tv_episode_group_id") or ""
        episode_groups = params.get("episode_groups")

        if not params.get("tvshowtitle"):
            tvshowtitle = control.infoLabel('ListItem.Property(englishTvShowTitle)')
            tvshowtitle = control.infoLabel('ListItem.TvShowTitle') if not tvshowtitle else tvshowtitle
            tvshowtitle = control.infoLabel('ListItem.Property(englishTitle)') if not tvshowtitle else tvshowtitle
            tvshowtitle = control.infoLabel('ListItem.OriginalTitle') if not tvshowtitle else tvshowtitle
        if not params.get("localtvshowtitle"):
            localtvshowtitle = control.infoLabel('ListItem.TvShowTitle') 
            localtvshowtitle = control.infoLabel('ListItem.Title') if not localtvshowtitle else localtvshowtitle
        if not params.get("originaltvshowtitle"):
            originaltvshowtitle = control.infoLabel('ListItem.Property(OriginalTvShowTitle)')
            originaltvshowtitle = control.infoLabel('ListItem.OriginalTitle') if not originaltvshowtitle else originaltvshowtitle
            # control.log(f'{originaltvshowtitle=}', 1)
        if not params.get("year"):
            year = control.infoLabel('ListItem.Property(TvShowYear)')
            year = control.infoLabel('ListItem.Year') if not year else year
        if not params.get("imdb"):
            imdb = control.infoLabel('ListItem.Property(imdb_id)')
            imdb = control.infoLabel('ListItem.UniqueID(imdb)') if not imdb else imdb
        if not params.get("tmdb"):
            tmdb = control.infoLabel('ListItem.Property(tmdb_id)')
            tmdb = control.infoLabel('ListItem.UniqueID(tmdb)') if not tmdb else tmdb
        if not params.get("tvdb"):
            tvdb = control.infoLabel('ListItem.Property(tvdb_id)')
            tvdb = control.infoLabel('ListItem.UniqueID(tvdb)') if not tvdb else tvdb
        if not params.get("meta"):
            meta = control.infoLabel('ListItem.Property(meta)')
        if not params.get("tv_episode_group_id"):
            tv_episode_group_id = control.infoLabel('ListItem.Property(tv_episode_group_id)')
        if not params.get("episode_groups"):
            episode_groups = control.infoLabel('ListItem.Property(episode_groups)')

        control.log(f'{referer=}', 0)
        #if not tvshowtitle or not tmdb:  # czemu tylko tmdb a nie imdb ?
        if not tvshowtitle or not tmdb and not imdb or referer and referer.get("action") in ["seasons_alt", "episodes"]:  # próba
            control.log(f'z pamieci', 0)
            # control.log(f'{action=} {tv_episode_group_id=} {episode_groups=}', 1)
            zmienne = control.window.getProperty('FanFilm.var.curr_item_s'+action)  # z pamięci
            if zmienne:
                zmienne = literal_eval(zmienne)
                # globals().update(zmienne)  # to nie działa w locals, czyli wewnątrz funkcji
        else:
            control.log(f'do pamieci', 0)
            # control.log(f'{action=} {tv_episode_group_id=} {episode_groups=}', 1)
            #zmienne = (tvshowtitle, year, imdb, tmdb, meta)
            zmienne = {"tvshowtitle":tvshowtitle, "year":year, "imdb":imdb, "tmdb":tmdb, "tvdb":tvdb, "meta":meta, "localtvshowtitle":localtvshowtitle, "originaltvshowtitle":originaltvshowtitle, "tv_episode_group_id":tv_episode_group_id, "episode_groups":episode_groups}
            # control.log(f'{zmienne=}', 1)
            control.window.setProperty('FanFilm.var.curr_item_s'+action, repr(zmienne))  # do pamięci
        
            # control.log(f" [ KONTROLA_s ] {tvshowtitle=} {year=} {imdb=} {tmdb=} {tvdb=} {localtvshowtitle=} {originaltvshowtitle=} {tv_episode_group_id=} {episode_groups=}  {meta=}", 0)

        # select = control.setting("hosts.mode")
        select = params.get("select")
        select = control.setting("hosts.mode") if select is None else select
        item = params.get("item")
        # control.log(f"{item=}",1)
        # if control.setting("generate_short_path") == "true" and (params.get("title") or params.get("tvshowtitle")) and select == "1" and not params.get("r"):
        if item is not None and control.setting("generate_short_path") == "true" and (params.get("title") or params.get("tvshowtitle")) and select == "1" and not params.get("r"):
            # nie pamiętam po co to przekierowanie
            control.window.setProperty('FanFilm.var.before_r', repr(params))  # do pamięci
            control.addItem(handle, sys.argv[0]+"?action=nothing", control.item(" proszę czekać ..."), False)  # opcjonalnie
            control.directory(handle, cacheToDisc=False, updateListing=True)  # obowiązkowo i musi być False, bo przy True nie chce robić przekierowania, gdy wyświetla stronę z cachu
            control.sleep0(100)
            control.log("przekierowanie (odświeżenie) z obcięciem parametrów", 0)  # tu dodatkowe polecenie jako zwłoka przed następnym
            control.execute('Container.Update(' + sys.argv[0]+f"?action={action}&r=1" + ')')
            action = "nothing"
        else:
            from resources.lib.indexers import episodes
            # episodes.seasons().get(tvshowtitle, year, imdb, tmdb, tvdb, meta, localtvshowtitle=localtvshowtitle, originaltvshowtitle=originaltvshowtitle, tv_episode_group_id=tv_episode_group_id, episode_groups=episode_groups)
            episodes.seasons().get(**zmienne)


    elif action == "episodes":
        season = None if season == "" or season == "None" else season
        zmienne = None
        #if not tvshowtitle or not tmdb:  # czemu tmdb a nie imdb ?
        # if not tvshowtitle or not (tmdb and imdb):  # próba, czy będzie dobrze działać
        # NumItems = control.infoLabel("Container().NumItems")  # często pokazuje informacje przed odświeżeniem, także nieprzydatne wówczas (a jak pokazuje, to czasami jest puste a czasami 0 - i bądź tu mądry)
        # NumItems = int(NumItems) if NumItems else 0
        control.log(f'{referer=}', 0)
        # if generate_short_path and (not referer or not NumItems) or params.get("r"):  # ryzykowniejsze, bo trafiła mi się nieskończona pętla
        if generate_short_path and (not referer or referer.get("action") not in ["seasons", "calendar", "tvSearchterm", "tvshowSearchterm", "lastWatched", "movies", "seasons_alt"]) or params.get("r"):
            control.log(f'z pamieci (próba)', 0)
            zmienne = control.window.getProperty('FanFilm.var.curr_item_e')  # z pamięci
            if zmienne:
                zmienne = literal_eval(zmienne)
                # globals().update(zmienne)  # to nie działa w locals, czyli wewnątrz funkcji
            else:
                control.log(f'nieudana próba', 0)
                pass

        # globals().update(params)  # priorytet mają te podane w adresie  # to chyba niebezpieczne

        meta = params.get("meta")

        localtvshowtitle = params.get("localtvshowtitle") or ""
        originaltvshowtitle = params.get("originaltvshowtitle") or ""

        tv_episode_group_id = params.get("tv_episode_group_id")

        # if not tvshowtitle or not tmdb and not imdb:
        if not zmienne:
            # control.log(f'{generate_short_path=}  {referer=}', 1)
            if generate_short_path and referer:
                control.log(f'odczytywanie z ListItemu', 0)
                if not episode:
                    episode = control.infoLabel('ListItem.Episode')  # nie można tego przy odświeżaniu
                    episode = episode if episode else None  # ważne jest None (choć 0 i '' też daje not episode)

                if not season:
                    season = control.infoLabel('ListItem.Season')
                    season = season if season else None  # ważne tu

                if not tv_episode_group_id:
                    tv_episode_group_id = control.infoLabel('ListItem.Property(tv_episode_group_id)')

                if not meta:
                    meta = control.infoLabel('ListItem.Property(meta)')

                if not year:
                    year = control.infoLabel('ListItem.Property(TvShowYear)')
                    year = control.infoLabel('ListItem.Year') if not year else year

                if not imdb:
                    imdb = control.infoLabel('ListItem.Property(imdb_id)')
                    imdb = control.infoLabel('ListItem.UniqueID(imdb)') if not imdb else imdb

                if not tmdb:
                    tmdb = control.infoLabel('ListItem.Property(tmdb_id)')
                    tmdb = control.infoLabel('ListItem.UniqueID(tmdb)') if not tmdb else tmdb

                if not tvdb:
                    tvdb = control.infoLabel('ListItem.Property(tvdb_id)')
                    tvdb = control.infoLabel('ListItem.UniqueID(tvdb)') if not tvdb else tvdb

                if not tvshowtitle:
                    tvshowtitle = control.infoLabel('ListItem.Property(englishTvShowTitle)')
                    tvshowtitle = control.infoLabel('ListItem.TvShowTitle') if not tvshowtitle else tvshowtitle
                    tvshowtitle = control.infoLabel('ListItem.Property(englishTitle)') if not tvshowtitle else tvshowtitle
                    tvshowtitle = control.infoLabel('ListItem.OriginalTitle') if not tvshowtitle else tvshowtitle

                if not localtvshowtitle:
                    localtvshowtitle = control.infoLabel('ListItem.TvShowTitle')
                    localtvshowtitle = control.infoLabel('ListItem.Title') if not localtvshowtitle else localtvshowtitle
                    # control.log(f'{localtvshowtitle=}', 1)

                if not originaltvshowtitle:
                    originaltvshowtitle = control.infoLabel('ListItem.Property(OriginalTvShowTitle)')
                    originaltvshowtitle = control.infoLabel('ListItem.OriginalTitle') if not originaltvshowtitle else originaltvshowtitle
                    # control.log(f'{originaltvshowtitle=}', 1)

            #zmienne = (tvshowtitle, year, imdb, tmdb, meta)
            zmienne = {"tvshowtitle":tvshowtitle, "year":year, "imdb":imdb, "tmdb":tmdb, "tvdb":tvdb, "meta":meta,
                       "season":season, "episode":episode, "localtvshowtitle":localtvshowtitle, "originaltvshowtitle":originaltvshowtitle, "tv_episode_group_id":tv_episode_group_id}

            if generate_short_path:
                if not tvshowtitle or not tmdb and not imdb:  # to się bardzo przydaje
                    control.log(f'zmienne nie zostaną zapamiętane, bo {tvshowtitle=} {tmdb=} {imdb=}', not(logsilent))
                    pass
                else:
                    control.log(f'do pamieci', 0)
                    control.window.setProperty('FanFilm.var.curr_item_e', repr(zmienne))  # do pamięci

            # control.log(f" [ KONTROLA_e ] {tvshowtitle=} {year=} {imdb=} {tmdb=} {tvdb=} {season=} {episode=} {localtvshowtitle=} {originaltvshowtitle=} {tv_episode_group_id=}  {meta=}", 0)

        # select = control.setting("hosts.mode")
        select = params.get("select")
        select = control.setting("hosts.mode") if select is None else select
        # control.log(f'{select=}', 1)

        # sprawdzenie, czy zrobić jeszcze dodatkowe przekerowanie
        # a może zrobić z tego funkcję? bo się powtarza w kilku miejscach
        # control.log(f" {sys.argv=} ", 1)
        import time
        item = params.get("item")
        # control.log(f"{item=}",1)
        # if generate_short_path and (params.get("title") or params.get("tvshowtitle")) and select == "1" and not params.get("r"):
        if item is not None and generate_short_path and (params.get("title") or params.get("tvshowtitle")) and select == "1" and not params.get("r"):
            # nie pamiętam po co to przekierowanie
            if (not (r_time := control.window.getProperty('FanFilm.var.r_time')) or int(r_time) < int(time.time()) - 2):  # ma służyć przed nieskończonym przekierowaniem w niektórych sytuacjach (jak np. błąd pythona w trakcie wykonywania kodu)
                control.window.setProperty('FanFilm.var.r_time', str(int(time.time())) )  # ustawienie znacznika r
                control.log(f'będzie przekierowanie jeszcze', not(logsilent))
                control.window.setProperty('FanFilm.var.before_r', repr(params))  # do pamięci
                control.addItem(handle, sys.argv[0]+"?action=nothing", control.item(" proszę czekać ..."), False)  # opcjonalnie
                control.directory(handle, cacheToDisc=False, updateListing=True)  # obowiązkowo i musi być False, bo przy True nie chce robić przekierowania, gdy wyświetla stronę z cachu
                control.sleep0(100)
                # control.log("przekierowanie (odświeżenie) z obcięciem parametrów", 1)  # tu dodatkowe polecenie jako zwłoka przed następnym
                control.execute('Container.Update(' + sys.argv[0]+f"?action={action}&r=1" + ')')  # uruchomienie przekierowania
                action = "nothing"
            else:
                control.log(f"przekierowanie zostało zablokowane", not(logsilent))
                action = "nothing"  # nie wiem, czy dać
                pass
        else:  # można wreszcie wywołać właściwą funkcję
            from resources.lib.indexers import episodes
            # episodes.episodes().get(tvshowtitle, year, imdb, tmdb, tvdb, season, episode, meta, localtvshowtitle=localtvshowtitle, originaltvshowtitle=originaltvshowtitle, tv_episode_group_id=tv_episode_group_id)
            episodes.episodes().get(**zmienne)
            control.window.clearProperty('FanFilm.var.r_time')  # reset (może dać na sam koniec)


    elif action == "calendar":
        # control.log(f'{url=}', 1)
        if not url:
            url = control.infoLabel('ListItem.Property(url)')
            if url:
                # control.log(f'do pamieci', 1)
                control.window.setProperty('FanFilm.var.url', url)  # do pamięci
            else:
                # control.log(f'z pamieci', 1)
                url = control.window.getProperty('FanFilm.var.url')  # z pamięci
        # control.log(f'{url=}', 1)
        refresh = params.get("refresh")
        from resources.lib.indexers import episodes
        episodes.episodes().calendar(url, refresh)


    elif action == "tvWidget":
        from resources.lib.indexers import episodes
        episodes.episodes().widget()


    elif action == "calendars":
        from resources.lib.indexers import episodes
        episodes.episodes().calendars()


    elif action == "episodeUserlists":
        from resources.lib.indexers import episodes
        episodes.episodes().userlists()


    elif action == "refresh":
        from ptw.libraries import control
        control.refresh()


    elif action == "queueItem":
        from ptw.libraries import control
        control.queueItem()


    elif action == "telegramLogin":
        try:
            from resources.lib.sources.tg.telegram import source as TelegramSource
            TelegramSource().login_from_settings()
        except Exception:
            from ptw.debug import fflog_exc
            fflog_exc(1)


    elif action == "telegramClearSession":
        try:
            from resources.lib.sources.tg.telegram import source as TelegramSource
            TelegramSource().clear_session_from_settings()
        except Exception:
            from ptw.debug import fflog_exc
            fflog_exc(1)


    elif action == "openSettings":
        from ptw.libraries import control
        control.openSettings(params.get("query"))


    elif action == "artwork":
        from ptw.libraries import control
        control.artwork()


    elif action == "addView":
        from ptw.libraries import views
        views.addView(params.get("content"))


    elif action == "moviePlaycount":
        from ptw.libraries import playcount
        ok = playcount.movies(imdb, params.get("query"), tmdb)
        if ok is False:
            control.infoDialog('Wystąpił jakiś błąd', sound=True, icon="WARNING")
            pass


    elif action == "episodePlaycount":
        from ptw.libraries import playcount
        ok = playcount.episodes(imdb, tmdb, season, episode, params.get("query"))
        if ok is False:
            control.infoDialog('Wystąpił jakiś błąd', sound=True, icon="WARNING")
            pass


    elif action == "tvPlaycount":
        control.busy()
        control.sleep(400)
        from ptw.libraries import playcount
        playcount.tvshows(name, imdb, tmdb, season, params.get("query"))
        control.idle(2)


    elif action == "trailer":
        # Zamknij = False  # gdzie to ma przełożenie ?
        windowedtrailer = params.get("windowedtrailer")
        # windowedtrailer = "1"  # nie wiem, co to ma dawać, bo i tak odtwarza się na całym ekranie
        windowedtrailer = int(windowedtrailer) if windowedtrailer in ("0", "1") else 0
        if name:
            import re
            # name = re.sub(r'\[/?LIGHT]', '', name)
            # name = re.sub(r'\[/?[^]]*]', '', name)
            name = re.sub(r'\[/?[^]\[]*]', '', name)
        control.log(f'{action=}  {name=}  {url=}  {windowedtrailer=}', 1)
        from ptw.libraries import trailer
        trailer.trailer().play(name, url, windowedtrailer)


    elif action == "tmdbManager":
        overlay = params.get("overlay")
        percent = int(params.get("percent") or 0)
        progress = int(params.get("progress") or 0)
        WatchedEpisodes = int(params.get("WatchedEpisodes") or 0) # dla seriali (ilość odcinków)
        content = params.get("content")
        if content == "movie":
            from resources.lib.indexers import movies
            movies.movies().tmdbManager(content, tmdb, overlay=overlay, progress=progress)
        if content in ["tvshow", "show", "tv"]:
            content = "tv"  # powinno być tv, bo tak ma tmdb to zdefiniowane
            from resources.lib.indexers import tvshows
            tvshows.tvshows().tmdbManager(content, tmdb, overlay=overlay, WatchedEpisodes=WatchedEpisodes)
            pass
        if content == "episode":
            # chyba tylko ocenianie
            # from resources.lib.indexers import episodes
            # episodes.episodes().tmdbManager(content, tmdb, season, episode)
            pass


    elif action == "traktManager":
        from ptw.libraries import trakt
        content = params.get("content")
        overlay = params.get("overlay")
        trakt.manager(name, imdb, tmdb, content, season, episode, overlay)


    elif action == "authTrakt":
        from ptw.libraries import trakt
        result = trakt.authTrakt()
        if result:  # True
            # control.dialog.notification("FanFilm", "Trakt - operacja powiodła się\nZalecane jest ponowne uruchomienie Kodi")  # chyba niepotrzebne, jak sys.exit() załatwi sprawę
            control.dialog.notification("FanFilm", "Trakt - operacja powiodła się")
            from ptw.libraries import cache
            cache.cache_remove("", "%.trakt_%")
            # sys.exit()  # pozwala chyba przerwać sesję, aby pozbyć się zapamiętanych ustawień i niektórych zmiennych z cache
            return
        elif result is None:
            control.dialog.notification("FanFilm", "Trakt\nCoś poszło nie tak - sprawdź log")
        else:  # False
            control.dialog.notification("FanFilm", "Trakt\nPrzerwano proces")


    elif action == "pairEkino":
        from resources.lib.sources.pl import ekinotv
        ekinotv.source().pair_scraper()


    elif action == "smuSettings":
        try:
            import resolveurl
            resolveurl.display_settings()
        except Exception:
            pass


    elif action == "reset_download_paths":
        if 0:
            import os
            dataPath = control.dataPath
            movie_download_path = os.path.join(dataPath, "Movies")  # nie wiem, skąd nazwy tych folderów (czyżby Kodi miał je gdzieś ustawione?)
            tv_download_path = os.path.join(dataPath, "TVShows")  # j.w.
        else:
            dataPath = f"special://profile/addon_data/{control.addonId()}/"
            # dataPath = control.transPath(dataPath)  # niepotrzebne
            movie_download_path = dataPath + "Movies"  # nie wiem, skąd nazwy tych folderów (czyżby Kodi miał je gdzieś ustawione?)
            tv_download_path = dataPath + "TVShows"  # j.w.
        if not control.existsPath(movie_download_path):
            control.makeDirs(movie_download_path)
            if not dataPath.startswith("special://"):
                movie_download_path += os.sep
        if not control.existsPath(tv_download_path):
            control.makeDirs(tv_download_path)
            if not dataPath.startswith("special://"):
                tv_download_path += os.sep
        control.setSetting('movie.download.path', movie_download_path)
        control.setSetting('tv.download.path', tv_download_path)


    # elif action == "reset_m3u_path":
        # control.setSetting('lista_m3u.file', '')


    elif action == "reset_path":
        sid = params.get("id")
        control.log(f'[FanFilm] {action=}  {sid=}',1)
        if sid:
            control.setSetting(sid, ' ')


    elif action == "download":
        # control.log(f'{action=}', 1)
        """
        downloads = (True  if (
                                control.setting("downloads") == "true"
                                and (len(control.listDir(control.setting("movie.download.path"))[0]) > 0 
                                  or len(control.listDir(control.setting("movie.download.path"))[1]) > 0
                                  or len(control.listDir(control.setting("tv.download.path"))[0]) > 0  # seriale zawsze są (albo powinny być) w folderach
                                  or len(control.listDir(control.setting("tv.download.path"))[1]) > 0  # test
                                    )
                              )
                     else False)
        """
        downloads = (
            control.setting("downloads") == "true"
            and not (
                control.setting("movie.download.path") == ""
                or control.setting("tv.download.path") == ""
            )
        )
        if not downloads:
            control.log(f'[FanFilm] {action=}  Pobieranie niemożliwe! - sprawdź ustawienia i parametry (foldery) pobierania',1)
            control.log(f'[FanFilm] {control.setting("movie.download.path")=}',1)
            control.log(f'[FanFilm] {control.setting("tv.download.path")=}',1)
            control.infoDialog('Pobieranie niemożliwe!\nsprawdź ustawienia i parametry (foldery) pobierania', sound=True, icon="ERROR")
            action = "nothing"
        else:
            control.busy()
            control.sleep(200)
            image = params.get("image")
            extrainfo = params.get("extrainfo", "")
            season_name = params.get("season_name", "")
            Zamknij = False  # gdzie to ma przełożenie ?
            url = params.get("url")
            if not url:
                source = params.get("source")
                from ptw.libraries import sources
                import json
                url = sources.sources().sourcesResolve(json.loads(source)[0], True)  # jak wywołanie jest z folderu (nie z okna)
            from ptw.libraries import downloader
            downloader.download(name, image, url, extrainfo, season_name)
            control.idle(2)


    elif action == "alterSources":
        #if not url:
            #control.log("BŁĄD: brak zmiennej url", 1)
        from ptw.libraries import sources
        sources.sources().alterSources(url, params.get("meta"))

        
    elif action == "buyItemAgain":
        from ptw.libraries import sources
        sources.sources().playItem(title, params.get("source"), for_sourcesResolve={'for_resolve': {'buy_anyway': True}})


    elif action == "clearSources":
        from ptw.libraries import sources
        sources.sources().clearSources()


    elif action == "random":
        rtype = params.get("rtype")  # w zależności od zadanego typu

        if not url and (rtype == "movie" or rtype == "show"):
            control.log(f"[FanFilm] [default.py] [random] BŁĄD: brak zmiennej url  {rtype=}", not(logsilent))
            pass

        # tworzenie listy

        if rtype == "movie":  # odtworzy losowy film z danej listy
            from resources.lib.indexers import movies
            rlist = movies.movies().get(url, create_directory=False)  # pobranie listy filmów z danej listy (określonej adresem url)
            r = sys.argv[0] + "?action=play"

        elif rtype == "show":
            from resources.lib.indexers import tvshows
            rlist = tvshows.tvshows().get(url, create_directory=False)  # pobranie listy seriali z danej listy (określonej adresem url)
            r = sys.argv[0] + "?action=random&rtype=season"  # bo następna akcja to będzie "season"

        elif rtype == "season":
            originaltitle = params.get("originaltitle")
            from resources.lib.indexers import episodes
            rlist = episodes.seasons(specials="false").get(tvshowtitle or originaltitle or "", year, imdb, tmdb, create_directory=False, episode_groups=False, localtvshowtitle=title)  # pobranie listy sezonów?
            r = sys.argv[0] + "?action=random&rtype=episode"  # bo następna akcja to będzie "episode"

        elif rtype == "episode":  # chyba odtworzy losowy odcinek (z danego sezonu?)
            localtvshowtitle = params.get("localtvshowtitle")
            # season = params.get("season")
            # control.log(f'[FanFilm] [random] {season=}',1)
            from resources.lib.indexers import episodes
            rlist = episodes.episodes(specials="false").get(tvshowtitle, year, imdb, tmdb, tvdb, season, create_directory=False, localtvshowtitle=localtvshowtitle)  # pobranie listy odcinków dla określonego sezonu?
            r = sys.argv[0] + "?action=play"

        from urllib.parse import quote_plus
        from random import randint
        import json

        # control.log(f'[FanFilm] [random] {len(rlist)=} rlist={json.dumps(rlist, indent=2)}',1)  # wszystkie z danej listy

        select = params.get("select")
        # meta = params.get("meta")
        # premiered = params.get("premiered")
        try:
            rand = randint(1, len(rlist)) - 1  # wylosowanie elementu z listy
            # control.log(f'[FanFilm] [random] {rand=}',1)

            # control.log(f'[FanFilm] [random] wylosowany ({rand=}) {json.dumps(rlist[rand], indent=2)}',1)

            if rlist[rand].get("media_type") == "show" and rtype == "movie":  # ważne dla multi
                control.log(f'[FanFilm] [random] zmiana typu z movie na show, bo {rlist[rand].get("media_type")=}',1)
                rtype == "show"
                r = sys.argv[0] + "?action=random&rtype=season"

            for p in ["originaltitle", "title", "year", "imdb", "tmdb", "season", "episode", "tvshowtitle", "localtvshowtitle", "premiered"]:  # zebranie wybranych danych dla funkcji play (z superinfo przeważnie - wyjątek: localtvshowtitle)
                if rtype == "show" and p == "tvshowtitle":
                # if p == "tvshowtitle" and rlist[rand].get("tvshowtitle"):  # sprawdzić
                    try:
                        r += "&" + p + "=" + quote_plus(rlist[rand]["title"])
                    except Exception:
                        pass
                elif rtype == "season" and p == "localtvshowtitle":
                # if p == "localtvshowtitle" and rlist[rand].get("localtvshowtitle"):  # sprawdzić
                    try:
                        r += "&" + p + "=" + quote_plus(rlist[rand]["localtvshowtitle"])
                    except Exception:
                        pass
                else:
                    try:
                        r += "&" + p + "=" + quote_plus(rlist[rand][p])
                    except Exception:
                        pass
            # korekta
            if "?action=play" in r:  # nie wiem, czy dobrze
                # if rtype == "movie":  #  dla filmów się sprawdza (nie testowałem jeszcze na innych)
                r = r.replace("&title=", "&localtitle=").replace("&originaltitle=", "&title=")  # konwersja od superinfo

            # dodanie mety
            try:
                # r += "&meta=" + quote_plus(json.dumps(rlist[rand]))  # nie wiem
                pass
            except Exception:
                # r += "&meta=" + quote_plus("{}")
                pass

            if select and "&select=" not in r:
                r += "&select=" + select

            if rtype == "movie":
                try:
                    # control.infoDialog(rlist[rand]["title"], control.lang(32536), time=30000, )
                    control.infoDialog(rlist[rand]["title"], "wylosowano", time=3000, )
                except Exception:
                    pass
            elif rtype == "episode":
                try:
                    # label1 = rlist[rand]["tvshowtitle"] + " - Season " + rlist[rand]["season"] + " - " + rlist[rand]["title"]
                    label1 = rlist[rand].get("localtvshowtitle") or rlist[rand]["tvshowtitle"]
                    label1 += f' (sezon {rlist[rand]["season"]}, odcinek {rlist[rand]["episode"]})'
                    # label2 = control.lang(32536)
                    label2 = "wylosowano"
                    # ltime = 30000
                    control.infoDialog(label1, label2, time=3000, )
                except Exception:
                    pass

            # control.log(f'[FanFilm] [random] {select=}',1)
            # if handle < 0:
            if "?action=play" not in r or select != "1":
                control.log(f'[FanFilm] [random] {r=}',1)
                control.execute("RunPlugin(%s)" % r)
            else:
                control.log(f'[FanFilm] [random] {select=}',1)
                control.execute("Container.Update(%s)" % r)
                action = "nothing"

        except Exception:
            control.infoDialog(control.lang(32537), time=8000)


    elif action == "movieToLibrary":
        from ptw.libraries import libtools
        libtools.libmovies().add(name, title, localtitle, year, imdb, tmdb)


    elif action == "moviesToLibrary":
        #if not url:
            #control.log("BŁĄD: brak zmiennej url", 1)
        PluginName = control.infoLabel('Container.PluginName')  # jak pusty, lub nie 'plugin.video.kadrplus', to oznacza, że wywoływane z innego pluginu
        isFolder = control.condVisibility('ListItem.IsFolder')  # nie zawsze sprawdza się, bo nie zawsze potrafi odczytać prawidłową pozycję
        control.log(f"[FanFilm] {isFolder=} {PluginName=}", not(logsilent))
        if isFolder:
            control.directory(handle)
            control.sleep0(100)
            control.execute('Action(Back)')
        from ptw.libraries import libtools
        libtools.libmovies().range(url)


    elif action == "moviesMultiToLibrary":
        from ptw.libraries import libtools
        libtools.libmovies().multi(params.get("select"))


    elif action == "moviesToLibrarySilent":
        #if not url:
            #control.log("BŁĄD: brak zmiennej url", 1)
        from ptw.libraries import libtools
        libtools.libmovies().silent(url)


    elif action == "tvshowToLibrary":
        from ptw.libraries import libtools
        meta = params.get("meta")
        localtvshowtitle = params.get("localtvshowtitle")
        libtools.libtvshows().add(tvshowtitle, year, imdb, tmdb, season, episode, meta, localtvshowtitle=localtvshowtitle)


    elif action == "tvshowsToLibrary":
        #if not url:
            #control.log("BŁĄD: brak zmiennej url", 1)
        PluginName = control.infoLabel('Container.PluginName')  # jak pusty, lub nie 'plugin.video.kadrplus', to oznacza, że wywoływane z innego pluginu
        isFolder = control.condVisibility('ListItem.IsFolder')  # nie zawsze sprawdza się, bo nie zawsze potrafi odczytać prawidłową pozycję
        control.log(f"[FanFilm] {isFolder=} {PluginName=}", not(logsilent))
        if isFolder:
            control.directory(handle)
            control.sleep0(100)
            control.execute('Action(Back)')
        from ptw.libraries import libtools
        libtools.libtvshows().range(url)


    elif action == "tvshowsToLibrarySilent":
        #if not url:
            #control.log("BŁĄD: brak zmiennej url", 1)
        from ptw.libraries import libtools
        libtools.libtvshows().silent(url)


    elif action == "updateLibrary":
        from ptw.libraries import libtools
        libtools.libepisodes().update(params.get("query"))


    elif action == "moviesAndtvshowsToLibrarySilent":
        movies = int(params.get("movies") or 0)
        tvshows = int(params.get("tvshows") or 0)
        from ptw.libraries import libtools
        if movies:
            libtools.libmovies().silent(url)  
        if tvshows:
            libtools.libtvshows().silent(url)


    elif action == "tmdbauthorize":
        from ptw.libraries import tmdbauth
        # tmdbauth.Auth().create_session_id()  # v3
        tmdbauth.Auth().generate_access_token()  # v4


    elif action == "tmdbdeauthorize":
        from ptw.libraries import tmdbauth
        tmdbauth.Auth().revoke_session_id()


    elif action == "libepisodesservice":
        # przeniosłem uruchamianie do service.py
        if True:
            control.log("[FanFilm]  starting cyclic checking and updating library episodes process", not(logsilent))
            from ptw.libraries import libtools
            libtools.libepisodes().service()


    elif action == "stop_http_server":
        # import httpserver
        control.log(f"[FanFilm]  {action=}  wysłanie sygnału do zatrzymania serwera http",1)
        control.window.setProperty('FanFilm.httpserver.force_stop', "true")  # do pamięci


    elif action == "start_http_server" or action == "on_off_http_server":
        # control.log(f'{action=}',1)
        if control.window.getProperty('FanFilm.httpserver.status') and action.startswith("o"):
            control.log(f"[FanFilm]  {action=}  wysłanie sygnału do zatrzymania serwera http",1)
            control.window.setProperty('FanFilm.httpserver.force_stop', "true")  # do pamięci
        else:
            try:
                control.log(f"[FanFilm]  {action=}  próbuję wystartować serwer http",1)
                import httpserver
                import threading
                _httpd_thread = threading.Thread( target=httpserver.start, args=(False,) )
                _httpd_thread.start()
            except Exception:
                control.log(f"[FanFilm]  {action=}  wystąpił jakiś problem z tym serwerem http",1)
                from ptw.debug import log_exception, fflog_exc
                fflog_exc(1)
                pass


    elif action == "lastWatched":
        from ptw.libraries import bookmarks
        limit = int(control.setting("lastWatchedList.limit"))
        positions = bookmarks.last_positions(999)  # trzeba pobierać więcej (nie wiem ile sensownie), bo odcinki będą zmniejszały ostateczną ilość pokazywanych tytułów
        # media_type, imdb, season, episode  = position
        # lista = [{"imdb": imdb, "media_type": media_type}, ]
        # lista.append({"imdb": "tt18335752", "media_type": "episode"})  # do testów tylko
        # control.log(f'{positions=}',1)
        if positions:
            try:
                # control.log(f'{len(positions[0])=}',1)
                # if len(positions[0]) == 4:
                lista = [{ ("imdb" if p[1].startswith("tt") else "tmdb"):p[1], "media_type":p[0]} for p in positions if p[1] and p[1]!="0" and p[1]!="None"]
                # else:
                    # lista = [{"imdb":p[1], "tmdb":p[4], "media_type":p[0]} for p in positions if (p[1] and p[1]!="0" and p[1]!="None" or p[4] and p[4]!="0" and p[4]!="None")]
                    # pass
                # control.log(f'{len(lista)=}  {lista=}',1)
                lista = [i for n, i in enumerate(lista) if i not in lista[:n]]  # eliminacja dubli
                # control.log(f'{len(lista)=}  {lista=}',1)
                lista = lista[:limit]
                # control.log(f'{len(lista)=}  {lista=}',1)
            except Exception:
                from ptw.debug import log_exception, fflog_exc
                fflog_exc(1)
                lista = []
        else:
            lista = []
        # control.log(f'{len(lista)=}  {lista=}',1)
        from resources.lib.indexers import movies
        movies.movies().list_by_imdb_or_tmdb(lista, "Ostatnio oglądane")


    elif action == "removeFromBookmarks":
        content = params.get("content")
        term = control.infoLabel('ListItem.Label') or ""
        yes = control.yesnoDialog(f'Czy chcesz usunąć z lokalnej historii FanFilm[CR][B]{term}[/B] ?'+
                                   '\n[LIGHT]Spowoduje to także utratę lokalnego statusu [I]Obejrzany w FanFilm[/I][/LIGHT]'+
                                   ('\ndla wszystkich odcinków' if content=="tvshow" else '')
                                 )
        if yes:
            from ptw.libraries import bookmarks
            ok = bookmarks._delete_record(content, imdb, season, episode, tmdb)
            if ok is False:
                control.infoDialog('Wystąpił jakiś błąd', sound=True, icon="WARNING")
            control.refresh()


    elif action == "deleteFile":
        dest = params.get("file")
        control.log(f'[FanFilm] {action=}  plik {dest=}',1)
        if (
            control.yesnoDialog(
                "Czy chcesz [B]skasować[/B] następujący plik?" + f"\n\n[LIGHT][I]{dest}[/I][/LIGHT]",
                yeslabel="Skasuj",
                nolabel="Zostaw",
                heading="Wymagane potwierdzenie",
            )
        ):
            # control.log(f'[FanFilm] {action=}  plik zostanie skasowany',1)
            try:
                successed = control.deleteFile(dest)
                if not successed:
                    control.log(f'[FanFilm] {action=}  nie udało się skasować pliku',1)
                    control.infoDialog('Wystąpił jakiś błąd', sound=True, icon="ERROR")
                else:
                    # control.log(f'[FanFilm] {action=}  wymuszenie odświeżenia listy źródeł', 1)
                    # control.window.clearProperty('imdb_id')  # będzie szukał ponownie wszystkich
                    # control.window.clearProperty(self.itemRejected)  # nie wiem, czy to też potrzeba

                    # from getConstants in sources.py
                    class self: pass
                    self.itemProperty = "plugin.video.kadrplus.container.items"
                    self.itemRejected = "plugin.video.kadrplus.container.itemsRejected"
                    items = control.window.getProperty(self.itemProperty)
                    import json
                    try:
                        items = json.loads(items)
                    except:
                        items = []
                    # control.log(f'[FanFilm] {action=}  \n{len(items)=}  {items=}',1)
                    # items = [i for i in items if i.get("url")!=dest]  # przeszukuje do końca
                    flags = False
                    for i in items:
                        if i.get("url") == dest:
                            items.remove(i)
                            flags = True
                            break
                    if flags:
                        # brakuje ewentualnego przenumerowania jeszcze
                        control.window.setProperty(self.itemProperty, json.dumps(items))
                    else:
                        # control.window.clearProperty(self.itemRejected)
                        items = control.window.getProperty(self.itemRejected)
                        try:
                            items = json.loads(items)
                        except:
                            items = []
                        # control.log(f'[FanFilm] {action=}  \nitemsRejected  {len(items)=}  {items=}',1)
                        for i in items:
                            if i.get("url") == dest:
                                items.remove(i)
                                flags = True
                                break
                        if flags:
                            # brakuje ewentualnego przenumerowania jeszcze
                            control.window.setProperty(self.itemRejected, json.dumps(items))

                    control.refresh()
            except Exception:
                control.log(f'[FanFilm] {action=}  wystąpił błąd podczas kasowania pliku',1)
                pass
            control.sleep(100)


    elif action == "add_rating":  # or "delete_rating":
        # przeniosłem do zewnętrznego pliku, bo potrzebowałem wywołania synchronicznego
        from ptw.libraries.tmdb import add_rating
        content = params.get("content")  # "movie" or "tv" (or "episode")
        add_rating(content, tmdb, season, episode)


    elif action == "DeleteList":  # też można by ewentualnie przenieść do zewnętrznego pliku
        if not (
            control.yesnoDialog(
                "Czy chcesz [B]skasować[/B] listę " + f"\n\n[LIGHT][I]{name}[/I][/LIGHT]",
                yeslabel="Skasuj",
                nolabel="Zostaw",
                heading="Wymagane potwierdzenie",
            )
        ):
            # control.idle(2)
            # sys.exit()
            return

        control.busy()
        control.sleep(200)

        # if "self" not in globals():
        if "self" not in locals():
            class self:
                pass

        # self.tmdb_access_token = control.setting("tmdb.access_token") or ""  # musi byc autoryzacja v4
        # self.tm_bearer = control.setting("tm.user_bearer") or apis.tmdb_bearer  # nie wiem, czy to zastąpi session_id
        # control.log(f'{self}',1)
        # control.log(f'{self.tmdb_access_token=}',1)
        # control.log(f'{self.tm_bearer=}',1)
        # bearer = self.tmdb_access_token or self.tm_bearer
        # control.log(f'{bearer=}',1)

        from ptw.libraries import apis
        tm_user = control.setting("tm.user") or apis.tmdb_API
        tmdb_sessionid = control.setting("tmdb.sessionid") or ""
        # self.tm_user = tm_user
        # self.tmdb_sessionid = tmdb_sessionid

        list_id = params.get("id")

        tmdbuserDeleteList_link = "https://api.themoviedb.org/3/list/%%s?api_key=%s&session_id=%s" % (tm_user, tmdb_sessionid)  # delete method
        url = tmdbuserDeleteList_link % list_id

        monitor = control.monitor
        counter = 1

        import requests

        # from resources.lib.indexers import movies
        # import resources.lib.indexers.tmdb_manager  # tylko, że tam robione pod klasę
        from resources.lib.indexers.tmdb_manager import doRequest

        while True:

            tmdb_results = requests.delete(url)
            # tmdb_results = movies.movies().doRequest(url, method="delete")
            # tmdb_results = self.doRequest(url, method="delete")  # to jak w klasie
            # tmdb_results = doRequest(self, url, method="delete")  # tu jest przekazanie dodatkowej zmiennej self imitującej klasę
            # tmdb_results = None  # do testów tylko

            if not tmdb_results and tmdb_results is not None and tmdb_results.status_code == 404:  # tylko, że jak nie ma takiej listy, to ten sam kod daje ich API
                control.log(f'wystąpił jakiś problem  {tmdb_results.text=}  {url=}',1)
                try:
                    status_code = tmdb_results.json().get("status_code")
                    if status_code not in [34]:  # https://developer.themoviedb.org/docs/errors
                        break
                except:
                    break
                counter -= 1
                if counter > 0:
                    control.log(f'czekam przed ponowieniem żądania do serwera  {counter=}',1)
                    control.sleep(5000)
                    if monitor.abortRequested():
                        break
                else:
                    break
            else:
                break
        if tmdb_results is not None:
            # control.log(f'{tmdb_results=}  \n{tmdb_results.text=}  \n{url=}',1)
            pass
        else:
            control.log(f'{tmdb_results=}  \n{url=}',1)

        result = tmdb_results
        try:
            msg = result.json()
            try:
                msg = msg.get("status_message") or ""
            except:
                pass
            msg = f'\n[LIGHT][I]{msg}[/I][/LIGHT]' if msg else ""
        except:
            try:
                msg = result.text
            except:
                msg = ""
                pass

        icon = control.infoLabel("ListItem.Icon") if result else "ERROR"  # jak to działa z tym infoLabel("ListItem.Icon") ?
        control.infoDialog(
            ("NIE " if icon == "ERROR" else "") + "wykonano poprawnie" + msg,
            heading="Menadżer TMDB",
            sound=True,
            icon=icon,
        )

        if True:
            from ptw.libraries import cache
            control.log(f'usuwam z cache',1)
            # key = (self.tmdblist, self.tmdb_user_lists)  # tylko, że self.tmdblist do jest funkcja z pliku movies.py albo tvshows.py (chyba, że chodzi tylko o nazwę funkcji)
            # key = ("tmdblist", tmdb_user_lists)  # tylko, że tam jest page=1 zaszyte
            tmdbuser = control.setting("tmdb.username") or "me"  # or control.setting("tmdb.account_id")
            lang = control.apiLanguage()["tmdb"]
            tmdb_user_lists = "https://api.themoviedb.org/3/account/%s/lists?api_key=%s&language=%s&session_id=%s&page=1" % (tmdbuser, tm_user, lang, tmdb_sessionid)
            url = tmdb_user_lists
            import re
            # url = re.sub("((?<=[?/])|&)(page[=/])([^&])", lambda x: x[1]+x[2]+str(int(x[3])+1), url).replace("?&", "?").rstrip("?&")
            url = re.sub("((?<=[?/])|&)(page[=/])([^&])", r"\1\2{}", url).replace("?&", "?").rstrip("?&")
            if "{}" in url:
                for n in range(1,10):  # do ilu jechać ?
                    urlN = url.format(n)
                    key = ("%.tmdblist", urlN)
                    # control.log(f'{key=}',1)
                    status = cache.remove(*key, like=True)  # usunięcie z cache
                    if status is False:
                        if n == 1:
                            # control.log('usuwam zmienne kluczy z adresu (jeśli są)',1)
                            # url = re.sub(r"[&]?\bapi_key=[^&]*", "", url)
                            # url = re.sub(r"[&]?\bsession_id=[^&]*", "", url)
                            # url = url.rstrip("?")
                            # urlN = url.format(n)
                            # key = ("%.tmdblist", urlN)
                            # status = cache_remove(*key, like=True)  # próba usunięcia z cache
                            if status is False:
                                # control.log(f'{status=} co oznacza, że nie ma cache dla tej funkcji {key=}',1)
                                break
                        else:
                            # control.log(f'{status=} oznacza, że nie ma więcej stron',1)
                            break  # nie ma sensu próbować kolejnych stron
            else:
                key = ("%.tmdblist", url)
                # control.log(f'{key=}',1)
                status = cache.remove(*key, like=True)  # usunięcie z cache
                if status is False:
                    # control.log('usuwam zmienne kluczy z adresu (jeśli są)',1)
                    # url = re.sub(r"[&]?\bapi_key=[^&]*", "", url)
                    # url = re.sub(r"[&]?\bsession_id=[^&]*", "", url)
                    # url = url.rstrip("?")
                    # key = ("%.tmdblist", url)
                    # status = cache.remove(*key, like=True)  # usunięcie z cache
                    if status is False:
                        # control.log(f'{status=} co oznacza, że nie ma cache dla tej funkcji {key=}',1)
                        pass

        control.sleep(200)
        control.idle(2)
        control.sleep(200)
        control.refresh()


    elif action == "fix_dla_AZ2R":
        # fix na widoki MediaInfo i Tri Panel w skórce skin.arctic.zephyr.2.resurrection.mod dla wyświetlania filmów w katalogach

        # przed zmianą
        a = """    <variable name="Image_Overlay_List">
            <value condition="ListItem.IsPlaying">indicator/play.png</value>
            <value condition="ListItem.IsResumable + Integer.IsGreater(ListItem.PercentPlayed,66)">indicator/inprogress-75.png</value>
            <value condition="ListItem.IsResumable + Integer.IsGreater(ListItem.PercentPlayed,33)">indicator/inprogress-50.png</value>"""

        # tak ma być po zmianie
        b = """    <variable name="Image_Overlay_List">
            <value condition="ListItem.IsPlaying">indicator/play.png</value>
            <value condition="ListItem.IsResumable + Integer.IsGreater(ListItem.PercentPlayed,66) | [!String.IsEmpty(ListItem.Property(WatchedProgress)) + Integer.IsGreater(ListItem.Property(WatchedProgress),66) + !Integer.IsEqual(ListItem.Property(WatchedProgress),100)]">indicator/inprogress-75.png</value>
            <value condition="ListItem.IsResumable + Integer.IsGreater(ListItem.PercentPlayed,33) | [!String.IsEmpty(ListItem.Property(WatchedProgress)) + Integer.IsGreater(ListItem.Property(WatchedProgress),33) + !Integer.IsEqual(ListItem.Property(WatchedProgress),100)]">indicator/inprogress-50.png</value>"""

        from ptw.debug import log_exception, fflog, fflog_exc
        from ptw.libraries import control

        file = "special://home/addons/skin.arctic.zephyr.2.resurrection.mod/1080i/Includes_Images.xml"

        if control.existsPath(file):

            control.infoDialog(f'Czekaj ...', 'fix_dla_AZ2R', sound=False, time=1)

            fflog('wczytanie pliku',1,1)
            with control.openFile(file) as f:
                c = f.read()

            # fflog(f'{type(c)=}')
            # fflog(f'{c=}')

            fflog('próba dokonania zamian',1,1)
            d = c.replace(a, b)  
         
            if d != c:
                fflog('zapisanie pliku',1,1)
                with control.openFile(file, "w") as f:
                    f.write(d)
                control.infoDialog(f'Operacja wykonana', 'fix_dla_AZ2R', sound=True)
            else:
                fflog('nie dokonano zmian w pliku',1,1)
                control.infoDialog('nie dokonano zmian w pliku', 'fix_dla_AZ2R', sound=True, icon='WARNING')

        else:
            fflog('problem z dostępem do pliku',1,1)
            control.infoDialog('problem z dostępem do pliku', 'fix_dla_AZ2R', sound=True, icon='ERROR')


    elif action == "mac_expire_date" or action == "check_account":
        control.busy()
        control.sleep(200)
        scraper = params.get("scraper")
        import importlib
        try:
            # module = importlib.import_module(module_name)
            # module.run()
            if scraper.startswith("stalker"):
                importlib.import_module(f"resources.lib.sources.pl.{scraper}").StalkerClient().mac_expire_date()
            elif scraper.startswith("xtream"):
                getattr(importlib.import_module(f"resources.lib.sources.pl.{scraper}").source(), action)()
            else:
                control.infoDialog('Nie zdefiniowano akcji', 'Akcja FF', sound=True, icon='WARNING')
                pass
        except ModuleNotFoundError:
            raise ValueError(f"Brak modułu {scraper}")
        except AttributeError:
            raise ValueError(f"Moduł {scraper} nie ma żądanej funkcji/metody")
        finally:
            control.idle(2)
            control.sleep(100)



    elif action == "test":
        """ coś na testy """
        control.log(f'[FanFilm] {action=}',1)
        pass
        # przykład okna
        # from https://kodi.wiki/view/GUI_tutorial
        import xbmcgui
        import sys
        # import urlparse
        from urllib.parse import parse_qs

        class PopupWindow(xbmcgui.WindowDialog):
            # def __init__(self, image, line1, line2, line3, line4, line5):
            def __init__(self, image, line1="tu twój napis", line2="dryga linia", line3="", line4="", line5="", action=""):
            # def __init__(self, **kwargs):
                self.addControl( xbmcgui.ControlImage(x=25, y=25, width=150, height=150, filename=image[0]) )
                self.addControl( xbmcgui.ControlLabel(x=190, y=25, width=500, height=25, label=line1[0]) )
                self.addControl( xbmcgui.ControlLabel(x=190, y=50, width=500, height=25, label=line2[0]) )
                # self.addControl( xbmcgui.ControlLabel(x=190, y=75, width=500, height=25, label=line3[0]) )
                # self.addControl( xbmcgui.ControlLabel(x=190, y=100, width=500, height=25, label=line4[0]) )
                # self.addControl( xbmcgui.ControlLabel(x=190, y=125, width=500, height=25, label=line5[0]) )
                self.addControl( xbmcgui.ControlButton(x=190, y=150, width=500, height=25, label="guzik1") )  # potrzebna jeszcza jakaś akcja
                # control.log(f'{dir(self)=}',1)

        # if __name__ == '__main__':
        if False:
            control.log(f'[FanFilm] {__name__=}',1)
            params1 = parse_qs('&'.join(sys.argv[1:]))
            control.log(f'[FanFilm] {params1=}',1)
        else:
            data_path = control.dataPath
            import os
            qrcode_file = os.path.join(data_path, "qrcode.png")
            params1 = {"image": [qrcode_file], "line1": ["dowolny tekst"]}

        window = PopupWindow(**params1)
        window.show()
        xbmc.sleep(5000)
        # control.directory(handle)
        window.close()
        del window
        # jak wrócić focusem na Container?


    else:
        control.log(f'[FanFilm] {action=}',1)
        pass



    # control.log(f"============================================================", not(logsilent))

    # control.log(f'[FanFilm] [default.py]   {action=}', 1)
    # control.log(f'[FanFilm] [default.py]   {params=}', 1)
    # handle = int(sys.argv[1])
    # control.log(f'[FanFilm] [default.py]   {handle=}', 1)
    # control.log(f"[FanFilm] [default.py]   {control.infoLabel('Container.PluginName')=}", 1)
    if (action != "nothing"
         and control.infoLabel('Container.PluginName')  # nie dla widgetów
        # and params != KFolderPath
         and params != FFlastpath
         and action and "silent" not in action.lower()  # to próba na coś, co się robić będzie w tle (jak synchronizacja biblioteki)
         # and "silent" not in params
         # and handle > -1  # zastanowić się nad tym
       ):
        control.window.setProperty('FanFilm.var.prev_lastpath', repr(FFlastpath))
        control.window.setProperty('FanFilm.var.lastpath', repr(params))  # do pamięci

    # try to prevent infinite busydialog
    # handle = int(sys.argv[1])  # wyżej to daję
    # control.log(f"[FanFilm]  koniec  {sys.argv=}", 1)
    # control.log(f"[FanFilm]  koniec  {handle=}  {action=}", 1)
    # if handle > -1 and action not in ['removeFromSearchHistory', 'clearCacheSearch', 'trailer', 'nothing', 'playItem']:  # nie może na razie być playitem, bo jak nie ma źródeł (katalog), to wisi
    # if handle > -1 and action not in ['removeFromSearchHistory', 'clearCacheSearch', 'trailer', 'nothing']: 
    if not odwolany_test:
        if handle > -1 and action not in ['removeFromSearchHistory', 'clearCacheSearch', 'trailer', 'nothing']:

            c = 3
            while control.condVisibility('Window.IsActive(busydialog)') and c > 0:
                control.sleep0(100)
                c -= 1

            # PluginName = control.infoLabel('Container.PluginName')  # tu można pomyśleć (jak pusty, lub nie 'plugin.video.kadrplus', to oznacza, że wywoływane z innego pluginu)
            # control.log(f"[FanFilm] {PluginName=}", 1)
            # isFolder = control.condVisibility('ListItem.IsFolder')  # nie sprawdza się, bo nie zawsze potrafi odczytać prawidłową pozycję
            # control.log(f"[FanFilm] {isFolder=}", 1)
            # IsPlayable = control.infoLabel('ListItem.Property(IsPlayable)')  # na tym też do końca nie można polegać, bo Kodi czasami tego nie odczytuje prawidłowo
            # control.log(f'[FanFilm] {IsPlayable=}', 1)
            control.sleep0(100)
            ilosc_pozycji_do_wyswietlenia = control.infoLabel("Container().NumItems")  # często pokazuje informacje przed odświeżeniem, także nieprzydatne wówczas (a jak pokazuje, to czasami jest puste a czasami '0' - i bądź tu mądry)
            control.log(f'[FanFilm] {ilosc_pozycji_do_wyswietlenia=}', 1) if not ilosc_pozycji_do_wyswietlenia or ilosc_pozycji_do_wyswietlenia == '0' else ''
            # control.log(f"[FanFilm] {control.currentDialogId()=}", 1)  # może być BusyDialog albo ProgressDialog (10101)

            if (
                control.condVisibility('Window.IsActive(busydialog)')  # trafiłem na ProgressDialog przy próbie tworzenia skrótu przez skórkę
                or (not ilosc_pozycji_do_wyswietlenia or int(ilosc_pozycji_do_wyswietlenia) < 1)  # to pomogło przy próbie tworzenia skrótu przez skórkę
               ):
                if action != "play" or select=='0':  # nie wiem, czy to dobrze !  (jeszcze ewentualnie z select można spróbować dołożyć, bo playItem się nie sprawdził, jak materiał się nie odtworzył
                    control.log(f'[FanFilm] dodanie pustego katalogu  {action=}', not(logsilent))  # potrzebne tylko, gdy akcja została wywoływana jako folder, a nie wygenerowała żadnej zawartości
                    updateListing = True if params.get("r") else False  # True świadczy, że po drodze było odświeżanie
                    control.directory(handle, cacheToDisc=True, updateListing=updateListing)  # w Kodi 19 może pojawiś się czasami WARNING w logach (że niepotrzebnie czasami taka operacja), ale w nowszych nie widziałem
                    control.sleep0(100)
                else:
                    control.log(f"[FanFilm] czy busydialog nie będzie wisiał w nieskończoność ? \n{action=} \n{control.condVisibility('Window.IsActive(busydialog)')=} \n{ilosc_pozycji_do_wyswietlenia=} \n{select=} {handle=}", not(logsilent))
                    pass

                if control.currentDialogId() == 9999 and action != "playItem":  # nie pamiętam co oznacza 9999 (może brak jakiegokolwiek okna)
                    if action != "play" or select == "1":  # czy zmienna "select" zawsze jest zdefiniowana?
                        if not control.monitor.abortRequested():
                            control.log(f"[FanFilm] {sys.argv=}", not(logsilent))
                            if False:  # tymczasowo, jako wybór wariantu
                                # control.log(f"[FanFilm] Can't display content for {sys.argv=}", 1)  # wyniosłem wyżej
                                # control.log(f"------------------------------------------------------------ \n", 1)
                                control.infoDialog(f"Brak zawartości[CR] ERROR    for {action=}", icon="ERROR", time=2000, sound=True)
                                # control.addItem(handle, url=sys.argv[0]+"?action=nothing", listitem=control.item(label="Wystąpił jakiś błąd"), isFolder=False)
                            else:
                                # control.sleep(100)
                                if control.infoLabel('ListItem.Property(IsPlayable)') != 'true':  # nie wiem, czy to ma sens, bo chyba zawsze będzie spełnione
                                    ilosc_pozycji_do_wyswietlenia = control.infoLabel("Container().NumItems")
                                    # control.log(f'[FanFilm] {ilosc_pozycji_do_wyswietlenia=}', 1)
                                    if ilosc_pozycji_do_wyswietlenia and int(ilosc_pozycji_do_wyswietlenia) < 1:  # dodatkowe zabezpieczenie
                                        control.log(f"[FanFilm] action Back", not(logsilent))
                                        control.execute('Action(Back)')

    control.log(f'[FanFilm] koniec   {params=}\n', not(logsilent))


    if 0:  # debug
        user_locals = {k: str(v) for k, v in locals().items() if not k.startswith('__')}
        # control.log(str(user_locals), 1)
        import json
        control.log( json.dumps(user_locals, indent=2), 1)

        user_globals = {k: str(v) for k, v in globals().items() if not k.startswith('__')}
        # control.log(str(user_globals), 1)
        import json
        control.log( json.dumps(user_globals, indent=2), 1)

        control_vars = {k: str(v) for k, v in vars(control).items() if not k.startswith('__')}
        import json
        control.log( "control_vars = " + json.dumps(control_vars, indent=2), 1)

        del user_locals, user_globals, json

    # control.log(f'{sys.argv[0]=}  {sys.argv[1]=}  {sys.argv[2]=}',1)
    control.log(f'{sys.argv=}\n\n',1)


    # if control.setting("invoker.fix") == "true":
        # return True
        # pass

    if control.window.getProperty('FanFilm.flag.play_took_place'):
        # Kadr+ 2.40.73:
        # Nie czyścimy tej flagi globalnie przy wejściu do pluginu. Musi ją skonsumować
        # widok Postęp, bo inaczej po obejrzeniu odcinka może zostać stary cache i ten
        # sam odcinek nadal wisi jako następny.
        if control.setting("invoker.fix") == "true" and control.currentWindowId != 10000:
            return True



if __name__ == '__main__':

    if router():
        sys.exit()
