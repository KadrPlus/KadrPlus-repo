# Kadr+ compatibility shim for Kodi environments without typing_extensions.
try:
    from typing import *  # noqa
except Exception:
    pass
try:
    from typing import TypedDict, Literal, Generic, Protocol, Final, NoReturn, TypeAlias, runtime_checkable
except Exception:
    pass
try:
    from typing import NotRequired, Required, Self, TypeGuard, Concatenate, ParamSpec
except Exception:
    class _TypingExtFallback:
        def __class_getitem__(cls, item): return object
    NotRequired = Required = Self = TypeGuard = Concatenate = ParamSpec = _TypingExtFallback
try:
    override
except NameError:
    def override(func): return func
try:
    deprecated
except NameError:
    def deprecated(*args, **kwargs):
        def deco(obj): return obj
        return deco
